import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { AngularFireMessagingModule } from '@angular/fire/messaging';
import { AngularFireFunctionsModule } from '@angular/fire/functions';
import { LoginComponent } from './login/login.component';
import { providers } from './app.provider';
import { AppRoutingModule } from './app-routing.module';
import { TemplateComponent } from './template/template.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';
import { CashForecastArInterfaceComponent } from './finance/cashforecast/arinterface/arinterface.component';
import { CashForecastCustomerComponent } from './finance/cashforecast/customer/customer.component';
import { CashForecastSupplierComponent } from './finance/cashforecast/supplier/supplier.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { RegisterComponent } from './onboard/suppliers/register/register.component';
import { OutCanadaCustomersComponent } from './outcanada/customer/customer.component';
import { OutCanadaComponent } from './outcanada/outcanada.component';
import { OutCanadaItemsComponent } from './outcanada/items/items.component';
import { OutCanadaMainComponent } from './outcanada/main/main.component';
import { OutCanadaManagerComponent } from './outcanada/manager/manager.component';
import { OutCanadaMonthComponent } from './outcanada/month/month.component';
import { CanadaRevenueProvinceComponent } from './outcanada/province/province.component';
import { OutOfDoorComponent } from './outofdoor/outofdoor.component';
import { OutOfDoorAgentComponent } from './outofdoor/agent/agent.component';
import { OutOfDoorCustomerComponent } from './outofdoor/customer/customer.component';
import { OutOfDoorDistributorComponent } from './outofdoor/distributor/distributor.component';
import { OutOfDoorItemComponent } from './outofdoor/item/item.component';
import { ItemSummaryComponent } from './outofdoor/itemsummary/itemsummary.component';
import { MainOutOfDoorComponent } from './outofdoor/main/main.component';
import { OutOfDoorMonthComponent } from './outofdoor/month/month.component';
import { NewCustomersComponent } from './outofdoor/newcustomers/newcustomers.component';
import { RevenueManagerComponent } from './outofdoor/revenuemanager/revenuemanager.component';
import { OutofdoorSalesManagersComponent } from './outofdoor/salesmanagers/salesmanagers.component';
import { OutOfDoorStateComponent } from './outofdoor/state/state.component';
import { OutofdoorTMCustomersComponent } from './outofdoor/tmcustomers/tmcustomers.component';
import { PriceListComponent } from './pricelists/pricelists.component';
import { PriceListDashboardComponent } from './pricelists/dashboard/dashboard.component';
import { EditProductRecipeComponent } from './productversion/recipe/edit/edit.component';
import { RecipesMainComponent } from './productversion/recipe/main/main.component';
import { ViewProductRecipeComponent } from './productversion/recipe/view/view.component';
import { ProfileComponent } from './profile/profile.component';
import { PmmvVsPmvComponent } from './reports/other/pmmvvspmv/pmmvvspmv.component';
import { ConversionComponent } from './utilities/conversion/conversion.component';
import { ProductsComponent } from './utilities/products/products.component';
import { CalendarComponent } from './globals/calendar/calendar.component';
import { TimelineComponent } from './globals/timeline/timeline.component';
import { PreAuthorizationApproveComponent } from './pre-authorization/request/approve/approve.component';
import { ShareModule } from './share/share.module';
import { SupplierClaimCreateComponent } from './reclaims/supplierclaim/create/create.component';
import { SupplierClaimSummaryComponent } from './reclaims/supplierclaim/summary/summary.component';
import { ReclaimsDashboardComponent } from './reclaims/dashboard/dashboard.component';
import { CustomerClaimSummaryComponent } from './reclaims/customerclaim/summary/summary.component';
import { CustomerClaimCreateComponent } from './reclaims/customerclaim/create/create.component';
import { ShippingLabelsComponent } from './shipping-labels/shipping-labels.component';
import { ApproveDonationApplicationComponent } from './donation/manage/application/approve/approve-donation-application.component';
import { HumanandWildLifeRegisterComponent } from './humansandwildlife/register/register.component';
import { HumanandWildlifeUserDashboardComponent } from './humansandwildlife/users-dashboard/dashboard.component';
import { HWAssociationsSummaryComponent } from './humansandwildlife/associations/summmary/summmary.component';
import { HWAssociationComponent } from './humansandwildlife/associations/manage/manage.component';
import { HumansAndWildLifeDashboardComponent } from './humansandwildlife/dashboard/dashboard.component';
import { HumansAndWildLifeInvitationsComponent } from './humansandwildlife/invitations/invitations.component';
import { ApproveLeaveComponent } from './hcm/leavemanagement/leaves/approve/approve.component';
import { PromotionApproveComponent } from './promotions/approve/approve.component';

export function HttpLoaderFactory(http: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    LoginComponent,
    TemplateComponent,
    DashboardComponent,
    AppComponent,
    CashForecastArInterfaceComponent,
    CashForecastCustomerComponent,
    CashForecastSupplierComponent,
    NotificationsComponent,
    RegisterComponent,
    OutCanadaComponent,
    OutCanadaCustomersComponent,
    OutCanadaItemsComponent,
    OutCanadaMainComponent,
    OutCanadaManagerComponent,
    OutCanadaMonthComponent,
    CanadaRevenueProvinceComponent,
    OutOfDoorComponent,
    OutOfDoorAgentComponent,
    OutOfDoorCustomerComponent,
    OutOfDoorDistributorComponent,
    OutOfDoorItemComponent,
    ItemSummaryComponent,
    MainOutOfDoorComponent,
    OutOfDoorMonthComponent,
    NewCustomersComponent,
    RevenueManagerComponent,
    OutofdoorSalesManagersComponent,
    OutOfDoorStateComponent,
    OutofdoorTMCustomersComponent,
    PriceListComponent,
    PriceListDashboardComponent,
    EditProductRecipeComponent,
    RecipesMainComponent,
    ViewProductRecipeComponent,
    ProfileComponent,
    PmmvVsPmvComponent,
    ConversionComponent,
    ProductsComponent,
    CalendarComponent,
    TimelineComponent,
    PreAuthorizationApproveComponent,
    SupplierClaimCreateComponent,
    SupplierClaimSummaryComponent,
    ReclaimsDashboardComponent,
    CustomerClaimSummaryComponent,
    CustomerClaimCreateComponent,
    ShippingLabelsComponent,
    ApproveDonationApplicationComponent,
    HumanandWildLifeRegisterComponent,
    HumanandWildlifeUserDashboardComponent,
    HWAssociationsSummaryComponent,
    HWAssociationComponent,
    HumansAndWildLifeDashboardComponent,
    HumansAndWildLifeInvitationsComponent,
    ApproveLeaveComponent,
    PromotionApproveComponent,
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFirestoreModule,
    AngularFireMessagingModule,
    AngularFireStorageModule,
    AngularFireFunctionsModule,
    HttpClientModule,
    ShareModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
  ],
  providers,
  bootstrap: [AppComponent],
})
export class AppModule {}
