import { NgModule } from '@angular/core';
import { ShareModule } from '../share/share.module';

import { TemplateResolve } from './template.resolve';
import { AgentTargetsRoutingModule } from './agent-targets-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TemplatesComponent } from './templates/templates.component';
import { TargetsComponent } from './targets/targets.component';
import { DetailComponent } from './templates/detail/detail.component';

@NgModule({
  declarations: [DashboardComponent, TemplatesComponent, TargetsComponent, DetailComponent],
  imports: [
    ShareModule,
    AgentTargetsRoutingModule
  ],
  providers: [TemplateResolve]
})
export class AgentTargetsModule { }
