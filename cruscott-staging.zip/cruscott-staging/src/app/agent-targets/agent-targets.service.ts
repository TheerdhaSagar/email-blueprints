import { Injectable } from '@angular/core';
import { HttpService } from '../globals/http.service';
import { FormatService } from '../globals/format.service';
import { ServerError } from '../globals/server.error';
import { Response } from '../globals/response';
import { Template, TemplateHeader, TemplateResponse } from './template';
import { Target, Targets } from './target';
import { Salesrep } from './salesrep';

@Injectable({
  providedIn: 'root'
})
export class AgentTargetsService {
  private _formatService: FormatService;
  private _httpService: HttpService;

  urlPrefix = '/agent/targets/';

  constructor(formatService: FormatService, httpService: HttpService) {
    this._formatService = formatService;
    this._httpService = httpService;
  }

  addAgentTarget(target: Target): Promise<Response> {
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', this.urlPrefix, { ...target }, (response) => {
        if (!response) {
          reject(new ServerError('addAgentTarget'));
        } else {
          resolve(response);
        }
      });
    });
  }

  copyTemplate(templateId: number, userId: number): Promise<Response | TemplateResponse> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}templates/copy/${templateId}/${userId}/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('copyTemplate'));
        } else {
          resolve(response);
        }
      });
    });
  }

  deleteAgentTarget(templateId: number, salesrepId: number): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}${templateId}/${salesrepId}/`;
      this._httpService.httpRequest('DELETE', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deleteAgentTarget'));
        } else {
          resolve(response);
        }
      });
    });
  }

  deleteTemplate(templateId: number): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}templates/${templateId}/`;
      this._httpService.httpRequest('DELETE', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deleteTemplate'));
        } else {
          resolve(response);
        }
      });
    });
  }

  formatTemplateData(data: TemplateHeader[]): TemplateHeader[] {
    const templates = [...data];
    for (let i = 0; i < templates.length; i++) {
      templates[i].f_start_date = this._formatService.formatDate(templates[i].start_date);
      templates[i].f_end_date = this._formatService.formatDate(templates[i].end_date);
    }
    return templates;
  }

  formatTemplateHeader(data: Template): Template {
    const template = { ...data };
    template.header.start_date = this._formatService.formatDate(data.header.start_date);
    template.header.end_date = this._formatService.formatDate(data.header.end_date);
    return template;
  }

  getTemplates(templateId: number = null): Promise<Template | TemplateHeader[]> {
    return new Promise((resolve, reject) => {
      let endPoint = `${this.urlPrefix}templates/`;
      if (templateId) {
        endPoint += `${templateId}/`;
      }
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('getTemplates'));
        } else if (templateId) {
          resolve(this.formatTemplateHeader(response));
        } else {
          resolve(this.formatTemplateData(response));
        }
      });
    });
  }

  loadPeriods(): Promise<Array<{ period_name: string }>> {
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', '/supplier/period/', null, (response) => {
        if (!response) {
          reject(new ServerError('loadPeriods'));
        } else {
          resolve(response);
        }
      });
    });
  }

  loadSalesreps(): Promise<Salesrep[]> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}salesreps/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('loadSalesreps'));
        } else {
          resolve(response);
        }
      });
    });
  }

  loadTargets(templateId: number): Promise<Targets> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}${templateId}/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('loadTargets'));
        } else {
          resolve(response);
        }
      });
    });
  }

  saveTarget(target: Target): Promise<Response> {
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('PUT', this.urlPrefix, { ...target }, (response) => {
        if (!response) {
          reject(new ServerError('saveTarget'));
        } else {
          resolve(response);
        }
      });
    });
  }

  saveTemplate(template: Template): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}templates/`;
      const data = { ...template };
      data.header.start_date = this._formatService.parseDate(data.header.start_date);
      data.header.end_date = this._formatService.parseDate(data.header.end_date);
      this._httpService.httpRequest('PUT', endPoint, data, (response) => {
        if (!response) {
          reject(new ServerError('saveTemplate'));
        } else {
          resolve(response);
        }
      });
    });
  }

  sendMailToAgents(templateId: number, subject: string): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}email/send/`;
      const data = { temp_id: templateId, subject };
      this._httpService.httpRequest('POST', endPoint, data, (response) => {
        if (!response) {
          reject(new ServerError('sendMailToAgents'));
        } else {
          resolve(response);
        }
      });
    });
  }
}
