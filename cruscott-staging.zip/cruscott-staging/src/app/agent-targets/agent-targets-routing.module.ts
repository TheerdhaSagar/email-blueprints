import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TemplatesComponent } from './templates/templates.component';
import { TargetsComponent } from './targets/targets.component';
import { DetailComponent } from './templates/detail/detail.component';
import { TemplateResolve } from './template.resolve';

const routes: Routes = [
  { path: '', component: DashboardComponent },
  { path: 'templates', component: TemplatesComponent },
  { path: 'templates/:id', component: DetailComponent, resolve: { template: TemplateResolve } },
  { path: 'targets', component: TargetsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgentTargetsRoutingModule { }
