import { TemplateLine } from './template';

export interface Target {
  agente_name?: string;
  bonus_period?: string;
  display_sequence?: number;
  level_1_description: string;
  level_2_description: string;
  level_3_description: string;
  level_4_description: string;
  level_5_description: string;
  level_1_target_amount?: number;
  level_2_target_amount?: number;
  level_3_target_amount?: number;
  level_4_target_amount?: number;
  level_5_target_amount?: number;
  salesrep_id: number;
  temp_id: number;
  template_name?: string;
  user_id: number;
}

export interface Targets {
  lines: TemplateLine[];
  targets: Target[];
}
