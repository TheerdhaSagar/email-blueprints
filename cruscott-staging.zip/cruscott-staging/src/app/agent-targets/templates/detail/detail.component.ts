import { Component, OnInit, Injector } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { AgentTargetsService } from '../../agent-targets.service';
import { Template } from '../../template';

declare const FooPicker;

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['../../targets/targets.component.scss']
})
export class DetailComponent implements OnInit {
  private _activatedRoute: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _agentTargetsService: AgentTargetsService = this.injector.get(AgentTargetsService);
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _router: Router = this.injector.get(Router);

  dateFormat: string;
  periods: Array<{ period_name: string }>;
  template: Template;
  userId: number;

  constructor(private injector: Injector) {}

  ngOnInit(): void {
    this._cacheService.getUser((user) => {
      if (!user) {
        this._router.navigate(['login']);
      } else if (!this._cacheService.user) {
        this._cacheService.initialize(user);
      } else {
        this.userId = user.user_id;
        this.dateFormat = user.date_format || 'dd-MMM-yyyy';
        this._activatedRoute.data.subscribe((data) => {
          if (data.template) {
            this.template = data.template;
            this.initializeDatePickers();
          }
        });
        this.loadPeriods();
      }
    });
  }

  initializeDatePickers(): void {
    new FooPicker({
      id: 'start-date',
      dateFormat: this.dateFormat
    });

    new FooPicker({
      id: 'end-date',
      dateFormat: this.dateFormat
    });
  }

  loadPeriods(): void {
    this._agentTargetsService.loadPeriods()
      .then((result) => {
        this.periods = result;
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  saveTemplate(): void {
    this.template.header.user_id = this.userId;
    this._agentTargetsService.saveTemplate(this.template)
      .then((result) => {
        this._appService.notify(result);
        if (result.status === 0) {
          this._router.navigate(['agent-targets/templates']);
        } else {
          this.template = this._agentTargetsService.formatTemplateHeader(this.template);
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }
}
