import { Component, OnInit, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { AgentTargetsService } from '../agent-targets.service';
import { TemplateHeader, TemplateResponse } from '../template';

@Component({
  selector: 'app-templates',
  templateUrl: './templates.component.html',
  styleUrls: ['./templates.component.scss']
})
export class TemplatesComponent implements OnInit {
  private _agentTargetsService: AgentTargetsService = this.injector.get(AgentTargetsService);
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _router: Router = this.injector.get(Router);

  pageDim: boolean;
  selectedTemplate: TemplateHeader;
  showCopyDialog: boolean;
  showDeleteDialog: boolean;
  templates: TemplateHeader[];
  userId: number;

  constructor(private injector: Injector) {}

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      } else {
        this.getTemplates();
        this.userId = data.user_id;
      }
    });
  }

  copyTemplate(): void {
    this.showCopyDialog = false;
    this._agentTargetsService.copyTemplate(this.selectedTemplate.temp_hdr_id, this.userId)
      .then((result) => {
        this._appService.notify(result);
        if (result.status === 0) {
          const data = result as TemplateResponse;
          this._router.navigate(['agent-targets/templates', data.template_id]);
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  deleteTemplate(): void {
    this.showDeleteDialog = false;
    this._agentTargetsService.deleteTemplate(this.selectedTemplate.temp_hdr_id)
      .then((result) => {
        this._appService.notify(result);
        if (result.status === 0) {
          this.getTemplates();
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  getTemplates(): void {
    this.pageDim = false;
    this._agentTargetsService.getTemplates()
      .then((result) => {
        this.templates = result as TemplateHeader[];
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }
}
