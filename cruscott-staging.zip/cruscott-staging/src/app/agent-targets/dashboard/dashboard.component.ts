import { Component } from '@angular/core';
import { DataService } from '../../globals/data.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent {
  roles = this.dataService.roles;

  constructor(private dataService: DataService) {}
}
