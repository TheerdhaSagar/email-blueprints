export interface Salesrep {
  name: string;
  salesrep_id: number;
}
