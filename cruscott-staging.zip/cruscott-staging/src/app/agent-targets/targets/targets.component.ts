import { Component, OnInit, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { AgentTargetsService } from '../agent-targets.service';
import { TemplateHeader } from '../template';
import { Target, Targets } from '../target';
import { Salesrep } from '../salesrep';

@Component({
  selector: 'app-targets',
  templateUrl: './targets.component.html',
  styleUrls: ['./targets.component.scss', '../templates/templates.component.scss'],
  providers: [OrderByPipe]
})
export class TargetsComponent implements OnInit {
  private _agentTargetsService: AgentTargetsService = this.injector.get(AgentTargetsService);
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _router: Router = this.injector.get(Router);

  filteredSalesreps: Salesrep[];
  pageDim: boolean;
  salesreps: Salesrep[];
  selectedSalesrepId: number;
  selectedTarget: Target;
  showAddDialog: boolean;
  showDeleteDialog: boolean;
  showDialog: boolean;
  subject: string;
  targets: Targets;
  templateId: number;
  templates: TemplateHeader[];
  totals: number[];
  toggleFilter: (e?) => void;
  userId: number;

  constructor(private injector: Injector) {
    this.toggleFilter = this._appService.toggleFilter();
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      } else {
        this.userId = data.user_id;
        this.getTemplates();
        this.loadSalesreps();
      }
    });
  }

  addAgentTarget(): void {
    if (!this.selectedSalesrepId) {
      return;
    }
    const requestObj = this.getTargetRequestObject();
    this.showAddDialog = false;
    this._agentTargetsService.addAgentTarget(requestObj)
      .then((result) => {
        if (result.status === 0) {
          this.selectedSalesrepId = null;
          this.loadTargets(false);
        } else {
          this._appService.notify(result);
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  calculateLevelTotal(level: string): number {
    if (!this.targets || !this.targets.targets) {
      return 0;
    }
    return this.targets.targets.reduce((total, target) => total + target[level] || 0, 0);
  }

  calculateTotals(): void {
    this.totals = [
      this.calculateLevelTotal('level_1_target_amount'),
      this.calculateLevelTotal('level_2_target_amount'),
      this.calculateLevelTotal('level_3_target_amount'),
      this.calculateLevelTotal('level_4_target_amount'),
      this.calculateLevelTotal('level_5_target_amount'),
    ];
  }

  deleteAgentTarget(): void {
    if (!this.selectedTarget) {
      return;
    }
    this.showDeleteDialog = false;
    this._agentTargetsService.deleteAgentTarget(this.selectedTarget.temp_id, this.selectedTarget.salesrep_id)
      .then((result) => {
        if (result.status === 1) {
          this._appService.notify(result);
        } else {
          this.targets.targets = this.targets.targets.filter((r) => r.salesrep_id !== this.selectedTarget.salesrep_id);
          this.filterSalesreps();
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  exportToExcel(): void {
    if (!this.targets || !this.targets.targets || !this.targets.lines) {
      return;
    }
    const data = this.targets.targets;
    const tableData = { data: [], footer: [] };
    data.forEach((row) => {
      tableData.data.push(this.getExportHeaderRow(row));
    });
    tableData.footer.push({ data: '' });
    this.totals.forEach((total) => {
      tableData.footer.push({ data: total, align: 'right' });
    });
    this._appService.tableToExcel('Agent Targets', tableData, 'export-data');
  }

  filterSalesreps(): void {
    this.filteredSalesreps = [];
    if (this.targets && this.targets.targets) {
      this.salesreps.forEach((salesrep) => {
        const index = this.targets.targets.findIndex((target) => salesrep.salesrep_id === target.salesrep_id);
        if (index === -1) {
          this.filteredSalesreps.push(salesrep);
        }
      });
    } else {
      this.filteredSalesreps = this.salesreps;
    }
  }

  getExportHeaderRow(row): any {
    const lines = this._orderBy.transform(this.targets.lines, 'line_num', false);
    const obj = {
      'Agenti ITALIA': { data: row.agente_name }
    };
    lines.forEach((line) => {
      obj[line.line_name] = { data: row[`level_${line.line_num}_target_amount`], align: 'right' };
    });
    return obj;
  }

  getTargetRequestObject(): Target {
    return {
      temp_id: this.templateId,
      user_id: this.userId,
      salesrep_id: this.selectedSalesrepId,
      level_1_description: this.getTargetLevelDescrition(1),
      level_2_description: this.getTargetLevelDescrition(2),
      level_3_description: this.getTargetLevelDescrition(3),
      level_4_description: this.getTargetLevelDescrition(4),
      level_5_description: this.getTargetLevelDescrition(5)
    };
  }

  getTargetLevelDescrition(level: number): string {
    const templateLine = this.targets.lines.filter((line) => line.line_num === level);
    return templateLine[0].line_name;
  }

  getTemplates(): void {
    this._agentTargetsService.getTemplates()
      .then((result) => {
        this.templates = result as TemplateHeader[];
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.toggleFilter();
      });
  }

  loadSalesreps(): void {
    this._agentTargetsService.loadSalesreps()
      .then((result) => {
        this.salesreps = result;
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  loadTargets(filter = true): void {
    if (filter) {
      this.toggleFilter();
    }
    this.pageDim = true;
    this._agentTargetsService.loadTargets(this.templateId)
      .then((result) => {
        this.targets = result;
        this.calculateTotals();
        this.filterSalesreps();
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  saveTarget(target: Target): void {
    const data = { ...target };
    data.user_id = this.userId;
    this._agentTargetsService.saveTarget(data)
      .then((result) => {
        if (result.status === 1) {
          this._appService.notify(result);
        } else {
          this.calculateTotals();
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  sendEmail(): void {
    if (!this.subject) {
      return;
    }
    this.showDialog = false;
    this.pageDim = true;
    this._agentTargetsService.sendMailToAgents(this.templateId, this.subject)
      .then((result) => {
        this._appService.notify(result);
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.subject = '';
        this.pageDim = false;
      });
  }
}
