import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { AgentTargetsService } from './agent-targets.service';
import { Template, TemplateHeader } from './template';

@Injectable()
export class TemplateResolve implements Resolve<Template | TemplateHeader[]> {
  constructor(private agentTargetsService: AgentTargetsService) {}

  resolve(route: ActivatedRouteSnapshot): Promise<Template | TemplateHeader[]> {
    const templateId = route.params.id;
    return this.agentTargetsService.getTemplates(templateId);
  }
}
