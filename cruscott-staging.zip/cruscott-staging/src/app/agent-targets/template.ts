export interface TemplateHeader {
  end_date: string;
  f_start_date: string;
  f_end_date: string;
  period_name: string;
  period_month: string;
  period_year: string;
  processed_flag: string;
  start_date: string;
  temp_hdr_id: number;
  temp_name: string;
  user_id: number;
}

export interface TemplateLine {
  temp_hdr_id: number;
  line_num: number;
  line_name: string;
  bonus_percentage: number;
}

export interface Template {
  header: TemplateHeader;
  lines: TemplateLine[];
}

export interface TemplateResponse {
  msg: string;
  status: number;
  template_id: number;
}
