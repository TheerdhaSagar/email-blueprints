import { Injectable } from '@angular/core';
import { HttpService } from '../../globals/http.service';
import { ServerError } from '../../globals/server.error';
import { Response } from '../../globals/response';
import { Supplier } from './supplier';
import { APIError } from '../../globals/api.error';

@Injectable({
  providedIn: 'root'
})
export class SupplierCashflowSetupService {
  private _httpService: HttpService;
  cashflowUrlPrefix = '/cashforecast/';
  urlPrefix = '/supplier/';

  constructor(httpService: HttpService) {
    this._httpService = httpService;
  }

  createOrUpdateSupplierSetup(requestMethod: string, supplier: Supplier): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.cashflowUrlPrefix}supplier/setup/`;
      this._httpService.httpRequest(requestMethod, endPoint, { ...supplier }, (response) => {
        if (!response) {
          reject(new ServerError('createOrUpdateSupplierSetup'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  deleteSupplierSetup(vendorId: number, orgId: number): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.cashflowUrlPrefix}supplier/setup/${vendorId}/${orgId}/`;
      this._httpService.httpRequest('DELETE', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deleteSupplierSetup'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  getSupplierSetupData(orgId: number): Promise<Supplier[]> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.cashflowUrlPrefix}supplier/setup/${orgId}/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('getSupplierSetupData'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  getSuppliers(): Promise<Supplier[]> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}vendorlov/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('getSuppliers'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }
}
