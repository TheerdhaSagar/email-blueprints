import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupplierCashflowSetupComponent } from './supplier-cashflow-setup.component';

describe('SupplierCashflowSetupComponent', () => {
  let component: SupplierCashflowSetupComponent;
  let fixture: ComponentFixture<SupplierCashflowSetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupplierCashflowSetupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupplierCashflowSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
