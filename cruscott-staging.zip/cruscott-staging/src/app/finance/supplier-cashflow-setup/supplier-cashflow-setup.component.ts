import {
  Component, OnInit, Injector, ViewEncapsulation, OnDestroy
} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { SupplierCashflowSetupService } from './supplier-cashflow-setup.service';
import { Supplier } from './supplier';
import { OrderByPipe } from '../../globals/order-by.pipe';

@Component({
  selector: 'app-supplier-cashflow-setup',
  templateUrl: './supplier-cashflow-setup.component.html',
  styleUrls: ['./supplier-cashflow-setup.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SupplierCashflowSetupComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _router: Router = this.injector.get(Router);
  private _supplierCashflowSetupService = this.injector.get(SupplierCashflowSetupService);

  allSuppliers: Supplier[];
  desc = false;
  orgId: number;
  pageDim: boolean;
  predicate: string;
  setupData: Supplier[];
  showDialog = false;
  showSupplierDialog = false;
  subOrgChange: Subscription;
  supplier: Supplier;
  suppliers: Supplier[] = [];
  userId: number;

  constructor(private injector: Injector) {
    this.supplier = {} as Supplier;
    this.predicate = 'vendor_name';
  }

  ngOnInit(): void {
    this._cacheService.getUser((user) => {
      if (!user) {
        this._router.navigate(['login']);
      } else {
        this.userId = user.user_id;
        this.orgId = this._cacheService.getOrgId();
        this.pageDim = true;
        this.loadSetupData();

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.pageDim = true;
          this.orgId = this._cacheService.getOrgId();
          this.loadSetupData();
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  backToDashboard(): void {
    this._router.navigate(['finance/cashflow']);
  }

  createOrUpdateSupplierSetup(): void {
    this.showSupplierDialog = false;
    this.supplier.user_id = this.userId;
    this.supplier.org_id = this.orgId;
    this._supplierCashflowSetupService.createOrUpdateSupplierSetup('POST', this.supplier)
      .then(() => {
        this.loadSetupData();
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
        this.supplier = {} as Supplier;
      });
  }

  deleteSupplierData(): void {
    this.showDialog = false;
    this._supplierCashflowSetupService.deleteSupplierSetup(this.supplier.vendor_id, this.orgId)
      .then(() => {
        const vendor = this.allSuppliers.find((supplier) => supplier.vendor_id === this.supplier.vendor_id);
        this.suppliers.push(vendor);
        this.suppliers = this._orderBy.transform(this.suppliers, 'vendor_name', false);
        this.loadSetupData();
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
        this.supplier = {} as Supplier;
      });
  }

  filterSuppliers(): void {
    this.setupData.forEach((data) => {
      const index = this.suppliers.findIndex((supplier) => supplier.vendor_id === data.vendor_id);
      if (index !== -1) {
        this.suppliers.splice(index, 1);
      }
    });
  }

  async loadSetupData(): Promise<void> {
    await this.loadSuppliers();
    this._supplierCashflowSetupService.getSupplierSetupData(this.orgId)
      .then((result) => {
        this.setupData = result;
        this.filterSuppliers();
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  loadSuppliers(): Promise<void> {
    return new Promise((resolve) => {
      this._supplierCashflowSetupService.getSuppliers()
        .then((result) => {
          this.allSuppliers = this._orderBy.transform(result, 'vendor_name', false);
          this.suppliers = [...this.allSuppliers];
        })
        .catch((error) => {
          this._appService.notify(error);
        })
        .finally(() => {
          resolve();
        });
    });
  }

  onContentChange(index: number, cellAttribute: string): void {
    const cell = document.getElementById(`cell-${index}-${cellAttribute}`);
    if (!cell) {
      return;
    }
    const cellValue = cell.innerText;
    const data = this.setupData[index][cellAttribute];
    if (!data || (data.toString() !== cellValue.toString())) {
      this.setupData[index][cellAttribute] = cellValue;
      cell.innerText = cellValue;
      this.supplier = this.setupData[index];
      this.supplier.user_id = this.userId;
      this._supplierCashflowSetupService.createOrUpdateSupplierSetup('PUT', this.supplier)
        .catch((error) => {
          this._appService.notify(error);
        });
    }
  }

  sort(predicate: string): void {
    if (predicate === this.predicate) {
      this.desc = !this.desc;
    }
    this.predicate = predicate;
  }
}
