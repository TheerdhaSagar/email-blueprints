export interface Supplier {
  days: number;
  invoice_currency_code: string;
  last_updated_date: string;
  num_1099: string;
  org_id: number;
  user_id: number;
  vat_registration_num: string;
  vendor_id: number;
  vendor_name: string;
  vendor_num: string;
}
