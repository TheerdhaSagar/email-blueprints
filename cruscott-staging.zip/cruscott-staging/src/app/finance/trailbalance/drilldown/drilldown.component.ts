import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { OrderByPipe } from '../../../globals/order-by.pipe';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';

@Component({
  selector: 'app-finance-trailbalance-drilldown',
  templateUrl: './drilldown.component.html',
  styleUrls: ['./drilldown.component.scss'],
  providers: [OrderByPipe]
})
export class TrailDrillDownComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  columnNames: any;
  columns: any;
  desc: boolean;
  drill_data: any;
  drilldownsearch: any;
  predicate: string;
  reportName: any;
  showSpinner: boolean;
  subOrgChange: Subscription;
  tb_details: any;
  toggleFilter: any;
  total_amount_credit: any;
  total_amount_debit: any;
  total_credit: any;
  total_debit: any;

  constructor(appService: AppService, cacheService: CacheService, orderBy: OrderByPipe, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.columnNames = [];
    this.columns = null;
    this.desc = false;
    this.drill_data = [];
    this.predicate = 'category';
    this.reportName = null;
    this.showSpinner = true;
    this.subOrgChange = null;
    this.tb_details = appService.balanceDetails;
    this.toggleFilter = null;
    this.total_amount_credit = null;
    this.total_amount_debit = null;
    this.total_credit = null;
    this.total_debit = null;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.showSpinner = true;
        this.toggleFilter = this._appService.toggleFilter();
        this.reportName = 'Trail Balance Drilldown';
        this.loadData();

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this._cacheService.setAssetBalanceData('');
          this._cacheService.setLiabilityData('');
          this._cacheService.setRevenueData('');
          this._router.navigate(['finance/trailbalance']);
        });
      }
    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  // Exports the table data into spreadsheet
  exportToExcel() {
    this.toggleFilter();
    let columns = this.columns,
      data = this._orderBy.transform(this.drill_data, this.predicate, this.desc),
      i,
      tableData: any = {},
      tmpReports = [];
    try {
      for (i = 0; i < data.length; i++) {
        let tmpReport: any = {};
        tmpReport.Category = { data: data[i].category };
        tmpReport.Source = { data: data[i].source };
        tmpReport['Journal Name'] = { data: data[i].journal_name };
        tmpReport['Journal Description'] = { data: data[i].journal_description };
        tmpReport.Account = {
          data: data[i].account,
          align: 'right'
        };
        tmpReport['JE Line #'] = {
          data: data[i].je_line_num,
          align: 'right'
        };
        tmpReport.Currency = { data: data[i].currency };
        tmpReport.Debit = {
          data: data[i].f_debit,
          align: 'right'
        };
        tmpReport.Credit = {
          data: data[i].f_credit,
          align: 'right'
        };
        tmpReport['Accounted Debit'] = {
          data: data[i].f_account_debit,
          align: 'right'
        };
        tmpReport['Accounted Credit'] = {
          data: data[i].f_account_credit,
          align: 'right'
        };
        tmpReport['Line Description'] = { data: data[i].line_description };
        if (columns) {
          for (let j = 0; j < columns.length; j++) {
            tmpReport[this._formatService.formatColumnName(columns[j].name)] = { data: data[i][columns[j].name] };
          }
        }
        tmpReports.push(tmpReport);
      }
      tableData.data = tmpReports;

      this._appService.tableToExcel('Trail Balance Drill down', tableData, 'export-data');
    } catch (e) {
      this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
    }
  }

  formatData(drilldown_data) {
    let columns = [],
      displayColumns = ['category', 'source', 'journal_name', 'jornal_description', 'account',
        'je_line_num', 'currency', 'debit', 'credit',
        'accounted_debit', 'accounted_credit', 'line_description'],
      i, keys,
      total_amount_credit = 0,
      total_amount_debit = 0,
      total_credit = 0,
      total_debit = 0;

    if (drilldown_data.length > 0) {
      keys = Object.keys(drilldown_data[0]);
      for (i = 0; i < keys.length; i++) {
        if (displayColumns.indexOf(keys[i]) === -1) {
          let obj: any = {};
          obj.id = 'col-' + i;
          obj.label = this._formatService.formatColumnName(keys[i]);
          obj.name = keys[i];
          obj.checked = false;
          columns.push(obj);
        }
      }
    }
    this.columnNames = columns;

    for (i = 0; i < drilldown_data.length; i++) {
      if (drilldown_data[i].credit) {
        drilldown_data[i].f_credit = this._formatService.formatNumber(drilldown_data[i].credit);
      } else {
        drilldown_data[i].f_credit = 0;
        drilldown_data[i].credit = 0;
      }

      if (drilldown_data[i].debit) {
        drilldown_data[i].f_debit = this._formatService.formatNumber(drilldown_data[i].debit);
      } else {
        drilldown_data[i].f_debit = 0;
        drilldown_data[i].debit = 0;
      }

      if (drilldown_data[i].accounted_debit) {
        drilldown_data[i].f_account_debit = this._formatService.formatNumber(drilldown_data[i].accounted_debit);
      } else {
        drilldown_data[i].f_account_debit = 0;
        drilldown_data[i].accounted_debit = 0;
      }

      if (drilldown_data[i].accounted_credit) {
        drilldown_data[i].f_account_credit = this._formatService.formatNumber(drilldown_data[i].accounted_credit);
      } else {
        drilldown_data[i].f_account_credit = 0;
        drilldown_data[i].accounted_credit = 0;
      }
      drilldown_data[i].batch_date_millis = this._formatService.dateInMillis(drilldown_data[i].batch_date);
      drilldown_data[i].gl_date_millis = this._formatService.dateInMillis(drilldown_data[i].gl_date);
      drilldown_data[i].conversion_date_millis = this._formatService.dateInMillis(drilldown_data[i].conversion_date);
      drilldown_data[i].f_batch_date = this._formatService.formatDate(drilldown_data[i].batch_date);
      drilldown_data[i].f_gl_date = this._formatService.formatDate(drilldown_data[i].gl_date);
      drilldown_data[i].f_conversion_date = this._formatService.getCurrencyCode(drilldown_data[i].conversion_date);
      if (drilldown_data[i].credit !== '') {
        total_credit = total_credit + drilldown_data[i].credit;
      }
      if (drilldown_data[i].debit !== '') {
        total_debit = total_debit + drilldown_data[i].debit;
      }
      if (drilldown_data[i].accounted_debit !== '') {
        total_amount_debit = total_amount_debit + drilldown_data[i].accounted_debit;
      }
      if (drilldown_data[i].accounted_credit !== '') {
        total_amount_credit = total_amount_credit + drilldown_data[i].accounted_credit;
      }
    }
    this.total_credit = this._formatService.formatNumber(total_credit);
    this.total_debit = this._formatService.formatNumber(total_debit);
    this.total_amount_debit = this._formatService.formatNumber(total_amount_debit);
    this.total_amount_credit = this._formatService.formatNumber(total_amount_credit);
    this.drill_data = drilldown_data;
    this.showSpinner = false;
  }

  loadData(): void {
    const endPoint = '/supplier/trailbalance/drilldown/';
    const dict: any = {};
    dict.account = parseInt(this._appService.account_id);
    dict.ledger_id = this._appService.ledger_id;
    dict.period = this._appService.period || '';
    this._httpService.httpRequest('POST', endPoint, dict, (drilldown_data) => {
      try {
        this.showSpinner = false;
        if (drilldown_data === null || drilldown_data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else if (drilldown_data.status === 1) {
          this._appService.notify({ status: 1, msg: drilldown_data.msg });
        } else {
          this.formatData(drilldown_data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  previousState(): void {
    this._router.navigate(['finance/trailbalance']);
  }

  // Table sorting
  sort(key): void {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
    }
    this.drill_data = this._orderBy.transform(this.drill_data, this.predicate, this.desc);
  }

  toggleColumn(column): void {
    let columns = this.columns, index;
    if (columns) {
      index = columns.indexOf(column);
      if (index > -1) {
        if (columns.length > 1) {
          this.columns.splice(index, 1);
        } else {
          this.columns = [];
        }
      } else {
        this.columns.push(column);
      }
    } else {
      this.columns = [];
      this.columns.push(column);
    }
  }
}
