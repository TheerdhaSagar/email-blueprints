import {
  Component, OnDestroy, OnInit, Injector
} from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';
import jQuery from 'jquery';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';
import { ExportDetails } from '../../outcanada/models/export-details';
import { ExportTableData } from '../../outcanada/models/exoport-table-data';
import { Record } from '../../donation/partner-association/record';

@Component({
  selector: 'app-finance-trailbalance',
  templateUrl: './trailbalance.component.html',
  styleUrls: ['./trailbalance.component.scss'],
  providers: [OrderByPipe]
})
export class TrailBalanceComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  assetBalances: any;
  assetSearch: any;
  balanceSheetBalance: number;
  balanceSheetBeginningBalance: number;
  balanceSheetPtd: number;
  descAsset: boolean;
  descAsset2: any;
  descAsset3: any;
  descLiability: boolean;
  descRevenue: boolean;
  f_balanceSheetBalance: any;
  f_balanceSheetBeginningBalance: any;
  f_balanceSheetPtd: any;
  f_liabilityBalance: any;
  f_liabilityBeginningBalance: any;
  f_liabilityPtd: any;
  f_PlBalance: any;
  f_PlBeginningBalance: any;
  f_PlPtd: any;
  focusLedger: boolean;
  focusPeriod: boolean;
  ledgers: any;
  liabilityBalance: number;
  liabilityBalances: any;
  liabilityBeginningBalance: number;
  liabilityPtd: number;
  liabilitySearch: any;
  periods: any;
  plBalance: number;
  plBeginningBalance: number;
  plPtd: number;
  predicateAsset: string;
  predicateLiability: string;
  predicateRevenue: string;
  reportName: any;
  requiredLedger: any;
  requiredPeriod: any;
  revenueBalances: any;
  revenueSearch: any;
  showSpinner: boolean;
  subOrgChange: Subscription;
  toggleFilter: (e?) => void;
  trailBalance: any;

  constructor(private injector: Injector) {
    this._window = window;

    this.assetBalances = [];
    this.balanceSheetBalance = 0;
    this.balanceSheetBeginningBalance = 0;
    this.balanceSheetPtd = 0;
    this.descAsset = false;
    this.descAsset2 = null;
    this.descAsset3 = null;
    this.descLiability = false;
    this.descRevenue = false;
    this.f_balanceSheetBalance = null;
    this.f_balanceSheetBeginningBalance = null;
    this.f_balanceSheetPtd = null;
    this.f_liabilityBalance = null;
    this.f_liabilityBeginningBalance = null;
    this.f_liabilityPtd = null;
    this.f_PlBalance = null;
    this.f_PlBeginningBalance = null;
    this.f_PlPtd = null;
    this.focusLedger = true;
    this.focusPeriod = true;
    this.ledgers = null;
    this.liabilityBalance = 0;
    this.liabilityBalances = [];
    this.liabilityBeginningBalance = 0;
    this.liabilityPtd = 0;
    this.periods = null;
    this.plBalance = 0;
    this.plBeginningBalance = 0;
    this.plPtd = 0;
    this.predicateAsset = 'account';
    this.predicateLiability = 'description';
    this.predicateRevenue = 'account_type';
    this.reportName = null;
    this.requiredLedger = null;
    this.requiredPeriod = null;
    this.revenueBalances = [];
    this.showSpinner = false;
    this.subOrgChange = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.trailBalance = null;
  }

  static exportData(data): Record<{ data?: string; align?: string }>[] {
    const tmpData: Record<{ data?: string; align?: string }>[] = [];
    if (data && data.length) {
      data.forEach((record) => {
        const tmpObj: Record<{ data?: string; align?: string }> = {};
        tmpObj['Account #'] = { data: record.account };
        tmpObj.Description = { data: record.description };
        tmpObj['Account Type'] = { data: record.account_type };
        tmpObj['Beginning Balance'] = {
          data: record.f_beginning_balance,
          align: 'right'
        };
        tmpObj.PTD = { data: record.f_ptd, align: 'right' };
        tmpObj[' End Balance'] = { data: record.f_balance, align: 'right' };
        tmpData.push(tmpObj);
      });
    }
    return tmpData;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this.toggleFilter();

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          jQuery('.container-full input').val('');
          this.assetBalances = [];
          this.liabilityBalances = [];
          this.revenueBalances = [];
          this.loadLedgerNames();
          this.loadPeriods();
        });
        if (this._dataService.fromState && this._dataService.fromState === '/finance/trailbalance/details') {
          if (this._cacheService.getAssetBalanceData()) {
            this.assetBalances = this._cacheService.getAssetBalanceData();
            this.liabilityBalances = this._cacheService.getLiabilityData();
            this.revenueBalances = this._cacheService.getRevenueData();

            this.f_balanceSheetBeginningBalance = this._appService.f_balanceSheetBeginningBalance;
            this.f_balanceSheetPtd = this._appService.f_balanceSheetPtd;
            this.f_balanceSheetBalance = this._appService.f_balanceSheetBalance;
            this.f_liabilityBeginningBalance = this._appService.f_liabilityBeginningBalance;
            this.f_liabilityPtd = this._appService.f_liabilityPtd;
            this.f_liabilityBalance = this._appService.f_liabilityBalance;
            this.f_PlBeginningBalance = this._appService.f_PlBeginningBalance;
            this.f_PlPtd = this._appService.f_PlPtd;
            this.f_PlBalance = this._appService.f_PlBalance;
            if (this._appService.ledgername) {
              this.requiredLedger = this._appService.ledger_id;
            }
            if (this._appService.period) {
              this.requiredPeriod = this._appService.period;
            }
          }
        }
        this.reportName = 'Trail Balance';
        this.loadLedgerNames();
        this.loadPeriods();
      }
    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  drilldown(d) {
    this._appService.account_id = d.account;
    this._appService.balanceDetails = d;
    this._router.navigate(['finance/trailbalance/details']);
  }

  exportAssets(): ExportDetails {
    const assetdata = this._orderBy.transform(this.assetBalances, this.predicateAsset, this.descAsset);
    const tableData: ExportTableData = { data: [], footer: [] };
    const totalData = [
      { data: '' }, { data: '' }, { data: '' },
      {
        data: this.f_balanceSheetBeginningBalance,
        align: 'right'
      }, {
        data: this.f_balanceSheetPtd,
        align: 'right'
      }, {
        data: this.f_balanceSheetBalance,
        align: 'right'
      }];
    tableData.data = TrailBalanceComponent.exportData(assetdata);
    tableData.footer = totalData;
    return { tableData, title: 'Assets' };
  }

  exportLiability(): ExportDetails {
    const tableData: ExportTableData = { data: [], footer: [] };
    const liabilitydata = this._orderBy.transform(this.liabilityBalances, this.predicateLiability, this.descAsset2);
    tableData.data = TrailBalanceComponent.exportData(liabilitydata);
    const totalData = [
      { data: '' }, { data: '' }, { data: '' },
      {
        data: this.f_liabilityBeginningBalance,
        align: 'right'
      }, {
        data: this.f_liabilityPtd,
        align: 'right'
      }, {
        data: this.f_liabilityBalance,
        align: 'right'
      }];
    tableData.footer = totalData;
    return { tableData, title: 'Liability' };
  }

  exportPAndL(): ExportDetails {
    const revenuedata = this._orderBy.transform(this.revenueBalances, this.predicateRevenue, this.descAsset3);
    const tableData: ExportTableData = { data: [], footer: [] };
    tableData.data = TrailBalanceComponent.exportData(revenuedata);
    const totalData = [
      { data: '' }, { data: '' }, { data: '' },
      {
        data: this.f_PlBeginningBalance,
        align: 'right'
      }, {
        data: this.f_PlPtd,
        align: 'right'
      }, {
        data: this.f_PlBalance,
        align: 'right'
      }];
    tableData.footer = totalData;
    return { tableData, title: 'P & L' };
  }

  // Exports the table data into spreadsheet
  exportToExcel(): void {
    try {
      this.toggleFilter();
      const list = [];
      if (this.assetBalances && this.assetBalances.length) {
        list.push(this.exportAssets());
      }
      if (this.liabilityBalances && this.liabilityBalances.length) {
        list.push(this.exportLiability());
      }
      if (this.revenueBalances && this.revenueBalances.length) {
        list.push(this.exportPAndL());
      }
      this._appService.exportMultiTable('Trail Balance', list, 'export-trialbalance');
    } catch (e) {
      this._appService.notify({ status: 1, msg: e.message, details: `<pre>${e.stack}</pre>` });
    }
  }

  formatLoadReport(data) {
    let assetData = [], i,
      liabilityData = [],
      revenueData = [];

    this.balanceSheetBeginningBalance = 0;
    this.balanceSheetPtd = 0;
    this.balanceSheetBalance = 0;
    this.liabilityBeginningBalance = 0;
    this.liabilityPtd = 0;
    this.liabilityBalance = 0;
    this.plBeginningBalance = 0;
    this.plPtd = 0;
    this.plBalance = 0;
    for (i = 0; i < data.length; i++) {
      if (data[i].account_type === 'Asset') {
        assetData.push(data[i]);
        this.balanceSheetBeginningBalance += parseFloat(data[i].beginning_balance);
        this.balanceSheetPtd = this.balanceSheetPtd + parseFloat(data[i].ptd);
        this.balanceSheetBalance = this.balanceSheetBalance + parseFloat(data[i].balance);

      } else if (data[i].account_type === 'Liability' || data[i].account_type === 'Ownership/Equity') {
        liabilityData.push(data[i]);
        this.liabilityBeginningBalance = this.liabilityBeginningBalance + parseFloat(data[i].beginning_balance);
        this.liabilityPtd = this.liabilityPtd + parseFloat(data[i].ptd);
        this.liabilityBalance = this.liabilityBalance + parseFloat(data[i].balance);
      } else if (data[i].account_type === 'Revenue' || data[i].account_type === 'Expense') {
        revenueData.push(data[i]);
        this.plBeginningBalance = this.plBeginningBalance + parseFloat(data[i].beginning_balance);
        this.plPtd = this.plPtd + parseFloat(data[i].ptd);
        this.plBalance = this.plBalance + parseFloat(data[i].balance);
      }
    }
    this.f_balanceSheetBeginningBalance = this._formatService.formatNumber(this.balanceSheetBeginningBalance);
    this.f_balanceSheetPtd = this._formatService.formatNumber(this.balanceSheetPtd);
    this.f_balanceSheetBalance = this._formatService.formatNumber(this.balanceSheetBalance);
    this.f_liabilityBeginningBalance = this._formatService.formatNumber(this.liabilityBeginningBalance);
    this.f_liabilityPtd = this._formatService.formatNumber(this.liabilityPtd);
    this.f_liabilityBalance = this._formatService.formatNumber(this.liabilityBalance);
    this.f_PlBeginningBalance = this._formatService.formatNumber(this.plBeginningBalance);
    this.f_PlPtd = this._formatService.formatNumber(this.plPtd);
    this.f_PlBalance = this._formatService.formatNumber(this.plBalance);

    this._appService.f_balanceSheetBeginningBalance = this.f_balanceSheetBeginningBalance;
    this._appService.f_balanceSheetPtd = this.f_balanceSheetPtd;
    this._appService.f_balanceSheetBalance = this.f_balanceSheetBalance;
    this._appService.f_liabilityBeginningBalance = this.f_liabilityBeginningBalance;
    this._appService.f_liabilityPtd = this.f_liabilityPtd;
    this._appService.f_liabilityBalance = this.f_liabilityBalance;
    this._appService.f_PlBeginningBalance = this.f_PlBeginningBalance;
    this._appService.f_PlPtd = this.f_PlPtd;
    this._appService.f_PlBalance = this.f_PlBalance;

    for (i = 0; i < data.length; i++) {
      data[i].f_beginning_balance = this._formatService.formatNumber(data[i].beginning_balance);
      data[i].f_ptd = this._formatService.formatNumber(data[i].ptd);
      data[i].f_balance = this._formatService.formatNumber(data[i].balance);
    }
    this.trailBalance = data;
    this.assetBalances = assetData;
    this.liabilityBalances = liabilityData;
    this.revenueBalances = revenueData;
    this.showSpinner = false;
    this._cacheService.setAssetBalanceData(this.assetBalances);
    this._cacheService.setLiabilityData(this.liabilityBalances);
    this._cacheService.setRevenueData(this.revenueBalances);
  }

  // Load ledger names
  loadLedgerNames(): void {
    const endPoint = '/supplier/ledgetname/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else if (data.length > 0) {
          this.ledgers = data;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  // Load periods data from web service
  loadPeriods(): void {
    const endPoint = '/supplier/period/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else if (data.length > 0) {
          this.periods = data;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  // Load the salesGroups related to logged in user based on the
  // selected organization
  loadReport() {
    let endPoint, flag, i, ledget, period;
    this.focusPeriod = true;
    this.assetBalances = [];
    this.liabilityBalances = [];
    this.revenueBalances = [];
    if (this.requiredLedger && this.requiredPeriod) {
      flag = 0;
      for (i = 0; i < this.ledgers.length; i++) {
        if (parseInt(this.requiredLedger) === this.ledgers[i].ledger_id) {
          flag = 1;
          break;
        }
      }
      if (flag === 0) {
        this.focusLedger = false;
        this.requiredLedger = '';
        return false;
      }
      if (this.requiredPeriod) {
        flag = 0;
        for (i = 0; i < this.periods.length; i++) {
          if (this.requiredPeriod === this.periods[i].period_name) {
            flag = 1;
            break;
          }
        }
        if (flag === 0) {
          this.requiredPeriod = '';
          this.focusPeriod = false;
          return false;
        }
      }
    } else {
      this.focusLedger = false;
      this.focusPeriod = false;
      return false;
    }
    ledget = this.requiredLedger;
    this._appService.ledger_id = ledget;
    this._appService.ledgername = jQuery('#ledgername').val();
    this.toggleFilter();
    period = this.requiredPeriod ? this.requiredPeriod : '';
    this._appService.period = period;
    if (period) {
      endPoint = '/supplier/trailbalance/' + ledget + '/' + period + '/';
    } else {
      endPoint = '/supplier/trailbalance/' + ledget + '/';
    }
    this.trailBalance = null;
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.formatLoadReport(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  onLedgerNameBlur() {
    this.focusLedger = false;
  }

  // Table sorting
  sort(tablename, key) {
    switch (tablename) {
      case 'asset':
        if (this.predicateAsset === key) {
          this.descAsset = !this.descAsset;
        } else {
          this.predicateAsset = key;
        }
        this.assetBalances = this._orderBy.transform(this.assetBalances, this.predicateAsset, this.descAsset);
        break;
      case 'liability':
        if (this.predicateLiability === key) {
          this.descLiability = !this.descLiability;
        } else {
          this.predicateLiability = key;
        }
        this.liabilityBalances = this._orderBy.transform(this.liabilityBalances, this.predicateLiability, this.descLiability);
        break;
      case 'revenue':
        if (this.predicateRevenue === key) {
          this.descRevenue = !this.descRevenue;
        } else {
          this.predicateRevenue = key;
        }
        this.revenueBalances = this._orderBy.transform(this.revenueBalances, this.predicateRevenue, this.descRevenue);
        break;
    }
  }

}
