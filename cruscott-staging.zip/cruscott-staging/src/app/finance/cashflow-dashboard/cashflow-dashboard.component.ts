import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CacheService } from '../../globals/cache.service';

@Component({
  selector: 'app-cashflow-dashboard',
  templateUrl: './cashflow-dashboard.component.html'
})
export class CashflowDashboardComponent implements OnInit {
  private _cacheService: CacheService;
  private _router: Router;

  constructor(cacheService: CacheService, router: Router) {
    this._cacheService = cacheService;
    this._router = router;
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });
  }

  showReport(name): void {
    this._router.navigate([name]);
  }
}
