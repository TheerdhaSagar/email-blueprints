import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CashflowDashboardComponent } from './cashflow-dashboard.component';

describe('CashflowDashboardComponent', () => {
  let component: CashflowDashboardComponent;
  let fixture: ComponentFixture<CashflowDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CashflowDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashflowDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
