import {
  Component, OnDestroy, OnInit, Injector
} from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { BankAccountsService } from '../bank-accounts/bank-accounts.service';
import { environment } from '../../../environments/environment';
import { APIError } from '../../globals/api.error';
import { ServerError } from '../../globals/server.error';
import { BankAccount } from '../bank-accounts/bank-account';

@Component({
  selector: 'app-finance-cashforecast',
  templateUrl: './cashforecast.component.html',
  styleUrls: ['./cashforecast.component.scss'],
  providers: [OrderByPipe]
})
export class CashForecastComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _bankAccountService: BankAccountsService = this.injector.get(BankAccountsService);
  _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  allTotals: any;
  bankAccounts: BankAccount[];
  cashForecast: any[];
  columns: Array<{ title: string; showDrilldown: boolean }>;
  currency: any;
  currentPage: number;
  desc: boolean;
  descriptionList: string[];
  descTable: boolean;
  downloadURL: any;
  exportMultipleData: any;
  fileName: any;
  forecast: { msg: any; showError: boolean };
  indexLedgerId: any;
  months: string[];
  msg: any;
  onSelection: any;
  pageDim: boolean;
  pageSize: any;
  period_name: any;
  periods: any;
  poTotalAmount: number;
  predicate: string;
  predicateTable: string;
  reportData: any;
  reportName: any;
  searchText: any;
  secondTableData: any[];
  secondTableTotals: any;
  selectedBank: string;
  selectDrillDownReport: string;
  showDialog: boolean;
  showDim: boolean;
  showExcludeButton = false;
  showSpinner: boolean;
  subOrgChange: any;
  toggleFilter: (e?) => void;
  totalPtd: number;
  totalsBaseAmount: number;
  totalsDueAmount: number;
  totalytd: any;
  transposedCashforecast: any;
  user: any;
  view: any;
  viewData: any;
  viewDataList: any[];
  weeks: any;
  windowWidth: any;

  constructor(private injector: Injector) {
    this._window = window;
  }

  ngOnInit(): void {
    this.setUpDOMHandlers();
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this.selectedBank = null;
      this.init();
    });

    this.init();
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  back(): void {
    this._router.navigate(['finance/cashflow']);
  }

  calculateBankBalances(data): void {
    const reportData = [...data];
    for (let i = 0; i < 12; i++) {
      reportData[i].f_overdue = reportData[i].overdue.map((amount) => this._formatService.formatNumber(amount));
    }
    if (!this.selectedBank || this.selectedBank === 'All Banks') {
      this.transposedCashforecast = reportData;
      return;
    }
    const index = this.bankAccounts.findIndex((bank) => bank.bank_account_identifier === this.selectedBank);
    const balance = this.bankAccounts[index].current_balance;
    for (let i = 0; i < 12; i++) {
      reportData[i].opening = i === 0 ? balance : reportData[i - 1].closing;
      reportData[i].closing = reportData[i].overdue.reduce((sum, amount) => sum + (amount || 0), reportData[i].opening);
      reportData[i].f_opening = this._formatService.formatNumber(reportData[i].opening);
      reportData[i].f_closing = this._formatService.formatNumber(reportData[i].closing);
    }
    this.transposedCashforecast = reportData;
  }

  calculateDrillDownTotals(data): void {
    const totals = [];
    this.totalsBaseAmount = 0;
    this.totalsDueAmount = 0;
    for (let i = 0; i < data.length; i++) {
      this.totalsBaseAmount += data[i].base_amount;
      this.totalsDueAmount += data[i].due_amount;
      for (let k = 0; k <= 12; k++) {
        totals[k] = totals[k] ? totals[k] + data[i][`w${k}`] : data[i][`w${k}`];
      }
    }
    for (let i = 0; i < totals.length; i++) {
      totals[i] = this._formatService.formatNumber(totals[i]);
    }
    this.totalsBaseAmount = this._formatService.formatNumber(this.totalsBaseAmount);
    this.totalsDueAmount = this._formatService.formatNumber(this.totalsDueAmount);
    this.secondTableTotals = totals;
  }

  // CashReceipt Export
  cashReceiptExport() {
    let data = this._orderBy.transform(this.secondTableData, this.predicateTable, this.descTable),
      tmpData = [], i, tmpObj, k;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj.Party = {
        data: data[i].supplier_name
      };
      tmpObj['Payment Method'] = {
        data: data[i].payment_method
      };
      tmpObj.Amount = {
        data: data[i].f_amount,
        align: 'right'
      };
      for (k = 1; k <= 12; k++) {
        tmpObj['B' + k] = {
          data: data[i]['f_b' + k],
          align: 'right'
        };
      }
      tmpData.push(tmpObj);
    }
    return tmpData;
  }

  // Customer Invoice Export
  customerInvExport() {
    // because of download issues we are downloading upto 1970 lines only
    this.viewDataList = this.secondTableData.slice(this.currentPage - 1, 1970);
    let data = this._orderBy.transform(this.viewDataList, this.predicateTable, this.descTable),
      tmpData = [], i, tmpObj;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      if (!data[i].amount_new) {
        data[i].amount_new = null;
      }
      if (!data[i].base_amount_new) {
        data[i].base_amount_new = null;
      }
      tmpObj['Party Name'] = {
        data: data[i].supplier_name
      };
      tmpObj.Account = {
        data: data[i].gl_account
      };
      tmpObj.Description = {
        data: data[i].description
      };
      tmpObj['Due Date'] = {
        data: data[i].due_date_new
      };
      tmpObj['Payment Method'] = {
        data: data[i].payment_method
      };
      tmpObj['Term Name'] = {
        data: data[i].payment_term
      };
      tmpObj['Trx #'] = {
        data: data[i].invoice_number
      };
      tmpObj.Currency = {
        data: data[i].currency_code
      };
      tmpObj.Amount = {
        data: data[i].amount_new,
        align: 'right'
      };
      tmpObj['Base Amount'] = {
        data: data[i].base_amount_new,
        align: 'right'
      };
      tmpObj.W1 = {
        data: data[i].f_w1,
        align: 'right'
      };
      tmpObj.W2 = {
        data: data[i].f_w2,
        align: 'right'
      };
      tmpObj.W3 = {
        data: data[i].f_w3,
        align: 'right'
      };
      tmpObj.W4 = {
        data: data[i].f_w4,
        align: 'right'
      };
      tmpObj.W5 = {
        data: data[i].f_w5,
        align: 'right'
      };
      tmpObj.W6 = {
        data: data[i].f_w6,
        align: 'right'
      };
      tmpObj.W7 = {
        data: data[i].f_w7,
        align: 'right'
      };
      tmpObj.W8 = {
        data: data[i].f_w8,
        align: 'right'
      };
      tmpObj.W9 = {
        data: data[i].f_w9,
        align: 'right'
      };
      tmpObj.W10 = {
        data: data[i].f_w10,
        align: 'right'
      };
      tmpObj.W11 = {
        data: data[i].f_w11,
        align: 'right'
      };
      tmpObj.W12 = {
        data: data[i].f_w12,
        align: 'right'
      };
      tmpData.push(tmpObj);
    }
    return tmpData;
  }

  downloadExcel() {
    if (this.downloadFile()) {
      return;
    }
    let endPoint = '/cashforecast/forecast/excel/', req: any = {}, index;
    req.org_id = parseInt(this._cacheService.getOrgId());
    req.ledger_id = parseInt(this.user.organizations[0].set_of_books_id);
    if (this.periods) {
      index = this.periods.map(x => x.period_name).indexOf(this.onSelection);
      if (index === -1) {
        this.onSelection = '';
        this.msg = 'Invalid Period';
        this.forecast.showError = true;
        this._appService.notify({
          status: 1,
          msg: this.msg
        });
        return;
      }
    }
    req.period = this.onSelection;

    this.showDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.showDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: downloadExcel()' });
      } else if (data.hasOwnProperty('status')) {
        this._appService.notify({ status: data.status, msg: data.msg });
      } else {
        this.fileName = data.filename;
        this.downloadFile();
      }
    });
  }

  downloadFile() {
    let link = document.getElementById('forecast-download') as HTMLAnchorElement;
    if (this.fileName) {
      link.href = this.downloadURL + '/cdn?file_name=' + this.fileName + '&?download_name=' + this.fileName;
      link.click();
      return true;
    }
    return false;
  }

  // Exports the table data into spreadsheet
  exportData() {
    this.toggleFilter();
    let list = [], listData: any = {}, tableData: any = {}, tmpData = [], tmpObj, totals = [];
    const data = [...this.transposedCashforecast];
    try {
      for (let i = 0; i < data.length; i++) {
        tmpObj = {};
        tmpObj.Week = { data: `W${data[i].week.week_number}` };
        if ('opening' in data[i]) {
          tmpObj['Opening Balance'] = { data: data[i].f_opening, align: 'right' };
        }
        for (let k = 0; k < this.columns.length; k++) {
          tmpObj[this.columns[k].title] = { data: data[i].f_overdue[k], align: 'right' };
        }
        if ('closing' in data[i]) {
          tmpObj['Closing Balance'] = { data: data[i].f_closing, align: 'right' };
        }
        tmpData.push(tmpObj);
      }
      tableData.data = tmpData;
      listData.tableData = tableData;
      listData.title = 'Cash Forecast';
      list.push(listData);
      if (this.view) {
        tableData = {};
        listData = {};
        tableData.data = this.getMultipleTableData(this.view);
        if (tableData.data) {
          listData.tableData = tableData;
          listData.title = this.view;
          list.push(listData);
        }
      }
      this._appService.exportMultiTable('Cash Forecast', list, 'export-data');
    } catch (e) {
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: `<pre>${e.stack}</pre>`
      });
    }
  }

  excludeInvoices(): void {
    const data = this.viewData.filter((row) => row.isSelected);
    const endPoint = '/cashforecast/exclude/';
    this.showDialog = false;
    this.showExcludeButton = false;
    this._httpService.httpRequest('POST', endPoint, data, (result) => {
      if (!result) {
        this._appService.notify({ status: 1, msg: 'Server Error - excludeInvoices()' });
      } else if (result.status === 1) {
        this._appService.notify(result);
      } else {
        this.loadReport();
        this.showDrilldown(data[0].description);
      }
    });
  }

  formatDrillDownData(budgetData, budgetDescription): void {
    const description = budgetDescription.split('_').join(' ').toLowerCase();
    this.totalsBaseAmount = 0;
    this.totalsDueAmount = 0;
    switch (description) {
    case 'supplier invoices':
      this.formatLoadSupplier(budgetData, description);
      this.onBankAccountChange();
      break;
    case 'customer invoices':
      this.formatLoadCustomer(budgetData, description);
      this.onBankAccountChange();
      break;
    case 'to be invoiced':
      this.formatLoadToBeInvoiced(budgetData, description);
      break;
    case 'customer receipts':
      this.formatLoadCashReceipt(budgetData, description);
      break;
    case 'purchase orders':
      this.formatPurchaseOrders(budgetData, description);
      this.onBankAccountChange();
      break;
    case 'ico inter company':
      this.formatLoadIntercom(budgetData, description);
      break;
    default:
      break;
    }
  }

  formatLoadCashReceipt(data, type) {
    try {
      let totals = [], i, k, j;
      for (i = 0; i < data.length; i++) {
        data[i].f_amount = this._formatService.formatNumber(data[i].base_amount);
        this.totalsBaseAmount += parseFloat(data[i].base_amount);
        for (k = 0; k <= 12; k++) {
          data[i]['w' + k] = parseFloat(data[i]['w' + k]) || 0;
          data[i]['f_b' + k] = this._formatService.formatNumber(data[i]['w' + k]);
          totals[k] = totals[k] ? totals[k] + data[i]['w' + k] : data[i]['w' + k];
        }
      }
      for (j = 0; j < totals.length; j++) {
        totals[j] = this._formatService.formatNumber(totals[j]);
      }
      this.currentPage = 1;
      this.totalsBaseAmount = this._formatService.formatNumber(this.totalsBaseAmount);
      this.viewData = this._orderBy.transform(data, this.predicateTable, this.descTable);
      this.secondTableTotals = totals;
      this.secondTableData = this.viewData;
      this.viewDataList = this.viewData.slice(this.currentPage - 1, this.pageSize);
      this.view = type;
      this.pageDim = false;
    } catch (e) {
      this.pageDim = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
  }

  formatLoadCustomer(data, type) {
    try {
      let totals = [], i, k, j;
      for (i = 0; i < data.length; i++) {
        data[i].invoice_number = parseInt(data[i].invoice_number) || null;
        data[i].due_amount = data[i].due_amount || 0;
        // this.totalsDueAmount += data[i].amount;
        data[i].amount_new = this._formatService.formatNumber(data[i].due_amount);
        data[i].base_amount = data[i].base_amount || 0;
        // this.totalsBaseAmount += data[i].base_amount;
        data[i].base_amount_new = this._formatService.formatNumber(data[i].base_amount);
        data[i].due_date = data[i].due_date || null;
        data[i].due_date_new = this._formatService.formatDate(data[i].due_date);
        data[i].due_date_millis = this._formatService.dateInMillis(data[i].due_date);
        for (k = 0; k <= 12; k++) {
          data[i]['w' + k] = parseFloat(data[i]['w' + k]) || 0;
          data[i]['f_w' + k] = this._formatService.formatNumber(data[i]['w' + k]);
          // totals[k] = totals[k] ? totals[k] + data[i]['w' + k] : data[i]['w' + k];
        }
        this.currency = data[0].invoice_currency_code;
      }
      // for (j = 0; j < totals.length; j++) {
      //   totals[j] = this._formatService.formatNumber(totals[j]);
      // }
      this.calculateDrillDownTotals(data);
      this.currentPage = 1;
      this.viewData = this._orderBy.transform(data, this.predicateTable, this.descTable);
      // this.totalsBaseAmount = this._formatService.formatNumber(this.totalsBaseAmount);
      // this.totalsDueAmount = this._formatService.formatNumber(this.totalsDueAmount);
      // this.secondTableTotals = totals;
      this.secondTableData = this.viewData;
      this.viewDataList = this.viewData.slice(this.currentPage - 1, this.pageSize);
      this.view = type;
      this.pageDim = false;
    } catch (e) {
      this.pageDim = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
  }

  formatLoadSupplier(data, type) {
    try {
      let totals = [], i, j, k;
      if (data && data.length > 0) {
        this.currency = data[0].currency_code;
        for (i = 0; i < data.length; i++) {
          data[i].base_amount = data[i].base_amount || 0;
          data[i].amount_new = this._formatService.formatNumber(data[i].base_amount);
          this.exportMultipleData.amount = data[i].amount_new;

          data[i].base_amount_new = this._formatService.formatNumber(data[i].base_amount);
          // this.totalsBaseAmount += data[i].base_amount;
          this.exportMultipleData.baseAmount = data[i].base_amount_new;

          data[i].due_amount = data[i].due_amount || 0;
          // this.totalsDueAmount += data[i].due_amount;
          data[i].due_new = this._formatService.formatNumber(data[i].due_amount);

          for (k = 0; k <= 12; k++) {
            data[i]['w' + k] = parseFloat(data[i]['w' + k]) || 0;
            data[i]['f_w' + k] = this._formatService.formatNumber(data[i]['w' + k]);
            // totals[k] = totals[k] ? totals[k] + data[i]['w' + k] : data[i]['w' + k];
          }

          data[i].due_date_new = data[i].due_date ? this._formatService.formatDate(data[i].due_date) : null;
          data[i].due_date_millis = data[i].due_date ? this._formatService.dateInMillis(data[i].due_date) : null;
          data[i].invoice_date_new = data[i].invoice_date ? this._formatService.formatDate(data[i].invoice_date) : null;
          data[i].invoice_date_millis = data[i].invoice_date ? this._formatService.dateInMillis(data[i].invoice_date) : null;
        }
        // for (j = 0; j < totals.length; j++) {
        //   totals[j] = this._formatService.formatNumber(totals[j]);
        // }
      }
      this.calculateDrillDownTotals(data);
      this.currentPage = 1;
      // this.totalsBaseAmount = this._formatService.formatNumber(this.totalsBaseAmount);
      // this.totalsDueAmount = this._formatService.formatNumber(this.totalsDueAmount);
      this.viewData = this._orderBy.transform(data, this.predicateTable, this.descTable);
      this.secondTableData = this.viewData;
      // this.secondTableTotals = totals;
      this.viewDataList = this.viewData.slice(this.currentPage - 1, this.pageSize);
      this.view = type;
      this.pageDim = false;
    } catch (e) {
      this.pageDim = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
  }

  formatLoadIntercom(data, type) {
    try {
      if (data.length !== 0) {
        this.currency = data[0].currency_code;
        for (let i = 0; i < data.length; i++) {
          data[i].ptd_actual = data[i].ptd_actual || 0;
          this.totalPtd += parseFloat(data[i].ptd_actual);
          data[i].ptd_actual_new = this._formatService.formatNumber(data[i].ptd_actual);
          data[i].ytd_actual = data[i].ytd_actual || 0;
          this.totalytd += parseFloat(data[i].ytd_actual);
          data[i].ytd_actual_new = this._formatService.formatNumber(data[i].ytd_actual);
        }
        this.totalytd = this._formatService.formatNumber(this.totalytd);
        this.totalPtd = this._formatService.formatNumber(this.totalPtd);
        this.viewDataList = data;
        this.secondTableData = data;
      }
      this.view = type;
      this.pageDim = false;
    } catch (e) {
      this.pageDim = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
  }

  formatLoadToBeInvoiced(data, type) {
    try {
      let totals = [], i, k, j;
      if (data && data.length > 0) {
        this.currency = data[0].currency_code;
        for (i = 0; i < data.length; i++) {
          data[i].due_amount = data[i].due_amount || 0;
          this.totalsDueAmount += parseFloat(data[i].due_amount);
          data[i].f_amount = this._formatService.formatNumber(data[i].due_amount);
          data[i].base_amount = data[i].base_amount || 0;
          this.totalsBaseAmount += data[i].base_amount;
          data[i].f_base_amount = this._formatService.formatNumber(data[i].base_amount);
          data[i].due_date = data[i].due_date || null;
          data[i].due_date_millis = this._formatService.dateInMillis(data[i].due_date);
          data[i].due_date = this._formatService.formatDate(data[i].due_date);
          data[i].invoice_date = data[i].invoice_date || null;
          data[i].trx_date_millis = this._formatService.dateInMillis(data[i].invoice_date);
          data[i].invoice_date = this._formatService.formatDate(data[i].invoice_date);
          data[i].account = data[i].account || null;
          data[i].f_account_number = parseInt(data[i].account);
          data[i].invoice_number = data[i].invoice_number || null;
          data[i].f_sales_order = parseInt(data[i].invoice_number);
          for (k = 0; k <= 12; k++) {
            data[i]['w' + k] = parseFloat(data[i]['w' + k]) || 0;
            data[i]['f_w' + k] = this._formatService.formatNumber(data[i]['w' + k]);
            totals[k] = totals[k] ? totals[k] + data[i]['w' + k] : data[i]['w' + k];
          }
        }
        for (j = 0; j < totals.length; j++) {
          totals[j] = this._formatService.formatNumber(totals[j]);
        }
      }
      this.currentPage = 1;
      this.viewData = this._orderBy.transform(data, this.predicateTable, this.descTable);
      this.totalsBaseAmount = this._formatService.formatNumber(this.totalsBaseAmount);
      this.totalsDueAmount = this._formatService.formatNumber(this.totalsDueAmount);
      this.secondTableTotals = totals;
      this.secondTableData = this.viewData;
      this.viewDataList = this.viewData.slice(this.currentPage - 1, this.pageSize);
      this.view = type;

    } catch (e) {
      this.pageDim = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
  }

  formatPurchaseOrders(data, type) {
    try {
      let totals = [], i, k, j;
      this.poTotalAmount = 0;
      if (data && data.length > 0) {
        for (i = 0; i < data.length; i++) {
          data[i].f_amount = this._formatService.formatNumber(data[i].base_amount);
          this.poTotalAmount += data[i].base_amount;
          for (k = 0; k <= 12; k++) {
            data[i]['w' + k] = parseFloat(data[i]['w' + k]) || 0;
            data[i]['f_w' + k] = this._formatService.formatNumber(data[i]['w' + k]);
            // totals[k] = totals[k] ? totals[k] + data[i]['w' + k] : data[i]['w' + k];
          }
        }
        // for (j = 0; j < totals.length; j++) {
        //   totals[j] = this._formatService.formatNumber(totals[j]);
        // }
      }
      this.calculateDrillDownTotals(data);
      this.currentPage = 1;
      this.viewData = this._orderBy.transform(data, this.predicateTable, this.descTable);
      // this.totalsBaseAmount = this._formatService.formatNumber(this.totalsBaseAmount);
      // this.totalsDueAmount = this._formatService.formatNumber(this.totalsDueAmount);
      this.poTotalAmount = this._formatService.formatNumber(this.poTotalAmount);
      // this.secondTableTotals = totals;
      this.secondTableData = this.viewData;
      this.viewDataList = this.viewData.slice(this.currentPage - 1, this.pageSize);
      this.view = type;
      this.pageDim = false;
    } catch (e) {
      this.pageDim = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
  }

  formatReportData(data): void {
    const transformData = this._orderBy.transform([...data], this.predicate, this.desc);
    const reportData = [];
    const columns = transformData.map((row) => ({ title: row.description, showDrilldown: row.show_drill_down === 1 }));
    for (let i = 0; i < 12; i++) {
      let overdue = [];
      if (i === 0) {
        overdue = transformData.map((row) => row[`w${i}`] + row[`w${i + 1}`]);
      } else {
        overdue = transformData.map((row) => row[`w${i + 1}`]);
      }
      reportData.push({
        week: this.weeks[i],
        overdue
      });
    }
    this.columns = columns;
    this.calculateBankBalances(reportData);
  }

  getBankAccounts(): void {
    this._bankAccountService.getBankAccounts(this._cacheService.getOrgId())
      .then((result) => {
        this.bankAccounts = result;
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  // export multiple tables
  getMultipleTableData(type) {
    switch (type) {
    case 'supplier invoices':
      return this.supplierInvExport();
    case 'customer invoices':
      return this.customerInvExport();
    case 'to be invoiced':
      return this.toBeInvExport();
    case 'customer receipts':
      return this.cashReceiptExport();
    case 'ico inter company':
      return this.interCompanyExport();
    case 'purchase orders':
      return this.purchaseOrdersExport();
    default:
      break;
    }
  }

  init(): void {
    this.allTotals = null;
    this.cashForecast = [];
    this.currency = null;
    this.currentPage = 0;
    this.desc = false;
    this.descriptionList = ['Customer Receipt', 'ICO Intercompany ', 'Purchase Orders', 'Supplier Invoices', 'To be Invoiced', 'Customer Invoices - Others'];
    this.descTable = false;
    this.downloadURL = environment.url;
    this.exportMultipleData = {};
    this.fileName = null;
    this.forecast = {
      msg: null,
      showError: false
    };
    this.indexLedgerId = null;
    this.months = ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC'];
    this.msg = null;
    this.onSelection = null;
    this.pageDim = false;
    this.pageSize = this._appService.pageSize;
    this.period_name = null;
    this.periods = null;
    this.poTotalAmount = 0;
    this.predicate = 'description';
    this.predicateTable = 'description';
    this.reportName = null;
    this.selectDrillDownReport = null;
    this.secondTableData = [];
    this.secondTableTotals = null;
    this.showDim = false;
    this.showSpinner = true;
    this.subOrgChange = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.totalPtd = 0;
    this.totalsBaseAmount = 0;
    this.totalsDueAmount = 0;
    this.totalytd = null;
    this.view = null;
    this.viewData = null;
    this.viewDataList = [];
    this.weeks = null;
    this.windowWidth = this._dataService.windowWidth;

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.reportName = 'Cash Forecast';
        const date = new Date();
        const month = this.months[date.getMonth()];
        const year = date.getFullYear() - 2000;
        this.period_name = `${month}-${year}`;
        this.onSelection = this.period_name;
        this.loadWeeks();
        this.loadPeriods();
        this.getBankAccounts();
      }
    });
  }

  // ICO Inter Company Export
  interCompanyExport() {
    let data = this._orderBy.transform(this.secondTableData, this.predicateTable, this.descTable),
      tableData: any = {}, tmpData = [], i, tmpObj;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj.Name = {
        data: data[i].supplier_name
      };
      tmpObj.Description = {
        data: data[i].description
      };
      tmpObj.Account = {
        data: data[i].account
      };
      tmpObj['PTD Actual'] = {
        data: data[i].ptd_actual_new ? data[i].ptd_actual_new : '',
        align: 'right'
      };
      tmpObj[' YTD Actual'] = {
        data: data[i].ytd_actual_new ? data[i].ytd_actual_new : '',
        align: 'right'
      };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    return tableData.data;
  }

  // Load Cash Receipt Data
  loadCashReceipt(type): void {
    const org = this._cacheService.getOrgId();
    const endPoint = `/cashforecast/receipt/details/${org}/`;
    this.pageDim = true;
    this.viewDataList = [];
    this.viewData = '';
    this.secondTableData = [];
    this.totalsBaseAmount = 0;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadCashReceipt' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.formatLoadCashReceipt(data, type);
      }
    });
  }

  // customer Invoices Data
  loadCustomerInvoices(type): void {
    let endPoint = '/cashforecast/customer/aging/';
    const org = this._cacheService.getOrgId();
    this.pageDim = true;
    this.viewDataList = [];
    this.viewData = '';
    this.secondTableData = [];
    this.totalsDueAmount = 0;
    this.totalsBaseAmount = 0;
    if (org) {
      endPoint += org + '/';
    }
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadCustomerInvoices' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.formatLoadCustomer(data, type);
      }
    });
  }

  // Load Intercompany Data
  loadIntercomData(type): void {
    const endPoint = `/cashforecast/${this._dataService.ledger_id}/${this.period_name}/`;
    this.pageDim = true;
    this.viewDataList = [];
    this.viewData = '';
    this.secondTableData = [];
    this.totalPtd = 0;
    this.totalytd = 0;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadIntercomData' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.formatLoadIntercom(data, type);
      }
    });
  }

  // Load More Scroll
  loadMore() {
    try {
      let page = this.currentPage + 1,
        startIndex = (page - 1) * this.pageSize, endIndex, tempData, i;
      endIndex = page * this.pageSize;
      this.currentPage = page;
      if (this.viewData) {
        tempData = this.viewData.slice(startIndex, endIndex);
        for (i = 0; i < tempData.length; i++) {
          this.viewDataList.push(tempData[i]);
        }
      }
    } catch (e) {
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
  }

  // Load periods data from web service
  loadPeriods(): void {
    const endPoint = '/supplier/period/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadPeriods' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        if (data.length > 0) {
          this.periods = data;
        }
      }
    });
  }

  // Load Purchase Orders
  loadPurchaseOrders(type): void {
    const org = this._cacheService.getOrgId();
    const endPoint = `/cashforecast/purchase/orders/${org}/`;
    this.pageDim = true;
    this.viewDataList = [];
    this.viewData = '';
    this.secondTableData = [];
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadPurchaseOrders' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.formatPurchaseOrders(data, type);
      }
    });
  }

  // Load the salesGroups related to logged in user based on the
  // selected organization
  loadReport(): void {
    let req: any = {};
    let i;
    let endPoint = `/cashforecast/${this._cacheService.getOrgId()}/`;
    if (this.selectedBank && this.selectedBank !== 'All Banks') {
      endPoint += `bank/${this.selectedBank}/`;
    }
    this.currentPage = 1;
    this.viewData = [];
    this.secondTableData = [];
    req.org_id = parseInt(this._cacheService.getOrgId());
    this.indexLedgerId = 0;
    for (i = 0; i < this.user.organizations.length; i++) {
      if (parseInt(this.user.organizations[i].organization_id) === this._dataService.orgId) {
        this.indexLedgerId = i;
        break;
      }

    }
    req.ledger_id = parseInt(this.user.organizations[this.indexLedgerId].set_of_books_id);
    // req.ledger_id = parseInt(user.organizations[0].set_of_books_id);
    if (this.periods) {
      let index = this.periods.map(x => x.period_name).indexOf(this.onSelection);
      if (index === -1) {
        this.onSelection = '';
        this.msg = 'Invalid Period';
        this.forecast.showError = true;
        this.cashForecast = null;
        this._appService.notify({
          status: 1,
          msg: this.msg
        });
        return;
      }
    }
    if (!this.onSelection) {
      this.msg = 'Invalid Period';
      this.forecast.showError = true;
      this.cashForecast = null;
      this._appService.notify({
        status: 1,
        msg: this.msg
      });
      return;
    } else {
      req.period = this.onSelection;
    }
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadReport' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (data && data.length > 0) {
        this.formatReportData(data);
      } else {
        this.transposedCashforecast = [];
      }
      this.showSpinner = false;
      if (this.selectDrillDownReport) {
        this.showDrilldown(this.selectDrillDownReport);
      }
    });
  }

  loadReportFormat(data) {
    try {
      this.reportData = [...data];
      let totals = [], i, k, j;
      for (i = 0; i < this.reportData.length; i++) {
        for (k = 0; k <= 12; k++) {
          this.reportData[i]['w' + k] = parseFloat(this.reportData[i]['w' + k]) || 0;
          this.reportData[i]['f_w' + k] = this._formatService.formatNumber(this.reportData[i]['w' + k]);
          totals[k] = totals[k] ? totals[k] + this.reportData[i]['w' + k] : this.reportData[i]['w' + k];
        }
      }
      for (j = 0; j < totals.length; j++) {
        totals[j] = this._formatService.formatNumber(totals[j]);
      }
      this.allTotals = totals;
      this.cashForecast = this._orderBy.transform(this.reportData, this.predicate, this.desc);
      this.showSpinner = false;
    } catch (e) {
      this.showSpinner = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
  }

  // Supplier Data
  loadSupplierData(type): void {
    this.pageDim = true;
    this.viewDataList = [];
    let endPoint = '/cashforecast/supplier/aging/';
    const org = this._cacheService.getOrgId();
    this.exportMultipleData = {};
    this.secondTableData = [];
    this.totalsDueAmount = 0;
    this.totalsBaseAmount = 0;
    this.secondTableTotals = [];
    if (org) {
      endPoint += org + '/';
    }
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadSupplierData' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.formatLoadSupplier(data, type);
      }
    });
  }

  // Tobe Invoiced Data
  loadToBeInvoiced(type): void {
    const org = this._cacheService.getOrgId();
    const endPoint = `/cashforecast/supplier/arinterface/${org}/`;
    this.pageDim = true;
    this.viewDataList = [];
    this.viewData = '';
    this.secondTableData = [];
    this.totalsDueAmount = 0;
    this.totalsBaseAmount = 0;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadToBeInvoiced' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.formatLoadToBeInvoiced(data, type);
      }
      this.pageDim = false;
    });
  }

  loadWeeks(): void {
    const endPoint = '/cashforecast/weeks/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadWeeks' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (data && data.length > 0) {
        const weeks = [...data];
        for (let i = 0; i < weeks.length; i++) {
          weeks[i].formatted = `${this._formatService.formatDate(data[i].start_date)} to
           ${this._formatService.formatDate(weeks[i].end_date)}`;
        }
        this.weeks = weeks;
        this.loadReport();
      }
    });
  }

  onBankAccountChange(): void {
    // Bank account should be considered only for US org
    if (this._cacheService.getOrgId() === 202 || this._cacheService.getOrgId() === 82) {
      if (this.selectedBank === 'All Banks') {
        this.viewData = this.secondTableData;
      } else {
        if (!this.bankAccounts || this.bankAccounts.length === 0 || !this.selectedBank) {
          return;
        }
        const index = this.bankAccounts.findIndex((account) => account.bank_account_identifier === this.selectedBank);
        const bankAccount = this.bankAccounts[index].account_name;
        this.viewData = this.secondTableData.filter((data) => data.gl_account === bankAccount);
      }
      this.calculateDrillDownTotals(this.viewData);
    }
  }

  onCheckboxSelectionChange(): void {
    this.showExcludeButton = this.viewData.some((row) => row.isSelected);
  }

  onPeriodSelect(): void {
    const index = this.periods.map((x) => x.period_name).indexOf(this.onSelection);
    if (index !== -1) {
      this.period_name = this.periods[index].period_name;
      this.fileName = null;
    } else {
      this.period_name = '';
    }
  }

  // Purchase Order Export
  purchaseOrdersExport() {
    let data = this._orderBy.transform(this.secondTableData, this.predicateTable, this.descTable),
      tableData: any = {}, tmpData = [], i, tmpObj, k;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj['Vendor Name'] = {
        data: data[i].supplier_name
      };
      tmpObj.Segment = {
        data: data[i].segment
      };
      tmpObj.Currency = {
        data: data[i].currency_code
      };
      tmpObj.PO = {
        data: data[i].invoice_number
      };
      tmpObj['Due Amount'] = {
        data: data[i].f_w0,
        align: 'right'
      };
      for (k = 1; k <= 12; k++) {
        tmpObj['W' + k] = {
          data: data[i]['f_w' + k],
          align: 'right'
        };
      }
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    return tableData.data;
  }

  setUpDOMHandlers(): void {
    jQuery('.scroll-top').click(() => {
      this._appService.scrollTop();
    });
  }

  // choose type and get respective data
  showDrilldown(budgetDescription): void {
    this.selectDrillDownReport = budgetDescription;
    this.pageDim = true;
    const endPoint = `/cashforecast/drilldown/${this._cacheService.getOrgId()}/${budgetDescription}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (!data) {
        this._appService.notify(new ServerError('loadDrillDownData'));
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.formatDrillDownData(data, budgetDescription);
      }
      this.pageDim = false;
    });
  }

  // Primary Table Sorting
  sort(key): void {
    this.desc = !this.desc;
    this.predicate = key;
    this.cashForecast = this._orderBy.transform(this.cashForecast, this.predicate, this.desc);
  }

  // Secondary Table Sorting
  sortTable(key): void {
    this.descTable = !this.descTable;
    this.predicateTable = key;
    this.viewDataList = this._orderBy.transform(this.viewDataList, this.predicateTable, this.descTable);
  }

  // Supplier Invoice Export
  supplierInvExport() {
    let data = this._orderBy.transform(this.secondTableData, this.predicateTable, this.descTable),
      tableData: any = {}, tmpData = [], i, tmpObj;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};

      data[i].due_amount = data[i].due_amount || null;

      data[i].base_amount_new = data[i].base_amount_new || null;

      tmpObj.Supplier = {
        data: data[i].supplier_name
      };
      tmpObj.Type = {
        data: data[i].type || ''
      };
      tmpObj['GL Account'] = {
        data: data[i].gl_account
      };
      tmpObj['Invoice Date'] = {
        data: data[i].invoice_date_new
      };
      tmpObj['Due Date'] = {
        data: data[i].due_date_new
      };
      tmpObj.Due = {
        data: data[i].due_new,
        align: 'right'
      };
      tmpObj['Invoice Number'] = {
        data: data[i].invoice_number
      };
      tmpObj.Currency = {
        data: data[i].currency_code
      };
      tmpObj['Base Amount'] = {
        data: data[i].base_amount_new,
        align: 'right'
      };
      for (let k = 1; k <= 12; k++) {
        tmpObj['W' + k] = {
          data: data[i]['f_w' + k],
          align: 'right'
        };
      }
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    return tableData.data;
  }

  // To be Invoiced Export
  toBeInvExport() {
    let data = this._orderBy.transform(this.secondTableData, this.predicateTable, this.descTable),
      tableData: any = {}, tmpData = [], i, tmpObj, k;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};

      data[i].base_amount = data[i].base_amount || null;

      tmpObj.Account = {
        data: data[i].gl_account
      };
      tmpObj['Party Name'] = {
        data: data[i].supplier_name
      };
      tmpObj['Due Date'] = {
        data: data[i].due_date
      };
      tmpObj['Trx Date'] = {
        data: data[i].invoice_date
      };
      tmpObj['Payment Method'] = {
        data: data[i].payment_method
      };
      tmpObj['Term Name'] = {
        data: data[i].payment_term
      };
      tmpObj['Account Number'] = {
        data: data[i].account
      };
      tmpObj['Sales Oreder'] = {
        data: data[i].invoice_number
      };
      tmpObj.Currency = {
        data: data[i].currency_code
      };
      tmpObj.Amount = {
        data: data[i].f_amount,
        align: 'right'
      };
      tmpObj['Base Amount'] = {
        data: data[i].f_base_amount,
        align: 'right'
      };
      for (k = 1; k <= 12; k++) {
        tmpObj['W' + k] = {
          data: data[i]['f_w' + k],
          align: 'right'
        };
      }
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    return tableData.data;
  }

  updateBank(index: number): void {
    const data = this.viewData[index];
    const endPoint = '/cashforecast/bank/update/';
    this._httpService.httpRequest('POST', endPoint, data, (result) => {
      if (!result) {
        this._appService.notify({ status: 1, msg: 'Server Error - updateBank()' });
      } else if (result.status === 1) {
        this._appService.notify(result);
      }
    });
  }
}
