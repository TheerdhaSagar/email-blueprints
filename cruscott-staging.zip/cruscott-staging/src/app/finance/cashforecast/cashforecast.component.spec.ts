import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CashforecastComponent } from './cashforecast.component';

describe('CashforecastComponent', () => {
  let component: CashforecastComponent;
  let fixture: ComponentFixture<CashforecastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CashforecastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashforecastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
