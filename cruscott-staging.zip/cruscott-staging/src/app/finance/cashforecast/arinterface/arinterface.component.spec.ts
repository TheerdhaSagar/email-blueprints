import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArinterfaceComponent } from './arinterface.component';

describe('ArinterfaceComponent', () => {
  let component: ArinterfaceComponent;
  let fixture: ComponentFixture<ArinterfaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArinterfaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArinterfaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
