import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { OrderByPipe } from '../../../globals/order-by.pipe';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';
import { APIError } from '../../../globals/api.error';

@Component({
  selector: 'app-finance-cashforecast-arinterface',
  templateUrl: './arinterface.component.html',
  styleUrls: ['./arinterface.component.scss'],
  providers: [OrderByPipe]
})
export class CashForecastArInterfaceComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _router: Router;

  cashForecast: any;
  currency: any;
  desc: boolean;
  pageDim: boolean;
  predicate: string;
  searchText: any;
  subOrgChange: Subscription;
  toggleFilter: (e?) => void;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, orderBy: OrderByPipe,
              formatService: FormatService, httpService: HttpService, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._router = router;

    // scope variables
    this.cashForecast = [];
    this.currency = null;
    this.desc = false;
    this.pageDim = null;
    this.predicate = 'gl_account';
    this.subOrgChange = null;
    this.toggleFilter = appService.toggleFilter();
    this.user = null;
  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(this.user);
        }
        this.loadData();
      }
    });

    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this.loadData();
    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  // Export table data to excel
  exportToExcel() {
    this.pageDim = true;
    let data = this._orderBy.transform(this.cashForecast, this.predicate, this.desc),
      tableData: any = {}, tmpObj, i,
      tmpData = [];
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      if (!data[i].amount) {
        data[i].amount = null;
      }
      if (!data[i].base_amount) {
        data[i].base_amount = null;
      }
      tmpObj.Account = { data: data[i].gl_account };
      tmpObj['Party Name'] = { data: data[i].party_name };
      tmpObj['Due Date'] = { data: data[i].due_date };
      tmpObj['Trx Date'] = { data: data[i].trx_date };
      tmpObj['Payment Method'] = { data: data[i].payment_method };
      tmpObj['Term Name'] = { data: data[i].term_name };
      tmpObj['Account Number'] = { data: data[i].account_number };
      tmpObj['Sales Oreder'] = { data: data[i].sales_order };
      tmpObj.Amount = { data: data[i].amountNew, align: 'right' };
      tmpObj['Base Amount'] = { data: data[i].baseAmountNew, align: 'right' };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('ToBeInvoiced', tableData, 'export-data');
    this.pageDim = false;
  }

  loadData() {
    this.pageDim = true;
    let endPoint,
      org = this._cacheService.getOrgId();
    endPoint = '/cashforecast/supplier/arinterface/' + org + '/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadData' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.currency = data[0].invoice_currency_code;
        for (let i = 0; i < data.length; i++) {
          if (data[i].amount) {
            data[i].amountNew = this._formatService.formatNumber(data[i].amount);
          } else {
            data[i].amountNew = 0;
            data[i].amount = 0;
          }
          if (data[i].base_amount) {
            data[i].baseAmountNew = this._formatService.formatNumber(data[i].base_amount);
          } else {
            data[i].baseAmountNew = 0;
            data[i].base_amount = 0;
          }
          if (data[i].due_date) {
            data[i].dueDateMillis = this._formatService.dateInMillis(data[i].due_date);
            data[i].due_date = this._formatService.formatDate(data[i].due_date);
          }
          if (data[i].trx_date) {
            data[i].trxDateMillis = this._formatService.dateInMillis(data[i].trx_date);
            data[i].trx_date = this._formatService.formatDate(data[i].trx_date);
          }
          if (data[i].account_number) {
            data[i].accountNumberNew = parseInt(data[i].account_number);
          }
          if (data[i].sales_order) {
            data[i].salesOrderNew = parseInt(data[i].sales_order);
          }
        }
        this.cashForecast = data;
      }
      this.pageDim = false;
    });
  }

  sort(key) {
    this.predicate = key;
    this.desc = !this.desc;
    this.cashForecast = this._orderBy.transform(this.cashForecast, this.predicate, this.desc);
  }

}
