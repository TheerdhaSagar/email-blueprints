import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { OrderByPipe } from '../../../globals/order-by.pipe';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-finance-cashforecast-supplier',
  templateUrl: './supplier.component.html',
  styleUrls: ['./supplier.component.scss'],
  providers: [OrderByPipe]
})
export class CashForecastSupplierComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _router: Router;

  cashForecast: any;
  currency: any;
  desc: boolean;
  pageDim: boolean;
  predicate: string;
  searchText: string;
  toggleFilter: (e?) => void;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, orderBy: OrderByPipe,
              formatService: FormatService, httpService: HttpService, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._router = router;

    // scope variables
    this.cashForecast = [];
    this.currency = null;
    this.desc = false;
    this.pageDim = false;
    this.predicate = 'gl_account';
    this.searchText = '';
    this.toggleFilter = appService.toggleFilter();
    this.user = null;
  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(this.user);
        }
        this.loadData();
      }
    });
  }

  // Export table data to excel
  exportToExcel() {
    this.pageDim = true;
    let data = this._orderBy.transform(this.cashForecast, this.predicate, this.desc),
      tableData: any = {}, tmpObj, i,
      tmpData = [];
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      if (!data[i].due) {
        data[i].due = null;
      }
      if (!data[i].base_amount_new) {
        data[i].base_amount_new = null;
      }
      if (!data[i].base_amount_new) {
        data[i].base_amount_new = null;
      }
      tmpObj.Supplier = { data: data[i].vendor_name };
      tmpObj.Type = { data: data[i].type };
      tmpObj['GL Account'] = { data: data[i].gl_account };
      tmpObj.Due = { data: data[i].dueNew, align: 'right' };
      tmpObj['Base Amount'] = { data: data[i].baseAmountNew, align: 'right' };
      tmpObj['Invoice Date'] = { data: data[i].invoiceDateNew };
      tmpObj['Due Date'] = { data: data[i].dueDateNew };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('supplierAging', tableData, 'export-data');
    this.pageDim = false;
  }

  loadData() {
    this.pageDim = true;
    let endPoint;
    endPoint = '/cashforecast/supplier/aging/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadData' });
      } else {
        this.currency = data[0].invoice_currency_code;
        for (let i = 0; i < data.length; i++) {
          if (data[i].amount) {
            data[i].amountNew = this._formatService.formatNumber(data[i].amount);
          } else {
            data[i].amountNew = 0;
            data[i].amount = 0;
          }

          if (data[i].base_amount) {
            data[i].baseAmountNew = this._formatService.formatNumber(data[i].base_amount);
          } else {
            data[i].baseAmountNew = 0;
            data[i].base_amount = 0;
          }

          if (data[i].due) {
            data[i].dueNew = this._formatService.formatNumber(data[i].due);
          } else {
            data[i].dueNew = 0;
            data[i].due = 0;
          }

          if (data[i].w0) {
            data[i].w0New = this._formatService.formatNumber(data[i].w0);
          } else {
            data[i].w0_new = 0;
            data[i].w0 = 0;
          }
          if (data[i].due_date) {
            data[i].dueDateNew = this._formatService.formatDate(data[i].due_date);
            data[i].due_date_millis = this._formatService.dateInMillis(data[i].due_date);
          }
          if (data[i].invoice_date) {
            data[i].invoiceDateNew = this._formatService.formatDate(data[i].invoice_date);
            data[i].invoice_date_millis = this._formatService.dateInMillis(data[i].invoice_date);
          }
        }
        this.cashForecast = data;
      }
      this.pageDim = false;
    });
  }

  sort(key) {
    this.predicate = key;
    this.desc = !this.desc;
    this.cashForecast = this._orderBy.transform(this.cashForecast, this.predicate, this.desc);
  }

}
