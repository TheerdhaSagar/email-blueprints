export interface Balance {
  bank_balance: number;
  currency_code: string;
  due_amount: number;
  f_bank_balance: string;
  f_due_amount: string;
  f_provisional_balance: string;
  provisional_balance: number;
}
