import {
  Component, OnInit, Injector, OnDestroy
} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { BankAccountsService } from './bank-accounts.service';
import { BankAccount } from './bank-account';
import { Balance } from './balance';
import { FormatService } from '../../globals/format.service';

declare const FooPicker;

@Component({
  selector: 'app-bank-accounts',
  templateUrl: './bank-accounts.component.html',
  styleUrls: ['./bank-accounts.component.scss']
})
export class BankAccountsComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _bankAccountsService: BankAccountsService = this.injector.get(BankAccountsService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _router: Router = this.injector.get(Router);

  balances: Balance[];
  bankAccounts: BankAccount[];
  desc = false;
  dueDate: string;
  orgId: number;
  orgName: string;
  orgSelected: number;
  parsedBankAccounts: { currency_code: string; bankAccounts: BankAccount[] }[];
  pageDim = false;
  predicate: string;
  selectedBank: BankAccount;
  showDialog: boolean;
  subOrgChange: Subscription;
  toggleFilter: (e?) => void;
  user: { date_format: string; organizations?: any[] };
  viewBy: string;

  constructor(private injector: Injector) {
    this.orgId = null;
    this.predicate = 'account_name';
    this.toggleFilter = this._appService.toggleFilter();
    this.viewBy = 'account';
  }

  ngOnInit(): void {
    this._cacheService.getUser((user) => {
      if (!user) {
        this._router.navigate(['login']);
      } else {
        this.user = user;
        this.getOrgDetails();
        this.loadBankAccounts(this.orgId);

        this.setUpDate();

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.getOrgDetails();
          this.loadBankAccounts(this.orgId);
          this.loadBalances(this.orgId);
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addBankAccount(): void {
    const bankAccount = this.getAccountObject();
    this.bankAccounts.push(bankAccount);
    this._bankAccountsService.createOrUpdateBankAccount('POST', bankAccount)
      .then(() => {
        this.loadBankAccounts(this.orgId);
      })
      .catch((error) => {
        this._appService.notify(error);
        this.bankAccounts.pop();
      });
  }

  applyFilter(): void {
    this.toggleFilter();
    this.pageDim = true;
    if (this.viewBy === 'balance') {
      this.loadBalances(this.orgSelected);
    } else {
      this.loadBankAccounts(this.orgSelected);
    }
  }

  backToDashboard(): void {
    this._router.navigate(['finance/cashflow']);
  }

  deleteBank(): void {
    this.showDialog = false;
    this._bankAccountsService.deleteBankAccount(this.selectedBank)
      .then(() => {
        this.bankAccounts = this.bankAccounts.filter(
          (bank) => this.selectedBank.bank_account_identifier !== bank.bank_account_identifier
        );
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  getAccountObject(): BankAccount {
    return {
      account_name: '',
      account_number: '',
      bank_account_identifier: '',
      bank_name: '',
      current_balance: 0,
      currency_code: '',
      exchange_rate: 0,
      f_current_balance: '0',
      f_exchange_rate: '0',
      f_statement_date: this._formatService.formatDate(this._appService.today()),
      organization_id: this.orgId,
      statement_date: this._appService.today(),
      statement_date_millis: this._formatService.dateInMillis(this._appService.today()),
      statement_identifier: '',
      total_balance: 0
    };
  }

  getOrgDetails(): void {
    this.pageDim = true;
    this.orgId = this._cacheService.getOrgId();
    this.orgName = (this.user.organizations.filter((details) => details.organization_id === this.orgId))[0].name;
    this.orgSelected = this.orgId;
  }

  loadBalances(orgId): void {
    let dueDate;
    if (this.dueDate) {
      dueDate = this._formatService.parseDate(this.dueDate);
    }
    this._bankAccountsService.getBalances(orgId, dueDate)
      .then((result) => {
        this.balances = result;
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  loadBankAccounts(orgId): void {
    this._bankAccountsService.getBankAccounts(orgId)
      .then((result) => {
        this.bankAccounts = result;
        if (this.viewBy === 'currency') {
          this.parseBankAccounts();
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
    if (this.viewBy === 'currency') {
      this.parseBankAccounts();
    }
  }

  onContentChange(cellIndex: number, id: string, cellAttribute: string): void {
    const cell = document.getElementById(`cell-${cellIndex}-${cellAttribute}`);
    if (!cell) {
      return;
    }
    const index = this.bankAccounts.findIndex((account) => account.bank_account_identifier === id);
    let cellValue = cell.innerText;
    const data = this.bankAccounts[index][cellAttribute];
    if (index !== -1) {
      if (!data || (data && data.toString() !== cellValue.toString())) {
        cellValue = this.onContentNumberChange(cellAttribute, cellValue);
        cell.innerText = cellValue || '0';
        this.updateBankAccountData(cellValue, cellAttribute, index);
      }
    }
  }

  onContentNumberChange(cellAttribute, htmlValue): string {
    let cellValue = htmlValue;
    const regEx = /^([0-9 .,-])+$/;
    if (cellAttribute === 'current_balance' || cellAttribute === 'exchange_rate') {
      if (!regEx.test(cellValue.toString())) {
        cellValue = '';
      } else {
        cellValue = this._formatService.parseNumber(cellValue);
        cellValue = this._formatService.formatNumber(cellValue, cellAttribute === 'exchange_rate' ? 4 : 0);
      }
    }
    return cellValue;
  }

  parseBankAccounts(): void {
    const currencyCodes = [];
    this.parsedBankAccounts = [];
    this.bankAccounts.forEach((bankAccount) => {
      const index = currencyCodes.findIndex((code) => code === bankAccount.currency_code);
      if (index === -1) {
        currencyCodes.push(bankAccount.currency_code);
      }
    });
    currencyCodes.forEach((currency) => {
      this.parsedBankAccounts.push({
        currency_code: currency,
        bankAccounts: this.bankAccounts.filter((account) => account.currency_code === currency)
      });
    });
  }

  setUpDate(): void {
    const _ = new FooPicker({
      id: 'due-date',
      dateFormat: this.user.date_format || 'dd-MMM-yyyy'
    });
  }

  sort(predicate: string): void {
    if (predicate === this.predicate) {
      this.desc = !this.desc;
    }
    this.predicate = predicate;
  }

  updateBankAccount(index: number): void {
    const account = { ...this.bankAccounts[index] };
    this._bankAccountsService.createOrUpdateBankAccount('PUT', account)
      .then(() => {
        this.bankAccounts = this._bankAccountsService.parseBanksData(this.bankAccounts);
        if (this.viewBy === 'currency') {
          this.parseBankAccounts();
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  updateBankAccountData(cellValue, cellAttribute, index): void {
    if (cellAttribute === 'current_balance') {
      this.bankAccounts[index][cellAttribute] = this._formatService.parseNumber(cellValue) || 0;
      this.bankAccounts[index].total_balance = this.bankAccounts[index][cellAttribute] +
        this.bankAccounts[index].mt940_closing_balance;
    } else if (cellAttribute === 'exchange_rate') {
      this.bankAccounts[index][cellAttribute] = this._formatService.parseNumber(cellValue) || 0;
    } else {
      this.bankAccounts[index][cellAttribute] = cellValue || 0;
    }
    this.updateBankAccount(index);
  }
}
