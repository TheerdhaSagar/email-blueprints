import { Injectable } from '@angular/core';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { ServerError } from '../../globals/server.error';
import { BankAccount } from './bank-account';
import { Balance } from './balance';
import { Response } from '../../globals/response';
import { APIError } from '../../globals/api.error';

@Injectable({
  providedIn: 'root'
})
export class BankAccountsService {
  private _formatService: FormatService;
  private _httpService: HttpService;
  urlPrefix = '/cashforecast/bankaccounts/';

  constructor(formatService: FormatService, httpService: HttpService) {
    this._formatService = formatService;
    this._httpService = httpService;
  }

  createOrUpdateBankAccount(method: string, bankAccount: BankAccount): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}`;
      this._httpService.httpRequest(method, endPoint, { ...bankAccount }, (response) => {
        if (!response) {
          reject(new ServerError('createOrUpdateBankAccount'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  deleteBankAccount(bankAccount: BankAccount): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}${bankAccount.bank_account_identifier}/`;
      this._httpService.httpRequest('DELETE', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deleteBankAccount'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  getBalances(orgId: number, dueDate: string = null): Promise<Balance[]> {
    return new Promise((resolve, reject) => {
      let endPoint = '/cashforecast/balance/';
      let req;
      if (dueDate) {
        req = { org_id: orgId, due_date: dueDate };
      } else {
        endPoint += orgId ? `${orgId}/` : '';
      }
      this._httpService.httpRequest(dueDate ? 'POST' : 'GET', endPoint, req, (response) => {
        if (!response) {
          reject(new ServerError('getBalances'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(this.parseBalances(response));
        }
      });
    });
  }

  getBankAccounts(orgId: number): Promise<BankAccount[]> {
    return new Promise((resolve, reject) => {
      let endPoint = `${this.urlPrefix}`;
      endPoint = orgId ? `${endPoint}${orgId}/` : endPoint;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('getBankAccounts'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(this.parseBanksData(response));
        }
      });
    });
  }

  parseBalances(balances: Balance[]): Balance[] {
    const data = balances;
    for (let index = 0; index < data.length; index++) {
      data[index].f_bank_balance = this._formatService.formatNumber(data[index].bank_balance);
      data[index].f_due_amount = this._formatService.formatNumber(data[index].due_amount);
      data[index].f_provisional_balance = this._formatService.formatNumber(data[index].provisional_balance);
    }
    return data;
  }

  parseBanksData(bankAccounts: BankAccount[]): BankAccount[] {
    const data = bankAccounts;
    data.forEach((bankData: BankAccount) => {
      const bank = bankData;
      bank.f_current_balance = this._formatService.formatNumber(bank.current_balance);
      bank.f_exchange_rate = this._formatService.formatNumber(bank.exchange_rate, 4);
      bank.f_statement_date = this._formatService.formatDate(bank.statement_date);
      bank.mt940_processed_date_in_millis = this._formatService.dateInMillis(bank.mt940_processed_date) || null;
      bank.total_balance = bank.current_balance + (bank.mt940_closing_balance || 0);
      bank.statement_date_millis = this._formatService.dateInMillis(bank.statement_date);
    });
    return data;
  }
}
