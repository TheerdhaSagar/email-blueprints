export interface BankAccount {
  account_name: string;
  account_number: string;
  bank_account_identifier: string;
  bank_name: string;
  current_balance: number;
  currency_code: string;
  exchange_rate: number;
  f_current_balance: string;
  f_exchange_rate: string;
  f_statement_date: string;
  mt940_closing_balance?: number;
  mt940_opening_balance?: number;
  mt940_processed_date?: string;
  mt940_processed_date_in_millis?: number;
  organization_id: number;
  statement_date: string;
  statement_date_millis: number;
  statement_identifier: string;
  total_balance?: number;
}
