import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FinanceReportsComponent } from './reports/reports.component';
import { CashflowDashboardComponent } from './cashflow-dashboard/cashflow-dashboard.component';
import { CashForecastComponent } from './cashforecast/cashforecast.component';
import { ChartOfAccountsComponent } from './chartofaccounts/chartofaccounts.component';
import { TrailBalanceComponent } from './trailbalance/trailbalance.component';
import { TrailDrillDownComponent } from './trailbalance/drilldown/drilldown.component';
import { SupplierCashflowSetupComponent } from './supplier-cashflow-setup/supplier-cashflow-setup.component';
import { BankAccountsComponent } from './bank-accounts/bank-accounts.component';
import { BudgetSetupComponent } from './budget-setup/budget-setup.component';
import { ExcludedInvoicesComponent } from './excluded-invoices/excluded-invoices.component';

const routes: Routes = [
  { path: 'dashboard', component: FinanceReportsComponent },
  { path: 'cashflow', component: CashflowDashboardComponent },
  { path: 'cashforecast', component: CashForecastComponent },
  { path: 'chartofaccounts', component: ChartOfAccountsComponent },
  { path: 'trailbalance', component: TrailBalanceComponent },
  { path: 'trailbalance/details', component: TrailDrillDownComponent },
  { path: 'supplier-setup', component: SupplierCashflowSetupComponent },
  { path: 'bank-accounts', component: BankAccountsComponent },
  { path: 'budget-setup', component: BudgetSetupComponent },
  { path: 'excluded-invoices', component: ExcludedInvoicesComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FinanceRoutingModule { }
