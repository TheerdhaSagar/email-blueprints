import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CacheService } from '../../globals/cache.service';
import { ReportService } from '../../globals/report.service';

@Component({
  selector: 'app-finance-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class FinanceReportsComponent implements OnInit {
  private _cacheService: CacheService;
  private _reportService: ReportService;
  private _router: Router;

  constructor(cacheService: CacheService, reportService: ReportService, router: Router) {
    this._cacheService = cacheService;
    this._reportService = reportService;
    this._router = router;
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
      }
    });
  }

  showReport(name): void {
    this._reportService.selectedReportView = '';
    this._router.navigate([name]);
  }
}
