export interface Budget {
  amount: number;
  bank_account_identifier?: string;
  budget_id: number;
  budget_name: string;
  due_date: string;
  frequency: string;
  org_id: number;
}
