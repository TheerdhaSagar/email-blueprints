import { Injectable } from '@angular/core';
import { HttpService } from '../../globals/http.service';
import { FormatService } from '../../globals/format.service';
import { ServerError } from '../../globals/server.error';
import { Response } from '../../globals/response';
import { Budget } from './budget';
import { APIError } from '../../globals/api.error';

@Injectable({
  providedIn: 'root'
})
export class BudgetSetupService {
  private _httpService: HttpService;

  urlPrefix = '/cashforecast/';
  frequencies = ['Mid of Month', 'Monthly', 'Quarterly', 'Yearly'];

  constructor(private formatService: FormatService, httpService: HttpService) {
    this._httpService = httpService;
  }

  createOrUpdateBudget(method: string, budget: Budget): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}budget/`;
      this._httpService.httpRequest(method, endPoint, { ...budget }, (response) => {
        if (!response) {
          reject(new ServerError('createOrUpdateBudget'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  deleteBudget(budgetId: number, orgId: number): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}budget/${orgId}/${budgetId}/`;
      this._httpService.httpRequest('DELETE', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deleteBudget'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  getBudgets(orgId): Promise<Budget[]> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}budget/${orgId}/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('getBudgets'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(this.parseBudgets(response));
        }
      });
    });
  }

  parseBudgets(budgets: Budget[]): Budget[] {
    const data = [...budgets];
    for (let index = 0; index < data.length; index++) {
      data[index].due_date = this.formatService.formatDate(data[index].due_date);
    }
    return data;
  }
}
