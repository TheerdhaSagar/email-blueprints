import {
  Component, OnInit, Injector, OnDestroy
} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { FormatService } from '../../globals/format.service';
import { BankAccountsService } from '../bank-accounts/bank-accounts.service';
import { BudgetSetupService } from './budget-setup.service';
import { BankAccount } from '../bank-accounts/bank-account';
import { Budget } from './budget';

declare let FooPicker;

@Component({
  selector: 'app-budget-setup',
  templateUrl: './budget-setup.component.html',
  styleUrls: ['./budget-setup.component.scss']
})
export class BudgetSetupComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _bankAccountService: BankAccountsService = this.injector.get(BankAccountsService);
  private _budgetSetupService: BudgetSetupService = this.injector.get(BudgetSetupService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _router: Router = this.injector.get(Router);

  bankAccounts: BankAccount[];
  budget: Budget;
  budgets: Budget[];
  desc = false;
  pageDim = false;
  predicate: string;
  showDialog: boolean;
  subOrgChange: Subscription;
  user: { date_format: string };

  constructor(private injector: Injector) {
    this.predicate = 'budget_name';
  }

  ngOnInit(): void {
    this._cacheService.getUser((user) => {
      if (!user) {
        this._router.navigate(['login']);
      } else {
        this.pageDim = true;
        this.loadBudgets();
        this.loadBankAccounts();

        this.user = user;

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.loadBudgets();
          this.loadBankAccounts();
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addBudget(): void {
    const budget = {
      budget_id: -1,
      budget_name: '',
      amount: 0,
      frequency: 'Monthly',
      org_id: this._cacheService.getOrgId(),
      due_date: ''
    };
    this.budgets.push(budget);
    this._budgetSetupService.createOrUpdateBudget('POST', budget)
      .then(() => {
        this.loadBudgets();
      })
      .catch((error) => {
        this._appService.notify(error);
        this.budgets.pop();
      });
  }

  backToDashboard(): void {
    this._router.navigate(['finance/cashflow']);
  }

  deleteBudget(): void {
    const index = this.budgets.findIndex((budget) => budget.budget_id === this.budget.budget_id);
    if (index !== -1) {
      this._budgetSetupService.deleteBudget(this.budgets[index].budget_id, this._cacheService.getOrgId())
        .then(() => {
          this.budgets.splice(index, 1);
        })
        .catch((error) => {
          this._appService.notify(error);
        });
    }
    this.showDialog = false;
  }

  loadBankAccounts(): void {
    const orgId = this._cacheService.getOrgId();
    this._bankAccountService.getBankAccounts(orgId)
      .then((result) => {
        this.bankAccounts = result;
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  loadBudgets(): void {
    const orgId = this._cacheService.getOrgId();
    this._budgetSetupService.getBudgets(orgId)
      .then((result) => {
        this.budgets = result;
        this.setUpDatePickers();
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  onContentChange(index: number, cellAttribute: string): void {
    const cell = document.getElementById(`cell-${index}-${cellAttribute}`);
    if (!cell) {
      return;
    }
    let cellValue = cell.innerText;
    const data = this.budgets[index][cellAttribute];
    const regEx = /^([0-9 .,-])+$/;
    if (!data || (data.toString() !== cellValue.toString())) {
      if (cellAttribute === 'amount' && !regEx.test(cellValue.toString())) {
        cellValue = '';
      }
      this.budgets[index][cellAttribute] = cellValue || 0;
      cell.innerText = cellValue || '0';
      this.updateBudget(index);
    }
  }

  setUpDatePickers(): void {
    setTimeout(() => {
      for (let index = 0; index < this.budgets.length; index++) {
        new FooPicker({
          id: `due-date-${index}`,
          dateFormat: this.user.date_format || 'dd-MMM-yyyy'
        });
      }
    });
  }

  sort(predicate: string): void {
    if (predicate === this.predicate) {
      this.desc = !this.desc;
    }
    this.predicate = predicate;
  }

  updateBudget(index: number): void {
    const budget = { ...this.budgets[index] };
    if (budget.due_date) {
      budget.due_date = this._formatService.parseDate(budget.due_date);
    }
    this._budgetSetupService.createOrUpdateBudget('PUT', budget)
      .catch((error) => {
        this._appService.notify(error);
      });
  }
}
