import { NgModule } from '@angular/core';
import { ShareModule } from '../share/share.module';

import { FinanceRoutingModule } from './finance-routing.module';

import { FinanceReportsComponent } from './reports/reports.component';
import { CashflowDashboardComponent } from './cashflow-dashboard/cashflow-dashboard.component';
import { CashForecastComponent } from './cashforecast/cashforecast.component';
import { ChartOfAccountsComponent } from './chartofaccounts/chartofaccounts.component';
import { TrailBalanceComponent } from './trailbalance/trailbalance.component';
import { TrailDrillDownComponent } from './trailbalance/drilldown/drilldown.component';
import { SupplierCashflowSetupComponent } from './supplier-cashflow-setup/supplier-cashflow-setup.component';
import { BankAccountsComponent } from './bank-accounts/bank-accounts.component';
import { BudgetSetupComponent } from './budget-setup/budget-setup.component';
import { ExcludedInvoicesComponent } from './excluded-invoices/excluded-invoices.component';

@NgModule({
  declarations: [
    FinanceReportsComponent,
    CashflowDashboardComponent,
    CashForecastComponent,
    ChartOfAccountsComponent,
    TrailBalanceComponent,
    TrailDrillDownComponent,
    SupplierCashflowSetupComponent,
    BankAccountsComponent,
    BudgetSetupComponent,
    ExcludedInvoicesComponent
  ],
  imports: [
    ShareModule,
    FinanceRoutingModule
  ]
})
export class FinanceModule { }
