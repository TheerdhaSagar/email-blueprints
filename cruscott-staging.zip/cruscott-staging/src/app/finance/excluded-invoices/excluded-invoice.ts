export class ExcludedInvoice {
  cashflow_type: string;
  customer_name: string;
  customer_number: number;
  exclusion_id: number;
  invoice_number: string;
  isSelected: boolean;
  org_id: number;
  reference_num: string;
}
