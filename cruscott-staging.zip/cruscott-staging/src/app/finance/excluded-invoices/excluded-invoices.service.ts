import { Injectable } from '@angular/core';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';
import { ServerError } from '../../globals/server.error';
import { Response } from '../../globals/response';
import { ExcludedInvoice } from './excluded-invoice';

@Injectable({
  providedIn: 'root'
})
export class ExcludedInvoicesService {
  private _httpService: HttpService;

  urlPrefix = '/cashforecast/exclude/';

  constructor(httpService: HttpService) {
    this._httpService = httpService;
  }

  getExcludedInvoices(orgId: number): Promise<ExcludedInvoice[]> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}${orgId}/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('getExcludedInvoices'));
        } else if (response.status && response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  removeInvoices(invoices: ExcludedInvoice[]): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.urlPrefix}remove/`;
      this._httpService.httpRequest('POST', endPoint, invoices, (response) => {
        if (!response) {
          reject(new ServerError('removeInvoices'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }
}
