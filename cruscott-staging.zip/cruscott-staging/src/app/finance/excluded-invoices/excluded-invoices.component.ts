import {
  Component, OnInit, OnDestroy, Injector
} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { ExcludedInvoicesService } from './excluded-invoices.service';
import { ExcludedInvoice } from './excluded-invoice';

@Component({
  selector: 'app-excluded-invoices',
  templateUrl: 'excluded-invoices.component.html'
})
export class ExcludedInvoicesComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _excludedInvoicesService: ExcludedInvoicesService = this.injector.get(ExcludedInvoicesService);
  private _router: Router = this.injector.get(Router);

  invoices: ExcludedInvoice[];
  pageDim: boolean;
  showDialog: boolean;
  showRemoveButton: boolean;
  subscribeOrgChange: Subscription;

  constructor(private injector: Injector) {}

  ngOnInit(): void {
    this.loadExcludedInvoices();
    this.subscribeOrgChange = this._appService.subscribeOrgChange(() => {
      this.loadExcludedInvoices();
    });
  }

  ngOnDestroy(): void {
    if (this.subscribeOrgChange) {
      this.subscribeOrgChange.unsubscribe();
    }
  }

  backToDashboard(): void {
    this._router.navigate(['finance/cashflow']);
  }

  loadExcludedInvoices(): void {
    this.pageDim = true;
    this._excludedInvoicesService.getExcludedInvoices(this._cacheService.getOrgId())
      .then((result) => {
        this.invoices = result;
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  onInvoiceSelection(): void {
    this.showRemoveButton = this.invoices.some((invoice) => invoice.isSelected);
  }

  removeInvoices(): void {
    this.showDialog = false;
    this.pageDim = true;
    const data = this.invoices.filter((invoice) => invoice.isSelected);
    this._excludedInvoicesService.removeInvoices(data)
      .then(() => {
        this.showRemoveButton = false;
        this.invoices = this.invoices.filter((invoice) => !invoice.isSelected);
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }
}
