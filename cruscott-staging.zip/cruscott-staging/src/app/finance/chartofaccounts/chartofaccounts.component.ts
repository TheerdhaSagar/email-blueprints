import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';

@Component({
  selector: 'app-finance-chartofaccounts',
  templateUrl: './chartofaccounts.component.html',
  styleUrls: ['./chartofaccounts.component.scss'],
  providers: [OrderByPipe]
})
export class ChartOfAccountsComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  chartOfAccounts: any;
  currentPage: any;
  desc: boolean;
  pageSize: number;
  predicate: string;
  reportData: any;
  reportName: any;
  searchAccount: string;
  searchQuery: any;
  showSpinner: boolean;
  toggleFilter: (e?) => void;

  constructor(appService: AppService, cacheService: CacheService, orderBy: OrderByPipe,
              formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.chartOfAccounts = [];
    this.currentPage = null;
    this.desc = true;
    this.pageSize = appService.pageSize;
    this.predicate = 'account';
    this.reportData = [];
    this.reportName = null;
    this.searchQuery = null;
    this.showSpinner = true;
    this.toggleFilter = appService.toggleFilter();
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.reportName = 'Chart Of Accounts';
        this.showSpinner = true;
        this.loadReport();
      }
    });
  }

  // Exports the table data into spreadsheet
  exportToExcel() {
    let activeDate, data = this._orderBy.transform(this.reportData, this.predicate, this.desc),
      endDate, i,
      tableData: any = {},
      tmpReports = [];
    this.toggleFilter();
    try {
      for (i = 0; i < data.length; i++) {
        let tmpReport: any = {};
        tmpReport.Account = {
          data: data[i].account
        };
        tmpReport.Description = {
          data: data[i].description
        };
        tmpReport.Enabled = {
          data: data[i].enabled_flag
        };
        tmpReport.Summary = {
          data: data[i].summary_flag
        };
        if (data[i].start_date) {
          activeDate = data[i].start_date;
        } else {
          activeDate = '';
        }
        tmpReport['Active Date'] = {
          data: activeDate
        };
        if (data[i].end_date) {
          endDate = data[i].end_date;
        } else {
          endDate = '';
        }
        tmpReport['End Date'] = {
          data: endDate
        };
        tmpReport['Allow Budget'] = {
          data: data[i].allow_budget
        };
        tmpReport['Allow Posting'] = {
          data: data[i].allow_posting
        };
        tmpReport['Account Type'] = {
          data: data[i].account_type
        };
        tmpReports.push(tmpReport);
      }
      tableData.data = tmpReports;
      this._appService.tableToExcel('Chart Of Accounts', tableData, 'export-data');
    } catch (e) {
      this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
    }
  }

  formatData(data) {
    for (let i = 0; i < data.length; i++) {
      if (data[i].start_date_active !== null) {
        data[i].start_date_millis = this._formatService.dateInMillis(data[i].start_date_active);
        data[i].start_date = this._formatService.formatDate(data[i].start_date_active);
      } else {
        data[i].start_date_millis = null;
      }
      if (data[i].end_date_active !== null) {
        data[i].end_date_millis = this._formatService.dateInMillis(data[i].end_date_active);
        data[i].end_date = this._formatService.formatDate(data[i].end_date_active);
      } else {
        data[i].end_date_millis = null;
      }
    }
    this.currentPage = 1;
    this.reportData = this._orderBy.transform(data, this.predicate, this.desc);
    this.chartOfAccounts = this.reportData.slice(this.currentPage - 1, this.pageSize);
    this.showSpinner = false;
  }

  // Load more quotes when the page is scrolled down
  loadMore() {
    let endIndex, i, page, startIndex, tempData;
    try {
      page = this.currentPage + 1;
      startIndex = (page - 1) * this.pageSize;
      endIndex = page * this.pageSize;
      this.currentPage = page;
      if (this.reportData) {
        tempData = this.reportData.slice(startIndex, endIndex);
        for (i = 0; i < tempData.length; i++) {
          this.chartOfAccounts.push(tempData[i]);
        }
      }
    } catch (e) {
      this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
    }
  }

  loadReport(): void {
    const endPoint = '/supplier/chart/accounts/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.formatData(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  // Table sorting
  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
    }
    if (this.searchQuery && this.searchQuery.length > 0) {
      this.chartOfAccounts = this._orderBy.transform(this.chartOfAccounts, this.predicate, this.desc);
    } else {
      this.reportData = this._orderBy.transform(this.reportData, this.predicate, this.desc);
      this.currentPage = 1;
      this.chartOfAccounts = this.reportData.slice(this.currentPage - 1, this.pageSize);
    }
  }

}
