import {
  Component, Injector, OnInit, OnDestroy
} from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { FilterPipe } from '../../globals/filter.pipe';
import { APIError } from '../../globals/api.error';

@Component({
  selector: 'app-coupons-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [OrderByPipe],
})
export class CouponSummaryComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _filter: FilterPipe = this.injector.get(FilterPipe);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  addCreditNote: any;
  allCoupons: any[];
  checkedCount: number;
  coupons: any[];
  couponCode: any;
  couponProducts: any;
  couponStatus: any;
  creditNoteDetails: any[];
  currentPage: number;
  custAccountId: number;
  desc: boolean;
  document: any;
  documents: any;
  errorCoupon: boolean;
  errorCouponMsg: any;
  fileDialog: boolean;
  focusCouponCode: boolean;
  focusCreditNote: boolean;
  format: any;
  pageDim: boolean;
  pageSize: number;
  parseCoupons: any[];
  predicate: string;
  previousCustId: number;
  roles: any;
  searchFrom: any;
  searchTo: any;
  searchQuery: any;
  selectedCoupon: any;
  showAdvanced: boolean;
  showCreditNoteDialog: boolean;
  showDialog: boolean;
  showDocs: boolean;
  showSpinner: boolean;
  status: any;
  subOrgChange: Subscription;
  toggleFilter: (e?) => void;
  user: any;

  constructor(private injector: Injector) {
    this._window = window;

    this.addCreditNote = {};
    this.allCoupons = [];
    this.checkedCount = 0;
    this.coupons = [];
    this.couponCode = null;
    this.couponStatus = 'P';
    this.creditNoteDetails = [];
    this.currentPage = 1;
    this.custAccountId = null;
    this.desc = true;
    this.document = null;
    this.documents = null;
    this.errorCoupon = false;
    this.errorCouponMsg = null;
    this.fileDialog = false;
    this.focusCouponCode = true;
    this.focusCreditNote = true;
    this.format = '';
    this.pageDim = false;
    this.pageSize = this._appService.pageSize;
    this.parseCoupons = [];
    this.predicate = 'coupon_id';
    this.previousCustId = null;
    this.roles = this._dataService.roles;
    this.searchFrom = '';
    this.searchTo = '';
    this.searchQuery = '';
    this.selectedCoupon = null;
    this.showAdvanced = false;
    this.showCreditNoteDialog = false;
    this.showDialog = false;
    this.showSpinner = false;
    this.status = [
      {
        label: 'All',
        value: 'ALL',
      },
      {
        label: 'Pending',
        value: 'P',
      },
      {
        label: 'Submitted for Approval',
        value: 'NA',
      },
      {
        label: 'Approved',
        value: 'ACN',
      },
      {
        label: 'Rejected',
        value: 'R',
      },
      {
        label: 'Waiting for Credit Note',
        value: 'WCN',
      },
    ];
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
  }

  ngOnInit(): void {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.applyCouponFilters();
        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.allCoupons = [];
          this.applyFilter(false);
        });
      }
    });

    this.couponProducts = [
      {
        product:
          'HQS NATURAL CHAT - THON DE ATLANTIQUE AU BOUILLON 24x70gr',
        quantity: 0,
        type: 'cat',
      },
      {
        product: 'DAILY CHAT - THON 24x70gr',
        quantity: 0,
        type: 'cat',
      },
      {
        product:
          'DAILY COMPLETE CHAT - DÎNER DE THON EN BOUILLON 24x70gr',
        quantity: 0,
        type: 'cat',
      },
      {
        product:
          'HQS COMPLETE CHAT - SAUMON ET POMME EN SAUCE 24x70gr',
        quantity: 0,
        type: 'cat',
      },
      {
        product:
          'HQS LA CUCINA POCHETTE CHAT - THON ET PAPAYE EN SAUCE 24x55grr',
        quantity: 0,
        type: 'cat',
      },
      {
        product:
          'HQS NATURAL CHIEN - ENTRÉE, FILET DE POULET 12x280gr',
        quantity: 0,
        type: 'dog',
      },
      {
        product:
          'HQS COMPLETE CHIEN - RAGOÛT DE THON AVEC HARICOTS VERTS ET PATATES 24x156gr',
        quantity: 0,
        type: 'dog',
      },
      {
        product:
          'LITIÈRE AGGLOMÉRANTE DE FIBRE VÉGÉTALE, CONTRÔLE DES ODEURS',
        quantity: 0,
        type: 'dog',
      },
      {
        product:
          'HQS GÂTERIES POUR CHIEN, CONFISERIE POMME & YOGOURT 54gr',
        quantity: 0,
        type: 'dog',
      },
      {
        product: 'HQS GÂTERIES POUR CHIEN, BISCUITS CAMOMILLE 60gr',
        quantity: 0,
        type: 'dog',
      },
      {
        product: 'CAT LITTER 2.27Kg',
        quantity: 1,
        disabled: true,
        type: 'cat',
      },
    ];
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addDocument(): void {
    if (!this.documents) {
      this.documents = [];
    }
    this.documents.push(this.document);
    (document.getElementById('coupon-upload') as HTMLFormElement).value = null;
  }

  applyCouponFilters(): void {
    if (this._cacheService.couponsFilters) {
      this.predicate = this._cacheService.couponsFilters.predicate;
      this.desc = this._cacheService.couponsFilters.desc;
      this.couponStatus = this._cacheService.couponsFilters.couponStatus;
      this.searchQuery = this._cacheService.couponsFilters.search;
      this.parseCoupons = this._cacheService.getCouponSummaryDetails();
      this.searchData();
      this.applyFilter(false);
    } else {
      this.toggleFilter();
    }
  }

  applyFilter(hideFilter = true): void {
    this.checkedCount = 0;
    this.custAccountId = null;
    this.previousCustId = null;
    this.creditNoteDetails = [];
    this.loadCoupons(!hideFilter);
    if (hideFilter) {
      this.toggleFilter();
    }
  }

  closeCreditNoteDialog(): void {
    this.showCreditNoteDialog = false;
    this.focusCreditNote = true;
    this.addCreditNote = { link_status_flag: 'N', credit_note_id: '' };
  }

  closeDialog(): void {
    this.focusCouponCode = true;
    this.couponCode = null;
    this.errorCoupon = false;
    this.errorCouponMsg = null;
    this.showDialog = false;
  }

  createCreditNote(): void {
    let customerId = null,
      coupons = [],
      endPoint = '/donation/creditnote/create/',
      req: any;
    if (
      this.addCreditNote.link_status_flag === 'Y' &&
      !this.addCreditNote.credit_note_id
    ) {
      this.focusCreditNote = false;
      return;
    }
    for (let i = 0; i < this.coupons.length; i++) {
      if (this.coupons[i].checked) {
        customerId = this.coupons[i].shop_id;
        coupons.push({
          coupon_code: this.coupons[i].coupon_code,
          cn_status: this.coupons[i].cn_status_flag,
        });
      }
    }

    if (!customerId) {
      return;
    }

    req = {
      date: this._appService.today(0),
      user_id: this.user.user_id,
      cust_id: customerId,
      coupons,
      user_description: this.user.user_description,
    };
    if (this.addCreditNote.link_status_flag === 'Y') {
      req.credit_note_id = this.addCreditNote.credit_note_id;
    }
    this.pageDim = true;
    this.showCreditNoteDialog = false;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: createCreditNote()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: data.status, msg: data.msg });
      } else if (data.status === 0) {
        this.checkedCount = 0;
        this.loadCoupons(true);
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  downloadFile(attachment): void {
    const blob = this._formatService.base64ToBlob(
      attachment.file_data,
      attachment.file_type
    );
    const url = this._window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    document.body.appendChild(a);
    a.style.display = 'none';
    a.href = url;
    a.download = attachment.file_name;
    a.click();
  }

  editCreditNote(coupon): void {
    if (coupon.cn_status_flag !== 'DRAFT') {
      this._appService.editCredit = true;
      this._appService.editCreditHeader = coupon.credit_note_id;
    } else {
      this._appService.copyCredit = true;
      this._appService.copyCreditHeader = coupon.credit_note_id;
    }
    this._appService.editCreditStatus = coupon.cn_status_flag;
    this._router.navigate(['creditnotes/create']);
  }

  exportData(): void {
    let data = this.coupons,
      tableData: any = {},
      tmpData = [],
      i,
      tmpObj,
      status;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj['Coupon Code'] = { data: data[i].coupon_code };
      tmpObj.Adopter = { data: data[i].adopter_name };
      tmpObj['Pet Type'] = { data: data[i].pet_type };
      tmpObj['Shop Name'] = { data: data[i].shop_name };
      tmpObj['Shop Address'] = { data: data[i].shop_address };
      tmpObj['Creation Date'] = { data: data[i].f_creation_date };
      tmpObj['Expiry Date'] = { data: data[i].f_expiration_date };
      if (data[i].approved === 'A') {
        status = 'Approved';
      } else if (data[i].approved === 'R') {
        status = 'Rejected';
      } else if (
        (data[i].approved === 'N' || data[i].approved === null) &&
        data[i].attachments_count > 0
      ) {
        status = 'Submitted for Approval';
      } else {
        status = 'Pending';
      }
      tmpObj.Status = { data: status };
      if (!this.roles.isB2b) {
        tmpObj['Credit Note #'] = { data: data[i].credit_note_id || '' };
        tmpObj['Credit Note Status'] = {
          data: CouponSummaryComponent.findStatus(data[i].cn_status_flag),
        };
      }
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Coupons', tableData, 'export-data');
  }

  findCouponStatus(couponDetails): string {
    let newStatus = '';
    if (couponDetails.attachments_count) {
      if (!couponDetails.approved && !couponDetails.cn_status) {
        newStatus = 'SUBMITTED FOR APPROVAL';
      } else if (
        (couponDetails.approved === 'A' && !this.roles.isB2b) ||
        (couponDetails.approved === 'A' &&
          !couponDetails.cn_status &&
          this.roles.isB2b)
      ) {
        newStatus = 'APPROVED';
      } else if (
        couponDetails.approved === 'A' &&
        couponDetails.cn_status &&
        this.roles.isB2b
      ) {
        newStatus = 'CREDIT NOTE CREATED';
      } else if (couponDetails.approved === 'R') {
        newStatus = 'REJECTED';
      }
    } else {
      newStatus = 'REQUEST CREDIT';
    }
    return newStatus;
  }

  static findStatus(status): string {
    let newStatus = null;
    switch (status) {
      case 'DRAFT':
        newStatus = 'Draft';
        break;
      case 'PENDING_APPROVAL':
        newStatus = 'Pending Approval';
        break;
      case 'CANCELLED':
        newStatus = 'Cancelled';
        break;
      case 'COMPLETE':
        newStatus = 'Complete';
        break;
      case 'NOT_APPROVED':
        newStatus = 'Not Approved';
        break;
      case 'APPROVED_PEND_COMP':
        newStatus = 'Approved Pending Completion';
        break;
      default:
        break;
    }
    return newStatus;
  }

  static getCountryCodeForOrg(orgId): string {
    if (orgId === 82) return 'IT';
    if (orgId === 83) return 'DE';
    if (orgId === 84) return 'CH';
    if (orgId === 101) return 'FR';
    if (orgId === 121) return 'UK';
    if (orgId === 141) return 'CA';
    if (orgId === 181) return 'NL,BE';
    if (orgId === 202) return 'US';
    return '';
  }

  getCouponProductsQtyTotal(): number {
    if (this.selectedCoupon) {
      return this.couponProducts.filter((prod) => prod.type === this.selectedCoupon.pet_type).reduce(
        (sum, product) => sum + product.quantity,
        0
      );
    }
     return this.couponProducts.reduce((sum, product) => sum + product.quantity, 0);
  }

  loadAttachments(coupon, doc): void {
    let endPoint = '/donation/coupon/documents/',
      req: any = {};
    req.req_type = doc ? 'DOWNLOAD' : 'GET';
    req.coupon_code = coupon ? coupon.coupon_code : '';
    req.doc_id = doc ? doc.attachment_id : '';
    if (coupon) {
      this.selectedCoupon = coupon;
    }

    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadAttachments()',
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (coupon) {
        for (let i = 0; i < data.length; i++) {
          data[i].filetype = data[i].file_type;
          data[i].filename = data[i].file_name;
        }
        this.documents = data;
        this.showDocs = true;
        this.fileDialog = true;
      } else {
        doc.file_data = data.result[0].file_data;
        this.downloadFile(doc);
      }
    });
  }

  loadCoupons(noSpinner?): void {
    let endPoint = '/donation/coupons/';
    const country = CouponSummaryComponent.getCountryCodeForOrg(
      this._cacheService.getOrgId()
    );
    if (this.roles.isB2b) {
      endPoint += `${this.user.cust_acc_id}/`;
    }
    endPoint += `?country=${country}&status=${this.couponStatus}`;
    if (!noSpinner) {
      this.pageDim = true;
    }
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error: loadCoupons()',
          });
        } else {
          for (let i = 0; i < data.length; i++) {
            data[i].f_creation_date = this._formatService.formatDate(
              data[i].creation_date
            );
            data[i].f_expiration_date = this._formatService.formatDate(
              data[i].expiry_date
            );

            data[i].creation_date_millis = this._formatService.dateInMillis(
              data[i].creation_date
            );
            data[i].expiration_date_millis = this._formatService.dateInMillis(
              data[i].expiry_date
            );
            data[i].cn_status_flag = data[i].cn_status_flag || null;
            data[i].f_cn_status = CouponSummaryComponent.findStatus(
              data[i].cn_status_flag
            );
            data[i].coupon_status = this.findCouponStatus(data[i]);
          }
          this.allCoupons = this._orderBy.transform(
            data,
            'creation_date_millis',
            this.desc
          );
          this.parseCouponDetails();
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadCreditNoteIds(customerId) {
    let endPoint = `/creditNote/customer/${customerId}/`,
      creditRequestIds;
    if (!customerId) {
      this.pageDim = false;
      return;
    }
    return new Promise((resolve) => {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        this.pageDim = false;
        try {
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: 'Server Error: loadCreditNoteIds()',
            });
          } else if (data.status === 1) {
            this._appService.notify({ status: data.status, msg: data.msg });
          } else {
            if (data.result.length) {
              creditRequestIds = this.coupons.map((coupon) => {
                if (coupon.shop_id === parseInt(customerId)) {
                  return parseInt(coupon.credit_note_id);
                }
              });
              this.creditNoteDetails = data.result.filter((cnrequest) => {
                return creditRequestIds.indexOf(cnrequest.request_id) === -1;
              });

              this.creditNoteDetails.forEach((cnrequest) => {
                cnrequest.f_date_in_millis = this._formatService.dateInMillis(
                  cnrequest.requested_date
                );
              });

              this._orderBy.transform(
                this.creditNoteDetails,
                'f_date_in_millis',
                true
              );
            }
          }
          this.previousCustId = this.custAccountId;
          resolve(data);
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>',
          });
        }
      });
    });
  }

  loadMore(): void {
    try {
      const page = this.currentPage + 1;
      let tempData;
      const startIndex = (page - 1) * this.pageSize;
      const endIndex = page * this.pageSize;
      this.currentPage = page;
      if (this.parseCoupons) {
        tempData = this.parseCoupons.slice(startIndex, endIndex);
        for (let i = 0; i < tempData.length; i++) {
          this.coupons.push(tempData[i]);
        }
      }
    } catch (e) {
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>',
      });
    }
  }

  onCheckBoxSelection(c): boolean {
    return !(
      ((c.approved === 'A' && c.cn_status !== 'C') ||
        (c.cn_status === 'C' && c.cn_status_flag === 'CANCELLED')) &&
      !c.disabled &&
      !this.roles.isB2b
    );
  }

  onLineSelection(): void {
    let couponAddress;
    this.checkedCount = 0;
    this.custAccountId = null;
    for (let i = 0; i < this.coupons.length; i++) {
      if (this.coupons[i].checked) {
        if (!this.custAccountId) {
          this.custAccountId = this.coupons[i].shop_id;
          couponAddress = this.coupons[i].shop_address.replace(/\s/g, '');
        }
        this.checkedCount++;
      }
    }

    for (let i = 0; i < this.coupons.length; i++) {
      // checking if the customer account id is not equal to shop id  or the customer id is same and address is different
      this.coupons[i].disabled =
        this.custAccountId &&
        (this.coupons[i].shop_id !== this.custAccountId ||
          (this.coupons[i].shop_id === this.custAccountId &&
            this.coupons[i].shop_address.replace(/\s/g, '') !== couponAddress));
    }
  }

  parseCouponDetails(): void {
    this.parseCoupons = [];
    if (this.couponStatus === 'ALL') {
      this.parseCoupons = [...this.allCoupons];
    } else if (this.couponStatus === 'ACN') {
      this.parseCoupons = this.allCoupons.filter(
        (coupon) => coupon.approved === 'A'
      );
    } else if (this.couponStatus === 'R') {
      this.parseCoupons = this.allCoupons.filter(
        (coupon) => coupon.approved === 'R'
      );
    } else if (this.couponStatus === 'NA') {
      this.parseCoupons = this.allCoupons.filter(
        (coupon) =>
          coupon.attachments_count > 0 &&
          (coupon.approved === 'N' || coupon.approved === null)
      );
    } else if (this.couponStatus === 'WCN') {
      this.parseCoupons = this.allCoupons.filter(
        (coupon) => coupon.approved === 'A' && !coupon.cn_status
      );
    } else {
      this.parseCoupons = this.allCoupons.filter(
        (coupon) =>
          coupon.attachments_count === 0 &&
          (coupon.approved === 'N' || coupon.approved === null)
      );
    }
    this.currentPage = 1;
    this.searchData();
  }

  searchData(): void {
    const search = this.searchQuery;
    let tmp_data;
    this.currentPage = 1;
    if (search) {
      tmp_data = this._filter.transform(this.parseCoupons, search, '');
      tmp_data = this._orderBy.transform(tmp_data, this.predicate, this.desc);
      this.coupons = tmp_data.slice(this.currentPage - 1, this.pageSize);
    } else {
      this.parseCoupons = this._orderBy.transform(
        this.parseCoupons,
        this.predicate,
        this.desc
      );
      this.coupons = this.parseCoupons.slice(
        this.currentPage - 1,
        this.pageSize
      );
    }
    this._cacheService.couponsFilters = {
      predicate: this.predicate,
      desc: this.desc,
      couponStatus: this.couponStatus,
      search: this.searchQuery,
    };
    this._cacheService.setCouponsSummaryDetails(this.parseCoupons);
  }

  async showCreditNote(): Promise<void> {
    this.pageDim = true;
    // if (this.previousCustId !== this.custAccountId) {
    this.creditNoteDetails = [];
    await this.loadCreditNoteIds(this.custAccountId);
    // }
    if (this.creditNoteDetails.length) {
      this.addCreditNote = { link_status_flag: 'N', credit_note_id: '' };
      this.showCreditNoteDialog = true;
      this.pageDim = false;
    } else {
      this.createCreditNote();
    }
  }

  showFileDialog(coupon): void {
    this.couponProducts.forEach(element => {
      if (!element.disabled) {
        element.quantity = 0;
      }
    });
    this.fileDialog = true;
    this.documents = null;
    this.selectedCoupon = coupon;
    this.showDocs = false;
  }

  sort(key): void {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = true;
    }
    this.searchData();
  }

  submitCoupon(): void {
    if (this._cacheService.getOrgId() !== 141 && !this.documents) {
      return;
    }

    let endPoint = '/donation/coupon/documents/',
      req: any = {},
      i,
      attachments = [],
      index = this.coupons.indexOf(this.selectedCoupon);
    this.fileDialog = false;
    if (index !== -1) {
      this.coupons[index].attachments_count = this.documents
        ? this.documents.length
        : 0;
    }

    if (this.documents) {
      for (i = 0; i < this.documents.length; i++) {
        attachments.push({
          file_type: this.documents[i].filetype,
          file_name: this.documents[i].filename,
          file_data: this.documents[i].base64,
          coupon_code: this.coupons[index].coupon_code,
          doc_type: 'COUPON_VALIDATION',
          user_id: this.user.user_id,
        });
      }
    }

    this.documents = null;
    this.pageDim = true;

    req.attachments = attachments;
    req.shop_name = this.coupons[index].shop_name;
    req.shop_address = this.coupons[index].shop_address;
    req.products = this.couponProducts;
    req.quantity = this.getCouponProductsQtyTotal();
    req.coupon_code = this.coupons[index].coupon_code;
    req.org_id = this._cacheService.getOrgId();
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: submitCoupon()',
        });
      } else {
        if (data.status) {
          const status = data.status === 'OK' ? 0 : 1;
          this._appService.notify({ status, msg: data.msg });
          if (data.status === 'OK') {
            this.loadCoupons(true);
          }
        } else {
          this._appService.notify({
            status: 1,
            msg: 'Unknown Error! Please try again',
          });
        }
      }
    });
  }

  updateStatus(status): void {
    if (!this.selectedCoupon) {
      this.fileDialog = false;
      return;
    }

    let endPoint = '/donation/coupon/status/',
      req: any = {};
    req.status = status;
    req.coupon_code = this.selectedCoupon.coupon_code;
    req.user = this.user.user_description;
    req.cust_account_id = this.selectedCoupon.shop_id;
    this.fileDialog = false;
    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: updateStatus()',
        });
      } else if (data.status) {
        this._appService.notify({
          status: data.status === 'OK' ? 0 : 1,
          msg: data.msg,
        });
        if (data.status === 'OK') {
          this.loadCoupons(true);
        }
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  validateCoupon(): void {
    if (!this.couponCode) {
      this.focusCouponCode = false;
      return;
    }
    const endPoint = '/donation/coupon/validate/';
    const req = {
      coupon_code: this.couponCode,
      shop_id: this.user.cust_acc_id,
    };

    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: validateCoupon()',
        });
      } else if (data.status) {
        if (data.status === 'ERROR' || data.status === 1) {
          this.focusCouponCode = false;
          this.errorCoupon = true;
          this.errorCouponMsg = data.msg;
        } else {
          this.loadCoupons(true);
          this._appService.notify({ status: 0, msg: data.msg });
          this.closeDialog();
        }
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  validateCouponProductsQty(): boolean {
    if (this.selectedCoupon && this._cacheService.getOrgId() === 141) {
      const quantities = this.couponProducts
        .filter((prod) => prod.type === this.selectedCoupon.pet_type)
        .reduce((sum, product) => sum + product.quantity, 0);
      return (
        !(
          this.selectedCoupon.pet_type === 'cat' &&
          quantities > 1 &&
          quantities <= 49
        ) ||
        (this.selectedCoupon.pet_type === 'dog' &&
          quantities > 1 &&
          quantities <= 24)
      );
    }
    return false;
  }
}
