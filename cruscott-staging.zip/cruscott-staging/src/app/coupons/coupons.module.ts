import { NgModule } from '@angular/core';

import { CouponsRoutingModule } from './coupons-routing.module';
import { ShareModule } from '../share/share.module';
import { CouponSummaryComponent } from './summary/summary.component';

@NgModule({
  declarations: [
    CouponSummaryComponent
  ],
  imports: [
    CouponsRoutingModule,
    ShareModule
  ]
})
export class CouponsModule { }
