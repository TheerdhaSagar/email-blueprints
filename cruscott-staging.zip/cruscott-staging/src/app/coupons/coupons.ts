export interface Coupons {
  adopter_name: string;
  adoption_id: number;
  approved: string;
  association_id: string;
  association_name: string;
  attachments_count: number;
  cn_status?: string;
  cn_status_flag?: string;
  contact_by?: string;
  contact_customer: string;
  country: string;
  coupon_code: string;
  created_by: number;
  creation_date: string;
  credit_note_id: string;
  expiry_date: string;
  language: string;
  pet_size: string;
  pet_type: string;
  shop_address: string;
  shop_id: number;
  shop_name: string;
  user_name: string;
}
