import { TestBed } from '@angular/core/testing';

import { ActivityPlannerService } from './activity-planner.service';

describe('ActivityPlannerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ActivityPlannerService = TestBed.get(ActivityPlannerService);
    expect(service).toBeTruthy();
  });
});
