import {
  Component,
  Injector,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { Location, TitleCasePipe } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import jQuery from 'jquery';
import { TranslateService } from '@ngx-translate/core';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { CommonService } from '../globals/common.service';
import { DataService } from '../globals/data.service';
import { FormatService } from '../globals/format.service';
import { HttpService } from '../globals/http.service';
import { OrderByPipe } from '../globals/order-by.pipe';
import { Settings } from '../globals/tabletemplate/models/settings';
import { TabletemplateComponent } from '../globals/tabletemplate/tabletemplate.component';
import { ExpenseService } from '../globals/expense.service';
import { EditorSettings } from '../globals/editor-settings';
import { ActivityPlannerService } from './activity-planner.service';
import { APIError } from '../globals/api.error';
import { ActivityPlannerUser } from './manager-reportee.model';

declare let FooPicker;
declare let tinyMCE;
declare let tinymce;

@Component({
  selector: 'app-activity-planner',
  templateUrl: './activity-planner.component.html',
  styleUrls: ['./activity-planner.component.scss'],
  providers: [OrderByPipe],
})
export class ActivityPlannerComponent implements OnInit, OnDestroy {
  @ViewChild(TabletemplateComponent) child: TabletemplateComponent;

  private _activityPlannerService = this.injector.get(ActivityPlannerService);
  private _appService = this.injector.get(AppService);
  private _cacheService = this.injector.get(CacheService);
  private _commonService = this.injector.get(CommonService);
  private _dataService = this.injector.get(DataService);
  private _expenseService = this.injector.get(ExpenseService);
  private _formatService = this.injector.get(FormatService);
  private _httpService = this.injector.get(HttpService);
  private _location = this.injector.get(Location);
  private _orderBy = this.injector.get(OrderByPipe);
  private _router = this.injector.get(Router);
  private _sanitizer = this.injector.get(DomSanitizer);
  private _translate = this.injector.get(TranslateService);
  private _titleCase = this.injector.get(TitleCasePipe);
  private _window: any;

  activityDeleteDetails: any;
  activeEditorId: string;
  addDate: string;
  addTaskToTrp: boolean;
  allExpenses: any[];
  allGoals: any[];
  allTasks: any[];
  allTrips: any[];
  allUsers: any[];
  appendHTML: (elementId: string, htmlToBeAppended: string) => void;
  approvalStatus: string;
  approvalStatusList: any[];
  approvalStatusListFiltered: any[];
  approveEnableBtn: boolean;
  approverComments: string;
  cardView: boolean;
  cards: any[];
  charCount = 0;
  chatComments: any[];
  chatThreads: any[];
  chatView: boolean;
  collaborators: any[];
  commentToDelete: any;
  completedTaskCount: number;
  creatingTaskInTrip: boolean;
  currentMonth: any;
  currentWeekNum: number;
  currencies: any;
  dateFormat: any;
  defaultCurrency: any = null;
  deletedDestinations: any[] = [];
  defaultUpdateText: string;
  deleteActivityDialog: boolean;
  deleteCollaborators: number[];
  desc: boolean;
  directReportees: any[];
  disableTaskFields: boolean;
  displayFromDate: any;
  displayMonth: any;
  displayToDate: any;
  displayWeek: number;
  displayYear: any;
  editAccess: boolean;
  editorFlag: Record<string, boolean>;
  editorSettings: EditorSettings;
  employeesList: any[];
  empSelected: number;
  expenseTableSettings: Settings;
  expenseView = false;
  expenses: any[];
  filteredTasks: any[];
  focusTaskEndTime = false;
  focusTripDescription = true;
  fromDate: any;
  goal: any;
  goals: any[];
  initialTripDetails: any = null;
  isOnlyGoals: boolean;
  linkTaskStatus: any;
  listView: boolean;
  loginUser: {
    default_org_id: number;
    user_id: number;
    user_description: string;
    user_name: string;
  };
  manager: any;
  managerEmpList: any;
  managersList: any;
  mapTaskMsg: string;
  maxCharacters = 5000;
  maxCharErrFlag = false;
  minimizeGoals: boolean;
  missingEventsList: {
    google_event_id: string;
    trip_description: string;
    start_date: string;
    end_date: string;
    checkFlag: boolean;
  }[] = [];
  newChatComment: string;
  newCollaborators: number[];
  newComment: string;
  newGoalComment: string;
  newTripComment: string;
  numberFormat: any;
  oldGoal: any;
  oldTaskDetails: any;
  orgId: any;
  otherReportees: any[];
  otherTransportList: any;
  otherUserBgColor: string;
  predicate: string;
  previousTaskDate: string;
  primaryTransportList = ['Plane', 'KM Allowance', 'Car', 'Train', 'Other'];
  regexTags = /(<([^>]+)>)/gi;
  relatedTasks: any[];
  reportView: boolean;
  reportViewPeriod: string;
  roles: any;
  searchTerm: string;
  selectedChat: any;
  selectedGoal: number;
  shortMonths: string[];
  showActivityLog: boolean;
  showAddGoal: boolean;
  showAddTask: boolean;
  showAddTrip: boolean;
  showCollaboratedProjects: boolean;
  showGoalDesc: boolean;
  showGoalError: boolean;
  showGoalFromProject: boolean;
  showGoalLink: boolean;
  showLinkedProjects: boolean;
  showMissingEvents = false;
  showNewComment: boolean;
  showNewTripComment: boolean;
  showReplyOption: boolean;
  showSearch: boolean;
  showSpinner: boolean;
  showSubTaskDate: boolean;
  showSubTaskDesc: boolean;
  showSubTaskDetails: boolean;
  showSubTasks: boolean;
  showTags: boolean;
  showTaskCollaborators: boolean;
  showTaskDates: boolean;
  showTaskMap: boolean;
  showTaskGoals: boolean;
  showTaskResults: boolean;
  showViewScreen: boolean;
  status: any;
  statusList: any[];
  subject: any;
  subTask: any;
  taskAttachment: any;
  taskApprovalStatusList: any[];
  taskDetails: any;
  taskStatusSelected: string;
  taskTags: any[];
  taskTagList: any[];
  tasks: any[];
  tasksLinkedToTrip: any[];
  timeList: any[];
  toDate: any;
  today: any;
  toggleAction: string;
  trip: any;
  tripAttachment: any = null;
  tripDeleteAttachments: any[] = [];
  tripErrorMessage: string;
  tripTableSettings: Settings = null;
  tripView = false;
  unsavedActivityType: string;
  unsavedDialog = false;
  user: any;
  userId: any;
  updateText: string;
  viewGoalCard = true;
  viewSelected: string;
  viewsList: string[];
  weekDay: string[];
  weekEndDate: any;
  weekNo: any;
  weekStartDate: any;

  constructor(private injector: Injector) {
    this._window = window;

    this.activityDeleteDetails = null;
    this.addDate = null;
    this.timeList = [];
    this.addTaskToTrp = false;
    this.allExpenses = [];
    this.allGoals = [];
    this.allTasks = [];
    this.allTrips = [];
    this.allUsers = [];
    this.appendHTML = ActivityPlannerComponent.appendHTML;
    this.approvalStatus = 'All';
    this.approvalStatusList = [
      {
        id: 'Drafts',
        label: 'Draft',
        isChecked: true,
      },
      {
        id: 'Processing',
        label: 'Processing',
        isChecked: true,
      },
      {
        id: 'Approved',
        label: 'Approved',
        isChecked: true,
      },
      {
        id: 'Rejected',
        label: 'Rejected',
        isChecked: true,
      },
    ];
    this.approvalStatusListFiltered = [];
    this.approveEnableBtn = false;
    this.approverComments = '';
    this.cardView = false;
    this.cards = [];
    this.chatComments = [];
    this.chatThreads = [];
    this.chatView = false;
    this.collaborators = [];
    this.commentToDelete = null;
    this.completedTaskCount = 0;
    this.creatingTaskInTrip = false;
    this.currentMonth = null;
    this.currentWeekNum = null;
    this.dateFormat = null;
    this.defaultUpdateText = this.initDefaultText();
    this.deleteActivityDialog = false;
    this.deleteCollaborators = [];
    this.desc = true;
    this.directReportees = [];
    this.disableTaskFields = false;
    this.displayFromDate = null;
    this.displayToDate = null;
    this.displayWeek = null;
    this.editAccess = true;
    this.editorFlag = {
      'task-update': false,
      'task-comment': false,
      'goal-comment-editor': false,
    };
    this.employeesList = [];
    this.empSelected = null;
    this.expenseTableSettings = null;
    this.expenses = [];
    this.filteredTasks = [];
    this.fromDate = null;
    this.goal = {};
    this.goals = [];
    this.linkTaskStatus = null;
    this.listView = false;
    this.manager = null;
    this.managerEmpList = null;
    this.managersList = [];
    this.mapTaskMsg = '';
    this.minimizeGoals = false;
    this.newChatComment = '';
    this.newCollaborators = [];
    this.newComment = '';
    this.newGoalComment = '';
    this.newTripComment = '';
    this.numberFormat = null;
    this.oldGoal = {};
    this.oldTaskDetails = {};
    this.orgId = null;
    this.otherReportees = [];
    this.otherUserBgColor = '#0f778e';
    this.predicate = 'startDateInMillis';
    this.previousTaskDate = null;
    this.relatedTasks = [];
    this.reportView = true;
    this.reportViewPeriod = 'Week';
    this.roles = this._dataService.roles;
    this.searchTerm = '';
    this.selectedChat = { id: null, type: '' };
    this.selectedGoal = null;
    this.shortMonths = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    this.showActivityLog = false;
    this.showAddGoal = false;
    this.showAddTask = false;
    this.showAddTrip = false;
    this.showCollaboratedProjects = false;
    this.showGoalDesc = false;
    this.showGoalError = false;
    this.showGoalFromProject = false;
    this.showGoalLink = false;
    this.showLinkedProjects = false;
    this.showNewComment = false;
    this.showNewTripComment = false;
    this.showReplyOption = true;
    this.showSearch = false;
    this.showSpinner = true;
    this.showSubTaskDate = false;
    this.showSubTaskDesc = true;
    this.showSubTaskDetails = false;
    this.showSubTasks = false;
    this.showTaskCollaborators = false;
    this.showTaskDates = false;
    this.showTaskMap = false;
    this.showTaskGoals = true;
    this.showTaskResults = false;
    this.showViewScreen = true;
    this.status = null;
    this.statusList = [
      { key: 'Drafts', type: 'draft', display: 'DRAFTS' },
      { key: 'Processing', type: 'pending', display: 'PROCESSING' },
      { key: 'Approved', type: 'approved', display: 'APPROVED' },
      { key: 'Rejected', type: 'rejected', display: 'REJECTED' },
    ];
    this.subTask = {};
    this.taskApprovalStatusList = [
      {
        id: 'I',
        label: 'In Progress',
        cssClass: 'bg-orange',
        color: 'orange',
        label_key: 'ACT_INPROGRESS',
      },
      {
        id: 'C',
        label: 'Completed',
        cssClass: 'bg-green',
        color: 'green',
        label_key: 'ACT_COMPLETED',
      },
      {
        id: 'CO',
        label: 'Collaborated',
        cssClass: 'bg-dark-blue',
        color: this.otherUserBgColor,
        label_key: 'ACT_COLLABORATED',
      },
      {
        id: 'AR',
        label: 'Archived',
        color: 'gray',
        label_key: 'ACT_ARCHIVED',
      },
    ];
    this.taskAttachment = null;
    this.taskDetails = {};
    this.taskStatusSelected = 'I';
    this.taskTags = [];
    this.taskTagList = [];
    this.tasks = [];
    this.tasksLinkedToTrip = [];
    this.toDate = null;
    this.today = new Date();
    this.toggleAction = 'U';
    this.updateText = '';
    this.user = null;
    this.userId = null;
    this.viewSelected = 'Week';
    this.viewsList = ['Week', 'Month', 'Year'];
    this.weekDay = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
    ];
    this.weekNo = null;
  }

  // Calculate time difference between End date and Start date
  static calculateDuration(endDate, startDate) {
    const result = Math.abs(endDate - startDate) / 1000;
    const days = Math.floor(result / 86400) + 1;
    const hours = Math.floor(result / 3600) % 24;
    const minutes = Math.floor(result / 60) % 60;
    let durationText;
    if (days > 1) {
      durationText = days + ' days';
    } else if (hours > 0 && minutes > 0) {
      durationText = hours + ' hrs' + ' ' + minutes + ' min';
    } else if (hours > 0) {
      durationText = hours + ' hrs';
    } else {
      durationText = minutes + ' min';
    }

    return [durationText, result];
  }

  // Validate start time and end time
  static compareTime(startTime, endTime) {
    let valid = true;
    let endHours;
    let startHours;
    const startArray = startTime.split(':');
    if (startArray[1].includes('PM')) {
      startHours = parseInt(startArray[0], 10) + 12;
    } else {
      startHours =
        parseInt(startArray[0], 10) === 12 ? 0 : parseInt(startArray[0], 10);
    }
    startHours += parseInt(startArray[1].substr(0, 2), 10) / 60;
    const endArray = endTime.split(':');
    if (endArray[1].includes('PM')) {
      endHours = parseInt(endArray[0], 10) + 12;
    } else {
      endHours =
        parseInt(endArray[0], 10) === 12 ? 0 : parseInt(endArray[0], 10);
    }
    endHours += parseInt(endArray[1].substr(0, 2), 10) / 60;
    if (startHours >= endHours) {
      valid = false;
    }
    return valid;
  }

  ngOnInit(): void {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this.getCurrentDayDetails();

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.loadUsers();
        this.user = data;
        this.userId = this.user.user_id;
        this.empSelected = this.userId;
        this.orgId = this._cacheService.getOrgId();
        this.dateFormat = this.user.date_format || 'dd-MMM-yyyy';
        this.numberFormat = this.user.number_format || '999.999,99';
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user.organizations.forEach((organization) => {
          if (this._dataService.orgId === organization.organization_id) {
            this.defaultCurrency = organization.currency_code;
          }
        });

        this.otherTransportList = this.primaryTransportList.slice(1);
        this.expenseTableSettings = new Settings({
          headers: [
            {
              title: 'Report #',
              keyName: 'report_header_id',
              redirect: 'report_header_id',
            },
            {
              title: 'Description',
              keyName: 'description',
              styles: { width: '25%' },
            },
            {
              title: 'Activity Linked',
              keyName: 'project_name',
              redirect: 'project_id',
            },
            {
              title: 'Created On',
              keyName: 'creation_date',
              styles: { format: 'date' },
            },
            { title: 'Current Approver', keyName: 'approver' },
            {
              title: 'Amount',
              keyName: 'total',
              styles: { format: 'numberformat' },
            },
            { title: '', keyName: 'default_currency_code' },
            {
              title: 'Status',
              keyName: 'exp_status',
              styles: { 'min-width': '76px' },
            },
          ],
          sortHeader: true,
          statusList: this.statusList,
          icons: [
            {
              iconType: 'icon',
              iconStyle: 'icon-trash2',
              iconAction: 'delete',
            },
          ],
          statusKey: 'exp_status',
          predicate: 'report_header_id',
          desc: this.desc,
        });
        this.addTripSettings();
        this.setUpDOMHandlers();
        this.getTaskTags();
        this._appService.scrollTop();

        this.blurLinkedGoal = this.blurLinkedGoal.bind(this);

        // Cards should exclude Archived status
        this.taskApprovalStatusList.slice(0, 3).forEach((status) => {
          this.cards.push({
            title: status.label,
            title_key: status.label_key,
            id: status.id,
            cssClass: status.cssClass,
            color: status.color,
            activities: [],
            minimize: status.id === 'C',
            initialLoad: status.id !== 'C' && status.id !== 'CO',
          });
        });
        this.loadManagerEmpList();

        // Adding a date picker for sub task due date
        setTimeout(() => {
          (() =>
            new FooPicker({
              id: 'sub-task-due-date',
              dateFormat: this.dateFormat,
            }))();
        });
        this.editorSettings = {
          menubar: false,
          branding: false,
          statusbar: false,
          placeholder: '',
          forced_root_block: 'div',
          force_br_newlines: true,
          force_p_newlines: false,
          height: 140,
          max_height: 400,
          autoresize_bottom_margin: 20,
          plugins: 'autoresize lists paste',
          block_formats:
            'Paragraph=p;Header 1=h1;Header 2=h2;Header 3=h3;Header 4=h4;',
          content_style: `@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600,700');
            body { font-family: "Source Sans Pro", sans-serif; font-size: 15px; color: #4d4c4c;}`,
          toolbar:
            'formatselect | bold italic underline strikethrough forecolor | blockquote bullist numlist | ' +
            'alignleft aligncenter alignright alignjustify',
          paste_retain_style_properties: 'color font-weight font-style',
        };
      }
    });

    this.populateTimeList();
    this.loadCurrencies();
  }

  ngOnDestroy(): void {
    jQuery('body').css('overflow', 'auto');
  }

  // Add the Goal and Project descriptions in report view as HTML snippets
  // as they are outputs from a rich text editor
  addActivityDescriptionsInReport(): void {
    setTimeout(() => {
      this.goals.forEach((goal, index) => {
        const goalObj = goal;
        goalObj.description = goalObj.description
          ? this._appService.replaceAll(goal.description, '\n', '<br>')
          : '';
        // replace all the id tags in the description using the regex condition id="([^\"]*?)"
        /* Regex Explanation:
              id=" matches the characters id=" literally
              *? - Matches between zero and unlimited times, as few times as possible
              [^ \"] - Negating double quotes character
              "  - matches the character " literally  */
        goalObj.description = goalObj.description.replaceAll(
          /id="([^\"]*?)"/g,
          ''
        );
        this.appendHTML(`report-goal-${index}`, goal.description);
        goal.related_projects.forEach((project, projectIndex) => {
          const projectObj = project;
          projectObj.goals = projectObj.goals
            ? this._appService.replaceAll(project.goals, '\n', '<br>')
            : '';
          // replace all the id tags in the related proj goals using the regex condition id="([^\"]*?)"
          projectObj.goals = projectObj.goals.replaceAll(/id="([^\"]*?)"/g, '');
          this.appendHTML(
            `report-activity-${index}-${projectIndex}`,
            project.goals
          );
        });
      });
    }, 100);
  }

  // Add attachments to a trip
  addAttachment() {
    let index;
    if (
      this._appService.checkFileSize(this.tripAttachment, this.trip.attachments)
    ) {
      index = this.trip.attachments
        .map((attachment) => attachment.file_name + attachment.file_type)
        .indexOf(this.tripAttachment.filename + this.tripAttachment.filetype);
      if (index === -1) {
        this.trip.attachments.push({
          created_date: this._formatService.formatDate(
            this._appService.today(0),
            this.dateFormat
          ),
          file_name: this.tripAttachment.filename,
          file_type: this.tripAttachment.filetype,
          file_content: this.tripAttachment.base64,
          attachment_type: this.tripAttachment.filetype,
        });
      } else {
        this._appService.notify({ msg: 'File already exists', status: 1 });
      }
      this.tripAttachment = null;
    }
  }

  // Add a destination to trip
  addDest() {
    if (this.validateTripDetails()) {
      this.trip.destinations.push({
        from: '',
        focusFrom: true,
        to: '',
        focusTo: true,
        startDate: '',
        focusStartDate: true,
        endDate: '',
        focusEndDate: true,
        startTime: '09:00 AM',
        endTime: '08:00 PM',
        focusEndTime: true,
        budgetList: [
          {
            name: 'Primary Transport',
            type: this.primaryTransportList[0],
            focus: true,
            typePresent: true,
            list: this.primaryTransportList,
            required: true,
            value: { value: null, type: this.defaultCurrency },
          },
          {
            name: 'Accomodation Budget',
            focus: true,
            value: { value: null, type: this.defaultCurrency },
          },
          {
            name: 'Meals Budget',
            focus: true,
            value: { value: null, type: this.defaultCurrency },
          },
          {
            name: 'Other Transport',
            type: '',
            focus: true,
            list: this.otherTransportList,
            typePresent: true,
            value: { value: null, type: this.defaultCurrency },
          },
          {
            name: 'Other Expenses',
            focus: true,
            value: { value: null, type: this.defaultCurrency },
          },
        ],
        totalBudget: 0,
        goals: '',
        focusGoals: true,
        results: '',
        showFull: true,
        attachments: [],
      });
      this.addFooPicker(
        'dest-start-' + (this.trip.destinations.length - 1),
        'dest-end-' + (this.trip.destinations.length - 1)
      );
    } else {
      this._appService.notify({
        msg: 'Please complete the details of previous destination',
        status: 1,
      });
    }
  }

  // Add date-pickers for elements with startDate and endDate
  addFooPicker(startId, endId) {
    if (jQuery(`#foopicker-${startId}`)[0]) {
      jQuery(`#foopicker-${startId}`)[0].remove();
    }
    if (jQuery(`#foopicker-${endId}`)[0]) {
      jQuery(`#foopicker-${endId}`)[0].remove();
    }
    setTimeout(() => {
      (() =>
        new FooPicker({
          id: startId,
          dateFormat: this.dateFormat,
        }))();

      (() =>
        new FooPicker({
          id: endId,
          dateFormat: this.dateFormat,
        }))();
    });
  }

  addGoal() {
    this.showAddGoal = true;
    this.showGoalDesc = true;
    this.showLinkedProjects = false;
    this.focusField('goal-title');
    this.oldGoal = {};
    this.goal = {
      isNew: true,
      name: '',
      description: '',
      type: 'Goal',
      comments: [],
    };
  }

  addGoalFromProject() {
    this.showGoalFromProject = true;
    this.addGoal();
  }

  addNewSubTask() {
    if (!this.taskDetails.sub_tasks.some((subTask) => subTask.is_new)) {
      this.taskDetails.sub_tasks.push({
        is_new: true,
        sub_task_display_order: this.taskDetails.sub_tasks.length,
      });
    }
  }

  addTag(tag) {
    let taskIndex = this.taskTags.findIndex(
      (taskTag) => taskTag.tag_id === tag.tag_id
    );
    if (taskIndex === -1) {
      this.taskTags.push(tag);
    } else {
      this.taskTags.splice(taskIndex, 1);
    }
  }

  addTaskAttachment() {
    let endPoint = '/activityplanner/attachment/',
      reqObj = {
        attachments: [
          {
            attachment_type: this.taskAttachment.filetype,
            file_name: this.taskAttachment.filename,
            file_type: this.taskAttachment.filetype,
            file_content: this.taskAttachment.base64,
          },
        ],
        reference_id: this.taskDetails.task_id,
        reference_type: 'task',
        created_id: this.user.user_id,
      };
    this.taskDetails.comments.push({
      comment_type: 'A',
      file_name: this.taskAttachment.filename,
      comment_data: this.taskAttachment.filename,
      comment_user_name: this.getUserBadgeText(this.user.user_description),
      showReplyOption: true,
      replies: [],
      created_date: `${this._appService.today(0)} ${this.getCurrentTime()}`,
      user_details: [
        {
          user_id: this.user.user_id,
          user_description: this.user.user_description,
        },
      ],
      created_id: this.user.user_id,
      activity_id: this.taskDetails.task_id,
      activity_type: 'task',
      file_content: this.taskAttachment.base64,
      imgUrl: this.getAttachmentImgUrls(this.taskAttachment.filetype),
    });
    this.toggleActions('U');

    this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - addTaskAttachment()',
        });
      } else if (data.hasOwnProperty('status') && data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  addTaskModelOpen(status?) {
    this._appService.scrollTop();
    this.taskTags = [];
    this.collaborators = [];
    this.editAccess = true;
    this.showActivityLog = false;
    this.showTaskCollaborators = false;
    this.showTaskDates = false;
    this.showTaskResults = false;
    this.showTaskGoals = true;
    this.showSubTasks = false;
    this.showTags = false;
    this.showGoalLink = true;
    this.selectedGoal = null;
    this.showGoalError = false;
    this.taskDetails = {
      org_id: this.orgId,
      description: '',
      task_location: 'Office',
      start_date: '',
      end_date: '',
      goals: this.initDefaultText(),
      results: '',
      user_comments: '',
      approver_comments: '',
      approver_id: '',
      created_id: this.userId,
      attachments: [],
      is_trip: false,
      map_trip: {},
      is_new: true,
      showCommments: 'N',
      comments: [],
      status: status || 'I',
      employee_name: this.user.user_description,
      task_user_name: this.getUserBadgeText(this.user.user_description),
      subTasks: [],
      dateError: '',
      type: 'task',
      sub_tasks: [],
      collaborators: [],
      activityLog: [],
      goal: {},
    };
    this.disableTaskFields = true;
    this.toggleActions('U');
    this.addDate = null;
    if (this.empSelected !== this.userId) {
      this.empSelected = this.userId;
      this.loadEmpActivities();
    }
  }

  addTripSettings() {
    this.tripTableSettings = new Settings({
      headers: [
        {
          title: 'Trip #',
          keyName: 'trip_id',
          redirect: 'trip_id',
        },
        {
          title: 'Description',
          keyName: 'description',
          styles: { width: '25%' },
        },
        {
          title: 'Created On',
          keyName: 'created_date',
          styles: { format: 'date' },
        },
        {
          title: 'Start Date',
          keyName: 'start_date',
          styles: { format: 'date' },
        },
        {
          title: 'End Date',
          keyName: 'end_date',
          styles: { format: 'date' },
        },
        {
          title: 'Duration',
          keyName: 'duration',
        },
      ],
      sortHeader: true,
      icons: [
        {
          iconType: 'icon',
          iconStyle: 'icon-trash2',
          iconAction: 'delete',
        },
      ],
      predicate: 'trip_id',
      desc: this.desc,
    });
  }

  static appendHTML(elementId, htmlToBeAppended): void {
    const element = document.getElementById(elementId);
    if (element) {
      if (element.childNodes.length) {
        element.innerHTML = '';
      }
      element.insertAdjacentHTML('beforeend', htmlToBeAppended);
    }
  }

  blurGoalDescription(): void {
    this.showGoalDesc = false;
    ActivityPlannerComponent.appendHTML(
      'goal-description',
      this.goal.description
    );
  }

  blurGoalName() {
    if (this.goal.isNew && this.goal.name) {
      this.saveGoal();
    }
  }

  blurLinkedGoal() {
    setTimeout(() => {
      if (this.taskDetails.is_new && this.selectedGoal) {
        this.saveTaskDetails();
      } else if (
        !this.selectedGoal &&
        this.taskDetails.created_id === this.userId
      ) {
        this.showGoalError = true;
      }
    }, 500);
  }

  blurSubTaskDesc() {
    this.showSubTaskDesc = false;
    ActivityPlannerComponent.appendHTML(
      'sub-task-description',
      this.subTask.sub_task_description
    );
  }

  blurTaskDescription() {
    if (
      this.taskDetails.is_new ||
      this.taskDetails.description !== this.oldTaskDetails.description
    ) {
      this.saveTaskDetails();
    }
  }

  blurTaskGoals() {
    this.showTaskGoals = false;
    ActivityPlannerComponent.appendHTML('task-goals', this.taskDetails.goals);
    if (this.taskDetails.goals !== this.oldTaskDetails.goals) {
      this.saveTaskDetails();
    }
  }

  blurTaskResults() {
    this.showTaskResults = false;
    if (this.taskDetails.results !== this.oldTaskDetails.results) {
      this.saveTaskDetails();
    }
  }

  // Calculate the start-date-time and end-date-time strings for a trip based on it's destination dates
  calculateTripDateTime() {
    let startDateTime;
    let endDateTime;
    let tmpStartDate;
    let tmpEndDate;
    let tripStartDate;
    let tripEndDate;
    this.trip.destinations.forEach((destination) => {
      startDateTime = this.combineDateTime(
        destination.startDate,
        destination.startTime
      );
      endDateTime = this.combineDateTime(
        destination.endDate,
        destination.endTime
      );
      tmpStartDate = new Date(startDateTime);
      tmpEndDate = new Date(endDateTime);
      if (!tripStartDate || tmpStartDate < tripStartDate) {
        tripStartDate = tmpStartDate;
        this.trip.startDateTime = startDateTime;
      }
      if (!tripEndDate || tmpEndDate > tripEndDate) {
        tripEndDate = tmpEndDate;
        this.trip.endDateTime = endDateTime;
      }
    });
  }

  changeActivityStatus(status, taskId, closeTask?): void {
    this._activityPlannerService
      .changeProjectStatus(status, taskId, this.userId)
      .then((response) => {
        this.saveActivityLog(
          `This project was moved to ${
            this.taskApprovalStatusList.find(
              (statusObj) => statusObj.id === status
            ).label
          }`,
          taskId
        );
        if (closeTask) {
          this.showAddTask = false;
          this.cardView ? this.showCardView() : this.showReport();
          this._appService.notify({
            status: 0,
            msg: `Project moved to ${
              status === 'AR' ? 'Archive' : 'Completed'
            }`,
          });
        }
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  // next button for going to next week/month/year
  changeDateNext() {
    this.showSpinner = true;
    if (this.viewSelected === 'Week') {
      this.weekNo = this.weekNo + 1;
    } else if (this.viewSelected === 'Month') {
      this.displayYear =
        this.currentMonth === 11 ? this.displayYear + 1 : this.displayYear;
      this.currentMonth = (this.currentMonth + 1) % 12;
      this.displayMonth = this.shortMonths[this.currentMonth];
    } else {
      this.displayYear = this.displayYear + 1;
    }
    this.updateDatesForView(!this.listView, this.listView);
  }

  // previous button for going to previous week/month/year
  changeDatePrev() {
    this.showSpinner = true;
    if (this.viewSelected === 'Week') {
      this.weekNo = this.weekNo - 1;
    } else if (this.viewSelected === 'Month') {
      this.displayYear =
        this.currentMonth === 0 ? this.displayYear - 1 : this.displayYear;
      this.currentMonth = this.currentMonth === 0 ? 11 : this.currentMonth - 1;
      this.displayMonth = this.shortMonths[this.currentMonth];
    } else {
      this.displayYear = this.displayYear - 1;
    }
    this.updateDatesForView(!this.listView, this.listView);
  }

  // Check if any fields in a trip are updated except results
  checkTripFieldChanges(trip) {
    const initialTripLines = this.initialTripDetails.destinations;
    if (this.initialTripDetails.description !== trip.description) {
      return true;
    } else {
      if (
        trip.destinations.length !== initialTripLines.length ||
        this.deletedDestinations.length
      ) {
        return true;
      } else {
        if (this.checkTripFieldDestinations(trip)) {
          return true;
        }
      }
    }
    if (
      trip.attachments.length !== this.initialTripDetails.attachments.length ||
      this.tripDeleteAttachments.length
    ) {
      return true;
    }
    return false;
  }

  checkTripFieldDestinations(trip) {
    let index;
    const initialTripLines = this.initialTripDetails.destinations;
    let budget;
    const compareAttributes = [
      'from',
      'to',
      'startDate',
      'endDate',
      'startTime',
      'endTime',
      'goals',
    ];
    // Check all the destinations data
    trip.destinations.every((destination) => {
      index = initialTripLines
        .map((dest) => dest.line_id)
        .indexOf(destination.line_id);
      if (index !== -1) {
        const test = compareAttributes.filter(
          (attr) => initialTripLines[index][attr] !== destination[attr]
        ).length;
        if (test > 0) {
          return true;
        }
        // Check values of each budget of a destination
        destination.budgetList.every((budgetList) => {
          budget =
            initialTripLines[index].budgetList[
              initialTripLines[index].budgetList
                .map((value) => value.name)
                .indexOf(budgetList.name)
            ];
          if (
            budget &&
            ((budget.required && budget.type !== budgetList.type) ||
              budget.value.value !== budgetList.value.value ||
              budget.value.type !== budgetList.value.type)
          ) {
            return true;
          }
          return false;
        });
      }
      return false;
    });
    return false;
  }

  checkUpdateCommentsChange(activityType): void {
    let updateFlag = false;
    if (activityType === 'task') {
      updateFlag =
        this.editorFlag['task-update'] || this.editorFlag['task-comment'];
    } else if (activityType === 'goal') {
      updateFlag = this.editorFlag['goal-comment-editor'];
    }
    if (updateFlag) {
      this.unsavedDialog = true;
      this.unsavedActivityType = activityType;
    } else if (activityType === 'task') {
      this.closeTask();
    } else {
      this.closeGoal();
    }
  }

  // Check selected user view week/month/year
  checkUserView() {
    this.showSpinner = true;
    this.displayYear = this.today.getFullYear();
    this.currentMonth = this.today.getMonth();
    this.displayMonth = this.shortMonths[this.currentMonth];

    if (this.viewSelected === 'Week') {
      this.getNumberOfWeek(this.today, true);
    } else {
      this.fromDate =
        this.viewSelected === 'Month'
          ? ActivityPlannerComponent.createDates(
              this.displayYear,
              this.currentMonth,
              1
            )
          : ActivityPlannerComponent.createDates(this.displayYear, 0, 1);
      this.toDate =
        this.viewSelected === 'Month'
          ? ActivityPlannerComponent.createDates(
              this.displayYear,
              this.currentMonth + 1,
              0
            )
          : ActivityPlannerComponent.createDates(this.displayYear, 11, 31);
    }
    if (this.listView) {
      if (this.expenseView) {
        this.loadAllExpenses();
      } else {
        this.loadActivityDetails(
          this.fromDate,
          this.toDate,
          this.empSelected,
          (data) => {
            this.parseAddedTrips(data);
          }
        );
      }
    } else {
      this.loadActivityDetails(
        this.fromDate,
        this.toDate,
        this.empSelected,
        (data) => {
          this.parseActivityDetails(data);
        },
        { status: this.taskStatusSelected, comments: 'Y' }
      );
    }
  }

  chooseStatus(activityType, status) {
    if (activityType === 'task') {
      this.taskDetails.status = status;
      this.hideBlock('#task-statuses');
      this.changeActivityStatus(status, this.taskDetails.task_id);
    }
  }

  // Minimize the destinations in add-trip screen
  closeDestination(destination) {
    let destStartDate;
    let destEndDate;
    if (!destination.from) {
      destination.focusFrom = false;
      return;
    } else if (!destination.to) {
      destination.focusTo = false;
      return;
    } else if (!destination.startDate) {
      destination.focusStartDate = false;
      return;
    } else if (!destination.endDate) {
      destination.focusEndDate = false;
      return;
    } else if (!destination.focusGoals) {
      destination.focusGoals = false;
      return;
    } else {
      if (destination.focusEndDate && destination.focusEndTime) {
        destStartDate = new Date(
          this.combineDateTime(destination.startDate, destination.startTime)
        );
        destEndDate = new Date(
          this.combineDateTime(destination.endDate, destination.endTime)
        );

        [
          destination.duration,
          destination.durationInSec,
        ] = ActivityPlannerComponent.calculateDuration(
          destStartDate,
          destEndDate
        );
        destination.showFull = false;
      }
    }
    destination.totalBudget = destination.budgetList[0].value;
  }

  closeGoal() {
    this.showAddGoal = false;
    this.showGoalDesc = false;
    this.goal.name = this.goal.name || this.oldGoal.name;
    if (
      this.goal.name &&
      (this.goal.name !== this.oldGoal.name ||
        this.goal.description !== this.oldGoal.description)
    ) {
      this.saveGoal();
    }
  }

  closeMissingGoogleEvents(): void {
    this.showMissingEvents = false;
    this.missingEventsList = [];
  }

  closeSubTask() {
    let subTaskToBeSaved = this.taskDetails.sub_tasks.find(
      (subTask) => subTask.sub_task_id === this.subTask.sub_task_id
    );
    subTaskToBeSaved.sub_task_title =
      this.subTask.sub_task_title || subTaskToBeSaved.sub_task_title;
    subTaskToBeSaved.sub_task_description = this.subTask.sub_task_description;
    subTaskToBeSaved.due_date = this.subTask.due_date;
    this.showSubTaskDetails = false;
    this.saveSubTask(subTaskToBeSaved);
  }

  closeTask() {
    if (this.creatingTaskInTrip) {
      this.creatingTaskInTrip = false;
      this.showTaskMap = true;
    }
    if (
      this.taskDetails.task_id &&
      this.selectedGoal &&
      this.selectedGoal !== this.oldTaskDetails.goal.id
    ) {
      this.linkOrUnLinkGoal('Link', this.taskDetails.task_id);
    } else if (
      this.taskDetails.task_id &&
      !this.selectedGoal &&
      this.taskDetails.created_id === this.userId
    ) {
      this.showGoalError = true;
      return;
    }
    this.showAddTask = false;
    this.taskDetails.tags = this.taskTags.map((tag) => tag.tag_id).join(',');
    if (
      this.taskDetails.sub_tasks.length &&
      !this.taskDetails.sub_tasks.some((subTask) => subTask.is_new)
    ) {
      this.saveSubTaskOrder();
    }
    this.saveCollaborators(this.taskDetails.task_id);
    if (
      this.editAccess &&
      (this.taskDetails.tags !== this.oldTaskDetails.tags ||
        this.oldTaskDetails.end_date !== this.taskDetails.end_date)
    ) {
      this.saveTaskDetails();
    } else if (this.cardView) {
      this.showCardView();
    } else if (this.reportView) {
      this.showReport();
    }
    this.editAccess = false;
    jQuery('body').css('overflow', 'auto');
  }

  closeTrip(flag = false) {
    this.showAddTrip = false;
    this._appService.scrollTop();
    this.showViewScreen = true;
    if (flag) {
      this.tripView = false;
      this.showAddedTrips();
    }
  }

  // Combine date and time strings to send to API
  combineDateTime(date, time) {
    let dateTimeStr = '';
    if (date && time) {
      dateTimeStr = this._formatService.parseDate(date, this.dateFormat);
      dateTimeStr += ' ' + time.split(' ')[0] + ':00 ' + time.split(' ')[1];
    }
    return dateTimeStr;
  }

  // Validate start and end dates
  compareDates(startDate, endDate) {
    let startDateMillis, endDateMillis;
    try {
      startDateMillis = this._formatService.dateInMillis(
        this._formatService.parseDate(startDate, this.dateFormat)
      );
      endDateMillis = this._formatService.dateInMillis(
        this._formatService.parseDate(endDate, this.dateFormat)
      );
      if (startDate === endDate) {
        return true;
      } else {
        if (startDateMillis > 0 && endDateMillis > 0) {
          if (startDateMillis > endDateMillis) {
            return false;
          }
        } else if (!startDateMillis) {
          return false;
        }
      }
    } catch (e) {
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>',
      });
    }
    return true;
  }

  // Validate the start time and end time for an activity
  compareDestTime(details, type) {
    if (type === 'trip') {
      details.focusEndTime = true;
      if (
        details.startDate &&
        details.endDate &&
        details.startDate === details.endDate
      ) {
        details.focusEndTime = ActivityPlannerComponent.compareTime(
          details.startTime,
          details.endTime
        );
      }
    } else {
      this.focusTaskEndTime = true;
      if (
        details.start_date &&
        details.end_date &&
        details.start_date === details.end_date
      ) {
        this.focusTaskEndTime = ActivityPlannerComponent.compareTime(
          details.start_time,
          details.end_time
        );
      }
    }
  }

  confirmDeleteActivity(): void {
    this.deleteActivityDialog = false;
    if (this.activityDeleteDetails.type === 'Goal') {
      this.deleteGoal();
    } else if (
      this.activityDeleteDetails.type === 'task' ||
      this.activityDeleteDetails.type === 'trip'
    ) {
      this.deleteActivity(this.activityDeleteDetails);
    } else if (this.activityDeleteDetails.type === 'sub-task') {
      this.deleteSubTask(this.activityDeleteDetails);
    } else if (this.activityDeleteDetails.comment_type) {
      this.deleteCommentOrUpdate(
        this.activityDeleteDetails.fromActivity,
        this.activityDeleteDetails.comment_id
      );
    } else {
      this.deleteExpense(this.activityDeleteDetails);
    }
  }

  createChatThread(): Promise<any> {
    const endPoint = '/activityplanner/chat/';
    const requestObj = {
      chat_creator: this.userId,
      chat_recipient: this.empSelected,
    };
    return new Promise((resolve) => {
      this._httpService.httpRequest('POST', endPoint, requestObj, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - createChatThread()',
          });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else {
          this.selectedChat.id = data.chat_id;
          this.setChatId();
          resolve(data);
        }
      });
    });
  }

  static createDates(year, month, day) {
    let date = new Date(year, month, day),
      months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ];
    return (
      date.getDate() + '-' + months[date.getMonth()] + '-' + date.getFullYear()
    );
  }

  createNewTripExpense() {
    this._appService.activityEmployee = this.empSelected;
    this._router.navigate(['expenses/manage']);
  }

  // Validate dates for an activity
  dateCheck(details, type?) {
    this.tripErrorMessage = '';
    setTimeout(() => {
      if (type === 'task') {
        details.dateError = '';
        if (
          details.end_date &&
          this._formatService.isValidDate(details.end_date) &&
          details.end_date !== this.previousTaskDate
        ) {
          this.saveActivityLog(
            `Due date was changed to ${details.end_date}`,
            details.task_id
          );
        } else if (!details.end_date && this.previousTaskDate) {
          this.saveActivityLog(`Due date was removed`, details.task_id);
        }
        this.previousTaskDate = details.end_date;
      } else {
        if (type === 'trip') {
          details.focusEndDate = true;
          details.focusStartDate = true;
          if (details.endDate) {
            details.focusEndDate = this.compareDates(
              details.startDate,
              details.endDate
            );
            this.tripErrorMessage = 'In-Valid End date';
          }
        }
      }
    });
  }

  deleteActivity(activity) {
    const endPoint = `/activityplanner/delete/${activity.type}/${
      activity.type === 'task' ? activity.task_id : activity.trip_id
    }/`;
    this.showSpinner = activity.type === 'trip';
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this.showSpinner = false;
        this._appService.notify({
          status: 1,
          msg: 'Server Error - deleteActivity()',
        });
      } else if (data.status && data.status === 1) {
        this.showSpinner = false;
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (!this.listView) {
        this.loadActivityDetails(
          this.fromDate,
          this.toDate,
          this.userId,
          (activities) => {
            this.parseActivityDetails(activities);
          }
        );
      } else {
        if (this.tripView) {
          this.loadActivityDetails(
            this.fromDate,
            this.toDate,
            this.empSelected,
            (parseTrips) => {
              this.parseAddedTrips(parseTrips);
            }
          );
        } else {
          this.loadAllExpenses();
        }
      }
      this._appService.notify({
        status: 0,
        msg: `Activity: ${activity.description} deleted`,
      });
      this.showAddTask = false;
    });
  }

  // Delete the comment or update from selected activity details (Goal, Project)
  deleteActivityComment(activityType, commentOrUpdateId): void {
    if (activityType === 'task') {
      const deleteIndex = this.taskDetails.comments.findIndex(
        (update) => update.comment_id === commentOrUpdateId
      );
      if (deleteIndex !== -1) {
        this.taskDetails.comments.splice(deleteIndex, 1);
        this.parseCommentsInActivities(null, commentOrUpdateId, 'delete');
        this.toggleActions(this.toggleAction);
      }
    } else {
      let goalIndex = this.goal.comments.findIndex(
        (update) => update.comment_id === commentOrUpdateId
      );
      if (goalIndex !== -1) {
        this.goal.comments.splice(goalIndex, 1);
        this.parseCommentsInGoals(null, commentOrUpdateId, 'delete');
      }
      goalIndex = this.allGoals.findIndex((goal) => goal.id === this.goal.id);
      if (goalIndex !== -1) {
        this.allGoals[
          goalIndex
        ].total_comment_count = this.goal.comments.length;
      }
    }
  }

  // Delete Attachment from a trip
  deleteAttachment(attachment, index) {
    if (attachment.file_id) {
      this.tripDeleteAttachments.push(attachment.file_id);
    }
    this.trip.attachments.splice(index, 1);
  }

  deleteExpense(expenseToBeDeleted) {
    let endPoint = '/expenses/' + expenseToBeDeleted.report_header_id + '/',
      expenseIndex;
    this._expenseService.deleteExpense(endPoint, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - deleteExpense()',
          });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this._appService.notify({
            status: data.status,
            msg: `${data.msg} - ${expenseToBeDeleted.report_header_id}`,
          });
          expenseIndex = this.expenses.findIndex(
            (expense) =>
              expense.report_header_id === expenseToBeDeleted.report_header_id
          );
          expenseIndex !== -1 ? this.expenses.splice(expenseIndex, 1) : null;
          expenseIndex = this.allExpenses.findIndex(
            (expense) =>
              expense.report_header_id === expenseToBeDeleted.report_header_id
          );
          expenseIndex !== -1 ? this.allExpenses.splice(expenseIndex, 1) : null;
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  deleteGoal() {
    const endPoint = `/activityplanner/goal/${this.goal.id}/`;
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - deleteGoal()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.showAddGoal = false;
        this.reportView ? this.showReport() : this.showCardView();
        this._appService.notify({
          status: 0,
          msg: `Goal: ${this.goal.name} deleted`,
        });
      }
    });
  }

  deleteSubTask(subTask) {
    const endPoint = `/activityplanner/subtask/${subTask.sub_task_id}/`;
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - deleteSubTask()',
        });
      } else if (data.status === 1) {
        this.showSubTaskDetails = false;
        this.showAddTask = false;
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this._appService.notify({
          status: 0,
          msg: `Task: ${subTask.sub_task_title} deleted`,
        });
        this.taskDetails.sub_tasks.splice(
          this.taskDetails.sub_tasks.findIndex(
            (subTaskObj) => subTaskObj.sub_task_id === subTask.sub_task_id
          ),
          1
        );
        this.showSubTaskDetails = false;
        this.subTask = {};
      }
    });
  }

  deleteCommentOrUpdate(activityType, updateId): void {
    this._activityPlannerService
      .deleteCommentOrUpdate(updateId)
      .then(() => {
        this.deleteActivityComment(activityType, updateId);
        this._appService.notify({
          status: 0,
          msg: `${
            this.activityDeleteDetails.comment_type === 'U'
              ? 'Update'
              : 'Comment'
          } deleted successfully`,
        });
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  /* disabled condition : Manager/UITripAccessAll can't edit his/her employee activity details,
  UITripAccessAll role is to view all activity details of all users
  If it is new activity then it should be editable
  If login user can edit his/her own activities */
  disableFields(type) {
    if (type === 'task') {
      return (
        (this.taskDetails.approver_id === this.userId ||
          this.roles.UITripAccessAll) &&
        !this.taskDetails.is_new &&
        this.userId !== this.empSelected
      );
    } else {
      return !this.trip.isNew && this.userId !== this.empSelected;
    }
  }

  downloadAttachment(attachment) {
    let blobFile = this._formatService.base64ToBlob(attachment.file_content),
      a,
      url;
    if (blobFile) {
      a = document.createElement('a');
      document.body.appendChild(a);
      url = this._window.URL.createObjectURL(blobFile);
      a.href = url;
      a.download = attachment.file_name;
      a.click();
      this._window.URL.revokeObjectURL(url);
    }
  }

  // Drag and drop tasks from one list to another in the card view
  drop(event: CdkDragDrop<any[]>, cardDetails) {
    let task;
    if (
      event.previousContainer === event.container &&
      event.previousIndex !== event.currentIndex
    ) {
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
      this.saveTaskOrder([event.container.id]);
    } else if (
      event.previousContainer !== event.container &&
      event.container.id !== 'CO' &&
      event.previousContainer.data[event.previousIndex].created_id ===
        this.userId
    ) {
      /* Collaborators of a task/project can't change the status of the card
         by moving it to another list unless they are the creators.
       * They can how ever change the order within the same list */
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
      task = event.container.data[event.currentIndex];
      // Update the completed task count if a task is moved from or to completed list
      if (event.container.id === 'C') {
        this.completedTaskCount =
          this.completedTaskCount === cardDetails.activities.length
            ? event.container.data.length
            : this.completedTaskCount + 1;
      } else if (task.status === 'C') {
        this.completedTaskCount = event.previousContainer.data.length;
      }
      task.status = event.container.id;
      this.changeActivityStatus(event.container.id, task.task_id);
      this.saveTaskOrder([event.container.id, event.previousContainer.id]);
    }
  }

  // Drag and drop goals
  dropGoal(event: CdkDragDrop<any[]>) {
    if (event.previousIndex !== event.currentIndex) {
      moveItemInArray(this.allGoals, event.previousIndex, event.currentIndex);
      this.saveTaskOrder(['G']);
    }
  }

  // Drag and drop subTasks within a task
  dropSubTasks(event: CdkDragDrop<any[]>) {
    moveItemInArray(
      this.taskDetails.sub_tasks,
      event.previousIndex,
      event.currentIndex
    );
  }

  // Expand destination in add-trip screen
  expandDestination(dest, index) {
    dest.showFull = true;
    this.addFooPicker('dest-start-' + index, 'dest-end-' + index);
  }

  extractContent(s): string {
    const span = document.createElement('span');
    span.innerHTML = s;
    return span.textContent.trim() || span.innerText.trim();
  }

  fetchActivityLog() {
    let endPoint = `/activityplanner/log/${this.taskDetails.task_id}/`,
      dateArray;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - fetchActivityLog()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (data.length) {
        data.forEach((log) => {
          const logRow = log;
          dateArray = logRow.log_date.split(' ');
          logRow.task_user_name = this.getUserBadgeText(log.user_description);
          logRow.date = `${this._formatService.formatDate(
            dateArray[0],
            this.dateFormat
          )}\xa0\xa0
          ${dateArray[1]} ${dateArray[2]}`;
        });
        this.taskDetails.activityLog = data;
      }
    });
  }

  fetchComments(activityType, activityId?) {
    let endPoint = `/activityplanner/comments/${activityType}/`;
    if (activityId) {
      // Only comments in chat view will be loaded in ascending order
      endPoint += `${activityId}/?sort=asc`;
    } else if (activityType === 'goal') {
      endPoint += `${this.goal.id}/`;
    } else if (activityType === 'task') {
      endPoint += `${this.taskDetails.task_id}/`;
    }
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - fetchComments()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        let commentStartDate;
        let fileType;
        // Calculate the time duration from when the comment/reply was posted
        data.comments.forEach((comment, commentIndex) => {
          const commentObj = comment;
          // commentObj.showReplyOption = true;
          commentObj.comment_user_name = this.getUserBadgeText(
            comment.user_details[0].user_description
          );
          commentObj.replies = comment.replies || [];
          commentObj.user_description =
            comment.user_details[0].user_description;
          commentObj.isSelf =
            comment.user_details[0].user_id === this.userId &&
            comment.comment_type === 'C';
          commentStartDate = comment.created_date.split(' ');
          commentObj.displayDate = `${this._formatService.formatDate(
            commentStartDate[0],
            this.dateFormat
          )}
              \xa0\xa0${ActivityPlannerComponent.parseTime(
                commentStartDate[1]
              )}`;
          commentObj.commentDate = this.getCommentDate(comment);

          if (comment.comment_type === 'A' && !this.chatView) {
            fileType = this.taskDetails.attachments.find(
              (file) => file.file_id === comment.parent_id
            ).file_type;
            commentObj.file_id = comment.parent_id;
            commentObj.file_name = comment.comment_data;
            commentObj.imgUrl = this.getAttachmentImgUrls(fileType);
          }

          if (comment.user_details[0].user_id === this.userId) {
            commentObj.showDeleteOption =
              new Date(this._appService.today()).getTime() ===
              new Date(commentStartDate[0]).getTime();
          }

          // Hide the user name, badge, reply option for consecutive comments if they are added by the same user
          if (
            commentIndex !== 0 &&
            data.comments[commentIndex - 1].comment_type === 'C' &&
            data.comments[commentIndex - 1].user_details[0].user_id ===
              comment.user_details[0].user_id &&
            comment.comment_type === 'C'
          ) {
            commentObj.hideAvatar = true;
          }
          if (
            commentIndex === data.comments.length - 1 ||
            (commentIndex !== data.comments.length - 1 &&
              data.comments[commentIndex + 1].user_details[0].user_id !==
                comment.user_details[0].user_id)
          ) {
            commentObj.showReplyOption = true;
          }
        });
        if (activityId) {
          this.selectedChat.id = activityId;
          this.selectedChat.type = activityType;
          this.chatComments = data.comments.filter(
            (comment) => comment.comment_type === 'C'
          );
          this.scrollToChatEnd();
        } else if (activityType === 'goal') {
          this.goal.comments = data.comments;
          this.focusTextEditor();
        } else if (activityType === 'task') {
          this.taskDetails.comments = data.comments;
          this.toggleActions(this.reportView ? this.toggleAction : 'U');
          if (data.comments.length) {
            this.taskDetails.showComments = true;
          } else {
            this.showNewComment = true;
          }
        }
      }
    });
  }

  fetchCommentsForChat(activityType, activityId) {
    if (activityId) {
      this.fetchComments(activityType, activityId);
    } else {
      this.selectedChat.id = null;
      this.selectedChat.type = activityType;
      this.chatComments = [];
    }
  }

  filterTasks() {
    if (!this.chatView) {
      this.loadActivityDetails(
        this.fromDate,
        this.toDate,
        this.empSelected,
        (data) => {
          this.parseActivityDetails(data);
          this.filteredTasks = [...this.allTasks];
        },
        { status: this.taskStatusSelected, comments: 'N' }
      );
    } else {
      this.loadUserChats();
    }
  }

  focusField(fieldId) {
    switch (fieldId) {
      case 'description':
        this.showTaskGoals = true;
        this.taskDetails.goals = this.initDefaultText();
        break;
      case 'goal-results':
        this.showTaskResults = !this.showTaskResults;
        this.hideBlock('#task-options');
        break;
      case 'sub-description':
        this.showSubTaskDesc = true;
        break;
      case 'goal-description':
        this.showGoalDesc = true;
        break;
      case 'task-goal-link':
        this.showGoalLink = true;
        this.selectedGoal = null;
        break;
    }

    setTimeout(() => {
      if (document.getElementById(fieldId)) {
        document.getElementById(fieldId).focus();
      }
    }, 30);
  }

  focusTextEditor(): void {
    tinyMCE.activeEditor.focus();
  }

  formatGoalComments(comments): void {
    comments.forEach((selectedComment, commentIndex) => {
      const comment = selectedComment;
      comment.comment_user_name = this.getUserBadgeText(
        comment.user_description
      );
      const commentDateArray = comment.created_date.split(' ');
      comment.displayDate = `${this._formatService.formatDate(
        commentDateArray[0],
        this.dateFormat
      )}
              \xa0\xa0${ActivityPlannerComponent.parseTime(
                commentDateArray[1]
              )}`;
      comment.commentDate = this.getCommentDate(comment);
      comment.isSelf =
        comment.comment_type === 'C' && comment.user_id === this.userId;
      // Hide the user name, badge, reply option for consecutive comments if they are added by the same user
      if (
        commentIndex !== 0 &&
        comments[commentIndex - 1].user_id === comment.user_id &&
        comment.comment_type === 'C'
      ) {
        comment.hideAvatar = true;
      }
      if (
        commentIndex === comments.length - 1 ||
        (commentIndex !== comments.length - 1 &&
          comments[commentIndex + 1].user_id !== comment.user_id)
      ) {
        comment.showReplyOption = true;
      }
    });
    return comments;
  }

  // Set the image url of an attachment based on its type
  getAttachmentImgUrls(fileType): string {
    let imgUrl = '/../../assets/images/';
    if (fileType.includes('image')) {
      imgUrl += 'image.svg';
    } else if (fileType.includes('csv') || fileType.includes('excel')) {
      imgUrl += 'excel.svg';
    } else if (fileType.includes('pdf')) {
      imgUrl += 'download-pdf.svg';
    } else if (fileType.includes('zip')) {
      imgUrl += 'zip.svg';
    } else {
      imgUrl += 'file.svg';
    }
    return imgUrl;
  }

  getCommentDate(comment): string {
    if (!comment.comment_date) {
      return '';
    }

    const commentDate = comment.comment_date.split(' ');
    return `${this._formatService.formatDate(
      commentDate[0],
      this.dateFormat
    )} ${ActivityPlannerComponent.parseTime(commentDate[1])}`;
  }

  static getCommentDisplaySettings(newComment, allComments, sortAscending?) {
    const commentIndex = allComments.length;
    const commentToBeAdded = newComment;
    commentToBeAdded.showReplyOption = true;
    /* If consecutive comments are from the same user, hide the user name and avatar for comments
    except for the first comment */
    if (
      sortAscending &&
      commentIndex &&
      allComments[commentIndex - 1].comment_type === 'C' &&
      allComments[commentIndex - 1].user_details[0].user_id ===
        commentToBeAdded.user_details[0].user_id &&
      commentToBeAdded.comment_type === 'C'
    ) {
      commentToBeAdded.hideAvatar = true;
    } else if (!sortAscending && commentToBeAdded.comment_type === 'C') {
      commentToBeAdded.showReplyOption = false;
      commentToBeAdded.hideAvatar = false;
      const prevComment = commentIndex
        ? allComments.find((comment) => comment.comment_type === 'C')
        : null;
      if (prevComment) {
        prevComment.hideAvatar =
          prevComment.user_details[0].user_id ===
          commentToBeAdded.user_details[0].user_id;
      }
    }
    return commentToBeAdded;
  }

  // Update from and to dates on first load and today button click
  getCurrentDayDetails() {
    this.displayYear = this.today.getFullYear();
    this.currentMonth = this.today.getMonth();
    this.displayMonth = this.shortMonths[this.currentMonth];
    if (this.viewSelected === 'Week') {
      this.getNumberOfWeek(this.today, true);
    } else {
      this.fromDate =
        this.viewSelected === 'Month'
          ? ActivityPlannerComponent.createDates(
              this.displayYear,
              this.currentMonth,
              1
            )
          : ActivityPlannerComponent.createDates(this.displayYear, 0, 1);
      this.toDate =
        this.viewSelected === 'Month'
          ? ActivityPlannerComponent.createDates(
              this.displayYear,
              this.currentMonth + 1,
              0
            )
          : ActivityPlannerComponent.createDates(this.displayYear, 11, 31);
    }
  }

  getCurrentTime() {
    let today = new Date(),
      hours,
      timeString;
    if (today.getHours() > 12) {
      hours = today.getHours() - 12;
    } else {
      hours = today.getHours() === 0 ? 12 : today.getHours();
    }
    timeString = `${hours}:${today.getMinutes()}:${today.getSeconds()} ${
      today.getHours() < 12 ? 'AM' : 'PM'
    }`;
    return timeString;
  }

  getDateInMillis(validDate): number {
    return this._formatService.dateInMillis(validDate);
  }

  /* Gives start and end dates for the week number
     isDisplay is check to update from and to dates to display in the top header in week view
   */
  getDateRangeOfWeek(weekNo, isDisplay?) {
    let d1 = new Date(),
      numOfDaysPastSinceLastMonday = (d1.getDay() || 7) - 1,
      weekNoToday,
      weeksInTheFuture,
      formattedFromDate,
      formattedToDate,
      index,
      fromDate,
      toDate,
      ordinal;
    d1.setDate(d1.getDate() - numOfDaysPastSinceLastMonday);
    weekNoToday = ActivityPlannerComponent.getWeek(d1);
    weeksInTheFuture = weekNo - weekNoToday;
    // week start date
    d1.setDate(d1.getDate() + 7 * weeksInTheFuture);
    this.weekStartDate = d1.getDate().toString();
    ordinal = this._formatService.getNumberOrdinal(
      this.weekStartDate[this.weekStartDate.length - 1]
    );
    this.weekStartDate = this.weekStartDate + ordinal;
    fromDate = ActivityPlannerComponent.createDates(
      d1.getFullYear(),
      d1.getMonth(),
      d1.getDate()
    );
    formattedFromDate =
      d1.getDate().toString().padStart(2, '0') +
      '-' +
      this.shortMonths[d1.getMonth()].substr(0, 3).toUpperCase() +
      '-' +
      d1.getFullYear();

    /* week end date */
    d1.setDate(d1.getDate() + 6);
    this.weekEndDate = d1.getDate().toString();
    ordinal = this._formatService.getNumberOrdinal(
      this.weekEndDate[this.weekEndDate.length - 1]
    );
    this.weekEndDate = this.weekEndDate + ordinal;
    toDate = ActivityPlannerComponent.createDates(
      d1.getFullYear(),
      d1.getMonth(),
      d1.getDate()
    );
    formattedToDate =
      d1.getDate().toString().padStart(2, '0') +
      '-' +
      this.shortMonths[d1.getMonth()].substr(0, 3).toUpperCase() +
      '-' +
      d1.getFullYear();

    if (isDisplay) {
      this.displayFromDate = this._formatService.formatDate(
        formattedFromDate,
        this.dateFormat
      );
      this.displayToDate = this._formatService.formatDate(
        formattedToDate,
        this.dateFormat
      );
      this.displayMonth = this.shortMonths[d1.getMonth()];
      d1.setDate(d1.getDate() - 1);
      this.displayWeek = ActivityPlannerComponent.getWeek(d1);
      this.fromDate = fromDate;
      this.toDate = toDate;
    }
  }

  /* used to calculate textarea height for task title inside task card
   * default height is 26px, we increase height in multiples of 26 for
   * every 50 characters in title */
  getDynamicHeight(elem, text) {
    if (!text || text.length < 50) {
      return this._sanitizer.bypassSecurityTrustStyle(`28px`);
    }
    return this._sanitizer.bypassSecurityTrustStyle(
      `${Math.ceil(text.length / 50) * 28}px`
    );
  }

  getEditorCharacterCountSettings(settingDetails): EditorSettings {
    const settings = settingDetails;
    settings.edit_flag = false;
    settings.forced_root_block = false;
    settings.max_chars = this.maxCharacters;
    settings.setup = (editor) => {
      editor.on('keydown', (event) => {
        const allowedKeys = [8, 37, 38, 39, 40, 46, 86]; // backspace, delete and cursor keys
        // setting our max character limit
        const tinymax = editor.settings.max_chars;
        this.activeEditorId = editor.id;
        // grabbing the length of the curent editors content
        let tinylen = editor.getContent().replace(this.regexTags, '');
        if (allowedKeys.indexOf(event.keyCode) !== -1) {
          tinylen = editor.getContent().replace(this.regexTags, '');
          if (tinylen.length < tinymax) {
            this.maxCharErrFlag = false;
          }
          this.charCount = tinylen.length;
          return true;
        }
        if (tinylen.length > tinymax) {
          event.preventDefault();
          event.stopPropagation();
          this.maxCharErrFlag = true;
          return false;
        }
        this.maxCharErrFlag = false;
        this.charCount = tinylen.length;
        return true;
      });

      editor.on('keyup', (e) => {
        const tinylen = editor.getContent().replace(this.regexTags, '');
        if ([32, 13].indexOf(e.keyCode) === -1) {
          this.editorFlag[editor.id] = true;
        }
        this.charCount = tinylen.length;
        if (tinylen.length < editor.settings.max_chars) {
          this.maxCharErrFlag = false;
        }
      });
    };

    settings.init_instance_callback = (editor) => {
      const tinylen = editor.getContent().replace(this.regexTags, '');
      this.maxCharErrFlag = tinylen.length > this.maxCharacters;
      this.charCount = tinylen.length;
    };
    settings.paste_preprocess = (plugin, args) => {
      // find the editor using the id
      const editor = tinymce.get(tinymce.activeEditor.id);
      this.activeEditorId = editor.id;
      // get the len of the previous written text in the editor
      const len = editor.contentDocument.body.innerText.length;
      const selectedText = tinyMCE.activeEditor.selection
        .getContent()
        .replace(this.regexTags, '').length;
      // paste data
      // const text = tinymce.dom.DomQuery(args.content).text();
      const text = args.content.replace(this.regexTags, '');
      // total count of the text
      if (len + text.length - selectedText > editor.settings.max_chars) {
        this.maxCharErrFlag = true;
      } else {
        this.maxCharErrFlag = false;
      }
      this.charCount = len + text.length - selectedText;
    };
    return settings;
  }

  getEditorSettings(editorId, placeholder?): EditorSettings {
    let settings = { ...this.editorSettings };
    if (placeholder) {
      this._translate.get(placeholder).subscribe((value) => {
        settings.placeholder = value;
      });
    }
    if (editorId === 'chat-editor') {
      settings.plugins = 'lists paste';
    }
    if (
      ['task-update', 'task-comment', 'goal-comment-editor'].indexOf(
        editorId
      ) !== -1
    ) {
      settings = { ...this.getEditorCharacterCountSettings(settings) };
    }
    return settings;
  }

  getNumberOfWeek(originDate, isDisplay): void {
    // copy the the date that is coming
    const today = new Date(
      Date.UTC(
        originDate.getFullYear(),
        originDate.getMonth(),
        originDate.getDate()
      )
    );
    /* Based on ISO standards, to find week 1 of a year it should contains the first thursday in it.
    Set to nearest Thursday: current date + 4 - current day number. Day for sunday starts as 0 ,
    to get from monday we need to change sunday to 7 */
    today.setUTCDate(today.getUTCDate() + 4 - (today.getUTCDay() || 7));
    // Get first day of year
    const firstDayOfYear = new Date(Date.UTC(today.getUTCFullYear(), 0, 1));
    const pastDaysOfYear =
      (today.valueOf() - firstDayOfYear.valueOf()) / 86400000;
    // Calculate full weeks to nearest Thursday
    const weekNoToDisplay = Math.ceil((pastDaysOfYear + 1) / 7);
    this.currentWeekNum = weekNoToDisplay;
    if (isDisplay) {
      this.weekNo = weekNoToDisplay;
      this.getDateRangeOfWeek(this.weekNo, true);
    } else {
      this.getDateRangeOfWeek(weekNoToDisplay);
    }
  }

  getTasksCondition(toggleAction): boolean {
    let lengthofText;
    if (toggleAction === 'U') {
      lengthofText = this.updateText.replace(this.regexTags, '').length;
    } else {
      lengthofText = this.newComment.replace(this.regexTags, '').length;
    }
    return (
      (this.newComment || this.updateText) && lengthofText < this.maxCharacters
    );
  }

  // Fetch the tags that can be assigned to a task
  getTaskTags() {
    let endPoint = '/activityplanner/task/tags/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'SERVER ERROR - getTaskTags()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: data.status, msg: data.msg });
      } else {
        this.taskTagList = data;
      }
    });
  }

  // Get a concatinated string of first letters of first and last name of a user
  getUserBadgeText(userName) {
    let employeeName, userBadge;
    if (userName) {
      employeeName = userName.split(' ');
      userBadge = employeeName[0][0];
      if (employeeName.length > 1) {
        userBadge += employeeName[1][0];
      }
      return userBadge;
    }
  }

  static getWeek(d1) {
    const target: any = new Date(d1);
    /* ISO standards, week starts with monday, add 6 to correct the number */
    const dayNr = (d1.getDay() + 6) % 7;
    target.setDate(target.getDate() - dayNr + 3);
    const firstThursday = target.valueOf();
    target.setMonth(0, 1);
    if (target.getDay() !== 4) {
      target.setMonth(0, 1 + ((4 - target.getDay() + 7) % 7));
    }
    // 7 * 24 * 60 * 60 * 1000 = 86400000 : No of milli seconds in a week
    return 1 + Math.ceil((firstThursday - target) / 604800000);
  }

  googleSync(syncOption, type, updateFlag = false) {
    this.showSpinner = true;
    const endPoint = '/activityplanner/google/sync/add/';
    const missingEvents = this.missingEventsList
      .filter((gevent) => gevent.checkFlag)
      .map((result) => result.google_event_id);
    const req = {
      user_id: this.userId,
      email_address: this.user.email_address,
      trip: type === 'trip' ? 'Y' : 'N',
      task: type === 'task' ? 'Y' : 'N',
      status: syncOption,
      updateFlag,
      start_date: ActivityPlannerComponent.createDates(this.displayYear, 0, 1),
      end_date: ActivityPlannerComponent.createDates(this.displayYear, 11, 31),
      missing_events: missingEvents,
      time_zone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    };
    this.showMissingEvents = false;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'SERVER ERROR - googleSync()',
        });
      } else if (data.missing_events) {
        this.missingEventsList = data.missing_events;
        this.showMissingEvents = true;
      } else {
        this._appService.notify({ status: data.status, msg: data.msg });
      }
      this.showSpinner = false;
    });
  }

  goToEmployeesSummary() {
    this._router.navigate(['/activity-planner/mapping/summary']);
  }

  groupProjectsLinkedToGoals(): void {
    // Grouping all the related projects to their associated goals
    const fromDate = this.getDateInMillis(this.fromDate);
    const toDate = this.getDateInMillis(this.toDate);
    this.allGoals.forEach((goal) => {
      const goalObj = goal;
      goalObj.related_projects = this.filteredTasks.filter(
        (task) => task.goal_id === goalObj.id
      );
      goalObj.goal_user_name = this.getUserBadgeText(goalObj.user_description);
      goalObj.minimize = false;
      goalObj.comments = goalObj.comments.filter(
        (comment) =>
          fromDate <= this.getDateInMillis(comment.created_date) &&
          this.getDateInMillis(comment.created_date) <= toDate
      );
      goalObj.comments = this.formatGoalComments(goalObj.comments);
    });
    // Only the goals with related projects will be shown in report view
    this.goals = this.allGoals.filter((goal) => goal.related_projects.length);
    this.addActivityDescriptionsInReport();
  }

  hideBlock(elementId) {
    if (jQuery(elementId).css('display') === 'block') {
      jQuery(elementId).css({ display: 'none' });
    }
  }

  initDefaultText(): string {
    let defaultText;
    defaultText =
      '<strong> 1. Assessment:</strong><br /><strong>2. le priorit&agrave; / prioritize:</strong><br />';
    defaultText +=
      '<strong>3. il piano / set:</strong><br /><strong> 4. l&rsquo;azione / act:</strong><br />';
    defaultText += '<strong> 5. la verifica / track:</strong><br/>';
    return defaultText;
  }

  isCurrentEmployee() {
    return this.empSelected === this.userId;
  }

  linkGoalToTask() {
    if (this.selectedGoal) {
      this.taskDetails.goal = this.allGoals.find(
        (goal) => goal.id === this.selectedGoal
      );
      this.showGoalLink = false;
      this.showGoalError = false;
    } else {
      this.taskDetails.goal = {};
    }
  }

  linkOrUnLinkGoal(action, taskId) {
    let endPoint = '/activityplanner/goal/link/',
      reqObj = {
        goal_id: action === 'Link' ? this.selectedGoal : '',
        task_ids: [taskId],
      };
    this.showGoalLink = false;
    this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - linkOrUnLinkGoal()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: data.status, msg: data.msg });
      }
    });
  }

  loadActivityDetails(
    startDate,
    endDate,
    userId,
    callback,
    statusOrCommentData?
  ) {
    const statusToLoad = this.cards
      .filter((card) => card.initialLoad)
      .map((card) => `'${card.id}'`)
      .join(',');
    const reqData: any = {
      start_date: startDate,
      end_date: endDate,
      type: this.tripView ? 'trip' : 'task',
      comments:
        statusOrCommentData && statusOrCommentData.comments
          ? statusOrCommentData.comments
          : 'N',
      org_id: this._cacheService.getOrgId(),
      users: [userId],
    };
    reqData.goals =
      (this.cardView && !this.minimizeGoals) ||
      (this.reportView && reqData.comments === 'N') ||
      this.listView
        ? 'Y'
        : 'N';

    if (statusOrCommentData && statusOrCommentData.status) {
      reqData.status =
        statusOrCommentData.status === 'All'
          ? ["'I','C'"]
          : [`'${statusOrCommentData.status}'`];
    } else {
      reqData.status = [statusToLoad];
    }
    this._activityPlannerService
      .loadActivityPlanner(reqData)
      .then((data) => {
        callback(data);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
      });
  }

  loadActvitiesBasedOnStatus(cardDetails) {
    let completedCard;
    cardDetails.minimize = !cardDetails.minimize;
    if (cardDetails.id === 'C' && !cardDetails.minimize) {
      cardDetails.initialLoad = true;
      this.loadActivityDetails(
        this.fromDate,
        this.toDate,
        this.empSelected,
        (data) => {
          this.parseActivityDetails(data, true);
          completedCard = this.cards.find((card) => card.id === 'C');
          completedCard.activities = this.allTasks.filter(
            (task) =>
              task.status === 'C' && task.created_id === this.empSelected
          );
          this.completedTaskCount = completedCard.activities.length;
        },
        { status: 'C', comments: 'N' }
      );
    }
  }

  loadAllExpenses() {
    let endPoint = '/expenses/summary/',
      reqObj,
      selectedUser = this.allUsers.find(
        (employee) => employee.employee_number === this.empSelected
      );
    this.allExpenses = [];
    this.expenses = [];
    if (selectedUser) {
      reqObj = {
        status: 'ALL',
        org_id: '',
        from_date: this.fromDate,
        to_date: this.toDate,
        person_id: selectedUser.person_id,
        created_by: '',
        linked_expenses_only: true,
      };
      this.showSpinner = !this.showAddTask;
      this._expenseService.insertExpenses(endPoint, reqObj, (data) => {
        try {
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: 'Server Error - loadAllExpenses()',
            });
            this.showSpinner = false;
          } else if (data.status === 1) {
            this._appService.notify({ msg: data.msg, status: data.status });
            this.showSpinner = false;
          } else {
            this.parseExpensesData(data, selectedUser);
          }
        } catch (e) {
          this.showSpinner = false;
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>',
          });
        }
      });
    } else {
      this.showSpinner = false;
    }
  }

  loadCurrencies() {
    this._commonService.loadCurrencies().then((data) => {
      this.currencies = data;
    });
  }

  loadEmpActivities() {
    this.populateStatusList();
    if (this.chatView) {
      this.loadUserChats();
    } else if (!this.listView) {
      this.showSpinner = true;
      this.loadActivityDetails(
        this.fromDate,
        this.toDate,
        this.empSelected,
        (data) => {
          this.parseActivityDetails(data);
        },
        this.reportView
          ? { status: this.taskStatusSelected, comments: 'N' }
          : ''
      );
    } else {
      if (this.expenseView) {
        this.loadAllExpenses();
      } else {
        this.loadActivityDetails(
          this.fromDate,
          this.toDate,
          this.empSelected,
          (data) => {
            this.parseAddedTrips(data);
          }
        );
      }
    }
  }

  loadManagerEmpList() {
    let endPoint = '/activityplanner/managers/' + this.userId + '/',
      expenseUser;
    endPoint += this.roles.UITripAccessAll ? '?permission=UITripAccessAll' : '';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadManagerEmpList()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.managerEmpList = data;
        this.populateStatusList();
        this.managersList = [...this.managerEmpList.managers];
        this.employeesList = this.managerEmpList.employees;
        this.employeesList = this._orderBy.transform(
          this.employeesList,
          'user_description',
          false
        );
        this.directReportees = this.employeesList.filter(
          (employee) => employee.direct_reportee === 'Y'
        );
        this.otherReportees = this.employeesList.filter(
          (employee) => employee.direct_reportee !== 'Y'
        );
        this.loginUser = {
          default_org_id: this.user.default_org_id,
          user_id: this.user.user_id,
          user_description: this.user.user_description + ' (me)',
          user_name: this.user.user_name,
        };
        this.employeesList.unshift(this.loginUser);
        if (
          this._dataService.fromState === '/expenses/manage' &&
          this._appService.activityEmployee
        ) {
          if (this._appService.activityEmployee) {
            // If the user is present in present in employee list and navigates back from expenses
            // Load the users expenses
            expenseUser = this.employeesList.find(
              (employee) =>
                employee.user_id === this._appService.activityEmployee
            );
            this.empSelected = expenseUser ? expenseUser.user_id : this.userId;
          } else {
            this.empSelected = this.userId;
          }
          this.showListView();
        } else {
          this.showSpinner = true;
          this.loadActivityDetails(
            this.fromDate,
            this.toDate,
            this.empSelected,
            (activityDetails) => {
              this.parseActivityDetails(activityDetails);
            },
            this.reportView
              ? { status: this.taskStatusSelected, comments: 'N' }
              : ''
          );
        }
      }
    });
  }

  loadUsers() {
    if (this._cacheService.backOfficeManagers) {
      this.allUsers = [...this._cacheService.backOfficeManagers];
    } else {
      this._commonService.loadPersons((data) => {
        this.allUsers = data;
      });
    }
  }

  loadUserChats(): void {
    const endPoint = `/activityplanner/chat/${this.empSelected}/${this.taskStatusSelected}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          msg: 'Server Error - loadUserChats()',
          status: 1,
        });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.parseChatThreads(data);
      }
    });
  }

  onDownload(attachment) {
    if (attachment.file_content) {
      this.downloadAttachment(attachment);
      return;
    }
    const endPoint = `/activityplanner/attachment/${attachment.file_id}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          msg: 'Server Error - onDownload()',
          status: 1,
        });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        attachment.file_content = data.file_content;
        this.downloadAttachment(attachment);
      }
    });
  }

  onUserSelect(user: ActivityPlannerUser): void {
    if (user.user_id) {
      this.empSelected = user.user_id;
      this.loadEmpActivities();
    }
  }

  openScope(): void {
    this.showTaskGoals = this.editAccess;
    if (
      (this.showTaskGoals &&
        this.extractContent(this.taskDetails.goals) === '') ||
      this.extractContent(this.taskDetails.goals) === null
    ) {
      this.taskDetails.goals = this.initDefaultText();
    }
  }

  parseActivityDetails(data, parseSelectedCards?) {
    let taskForComments;
    let commentDateArray;
    if (data.comments) {
      // When only updates, trips are fetched, find the respective tasks and assign the updates, trips
      data.comments.forEach((taskComments) => {
        taskForComments = this.filteredTasks.find(
          (task) => task.task_id === taskComments.task_id
        );
        if (taskForComments) {
          taskForComments.allComments = taskComments.comments;
          taskForComments.showAllComments = false;
          taskForComments.showAllUpdates = false;
          taskForComments.comments = taskForComments.allComments.filter(
            (comment) => comment.comment_type === 'C'
          );
          taskForComments.comments = this.formatGoalComments(
            taskForComments.comments
          );
          taskForComments.updates = taskForComments.allComments.filter(
            (comment) => comment.comment_type !== 'C'
          );
          taskForComments.updates = this.formatGoalComments(
            taskForComments.updates
          );
        }
      });
    } else {
      this.allTasks = [];
      this.completedTaskCount = data.completed_task_count;
      const tasks = data.tasks.filter((task) =>
        ['I', 'C', 'AR'].includes(task.status)
      );
      const fromDate = this.getDateInMillis(this.fromDate);
      const toDate = this.getDateInMillis(this.toDate);
      for (let i = 0; i < tasks.length; i++) {
        tasks[i].start_date = tasks[i].start_date_time
          ? this._formatService.formatDate(
              tasks[i].start_date_time.split(' ')[0]
            )
          : '';
        tasks[i].end_date = tasks[i].end_date_time
          ? this._formatService.formatDate(tasks[i].end_date_time.split(' ')[0])
          : '';
        tasks[i].showAllComments = false;
        tasks[i].showAllUpdates = false;
        tasks[i].allComments = tasks[i].comments;
        tasks[i].comments = tasks[i].allComments.filter(
          (comment) =>
            comment.comment_type === 'C' &&
            fromDate <= this.getDateInMillis(comment.created_date) &&
            this.getDateInMillis(comment.created_date) <= toDate
        );
        tasks[i].comments = this.formatGoalComments(tasks[i].comments);
        tasks[i].updates = tasks[i].allComments.filter(
          (comment) =>
            comment.comment_type !== 'C' &&
            fromDate <= this.getDateInMillis(comment.created_date) &&
            this.getDateInMillis(comment.created_date) <= toDate
        );
        tasks[i].updates = this.formatGoalComments(tasks[i].updates);

        if (tasks[i].tags) {
          tasks[i].taskTags = [];
          const tagIds = tasks[i].tags.split(',');
          tagIds.forEach((tagId) => {
            tasks[i].taskTags.push(
              this.taskTagList.find((tag) => tag.tag_id === parseInt(tagId))
            );
          });
        }
        tasks[i].task_user_name = this.getUserBadgeText(tasks[i].employee_name);
        if (tasks[i].created_id === this.user.user_id) {
          tasks[i].user_name = this.user.user_description;
        } else {
          const taskIndex = this.employeesList.findIndex(
            (employee) => employee.user_id === tasks[i].created_id
          );
          if (taskIndex !== -1) {
            tasks[i].user_name = this.employeesList[taskIndex].user_description;
          }
        }

        this.allTasks.push(tasks[i]);
      }

      this.allTasks = this._orderBy.transform(
        this.allTasks,
        'display_order',
        false
      );

      if (this.cardView && !parseSelectedCards) {
        this.parseDataForCards();
      } else if (this.reportView) {
        this.filteredTasks = [...this.allTasks];
      }
    }
    this.parseGoals(data);
    this.showSpinner = false;
  }

  parseAddedTrips(data) {
    this.allTrips = [];
    const trips = data.trips;
    let parsedStartDate;
    let parsedEndDate;
    let formattedDate;
    trips.forEach((trip) => {
      trip.checked = false;
      parsedStartDate = new Date(
        this._formatService.getStandardDateFormat(
          trip.start_date_time,
          'dd-MMM-yyyy'
        )
      );
      parsedEndDate = new Date(
        this._formatService.getStandardDateFormat(
          trip.end_date_time,
          'dd-MMM-yyyy'
        )
      );
      formattedDate =
        parsedStartDate.getDate().toString().padStart(2, '0') +
        '-' +
        this.shortMonths[parsedStartDate.getMonth()]
          .substr(0, 3)
          .toUpperCase() +
        '-' +
        parsedStartDate.getFullYear();
      trip.date_to_display = [];
      trip.startDateInMillis = this._formatService.dateInMillis(
        trip.start_date_time
      );
      trip.date_to_display.push(
        this.weekDay[parsedStartDate.getDay()],
        this._formatService.formatDate(formattedDate)
      );
      [
        trip.duration,
        trip.durationInSec,
      ] = ActivityPlannerComponent.calculateDuration(
        parsedEndDate,
        parsedStartDate
      );
      trip.start_date = this._formatService.formatDate(
        trip.start_date_time.split(' ')[0]
      );
      trip.end_date = this._formatService.formatDate(
        trip.end_date_time.split(' ')[0]
      );
      trip.start_time = ActivityPlannerComponent.parseTime(
        trip.start_date_time.split(' ')[1]
      );
      trip.end_time = ActivityPlannerComponent.parseTime(
        trip.end_date_time.split(' ')[1]
      );
      if (trip.created_id === this.user.user_id) {
        trip.user_name = this.user.user_description;
      } else {
        const tripIndex = this.employeesList.findIndex(
          (employee) => employee.user_id === trip.created_id
        );
        if (tripIndex !== -1) {
          trip.user_name = this.employeesList[tripIndex].user_description;
        }
      }
      this.allTrips.push(trip);
      trip.displayConditions = { delete: true };
    });
    this.showSpinner = false;
  }

  parseChatThreads(chatData) {
    this.resetChatThreads();
    this.chatThreads.forEach((threadType) => {
      const threadObj = threadType;
      threadObj.chats = chatData[threadObj.threadKey];
      // If chat role is present, user can view employees individual chats with him
      if (
        this.roles.UIActivityPlannerChat &&
        threadObj.threadKey === 'user_chats' &&
        this.empSelected !== this.userId
      ) {
        threadObj.chats = threadObj.chats.find(
          (chat) =>
            chat.chat_creator === this.userId ||
            chat.chat_recipient === this.userId
        );
        threadObj.chats = threadObj.chats
          ? [threadObj.chats]
          : [
              {
                id: null,
                description: this.user.user_description,
                type: 'chat',
              },
            ];
      }
      if (threadObj.chats.length && !this.selectedChat.type) {
        this.selectedChat.id = threadObj.chats[0].id;
        this.selectedChat.type = threadObj.chats[0].type;
        this.fetchCommentsForChat(this.selectedChat.type, this.selectedChat.id);
      }
    });
  }

  parseCommentsInActivities(commentsToBeAdded, commentId, type?): void {
    const goalIndex = this.goals.findIndex(
      (goal) => goal.id === this.taskDetails.goal.id
    );
    const taskIndex = this.goals[goalIndex].related_projects.findIndex(
      (task) => task.task_id === this.taskDetails.task_id
    );
    if (taskIndex !== -1) {
      const task = this.goals[goalIndex].related_projects[taskIndex];
      if (type === 'updates') {
        commentsToBeAdded.user_id = commentsToBeAdded.user_details[0].user_id;
        commentsToBeAdded.user_description =
          commentsToBeAdded.user_details[0].user_description;
        task.allComments.unshift(commentsToBeAdded);
        if (this.toggleAction === 'U') {
          task.updates.unshift(commentsToBeAdded);
        } else {
          task.comments.unshift(commentsToBeAdded);
        }
      } else {
        this.spliceData(task.allComments, 'comment_id', commentId);
        if (this.toggleAction === 'U') {
          this.spliceData(task.updates, 'comment_id', commentId);
        } else {
          this.spliceData(task.comments, 'comment_id', commentId);
        }
      }
    }
  }

  parseCommentsInGoals(comments, commentId, type): void {
    const goalIndex = this.goals.findIndex((goal) => goal.id === this.goal.id);
    if (goalIndex !== -1) {
      if (type === 'updates') {
        this.goals[goalIndex].comments.unshift(comments);
      } else {
        const commentIndex = this.goals[goalIndex].comments.findIndex(
          (comment) => comment.comment_id === commentId
        );
        if (commentIndex !== -1) {
          this.goals[goalIndex].comments.splice(commentIndex, 1);
        }
      }
    }
  }

  parseCommentsOrReply(
    comments,
    data,
    requestObj,
    activityType,
    editorId
  ): void {
    let commentToBeAdded = comments;
    commentToBeAdded.comment_id = data.comment_id;
    if (commentToBeAdded.comment_type === 'R') {
      commentToBeAdded.enableEdit = false;
    } else {
      commentToBeAdded.isSelf = commentToBeAdded.comment_type === 'C';
      if (requestObj.fromChat) {
        commentToBeAdded.user_description = this.user.user_description;
        commentToBeAdded = ActivityPlannerComponent.getCommentDisplaySettings(
          commentToBeAdded,
          this.chatComments,
          true
        );
        this.chatComments.push(commentToBeAdded);
        this.scrollToChatEnd();
        this.newChatComment = '';
      } else if (activityType === 'goal') {
        commentToBeAdded = ActivityPlannerComponent.getCommentDisplaySettings(
          commentToBeAdded,
          this.goal.comments
        );
        this.goal.comments.unshift(commentToBeAdded);
        this.parseCommentsInGoals(commentToBeAdded, data.comment_id, 'updates');
        if (this.reportView) {
          this.showReport();
        } else if (this.cardView) {
          this.showCardView();
        }
        this.newGoalComment = '';
        this.resetEditor(editorId, this.newGoalComment);
      } else if (activityType === 'task') {
        commentToBeAdded = ActivityPlannerComponent.getCommentDisplaySettings(
          commentToBeAdded,
          this.taskDetails.comments
        );
        this.taskDetails.comments.unshift(commentToBeAdded);
        this.toggleActions(this.toggleAction);
        if (this.toggleAction !== 'U') {
          this.newComment = '';
          this.resetEditor(editorId, this.newComment);
        } else {
          this.updateText = '';
          this.resetEditor(editorId, this.updateText);
        }
        this.parseCommentsInActivities(
          commentToBeAdded,
          data.comment_id,
          'updates'
        );
        this.showNewComment = false;
      }
    }
  }

  // Parsing data for card view
  parseDataForCards() {
    this.cards.forEach((card) => {
      if (card.id !== 'CO') {
        card.activities = this.allTasks.filter(
          (activity) =>
            activity.status === card.id &&
            activity.created_id === this.empSelected
        );
      } else {
        // Collaborated tasks which are not owned by the user
        card.activities = this.allTasks.filter(
          (activity) => activity.created_id !== this.empSelected
        );
      }
    });
  }

  parseExpensesData(data, selectedUser): void {
    this.allExpenses = [];
    this._expenseService.parseExpensesData(data, 'ALL', (parsedData) => {
      parsedData.forEach((expense) => {
        const expenseObj = expense;
        // If expense is in 'Draft' state, show delete option
        if (
          expenseObj.exp_status === 'Drafts' &&
          (expenseObj.created_by === this.userId ||
            expenseObj.employee_id === this.user.person_id)
        ) {
          expenseObj.displayConditions = { delete: true };
        }
        this.allExpenses.push(expenseObj);
      });
      /* Filter the user expenses only if they are assigned to the user
       irrespective of who created it */
      this.allExpenses = this.allExpenses.filter(
        (expense) => expense.employee_id === selectedUser.person_id
      );
      this.viewActivities();
      this.showSpinner = false;
    });
  }

  parseGoals(goalsData): void {
    if (goalsData.goals) {
      // If entire goal data is loaded, order them and group the related projects
      this.allGoals = [...goalsData.goals];
      if (this.reportView) {
        this.groupProjectsLinkedToGoals();
        if (this.goals[0]) {
          this.goals[0].minimize = false;
        }
      } else {
        this.allGoals.forEach((goal) => {
          const goalObj = goal;
          goalObj.goal_user_name = this.getUserBadgeText(
            goalObj.user_description
          );
        });
      }
    } else if (goalsData.goal_comments) {
      // If only comments are loaded based on dates, update the comments in report view
      this.parseGoalComments(goalsData.goal_comments);
    }
  }

  parseGoalComments(goalComments): void {
    goalComments.forEach((commentObj) => {
      const relatedGoal = this.goals.find((goal) => goal.id === commentObj.id);
      if (relatedGoal) {
        relatedGoal.comments = commentObj.comments || [];
        relatedGoal.comments = this.formatGoalComments(relatedGoal.comments);
      }
    });
  }

  // Parse the task details fetched to populate them in the template
  parseTaskDetails(data) {
    let tagIds;
    this.taskDetails = {};
    this.addFooPicker('task-from-date', 'task-to-date');
    this.taskTags = [];
    jQuery('body').css('overflow', 'hidden');
    data.tasks[0].start_date = data.tasks[0].start_date_time
      ? this._formatService.formatDate(
          data.tasks[0].start_date_time.split(' ')[0]
        )
      : '';
    data.tasks[0].end_date = data.tasks[0].end_date_time
      ? this._formatService.formatDate(
          data.tasks[0].end_date_time.split(' ')[0]
        )
      : '';
    data.tasks[0].is_trip = data.mapped_trips.length;
    data.tasks[0].comments = [];
    data.tasks[0].type = 'task';
    this.showActivityLog = false;
    this.showTaskCollaborators = false;
    this.showTaskDates = !!data.tasks[0].end_date;
    this.showTaskResults = false;
    this.showTaskGoals = false;
    this.disableTaskFields = false;
    this.taskDetails = data.tasks[0];
    this.taskDetails.goals = this.taskDetails.goals
      ? this._appService.replaceAll(this.taskDetails.goals, '\n', '<br>')
      : '';
    // replace all the id tags in the string using the regex condition id="([^\"]*?)"
    this.taskDetails.goals = this.taskDetails.goals.replaceAll(
      /id="([^\"]*?)"/g,
      ''
    );
    ActivityPlannerComponent.appendHTML('task-goals', this.taskDetails.goals);
    this.taskDetails.task_user_name = this.getUserBadgeText(
      this.taskDetails.employee_name
    );
    this.showSubTasks = false;
    this.editAccess = this.taskDetails.created_id === this.userId;
    this.collaborators = [...this.taskDetails.collaborators];
    this.taskDetails.collaborators.forEach((collaborator) => {
      collaborator.task_user_name = this.getUserBadgeText(
        collaborator.user_description
      );
    });
    if (this.taskDetails.tags) {
      tagIds = this.taskDetails.tags.split(',');
      tagIds.forEach((tagId) => {
        this.taskTags.push(
          this.taskTagList.find((tag) => tag.tag_id === parseInt(tagId))
        );
      });
    } else {
      this.taskDetails.tags = '';
    }
    this.taskDetails.sub_tasks.forEach((subTask) => {
      subTask.assigned_user_id = subTask.user_id;
      subTask.task_user_name = this.getUserBadgeText(subTask.user_description);
      subTask.due_date = subTask.due_date
        ? this._formatService.formatDate(subTask.due_date, this.dateFormat)
        : '';
      subTask.old_title = subTask.sub_task_title;
      subTask.completed = subTask.sub_task_priority === 'Y';
    });
    if (this.taskDetails.goal[0]) {
      this.taskDetails.goal = this.taskDetails.goal[0];
      this.showGoalLink = false;
      this.selectedGoal = this.taskDetails.goal.id;
    } else {
      this.taskDetails.goal = {};
      this.showGoalLink = this.taskDetails.created_id === this.userId;
      this.selectedGoal = null;
    }
    this.showGoalError = false;
    this.taskDetails.activityLog = [];
    this.taskDetails.sub_tasks = this._orderBy.transform(
      this.taskDetails.sub_tasks,
      'sub_task_display_order',
      false
    );
    this.oldTaskDetails = { ...this.taskDetails };
    this.previousTaskDate = this.oldTaskDetails.end_date;
    this.showAddTask = true;
    this.fetchComments('task');
  }

  // Convert 24 hour time format to 12 hour time format
  static parseTime(time) {
    let timeArr, timeStr, hours, hourStr;
    timeArr = time.split(':');
    hours = parseInt(timeArr[0]);
    if (hours > 12) {
      hourStr = hours - 12;
    } else {
      hourStr = hours === 0 ? 12 : hours;
    }
    hourStr = hourStr < 10 ? '0' + hourStr : hourStr;
    timeStr = hourStr + ':' + timeArr[1] + (hours < 12 ? ' AM' : ' PM');
    return timeStr;
  }

  // Parse the trip details fetched to populate them in the template
  parseTripDetails(data) {
    let tmpObj: any = {};
    let destStartDate;
    let destEndDate;
    const trip = data.trips[0];
    let index;
    this.focusTripDescription = true;
    this.listView = false;
    this.tasksLinkedToTrip = [];
    trip.destinations = [];
    trip.lines.forEach((dest) => {
      tmpObj = {
        line_id: dest.line_id,
        from: dest.from_location,
        focusFrom: true,
        to: dest.to_location,
        focusTo: true,
        startDate: this._formatService.formatDate(
          dest.start_date_time.split(' ')[0]
        ),
        focusStartDate: true,
        endDate: this._formatService.formatDate(
          dest.end_date_time.split(' ')[0]
        ),
        focusEndDate: true,
        startTime: ActivityPlannerComponent.parseTime(
          dest.start_date_time.split(' ')[1]
        ),
        endTime: ActivityPlannerComponent.parseTime(
          dest.end_date_time.split(' ')[1]
        ),
        focusEndTime: true,
        budgetList: [
          {
            name: 'Primary Transport',
            type: this.primaryTransportList[0],
            focus: true,
            typePresent: true,
            list: this.primaryTransportList,
            required: true,
            value: { value: null, type: this.defaultCurrency },
          },
          {
            name: 'Accomodation Budget',
            focus: true,
            value: { value: null, type: this.defaultCurrency },
          },
          {
            name: 'Meals Budget',
            focus: true,
            value: { value: null, type: this.defaultCurrency },
          },
          {
            name: 'Other Transport',
            type: '',
            focus: true,
            list: this.otherTransportList,
            typePresent: true,
            value: { value: null, type: this.defaultCurrency },
          },
          {
            name: 'Other Expenses',
            focus: true,
            value: { value: null, type: this.defaultCurrency },
          },
        ],
        totalBudget: 0,
        goals: dest.goals,
        focusGoals: true,
        results: dest.results,
        showFull: false,
      };
      dest.budget_list.forEach((budget) => {
        index = tmpObj.budgetList
          .map((value) => value.name)
          .indexOf(budget.budget_type);
        if (index !== -1) {
          tmpObj.budgetList[index].id = budget.budget_id;
          tmpObj.budgetList[index].type = budget.budget_value;
          tmpObj.budgetList[index].value = {
            value: budget.expense_amount,
            type: budget.currency_code,
          };
        }
      });
      tmpObj.totalBudget = tmpObj.budgetList[0].value;
      tmpObj.totalBudget.value = this._formatService.numberParser(
        tmpObj.totalBudget.value
      );
      destStartDate = new Date(
        this.combineDateTime(tmpObj.startDate, tmpObj.startTime)
      );
      destEndDate = new Date(
        this.combineDateTime(tmpObj.endDate, tmpObj.endTime)
      );
      [
        tmpObj.duration,
        tmpObj.durationInSec,
      ] = ActivityPlannerComponent.calculateDuration(
        destStartDate,
        destEndDate
      );
      trip.destinations.push(tmpObj);
      this.addFooPicker(
        'dest-start-' + (trip.destinations.length - 1),
        'dest-end-' + (trip.destinations.length - 1)
      );
    });
    trip.attachments.map(
      (task) =>
        (task.created_date = this._formatService.formatDate(task.created_date))
    );
    trip.comments = [];
    trip.showComments = false;
    trip.type = 'trip';
    this.trip = trip;
    this.initialTripDetails = JSON.parse(JSON.stringify(trip));
  }

  // Populate the status list according to the user role
  populateStatusList() {
    if (this.roles.UITripAccessAll || this.user.user_id === this.empSelected) {
      // All Access user can see all the statuses
      this.approvalStatusListFiltered = [...this.approvalStatusList];
    } else {
      // Manager can only see tasks/trips of his employees which are 'Under review`, 'Approved' and 'Rejected'
      this.approvalStatusListFiltered = this.approvalStatusList.filter(
        (status) => ['Processing', 'Approved', 'Rejected'].includes(status.id)
      );
    }
  }

  // Populate the list of time values for time drop downs
  populateTimeList() {
    let timeStr;
    let hourStr;
    for (let i = 0; i < 24; i++) {
      if (i > 12) {
        hourStr = i - 12;
      } else {
        hourStr = i === 0 ? 12 : i;
      }
      hourStr = hourStr < 10 ? '0' + hourStr : hourStr;
      for (let j = 0; j < 60; j = j + 15) {
        timeStr = hourStr + ':' + (j === 0 ? '00' : j);
        timeStr += i >= 12 ? ' PM' : ' AM';
        this.timeList.push(timeStr);
      }
    }
  }

  // Remove a destination from a trip
  removeDestination(dest, index) {
    if (dest.line_id) {
      this.deletedDestinations.push(dest.line_id);
    }
    this.trip.destinations.splice(index, 1);
  }

  resetChatThreads(): void {
    this.chatThreads = [
      {
        threadName: 'Goals',
        threadKey: 'goal_chats',
        chats: [],
      },
      {
        threadName: 'Activities',
        threadKey: 'project_chats',
        chats: [],
      },
    ];
    // User chats of employees are not visible if chat role is not present
    if (this.roles.UIActivityPlannerChat || this.empSelected === this.userId) {
      this.chatThreads.unshift({
        threadName: 'Users',
        threadKey: 'user_chats',
        chats: [],
      });
    }
    this.resetSelectedChat();
  }

  resetEditor(editorId, comment): void {
    this.maxCharErrFlag = false;
    this.charCount = comment.replace(this.regexTags, '').length;
    this.editorFlag[editorId] = false;
  }

  // Reset the status and activity type filters
  resetFilters() {
    this.approvalStatusList.forEach((status) => {
      status.isChecked = true;
    });
    this.empSelected = this.userId;
  }

  resetSelectedChat(): void {
    this.selectedChat.id = null;
    this.selectedChat.type = '';
    this.chatComments = [];
  }

  saveActivityLog(msg, taskId) {
    let endPoint = '/activityplanner/log/',
      reqObj;
    reqObj = {
      task_id: taskId,
      log_message: msg,
      created_id: this.userId,
      created_date: `${this._appService.today(0)} ${this.getCurrentTime()}`,
    };
    this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - saveActivityLog()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (this.showAddTask) {
        reqObj.user_id = this.userId;
        reqObj.user_description = this.user.user_description;
        reqObj.task_user_name = this.getUserBadgeText(reqObj.user_description);
        reqObj.date = `${this._formatService.formatDate(
          this._appService.today(0),
          this.dateFormat
        )}
        \xa0\xa0${this.getCurrentTime()}`;
        this.taskDetails.activityLog.unshift(reqObj);
      }
    });
  }

  saveCollaborators(taskId) {
    let addOrDeleteUser,
      reqObj,
      endPoint = '/activityplanner/collaborators/';
    this.newCollaborators = [];
    this.deleteCollaborators = [];

    /*Check which collaborators have been deleted and populate the respective array
     * Here this.taskDetails.collaborators is the initial collaborator list fetched and
     * this.collaborators is the manipulated list in which users have been added and deleted*/
    this.taskDetails.collaborators.forEach((user) => {
      addOrDeleteUser = this.collaborators.find(
        (collaborator) => collaborator.user_id === user.user_id
      );
      !addOrDeleteUser ? this.deleteCollaborators.push(user.user_id) : '';
    });
    // Check which collaborators have been newly added and populate the respective array
    this.collaborators.forEach((user) => {
      addOrDeleteUser = this.taskDetails.collaborators.find(
        (collaborator) => collaborator.user_id === user.user_id
      );
      !addOrDeleteUser ? this.newCollaborators.push(user.user_id) : '';
    });
    if (this.newCollaborators.length || this.deleteCollaborators.length) {
      reqObj = {
        add_user_ids: this.newCollaborators,
        delete_user_ids: this.deleteCollaborators,
        task_id: taskId,
        created_id: 1,
      };
      this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - saveCollaborators()',
          });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      });
    }
  }

  saveComment(activityType, comment, editorId, fromChat?) {
    this.saveCommentOrReply(activityType, editorId, {
      comment_type:
        activityType === 'task' && this.toggleAction === 'U' && !fromChat
          ? 'U'
          : 'C',
      comment_data: comment
        ? this._appService.replaceAll(comment, '\n', '')
        : '',
      parent_id: '',
      comment_user_name: this.getUserBadgeText(this.user.user_description),
      showReplyOption: true,
      showDeleteOption: true,
      replies: [],
      fromChat,
    });
  }

  async saveCommentOrReply(activityType, editorId, requestObject) {
    let commentedDate = this._appService.today(0);
    const commentToBeAdded = requestObject;
    if (!commentToBeAdded.comment_data) {
      if (commentToBeAdded.comment_type === 'C') {
        commentToBeAdded.showReplyOption = true;
      }
      return;
    }

    // If commenting is for current week then create date will be today's date otherwise
    // take the saving weeks last date as created date
    if (commentToBeAdded.comment_type === 'C') {
      commentedDate =
        this.displayWeek !== this.currentWeekNum
          ? this._formatService.parseDate(this.displayToDate)
          : commentedDate;
    }
    commentToBeAdded.created_date = `${commentedDate} ${this.getCurrentTime()}`;
    commentToBeAdded.displayDate = `${this._formatService.formatDate(
      commentedDate,
      this.dateFormat
    )}
      \xa0\xa0${ActivityPlannerComponent.parseTime(this.getCurrentTime())}`;
    commentToBeAdded.user_details = [
      {
        user_id: this.user.user_id,
        user_description: this.user.user_description,
      },
    ];
    commentToBeAdded.created_id = this.user.user_id;
    if (requestObject.fromChat) {
      if (!this.selectedChat.id) {
        await this.createChatThread();
      }
      commentToBeAdded.activity_id = this.selectedChat.id;
    } else if (activityType === 'goal') {
      commentToBeAdded.activity_id = this.goal.id;
    } else if (activityType === 'task') {
      commentToBeAdded.activity_id = this.taskDetails.task_id;
    }
    commentToBeAdded.activity_type = activityType;
    this._activityPlannerService
      .saveCommentsOrReply(commentToBeAdded)
      .then((data) => {
        this.parseCommentsOrReply(
          commentToBeAdded,
          data,
          requestObject,
          activityType,
          editorId
        );
      })
      .catch((err) => {
        this.showSpinner = false;
        this._appService.notify(err);
      });
  }

  saveGoal() {
    let endPoint = '/activityplanner/goal/',
      method,
      existingGoalIndex,
      reqObj: any = {
        name: this.goal.name,
        description: this.goal.description
          ? this._appService.replaceAll(this.goal.description, '\n', '')
          : '',
      };
    // replace all the id tags in the string using the regex condition id="([^\"]*?)"
    reqObj.description = reqObj.description.replaceAll(/id="([^\"]*?)"/g, '');
    if (this.goal.isNew) {
      method = 'POST';
      reqObj.created_id = this.userId;
    } else {
      method = 'PUT';
      reqObj.id = this.goal.id;
      reqObj.recent_updated_user_id = this.userId;
    }
    this._httpService.httpRequest(method, endPoint, reqObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - saveGoal()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (data.status === 0) {
        this.goal.goal_user_name = this.getUserBadgeText(
          this.user.user_description
        );
        if (this.goal.isNew) {
          this.goal.isNew = false;
          this.goal.id = data.goal_id;
          this.goal.user_id = this.userId;
          this.focusTextEditor();
          this.allGoals.push(this.goal);
        } else if (this.reportView) {
          this.filterTasks();
        } else {
          // If the task already exists in the list update it with the latest values
          existingGoalIndex = this.allGoals.findIndex(
            (goal) => goal.id === this.goal.id
          );
          if (existingGoalIndex !== -1) {
            this.allGoals[existingGoalIndex].name = this.goal.name;
          }
        }
        this.oldGoal = { ...this.goal };
      }
    });
  }

  saveSubTask(subTask) {
    if (!subTask.sub_task_title) {
      subTask.sub_task_title = subTask.old_title || '';
      return;
    }
    let collaborator,
      method,
      endPoint = `/activityplanner/subtask/`,
      reqObj: any = {
        task_id: this.taskDetails.task_id,
        sub_task_title: subTask.sub_task_title,
        assigned_user_id: subTask.assigned_user_id || '',
        sub_task_description: this.subTask.sub_task_description
          ? this._appService.replaceAll(
              this.subTask.sub_task_description,
              '\n',
              ''
            )
          : '',
        sub_task_display_order: subTask.sub_task_display_order,
        sub_task_priority: subTask.completed ? 'Y' : 'N', // We're saving sub task status in this field
        due_date: subTask.due_date
          ? this._formatService.parseDate(subTask.due_date, this.dateFormat)
          : '',
      };
    // replace all the id tags in the string using the regex condition id="([^\"]*?)"
    reqObj.sub_task_description = reqObj.sub_task_description.replaceAll(
      /id="([^\"]*?)"/g,
      ''
    );
    if (subTask.is_new) {
      method = 'POST';
      reqObj.created_id = this.userId;
    } else {
      method = 'PUT';
      reqObj.recent_updated_user_id = this.userId;
      reqObj.sub_task_id = subTask.sub_task_id;
    }
    this._httpService.httpRequest(method, endPoint, reqObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - saveSubTask()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (data.status === 0) {
        if (subTask.is_new) {
          subTask.is_new = false;
          subTask.sub_task_id = data.sub_task_id;
          subTask.old_title = subTask.sub_task_title;
        }
        // Add the assignee as a collaborator to the project if he isn't already a collaborator
        if (
          reqObj.assigned_user_id &&
          reqObj.assigned_user_id !== this.taskDetails.created_id &&
          !this.collaborators.some(
            (collaboratorDet) =>
              collaboratorDet.user_id === reqObj.assigned_user_id
          )
        ) {
          collaborator = this.allUsers.find(
            (collaboratorDet) =>
              collaboratorDet.employee_number === reqObj.assigned_user_id
          );
          this.collaborators.push({
            user_id: collaborator.employee_number,
            user_description: collaborator.user_description,
            task_user_name: this.getUserBadgeText(
              collaborator.user_description
            ),
          });
        }
      }
    });
  }

  saveSubTaskOrder() {
    let endPoint = '/activityplanner/subtask/order/',
      reqObj = {
        sub_task_order: this.taskDetails.sub_tasks.map((subTask, index) => {
          return {
            sub_task_id: subTask.sub_task_id,
            sub_task_display_order: index,
          };
        }),
      };
    this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - saveSubTaskOrder()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  saveTaskDetails() {
    let reqData, endPoint;
    if (!this.taskDetails.description || !this.taskDetails.goal.id) {
      return;
    } else {
      this.taskDetails.goals = this.taskDetails.goals
        ? this._appService.replaceAll(this.taskDetails.goals, '\n', '')
        : '';
      // replace all the id tags in the string using the regex condition id="([^\"]*?)"
      this.taskDetails.goals = this.taskDetails.goals.replaceAll(
        /id="([^\"]*?)"/g,
        ''
      );
      reqData = { ...this.taskDetails };
      if (reqData.hasOwnProperty('task_id')) {
        endPoint = '/activityplanner/task/update/';
        reqData.attachments = [];
        reqData.delete_attachments = [];
        reqData.recent_updated_user_id = this.userId;
      } else {
        this.disableTaskFields = true;
        endPoint = '/activityplanner/task/add/';
        reqData.map_trip = {};
      }
      reqData.task_description =
        this.taskDetails.description || this.oldTaskDetails.description;
      reqData.end_date = reqData.end_date
        ? this._formatService.parseDate(reqData.end_date, this.dateFormat) +
          ' 06:00:00 PM'
        : '';
      reqData.start_date = reqData.end_date;
      reqData.tags = this.taskTags.map((tag) => tag.tag_id).join(',');
      this._httpService.httpRequest('POST', endPoint, reqData, (data) => {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - saveTask()',
          });
        } else if (data.status === 0) {
          if (this.listView) {
            this.loadAllExpenses();
          } else {
            this.loadActivityDetails(
              this.fromDate,
              this.toDate,
              this.empSelected,
              (activityDetails) => {
                this.parseActivityDetails(activityDetails);
              }
            );
          }
          this.taskDetails.task_id = data.task_id;
          if (this.taskDetails.is_new) {
            this.linkOrUnLinkGoal('Link', this.taskDetails.task_id);
            this.focusTextEditor();
            this.saveActivityLog('This project has been created', data.task_id);
          }
          this.taskDetails.is_new = false;
          this.oldTaskDetails = { ...this.taskDetails };
          this.disableTaskFields = false;
        } else if (data.status === 1) {
          this.showAddTask = false;
          this._appService.notify({ status: data.status, msg: data.msg });
        }
      });
    }
  }

  saveTaskOrder(listsToBeOrdered) {
    let endPoint = '/activityplanner/task/order/',
      listOfTasks = [],
      reqObj,
      filteredCards;
    if (listsToBeOrdered.includes('G')) {
      this.allGoals.forEach((goal, index) => {
        listOfTasks.push({
          task_id: goal.id,
          status: 'G',
          display_order: index,
        });
      });
    } else {
      filteredCards = this.cards.filter(
        (card) => listsToBeOrdered.includes(card.id) && card.activities.length
      );
      // Save the order of the card lists that are not minimized for the current user
      if (filteredCards.length) {
        filteredCards.forEach((card) => {
          // Prepare a single list of tasks for all cards
          listOfTasks.push(
            ...card.activities.map((activity, index) => {
              return {
                task_id: activity.task_id,
                status: card.id,
                display_order: index,
              };
            })
          );
        });
      }
    }
    if (listOfTasks.length) {
      reqObj = {
        task_order: listOfTasks,
        task_status: listsToBeOrdered,
        user_id: this.userId,
      };
      this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - saveTaskOrder()',
          });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      });
    }
  }

  // Save trip details
  saveTrip() {
    let endPoint;
    let lineObj;
    let reqObj;
    if (!this.validateTripDetails()) {
      return;
    }
    this.calculateTripDateTime();
    reqObj = {
      start_date_time: this.trip.startDateTime,
      end_date_time: this.trip.endDateTime,
      trip_description: this.trip.description,
      org_id: this.orgId,
      approver_id: this.roles.isCEO
        ? this.userId
        : this.managersList[0].manager_id,
      user_comments: '',
      approver_comments: '',
      lines: [],
      attachments: [],
      map_task: {},
    };
    if (!this.trip.isNew) {
      // If only results are changed the status remains the same
      if (!this.checkTripFieldChanges(this.trip)) {
        reqObj.status = this.trip.status;
      } else {
        reqObj.status = this.trip.status === 'P' ? 'P' : 'D';
      }
      reqObj.trip_id = this.trip.trip_id;
      reqObj.created_id = this.trip.created_id;
      reqObj.recent_updated_user_id = this.userId;
      reqObj.delete_attachments = this.tripDeleteAttachments;
      reqObj.delete_lines = this.deletedDestinations;
      this.deletedDestinations = [];
      this.tripDeleteAttachments = [];
      endPoint = '/activityplanner/trip/update/';
    } else {
      reqObj.status = 'P';
      reqObj.created_id = this.userId;
      reqObj.map_task.tasks = this.tasksLinkedToTrip.map((task) => task.id);
      reqObj.map_task.created_id = this.userId;
      endPoint = '/activityplanner/trip/add/';
    }
    reqObj.time_zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    reqObj.attachments = this.trip.attachments.filter(
      (attachment) => !attachment.file_id
    );
    this.trip.destinations.forEach((destination) => {
      lineObj = this.saveTripReqDestination(destination);
      reqObj.lines.push(lineObj);
    });
    this.showSpinner = true;
    this._activityPlannerService
      .saveTripDetails(endPoint, 'POST', reqObj)
      .then((data) => {
        this._appService.notify(data);
        this.resetFilters();
        this.tripView = false;
        this.showAddedTrips(false);
        this.closeTrip();
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
      });
  }

  saveTripReqDestination(destination) {
    let lineObj;
    const startDateTime = this.combineDateTime(
      destination.startDate,
      destination.startTime
    );
    const endDateTime = this.combineDateTime(
      destination.endDate,
      destination.endTime
    );
    lineObj = {
      line_id: destination.line_id || null,
      from_location: destination.from,
      to_location: destination.to,
      start_date_time: startDateTime,
      end_date_time: endDateTime,
      goals: destination.goals,
      results: destination.results || '',
      budget_list: [],
    };

    destination.budgetList.forEach((budget) => {
      if (budget.value) {
        const budgetVal = this._formatService.parseNumber(
          budget.value.value,
          this.numberFormat
        );
        if (
          budgetVal &&
          ((budget.typePresent && budget.type) || !budget.typePresent)
        ) {
          lineObj.budget_list.push({
            budget_id: budget.id || null,
            budget_type: budget.name,
            expense_amount: budgetVal,
            currency_code: budget.value.type,
            budget_value: budget.type || '',
          });
        }
      }
    });
    return lineObj;
  }

  saveUnSavedActivities(btnType, activityType): void {
    if (btnType === 'save') {
      if (this.editorFlag['task-update']) {
        this.toggleAction = 'U';
        this.saveComment(activityType, this.updateText, 'task-update');
      }
      if (this.editorFlag['task-comment']) {
        this.toggleAction = 'C';
        this.saveComment(activityType, this.newComment, 'task-comment');
      }
      if (this.editorFlag['goal-comment-editor']) {
        this.saveComment(
          activityType,
          this.newGoalComment,
          'goal-comment-editor'
        );
      }
    }
    this.unsavedDialog = false;
    setTimeout(() => {
      if (activityType === 'task') {
        this.newComment = '';
        this.updateText = '';
        this.resetEditor('task-comment', this.newComment);
        this.resetEditor('task-update', this.updateText);
        this.closeTask();
      } else {
        this.newGoalComment = '';
        this.resetEditor('goal-comment-editor', this.updateText);
        this.closeGoal();
      }
    }, 1000);
  }

  scrollToChatEnd() {
    setTimeout(() => {
      this._appService.scrollTo(
        '#comment-thread',
        jQuery('#comment-thread')[0].scrollHeight
      );
    });
  }

  selectAction(event): void {
    if (event.action === 'icon-trash2') {
      this.showDeleteActivityModal(event.data);
    }
  }

  selectTaskAssignee(subTask) {
    let user_name = this.allUsers.find(
      (user) =>
        user.employee_number ===
        (parseInt(subTask.assigned_user_id) || this.userId)
    ).user_description;
    subTask.user_description = user_name;
    subTask.task_user_name = this.getUserBadgeText(user_name);
    this.subTask = { ...subTask };
  }

  setChatId(): void {
    // Set the chat Id for a newly created individual chat, so that comments can be added to this chat
    const user_chats = this.chatThreads.find(
      (thread) => thread.threadKey === 'user_chats'
    );
    const selectedChat = user_chats.chats.find((chat) => !chat.id);
    if (selectedChat) {
      selectedChat.id = this.selectedChat.id;
    }
  }

  setCommentMargins(comment): any {
    // Set comment margins based on the presence of user name and badge for the comment
    return { 'margin-top': comment.hideAvatar ? '' : '5px' };
  }

  setUpDOMHandlers() {
    let hideBlocks = [
      '#trip-sync-options',
      '#task-sync-options',
      '#task-statuses',
      '#task-options',
      '#trip-statuses',
      '#task-tags',
      '.task-assign-user',
      '#goal-options',
    ];

    // Close the sync options modal on clicking anywhere in DOM
    jQuery(document).mouseup((e) => {
      e.stopPropagation();

      hideBlocks.forEach((block) => {
        if (block.startsWith('#') && jQuery(block).css('display') === 'block') {
          jQuery(block).css({ display: 'none' });
        } else if (block.startsWith('.')) {
          jQuery(block).each((index, element) => {
            if (
              !jQuery(element).has(e.target).length &&
              jQuery(element).css('display') === 'block'
            ) {
              jQuery(element).css({ display: 'none' });
              const blockCode = () =>
                block === '.task-assign-user' &&
                element.id !== 'task-collaborators'
                  ? this.saveSubTask(this.subTask)
                  : '';
              blockCode();
            }
          });
        }
      });
    });

    // if the task card is open and the page is scrolled then the
    // task close icon should be made sticky
    jQuery('.task-details-wrapper').scroll(() => {
      if (this.showAddTask) {
        // 10 is the default position from top for the task-close div
        let scrollPos = jQuery('.task-details-wrapper').scrollTop() + 10;
        jQuery('.task-details-wrapper .task-close').css({
          top: scrollPos + 'px',
        });
      }
    });

    // by default scroll the task details card upto goals
    if (this.showAddTask) {
      let scrollPos = jQuery('.task-action-container').offset().top;
      jQuery('.task-details-wrapper').animate(
        {
          scrollTop: scrollPos,
        },
        300
      );
    }

    jQuery('.tool-tip-item').click((event) => {
      event.stopPropagation();
    });
  }

  showAddedTrips(flag = true) {
    if (!this.tripView) {
      this._appService.scrollTop();
      this.listView = true;
      this.tripView = true;
      this.expenseView = false;
      this.showAddTrip = false;
      this.showSpinner = flag;
      this.updateDatesForView(false, true);
      jQuery('body').css('overflow', 'auto');
    }
  }

  showAssignTaskDialog(index) {
    this.showBlock(`#task-assign-user-${index}`);
    this.focusField(`task-assign-input-${index}`);
  }

  showBlock(activityType) {
    if (activityType === 'task' && this.editAccess) {
      jQuery('#task-statuses').css('display', 'block');
    } else if (activityType === 'trip') {
      jQuery('#trip-statuses').css('display', 'block');
    } else {
      jQuery(activityType).css('display', 'block');
    }
  }

  showCardView(isOnlyGoals = false): void {
    const fromDate = ActivityPlannerComponent.createDates(
      this.today.getFullYear(),
      0,
      1
    );
    const toDate = ActivityPlannerComponent.createDates(
      this.today.getFullYear(),
      11,
      1
    );
    this.listView = false;
    this.expenseView = false;
    this.tripView = false;
    this.reportView = false;
    this.chatView = false;
    this.cardView = true;
    this.isOnlyGoals = isOnlyGoals;
    this.showSpinner = true;
    this.reportViewPeriod = this.viewSelected;
    this.loadActivityDetails(fromDate, toDate, this.empSelected, (data) => {
      this.parseActivityDetails(data);
    });
  }

  showChat() {
    this.reportView = false;
    this.listView = false;
    this.expenseView = false;
    this.tripView = false;
    this.cardView = false;
    this.chatView = true;
    this.loadUserChats();
  }

  showDeleteActivityModal(activity, fromActivity?) {
    this.deleteActivityDialog = true;
    this.activityDeleteDetails = activity;
    this.activityDeleteDetails.fromActivity = fromActivity;
    if (this.activityDeleteDetails.type === 'Goal') {
      this.activityDeleteDetails.displayName = `Goal: ${this.activityDeleteDetails.name}`;
    } else if (this.activityDeleteDetails.type === 'task') {
      this.activityDeleteDetails.displayName = `Activity: ${this.activityDeleteDetails.description}`;
    } else if (this.activityDeleteDetails.type === 'sub-task') {
      this.activityDeleteDetails.displayName = `Task: ${this.activityDeleteDetails.sub_task_title}`;
    } else if (this.activityDeleteDetails.type === 'trip') {
      this.activityDeleteDetails.displayName = `Trip: ${this.activityDeleteDetails.description}`;
    } else if (this.activityDeleteDetails.comment_type) {
      this.activityDeleteDetails.displayName =
        this.activityDeleteDetails.comment_type === 'U' ? 'Update' : 'Comment';
    } else {
      this.activityDeleteDetails.displayName = `Expense: ${this.activityDeleteDetails.report_header_id}`;
    }
  }

  showExpenses(): void {
    if (!this.expenseView) {
      this._appService.scrollTop();
      this.listView = true;
      this.expenseView = true;
      this.tripView = false;
      this.viewSelected = 'Year';
      this.updateDatesForView(false, true);
      jQuery('body').css('overflow', 'auto');
    }
  }

  showGoalTable(): void {
    this.viewGoalCard = !this.viewGoalCard;
    if (this.viewGoalCard) {
      this.addActivityDescriptionsInReport();
    }
  }

  showListView() {
    if (!this.listView) {
      this._appService.scrollTop();
      this.listView = true;
      this.expenseView = true;
      this.showAddTrip = false;
      this.cardView = this.reportView = false;
      this.chatView = false;
      this.reportViewPeriod = this.viewSelected;
      this.viewSelected = 'Year';
      this.updateDatesForView(false, true);
      if (!this.allGoals.length) {
        this.loadActivityDetails(
          this.fromDate,
          this.toDate,
          this.empSelected,
          (data) => {
            this.parseActivityDetails(data);
          }
        );
      }
      jQuery('body').css('overflow', 'auto');
    }
  }

  showReport() {
    this.reportView = true;
    this.cardView = false;
    this.listView = false;
    this.expenseView = false;
    this.tripView = false;
    this.chatView = false;
    this.viewSelected = this.reportViewPeriod;
    this.updateDatesForView(false);
    this.filterTasks();
  }

  showSubTask(subTask) {
    this.showSubTaskDetails = true;
    this.subTask = { ...subTask };
    this.subTask.type = 'sub-task';
    this.showSubTaskDesc = !this.subTask.sub_task_description;
    this.showSubTaskDate = !!this.subTask.due_date;
    this.subTask.sub_task_description = this.subTask.sub_task_description
      ? this._appService.replaceAll(
          this.subTask.sub_task_description,
          '\n',
          '<br>'
        )
      : '';
    // replace all the id tags in the string using the regex condition id="([^\"]*?)"
    this.subTask.sub_task_description = this.subTask.sub_task_description.replaceAll(
      /id="([^\"]*?)"/g,
      ''
    );
    ActivityPlannerComponent.appendHTML(
      'sub-task-description',
      this.subTask.sub_task_description
    );
  }

  showSyncOptions(type) {
    jQuery(`#${type}-sync-options`).css('display', 'block');
  }

  showTask(status?) {
    /* If no goals are present for a user, he/she is prompted to add a goal
       before adding a project */
    if (!this.allGoals.length) {
      this._appService.notify({
        status: 1,
        msg: 'No Goals added! Please add a goal first, to create a project.',
        details: 'In-order to create a project, a goal has to be linked to it.',
      });
      return;
    }
    this.taskDetails = {};
    this.showAddTask = true;
    this.focusField('task-title');
    this.addFooPicker('task-from-date', 'task-to-date');
    jQuery('body').css('overflow', 'hidden');
    this.addTaskModelOpen(status);
  }

  showTaskTags() {
    if (this.editAccess) {
      jQuery('#task-tags').css('display', 'block');
    }
  }

  showTrip() {
    this._appService.scrollTop();
    this.showViewScreen = false;
    this.showAddTrip = true;
    this.tripErrorMessage = '';
    this.focusTripDescription = true;
    this.tasksLinkedToTrip = [];
    this.trip = {
      approver_id: this.roles.isCEO
        ? this.userId
        : this.managersList[0].manager_id,
      description: '',
      destinations: [
        {
          from: '',
          focusFrom: true,
          to: '',
          focusTo: true,
          startDate:
            this._formatService.formatDate(
              this._appService.addDate,
              this.dateFormat
            ) || '',
          focusStartDate: true,
          endDate: '',
          focusEndDate: true,
          startTime: '09:00 AM',
          endTime: '08:00 PM',
          focusEndTime: true,
          budgetList: [
            {
              name: 'Primary Transport',
              type: this.primaryTransportList[0],
              focus: true,
              typePresent: true,
              list: this.primaryTransportList,
              required: true,
              value: { value: null, type: this.defaultCurrency },
            },
            {
              name: 'Accomodation Budget',
              focus: true,
              value: { value: null, type: this.defaultCurrency },
            },
            {
              name: 'Meals Budget',
              focus: true,
              value: { value: null, type: this.defaultCurrency },
            },
            {
              name: 'Other Transport',
              type: '',
              focus: true,
              list: this.otherTransportList,
              typePresent: true,
              value: { value: null, type: this.defaultCurrency },
            },
            {
              name: 'Other Expenses',
              focus: true,
              value: { value: null, type: this.defaultCurrency },
            },
          ],
          totalBudget: 0,
          goals: '',
          focusGoals: true,
          results: '',
          showFull: true,
        },
      ],
      isNew: true,
      attachments: [],
    };
    this._appService.addDate = null;
    this.addFooPicker('dest-start-0', 'dest-end-0');
  }

  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = true;
    }
  }

  spliceData(data, idName, id): void {
    let index = data.findIndex((obj) => obj[idName] === id);
    if (index !== -1) {
      data.splice(index, 1);
    }
  }

  toggleActions(action) {
    this.toggleAction = action;
    switch (action) {
      case 'C':
        this.taskDetails.actionItems = this.taskDetails.comments.filter(
          (item) => item.comment_type === 'C'
        );
        break;
      case 'U':
        this.taskDetails.actionItems = this.taskDetails.comments.filter(
          (item) => item.comment_type === 'U' || item.comment_type === 'A'
        );
        break;
      default:
        break;
    }
    this.toggleComment(action);
    if (action !== 'A') {
      this.focusTextEditor();
    }
  }

  toggleActivityLog() {
    if (!this.showActivityLog) {
      this.toggleAction = 'A';
      this.showActivityLog = true;
      this.fetchActivityLog();
    } else {
      this.showActivityLog = false;
      this.toggleActions('U');
    }
  }

  toggleComment(action): void {
    if (action === 'C') {
      this.newComment = this.editorFlag['task-comment'] ? this.newComment : '';
    } else {
      this.updateText = this.editorFlag['task-update'] ? this.updateText : '';
    }
  }

  toggleRelatedActivities(goal, goalIndex): void {
    const goalObj = goal;
    goalObj.minimize = !goalObj.minimize;
    if (!goalObj.minimize) {
      setTimeout(() => {
        goalObj.related_projects.forEach((projectDetails, projectIndex) => {
          const project = projectDetails;
          // replace all the id tags in the string using the regex condition id="([^\"]*?)"
          project.goals = project.goals.replaceAll(/id="([^\"]*?)"/g, '');
          this.appendHTML(
            `report-activity-${goalIndex}-${projectIndex}`,
            project.goals
          );
        });
      }, 100);
    }
  }

  toggleSubTask() {
    let index;
    if (this.showSubTasks) {
      index = this.taskDetails.sub_tasks.findIndex((subTask) => subTask.is_new);
      index !== -1 ? this.taskDetails.sub_tasks.splice(index, 1) : '';
    } else if (!this.taskDetails.sub_tasks.length) {
      this.addNewSubTask();
    }
    this.showSubTasks = !this.showSubTasks;
  }

  // Update from and to dates based on view selected and load activities
  updateDatesForView(loadActivities, loadTripExpenses?) {
    if (this.viewSelected === 'Week') {
      this.getDateRangeOfWeek(this.weekNo, true);
    } else {
      this.fromDate =
        this.viewSelected === 'Month'
          ? ActivityPlannerComponent.createDates(
              this.displayYear,
              this.currentMonth,
              1
            )
          : ActivityPlannerComponent.createDates(this.displayYear, 0, 1);
      this.toDate =
        this.viewSelected === 'Month'
          ? ActivityPlannerComponent.createDates(
              this.displayYear,
              this.currentMonth + 1,
              0
            )
          : ActivityPlannerComponent.createDates(this.displayYear, 11, 31);
    }
    if (loadActivities) {
      this.loadActivityDetails(
        this.fromDate,
        this.toDate,
        this.empSelected,
        (data) => {
          this.parseActivityDetails(data);
        },
        this.reportView
          ? { status: this.taskStatusSelected, comments: 'Y' }
          : ''
      );
    }

    if (loadTripExpenses && this.expenseView) {
      this.loadAllExpenses();
    }

    if (loadTripExpenses && this.tripView) {
      this.loadActivityDetails(
        this.fromDate,
        this.toDate,
        this.empSelected,
        (data) => {
          this.parseAddedTrips(data);
        }
      );
    }
  }

  // Validate the budget values of destination
  validateBudgets(budgets) {
    let valid = true;
    budgets.forEach((budget) => {
      budget.focus = true;
      if (budget.required) {
        if (
          !(
            budget.value &&
            budget.value.value &&
            budget.value.value !== '0.00' &&
            budget.value.value !== '0,00'
          )
        ) {
          budget.focus = false;
          this.tripErrorMessage = budget.name + ' is required';
          valid = false;
          return false;
        }
      }
    });
    return valid;
  }

  // Validate trip details before saving the data
  validateTripDetails() {
    let valid = true;
    let key;
    const params = ['from', 'to', 'startDate', 'endDate'];
    if (!this.trip.description) {
      this.focusTripDescription = false;
      return false;
    }
    this.trip.destinations.every((destination) => {
      params.every((param) => {
        if (!destination[param]) {
          key = `focus${this._titleCase.transform(param)}`;
          destination[key] = false;
          valid = false;
          return false;
        }
        return true;
      });
      if (!this.compareDates(destination.startDate, destination.endDate)) {
        destination.focusEndTime = false;
        this.tripErrorMessage = 'In-valid End date';
        valid = false;
        return false;
      } else if (!this.validateBudgets(destination.budgetList)) {
        valid = false;
        return false;
      } else if (!destination.goals) {
        destination.focusGoals = false;
        valid = false;
        return false;
      }
      if (destination.startDate && destination.endDate) {
        destination.focusEndTime = true;
        if (
          destination.startDate === destination.endDate &&
          !ActivityPlannerComponent.compareTime(
            destination.startTime,
            destination.endTime
          )
        ) {
          destination.focusEndTime = false;
          valid = false;
          return false;
        }
      }
      return true;
    });
    return valid;
  }

  viewActivities() {
    const statusSelected = this.approvalStatusListFiltered
      .filter((status) => status.isChecked)
      .map((filteredStatus) => filteredStatus.id);
    this.expenses = this.allExpenses.filter((expense) =>
      statusSelected.includes(expense.exp_status)
    );
  }

  viewExpenseOrProject(redirectionDetails) {
    if (redirectionDetails.key === 'report_header_id') {
      this._appService.reportHeaderId = redirectionDetails.value;
      this._appService.editExpense = true;
      this._appService.activityEmployee = this.empSelected;
      this._router.navigate(['expenses/manage']);
    } else {
      this.viewTaskDetails(redirectionDetails.value);
    }
  }

  viewGoal(goalId) {
    if (!goalId) {
      return;
    }
    const endPoint = `/activityplanner/goal/${goalId}/`;
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: viewGoal()' });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.showAddGoal = true;
        this.showLinkedProjects = false;
        this.goal = { ...data[0] };
        this.goal.description = this.goal.description
          ? this._appService.replaceAll(this.goal.description, '\n', '<br>')
          : '';
        // replace all the id tags in the goal description using the regex condition id="([^\"]*?)"
        this.goal.description = this.goal.description.replaceAll(
          /id="([^\"]*?)"/g,
          ''
        );
        ActivityPlannerComponent.appendHTML(
          'goal-description',
          this.goal.description
        );
        this.goal.type = 'Goal';
        this.goal.linked_projects.forEach((project) => {
          project.task_user_name = this.getUserBadgeText(
            project.user_description
          );
        });
        this.fetchComments('goal');
        this.oldGoal = { ...data[0] };
      }
    });
  }

  viewTaskDetails(taskId) {
    this._appService.scrollTop();
    this.showSpinner = true;
    const endPoint = `/activityplanner/details/task/${taskId}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: viewTaskDetails()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.setUpDOMHandlers();
        this.parseTaskDetails(data);
      }
    });
  }

  // Called when a task or trip is clicked in the list-view
  viewTaskOrTrip(activity) {
    if (activity.type === 'trip') {
      jQuery('body').css('overflow', 'auto');
      // this.viewTrip(activity.trip_id);
    } else {
      this.viewTaskDetails(activity.task_id);
    }
  }

  // Called from report view when clicked on Updates or comments to focus on the respective fields
  viewTaskWithAction(activity, action) {
    this.toggleAction = action;
    this.viewTaskDetails(activity.task_id);
  }

  // Load the trip details
  viewTrip(event) {
    const tripId = event.value;
    this._appService.scrollTop();
    const endPoint = '/activityplanner/details/trip/' + tripId + '/';
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          msg: 'Server Error - viewTrip()',
          status: 1,
        });
      } else {
        if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          if (data.trips[0]) {
            this.showViewScreen = false;
            this.showAddTrip = true;
            this.setUpDOMHandlers();
            this.parseTripDetails(data);
          }
        }
      }
    });
  }
}
