import { Injector, Injectable } from '@angular/core';
import { HttpService } from '../globals/http.service';
import { Response } from '../globals/response';
import { ServerError } from '../globals/server.error';
import { APIError } from '../globals/api.error';
import { ManagerReportees } from './manager-reportee.model';

@Injectable({
  providedIn: 'root',
})
export class ActivityPlannerService {
  private readonly URL_PREFIX: string;
  private _httpService: HttpService = this.injector.get(HttpService);

  constructor(private injector: Injector) {
    this.URL_PREFIX = '/activityplanner';
  }

  deleteCommentOrUpdate(commentId): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.URL_PREFIX}/comments/delete/${commentId}/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deleteCommentOrUpdate'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  changeProjectStatus(
    status: string,
    projectId: number,
    userId: number
  ): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.URL_PREFIX}/task/status/update/`;
      const reqObj = {
        task_id: projectId,
        task_status: status,
        user_id: userId,
      };
      this._httpService.httpRequest('POST', endPoint, reqObj, (response) => {
        if (!response) {
          reject(new ServerError('changeProjectStatus'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  loadActivityPlanner(reqObj) {
    return new Promise((resolve, reject) => {
      const endPoint = '/activityplanner/summary/';
      this._httpService.httpRequest('POST', endPoint, reqObj, (response) => {
        if (!response) {
          reject(new ServerError('SERVER ERROR - loadActivityPlanner()'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  saveCommentsOrReply(comments): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = '/activityplanner/comments/add/';
      this._httpService.httpRequest('POST', endPoint, comments, (response) => {
        if (!response) {
          reject(new ServerError('saveCommentsOrReply'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  getManagerReportees(): Promise<ManagerReportees[] | Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.URL_PREFIX}/managers/reportees/`;
      this._httpService.httpRequest(
        'GET',
        endPoint,
        null,
        (response: ManagerReportees[] | Response) => {
          if (!response) {
            reject(new ServerError('getManagerReportees()'));
          } else if ('status' in response) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  saveTripDetails(endPoint, method, reqObj) {
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        method,
        endPoint,
        reqObj,
        (response: Response) => {
          if (!response) {
            reject(new ServerError('SERVER ERROR - saveTripDetails()'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }
}


