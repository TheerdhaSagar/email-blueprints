import { NgModule } from '@angular/core';

import { ActivityPlannerRoutingModule } from './activity-planner-routing.module';
import { ShareModule } from '../share/share.module';
import { ActivityPlannerComponent } from './activity-planner.component';
import { ActivityMappingSummaryComponent } from './mapping/summary/summary.component';
import { EditMappingComponent } from './mapping/edit-mapping/edit-mapping.component';
import { ManagerReporteesComponent } from './manager-reportee/manager-reportee.component';
import { ReporteeTreeComponent } from './manager-reportee/reportee-tree-component/reportee-tree-component';

@NgModule({
  declarations: [
    ActivityPlannerComponent,
    ActivityMappingSummaryComponent,
    EditMappingComponent,
    ManagerReporteesComponent,
    ReporteeTreeComponent,
  ],
  imports: [ActivityPlannerRoutingModule, ShareModule],
})
export class ActivityPlannerModule {}
