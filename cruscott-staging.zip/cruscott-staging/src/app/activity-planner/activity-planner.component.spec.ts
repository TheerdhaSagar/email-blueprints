import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { OrderByPipe } from '../globals/order-by.pipe';
import { FilterPipe } from '../globals/filter.pipe';
import { RouterModule, Router, Routes } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { DragDropModule } from '@angular/cdk/drag-drop';

import { ActivityPlannerComponent } from './activity-planner.component';
import { CalendarComponent } from '../globals/calendar/calendar.component';
import { CurrencyComponent } from '../globals/currency/currency.component';
import { TimelineComponent } from '../globals/timeline/timeline.component';
import { LoginComponent } from '../login/login.component';
import { SpinnerComponent } from '../globals/spinner/spinner.component';
import { APP_BASE_HREF } from '@angular/common';
import { HttpService } from '../globals/http.service';

describe('ActivityPlannerComponent ', () => {
  let component: ActivityPlannerComponent;
  let fixture: ComponentFixture<ActivityPlannerComponent>;
  let router: Router;
  let routes: Routes = [{ path: 'login', component: LoginComponent }];

  beforeEach(async(() => {

    TestBed.configureTestingModule({
      imports: [FormsModule, DragDropModule, HttpClientModule, HttpClientTestingModule, InfiniteScrollModule, RouterModule.forRoot(routes), TranslateModule.forRoot()],
      declarations: [LoginComponent, TimelineComponent, FilterPipe, OrderByPipe, ActivityPlannerComponent, SpinnerComponent, CalendarComponent, CurrencyComponent],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, HttpService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityPlannerComponent);
    component = fixture.componentInstance;

    router = TestBed.get(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Tests for addTaskModelOpen()', () => {

    beforeEach(() => {
      component.managersList = [{ manager_id: 2007 }];
      component.userId = 1;
      component.user = { user_description: 'Test User' };
    });

    it('should set the default values for a new task', () => {
      component.empSelected = 1;
      component.addTaskModelOpen('I');
      expect(component.taskDetails.created_id).toEqual(component.userId);
      expect(component.taskDetails.approver_id).toEqual(component.managersList[0].manager_id);
      expect(component.taskDetails.status).toEqual('I');
    });

    it(`should load the current employee activities in the background
     when task is added from another employees summary`, () => {
      spyOn(component, 'loadActivityDetails');
      // Current employee is 1 but the task is added from summary of employee 2
      component.empSelected = 2;
      component.addTaskModelOpen();
      // Load task summary of employee 1 in the background
      expect(component.loadActivityDetails).toHaveBeenCalled();
      // If no task status is passed to addTaskModal, it should be set to 'T' -To Do by default
      expect(component.taskDetails.status).toEqual('T');
    });

  });

});
