import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {
  ManagerReportees,
  ActivityPlannerUser,
} from '../../manager-reportee.model';

enum ReporteeType {
  DIRECT,
  OTHER,
}

@Component({
  selector: 'app-reportee-tree-component',
  templateUrl: './reportee-tree-component.html',
  styleUrls: ['./reportee-tree-component.scss'],
})
export class ReporteeTreeComponent implements OnInit {
  @Input() depth = 0;
  @Input() directManagerId: number;
  @Input() isDirect: boolean;
  @Input() managerReportees: ManagerReportees[];
  @Input() managers: number[] = [];
  @Input() selectedUserId: number;
  @Input() userId: number;

  @Output() selectUser: EventEmitter<ActivityPlannerUser> =
    new EventEmitter<ActivityPlannerUser>();

  currentUser: ManagerReportees;
  directReportees: ActivityPlannerUser[];
  otherReportees: ActivityPlannerUser[];
  selectedUserName: string;

  ngOnInit(): void {
    this.currentUser = this.getCurrentUser(this.userId);
    this.directReportees = this.getReportees(ReporteeType.DIRECT);
    this.otherReportees = this.getReportees(ReporteeType.OTHER);
    if (this.directReportees.length || this.otherReportees.length) {
      this.managers = this.managers.concat([this.userId]);
    }
    if (this.selectedUserId === this.userId) {
      this.selectedUserName = this.currentUser.user_name;
    }
  }

  getCurrentUser(userId: number): ManagerReportees {
    if (!this.managerReportees) {
      return null;
    }
    let user = this.managerReportees.find((u) => u.user_id === userId);
    if (!user) {
      const manager = this.managerReportees.find(
        (u) => u.user_id === this.directManagerId
      );
      if (this.isDirect) {
        user = manager.reportees.find(
          (u) => u.user_id === userId
        ) as ManagerReportees;
      } else {
        user = manager.other_reportees.find(
          (u) => u.user_id === userId
        ) as ManagerReportees;
      }
    }
    return { ...user };
  }

  getReportees(reporteeType: ReporteeType): ActivityPlannerUser[] {
    if (
      !this.currentUser ||
      !this.currentUser.reportees ||
      !this.currentUser.other_reportees
    ) {
      return [];
    }

    const mainUser =
      this.managers.length > 0
        ? this.getCurrentUser(this.managers[0])
        : this.currentUser;
    let otherReporteesIds = [];
    if (mainUser.other_reportees) {
      otherReporteesIds = mainUser.other_reportees.map((user) => user.user_id);
    }

    if (
      otherReporteesIds.length &&
      mainUser.user_id !== this.currentUser.user_id
    ) {
      if (otherReporteesIds.includes(this.currentUser.user_id)) {
        return [];
      }
    }

    if (reporteeType === ReporteeType.DIRECT) {
      return this.currentUser.reportees.filter(
        (user) => !this.managers.includes(user.user_id)
      );
    }

    if (this.managers.length > 0) {
      return [];
    }

    return this.currentUser.other_reportees.filter(
      (user) => !this.managers.includes(user.user_id)
    );
  }

  isDepthIndicatorVisible(): boolean {
    return this.directReportees.length > 0 || this.otherReportees.length > 0;
  }

  onSelect(user: ActivityPlannerUser): void {
    this.currentUser.active = false;
    if (user) {
      this.selectUser.emit(user);
      this.selectedUserName = user.user_name;
    } else {
      this.selectUser.emit({
        user_id: this.currentUser.user_id,
        user_name: this.currentUser.user_name,
      });
      this.selectedUserName = this.currentUser.user_name;
    }
  }

  showReportees(event): void {
    event.stopPropagation();
    this.currentUser.active = !this.currentUser.active;
  }
}
