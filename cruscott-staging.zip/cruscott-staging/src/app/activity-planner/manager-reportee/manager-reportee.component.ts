import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { Response } from '../../globals/response';
import { ActivityPlannerService } from '../activity-planner.service';
import {
  ManagerReportees,
  ActivityPlannerUser,
} from '../manager-reportee.model';

@Component({
  selector: '<app-act-manager-reportee></app-act-manager-reportee>',
  templateUrl: './manager-reportee.component.html',
})
export class ManagerReporteesComponent implements OnInit {
  managerReportees: ManagerReportees[];

  @Input() userId: number;
  @Input() selectedUserId: number;

  @Output() selectUser = new EventEmitter<ActivityPlannerUser>();

  constructor(
    private appService: AppService,
    private activityService: ActivityPlannerService
  ) {}

  ngOnInit(): void {
    this.loadManagerReportees();
  }

  loadManagerReportees(): void {
    this.activityService
      .getManagerReportees()
      .then((result: ManagerReportees[]) => {
        this.managerReportees = result;
      })
      .catch((err: Response) => {
        this.appService.notify(err);
      });
  }

  onSelect(event): void {
    this.selectUser.emit(event);
  }
}
