import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivityMappingSummaryComponent } from './summary.component';

describe('SummaryComponent', () => {
  let component: ActivityMappingSummaryComponent;
  let fixture: ComponentFixture<ActivityMappingSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivityMappingSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityMappingSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
