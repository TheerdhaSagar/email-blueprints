import { Component, OnInit, ViewChild } from '@angular/core';
import { TabletemplateComponent } from '../../../globals/tabletemplate/tabletemplate.component';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { HttpService } from '../../../globals/http.service';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { Settings } from '../../../globals/tabletemplate/models/settings';
import { CommonService } from '../../../globals/common.service';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss', '../../../usermanagement/managers/summary/summary.component.scss']
})
export class ActivityMappingSummaryComponent implements OnInit {

  @ViewChild(TabletemplateComponent) child: TabletemplateComponent;

  private _appService: AppService;
  private _cacheService: CacheService;
  private _commonService: CommonService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  allEmployees: any[];
  searchQuery: string;
  showSpinner: boolean;
  tableSettings: Settings;
  toggleFilter: (e?) => void;

  constructor(appService: AppService, cacheService: CacheService, commonService: CommonService, httpService: HttpService,
              location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._commonService = commonService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.allEmployees = [];
    this.searchQuery = '';
    this.showSpinner = false;
    this.tableSettings = new Settings({
      headers: [
        { title: 'User Name', keyName: 'user_name', redirect: 'user_id' },
        { title: 'Known As', keyName: 'full_name' },
        { title: 'Email Address', keyName: 'email_address' }
      ],
      sortHeader: true,
      predicate: ''
    });
    this.toggleFilter = this._appService.toggleFilter();
  }

  ngOnInit(): void {
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        setTimeout(() => {
          this.loadEmployees();
        }, 50);
      }
    });
  }

  // Navigate to the edit mapping screen for the selected employee
  editMapping(managerDetails): void {
    this._appService.activityEmployee = this.allEmployees.find(
      (employee) => employee.user_id === managerDetails.value
    );
    this._router.navigate(['/activity-planner/mapping/edit']);
  }

  // download the table data
  exportData(): void {
    this.toggleFilter();
    this.child.exportData('Activity-Planner Managers');
  }

  goToActivityPlanner(): void {
    this._router.navigate(['/activity-planner']);
  }

  loadEmployees(): void {
    this.showSpinner = true;
    this._commonService.loadActivityPlannerUsers((data) => {
      this.showSpinner = false;
      this.allEmployees = [...data];
    });
  }
}
