import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { HttpService } from '../../../globals/http.service';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { CommonService } from '../../../globals/common.service';
import { Settings } from '../../../globals/tabletemplate/models/settings';

@Component({
  selector: 'app-edit-mapping',
  templateUrl: './edit-mapping.component.html',
  styleUrls: ['./edit-mapping.component.scss', '../../../usermanagement/mapping/customer/customer.component.scss']
})
export class EditMappingComponent implements OnInit {

  private _appService: AppService;
  private _cacheService: CacheService;
  private _commonService: CommonService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  allEmployees: any[];
  employee: any;
  employeeTableSettings: Settings;
  employees: any[];
  initialEmployees: any[];
  initialManagers: any[];
  managerTableSettings: Settings;
  managers: any[];
  newEmployee: number;
  newManager: number;
  showDialog: boolean;
  showSpinner: boolean;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, commonService: CommonService,
              httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._commonService = commonService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.allEmployees = [];
    this.employee = {};
    this.employeeTableSettings = new Settings({
      checkboxes: true,
      checkBoxHeader: 'Direct Reportee',
      desc: false,
      headers: [
        { title: 'User Id', keyName: 'user_id' },
        { title: 'User Name', keyName: 'user_description' }
      ],
      icons: [{ iconType: 'icon', iconStyle: 'icon-cross', iconAction: 'delete' }],
      predicate: 'user_description',
      sortHeader: true
    });
    this.employees = [];
    this.initialManagers = [];
    this.managerTableSettings = new Settings({
      headers: [
        { title: 'User Id', keyName: 'manager_id' },
        { title: 'User Name', keyName: 'manager_name' }
      ],
      icons: [{ iconType: 'icon', iconStyle: 'icon-cross', iconAction: 'delete' }],
      sortHeader: true,
      predicate: 'manager_name',
      desc: false
    });
    this.managers = [];
    this.newEmployee = null;
    this.newManager = null;
    this.showDialog = false;
    this.showSpinner = false;
    this.user = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this._appService.scrollTop();
        if (this._appService.activityEmployee) {
          this.employee = this._appService.activityEmployee;
          this.loadActivityPlannerUsers();
          this.loadManagers();
          this._appService.activityEmployee = null;
        } else {
          this.goToSummary();
        }
      }
    });
  }

  addEmployee() {
    const employeeToAdd = this.allEmployees.find((employee) => employee.user_id === this.newEmployee);
    // Add a manager if he isn't already mapped to the employee
    if (employeeToAdd && !this.employees.some((employee) => employee.user_id === this.newEmployee)) {
      this.employees.push({
        user_id: employeeToAdd.user_id,
        user_description: employeeToAdd.full_name,
        isChecked: false,
        isCheckBox: true,
        displayConditions: { delete: true },
        direct_reportee: 'N',
        existingMapping: this.initialEmployees.some((employee) => employee.user_id === this.newEmployee)
      });
      this.newEmployee = null;
    }
  }

  addManager() {
    const managerToAdd = this.allEmployees.find((employee) => employee.user_id === this.newManager);
    // Add a manager if he isn't already mapped to the employee
    if (managerToAdd && !this.managers.some((manager) => manager.manager_id === this.newManager)) {
      this.managers.push({
        manager_id: managerToAdd.user_id,
        manager_name: managerToAdd.full_name,
        displayConditions: { delete: true }
      });
      this.newManager = null;
    }
  }

  addOrRemoveReportee(employeeDetails) {
    if (employeeDetails.existingMapping) {
      const endPoint = '/activityplanner/reportee/status/';
      const reqObj = {
        employee_id: employeeDetails.user_id,
        manager_id: this.employee.user_id,
        recent_updated_user_id: this.user.user_id,
        direct_reportee: employeeDetails.isChecked ? 'Y' : 'N'
      };
      this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - addOrRemoveReportee()' });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      });
    }
  }

  deleteEmployee(employeeDetails) {
    const deleteIndex = this.employees.findIndex((employee) => employee.user_id === employeeDetails.user_id);
    deleteIndex !== -1 ? this.employees.splice(deleteIndex, 1) : null;
  }

  // Un map a manager from the employee
  deleteManager(managerDetails) {
    const deleteIndex = this.managers.findIndex((employee) => employee.manager_id === managerDetails.manager_id);
    deleteIndex !== -1 ? this.managers.splice(deleteIndex, 1) : null;
  }

  goToSummary() {
    this._router.navigate(['/activity-planner/mapping/summary']);
  }

  loadActivityPlannerUsers() {
    let currentUserIndex;
    // Populate the users LOV and delete the selected user from the list
    if (this._cacheService.activityPlannerUsers && this._cacheService.activityPlannerUsers.length) {
      this.allEmployees = [...this._cacheService.activityPlannerUsers];
      currentUserIndex = this.allEmployees.findIndex(employee => employee.user_id === this.employee.user_id);
      currentUserIndex !== -1 ? this.allEmployees.splice(currentUserIndex, 1) : null;
    } else {
      this._commonService.loadActivityPlannerUsers((data) => {
        this.allEmployees = [...data];
        currentUserIndex = this.allEmployees.findIndex(employee => employee.user_id === this.employee.user_id);
        currentUserIndex !== -1 ? this.allEmployees.splice(currentUserIndex, 1) : null;
      });
    }
  }

  loadManagers() {
    const endPoint = `/activityplanner/managers/${this.employee.user_id}/`;
    try {
      this.showSpinner = true;
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({ msg: 'Server Error - loadManagers()', status: 1 });
        } else if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else if (data.status === 0) {
          data.managers.forEach((manager) => {
            const managerObj = manager;
            managerObj.displayConditions = { delete: true };
          });
          data.employees.forEach((employee) => {
            const employeeObj = employee;
            employeeObj.displayConditions = { delete: true };
            employeeObj.isCheckBox = true;
            employeeObj.isDirectReportee = employeeObj.direct_reportee === 'Y';
            employeeObj.isChecked = employeeObj.direct_reportee === 'Y';
            employeeObj.existingMapping = true;
          });
          this.managers = [...data.managers];
          this.initialManagers = [...data.managers];
          this.employees = [...data.employees];
          this.initialEmployees = [...data.employees];
        }
        this.showSpinner = false;
      });
    } catch (e) {
      this.showSpinner = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: `<pre>${e.stack}</pre>`
      });
    }
  }

  saveMapping() {
    const endPoint = '/activityplanner/map/managers/';
    const reqObj = {
      insert_managers: [],
      delete_managers: [],
      insert_employees: [],
      delete_employees: [],
      employee_id: this.employee.user_id,
      primary_approver: '',
      created_id: this.user.user_id
    };
    let index;

    // Populating the newly inserted managers by comparing the intial managers mapped to the current mapping
    this.managers.forEach((manager) => {
      index = this.initialManagers.findIndex((initialManager) => initialManager.manager_id === manager.manager_id);
      if (index === -1) {
        reqObj.insert_managers.push(manager.manager_id);
      }
    });

    // Populating the deleted manager mappings
    this.initialManagers.forEach((initialManager) => {
      index = this.managers.findIndex((manager) => manager.manager_id === initialManager.manager_id);
      if (index === -1) {
        reqObj.delete_managers.push(initialManager.manager_id);
      }
    });

    // Populating the newly inserted employees by comparing the intial employees mapped to the current user
    this.employees.forEach((employee) => {
      index = this.initialEmployees.findIndex((initialEmployee) => initialEmployee.user_id === employee.user_id);
      if (index === -1) {
        reqObj.insert_employees.push({
          employee_id: employee.user_id,
          direct_reportee: employee.isChecked ? 'Y' : 'N'
        });
      }
    });

    // Populating the deleted employee mappings
    this.initialEmployees.forEach((initialEmployee) => {
      index = this.employees.findIndex((employee) => employee.user_id === initialEmployee.user_id);
      if (index === -1) {
        reqObj.delete_employees.push(initialEmployee.user_id);
      }
    });

    this.showSpinner = true;
    this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - saveMapping()' });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else {
          this._appService.notify({
            status: 0,
            msg: `Mappings successfully updated for ${this.employee.full_name}`
          });
          this.goToSummary();
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });

  }

  selectAction(event, deleteType): void {
    if (event.action === 'icon-cross') {
      deleteType === 'employee' ? this.deleteEmployee(event.data) : this.deleteManager(event.data);
    }
  }
}
