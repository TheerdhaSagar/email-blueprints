import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivityPlannerComponent } from './activity-planner.component';
import { ActivityMappingSummaryComponent } from './mapping/summary/summary.component';
import { EditMappingComponent } from './mapping/edit-mapping/edit-mapping.component';

const routes: Routes = [
  { path: '', component: ActivityPlannerComponent },
  { path: 'mapping/summary', component: ActivityMappingSummaryComponent },
  { path: 'mapping/edit', component: EditMappingComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ActivityPlannerRoutingModule { }
