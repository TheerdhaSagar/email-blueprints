export interface ActivityPlannerUser {
  active?: boolean;
  user_id: number;
  user_name: string;
}

export interface ManagerReportees extends ActivityPlannerUser {
  reportees: ActivityPlannerUser[];
  other_reportees: ActivityPlannerUser[];
}
