import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AppService } from "../../globals/app.service";
import { CacheService } from "../../globals/cache.service";
import { DataService } from "../../globals/data.service";
import { FormatService } from "../../globals/format.service";
import { Router } from "@angular/router";
import { FilterPipe } from "../../globals/filter.pipe";
import { OrderByPipe } from "../../globals/order-by.pipe";
import { HttpService } from "../../globals/http.service";
import { TitleCasePipe } from "@angular/common";
import { APIError } from '../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-assetcreate',
  templateUrl: './assetcreate.component.html',
  styleUrls: ['./assetcreate.component.scss'],
  providers: [FilterPipe, OrderByPipe, TitleCasePipe]
})
export class AssetcreateComponent implements OnInit {
  @ViewChild('fileUpload') fileUpload: ElementRef;
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _orderBy: OrderByPipe;
  private _router: Router;
  private _titlecase: TitleCasePipe;
  private _window: any;

  allAssetTypes: any[];
  appAssetId: number;
  assetAttachment: any;
  assetDetails: any;
  assetSubTypes: any[];
  assetTypes: any[];
  attachmentArr: any[];
  attachmentType: string;
  attachmentTypes: string[];
  conditionsList: string[];
  currencies: string[];
  dateFormat: string;
  defaultCurrency: any;
  deleteAssetAttachment: boolean;
  deleteAttachment: any;
  editAssetAttachment: boolean;
  editAttachment: any;
  editAttachmentFileId: number;
  employeeNumber: any;
  fileDialog: boolean;
  focusAssetType: boolean;
  focusAssetSubType: boolean;
  focusAttachmentType: boolean;
  focusBrand: boolean;
  focusEditAttachmentType: boolean;
  focusModel: boolean;
  focusPONumber: boolean;
  focusPurchaseDate: boolean;
  focusRenewalDate: boolean;
  focusWarrantyDate: boolean;
  historyDescription: string;
  isEdit: boolean;
  lifeTimeArr: any[];
  locations: any[];
  numberFormat: string;
  oldAssetDetails: any;
  org: number;
  purchaseDateMsg: string;
  renewalDateMsg: string;
  selectedUsersList: any[];
  selection: string;
  showSpinner: boolean;
  statusList: string[];
  steps: string[];
  user: any;
  users: any[];
  warrantyDateMsg: string;


  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService,
              httpService: HttpService, orderBy: OrderByPipe, router: Router, titleCasePipe: TitleCasePipe) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._orderBy = orderBy;
    this._router = router;
    this._titlecase = titleCasePipe;
    this._window = window;

    this.allAssetTypes = [];
    this.appAssetId = null;
    this.assetAttachment = null;
    this.assetDetails = {
      asset_attachments: [],
      license_number: '',
      status: '',
      serial_number: '',
      purchased_date: '',
      renewal_date: '',
      warranty_expiry_date: '',
      po_number: '',
      currency_code: '',
      purchased_price: {},
      purchases_price: {},
      asset_life_time: '',
      description: '',
      location_id: null,
      assest_type_id: '',
      asset_type: '',
      asset_sub_type: '',
      brand: '',
      model: '',
      asset_id: null,
      asset_history: [],
      delete_attachments: [],
      user_ids: [],
      asset_condition: '',
      inventory_number: ''
    };
    this.assetSubTypes = [];
    this.assetTypes = null;
    this.attachmentArr = [];
    this.attachmentType = '';
    this.attachmentTypes = ['Asset Invoice', 'Asset History'];
    this.conditionsList = ['New', 'Used'];
    this.currencies = [];
    this.dateFormat = null;
    this.defaultCurrency = null;
    this.deleteAssetAttachment = false;
    this.deleteAttachment = null;
    this.editAssetAttachment = false;
    this.editAttachment = {};
    this.editAttachmentFileId = null;
    this.fileDialog = false;
    this.focusAssetType = true;
    this.focusAssetSubType = true;
    this.focusAttachmentType = true;
    this.focusBrand = true;
    this.focusEditAttachmentType = true;
    this.focusModel = true;
    this.focusPONumber = true;
    this.focusPurchaseDate = true;
    this.focusRenewalDate = true;
    this.focusWarrantyDate = true;
    this.historyDescription = '';
    this.isEdit = false;
    this.lifeTimeArr = [{ 'life_time_id': 1, 'life_time': 'Months' }];
    this.locations = [];
    this.numberFormat = null;
    this.oldAssetDetails = {};
    this.org = null;
    this.purchaseDateMsg = '';
    this.renewalDateMsg = '';
    this.warrantyDateMsg = '';
    this.selectedUsersList = [];
    this.selection = 'GeneralInformation';
    this.showSpinner = false;
    this.statusList = ['In-Transit', 'Assigned', 'Available', 'Retired', 'Destroyed', 'Lost'];
    this.steps = ['GeneralInformation', 'Attachments', 'History'];
    this.user = null;
    this.users = [];
  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        this.org = this._cacheService.getOrgId();
        if (!this._cacheService.user) {
          this._cacheService.initialize(this.user);
        }
        this.numberFormat = this.user.number_format || '999,999.99';
        this.dateFormat = this.user.date_format;
        this.showSpinner = true;
        this.loadCurrencies();
        this.loadUsers();
        if (this._appService.assetId) {
          this.showSpinner = true;
          this.appAssetId = this._appService.assetId;
          this._appService.assetId = null;
        }
      }

      for (let i = 0; i < this.user.organizations.length; i++) {
        if (this._dataService.orgId === this.user.organizations[i].organization_id) {
          this.defaultCurrency = this.user.organizations[i].currency_code;
          break;
        }
      }

      setTimeout(() => {
        new FooPicker({
          id: 'purchase_date',
          dateFormat: this.dateFormat
        });

        new FooPicker({
          id: 'renewal_date',
          dateFormat: this.dateFormat
        });

        new FooPicker({
          id: 'warranty_date',
          dateFormat: this.dateFormat
        });
      });
    });
  }

  // Add attachments to a assets
  addAttachment() {
    let index;
    this.focusAttachmentType = !!this.attachmentType;
     if (!this.attachmentType) {
      return;
    } else if (!this.assetAttachment) {
      this._appService.notify({ status: 1, msg: 'Please upload the file' });
      return;
    }
    this.focusAttachmentType = true;
    if (this._appService.checkFileSize(this.assetAttachment, this.assetDetails.asset_attachments)) {
      index = this.assetDetails.asset_attachments.map(attachment => attachment.file_name + attachment.file_type).indexOf(this.assetAttachment.filename + this.assetAttachment.filetype);
      if (index === -1) {
        this.assetDetails.asset_attachments.push({
          created_date: this._formatService.formatDate(this._appService.today(0), this.dateFormat),
          file_name: this.assetAttachment.filename,
          file_type: this.assetAttachment.filetype,
          file_content: this.assetAttachment.base64,
          attachment_type: this.attachmentType,
          edit: false
        });
      } else {
        this._appService.notify({ msg: 'File already exists', status: 1 });
      }
      this.historyDescription += `${this.attachmentType} : ${this.assetAttachment.filename} is added . `;
      this.assetAttachment = null;
      this.attachmentType = '';
      this.closeAttachmentDialog();
    } else {
      this._appService.notify({ msg: 'File size greater than 25MB', status: 1 });
    }
  }

  // to populate all the sub type based on asset type selection
  assetSubTypeDetails() {
    let arrSubType;
    this.assetSubTypes = [];
    arrSubType = this.allAssetTypes.filter(item => {
      return item.asset_type === this.assetDetails.asset_type
    }).map(item => item.asset_sub_type);
    this.assetSubTypes = arrSubType.filter((value, index, self) => self.indexOf(value) === index);
  }

  // route back to summary screen
  cancelAsset() {
    this._router.navigate(['asset-management/summary']);
  }

  // check which fields are edited to be saved in history
  checkAssetFields(asset) {
    let initialAsset = this.oldAssetDetails, keys, historyDetails = '', keyName,
      index, display, initialValue, assetValue,
      deleteKeys = ['asset_attachments', 'asset_history', 'delete_attachments', 'asset_mapping','location_id'];

    if (asset.location_id) {
      index = this.locations.map(loc => loc.location_id).indexOf(parseInt(asset.location_id));
      asset.location_name = this.locations[index].location_name;
    } else {
      asset.location_name = '';
    }

    deleteKeys.forEach(key => {
      delete initialAsset[key];
    });
    keys = Object.keys(initialAsset);

    for (let i = 0; i < keys.length; i++) {
      keyName = keys[i];
      if (keyName === 'user_ids' || keyName === 'unlink_user_ids') {
        display = keyName === 'user_ids' ? 'assigned to' : 'unassigned from';
        if (asset[keyName].length > 0) {
          this.users.forEach(user => {
            index = asset[keyName].indexOf(user.employee_number);
            if (index !== -1) {
              historyDetails += `Asset ${display} ${user.full_name}. ` ;
            }
          });
        }
      } else {
        initialAsset[keyName] = initialAsset[keyName] ? initialAsset[keyName] : '';
        asset[keyName] = asset[keyName] ? asset[keyName] : '';
        if (initialAsset[keyName] !== asset[keyName]) {
          // Converting price amounts to user number formats for display
          initialValue = keyName === 'purchased_price' ? this._formatService.formatNumber(initialAsset[keyName]) : initialAsset[keyName];
          assetValue = keyName === 'purchased_price' ? this._formatService.formatNumber(asset[keyName]) : asset[keyName];
          historyDetails += this.historyDetailsToUpdate(keyName, initialValue , assetValue);
        }
      }
    }
    this.historyDescription += historyDetails;
    return !!this.historyDescription;
  }

  // to clear the brand details if change of asset sub type
  clearBrandDetails() {
    this.assetDetails.brand = '';
  }

  clearHistoryNotes(history) {
    history.edit = false;
    history.editNotes = history.notes;
  }

  clearInventoryNumber() {
    this.assetDetails.inventory_number='';
  }

  clearPONumber() {
    this.assetDetails.po_number = '';
    this.focusPONumber = true;
  }

  closeAttachmentDialog() {
    this.fileDialog = false;
    this.focusAttachmentType = true;
    this.attachmentType = '';
    this.assetAttachment = null;
    this.fileUpload.nativeElement.value = null;
  }

  closeDeleteAttachmentDialog() {
    this.deleteAssetAttachment = false;
    this.deleteAttachment = null;
  }

  closeEditAttachmentDialog() {
    this.editAssetAttachment = false;
    this.editAttachment = {};
    this.attachmentType = '';
    this.focusAttachmentType = true;
    (document.getElementById('docUpload') as HTMLFormElement).value = null;
  }

  // compare dates if there are given
  dateCheck() {
    let purchaseDate, renewalDate, warrantDate;
    setTimeout(() => {
      if (this.assetDetails.purchased_date && !this._formatService.validateDate(this.assetDetails.purchased_date)) {
        this.focusPurchaseDate = false;
        this.purchaseDateMsg = 'Invalid Date';
        this.assetDetails.purchased_date = '';
        return;
      }
      if (this.assetDetails.renewal_date && !this._formatService.validateDate(this.assetDetails.renewal_date)) {
        this.focusRenewalDate = false;
        this.renewalDateMsg = 'Invalid Date';
        this.assetDetails.renewal_date = '';
        return;
      }
      if (this.assetDetails.warranty_expiry_date && !this._formatService.validateDate(this.assetDetails.warranty_expiry_date)) {
        this.focusWarrantyDate = false;
        this.warrantyDateMsg = 'Invalid Date';
        this.assetDetails.warranty_expiry_date = '';
        return;
      }
      purchaseDate = this._formatService.dateInMillis(this._formatService.parseDate(this.assetDetails.purchased_date));
      renewalDate = this._formatService.dateInMillis(this._formatService.parseDate(this.assetDetails.renewal_date));
      warrantDate = this._formatService.dateInMillis(this._formatService.parseDate(this.assetDetails.warranty_expiry_date));
      if (this.assetDetails.purchased_date && this.assetDetails.renewal_date && (purchaseDate >= renewalDate)) {
        this.focusRenewalDate = false;
        this.renewalDateMsg = 'Renewal Date  should be greater than purchase Date';
        this.assetDetails.renewal_date = '';
      } else if (this.assetDetails.purchased_date && this.assetDetails.warranty_expiry_date && (purchaseDate >= warrantDate)) {
        this.focusWarrantyDate = false;
        this.warrantyDateMsg = 'Warranty Date should be greater than purchase date';
        this.assetDetails.warranty_expiry_date = '';
      } else if (this.assetDetails.renewal_date && this.assetDetails.warranty_expiry_date && (renewalDate > warrantDate)) {
        this.focusWarrantyDate = false;
        this.warrantyDateMsg = 'Warranty Date should be greater than or equal Renewal Date';
        this.assetDetails.warranty_expiry_date = '';
      } else {
        this.focusWarrantyDate = true;
        this.focusRenewalDate = true;
        this.focusPurchaseDate = true;
      }
    }, 100);

  }

  // delete existing assets
  deleteAttachmentDetails(attachment) {
    let index = this.assetDetails.asset_attachments.map(attachment => attachment.file_name + attachment.file_type)
      .indexOf(attachment.file_name + attachment.file_type);
    if (index !== -1) {
      if (this.assetDetails.asset_attachments[index].file_id) {
        this.assetDetails.delete_attachments.push(this.assetDetails.asset_attachments[index].file_id);
        this.historyDescription += `${this.assetDetails.asset_attachments[index].attachment_type} : ` +
          `${this.assetDetails.asset_attachments[index].file_name} is deleted. `;

      }
      this.assetDetails.asset_attachments.splice(index, 1);
    }
    this.deleteAssetAttachment = false;
    this.deleteAttachment = null;
  }

  // delete attachment dialog
  deleteAttachmentDialog(attachment) {
    this.deleteAssetAttachment = true;
    this.deleteAttachment = attachment;
  }

  //download Attachment
  downloadAttachment(attachment) {
    let a, blobFile = this._formatService.base64ToBlob(attachment.base64 || attachment.file_content),
      url;
    if (blobFile) {
      a = document.createElement('a');
      document.body.appendChild(a);
      url = this._window.URL.createObjectURL(blobFile);
      a.href = url;
      a.download = attachment.filename || attachment.file_name;
      a.click();
      this._window.URL.revokeObjectURL(url);
    }
  }

  // edit the attachment details
  editAttachmentDetails(attachment) {
    let req, endPoint = '/hrms/assetmanagement/attachments/', index;
    this.focusAttachmentType = !!this.attachmentType;
    if (!this.attachmentType) {
      return;
    } else if (!attachment) {
      this._appService.notify({ status: 1, msg: 'Please upload the file' });
      return;
    }
    this.focusEditAttachmentType = true;
    index = this.assetDetails.asset_attachments.map(x => x.file_name).indexOf(attachment.filename);
    if (index !== -1 || this._appService.checkFileSize(attachment, this.assetDetails.asset_attachments)) {
      index = this.assetDetails.asset_attachments.map(attachment => attachment.file_id).indexOf(this.editAttachmentFileId);
      req = {};
      req.attachment_type = this.attachmentType;
      req.file_name = attachment.filename;
      req.file_type = attachment.filetype;
      req.file_content = attachment.base64;
      req.file_id = this.editAttachmentFileId;
      req.reference_id = this.appAssetId;
      req.created_id = this.user.user_id;
      this.historyDescription += `${this.assetDetails.asset_attachments[index].attachment_type} : `;
      this.historyDescription += `${this.assetDetails.asset_attachments[index].file_name} is changed to `;
      this.historyDescription += `${this.attachmentType} : ${attachment.filename}. `;
      this.editAssetAttachment = false;
      this._httpService.httpRequest('PUT', endPoint, req, (data) => {
        this.showSpinner = false;
        if (data === undefined || data === null) {
          this._appService.notify({ msg: 'Server Error -  editAttachmentDetails()', status: 1 });
        } else if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          this._appService.notify({ msg: 'Updated attachment successfully', status: 0 });
          this.assetDetails.asset_attachments[index].file_name = attachment.filename;
          this.assetDetails.asset_attachments[index].file_type = attachment.filetype;
          this.assetDetails.asset_attachments[index].file_content = attachment.base64;
          this.assetDetails.asset_attachments[index].attachment_type = this.attachmentType;
        }
        this.editAttachment = {};
        this.attachmentType = '';
      });
    } else {
      this._appService.notify({ msg: 'File size greater than 25MB', status: 1 });
    }
  }

// for Edit attachment dialog
  editAttachmentDialog(attachment) {
    this.editAssetAttachment = true;
    this.editAttachment = {
      filename: attachment.file_name,
      filetype: attachment.file_type,
      base64: attachment.file_content,
      attachmentType: attachment.attachment_type
    };
    this.editAttachmentFileId = attachment.file_id;
    this.attachmentType = attachment.attachment_type;
  }

  // check the current step
  getCurrentStepIndex() {
    return this.steps.map(x => x).indexOf(this.selection);
  }

  // Steps wrapper Selection
  goToStep(index) {
    if (index === 0) {
      setTimeout(() => {
        new FooPicker({
          id: 'purchase_date',
          dateFormat: this.dateFormat
        });

        new FooPicker({
          id: 'renewal_date',
          dateFormat: this.dateFormat
        });

        new FooPicker({
          id: 'warranty_date',
          dateFormat: this.dateFormat
        });
      });
    }
    this.selection = this.steps[index];
  }

  // go to summary screen
  goToSummary() {
    this._router.navigate(['asset-management/summary']);
  }

  //  add / edit the history details
  historyDetails(assetId, historyDetails?) {
    let endPoint = '/hrms/assetmanagement/history/', req, method;
    this.showSpinner = true;
    if (historyDetails) {
      req = historyDetails;
      req.asset_id = assetId;
      req.created_id = this.user.user_id;
      method = 'PUT';
    } else {
      req = {
        'created_id': this.user.user_id,
        'description': this.historyDescription,
        'notes': '',
        'asset_id': assetId
      };
      method = 'POST';
    }
    // this.showSpinner = false;
    this._httpService.httpRequest(method, endPoint, req, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - HistoryDetails()', status: 1 });
      } else if (historyDetails || data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      }
      if (!historyDetails) {
        this._router.navigate(['asset-management/summary']);
      }
    });
  }

  // History details to be updated for history
  historyDetailsToUpdate(keyName, initialAssetValue, assetValue) {
    let newKey = this._titlecase.transform(keyName.split("_").join(' '));
    if (!assetValue) {
      return `${newKey} is cleared from ${initialAssetValue}. `;
    } else if (!initialAssetValue) {
      return `${newKey} is added - ${assetValue}. `;
    } else {
      return `${newKey} is changed from ${initialAssetValue} to ${assetValue}. `;
    }
  }

  //load currencies
  loadCurrencies() {
    const endPoint = '/expenses/currencies/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadCurrencies()' });
        this.showSpinner = false;
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
        this.showSpinner = false;
      } else {
        this.currencies = data;
        this.assetDetails.purchases_price = { value: null, type: this.defaultCurrency };
      }
    });
  }

  // load location and asset type details
  loadLocationAndAssetTypes() {
    let endPoint = '/hrms/assetmanagement/assets/lov/' + this._cacheService.getOrgId() + '/';
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadLocationAndAssetTypes()', status: 1 });
        this.showSpinner = false;
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
        this.showSpinner = false;
      } else {
        this.locations = data.locations;
        this.allAssetTypes = data.asset_types;
        this.assetTypes = this.allAssetTypes.map(item => item.asset_type)
          .filter((value, index, self) => self.indexOf(value) === index);
        if (this.appAssetId) {
          this.loadRequestedAsset(this.appAssetId);
        } else {
          this.showSpinner = false;
        }
      }
    });
  }

  // load requested asset details
  loadRequestedAsset(assetId) {
    this.isEdit = true;
    let endPoint = '/hrms/assetmanagement/details/asset/' + assetId + '/';
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadRequestedAsset()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: 1 });
      } else {
        this.parseRequestedAsset(data.asset_details);
      }
    });
  }

  // Load all users
  loadUsers() {
    let endPoint = '/users/persons/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadUsers()' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.users = data;
        this.loadLocationAndAssetTypes();
      }
    });
  }

  // download attachments
  onDownload(attachment) {
    let endPoint = '/hrms/assetmanagement/attachments/' + attachment.file_id + '/';
    if (attachment.file_content) {
      this.downloadAttachment(attachment);
      return;
    }
    /* to service */
    if (attachment.file_id) {
      this.showSpinner = true;
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: 'Server Error - onDownload()'
            });
          } else if (data.status === 1) {
            this._appService.notify({
              msg: data.msg,
              status: data.status
            });
          } else {
            attachment.file_content = data.file_content;
            this.downloadAttachment(attachment);
          }
        } catch (e) {
          this._appService.notify({
            msg: e.message,
            status: 1,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }
  }

  // to parse the requested asset details to populate them
  parseRequestedAsset(data) {
    let index;
    this.selectedUsersList = [];
    this.assetDetails = data[0];
    index = this.allAssetTypes.map(item => item.asset_type_id).indexOf(this.assetDetails.assest_type_id);
    if (index !== -1) {
      this.assetDetails.asset_type = this.allAssetTypes[index].asset_type;
      this.assetDetails.asset_sub_type = this.allAssetTypes[index].asset_sub_type;
    }
    this.assetSubTypeDetails();
    this.assetDetails.purchases_price = {
      'type': this.assetDetails.currency_code ? this.assetDetails.currency_code : this.defaultCurrency,
      'value': this._formatService.formatNumber(this.assetDetails.purchased_price)
    };
    for (let i = 0; i < this.assetDetails.asset_attachments.length; i++) {
      this.assetDetails.asset_attachments[i].attachment_type = this.assetDetails.asset_attachments[i].reference_type;
      this.assetDetails.asset_attachments[i].edit = true;
    }
    this.assetDetails.asset_history.forEach(history => {
      history.edit = false;
      history.editNotes = history.notes;
    });
    this.assetDetails.asset_history = this._orderBy.transform(this.assetDetails.asset_history, 'asset_history_id', true);
    this.assetDetails.user_ids = [];
    this.assetDetails.unlink_user_ids = [];
    this.assetDetails.asset_condition = this.assetDetails.condition;
    this.oldAssetDetails = { ...this.assetDetails };
    this.assetDetails.purchased_date = this._formatService.formatDate(this.assetDetails.purchased_date);
    this.assetDetails.renewal_date = this._formatService.formatDate(this.assetDetails.renewal_date);
    this.assetDetails.warranty_expiry_date = this._formatService.formatDate(this.assetDetails.warranty_expiry_date);
    this.assetDetails.delete_attachments = [];
    this.assetDetails.asset_condition = this.assetDetails.condition;
    this.assetDetails.asset_mapping.forEach(item => {
      index = this.users.map(x => x.employee_number).indexOf(item.assigned_user_id);
      if (index !== -1) {
        this.selectedUsersList.push(this.users[index]);
      }
    });
  }

  // check if the po  details are correct or not
  poCheck() {
    let endPoint = '/procurement/check/po/', req;
    if (this.assetDetails.po_number) {
      this.showSpinner = true;
      req = { 'po_num': this.assetDetails.po_number };
      this._httpService.httpRequest('POST', endPoint, req, (data) => {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ msg: 'Server Error - POCheck()', status: 1 });
        } else if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          this.focusPONumber = data.po_status;
        }
      });
    } else {
      this.focusPONumber = true;
    }
  }

  removeFocus() {
    this.focusAssetType = !!this.assetDetails.asset_type;
    this.focusAssetSubType = !!this.assetDetails.asset_sub_type;
    this.focusBrand = !!this.assetDetails.brand;
  }

  // Remove user from asset
  removeUser(user) {
    this.selectedUsersList.splice(this.selectedUsersList.indexOf(user), 1);
  }

  // save asset details
  saveAsset() {
    let endPoint = '/hrms/assetmanagement/asset/', req,
      method, index,
      historyUpdate = false;
    this.showSpinner = true;
    if (this.validateParameters()) {
      this.removeFocus();
      this._appService.notify({ msg: 'Please fill the mandatory fields', status: 1 });
      this.showSpinner = false;
      return;
    }
    req = Object.assign({}, this.assetDetails);
    req.asset_attachments = [];
    req.purchased_price = req.purchases_price.value ? parseFloat(this._formatService.parseNumber(req.purchases_price.value)) : '';
    req.currency_code = req.purchases_price.value && req.purchases_price.type ? req.purchases_price.type : '';
    req.purchased_date = req.purchased_date ? this._formatService.parseDate(req.purchased_date) : '';
    req.warranty_expiry_date = req.warranty_expiry_date ? this._formatService.parseDate(req.warranty_expiry_date) : '';
    req.renewal_date = req.renewal_date ? this._formatService.parseDate(req.renewal_date) : '';
    // to get the asset type id based on the the selection of type, sub type
    index = this.allAssetTypes.map(x => x.asset_type + " " + x.asset_sub_type).indexOf(req.asset_type + " " + req.asset_sub_type);
    req.asset_type_id = index !== -1 ? this.allAssetTypes[index].asset_type_id : null;
    this.assetDetails.asset_attachments.forEach((attachment) => {
      if (!attachment.file_id) {
        req.asset_attachments.push(attachment);
      }
    });
    req.org_id = this._cacheService.getOrgId();
    req.created_id = this.user.user_id;
    req.user_ids = [];

    if (this.assetDetails.asset_id) {
      method = 'PUT';

      // Updating newly added users list
      this.selectedUsersList.forEach(user => {
        index = this.assetDetails.asset_mapping.map(x => x.assigned_user_id).indexOf(user.employee_number);
        if (index === -1) {
          req.user_ids.push(user.employee_number);
        }
      });

      req.unlink_user_ids = [];

      // Updating removed users list
      this.assetDetails.asset_mapping.forEach(user => {
        index = this.selectedUsersList.map(x => x.employee_number).indexOf(user.assigned_user_id);
        if (index === -1) {
          req.unlink_user_ids.push(user.assigned_user_id);
        }
      });
      if (this.checkAssetFields(req)) {
        historyUpdate = true;
      }
    } else {
      this.selectedUsersList.forEach(user => {
        req.user_ids.push(user.employee_number);
      });

      this.historyDescription = 'New asset is created';
      method = 'POST';
      historyUpdate = true;
    }
    this._httpService.httpRequest(method, endPoint, req, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - SaveAsset()', status: 1 });
      } else {
        if (data.hasOwnProperty('status') && data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
          this._router.navigate(['asset-management/summary']);
        } else {
          if (historyUpdate) {
            this.historyDetails(data.asset_id);
          } else {
            this._router.navigate(['asset-management/summary']);
          }
          this._appService.notify({ msg: data.msg, status: data.status });
        }
      }
    });
  }

  // Add user to asset
  selectUsers(user) {
    let userIndex, selectedIndex;
    if (user) {
      userIndex = this.users.map(x => x.employee_number).indexOf(parseInt(user));
      selectedIndex = this.selectedUsersList.map(x => x.employee_number).indexOf(parseInt(user));
      if (userIndex !== -1 && selectedIndex === -1) {
        this.selectedUsersList.push(this.users[userIndex]);
      }
    }
    (document.getElementById('userId') as HTMLFormElement).value = '';
  }

  setFocus() {
    this.focusAssetType = true;
    this.focusAssetSubType = true;
    this.focusBrand = true;
  }

  // update history notes
  updateHistoryDetails(history) {
    history.edit = false;
    history.notes = history.editNotes;
    this.historyDetails(this.assetDetails.asset_id, history);
  }

  validateParameters() {
    this.setFocus();
    return (this.focusAssetType && !this.assetDetails.asset_type) ||
      (this.focusAssetSubType && !this.assetDetails.asset_sub_type) || (this.focusBrand && !this.assetDetails.brand) || (!this.focusPONumber);
  }

}
