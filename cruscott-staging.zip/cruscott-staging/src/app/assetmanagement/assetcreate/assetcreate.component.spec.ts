import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';
import { Router, RouterModule, Routes } from '@angular/router';

import { AssetcreateComponent } from './assetcreate.component';
import { CurrencyComponent } from '../../globals/currency/currency.component';
import { AutocompleteComponent } from '../../globals/autocomplete/autocomplete.component';
import { SpinnerComponent } from '../../globals/spinner/spinner.component';
import { LoginComponent } from '../../login/login.component';

describe('AssetCreateComponent', () => {
  let component: AssetcreateComponent;
  let fixture: ComponentFixture<AssetcreateComponent>;
  let routes: Routes = [{ path: 'login', component: LoginComponent }];
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  const allAssetTypes = [
    {
      'asset_sub_type': 'Monitor',
      'brand': null,
      'asset_type_id': 5,
      'asset_type': 'Hardware'
    },
    {
      'asset_sub_type': 'Furniture',
      'brand': null,
      'asset_type_id': 6,
      'asset_type': 'Hardware'
    },
    {
      'asset_sub_type': 'System',
      'brand': null,
      'asset_type_id': 7,
      'asset_type': 'Software'
    },
    {
      'asset_sub_type': 'Application',
      'brand': null,
      'asset_type_id': 8,
      'asset_type': 'Software'
    },
    {
      'asset_sub_type': 'Security',
      'brand': null,
      'asset_type_id': 9,
      'asset_type': 'Software'
    }
  ];
  const user = { 'user_id': 1 };

  beforeAll(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, HttpClientModule, RouterModule.forRoot(routes), TranslateModule.forRoot()],
      declarations: [AssetcreateComponent, AutocompleteComponent, CurrencyComponent, LoginComponent, SpinnerComponent],
      providers: [{ provide: Router, useValue: mockRouter }]
    })
      .compileComponents();
  }));

  beforeAll(() => {
    fixture = TestBed.createComponent(AssetcreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Add Attachment', () => {
    component.attachmentType = '';
    component.addAttachment();

    component.assetAttachment = null;
    component.addAttachment();

    component.attachmentType = 'Asset Invoice';
    component.assetAttachment = {
      filename: 'sort-icon.png',
      filetype: 'image/png',
      base64: ''
    };
    component.assetDetails.asset_attachments = [];
    component.addAttachment();
    expect(component.assetDetails.asset_attachments.length).toBe(1);
  });

  it('Clear Brand Details', () => {
    component.clearBrandDetails();
    expect(component.assetDetails.brand).toBe('');
  });

  it('Clear History Notes', () => {
    const history = {
      asset_history_id: 278,
      description: 'New asset is created',
      edit: true,
      editNotes: null,
      history_date: '02-Oct-2019',
      notes: 'Testing'
    };
    component.clearHistoryNotes(history);
    expect(history.edit).toBe(false);
    expect(history.editNotes).toBe('Testing');
  });

  it('Clear PO Number', () => {
    component.clearPONumber();
    expect(component.assetDetails.po_number).toBe('');
    expect(component.focusPONumber).toBe(true);
  });

  it('Clear Inventory Number', () => {
    component.clearInventoryNumber();
    expect(component.assetDetails.inventory_number).toBe('');
  });

  it('Close delete attachment dialog', () => {
    component.closeDeleteAttachmentDialog();
    expect(component.deleteAttachment).toBe(null);
    expect(component.deleteAssetAttachment).toBe(false);
  });

  it('Close edit attachment dialog', () => {
    component.closeEditAttachmentDialog();
    expect(component.editAssetAttachment).toBe(false);
  });

  it('Date Check', () => {
    // Check for invalid Purchase date
    component.assetDetails.purchased_date = '07-March-2019';
    component.dateCheck();
    setTimeout(() => {
      expect(component.focusPurchaseDate).toBe(false);
      expect(component.assetDetails.purchased_date).toBe('');
    }, 100);

    // Check for invalid Renewal date
    component.assetDetails.renewal_date = '10-March-2019';
    component.dateCheck();
    setTimeout(() => {
      expect(component.focusRenewalDate).toBe(false);
      expect(component.assetDetails.renewal_date).toBe('');
    }, 100);

    // Check for invalid Warranty expiry date
    component.assetDetails.warranty_expiry_date = '02-October-2019';
    component.dateCheck();
    setTimeout(() => {
      expect(component.focusWarrantyDate).toBe(false);
      expect(component.assetDetails.warranty_expiry_date).toBe('');
    }, 100);

    // Check for Renewal date cannot be greater than Warranty expiry date
    component.assetDetails.renewal_date = '07-Oct-2019';
    component.assetDetails.warranty_expiry_date = '06-Oct-2019';
    component.dateCheck();
    setTimeout(() => {
      expect(component.focusWarrantyDate).toBe(false);
      expect(component.assetDetails.warranty_expiry_date).toBe('');
    }, 100);

    // Check for Purchase date cannot be greater than Renewal date
    component.assetDetails.purchased_date = '07-Oct-2019';
    component.assetDetails.renewal_date = '06-Oct-2019';
    component.dateCheck();
    setTimeout(() => {
      expect(component.focusRenewalDate).toBe(false);
      expect(component.assetDetails.renewal_date).toBe('');
    }, 100);

    // Check for Purchase date cannot be greater than Warranty expiry data
    component.assetDetails.purchased_date = '07-Oct-2019';
    component.assetDetails.warranty_expiry_date = '06-Oct-2019';
    component.dateCheck();
    setTimeout(() => {
      expect(component.focusWarrantyDate).toBe(false);
      expect(component.assetDetails.warranty_expiry_date).toBe('');
    }, 100);

    // When all dates are valid
    component.assetDetails.purchased_date = '05-Oct-2019';
    component.assetDetails.renewal_date = '06-Oct-2019';
    component.assetDetails.warranty_expiry_date = '07-Oct-2019';
    component.dateCheck();
    setTimeout(() => {
      expect(component.focusPurchaseDate).toBe(true);
      expect(component.focusRenewalDate).toBe(true);
      expect(component.focusWarrantyDate).toBe(true);
    }, 100);
  });

  it('Cancel Asset - Go to Summary Page', () => {
    component.cancelAsset();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['asset-management/summary']);
  });

  it('Asset sub type details', () => {
    component.allAssetTypes = allAssetTypes;
    component.assetDetails.asset_type = 'Software';
    component.assetSubTypeDetails();
    expect(component.assetSubTypes.length).toBe(3);
  });

  it('Check Asset Fields - To Update History', () => {
    component.users = [
      {
        'employee_number': 1,
        'full_name': 'Reddy, Bhimireddy'
      }
    ];
    const asset = {
      'asset_id': 120,
      'status': 'Available',
      'po_number': null,
      'license_number': '1234',
      'brand': 'HP',
      'asset_sub_type': 'Mouse',
      'model': '1',
      'purchased_price:': '14.5',
      'asset_type': 'Hardware',
      'f_brand_model': 'HP 1',
      'user_ids': [1]
    };
    component.oldAssetDetails = {
      'asset_id': 120,
      'status': 'Available',
      'po_number': null,
      'license_number': '1234',
      'brand': 'Dell',
      'asset_sub_type': 'Mouse',
      'model': '1',
      'purchased_price:': '14.5',
      'asset_type': 'Hardware',
      'f_brand_model': 'HP 1',
      'user_ids': []
    };
    const historyDescription = 'Asset Invoice : sort-icon.png is added . Brand is changed from Dell to HP. Asset assigned to Reddy, Bhimireddy. ';
    component.checkAssetFields(asset);
    expect(component.historyDescription).toEqual(historyDescription);
  });

  it('Delete Attachment', () => {
    const attach = {
      'file_type': 'image/png',
      'file_name': 'sort-icon.png',
      'file_content': '',
      'file_id': 80
    };
    component.assetDetails.asset_attachments = [
      {
        'file_type': 'image/png',
        'file_name': 'sort-icon.png',
        'file_content': '',
        'file_id': 80
      },
      {
        'file_type': 'image/png',
        'file_name': 'abc.png',
        'file_content': ''
      }
    ];
    component.deleteAttachmentDetails(attach);
    expect(component.assetDetails.delete_attachments.length).toBe(1);
  });

  it('Delete Attachment Dialog', () => {
    const attach = {
      'file_type': 'image/png',
      'file_name': 'sort-icon.png',
      'file_content': '',
      'file_id': 80
    };
    component.deleteAttachmentDialog(attach);
    expect(component.deleteAssetAttachment).toBe(true);
  });

  it('Download Attachment', () => {
    const attach = {
      'file_type': 'image/png',
      'file_name': '5410_226 (1).png',
      'file_content': 'iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAYFBMVEX///8zMzMoKCiKiooPDw8UFBS8vLy5ubm4uLjAwMAlJSUQEBD8/PwvLy+SkpLn5+cHBwchISGwsLBGRkZ9fX13d3dwcHDQ0NAXFxepqamfn59cXFxAQEDa2trNzc1hYWGbBDHnAAAC/ElEQVR4nO3diXaiQBCFYXAHV4xLzCTm/d9yRM8koOLI0lZ31f89AXUuoYh0d0URAAAAAAAAAAAAAAAAAKCZ2Xr3Z7eeSV+GO8cs6817WXqUvhBXkkF8MUikL8WNnwK1lpgM419DhSWOBnHRVF2JpQQ1pphM42u6UhxdJ3hOcSR9Wd1JBncK1PREvZugphQrEtST4qi6wFOJClK88xQt3ajBp/gwQQ0p3jR6bSk+eMgUUgy4xMo2cZVisDfqUwmGnOLo8VO0aBpkik8nGGqK4zoFhtg0atyiF6H9M1UzwfBSfLJNlIXUNP77qhZ6iuMmCZ5THEtf+nMaJhhOiuO6T9GiaQAptkjwnKL3TWPSrsBTiZ6nWLvR3/L7HbVBow8rxcZtoszfptFJgjlfU+wowZyfKbZsE2U+tv5J+6do0XQiXdC1ThPM+ZZi60Z/p0SvUmz1LlrFp9bvIMGcPyl22CbKfGkanTX6W360/omrBHNDD25Uhwnm5FPsuNHfkm79XyvHBcbx6ku0ws+58wrnn5IFHt+dFxjH73vBCj/SF1SYfghWuOi9osKFYIXr7AUVZmvBCpcuu/0/w6VghdHW/R9iupEsMJq9uS4xfRMt8FTiZpX23ElXG/ndGcvDou/K4iD6NwgAAAAAAAAAMGZ5cPaTd7/vwW/es53j7xZb6e8W6r89bV7w/XArWaD+b8D6v+PrX4uhfz3NXv2aqJesa5NtF3v1axP1ry81sEbYwDpvA2v1Dey3MLBnxtW+J28SzKnfu2Zg/6GBPaQG9gEb2MttYD++gTMVDJyLYeBsEwPn0xg4Y6hl6/frXbSK+rO+DJzXZuDMPQPnJjY7+zKYW/SidusPK8Gc+jNoDZwjXOvnKd/fRauoP8/bwJnsBs7VNzAbwcB8CwMzSgzMmTEwK+jBO2rIbaJM/cwuA3PXDMzOMzD/0MAMSwNzSEspanqKFiWDy0rGudYCo+jYO890nqud6ZzP5d5+bzXP5QYAAAAAAAAAAAAAAAAAx/4CiZouGKiemOEAAAAASUVORK5CYII=',
      'file_id': 59,
      'created_date': '02-OCT-2019'
    };
    component.downloadAttachment(attach);
  });

  it('Edit Attachment Details', () => {
    component.user = user;
    component.editAttachmentFileId = 80;
    component.attachmentType = 'Asset Invoice';
    const attach = {
      'filetype': 'image/png',
      'filename': 'sort-icon.png',
      'base64': ''
    };
    component.assetDetails.asset_attachments = [
      {
        'file_type': 'image/png',
        'file_name': 'sort-icon.png',
        'file_content': '',
        'file_id': 80,
        'attachment_type': 'Asset Invoice'
      }
    ];
    component.editAttachmentDetails(attach);
    expect(component.focusEditAttachmentType).toBe(true);
  });

  it('Edit Attachment Dialog', () => {
    const attach = {
      'file_type': 'image/png',
      'file_name': 'sort-icon.png',
      'file_content': '',
      'file_id': 80,
      'attachment_type': 'Asset Invoice'
    };
    component.editAttachmentDialog(attach);
    expect(component.editAssetAttachment).toBe(true);
    expect(component.editAttachmentFileId).toBe(80);
    expect(component.attachmentType).toBe('Asset Invoice');
  });

  it('Go to Step', () => {
    component.goToStep(1);
    expect(component.selection).toBe('Attachments');
  });

  it('Go to Summary Page', () => {
    component.goToSummary();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['asset-management/summary']);
  });

  it('Add/Edit history details', () => {
    const historyDetails = {
      'edit': false,
      'notes': 'Testing'
    };
    component.user = user;
    component.historyDetails(12, historyDetails);

    component.historyDetails(13);
  });

  it('History details to update', () => {
    expect(component.historyDetailsToUpdate('model', 'Dell', '')).toBe('Model is cleared from Dell. ');

    expect(component.historyDetailsToUpdate('model', '', 'Intel')).toBe('Model is added - Intel. ');
  });

  // To Do
  it('Load Currencies', () => {
    component.loadCurrencies();
  });

  // To Do
  it('Load Location and AssetTypes', () => {
    component.loadLocationAndAssetTypes();
  });

  // To Do
  it('Load requested Asset', () => {
    component.loadRequestedAsset(12);
  });

  // To Do
  it('Load Users', () => {
    component.loadUsers();
  });

  it('On download', () => {
    let attach = {
      'file_type': 'image/png',
      'file_name': 'sort-icon.png',
      'file_content': '',
      'file_id': 80,
      'attachment_type': 'Asset Invoice'
    };
    // Called with out file content
    component.onDownload(attach);

    attach = {
      'file_type': 'image/png',
      'file_name': 'sort-icon.png',
      'file_content': 'abcd',
      'file_id': 80,
      'attachment_type': 'Asset Invoice'
    };
    // Called with file content
    component.onDownload(attach);
  });

  it('Parse Asset details', () => {
    component.allAssetTypes = allAssetTypes;
    const data = [
      {
        'asset_life_time': null,
        'inventory_number': '123654',
        'location_id': null,
        'asset_id': 136,
        'location_name': null,
        'license_number': '123',
        'renewal_date': null,
        'serial_number': null,
        'status': null,
        'asset_mapping': [],
        'service_history': [],
        'description': null,
        'purchased_date': null,
        'brand': 'Dell',
        'asset_sub_type': 'Monitor',
        'purchased_price': null,
        'asset_type': 'Hardware',
        'assest_type_id': 5,
        'condition': null,
        'asset_attachments': [],
        'po_number': null,
        'asset_history': [
          {
            'notes': null,
            'history_date': '24-Oct-2019',
            'description': 'New asset is created',
            'asset_history_id': 344
          }
        ],
        'warranty_expiry_date': null,
        'model': null,
        'currency_code': 'EUR'
      }
    ];
    component.parseRequestedAsset(data);
    expect(component.selectedUsersList.length).toBe(0);
  });

  it('PO Check', () => {
    component.poCheck();
    expect(component.focusPONumber).toBe(true);

    component.assetDetails.po_number = '123';
    component.poCheck();
  });

  it('Remove focus', () => {
    component.assetDetails.asset_type = 'Hardware';
    component.removeFocus();
    expect(component.focusAssetType).toBe(true);
  });

  it('Remove user', () => {
    component.selectedUsersList = [
      {
        'employee_number': 1,
        'full_name': 'Reddy, Bhimireddy'
      },
      {
        'employee_number': 2,
        'full_name': 'Jannumahanthi, Mrudula'
      }
    ];
    const user = {
      'employee_number': 1,
      'full_name': 'Reddy, Bhimireddy'
    };
    component.removeUser(user);
    expect(component.selectedUsersList.length).toBe(1);
  });

  it('Save Asset details', () => {
    component.user = user;
    component.assetDetails = {
      'asset_life_time': null,
      'inventory_number': '123654',
      'location_id': null,
      'asset_id': 136,
      'location_name': null,
      'license_number': '123',
      'renewal_date': null,
      'serial_number': null,
      'status': null,
      'asset_mapping': [],
      'service_history': [],
      'description': null,
      'purchased_date': null,
      'brand': 'Dell',
      'asset_sub_type': 'Monitor',
      'purchases_price': {
        'type': 'EUR',
        'value': '123'
      },
      'asset_type': 'Hardware',
      'condition': null,
      'asset_attachments': [],
      'po_number': null,
      'asset_history': [
        {
          'notes': null,
          'history_date': '24-Oct-2019',
          'description': 'New asset is created',
          'asset_history_id': 344
        }
      ],
      'warranty_expiry_date': null,
      'model': null,
      'currency_code': 'EUR'
    };
    component.saveAsset();
  });

  it('Select Users', () => {
    component.users = [
      {
        'employee_number': 1,
        'full_name': 'Reddy, Bhimireddy'
      },
      {
        'employee_number': 2,
        'full_name': 'Jannumahanthi, Mrudula'
      }
    ];
    component.selectedUsersList = [
      {
        'employee_number': 1,
        'full_name': 'Reddy, Bhimireddy'
      }
    ];
    component.selectUsers(2);
    expect(component.selectedUsersList.length).toBe(2);
  });

  it('Update history details', () => {
    component.user = user;
    const history = {
      'edit': true,
      'editNotes': 'Test'
    };
    component.updateHistoryDetails(history);
    expect(history.edit).toBe(false);
  });

});
