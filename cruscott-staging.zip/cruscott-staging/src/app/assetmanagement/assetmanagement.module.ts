import { NgModule } from '@angular/core';
import { AssetManagementRoutingModule } from './assetmanagement-routing.module';
import { ShareModule } from '../share/share.module';
import { AssetcreateComponent } from './assetcreate/assetcreate.component';
import { AssetsummaryComponent } from './assetsummary/assetsummary.component';

@NgModule({
  declarations: [
    AssetsummaryComponent,
    AssetcreateComponent
  ],
  imports: [
    AssetManagementRoutingModule,
    ShareModule
  ]
})
export class AssetManagementModule { }
