import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssetcreateComponent } from './assetcreate/assetcreate.component';
import { AssetsummaryComponent } from './assetsummary/assetsummary.component';

const routes: Routes = [
  { path: 'summary', component: AssetsummaryComponent },
  { path: 'create', component: AssetcreateComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})


export class AssetManagementRoutingModule { }
