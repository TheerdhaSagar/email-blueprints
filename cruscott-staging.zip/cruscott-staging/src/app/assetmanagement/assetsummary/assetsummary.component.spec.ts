import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';
import { Router, RouterModule, Routes } from '@angular/router';

import { AssetsummaryComponent } from './assetsummary.component';
import { LoginComponent } from '../../login/login.component';
import { SpinnerComponent } from '../../globals/spinner/spinner.component';

describe('AssetSummaryComponent', () => {
  let component: AssetsummaryComponent;
  let fixture: ComponentFixture<AssetsummaryComponent>;
  let routes: Routes = [{ path: 'login', component: LoginComponent }];
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  const assetSummary = [
    {
      'asset_id': 118,
      'status': 'Available',
      'asset_mapping': null,
      'location_name': null,
      'po_number': null,
      'license_number': null,
      'brand': 'HP',
      'renewal_date': null,
      'asset_sub_type': 'Monitor',
      'purchased_date': '02-oct-2019',
      'purchased_price': null,
      'warranty_expiry_date': null,
      'serial_number': null,
      'model': '2',
      'location_id': null,
      'asset_type': 'Hardware',
      'currency_code': null,
      'year': 2019
    },
    {
      'asset_id': 117,
      'status': 'Available',
      'asset_mapping': null,
      'location_name': null,
      'po_number': null,
      'license_number': null,
      'brand': 'HP',
      'renewal_date': null,
      'asset_sub_type': 'Monitor',
      'purchased_date': '15-aug-2017',
      'purchased_price': null,
      'warranty_expiry_date': null,
      'serial_number': null,
      'model': '1',
      'location_id': null,
      'asset_type': 'Hardware',
      'currency_code': 'EUR',
      'year': 2017
    },
    {
      'asset_id': 119,
      'status': 'Assigned',
      'asset_mapping': null,
      'location_name': null,
      'po_number': null,
      'license_number': null,
      'brand': 'Dell',
      'renewal_date': null,
      'asset_sub_type': 'Macfree',
      'purchased_date': '25-nov-2020',
      'purchased_price': null,
      'warranty_expiry_date': null,
      'serial_number': null,
      'model': '1',
      'location_id': null,
      'asset_type': 'Software',
      'currency_code': null,
      'year': 2020
    }
  ];

  beforeAll(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, HttpClientModule, InfiniteScrollModule, RouterModule.forRoot(routes), TranslateModule.forRoot()],
      declarations: [AssetsummaryComponent, LoginComponent, OrderByPipe, SpinnerComponent],
      providers: [{ provide: Router, useValue: mockRouter }]
    })
      .compileComponents();
  }));

  beforeAll(() => {
    fixture = TestBed.createComponent(AssetsummaryComponent);
    component = fixture.componentInstance;

    component['_window'].ga = () => {};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Edit Asset', () => {
    const asset = {
      'asset_life_time': null,
      'location_id': null,
      'asset_id': 121,
      'location_name': null,
      'license_number': null,
      'renewal_date': null,
      'serial_number': null,
      'status': null,
      'asset_mapping': [],
      'service_history': [],
      'description': null,
      'purchased_date': null,
      'brand': 'HP',
      'asset_sub_type': 'Keyboard',
      'purchased_price': null,
      'asset_type': 'Hardware',
      'condition': null,
      'asset_attachments': [],
      'po_number': null,
      'asset_history': [
        {
          'notes': null,
          'history_date': '02-Oct-2019',
          'description': 'New asset is created',
          'asset_history_id': 278
        }
      ],
      'warranty_expiry_date': null,
      'model': '1',
      'currency_code': null
    };
    component.editAsset(asset);
    expect(component['_appService'].assetId).toBe(asset.asset_id);
  });

  it('Export Data', () => {
    component.assetSummary = [
      {
        'asset_id': 120,
        'status': 'Available',
        'asset_mapping': null,
        'location_name': null,
        'po_number': null,
        'license_number': null,
        'brand': 'HP',
        'renewal_date': null,
        'asset_sub_type': 'Mouse',
        'purchased_date': null,
        'purchased_price': null,
        'warranty_expiry_date': null,
        'serial_number': null,
        'model': '1',
        'location_id': null,
        'asset_type': 'Hardware',
        'currency_code': null,
        'formatted_purchased_price': '',
        'f_purchase_date': null,
        'f_purchase_date_millis': 0,
        'f_renewal_date': null,
        'f_renewal_date_millis': 0,
        'f_warranty_date': null,
        'f_warranty_date_millis': 0,
        'f_brand_model': 'HP 1',
        'users': [],
        'moreUsers': [],
        'user_name': ''
      },
      {
        'asset_id': 121,
        'status': null,
        'asset_mapping': '21',
        'location_name': null,
        'po_number': null,
        'license_number': null,
        'brand': 'HP',
        'renewal_date': null,
        'asset_sub_type': 'Keyboard',
        'purchased_date': null,
        'purchased_price': null,
        'warranty_expiry_date': null,
        'serial_number': null,
        'model': '1',
        'location_id': null,
        'asset_type': 'Hardware',
        'currency_code': 'EUR',
        'formatted_purchased_price': '',
        'f_purchase_date': null,
        'f_purchase_date_millis': 0,
        'f_renewal_date': null,
        'f_renewal_date_millis': 0,
        'f_warranty_date': null,
        'f_warranty_date_millis': 0,
        'f_brand_model': 'HP 1',
        'users': [
          {
            'card_number': null,
            'default_org_id': 82,
            'email_address': 'saikrishna@finday.com',
            'employee_number': 21,
            'full_name': 'Valvassori, Claudio',
            'person_id': 94,
            'user_name': 'CLAUDIO'
          }
        ],
        'moreUsers': [],
        'user_name': 'Valvassori, Claudio'
      }
    ];
    component.toggleFilter();
    component.exportData();
  });

  it('Filter Search', () => {
    component.searchQuery = '';
    component.allAssets = assetSummary;
    component.filterSearch();
    expect(component.assetSummary.length).toBe(3);

    component.searchQuery = 'Desktop';
    component.filterSearch();
    expect(component.assetSummary.length).toBe(0);
  });

  it('Load More', () => {
    component.currentPage = 1;
    component.loadMore();
  });

  it('Parse Asset Details', () => {
    component.parseAssetDetails(assetSummary);
    expect(component.allAssets.length).toBe(3);
    expect(component.assetSummary.length).toBe(3);
  });

  it('Sort with same key and Search query', () => {
    component.allAssets = assetSummary;
    component.desc = true;
    component.searchQuery = 'Software';
    component.filterSearch();
    component.sort('asset_id');
    expect(component.assetSummary.length).toBe(1);
    expect(component.assetSummary[0].asset_id).toBe(119);
  });

  it('Sort with different key and no Search query', () => {
    component.allAssets = assetSummary;
    component.desc = true;
    component.searchQuery = '';
    component.sort('asset_type');
    expect(component.assetSummary[0].asset_type).toBe('Software');
  });

  it('Go to asset creation page', () => {
    component.addAsset();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['asset-management/create']);
  });

  it('Apply Filter', () => {
    component.allAssets = assetSummary;
    component.applyFilter();
    expect(component.assetSummary.length).toBe(3);

    component.assetStatus = 'Assigned';
    component.applyFilter();
    expect(component.assetSummary.length).toBe(1);

    component.selectedYear = '2019';
    component.assetStatus = '';
    component.applyFilter();
    expect(component.assetSummary.length).toBe(1);

    component.selectedYear = '2020';
    component.assetStatus = 'Assigned';
    component.applyFilter();
    expect(component.assetSummary.length).toBe(1);
  });

  // To Do
  it('Load Asset Summary', () => {
    component.loadAssetSummary();
  });

  // To Do
  it('Load Users', () => {
    component.loadUsers();
  });

  it('Delete Asset', () => {
    const asset = {
      'asset_id': 120,
      'status': 'Available',
      'asset_sub_type': 'Mouse',
    };
    component.deleteAsset(asset);
  });

});
