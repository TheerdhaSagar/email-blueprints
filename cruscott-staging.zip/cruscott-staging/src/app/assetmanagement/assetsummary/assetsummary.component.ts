import {
  Component,
  Injector,
  OnDestroy,
  OnInit
} from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/globals/common.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { HttpService } from '../../globals/http.service';
import { FormatService } from '../../globals/format.service';
import { FilterPipe } from '../../globals/filter.pipe';

@Component({
  selector: 'app-assetsummary',
  templateUrl: './assetsummary.component.html',
  styleUrls: ['./assetsummary.component.scss'],
  providers: [FilterPipe, OrderByPipe]
})
export class AssetsummaryComponent implements OnInit, OnDestroy {
  private _appService: AppService = this._injector.get(AppService);
  private _cacheService: CacheService = this._injector.get(CacheService);
  private _commonService: CommonService = this._injector.get(CommonService);
  private _filter: FilterPipe = this._injector.get(FilterPipe);
  private _formatService: FormatService = this._injector.get(FormatService);
  private _httpService: HttpService = this._injector.get(HttpService);
  private _orderBy: OrderByPipe = this._injector.get(OrderByPipe);
  private _router: Router = this._injector.get(Router);


  allAssets: any[];
  assetStatus: string;
  assetSummary: any[];
  currentPage: number;
  dateFormat: string;
  deleteAssetDetails: any;
  deleteAssetFlag: boolean;
  desc: boolean;
  numberFormat: string;
  orgId: number;
  pageSize: number;
  predicate: string;
  searchQuery: string;
  selectedYear: string;
  showSpinner: boolean;
  statusList: any[];
  subOrgChange: any;
  toggleFilter: (e?) => void;
  user: any;
  userId: any;
  users: any[];
  yearsList: any[];

  constructor(private _injector: Injector) {
    this.allAssets = [];
    this.assetStatus = '';
    this.assetSummary = [];
    this.currentPage = 1;
    this.dateFormat = null;
    this.deleteAssetDetails = null;
    this.deleteAssetFlag = false;
    this.desc = true;
    this.numberFormat = null;
    this.orgId = null;
    this.pageSize = this._appService.pageSize;
    this.predicate = 'asset_id';
    this.searchQuery = null;
    this.selectedYear = '';
    this.showSpinner = true;
    this.statusList = ['In-Transit', 'Assigned', 'Available', 'Retired', 'Destroyed', 'Lost'];
    this.subOrgChange = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.userId = null;
    this.users = [];
    this.yearsList = [];
  }

  ngOnInit(): void {
    this.showSpinner = true;
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        this.userId = this.user.user_id;
        this.orgId = this._cacheService.getOrgId();
        this.dateFormat = this.user.date_format || 'dd-MM-yyyy';
        this.numberFormat = this.user.number_format || '999.999,99';
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this._appService.scrollTop();
        this.loadUsers();
      }
    });
    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this.showSpinner = true;
      this.loadAssetSummary();
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  // add a new asset
  addAsset(): void {
    this._router.navigate(['asset-management/create']);
  }

  applyFilter(): void {
    this.toggleFilter();
    if (this.assetStatus && !this.selectedYear) {
      this.assetSummary = this.allAssets.filter(asset => asset.status === this.assetStatus);
    } else if (!this.assetStatus && this.selectedYear) {
      this.assetSummary = this.allAssets.filter(asset => asset.year === parseInt(this.selectedYear));
    } else if (this.assetStatus && this.selectedYear) {
      this.assetSummary = this.allAssets.filter(asset => asset.status === this.assetStatus && asset.year === parseInt(this.selectedYear));
    } else {
      this.assetSummary = this.allAssets;
    }
    this.assetSummary = this._orderBy.transform(this.assetSummary, this.predicate, this.desc);
  }

  // delete the asset
  deleteAsset(asset): void {
    const endPoint = `/hrms/assetmanagement/asset/${asset.asset_id}/`;
    this.showSpinner = true;
    this.deleteAssetFlag = false;
    this.deleteAssetDetails = null;
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ msg: 'Server Error - DeleteAsset()', status: 1 });
        } else {
          this._appService.notify({ msg: data.msg, status: data.status });
          if (data.status === 0) {
            this.loadAssetSummary();
          }
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: `<pre>${e.stack}</pre>`
        });
      }
    });

  }

  // edit an asset
  editAsset(asset): void {
    this._appService.assetId = asset.asset_id;
    this._router.navigate(['asset-management/create']);
  }

  // export to excel sheet
  exportData(): void {
    this.toggleFilter();
    let tableData = { data: [] },
      tmpObj, tmpData = [], users,
      exportData = this._orderBy.transform(this.assetSummary, this.predicate, this.desc);
    for (let i = 0; i < exportData.length; i++) {
      users = '';
      exportData[i].users.forEach(user => {
        users += users ? ' - ' + user.full_name : user.full_name;
      });
      tmpObj = {};
      tmpObj['Brand and Model'] = {
        data: exportData[i].f_brand_model
      };
      tmpObj.Type = {
        data: exportData[i].asset_type
      };
      tmpObj['Sub-Type'] = {
        data: exportData[i].asset_sub_type
      };
      tmpObj.Location = {
        data: exportData[i].location_name
      };
      tmpObj['Purchase Date'] = {
        data: exportData[i].f_purchase_date
      };
      tmpObj['Purchase Price'] = {
        data: exportData[i].purchased_price
      };
      tmpObj['Currency Code'] = {
        data: exportData[i].currency_code
      };
      tmpObj['Expiry Date'] = {
        data: exportData[i].f_warranty_date
      };
      tmpObj['Renewal Date'] = {
        data: exportData[i].f_renewal_date
      };
      tmpObj.Users = {
        data: users
      };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('AssetManagement', tableData);
  }

  // search the table with the search value
  filterSearch(): void {
    let search = this.searchQuery;
    let tmp_data;
    this.currentPage = 1;
    if (search) {
      tmp_data = this._filter.transform(this.allAssets, search, '');
      this.assetSummary = tmp_data.slice(this.currentPage - 1, this.pageSize);
    } else {
      this.assetSummary = this.allAssets.slice(this.currentPage - 1, this.pageSize);
    }
  }

  // Get the purchased year of the asset
  getAssetYear(asset): void {
    let index, year;
    if (asset.purchased_date) {
      year = asset.purchased_date.split('-');
      asset.year = parseInt(year[2]);
      index = this.yearsList.findIndex(value => value === parseInt(year[2]));
      if (index === -1) {
        this.yearsList.push(parseInt(year[2]));
      }
    }
  }

  loadAssetSummary(): void {
    const endPoint = `/hrms/assetmanagement/summary/${this._cacheService.getOrgId()}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error-LoadAssetSummary()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: 1 });
      } else {
        this.parseAssetDetails(data.summary);
      }
    });
  }

  // Load more records on scroll
  loadMore(): void {
    try {
      let page = this.currentPage + 1, tempData, i,
        startIndex = (page - 1) * this.pageSize, endIndex = page * this.pageSize;
      this.currentPage = page;
      if (this.allAssets) {
        tempData = this.allAssets.slice(startIndex, endIndex);
        for (i = 0; i < tempData.length; i++) {
          this.assetSummary.push(tempData[i]);
        }
      }
    } catch (e) {
      this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
    }
  }

  // Load all users
  loadUsers(): void {
    this._commonService.loadPersons((data) => {
      this.users = data;
      this.loadAssetSummary();
    });
  }

  // parse the summary details
  parseAssetDetails(assetDetails): void {
    let split;
    let index;
    const data = assetDetails;
    this.allAssets = [];
    this.assetSummary = [];
    for (let i = 0; i < data.length; i++) {
      data[i].year = '';
      this.getAssetYear(data[i]);
      data[i].formatted_purchased_price = data[i].purchased_price ? this._formatService.formatNumber(data[i].purchased_price) : '';
      data[i].f_purchase_date = this._formatService.formatDate(data[i].purchased_date);
      data[i].f_purchase_date_millis = this._formatService.dateInMillis(data[i].purchased_date);
      data[i].f_renewal_date = this._formatService.formatDate(data[i].renewal_date);
      data[i].f_renewal_date_millis = this._formatService.dateInMillis(data[i].renewal_date);
      data[i].f_warranty_date = this._formatService.formatDate(data[i].warranty_expiry_date);
      data[i].f_warranty_date_millis = this._formatService.dateInMillis(data[i].warranty_expiry_date);
      data[i].f_brand_model = `${data[i].brand} ${data[i].model}`;
      data[i].users = [];
      data[i].moreUsers = [];
      if (data[i].asset_mapping) {
        split = data[i].asset_mapping.split(',');
        split.forEach(value => {
          index = this.users.map(x => x.employee_number).indexOf(parseInt(value));
          if (index !== -1) {
            data[i].users.push(this.users[index]);
          }
        });
      }
      data[i].user_name = data[i].users[0] ? data[i].users[0].full_name : '';
      if (data[i].users.length > 1) {
        for (let j = 1; j < data[i].users.length; j++) {
          data[i].moreUsers.push(data[i].users[j].full_name);
        }
      }
    }
    this.yearsList = this.yearsList.sort();
    if (data.length > 0) {
      this.allAssets = data;
      this.allAssets = this._orderBy.transform(this.allAssets, this.predicate, this.desc);
      this.currentPage = 1;
      this.assetSummary = this.allAssets.slice(this.currentPage - 1, this.pageSize);
    }

  }

  sort(key): void {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
    }

    if (this.searchQuery) {
      this.assetSummary = this._orderBy.transform(this.assetSummary, this.predicate, this.desc);
    } else {
      this.allAssets = this._orderBy.transform(this.allAssets, this.predicate, this.desc);
      this.currentPage = 1;
      this.assetSummary = this.allAssets.slice(this.currentPage - 1, this.pageSize);
    }
  }
}
