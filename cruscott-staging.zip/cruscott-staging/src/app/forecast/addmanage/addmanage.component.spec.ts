import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddmanageComponent } from './addmanage.component';

describe('AddmanageComponent', () => {
  let component: AddmanageComponent;
  let fixture: ComponentFixture<AddmanageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddmanageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddmanageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
