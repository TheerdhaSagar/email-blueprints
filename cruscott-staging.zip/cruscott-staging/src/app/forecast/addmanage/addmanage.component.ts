import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-forecast-addmanage',
  templateUrl: './addmanage.component.html',
  styleUrls: ['./addmanage.component.scss'],
  providers: [OrderByPipe]
})
export class AddManageForecastComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  addDialog: any;
  addNewFocus: boolean;
  addPage: any;
  categories: any;
  categoriesMain: any[];
  categoryId: any;
  categoryMain: any[];
  categoryName: any;
  currentStep: number;
  dateFormat: any;
  dateFormatExample: string;
  dateFormats: any[];
  deletedFocuses: any[];
  deleteId: any;
  deleteIndex: any;
  deleteRow: any;
  dialogMsg: any;
  editClose: any;
  editFocus: any;
  editOpen: any;
  editPage: any;
  editPromoMode: boolean;
  editSegment: any;
  endDate: any;
  errorMsg: any;
  expandObject: any;
  focusDisplay: boolean;
  focusEndDate: boolean;
  focusFlag: any;
  focusFocus: boolean;
  focusIndex: any;
  focusLines: any;
  focusPromo: boolean;
  focusSales: boolean;
  focusStartDate: boolean;
  forecast: { errorStatus: boolean; calloutStatus: boolean; errorMsg: string; successStatus: boolean };
  loadItems: any[];
  newMsg: any;
  newStatus: any;
  notificationDialog: any;
  pageDim: any;
  pdelete: any;
  percent: any;
  promoDialog: any;
  promoId: any;
  promoName: any;
  promoDeleteDialog: any;
  promotionDetails: any;
  roles: any;
  salesGroups: any[];
  segmentItems: any[];
  selectedGroup: any;
  selectedGrp: any;
  selectSave: any;
  showDialog: any;
  showSales: boolean;
  showSpinner: boolean;
  showtable: boolean;
  status: any;
  startDate: any;
  steps: ({ step_number: number; step_name: string })[];
  stepsCount: number;
  tmpIndex: any;
  tmpObjectives: any[];
  toggle: any;
  toggleFilter: (e?) => void;
  user: any;
  userDateFormat: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, orderBy: OrderByPipe,
              formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.addDialog = null;
    this.addNewFocus = false;
    this.addPage = null;
    this.categories = null;
    this.categoriesMain = [];
    this.categoryId = null;
    this.categoryName = null;
    this.currentStep = 1;
    this.dateFormat = null;
    this.deletedFocuses = [];
    this.deleteId = null;
    this.deleteIndex = null;
    this.deleteRow = null;
    this.dialogMsg = null;
    this.editClose = null;
    this.editFocus = [];
    this.editOpen = null;
    this.editPage = null;
    this.editSegment = null;
    this.endDate = null;
    this.errorMsg = null;
    this.expandObject = [];
    this.focusDisplay = false;
    this.focusEndDate = true;
    this.focusFlag = null;
    this.focusFocus = true;
    this.focusIndex = null;
    this.focusLines = null;
    this.focusPromo = true;
    this.focusSales = true;
    this.focusStartDate = true;
    this.forecast = {
      calloutStatus: false,
      errorMsg: '',
      errorStatus: false,
      successStatus: false
    };
    this.loadItems = [];
    this.newMsg = null;
    this.newStatus = null;
    this.notificationDialog = null;
    this.pageDim = null;
    this.pdelete = null;
    this.percent = null;
    this.promoDialog = null;
    this.promoId = null;
    this.promoName = null;
    this.promoDeleteDialog = null;
    this.promotionDetails = {};
    this.roles = dataService.roles;
    this.segmentItems = [];
    this.selectedGroup = null;
    this.selectedGrp = null;
    this.selectSave = null;
    this.showDialog = null;
    this.showSales = false;
    this.showtable = false;
    this.status = null;
    this.steps = [{
      step_name: 'Promotion Details',
      step_number: 1
    }, {
      step_name: 'Add Focus',
      step_number: 2
    }, {
      step_name: 'Preview & Save',
      step_number: 3
    }];
    this.startDate = null;
    this.stepsCount = 3;
    this.tmpIndex = null;
    this.tmpObjectives = [];
    this.toggle = null;
    this.toggleFilter = appService.toggleFilter();
    this.user = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.dateFormat = this.user.date_format || 'dd-MMM-yyyy';

        new FooPicker({
          id: 'start-date',
          dateFormat: this.dateFormat
        });
        new FooPicker({
          id: 'end-date',
          dateFormat: this.dateFormat
        });

        if (this._appService.editPage) {
          this.promoId = this._appService.promoId;
          this.editPage = this._appService.editPage;
          this.pageDim = true;
          this.currentStep = 3;
          this._appService.editPage = null;
        }
        if (this._appService.addpage) {
          this.addPage = this._appService.addpage;
          this.selectedGroup = this._appService.selectedGrp;
          this.selectedGrp = this._appService.selectedGrp;
          this._appService.selectedGrp = null;
          this._appService.addpage = null;
        }

        this.loadDateFormats();
        this.loadSalesGroups();
        this.loadCategories();
        this.setUpDOMHandlers();
      }
    });
  }

  addFocus() {
    this.addNewFocus = true;
    this.categoryId = null;
    this.segmentItems = [];
  }

  clearFocus(index?) {
    this.addNewFocus = false;
    this.segmentItems = [];
    this.categoryName = null;
    this.categoryId = null;
    this.focusFocus = true;
    if (index !== null && index !== undefined) {
      this.editFocus['editFocus' + index] = false;
    }

    if (this.editOpen && (index !== undefined && index !== null)) {
      for (let i = 0; i < this.tmpObjectives[index].items.length; i++) {
        let item = this.tmpObjectives[index].items[i];
        if (item.deleted_line && (item.estimated_qty === undefined || item.estimated_qty === null)) {
          item.quantity = '';
        } else {
          item.quantity = item.estimated_qty;
        }
      }
    }

    this.editOpen = false;

    for (let i = 0; i < this.tmpObjectives.length; i++) {
      if (this.editFocus['editFocus' + i] && this.expandObject['expandObject' + i]) {
        this.editOpen = true;
        break;
      }
    }
  }

  closeNotificationDialog() {
    if (this.editOpen) {
      for (let index = 0; index < this.tmpObjectives.length; index++) {
        for (let i = 0; i < this.tmpObjectives[index].items.length; i++) {
          let item = this.tmpObjectives[index].items[i];
          if (item.deleted_line && (item.estimated_qty === undefined || item.estimated_qty === null)) {
            item.quantity = '';
          } else {
            item.quantity = item.estimated_qty;
          }
        }
      }

      this.currentStep = 3;
      this.goToStep(3);
    }

    this.addNewFocus = false;
    this.notificationDialog = false;
    this.focusFocus = true;
    this.editOpen = false;
    this.categoryId = null;
    this.segmentItems = [];
  }

  // to close and redirect to summary page
  closePage() {
    this._appService.addpage = false;
    this._appService.editPage = false;
    this._appService.selectedGrp = this.selectedGrp;

    this.addDialog = false;
    this.addPage = false;
    this.categories = this.categoriesMain;
    this.categoryId = null;
    this.dialogMsg = null;
    this.editClose = false;
    this.editSegment = false;
    this.endDate = '';
    this.focusFocus = true;
    this.loadItems = [];
    this.percent = '';
    this.pdelete = false;
    this.promoId = null;
    this.promoName = '';
    this.segmentItems = [];
    this.startDate = '';
    this.tmpObjectives = [];

    this._router.navigate(['purchasing/forecast/manage']);
  }

  continueStep() {
    if (this.currentStep === 1) {
      this.errorMsg = '';
      if (!this.startDate || !this.endDate || !this.selectedGrp || !this.promoName) {
        this.promoErrors();
        this.errorMsg = 'End Date is required';
        this.notificationMsgs('Promotion Details are mandatory');
        return;
      }
      let compareDate = this._formatService.dateInMillis(this._formatService.parseDate(this.startDate)) > this._formatService.dateInMillis(this._formatService.parseDate(this.endDate));
      if (compareDate) {
        this.endDate = '';
        this.focusEndDate = false;
        this.errorMsg = 'End Date should be greater than Start Date';
        return;
      }
      this.goToStep(this.currentStep + 1);
      return;
    }
    if (this.currentStep === 2) {
      for (let i = 0; i < this.tmpObjectives.length; i++) {
        if (this.editFocus['editFocus' + i] && this.expandObject['expandObject' + i]) {
          this.newMsg = 'Focuses are in edit mode.Do you want to save?';
          this.notificationDialog = true;
          return;
        }
      }
      this.goToStep(this.currentStep + 1);
    } else {
      if (this.addNewFocus && this.categoryId) {
        this.newMsg = 'Do you want to save the Focus?';
        this.notificationDialog = true;
        return;
      }
      this.focusFocus = false;
      this.notificationMsgs('At least one Focus to be added');
    }
  }

  // to delete a particular focus in edit page
  deleteCategory(category, promoId) {
    let endPoint = '/pforecast/promo/line/',
      req = {
        category_id: category,
        promo_id: promoId
      };

    this.pageDim = true;
    this._httpService.httpRequest('DELETE', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this.deleteId = null;
        this.deleteIndex = null;
        this.showDialog = false;
        this._appService.notify({ status: 1, msg: 'Server Error: deleteCategory()' });
      } else {
        this.forecast.errorMsg = data.msg;
        this.forecast.successStatus = data.status === 0;
        this.forecast.errorStatus = data.status !== 0;
        this._appService.notify({ status: data.status, msg: data.msg });
      }

      const index = this.loadItems.map(x => x.category_id).indexOf(category);
      if (index !== -1) {
        this.loadItems.splice(index, 1);
      }

      for (let i = this.focusLines.length - 1; i >= 0; i--) {
        if (this.focusLines[i].category_id === category) {
          this.focusLines.splice(i, 1);
        }
      }
    });
  }

  // delete Modal a single focus
  deleteLine(event?, d?, index?) {
    if (this.tmpObjectives.length > 0) {
      event.stopPropagation();
      this.showDialog = true;
      this.deleteId = index;
      this.deleteRow = d;
    } else {
      if (this.editPage) {
        this.pdelete = true;
        this.promoDialog = true;
        this.dialogMsg = 'Promotion will get deleted. Do you want to continue?';
      } else {
        this.notificationDialog = true;
        this.focusFlag = true;
        this.newMsg = 'Sorry! Need to have a single Focus for a Promotion.';
      }
    }

  }

  deletePromotion() {
    let endPoint = '/pforecast/promo/',
      req = {
        promo_id: this.promoId
      };

    this.promoDeleteDialog = false;
    this.pageDim = true;
    this._httpService.httpRequest('DELETE', endPoint, req, (data) => {
      this.promoDialog = false;
      this.deleteId = null;
      this.deleteIndex = null;
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: deletePromotion()' });
      } else {
        this.forecast.errorMsg = data.msg;
        this.forecast.successStatus = data.status === 0;
        this.forecast.errorStatus = data.status !== 0;
        this._appService.notify({ status: data.status, msg: data.msg });
        this.closePage();
      }
    });
  }

  // To Close and redirect to summary page on edit
  editClosePage() {
    // to show pop when focuses are not there
    if (this.tmpObjectives.length === 0) {
      this.editClose = true;
      this.deleteLine();
      return;
    }
    this.closePage();
  }

  // edit a single focus
  editLine(d, index) {
    let focus = this.tmpObjectives[index];
    this.currentStep = 2;
    this.tmpIndex = index;
    this.categoryId = focus.category_id;
    let loadIndex = this.loadItems.map(x => x.category_id).indexOf(focus.category_id);
    if (loadIndex === -1) {
      this.loadSegmentItems(focus, index);
    } else {
      this.itemsLoop(this.loadItems[loadIndex].items, index);
    }

    this.editFocus['editFocus' + index] = true;
    this.expandObject['expandObject' + index] = true;
    this.editOpen = true;
  }

  // focus expand or compress
  expand(index) {
    this.expandObject['expandObject' + index] = !this.expandObject['expandObject' + index];
    this.editFocus['editFocus' + index] = false;
  }

  // When no focus in add , button for new focus in modal
  focusStep() {
    this.focusFlag = false;
    this.notificationDialog = false;
    this.currentStep = 2;
    this.goToStep(2);
  }

  formatSalesGroupData(data) {
    let groups = this._cacheService.getGroupList(), tmpGroups = [];
    for (let i = 0; i < data.length; i++) {
      if (groups.indexOf(data[i].group_name) !== -1) {
        tmpGroups.push({
          group_name: data[i].group_name
        });
      }
    }

    this.salesGroups = tmpGroups;

    if (tmpGroups[0] && this.addPage) {
      this.selectedGrp = this.selectedGroup;
    } else {
      this.selectedGroup = tmpGroups[0].group_name;
      this.selectedGrp = tmpGroups[0].group_name;
    }
  }

  goToStep(index) {
    this.toggle = false;
    let fromDate, toDate;
    // When Promotion Details
    if (index === 1) {
      this.focusFocus = true;
      this.categoryId = null;
      this.segmentItems = [];
      this.currentStep = index;
      if (this.editOpen) {
        for (let k = 0; k < this.tmpObjectives.length; k++) {
          for (let i = 0; i < this.tmpObjectives[k].items.length; i++) {
            let item = this.tmpObjectives[k].items[i];
            if (item.deleted_line && (item.estimated_qty === undefined || item.estimated_qty === null)) {
              item.quantity = '';
            } else {
              item.quantity = item.estimated_qty;
            }
          }
        }
      }

      this.editOpen = false;
    }
    // When Add focus
    if (index === 2) {
      if (!this.startDate || !this.endDate || !this.selectedGrp || !this.promoName) {
        this.promoErrors();
        this.errorMsg = 'End Date is required';
        this.notificationMsgs('Promotion Details are mandatory');
        return;
      }

      fromDate = this._formatService.dateInMillis(this._formatService.parseDate(this.startDate));
      toDate = this._formatService.dateInMillis(this._formatService.parseDate(this.endDate));
      if (fromDate > toDate) {
        this.endDate = '';
        this.focusEndDate = false;
        this.errorMsg = 'End Date should be greater than Start Date';
        return;
      }

      if (this.status !== 'APPROVED' && !this.roles.UISalesForecastApprove) {
        this.addNewFocus = this.tmpObjectives.length === 0;
      }
      this.currentStep = index;
      for (let i = 0; i < this.tmpObjectives.length; i++) {
        this.expandObject['expandObject' + i] = true;
        this.editFocus['editFocus' + i] = false;
      }
    }

    // When Preview
    if (index === 3) {
      for (let i = 0; i < this.tmpObjectives.length; i++) {
        if (this.editFocus['editFocus' + i] && this.expandObject['expandObject' + i]) {
          this.newMsg = 'Focuses are in edit mode.Do you want to save?';
          this.notificationDialog = true;
          return;
        }
      }

      if (!this.startDate || !this.endDate || !this.selectedGrp || !this.promoName) {
        this.promoErrors();
        this.errorMsg = 'End Date is required';
        this.notificationMsgs('Promotion Details are mandatory');
        return;
      }

      fromDate = this._formatService.dateInMillis(this._formatService.parseDate(this.startDate));
      toDate = this._formatService.dateInMillis(this._formatService.parseDate(this.endDate));
      if (fromDate > toDate) {
        this.endDate = '';
        this.focusEndDate = false;
        this.errorMsg = 'End Date should be greater than Start Date';
        return;
      }

      for (let i = 0; i < this.tmpObjectives.length; i++) {
        this.expandObject['expandObject' + i] = true;
      }
      this.notificationDialog = false;
      this.focusFocus = true;
      this.editOpen = false;
      this.categoryId = null;
      this.segmentItems = [];
      this.currentStep = index;
    }
  }

  groupChange(grp) {
    this.selectedGrp = grp;
    this.selectedGroup = grp;
  }

  itemsLoop(data, index) {
    this.segmentItems = [];
    let tmpItems = [], items = this.tmpObjectives[index].items, catItem;

    for (let i = 0; i < data.length; i++) {
      let itemIndex = items.map(x => x.inventory_item_id).indexOf(data[i].inventory_item_id);
      if (itemIndex !== -1) {
        catItem = {
          avg_qty: items[itemIndex].avg_qty,
          category_id: data[i].category_id,
          description: data[i].description,
          estimated_qty: items[itemIndex].estimated_qty,
          focus_header_id: items[itemIndex].focus_header_id,
          four_months_avg: data[i].four_months_avg,
          inventory_item_id: data[i].inventory_item_id,
          lines_id: items[itemIndex].lines_id,
          one_month_avg: data[i].one_month_avg,
          onhand_qty: data[itemIndex].onhand_qty,
          segment1: data[i].segment1,
          three_months_avg: data[i].three_months_avg
        };

        if (parseInt(items[itemIndex].quantity) > 0) {
          catItem.quantity = items[itemIndex].quantity;
        }

        tmpItems.push(catItem);
      } else {
        catItem = data[i];
        catItem.avg_qty = null;
        catItem.focus_header_id = null;
        catItem.estimated_qty = null;
        tmpItems.push(catItem);
      }
    }
    this.tmpObjectives[index].items = this._orderBy.transform(tmpItems, 'segment1');
  }

  loadCategories(): void {
    const endPoint = '/pforecast/categories/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this.pageDim = false;
        this._appService.notify({ status: 1, msg: 'Server Error: loadCategories()' });
      } else if (data.status === 1) {
        this.pageDim = false;
        this._appService.notify(new APIError(data.msg));
      } else {
        this.categories = data;
        this.categoriesMain = data;
        this.categoryMain = data;
        if (this.editPage) {
          this.loadData(this.promoId);
        }
      }
    });
  }

  loadData(promoId): void {
    this.pageDim = true;
    const endPoint = `/pforecast/promo/all/${promoId}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadData()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.prepareData(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadDateFormats(): void {
    const endPoint = '/preferences/dateformat/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: loadDateFormats()' });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.dateFormats = data;
        for (let i = 0; i < this.dateFormats.length; i++) {
          if (this.dateFormat === this.dateFormats[i].lookup_code) {
            this.dateFormatExample = this.dateFormats[i].meaning;
            break;
          }
        }
      }
    });
  }

  // Load the salesGroups related to logged in user based on the selected organization
  loadSalesGroups(): void {
    const endPoint = '/metrics/cruscott/channels/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadSalesGroups()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.formatSalesGroupData(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadSegmentItems(category?, tmpIndex?) {
    if (!this.categoryId) {
      this.focusFocus = true;
      this.notificationDialog = false;
      return;
    }

    const endPoint = `/pforecast/items/${this.categoryId}/`;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadSegmentItems()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          if (category) {
            let items = category.items, tmpItems = [], catItem;
            for (let i = 0; i < data.length; i++) {
              let itemIndex = items.map(x => x.inventory_item_id).indexOf(data[i].inventory_item_id);
              if (itemIndex !== -1) {
                catItem = {
                  avg_qty: items[itemIndex].avg_qty,
                  category_id: data[i].category_id,
                  description: data[i].description,
                  estimated_qty: items[itemIndex].estimated_qty,
                  focus_header_id: items[itemIndex].focus_header_id,
                  four_months_avg: data[i].four_months_avg,
                  inventory_item_id: data[i].inventory_item_id,
                  lines_id: items[itemIndex].lines_id,
                  one_month_avg: data[i].one_month_avg,
                  onhand_qty: items[itemIndex].onhand_qty,
                  segment1: data[i].segment1,
                  three_months_avg: data[i].three_months_avg
                };

                if (parseInt(items[itemIndex].quantity) > 0) {
                  catItem.quantity = items[itemIndex].quantity;
                }

                tmpItems.push(catItem);
              } else {
                catItem = data[i];
                tmpItems.push(catItem);
              }
            }

            this.segmentItems = this._orderBy.transform(tmpItems, 'segment1');
            this.tmpObjectives[tmpIndex].items = this._orderBy.transform(tmpItems, 'segment1');
          } else {
            this.segmentItems = this._orderBy.transform(data, 'segment1');
          }

          this.loadItems.push({
            category_id: this.categoryId,
            items: [...this.segmentItems]
          });
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  notificationMsgs(message) {
    this.forecast.errorMsg = message;
    this.forecast.calloutStatus = true;
    this.forecast.successStatus = false;
    this._appService.notify({ status: 1, msg: message });
  }

  // prepare promotion in preview
  prepareData(data) {
    this.currentStep = 3;
    let tmpData = data[0];
    this.promoId = tmpData.promo_id;
    this.status = tmpData.status;
    this.promoId = tmpData.promo_id;
    this.startDate = this._formatService.formatDate(tmpData.start_date);
    this.endDate = this._formatService.formatDate(tmpData.end_date);
    this.tmpObjectives = tmpData.focus_header;
    this.promoName = tmpData.promo_name;
    this.selectedGrp = tmpData.group_name;
    if (this.status === 'APPROVED' || this.roles.UISalesForecastApprove) {
      this.editPromoMode = true;
    }
    this.focusLines = [];
    for (let i = 0; i < this.tmpObjectives.length; i++) {
      this.expandObject['expandObject' + i] = true;
      let index = this.categories.map(x => x.category_id).indexOf(this.tmpObjectives[i].category_id);
      if (index !== -1) {
        this.categories.splice(index, 1);
      }

      for (let j = 0; j < this.tmpObjectives[i].items.length; j++) {
        this.focusLines.push(this.tmpObjectives[i].items[j]);
      }
    }
  }

  // delete a focus
  promoDelete() {
    this.addNewFocus = false;
    this.categoryId = null;
    this.segmentItems = [];
    let focus = this.tmpObjectives[this.deleteId];
    let index = this.categoryMain.map(x => x.category_id).indexOf(focus.category_id);
    if (index !== -1) {
      let category = {...this.categoryMain[index]};
      let categoryIndex = this.categories.map(x => x.category_id).indexOf(focus.category_id);
      if (categoryIndex === -1) {
        this.categories.push(category);
      }
    }

    if (this.editPage) {
      index = this.focusLines.map(x => x.category_id).indexOf(focus.category_id);
      if (index !== -1) {
        this.deleteCategory(focus.category_id, this.promoId);
      }
    }

    this.editFocus['editFocus' + this.deleteId] = false;
    this.tmpObjectives.splice(this.deleteId, 1);
    this.showDialog = false;
    this.addNewFocus = false;
  }

  promoErrors() {
    this.focusStartDate = false;
    this.focusEndDate = false;
    this.focusSales = false;
    this.focusPromo = false;
  }

  // to save a single Focus
  saveCurrentStep(parentIndex?, loadExists?) {
    try {
      this.selectSave = true;
      let segItems, index;
      if (loadExists) {
        segItems = this.tmpObjectives[parentIndex].items;
        this.categoryId = this.tmpObjectives[parentIndex].category_id;
      } else {
        segItems = this.segmentItems;
      }

      index = this.categoryMain.map(x => parseInt(x.category_id)).indexOf(parseInt(this.categoryId));

      if (index !== -1) {
        let category = {...this.categoryMain[index]}, quantity = 0;

        for (let i = 0; i < segItems.length; i++) {
          let isNum = /^\d+$/.test(segItems[i].quantity);
          if (isNum) {
            let qty = parseInt(segItems[i].quantity);
            if (qty > 0) {
              quantity += qty;
              segItems[i].deleted_line = false;
              if (segItems[i].four_months_avg === undefined || segItems[i].four_months_avg === null) {
                segItems[i].avg_qty = null;
              } else {
                segItems[i].avg_qty = segItems[i].four_months_avg;
              }
              segItems[i].estimated_qty = parseInt(segItems[i].quantity);
              segItems[i].actual_qty = null;
            }
          }
        }

        if (quantity === 0) {
          this.pageDim = false;
          this.selectSave = false;
          this.focusFocus = true;
          if (this.notificationDialog) {
            this.notificationDialog = false;
          }
          this.notificationMsgs('Add Quantity for atleast one Item');
          return;
        }
        category.quantity = quantity;
        category.items = segItems;

        let tmpIndex = this.tmpObjectives.map(x => x.category_id).indexOf(this.categoryId);
        if (tmpIndex !== -1) {
          this.tmpObjectives[tmpIndex] = category;
          this.editFocus['editFocus' + tmpIndex] = false;
        } else {
          this.tmpObjectives.push(category);
          let length = this.tmpObjectives.length - 1;
          this.editFocus['editFocus' + length] = false;
          this.expandObject['expandObject' + length] = true;

          let spliceIndex = this.categories.map(x => x.category_id).indexOf(this.categoryId);
          if (spliceIndex !== -1) {
            this.categories.splice(spliceIndex, 1);
          }

        }

        this.categoryId = null;
        this.segmentItems = [];
        this.focusFocus = true;
        this.addNewFocus = false;
        this.focusFocus = true;
        this.selectSave = false;
        this.editOpen = false;

        for (let i = 0; i < this.tmpObjectives.length; i++) {
          if (this.editFocus['editFocus' + i] && this.expandObject['expandObject' + i]) {
            this.editOpen = true;
            break;
          }
        }

        if (this.notificationDialog) {
          this.notificationDialog = false;
          this.goToStep(3);
        }
      } else {
        this.pageDim = false;
        this.focusFocus = false;
        this.forecast.successStatus = false;
      }
    } catch (e) {
      this.pageDim = false;
      this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
    }
  }

  // to save multiple focuses
  saveMultiFocus() {
    try {
      let segItems;
      for (let k = 0; k < this.tmpObjectives.length; k++) {
        if (this.editFocus['editFocus' + k] && this.expandObject['expandObject' + k]) {
          segItems = this.tmpObjectives[k].items;
          this.categoryId = this.tmpObjectives[k].category_id;
          let index = this.categoryMain.map(x => x.category_id).indexOf(this.categoryId);
          if (index !== -1) {
            let category = {...this.categoryMain[index]}, quantity = 0;
            for (let i = 0; i < segItems.length; i++) {
              let isNum = /^\d+$/.test(segItems[i].quantity);
              if (isNum) {
                let qty = parseInt(segItems[i].quantity);
                if (qty > 0) {
                  quantity += qty;
                  segItems[i].deleted_line = false;
                  if (segItems[i].four_months_avg === undefined || segItems[i].four_months_avg === null) {
                    segItems[i].avg_qty = null;
                  } else {
                    segItems[i].avg_qty = segItems[i].four_months_avg;
                  }
                  segItems[i].estimated_qty = parseInt(segItems[i].quantity);
                  segItems[i].actual_qty = null;
                }
              }
            }

            if (quantity === 0) {
              this.pageDim = false;
              this.selectSave = false;
              this.focusFocus = true;
              if (this.notificationDialog) {
                this.notificationDialog = false;
              }
              this.notificationMsgs('Add Quantity for atleast one Item');
              return;
            }
            category.quantity = quantity;
            category.items = segItems;
            let tmpIndex = this.tmpObjectives.map(x => x.category_id).indexOf(this.categoryId);
            if (tmpIndex !== -1) {
              this.tmpObjectives[tmpIndex] = category;
              this.editFocus['editFocus' + tmpIndex] = false;
            } else {
              this.tmpObjectives.push(category);
              let length = this.tmpObjectives.length - 1;
              this.editFocus['editFocus' + length] = false;
              this.expandObject['expandObject' + length] = true;
              let spliceIndex = this.categories.map(x => x.category_id).indexOf(this.categoryId);
              if (spliceIndex !== -1) {
                this.categories.splice(spliceIndex, 1);
              }

            }

            this.categoryId = null;
            this.segmentItems = [];
          }
        }
      }

      this.focusFocus = true;
      this.editOpen = false;
      this.addNewFocus = false;
      this.focusFocus = true;
      this.selectSave = false;
      if (this.notificationDialog) {
        this.notificationDialog = false;
        this.goToStep(3);
      }
    } catch (e) {
      this.pageDim = false;
      this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
    }
  }

  // to insert or update a promotion
  saveSalesForecast() {
    if (this.tmpObjectives.length === 0) {
      this.editClose = false;
      this.deleteLine();
      return;
    }

    let category = [], clearQuantity = [], req, reqType = this.promoId ? 'PUT' : 'POST',
      endPoint = '/pforecast/promotion/';

    for (let i = 0; i < this.tmpObjectives.length; i++) {
      let focus = this.tmpObjectives[i];
      for (let j = 0; j < focus.items.length; j++) {
        if (focus.items[j].quantity === '' && focus.items[j].lines_id) {
          focus.items[j].deleted_line = true;
          clearQuantity.push(focus.items[j].lines_id);
        }
        if (parseInt(focus.items[j].quantity) > 0) {
          category.push(focus.items[j]);
        }
      }
    }

    req = {
      category,
      clear_lines: clearQuantity,
      created_by: this.user.user_id,
      end_date: this._formatService.parseDate(this.endDate),
      last_updated_by: this.user.user_id,
      promo_name: this.promoName,
      sales_channel: this.selectedGrp,
      start_date: this._formatService.parseDate(this.startDate),
      status: this.status === 'REJECTED' ? 'PENDING' : this.status
    };

    if (this.promoId) {
      req.promo_id = this.promoId;
    }

    this.pageDim = true;
    this._httpService.httpRequest(reqType, endPoint, req, (data) => {
      try {
        if (data === null || data === undefined) {
          this.pageDim = false;
          this._appService.notify({ status: 1, msg: 'Server Error: saveSalesForecast()' });
        } else {
          this.forecast.errorMsg = data.message;
          this.forecast.successStatus = data.status === 0;
          this.forecast.errorStatus = data.status !== 0;
          this._appService.notify({ status: data.status, msg: data.message });
          if (!(this.roles.UISalesForecastApprove || this.roles.isAdmin) || !this.roles.editPage) {
            this.closePage();
          } else if (this.status !== 'APPROVED') {
            this.loadData(req.promo_id);
          }
          this.selectSave = false;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  setUpDOMHandlers() {
    jQuery('.scroll-top').click(() => {
      this._appService.scrollTop();
    });
  }

  // Request for status change
  statusApproval(status) {
    if (status === 'APPROVED') {
      for (let i = 0; i < this.tmpObjectives.length; i++) {
        let focus = this.tmpObjectives[i];
        for (let j = 0; j < focus.items.length; j++) {
          let index = this.focusLines.map(x => x.inventory_item_id).indexOf(focus.items[j].inventory_item_id);
          if (index === -1 || (parseInt(this.focusLines[index].quantity) !== parseInt(focus.items[j].quantity))) {
            this.status = status;
            this.saveSalesForecast();
            this.closePage();
            return;
          }
        }
      }
    }

    let endPoint = '/pforecast/focus/status/',
      req = {
        status,
        promo_id: this.promoId
      };

    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      this.promoDialog = false;
      this.status = null;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: statusApproval()' });
      } else {
        this.forecast.errorMsg = data.msg;
        this.forecast.successStatus = data.status === 0;
        this.forecast.errorStatus = data.status !== 0;
        this._appService.notify({ status: data.status, msg: data.msg });
        this.closePage();
      }
    });
  }

  // status confirmation Modal
  statusModal(flag) {
    if (this.tmpObjectives.length === 0) {
      this.newMsg = 'Sorry! There are no focus for you to approve/reject.';
      this.notificationDialog = true;
      return;
    }
    this.pdelete = false;
    this.editClose = false;
    if (flag === 'status_approve') {
      this.dialogMsg = 'Do you want to Approve the Promotion?';
      this.newStatus = 'APPROVED';
    } else if (flag === 'status_reject') {
      this.dialogMsg = 'Do you want to Reject the Promotion?';
      this.newStatus = 'REJECTED';
    }
    this.promoDialog = true;
  }

  // to check the entered quantity is number or not
  validateQuantity(quantity, index, parentIndex, loadExists) {
    quantity = parseFloat(quantity);
    let data;
    if (loadExists) {
      data = this.tmpObjectives[parentIndex].items[index];
    } else {
      data = this.segmentItems[index];
    }

    if (parseInt(quantity) > 0 && parseInt(quantity)) {
      data.quantity = parseInt(quantity);
      data.deleted_line = true;
    } else {
      data.quantity = '';
      data.deleted_line = false;
    }
    this.segmentItems[index].quantity = data.quantity;
  }
}
