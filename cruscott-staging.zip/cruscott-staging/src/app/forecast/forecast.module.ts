import { NgModule } from '@angular/core';
import { ShareModule } from '../share/share.module';

import { ForecastRoutingModule } from './forecast-routing.module';

import { PurchasingDashboardComponent } from './dashboard/purchasing/purchasing.component';
import { AddManageForecastComponent } from './addmanage/addmanage.component';
import { ForecastDashboardComponent } from './dashboard/dashboard.component';
import { ItemDetailsComponent } from './itemdetails/itemdetails.component';
import { ManageForecastComponent } from './manage/manage.component';
import { ManagePOComponent } from './managepo/managepo.component';
import { OrderSummaryComponent } from './order/summary/summary.component';
import { SupplierOrdersComponent } from './order/supplier/supplier.component';
import { ForecastSummaryComponent } from './summary/summary.component';
import { ManagePoFormatsComponent } from './manage-po-formats/manage-po-formats.component';
import { SafetyStockComponent } from './safety-stock/safety-stock.component';

@NgModule({
  declarations: [
    PurchasingDashboardComponent,
    AddManageForecastComponent,
    ForecastDashboardComponent,
    ItemDetailsComponent,
    ManageForecastComponent,
    ManagePOComponent,
    OrderSummaryComponent,
    SupplierOrdersComponent,
    ForecastSummaryComponent,
    ManagePoFormatsComponent,
    SafetyStockComponent
  ],
  imports: [
    ShareModule,
    ForecastRoutingModule
  ]
})
export class ForecastModule { }
