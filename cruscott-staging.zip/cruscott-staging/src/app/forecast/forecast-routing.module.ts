import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PurchasingDashboardComponent } from './dashboard/purchasing/purchasing.component';
import { AddManageForecastComponent } from './addmanage/addmanage.component';
import { ForecastDashboardComponent } from './dashboard/dashboard.component';
import { ItemDetailsComponent } from './itemdetails/itemdetails.component';
import { ManageForecastComponent } from './manage/manage.component';
import { ManagePOComponent } from './managepo/managepo.component';
import { OrderSummaryComponent } from './order/summary/summary.component';
import { SupplierOrdersComponent } from './order/supplier/supplier.component';
import { ForecastSummaryComponent } from './summary/summary.component';
import { ManagePoFormatsComponent } from './manage-po-formats/manage-po-formats.component';
import { SafetyStockComponent } from './safety-stock/safety-stock.component';

const routes: Routes = [
  { path: 'dashboard', component: PurchasingDashboardComponent },
  { path: 'sales/forecast/manage', component: AddManageForecastComponent },
  { path: 'forecast/dashboard', component: ForecastDashboardComponent },
  { path: 'forecast/items', component: ItemDetailsComponent },
  { path: 'forecast/manage', component: ManageForecastComponent },
  { path: 'forecast/po', component: ManagePOComponent },
  { path: 'forecast/orders', component: OrderSummaryComponent },
  { path: 'forecast/orders/supplier', component: SupplierOrdersComponent },
  { path: 'forecast', component: ForecastSummaryComponent },
  { path: 'forecast/po/formats', component: ManagePoFormatsComponent },
  { path: 'forecast/safetystocks', component: SafetyStockComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForecastRoutingModule { }
