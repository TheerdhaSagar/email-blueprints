import { Component, OnInit, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';

@Component({
  selector: 'app-forecast-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class ForecastDashboardComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _router: Router = this.injector.get(Router);

  roles: Record<string, boolean>;

  constructor(private injector: Injector) {
    this.roles = this._dataService.roles;
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']).then();
      } else if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });
  }

  goToState(state, view?): void {
    this._appService.forecastWeeks = !!(view && view === '5weeks');
    this._router.navigate([state]).then();
  }
}
