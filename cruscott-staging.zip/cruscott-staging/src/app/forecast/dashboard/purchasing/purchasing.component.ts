import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { CacheService } from '../../../globals/cache.service';
import { DataService } from '../../../globals/data.service';
import { ReportService } from '../../../globals/report.service';

@Component({
  selector: 'app-forecast-dashboard-purchasing',
  templateUrl: './purchasing.component.html',
  styleUrls: ['./purchasing.component.scss']
})
export class PurchasingDashboardComponent implements OnInit {
  private _cacheService: CacheService;
  private _location: Location;
  private _reportService: ReportService;
  private _router: Router;
  private _window: any;

  modules: any[];
  roles: any;

  constructor(cacheService: CacheService, dataService: DataService, location: Location, reportService: ReportService,
              router: Router) {
    this._cacheService = cacheService;
    this._location = location;
    this._reportService = reportService;
    this._router = router;
    this._window = window;

    this.modules = [];
    this.roles = dataService.roles;
  }

  ngOnInit(): void {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIPurchaseForecast) {
          this.modules.push({ name: 'Purchase Forecast', title: '', state: 'purchasing/forecast/dashboard' });
        }
        this.modules.push({ name: 'Sales Forecast', title: '', state: 'purchasing/forecast/manage' });
        if (this.roles.isAdmin || this.roles.UIPricelist) {
          this.modules.push({
            name: 'Price Lists',
            title: 'Upload, update & download price lists',
            state: 'pricelists/dashboard'
          });
        }
        if (this.roles.UIUtilities) {
          this.modules.push({ name: 'Products', title: '', state: 'utilities/products' });
        }

        if (this.roles.isAdmin || this.roles.UIPOFormats) {
          this.modules.push({
            name: 'PO Number Formats',
            title: 'View PO number formats of a Supplier',
            state: 'purchasing/forecast/po/formats'
          });
        }

        this.modules = PurchasingDashboardComponent.prepareCards(this.modules);
      }
    });
  }

  goToState(name): void {
    this._reportService.selectedReportView = '';
    this._router.navigate([name]);
  }

  static prepareCards(modules) {
    let i, row = [], cardRows = [];
    for (i = 0; i < modules.length; i++) {
      if (i > 0 && i % 4 === 0) {
        cardRows.push(row);
        row = [];
      }
      row.push(modules[i]);
    }
    if (row && row.length > 0) {
      cardRows.push(row);
    }
    return cardRows;
  }
}
