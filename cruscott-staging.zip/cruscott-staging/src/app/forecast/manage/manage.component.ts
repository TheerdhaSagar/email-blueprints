import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-forecast-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.scss'],
  providers: [OrderByPipe]
})
export class ManageForecastComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  data: any[];
  dateFormat: any;
  dateFormatExample: any;
  dateFormats: any;
  deleteId: any;
  deleteIndex: any;
  desc: any;
  focusFromDate: any;
  forecast: { errorStatus: boolean; calloutStatus: boolean; errorMsg: string; successStatus: boolean };
  forecastSearch: any;
  fromDate: any;
  fromDateMsg: any;
  pageDim: any;
  predicate: any;
  roles: any;
  salesGroups: any;
  selectedGroup: any;
  selectedGrp: any;
  showDialog: boolean;
  showSales: boolean;
  showSpinner: boolean;
  status: string;
  statusList: string[];
  tmpObjectives: any[];
  toDate: any;
  toggleFilter: (e?) => void;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, orderBy: OrderByPipe,
              formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.data = [];
    this.dateFormat = null;
    this.dateFormatExample = null;
    this.dateFormats = null;
    this.deleteId = null;
    this.deleteIndex = null;
    this.desc = null;
    this.focusFromDate = null;
    this.forecast = {
      calloutStatus: false,
      errorMsg: '',
      errorStatus: false,
      successStatus: false
    };
    this.forecastSearch = null;
    this.fromDate = null;
    this.fromDateMsg = null;
    this.pageDim = null;
    this.predicate = null;
    this.roles = dataService.roles;
    this.salesGroups = null;
    this.selectedGroup = null;
    this.selectedGrp = null;
    this.showDialog = false;
    this.showSales = false;
    this.status = 'ALL';
    this.statusList = ['ALL', 'PENDING', 'APPROVED', 'REJECTED'];
    this.tmpObjectives = [];
    this.toDate = null;
    this.toggleFilter = appService.toggleFilter();
    this.user = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.dateFormat = this.user.date_format || 'dd-MMM-yyyy';

        new FooPicker({
          id: 'start-date',
          dateFormat: this.dateFormat
        });

        new FooPicker({
          id: 'end-date',
          dateFormat: this.dateFormat
        });

        this.pageDim = true;
        this.loadDateFormats();
        this.loadSalesGroups();

        if (this._appService.selectedGrp) {
          this.selectedGrp = this._appService.selectedGrp;
          this.selectedGroup = this._appService.selectedGrp;
          this._appService.selectedGrp = null;
        }

        this.setUpDOMHandlers();
      }
    });
  }

  // to popup the delete modal
  deleteModal(event, id, dataIndex) {
    event.stopPropagation();
    this.showDialog = true;
    this.deleteId = id;
    this.deleteIndex = dataIndex;
  }

  // to delete the promotion
  deleteSegment() {
    this.showDialog = false;
    let endPoint = '/pforecast/promo/', focusData = this.data[this.deleteIndex], req;
    req = {
      promo_id: focusData.promoId
    };
    this.pageDim = true;
    this._httpService.httpRequest('DELETE', endPoint, req, (data) => {
      this.pageDim = false;
      this.deleteId = null;
      this.deleteIndex = null;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: deleteSegment()' });
      } else {
        this.forecast.errorMsg = data.msg;
        this.forecast.successStatus = data.status === 0;
        this.forecast.errorStatus = data.status !== 0;
        this._appService.notify({ status: data.status, msg: data.msg });
        this.loadData();
      }
    });
  }

  editPromo(id, group_name) {
    this._appService.editPage = true;
    this._appService.promoId = id;
    this._appService.selectedGrp = group_name;
    this._router.navigate(['purchasing/sales/forecast/manage']);
  }

  exportToExcel() {
    this.toggleFilter();
    let data = this._orderBy.transform(this.data, this.predicate, this.desc), tableData: any = {}, tmpData = [],
      tmpObj, focus, count, stat;

    tmpData.push({
      'End Date': { data: '' },
      'Estimated Quantity': { data: '', align: 'right' },
      Focus: { data: '' },
      'Promo Id': { data: '' },
      'Promo Name': { data: '' },
      'Sales Channel': { data: '' },
      'Start Date': { data: '' },
      Status: { data: '' }
    });

    for (let i = 0; i < data.length; i++) {
      focus = data[i].focus;
      count = 1;
      stat = 1;
      for (let j = 0; j < focus.length; j++) {
        if (count === 1) {
          count = 2;
          tmpObj = {
            'End Date': { data: data[i].endDate },
            'Promo Id': { data: data[i].promoId },
            'Promo Name': { data: data[i].promoName },
            'Sales Channel': { data: data[i].channel },
            'Start Date': { data: data[i].startDate }
          };
        } else {
          tmpObj = {
            'End Date': { data: '' },
            'Promo Id': { data: '' },
            'Promo Name': { data: '' },
            'Sales Channel': { data: '' },
            'Start Date': { data: '' }
          };
        }

        tmpObj.Focus = { data: focus[j].segment1 };
        tmpObj['Estimated Quantity'] = { data: focus[j].estimated_qty, align: 'right' };
        if (stat === 1) {
          stat = 2;
          tmpObj.Status = { data: data[i].status };
        } else {
          tmpObj.Status = { data: '' };
        }

        tmpData.push(tmpObj);
      }
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Sales Forecast', tableData, 'sales-table');
  }

  // to redirect to add page
  focusDialog() {
    this._appService.addpage = true;
    this._appService.selectedGrp = this.selectedGroup;
    this._router.navigate(['purchasing/sales/forecast/manage']);
  }

  formatSalesGroupData(data) {
    let groups = this._cacheService.getGroupList(), tmpGroups = [];
    for (let i = 0; i < data.length; i++) {
      if (groups.indexOf(data[i].group_name) !== -1) {
        tmpGroups.push({
          group_name: data[i].group_name
        });
      }
    }
    this.salesGroups = tmpGroups;
    if (tmpGroups[0] && this.selectedGrp === undefined || this.selectedGrp === null) {
      this.selectedGroup = tmpGroups[0].group_name;
      this.selectedGrp = tmpGroups[0].group_name;
    }
  }

  groupChange(grp) {
    this.selectedGrp = grp;
    this.selectedGroup = grp;
  }

  loadData(): void {
    const endPoint = '/pforecast/promo/all/';
    const req = {
      end_date: this.toDate ? this._formatService.parseDate(this.toDate) : '',
      sales_channel: this.selectedGroup,
      start_date: this.fromDate ? this._formatService.parseDate(this.fromDate) : '',
      status: this.status !== 'ALL' ? this.status : ''
    };

    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadData()' });
        } else if (data.status === 1) {
          this.forecast.errorMsg = data.msg;
          this.forecast.errorStatus = true;
          this.forecast.successStatus = false;
          this._appService.notify({ status: 1, msg: data.msg });
        } else {
          this.prepareData(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  // load date formats
  loadDateFormats(): void {
    const endPoint = '/preferences/dateformat/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this.showSpinner = false;
        this._appService.notify({ status: 1, msg: 'Server Error: loadDateFormats()' });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
        this.showSpinner = false;
      } else {
        this.dateFormats = data;
        for (let i = 0; i < this.dateFormats.length; i++) {
          if (this.dateFormat === this.dateFormats[i].lookup_code) {
            this.dateFormatExample = this.dateFormats[i].meaning;
            break;
          }
        }
      }
    });
  }

  // Load the salesGroups related to logged in user based on the selected organization
  loadSalesGroups(): void {
    const endPoint = '/metrics/cruscott/channels/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: loadSalesGroups()' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.formatSalesGroupData(data);
        this.loadData();
      }
    });
  }

  // to filter the data
  onChange() {
    this.toggleFilter();
    this.selectedGrp = this.selectedGroup;
    let startDate = this._formatService.dateInMillis(this._formatService.parseDate(this.fromDate));
    let endDate = this._formatService.dateInMillis(this._formatService.parseDate(this.toDate));
    if (startDate > endDate) {
      this.toDate = '';
      this.toggleFilter();
      this.forecast.errorMsg = 'End Date is less than Start Date';
      this.forecast.calloutStatus = true;
      this.forecast.successStatus = false;
      this._appService.notify({ status: 1, msg: 'End Date is less than Start Date' });
      return;
    }

    this.loadData();
  }

  prepareData(data) {
    this.data = [];
    this.predicate = 'promoId';
    this.desc = true;
    for (let i = 0; i < data.length; i++) {
      if ((this.roles.UISalesForecastApprove && data[i].focus.length > 0) || !this.roles.UISalesForecastApprove) {
        this.data.push({
          channel: data[i].group_name,
          endDate: this._formatService.formatDate(data[i].end_date),
          endDateInMillis: this._formatService.dateInMillis(data[i].end_date),
          focus: data[i].focus,
          promoId: data[i].promo_id,
          promoName: data[i].promo_name,
          startDate: this._formatService.formatDate(data[i].start_date),
          startDateInMillis: this._formatService.dateInMillis(data[i].start_date),
          status: data[i].status
        });
      }
    }
  }

  // to scroll the page up
  setUpDOMHandlers() {
    jQuery('.scroll-top').click(() => {
      this._appService.scrollTop();
    });
  }

  sort(predicate) {
    if (predicate === this.predicate) {
      this.desc = !this.desc;
    } else {
      this.predicate = predicate;
      this.desc = true;
    }
  }
}
