import {
  Component, Injector, OnInit, OnDestroy, ViewChild
} from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Settings } from '../../globals/tabletemplate/models/settings';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { CommonService } from '../../globals/common.service';
import { TabletemplateComponent } from '../../globals/tabletemplate/tabletemplate.component';

declare let FooPicker: any;

@Component({
  selector: 'app-manage-po-formats',
  templateUrl: './manage-po-formats.component.html',
  styleUrls: ['./manage-po-formats.component.scss']
})
export class ManagePoFormatsComponent implements OnInit, OnDestroy {
  @ViewChild(TabletemplateComponent) child: TabletemplateComponent;

  private _appService = this.injector.get(AppService);
  private _cacheService = this.injector.get(CacheService);
  private _commonService = this.injector.get(CommonService);
  private _formatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  allSupplierDetails: any[];
  allSupplierLOV: any[];
  copyVendorDetails: any[];
  copyYear: string;
  copyYears: any[];
  dateFormat: string;
  dateMsg: string;
  desc: boolean;
  filterSupplierDetails: any[];
  focusCopyYear: boolean;
  focusPONumber: boolean;
  focusPrefix: boolean;
  focusStartDate: boolean;
  focusVendor: boolean;
  footerHide: boolean;
  isCopy: boolean;
  isEdit: boolean;
  orgId: number;
  poMsg: string;
  predicate: string;
  prefixMsg: string;
  searchQuery: string;
  selectedYear: string;
  showCopyDialog: boolean;
  showSpinner: boolean;
  showSupplier: boolean;
  subOrgChange: Subscription;
  supplierDetail: any;
  supplierLOV: any;
  tableSettings: Settings;
  toggleFilter: (e?) => void;
  user: any;
  vendorMsg: string;
  years: any[];

  constructor(private injector: Injector) {
    this._window = window;

    this.allSupplierDetails = [];
    this.allSupplierLOV = [];
    this.copyVendorDetails = [];
    this.copyYear = '';
    this.copyYears = [];
    this.dateFormat = null;
    this.dateMsg = null;
    this.desc = false;
    this.filterSupplierDetails = [];
    this.footerHide = false;
    this.isCopy = false;
    this.isEdit = false;
    this.poMsg = '';
    this.predicate = 'vendor_name';
    this.prefixMsg = '';
    this.searchQuery = '';
    this.init();
  }

  ngOnInit(): void {
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.orgId = this._cacheService.getOrgId();
        this.user = data;
        this.dateFormat = this.user.date_format;
        this.setupTableSettings();
        this.loadYears();
        this.loadSupplierLOV();
        this.loadSupplierPODetails();
        this.onOrgChange();
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  applyFilter(): void {
    this.copyVendorDetails = [];
    this.footerHide = false;
    this.filterSupplierDetails = this.allSupplierDetails.filter((supplier) => supplier.year ===
      parseInt(this.selectedYear, 10));
    this.filterSupplierDetails.forEach((supplier) => {
      const supplierObj = supplier;
      supplierObj.isChecked = false;
    });
  }

  checkVendorNames(): boolean {
    const index = this.allSupplierDetails.findIndex((supplier) => supplier.supplier_id ===
      this.supplierDetail.supplier_id && supplier.year === parseInt(this.supplierDetail.year, 10) &&
      supplier.org_id === parseInt(this.supplierDetail.org_id, 10));
    if (index !== -1) {
      this.supplierDetail.supplier_id = null;
      this.focusVendor = false;
      this.vendorMsg = 'Vendor already exists';
      return true;
    }
    return false;
  }

  clearVariables(): void {
    this.closeSupplierDetails();
    this.footerHide = false;
    this.copyVendorDetails = [];
    this.prefixMsg = '';
    this.poMsg = '';
    this.searchQuery = '';
  }

  closeCopySupplierDialog(): void {
    this.copyYear = '';
    this.isCopy = false;
    this.showCopyDialog = false;
    this.focusCopyYear = true;
  }

  closeSupplierDetails(): void {
    this.isEdit = false;
    this.prefixMsg = '';
    this.setFocus();
    this.showSupplier = false;
    this.supplierDetail = {
      supplier_id: '',
      prefix: '',
      p_start_date: this._formatService.formatDate(this._appService.today(0)),
      p_end_date: '',
      year: new Date().getFullYear(),
      po_number: 0,
      org_id: this._cacheService.getOrgId()
    };
  }

  copyDisableSelectedVendors(action): void {
    const endPoint = '/forecast/poformat/copy/';
    const req: any = {};
    if (this.focusCopyYear && !this.copyYear && action === 'copy') {
      this.focusCopyYear = false;
      return;
    }
    req.data = this.copyVendorDetails.map((vendor) => ({
      supplier_id: vendor.supplier_id,
      prefix: vendor.prefix,
      year: action === 'copy' ? parseInt(this.copyYear, 10) : vendor.year,
      start_date: action === 'copy' ? this._appService.today(0) : this._formatService.parseDate(vendor.p_start_date),
      end_date: action === 'copy' ? '' : this._appService.today(0),
      org_id: vendor.org_id,
      po_number: action === 'copy' ? 0 : vendor.po_number
    }));
    req.action = action;
    this.closeCopySupplierDialog();
    this.showSpinner = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'SERVER ERROR - copySelectedVendors()' });
      } else {
        this._appService.notify({ status: data.status, msg: data.msg });
        this.copyVendorDetails = [];
        this.footerHide = false;
        this.searchQuery = '';
        this.loadSupplierPODetails();
      }
    });
  }

  editPOFormat(event): void {
    this.isEdit = true;
    const supplier = this.allSupplierDetails.find((podetails) => podetails.supplier_id ===
      event.value && podetails.year === parseInt(this.selectedYear, 10));
    this.supplierDetail = { ...supplier };
    this.showSupplier = true;
  }

  exportData(): void {
    this.toggleFilter();
    this.child.exportData('PO_Formats');
  }

  getSelectedDetails(data): void {
    this.footerHide = false;
    const selectedData = data;
    const index = this.copyVendorDetails.findIndex((vendor) => vendor.supplier_id === selectedData.supplier_id);
    if (selectedData.isChecked && index === -1) {
      this.copyVendorDetails.push(selectedData);
    } else {
      this.copyVendorDetails.splice(index, 1);
    }
    this.footerHide = !!this.copyVendorDetails.length;
  }

  init() {
    this.selectedYear = new Date().getFullYear().toString();
    this.showCopyDialog = false;
    this.showSpinner = true;
    this.showSupplier = false;
    this.supplierDetail = {
      supplier_id: null,
      prefix: '',
      p_start_date: this._formatService.formatDate(this._appService.today(0)),
      p_end_date: '',
      year: new Date().getFullYear(),
      po_number: 0,
      org_id: this._cacheService.getOrgId()
    };
    this.supplierLOV = [];
    this.tableSettings = new Settings({ headers: [] });
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.vendorMsg = '';
    this.years = [];
    this.setFocus();
  }


  loadSupplierLOV(): void {
    this._commonService.loadSuppliers((data) => {
      this.supplierLOV = data;
      this.allSupplierLOV = data;
    });
  }

  loadSupplierPODetails(): void {
    const endPoint = '/forecast/poformat/details/';
    const req = { year: '', org: this._cacheService.getOrgId() };
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'SERVER ERROR - loadSupplerPODetails()' });
      } else if (Object.prototype.hasOwnProperty.call(data, 'status') && data.status === 0) {
        this.parseSupplierDetails(data);
      } else {
        this._appService.notify({ status: 1, msg: data.msg });
      }
      this.showSpinner = false;
      this.footerHide = false;
    });
  }


  loadYears(): void {
    const yearDetails = this._commonService.loadYears(2010, 5);
    this.selectedYear = yearDetails.currentYear.toString();
    this.years = yearDetails.years;
  }

  onOrgChange(): void {
    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      if (this.orgId !== this._cacheService.getOrgId()) {
        this.orgId = this._cacheService.getOrgId();
        this.loadSupplierPODetails();
      }
    });
  }

  openCopyDialog(action?): void {
    if (action === 'copy') {
      const nextYear = new Date().getFullYear();
      this.copyYears = this._commonService.loadYears(nextYear, 5).years;
      this.isCopy = true;
    }
    this.showCopyDialog = true;
  }

  openCreateDialog(): void {
    this.showSupplier = true;
    this.setFocus();
    this.supplierDetail = {
      supplier_id: null,
      prefix: '',
      p_start_date: this._formatService.formatDate(this._appService.today(0)),
      p_end_date: '',
      year: new Date().getFullYear(),
      po_number: 0,
      org_id: this._cacheService.getOrgId()
    };
  }

  static formatPONumber(num: number, size: number): string {
    let poNumber = `${num}`;
    while (poNumber.length < size) {
      poNumber = `0${poNumber}`;
    }
    return poNumber;
  }

  parseSupplierDetails(data): void {
    const supplierData = data.suppliers;
    let formattedPONumber;
    for (let i = 0; i < supplierData.length; i++) {
      supplierData[i].p_start_date = this._formatService.formatDate(supplierData[i].start_date);
      supplierData[i].p_end_date = this._formatService.formatDate(supplierData[i].end_date);
      supplierData[i].is_checked = false;
      supplierData[i].isCheckBox = true;
      formattedPONumber = ManagePoFormatsComponent.formatPONumber(supplierData[i].po_number, 3);
      supplierData[i].latest_po_number = `${supplierData[i].prefix}-${supplierData[i].year}-${formattedPONumber}`;
    }

    this.allSupplierDetails = supplierData;
    this.applyFilter();
  }

  removeFocus(): void {
    this.focusVendor = false;
    this.focusPrefix = false;
    this.focusStartDate = false;
  }

  saveSupplierPOFormat(): void {
    const endPoint = '/forecast/poformat/';
    const method = this.isEdit ? 'PUT' : 'POST';
    const req = this.supplierDetail;
    if (this.validateFields() || (!this.isEdit && this.checkVendorNames())) {
      this.removeFocus();
      return;
    }
    req.prefix = req.prefix.toUpperCase();
    req.start_date = this._formatService.parseDate(req.p_start_date);
    req.end_date = req.p_end_date ? this._formatService.parseDate(req.p_end_date) : '';
    this.showSpinner = true;
    this.clearVariables();
    this._httpService.httpRequest(method, endPoint, req, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'SERVER ERROR - saveSupplierPOFormat()' });
      } else {
        this._appService.notify({ status: data.status, msg: data.msg });
        this.loadSupplierPODetails();
      }
    });
  }

  setFocus(): void {
    this.focusCopyYear = true;
    this.focusPONumber = true;
    this.focusPrefix = true;
    this.focusStartDate = true;
    this.focusVendor = true;
  }

  setupDatePicker(): void {
    // Adding a date picker
    setTimeout(() => {
      new FooPicker({
        id: 'start-date',
        dateFormat: this.dateFormat
      });
      new FooPicker({
        id: 'end-date',
        dateFormat: this.dateFormat
      });
    });
  }

  setupTableSettings(): void {
    this.setupDatePicker();
    this.tableSettings = new Settings({
      headers: [
        { title: 'Vendor Name', keyName: 'vendor_name', redirect: 'supplier_id' },
        { title: 'Vendor Prefix', keyName: 'prefix' },
        { title: 'Start Date', keyName: 'start_date', styles: { format: 'date' } },
        { title: 'End Date', keyName: 'end_date', styles: { format: 'date' } },
        { title: 'Year', keyName: 'year' },
        { title: 'Latest PO Number', keyName: 'latest_po_number', styles: { width: '150px' } },
      ],
      sortHeader: true,
      predicate: this.predicate,
      checkboxes: true,
      desc: this.desc
    });
  }

  validateDate(): boolean {
    if (this.supplierDetail.p_start_date && !this._formatService.validateDate(this.supplierDetail.p_start_date)) {
      this.focusStartDate = false;
      this.supplierDetail.p_start_date = '';
      this.dateMsg = 'Invalid date';
      return true;
    }
    if (!this.isEdit) {
      this.supplierDetail.year = this.supplierDetail.p_start_date ? new Date(
        this._formatService.parseDate(this.supplierDetail.p_start_date)
      ).getFullYear() : '';
      this.checkVendorNames();
    }
    return false;
  }

  validateFields(): boolean {
    this.setFocus();
    this.validatePONumber(this.supplierDetail.po_number);
    return ((this.focusVendor && !this.supplierDetail.supplier_id) ||
      (this.validatePrefix(this.supplierDetail.prefix)) ||
      (this.focusStartDate && !this.supplierDetail.p_start_date) || (!this.focusPONumber));
  }

  validatePONumber(poNumber): void {
    if (poNumber === null) {
      this.focusPONumber = false;
      this.supplierDetail.po_number = null;
      this.poMsg = 'Latest PO Number is required';
    } else if ((Number.isNaN(Number(poNumber)) || Number(poNumber) < 0)) {
      this.focusPONumber = false;
      this.supplierDetail.po_number = null;
      this.poMsg = 'Should be a number greater than or equal to 0';
    } else {
      this.poMsg = '';
      this.focusPONumber = true;
    }
  }

  validatePrefix(prefix): boolean {
    if ((this.focusPrefix && !prefix) || (prefix && prefix.length > 4) || !(/^[a-zA-Z0-9]+$/.test(prefix))) {
      this.prefixMsg = (this.focusPrefix && !prefix) ? 'Prefix is required' :
        'Should be alphabets and numbers with maximum 4 characters';
      this.focusPrefix = false;
      return true;
    }
    this.prefixMsg = '';
    this.focusPrefix = true;
    return false;
  }
}
