import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagePoFormatsComponent } from './manage-po-formats.component';

describe('ManagePoFormatsComponent', () => {
  let component: ManagePoFormatsComponent;
  let fixture: ComponentFixture<ManagePoFormatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagePoFormatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePoFormatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
