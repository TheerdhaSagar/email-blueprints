import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';

@Component({
  selector: 'app-forecast-itemdetails',
  templateUrl: './itemdetails.component.html',
  styleUrls: ['./itemdetails.component.scss']
})
export class ItemDetailsComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  data: any;
  forecastSearch: any;
  months: string[];
  pageDim: boolean;
  period: any;
  periods: any;
  roles: any;
  selectedGroup: any;
  salesGroups: any;
  toggleFilter: (e?) => void;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, httpService: HttpService,
              location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.data = null;
    this.months = ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC'];
    this.pageDim = false;
    this.period = null;
    this.periods = null;
    this.roles = dataService.roles;
    this.selectedGroup = null;
    this.salesGroups = null;
    this.toggleFilter = appService.toggleFilter();
    this.user = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;

        if (this.roles.isAdmin || this.roles.hasForecastDetails) {
          this.loadSalesGroups();
          this.loadPeriods();
        } else {
          this._router.navigate(['purchasing/forecast']);
        }
      }
    });
  }

  back() {
    this._router.navigate(['purchasing/forecast/manage']);
  }

  exportToExcel() {
    this.toggleFilter();
    let data = this.data, tableData: any = {}, tmpData = [], selected: any = {};
    selected['Sales Channel'] = { data: this.selectedGroup };
    selected.Period = { data: '' };
    selected.Items = { data: '', align: 'right' };
    selected['Average 4 Months'] = { data: '' };
    selected['Estimated Quantity'] = { data: '', align: 'right' };
    selected['Actual Quantity'] = { data: '', align: 'right' };
    selected['On Hand Quantity'] = { data: '', align: 'right' };
    tmpData.push(selected);
    for (let i = 0; i < data.length; i++) {
      let lines = data[i].lines, count = 1;
      for (let j = 0; j < lines.length; j++) {
        let tmpObj: any = {};
        tmpObj['Sales Channel'] = { data: '' };
        if (count === 1) {
          count = 2;
          tmpObj.Period = { data: data[i].period };
        } else {
          tmpObj.Period = { data: '' };
        }
        tmpObj.Items = { data: lines[j].description };
        tmpObj['Average 4 Months'] = { data: lines[j].avg_qty, align: 'right' };
        tmpObj['Estimated Quantity'] = { data: lines[j].estimated_qty, align: 'right' };
        tmpObj['Actual Quantity'] = { data: lines[j].actual_qty, align: 'right' };
        tmpObj['On Hand Quantity'] = { data: lines[j].onhand_qty, align: 'right' };
        tmpData.push(tmpObj);
      }
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('PurchaseForecastDetails', tableData, 'notes');
  }

  formatSalesGroupData(data) {
    let groups = this._cacheService.getGroupList(), tmpGroups = [];
    for (let i = 0; i < data.length; i++) {
      if (groups.indexOf(data[i].group_name) !== -1) {
        tmpGroups.push({
          group_name: data[i].group_name
        });
      }
    }
    this.salesGroups = tmpGroups;
    if (tmpGroups[0]) {
      this.selectedGroup = tmpGroups[0].group_name;
    }
    this.loadData();
  }

  loadData(): void {
    this.setSalesChannel();
    const endPoint = `/pforecast/focus/items/${this.selectedGroup}/`;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadData()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.prepareData(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadPeriods(): void {
    const endPoint = '/pforecast/periods/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else {
          if (data.length > 0) {
            this.periods = data;
            if (!this.period) {
              let date = new Date();
              let mon = this.months[date.getMonth()];
              let year = date.getFullYear() - 2000;
              let period = mon + '-' + year;
              for (let i = 0; i < data.length; i++) {
                if (data[i].period_name === period) {
                  this.period = data[i];
                  break;
                }
              }
            }
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  // Load the salesGroups related to logged in user based on the selected organization
  loadSalesGroups(): void {
    const endPoint = '/metrics/cruscott/channels/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadSalesGroups()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.formatSalesGroupData(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  onChange() {
    this.toggleFilter();
    this.loadData();
  }

  prepareData(data) {
    this.data = [];
    for (let i = 0; i < data.length; i++) {
      let period = data[i].period, obj: any = {};
      obj.lines = [];
      data[i].avg_qty = data[i].avg_qty || '';
      data[i].estimated_qty = data[i].estimated_qty || '';
      data[i].actual_qty = data[i].actual_qty || '';
      data[i].onhand_qty = data[i].onhand_qty || '';
      let index = this.data.map(x => x.period).indexOf(period);
      if (index !== -1) {
        this.data[index].lines.push(data[i]);
      } else {
        obj.period = period;
        obj.lines.push(data[i]);
        this.data.push(obj);
      }
    }
  }

  setSalesChannel(): void {
    if (this._cacheService.salesChannel) {
      this.selectedGroup = this._cacheService.salesChannel;
      this._cacheService.salesChannel = null;
    }
  }
}
