import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { DataService } from '../../../globals/data.service';
import { HttpService } from '../../../globals/http.service';

@Component({
  selector: 'app-events-hostess-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateHostessComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  autoPassword: boolean;
  description: any;
  editHostee: boolean;
  email_address: any;
  external_id: any;
  focusDescription: any;
  focusEmail: any;
  focusId: any;
  focusPassword: any;
  focusPhone: any;
  focusRetypePassword: any;
  focusUsername: any;
  mailNotification: boolean;
  pageDim: boolean;
  password: any;
  passwordChanged: boolean;
  phone_no: any;
  retype_password: any;
  user_id: any;
  username: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, httpService: HttpService,
              location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.autoPassword = false;
    this.description = null;
    this.editHostee = false;
    this.email_address = null;
    this.external_id = null;
    this.focusDescription = null;
    this.focusEmail = null;
    this.focusPassword = null;
    this.focusRetypePassword = null;
    this.focusUsername = null;
    this.mailNotification = false;
    this.pageDim = false;
    this.password = null;
    this.passwordChanged = false;
    this.phone_no = null;
    this.retype_password = null;
    this.user_id = null;
    this.username = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', {
      page: this._location.path()
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.autoPassword = false;
        this.mailNotification = false;
        this.pageDim = false;
        if (this._dataService.fromState && this._dataService.fromState === '/events/hostess') {
          if (this._appService.hostess_id) {
            this.user_id = this._appService.hostess_id;
            this._appService.hostess_id = '';
            this.pageDim = true;
            this.editHostee = true;
            this.editHostess();
          }
        }
      }
    });
  }

  changePassword() {
    if (this.editHostee) {
      this.passwordChanged = true;
    }
  }

  checkValidName() {
    if (this.editHostee) {
      return;
    }
    this.focusUsername = false;
    if (!this.username) {
      return false;
    } else {
      const endPoint = `/users/validate/${this.username}/`;
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - checkValidName()' });
        } else if (data.status !== 0) {
          this.username = null;
          this._appService.notify({
            status: 1,
            msg: 'Username already exists please choose another name'
          });
        }
      });
    }
  }

  editHostess() {
    const endPoint = '/events/hostess/user/' + this.user_id + '/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - editHostess()' });
        } else if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          this.description = data[0].user_description;
          this.username = data[0].user_name;
          this.email_address = data[0].email_address;
          this.phone_no = data[0].phone;
          this.external_id = data[0].external_identification || '';
          this.password = data[0].password;
        }
      } catch (e) {
        this._appService.notify({ msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  generatePassword() {
    if (this.autoPassword) {
      this.password = null;
      this.retype_password = null;
    }
  }

  goToPrevious() {
    this._router.navigate(['events/hostess']);
  }

  saveHostess() {
    let result = this.validation(), obj: any = {}, endPoint;
    if (result) {
      this.pageDim = true;
      obj.user_name = this.username;
      obj.description = this.description;
      obj.password = this.password;
      obj.email_address = this.email_address;
      obj.phone_no = this.phone_no;
      obj.send_mail = this.mailNotification ? 'Y' : 'N';
      obj.external_identification = this.external_id || '';
      endPoint = '/events/hostess/new/';
      this._httpService.httpRequest('POST', endPoint, obj, (data) => {
        try {
          this.pageDim = false;
          if (data === null || data === undefined) {
            this._appService.notify({ status: 1, msg: 'Server Error - saveHostess()' });
          } else if (data) {
            this._appService.notify({
              status: data.status,
              msg: data.msg
            });
            this._router.navigate(['events/hostess']);
            return false;
          }
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }
  }

  updateHostess() {
    if (!this.description || !this.password || !this.phone_no ||
      !this.external_id || !this.email_address || (this.passwordChanged && !this.retype_password)) {
      return;
    }
    if (this.passwordChanged && this.password !== this.retype_password) {
      this._appService.notify({ msg: 'Password and Retype Password should be same', status: 1 });
      return;
    }
    this.pageDim = true;
    let endPoint = '/events/hostess/update/', dict: any = {};
    dict.user_id = this.user_id;
    dict.user_description = this.description;
    dict.password = this.password;
    dict.phone_no = this.phone_no;
    dict.external_id = this.external_id;
    dict.email_address = this.email_address;
    this._httpService.httpRequest('PUT', endPoint, dict, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - updateHostess()' });
        } else {
          this._appService.notify({ msg: data.msg, status: data.status });
          this._router.navigate(['events/hostess']);
        }
      } catch (e) {
        this._appService.notify({ msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  validateEmail() {
    this.focusEmail = false;
    let result = this._appService.validateEmail(this.email_address);
    if (!result) {
      this.email_address = null;
      this._appService.notify({
        status: 1,
        msg: 'Please enter valid email address'
      });
    }
  }

  // validations
  validation() {
    if (!this.username) {
      this.focusUsername = true;
      return false;
    }

    if (!this.description) {
      this.focusDescription = true;
      return false;
    }

    if (!this.autoPassword) {
      if (!this.password) {
        this.focusPassword = true;
        return false;
      }
      if (!this.retype_password) {
        this.focusRetypePassword = true;
        return false;
      }

      if (this.password !== this.retype_password) {
        this._appService.notify({
          status: 1,
          msg: 'Password and Retype password should be same'
        });
        return false;
      }
    }
    if (!this.email_address) {
      this.focusEmail = true;
      return false;
    }
    return true;
  }
}
