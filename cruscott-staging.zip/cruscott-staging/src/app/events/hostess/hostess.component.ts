import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';

declare var FooPicker: any;

@Component({
  selector: 'app-events-hostess',
  templateUrl: './hostess.component.html',
  styleUrls: ['./hostess.component.scss']
})
export class HostessComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _sce: DomSanitizer;
  private _router: Router;
  private _window: any;

  _index: any;
  actions: ({ name: string, label: string })[];
  agency_verified: any;
  amount: any;
  approveEvent: any;
  attachment_categories: any;
  attachmentDialog: any;
  attachments: any[];
  compenso_variable: any;
  createdBy: any;
  data: any;
  deletedAttachments: any[];
  deleteDialog: boolean;
  editReport: any;
  event_date_millis: any;
  event_name: any;
  events: any[];
  expandObject: any[];
  expandObjective: any[];
  f_totalValue: any;
  focusAmount: boolean;
  focusCategory: boolean;
  focushostessName: boolean;
  focusImage: boolean;
  focusTotal: boolean;
  focusVariable: boolean;
  focusreportDate: boolean;
  focusselectedEvent: boolean;
  format: any;
  giftObjectives: any;
  gifts: any;
  hostess: any;
  hostess_id: any;
  hostessName: any;
  hostess_image: any;
  image_category: any;
  image_msg: any;
  last_update_by: any;
  lookup_value: any;
  note: any;
  number_format: any;
  pageDim: boolean;
  rejectEvent: any;
  reportDate: any;
  reportId: any;
  report_verified: any;
  reported_by: any;
  rimborso_extra: any;
  selectedEvent: any;
  shippingAddress: any;
  showActions: any;
  showApproval: any;
  submit: any;
  tmpObjectives: any;
  totalValue: any;
  todays_date_millis: any;
  total_compenso: any;
  total_msg: any;
  user: any;
  verified_by: any;
  viewUserId: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService,
              httpService: HttpService, location: Location, sce: DomSanitizer, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._sce = sce;
    this._router = router;
    this._window = window;

    this.actions = [
      { name: 'Create Event', label: 'eventcreation' },
      { name: 'Event Summary', label: 'eventsummary' },
      { name: 'Hostess Report', label: 'hostessreport' }
    ];
    this.agency_verified = null;
    this.amount = null;
    this.approveEvent = null;
    this.attachmentDialog = null;
    this.attachments = [];
    this.compenso_variable = null;
    this.createdBy = null;
    this.data = {};
    this.deletedAttachments = [];
    this.editReport = null;
    this.event_date_millis = null;
    this.event_name = null;
    this.events = [];
    this.expandObject = [];
    this.expandObjective = [];
    this.f_totalValue = null;
    this.focusAmount = null;
    this.focusCategory = null;
    this.focusImage = null;
    this.focusTotal = null;
    this.focusVariable = null;
    this.focusselectedEvent = null;
    this.format = null;
    this.giftObjectives = [];
    this.hostess = null;
    this.hostessName = null;
    this.hostess_image = {};
    this.image_category = null;
    this.image_msg = null;
    this.lookup_value = null;
    this.note = null;
    this.pageDim = false;
    this.rejectEvent = null;
    this.reportDate = null;
    this.reportId = null;
    this.report_verified = null;
    this.rimborso_extra = null;
    this.selectedEvent = null;
    this.shippingAddress = null;
    this.showApproval = null;
    this.submit = null;
    this.tmpObjectives = [];
    this.todays_date_millis = null;
    this.total_compenso = null;
    this.total_msg = null;
    this.user = null;
    this.verified_by = null;
    this.viewUserId = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', {
      page: this._location.path()
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.format = this.user.date_format ? this.user.date_format : 'dd-MMM-yyyy';
        if (this.user.number_format) {
          this.number_format = this.user.number_format;
        } else {
          this.number_format = '999,999.99';
        }
        this.submit = false;
        this.approveEvent = false;
        this.rejectEvent = false;
        this.viewUserId = this.user.user_id;

        if (this._appService.report_id) {
          this.reportId = this._appService.report_id;
          this._appService.report_id = null;
          this.editReport = true;
          this.events = [];
        }
        this.loadAttachmentCategories();
        setTimeout(() => {
          if (this.editReport) {
            this.loadReport();
          } else {
            this.pageDim = true;
            this.loadHostess();
            this.loadEvents();
          }
        }, 500);
      }
    });

    if (!this._dataService.roles.isHostess) {
      this.actions.push({ name: 'View Report', label: 'events/reports/hostess' });
    }
    if (this._dataService.roles.isAdmin || this._dataService.roles.isAgent) {
      this.actions.push({ name: 'Ambassador Visits', label: 'events/ambassador/summary' });
    }
    if (!this._dataService.roles.isAgency) {
      this.actions.push({ name: 'View Objectives', label: 'events/objectives/summary' });
      this.actions.push({ name: 'Create Objective', label: 'events/objectives/manage' });
    }
  }

  approve() {
    if (!this.f_totalValue) {
      this.focusTotal = true;
      this.total_msg = 'TOTALE RIMBORSO is required';
      return;
    }
    this.approveEvent = true;
    this.editReport = true;
    this.showApproval = 'Approve';
  }

  backToSummary() {
    this._router.navigate(['events/hostess/report']);
  }

  cancelApproval() {
    this.submit = false;
    this.showApproval = '';
    this.rejectEvent = false;
    this.approveEvent = false;
    this.amount = this.editReport ? this.data.amount ?
      this._formatService.formatNumber(this.data.amount) : '' :
      this.data.compenso_hostess ? this._formatService.formatNumber(this.data.compenso_hostess) : '';

    this.rimborso_extra = this.editReport && this.data.rimborso_extra !== null ?
      this._formatService.formatNumber(this.data.rimborso_extra) : '';

    this.compenso_variable = this.editReport && this.data.compenso_variable !== null ?
      this._formatService.formatNumber(this.data.compenso_variable) : '';

    this.total_compenso = this.editReport && this.data.total_compenso !== null ?
      this._formatService.formatNumber(this.data.total_compenso) : this.amount;

    this.focusAmount = false;
    this.focusVariable = false;
  }

  closeDialog() {
    this.focusCategory = false;
    this.hostess_image = '';
    this.image_category = '';
    this.attachmentDialog = false;
    this.focusImage = false;
    this.image_msg = '';
  }

  deleteAttachment(index?) {
    if (index !== null && index !== undefined) {
      this.deleteDialog = true;
      this._index = index;
    } else {
      this.deleteDialog = false;
      if (this.attachments[this._index].file_id && this.editReport) {
        this.deletedAttachments.push({ file_id: this.attachments[this._index].file_id });
      }
      this.attachments.splice(this._index, 1);
      this._index = '';
    }
  }

  download_image(attachment) {
    let blobFile = this._formatService.base64ToBlob(attachment.base64);
    if (blobFile) {
      let a = document.createElement('a');
      document.body.appendChild(a);
      let url = this._window.URL.createObjectURL(blobFile);
      a.href = url;
      a.download = attachment.image_name;
      a.click();
      this._window.URL.revokeObjectURL(url);
    }
    this.pageDim = false;
  }

  filterEvents(data) {
    let events = [];
    for (let i = 0; i < data.length; i++) {
      if (data[i].status === 'Active' && !data[i].report_count) {
        events.push(data[i]);
      }
    }
    this.events = events;
  }

  formatAddress(data) {
    let addressOne = data.address_1 + '<br/>';
    let addressTwo = data.address_2;
    let address = addressTwo.split(',');
    let formatted = '';
    if (address && address.length > 0) {
      for (let i = 0; i < address.length - 1; i++) {
        if (i !== 0 && address[i]) {
          formatted += '<br/>';
        }
        formatted += address[i];
      }
      formatted += address[address.length - 1];
    }
    return this._sce.bypassSecurityTrustHtml(addressOne + formatted);
  }

  get_base64(attachment) {
    if (attachment.base64) {
      this.download_image(attachment);
    } else {
      this.pageDim = true;
      const endPoint = '/events/attachments/';
      const dict = { pk1_value: this.reportId, file_name: attachment.image_name };
      this._httpService.httpRequest('POST', endPoint, dict, (data) => {
        try {
          this.pageDim = false;
          if (data === null || data === undefined) {
            this._appService.notify({ status: 1, msg: 'Server Error - get_base64()' });
          } else if (data.status === 1) {
            this._appService.notify({ msg: data.msg, status: data.status });
            this.pageDim = false;
          } else {
            attachment.base64 = data.file_data;
            this.download_image(attachment);
          }
        } catch (e) {
          this._appService.notify({
            msg: e.message, status: 1,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }
  }

  loadAttachmentCategories() {
    const endPoint = '/events/attachmentcategories/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadAttachmentCategories()' });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.attachment_categories = data;
      }
    });
  }

  loadEvents() {
    let endPoint = '/events/summary/', req: any = {};
    req.user_id = '';
    if (this._dataService.roles.isAgent || this._dataService.roles.isHostess) {
      req.user_id = this.user.user_id;
    } else if (!this._dataService.roles.isAdmin && !this._dataService.roles.isAgency) {
      endPoint += 'user/';
      req.user_id = this.user.user_id;
    }
    req.from_date = '';
    req.to_date = '';
    req.created_by = '';
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - loadEvents()' });
        } else {
          if (data.status === 1) {
            this._appService.notify({ msg: data.msg, status: data.status });
            return;
          }
          this.filterEvents(data.events);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadHostess() {
    const endPoint = '/users/hostess/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - loadHostess()' });
        } else if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          this.hostess = data;
          if (this._appService.event) {
            this.selectedEvent = this._appService.event.event_id;
            this.onEventSelection();
            setTimeout(() => {
              this.event_name = this._appService.event.event_name;
              this._appService.event = '';
            }, 100);
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadReport() {
    let gift_currency, endPoint = '/events/hostess/report/' + this.reportId + '/';
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - loadReport()' });
        } else {
          if (data.status === 1) {
            this._appService.notify({ msg: data.msg, status: data.status });
            this.pageDim = false;
            return;
          }
          this.data = data;
          this.note = data.approver_note || '';
          let i, j;
          this.giftObjectives = [];
          this.totalValue = 0;
          if (data.hostess_id !== data.last_update_by) {
            this.reported_by = data.reported_by;

          }
          this.report_verified = data.report_verified;
          this.last_update_by = data.last_update_by;
          this.verified_by = data.verified_by;
          this.hostess_id = data.hostess_id;
          this.agency_verified = data.report_verified === 'Y';
          this.amount = data.amount !== null ? this._formatService.formatNumber(data.amount) : '';
          this.total_compenso = data.total_compenso !== null ? this._formatService.formatNumber(data.total_compenso) :
            data.report_status === 'PENDING_APPROVAL' ? this.amount : '';
          this.rimborso_extra = data.rimborso_extra !== null ? this._formatService.formatNumber(data.rimborso_extra) : '';
          this.compenso_variable = data.compenso_variable !== null ? this._formatService.formatNumber(data.compenso_variable) : '';
          if (data.attachments.length > 0) {
            this.attachments = [];
            for (i = 0; i < data.attachments.length; i++) {
              let attachment: any = {};
              attachment.image_name = data.attachments[i].file_name;
              attachment.image_type = data.attachments[i].file_content_type;
              attachment.base64 = data.attachments[i].file_data;
              attachment.file_id = data.attachments[i].file_id;
              attachment.image_category = data.attachments[i].description;
              let index = this.attachment_categories.map(x => x.lookup_key).indexOf(data.attachments[i].description);
              if (index !== -1) {
                attachment.lookup_value = this.attachment_categories[index].lookup_value;
              }
              this.attachments.push(attachment);
            }
          }
          for (i = 0; i < data.gifts.length; i++) {
            data.gifts[i].targets = [];
            data.gifts[i].vouchers_spent = 0;
            data.gifts[i].f_value_spent = this._formatService.formatNumber(data.gifts[i].value_spent);
            data.gifts[i].last_updated_by = this.user.user_id;
            data.gifts[i].last_updated_date = this._appService.today(0);
            for (j = 0; j < data.gifts[i].targets.length; j++) {

              gift_currency = gift_currency || data.gifts[i].targets[j].currency;
              data.gifts[i].targets[j].f_value = data.gifts[i].targets[j].value ? this._formatService.formatNumber(
                data.gifts[i].targets[j].value.toString()) : '';
              data.gifts[i].targets[j].value_spent = data.gifts[i].targets[j].value_spent || '';
              data.gifts[i].targets[j].last_updated_by = this.user.user_id;
              data.gifts[i].targets[j].last_updated_date = this._appService.today(0);
              data.gifts[i].targets[j].f_value_spent = data.gifts[i].targets[j].value_spent ?
                this._formatService.formatNumber(
                  data.gifts[i].targets[j].value_spent.toString()) : '';
              data.gifts[i].vouchers_spent += data.gifts[i].targets[j].vouchers ? parseInt(
                data.gift_targets[j].vouchers) : 0;
            }
            this.giftObjectives.push(data.gifts[i]);
            this.totalValue += data.gifts[i].value * data.gifts[i].vouchers;
          }
          if (data.gifts.length > 0) {
            gift_currency = data.gifts[0].currency;
          } else {
            this.f_totalValue = this._formatService.formatNumber(0);
          }
          if (data.report_status === 'APPROVED' || data.report_status === 'REJECTED') {
            this.f_totalValue = data.discount !== null ? this._formatService.formatNumber(data.discount) : this._formatService.formatNumber(this.totalValue);
          } else {
            for (i = 0; i < data.gifts.length; i++) {
              if (data.gifts[i].currency === gift_currency) {
                this.f_totalValue = data.discount !== null ? this._formatService.formatNumber(data.discount) : this._formatService.formatNumber(this.totalValue);
              } else {
                this.f_totalValue = '';
                break;
              }
            }
          }
          this.tmpObjectives = [];
          for (i = 0; i < data.objectives.length; i++) {
            data.objectives[i].last_updated_by = this.user.user_id;
            data.objectives[i].last_updated_date = this._appService.today(0);
            for (j = 0; j < data.objectives[i].targets.length; j++) {
              data.objectives[i].targets[j].last_updated_date = this._appService.today(0);
              data.objectives[i].targets[j].last_updated_by = this.user.user_id;
            }
            this.tmpObjectives.push(data.objectives[i]);
          }
          this.shippingAddress = this.formatAddress(data);
          this.selectedEvent = data.event_id;
          this.hostessName = data.hostess_name;
          this.createdBy = data.created_by;
          setTimeout(() => {
            jQuery('#event-name').val(data.event_name);
          }, 100);
          this.event_name = data.event_name;
          this.reportDate = this._formatService.formatDate(data.report_date);
          this.pageDim = false;
          if ((this._dataService.roles.isAgency && (this.data.report_status === 'REJECTED')) ||
            (this.viewUserId === this.createdBy ||
              this.viewUserId === this.hostess_id) && (this.data.report_status === 'REJECTED' ||
              data.report_status === 'CREATED')) {
            this.reportDate = this._formatService.formatDate(this._appService.today(0));
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  onEventSelection() {
    let endPoint = '/events/id/' + this.selectedEvent + '/';
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - onEventSelection()' });
        } else {
          if (data.status === 1) {
            this._appService.notify({ msg: data.msg, status: data.status });
            return;
          }
          this.data = data;
          this.amount = data.compenso_hostess ? this._formatService.formatNumber(data.compenso_hostess) : '';
          this.note = '';
          this.event_date_millis = this._formatService.dateInMillis(data.event_date);
          this.todays_date_millis = this._formatService.dateInMillis(this._appService.today(0));
          data.f_event_date = this._formatService.formatDate(data.event_date);
          if (this._dataService.roles.isAdmin && (this.event_date_millis <= this.todays_date_millis)) {
            new FooPicker({
              id: 'report-date',
              dateFormat: this.format
            });
          }
          this.reportDate = this._formatService.formatDate(this._appService.today(0));
          this.shippingAddress = this.formatAddress(data);
          this.gifts = data.gifts;
          let i, j, index;
          if (this.hostess.length > 0) {
            index = this.hostess.map(x => parseInt(x.user_id)).indexOf(parseInt(data.hostess_id));
            this.hostessName = this.hostess[index].user_description;
          }
          this.giftObjectives = [];
          for (i = 0; i < data.gifts.length; i++) {
            data.gifts[i].vouchers_spent = 0;
            data.gifts[i].value_spent = 0;
            data.gifts[i].f_value_spent = 0;
            for (j = 0; j < data.gifts[i].targets.length; j++) {
              if (data.gifts[i].targets[j].event_objective_id === data.gifts[i].objective_id) {
                data.gifts[i].targets[j].value_spent = '';
                data.gifts[i].targets[j].event_id = data.event_id;
                data.gifts[i].targets[j].value = data.gifts[i].value;
                data.gifts[i].targets[j].f_value = this._formatService.formatNumber(data.gifts[i].value);
                data.gifts[i].targets[j].event_gift_id = data.gifts[i].event_gift_id;
                data.gifts[i].targets[j].currency = data.gifts[i].currency;
                data.gifts[i].targets[j].vouchers = '';
              }
            }
            this.giftObjectives.push(data.gifts[i]);
          }
          this.tmpObjectives = [];
          this.reportDate = !this.editReport && this.event_date_millis > this.todays_date_millis ? this.data.f_event_date : this._formatService.formatDate(this._appService.today(0));
          for (i = 0; i < data.objectives.length; i++) {
            // data.objectives[i].targets = [];
            data.objectives[i].target_achieved = 0;
            for (j = 0; j < data.objectives[i].targets.length; j++) {
              data.objectives[i].targets[j].target_achieved = '';
            }
            this.tmpObjectives.push(data.objectives[i]);
          }
          // this.targets = data.targets;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  onTargetChange(target) {
    target.target_achieved = parseInt(target.target_achieved) >= 0 ? parseInt(target.target_achieved) : '';
  }

  reject() {
    this.focusTotal = false;
    this.total_msg = '';
    this.rejectEvent = true;
    this.editReport = true;
    this.f_totalValue = this.f_totalValue || '';
    this.showApproval = 'Reject';
    if ((this._dataService.roles.isAgent || this._dataService.roles.isAdmin) && this.data.report_status === 'REJECTED') {
      this.saveReport();
    }
  }

  saveReport() {
    let endPoint = '/events/hostess/', req: any = {}, i, type;
    req.report_verified = this._dataService.roles.isAgency ? this.agency_verified ? 'Y' : 'N' : this.report_verified || '';
    req.verified_by = this.submit && this._dataService.roles.isAgency ? this.user.user_id : this.verified_by || '';
    req.discount = this.f_totalValue ? this._formatService.parseNumber(this.f_totalValue) : '';
    if (this.showApproval === 'Approve' && (!this.amount || !this.compenso_variable)) {
      this.focusAmount = true;
      this.focusVariable = true;
      return;
    }
    if (!this.editReport || (this.editReport && (this.data.report_status === 'REJECTED' || this.data.report_status === 'PENDING_APPROVAL'))) {
      req.attachments = [];
      for (i = 0; i < this.attachments.length; i++) {
        if (!this.attachments[i].file_id) {
          let attachment: any = {};
          attachment.file_blob = this.attachments[i].base64;
          attachment.ref_id = parseInt(this.selectedEvent);
          attachment.title = 'HOSTESS LINES';
          attachment.file_name = this.attachments[i].image_name;
          attachment.content_type = this.attachments[i].image_type;
          attachment.entity_name = 'EVENTS';
          attachment.category_name = 'Miscellaneous';
          attachment.description = this.attachments[i].image_category;
          req.attachments.push(attachment);
        }
      }
    }
    if (this.editReport) {
      req.deletedAttachments = this.deletedAttachments;
    }
    if (this.amount) {
      req.amount = this._formatService.parseNumber(this.amount.toString());
    } else {
      req.amount = '';
    }
    req.note = this.note || '';
    req.rimborso_extra = this.rimborso_extra ? this._formatService.parseNumber(this.rimborso_extra) : '';
    req.compenso_variable = this.compenso_variable ? this._formatService.parseNumber(this.compenso_variable) : '';
    this.total_compenso = this._formatService.parseNumber(0);
    if (this.amount) {
      this.total_compenso = this.total_compenso + this._formatService.parseNumber(this.amount);
    }
    if (this.compenso_variable) {
      this.total_compenso = this.total_compenso + this._formatService.parseNumber(this.compenso_variable);
    }
    if (this.rimborso_extra) {
      this.total_compenso = this.total_compenso + this._formatService.parseNumber(this.rimborso_extra);
    }
    req.total_compenso = this.total_compenso || '';
    this.showApproval = '';
    if (!this.editReport && !this.validateEvent()) {
      this.selectedEvent = null;
      this.focusselectedEvent = false;
      this.submit = false;
      this.rejectEvent = false;
      this.approveEvent = false;
      this.amount = '';
      return;
    }
    req.event_id = parseInt(this.selectedEvent);
    if (this.editReport) {
      req.report_id = this.reportId;
    }
    if (this.reportDate) {
      req.report_date = this._formatService.parseDate(this.reportDate);
    } else {
      this.reportDate = null;
      this.focusreportDate = false;
      this.submit = false;
      this.rejectEvent = false;
      this.approveEvent = false;
      this.amount = '';
      return;
    }
    if (this.hostessName) {
      req.hostess_name = this.hostessName;
    } else {
      this.hostessName = null;
      this.focushostessName = false;
      this.submit = false;
      this.rejectEvent = false;
      this.approveEvent = false;
      this.amount = '';
      return;
    }
    if (!this.editReport) {
      req.creation_date = this._appService.today(0);
      req.created_by = this.user.user_id;
    }
    req.last_updated_date = this._appService.today(0);
    if (this.editReport && this.data.report_status === 'APPROVED' && this.submit) {
      req.status = 'APPROVED';
      req.last_update_by = this.user.user_id;
      req.approver = this.data.approver;
    } else if (this.submit) {
      req.status = 'PENDING_APPROVAL';
      req.last_update_by = this.user.user_id;
      req.approver = '';
    } else if (this.approveEvent) {
      req.status = 'APPROVED';
      req.last_update_by = this.last_update_by;
      req.approver = this.user.user_id;
    } else if (this.rejectEvent) {
      req.status = 'REJECTED';
      req.approver = this.user.user_id;
      req.last_update_by = this.last_update_by;
    }
    req.objectives = this.tmpObjectives;
    req.gifts = this.giftObjectives;
    this.pageDim = true;
    req.send_email = !(this.editReport && !this._dataService.roles.isAgent &&
      !this._dataService.roles.isAdmin && this.data.report_status === 'APPROVED');
    type = this.editReport ? 'PUT' : 'POST';
    this._httpService.httpRequest(type, endPoint, req, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - saveReport()' });
        } else {
          this.pageDim = false;
          if (data.status === 1) {
            this._appService.notify({ status: data.status, msg: data.msg });
          } else {
            if (this.submit) {
              this._appService.hostessMsg = 'Report submitted successfully';
            } else if (this.approveEvent) {
              this._appService.hostessMsg = 'Report approved';
            } else if (this.rejectEvent) {
              this._appService.hostessMsg = 'Report rejected';
            } else {
              this._appService.hostessMsg = data.msg;
            }
            this._appService.hostessStatus = data.status;
            this._router.navigate(['events/hostess/report']);
            this.editReport = false;
            this.reportId = '';
          }
        }
        this.submit = false;
        this.rejectEvent = false;
        this.approveEvent = false;
        this.amount = '';
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  selectAction(state_name) {
    if (state_name) {
      this._router.navigate(state_name);
    }
  }

  setLookUpValue() {
    let index = this.attachment_categories.map(x => x.lookup_key).indexOf(this.image_category);
    if (index !== -1) {
      this.lookup_value = this.attachment_categories[index].lookup_value;
    }
  }

  submitReport() {
    if ((!this.editReport || (this.editReport && (this.data.report_status === 'REJECTED' ||
      ((this._dataService.roles.isAgency || this._dataService.roles.isHostess) && this.data.report_status === 'PENDING_APPROVAL')))) &&
      this.attachments.length === 0) {
      this._appService.notify({ msg: 'Add atleast one attachment', status: 1 });
      return;
    }
    this.submit = true;
    this.showApproval = 'Submit';
  }

  totalTarget(objective) {
    objective.target_achieved = 0;
    for (let i = 0; i < objective.targets.length; i++) {
      if (objective.targets[i].target_achieved) {
        objective.target_achieved = parseInt(objective.target_achieved) + parseInt(objective.targets[i].target_achieved);
      }
    }
  }

  totalValueSpent(target, objective) {
    objective.vouchers_spent = 0;
    objective.value_spent = 0;
    objective.f_value_spent = 0;
    if (!target.vouchers) {
      target.value_spent = '';
      target.f_value_spent = '';
    } else {
      target.f_value_spent = this._formatService.formatNumber(parseFloat(target.vouchers) * parseFloat(objective.value));
      target.value_spent = parseFloat(target.vouchers) * parseFloat(objective.value);
    }
    for (let i = 0; i < objective.targets.length; i++) {
      if (objective.targets[i].vouchers) {
        objective.vouchers_spent += parseInt(objective.targets[i].vouchers);
      }
      if (objective.targets[i].value_spent) {
        objective.value_spent += parseFloat(objective.targets[i].value_spent.toString());
        objective.f_value_spent = this._formatService.formatNumber(objective.value_spent);
      }
    }
  }

  updateAttachment() {
    if (!this.image_category) {
      this.focusCategory = true;
      return;
    }
    if (!this.hostess_image) {
      this.focusImage = true;
      this.image_msg = 'Image is required';
      return;
    }

    let index = this.attachments.map(x => x.image_name).indexOf(this.hostess_image.filename);
    if (index !== -1 && this.attachments[index].lookup_value === this.lookup_value) {
      this.focusImage = true;
      this.image_msg = 'Image name already exists with selected category';
      this.hostess_image = '';
      return;
    }

    this.attachments.push({
      image_name: this.hostess_image.filename,
      image_type: this.hostess_image.filetype,
      base64: this.hostess_image.base64,
      image_category: this.image_category,
      lookup_value: this.lookup_value
    });
    this.hostess_image = '';
    this.image_category = '';
    this.attachmentDialog = false;
    (document.getElementById('fileUpload') as HTMLFormElement).value = null;
  }

  validateAttachment() {
    if (!this.hostess_image) {
      return;
    }
    if (this.hostess_image.filetype !== 'image/jpeg' && this.hostess_image.filetype !== 'image/png') {
      this.hostess_image = '';
      this.focusImage = true;
      this.image_msg = 'Upload image of type JPEG/PNG';
    } else {
      this.focusImage = false;
    }
  }

  validateAmount(amount, type) {
    if (amount !== '') {
      amount = this._formatService.numberParser(amount);
      if (type === 'compenso_base') {
        this.amount = amount;
      } else if (type === 'rimborso_extra') {
        this.rimborso_extra = amount;
      } else {
        this.compenso_variable = amount;
      }
    }
    this.total_compenso = 0;
    if (this.rimborso_extra) {
      this.total_compenso = this.total_compenso + parseFloat(this._formatService.parseNumber(this.rimborso_extra));
    }
    if (this.compenso_variable) {
      this.total_compenso = this.total_compenso + parseFloat(this._formatService.parseNumber(this.compenso_variable));
    }
    if (this.amount) {
      this.total_compenso = this.total_compenso + parseFloat(this._formatService.parseNumber(this.amount));
    }
    this.total_compenso = this._formatService.formatNumber(this.total_compenso.toString());
  }

  validateEvent() {
    let id = parseInt(this.selectedEvent);
    let index = this.events.map(x => x.event_id).indexOf(id);
    return index !== -1;
  }

  validateTotalValue() {
    if (!this.f_totalValue) {
      return;
    }
    this.f_totalValue = this._formatService.numberParser(this.f_totalValue);
  }

  validateVoucher(voucher) {
    voucher.vouchers = parseInt(voucher.vouchers) >= 0 ? parseInt(voucher.vouchers) : '';
    if (this._dataService.roles.isAgent || this._dataService.roles.isAdmin) {
      this.totalValue = 0;
      for (let i = 0; i < this.giftObjectives.length; i++) {
        this.totalValue += this.giftObjectives[i].value * this.giftObjectives[i].vouchers;
      }
      this.f_totalValue = this._formatService.formatNumber(this.totalValue);
    }
  }
}
