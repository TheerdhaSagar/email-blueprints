import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { DataService } from '../../../globals/data.service';
import { OrderByPipe } from '../../../globals/order-by.pipe';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';

@Component({
  selector: 'app-events-hostess-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
  providers: [OrderByPipe]
})
export class HostessUsersComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  actions: any[];
  desc: boolean;
  predicate: string;
  roles: any;
  searchUser: any;
  showActions: any;
  showSpinner: boolean;
  toggleFilter: (e?) => void;
  users: any[];
  windowWidth: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService,
              orderBy: OrderByPipe, formatService: FormatService, httpService: HttpService,
              location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.actions = [];
    this.desc = true;
    this.predicate = 'user_id';
    this.roles = dataService.roles;
    this.toggleFilter = appService.toggleFilter();
    this.users = [];
    this.windowWidth = dataService.windowWidth;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', {
      page: this._location.path()
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.loadUsers();
        this.pushActions();
        this.toggleFilter = this._appService.toggleFilter();
      }
    });
  }

  createHostess() {
    this._router.navigate(['events/hostess/create']);
  }

  editHostess(user) {
    this._appService.hostess_id = user.user_id;
    this._router.navigate(['events/hostess/create']);
  }

  exportData() {
    this.toggleFilter();
    let tableData: any = {}, tmpData = [], i, tmpObj,
      data = this._orderBy.transform(this.users, this.predicate, this.desc);
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj['User Name'] = { data: data[i].user_name };
      tmpObj['User Description'] = { data: data[i].user_description };
      tmpObj['Email Address'] = { data: data[i].email_address };
      tmpObj['External Identification'] = { data: data[i].external_id };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Hostess', tableData, 'exportUsers');
  }

  loadUsers(): void {
    this.showSpinner = true;
    const endPoint = '/events/hostessusers/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error- loadUsers()' });
      } else if (data.status === 1) {
        this._appService.notify({ status: data.status, msg: data.msg });
      } else {
        for (let i = 0; i < data.length; i++) {
          data[i].external_id = data[i].external_identification !== null ? data[i].external_identification : '';
        }
        this.users = data;
      }
    });
  }

  pushActions() {
    this.actions.push({ name: 'Event Summary', label: 'events/summary' });
    this.actions.push({ name: 'Create Event', label: 'events/manage' });
    this.actions.push({ name: 'Hostess Report', label: 'events/hostess/report' });
    this.actions.push({ name: 'Create Hostess', label: 'events/hostess/create' });
    if (!this.roles.isHostess) {
      this.actions.push({ name: 'View Report', label: 'events/reports/hostess' });
    }
    if (this.roles.isAgent || this.roles.isAdmin) {
      this.actions.push({ name: 'Ambassador Visits', label: 'events/ambassador/summary' });
    }
    if (!this.roles.isAgency) {
      this.actions.push({ name: 'View Objectives', label: 'events/objectives/summary' });
      this.actions.push({ name: 'Create Objective', label: 'events/objectives/manage' });
    }
  }

  selectAction(state_name) {
    this._router.navigate([state_name]);
  }

  sort(key) {
    this.desc = !this.desc;
    this.predicate = key;
  }
}
