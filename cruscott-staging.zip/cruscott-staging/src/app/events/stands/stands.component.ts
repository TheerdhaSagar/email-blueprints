import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';

@Component({
  selector: 'app-events-stands',
  templateUrl: './stands.component.html',
  styleUrls: ['./stands.component.scss'],
  providers: [OrderByPipe]
})
export class StandComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  agentCost: any;
  assembleCost: any;
  desc = true;
  hostessCost: any;
  msg: any;
  otherCost: any;
  pageDim: any;
  predicate: string;
  rentalCost: any;
  reservations: any;
  searchQuery: any;
  selectedLine: any;
  shippingCost: any;
  showConfirmation: any;
  showSpinner: any;
  standName: any;
  stands: any;
  status: any;
  toggleFilter: (e?) => void;
  totalCost: any;

  constructor(appService: AppService, cacheService: CacheService, orderBy: OrderByPipe, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.agentCost = null;
    this.assembleCost = null;
    this.desc = true;
    this.hostessCost = null;
    this.otherCost = null;
    this.pageDim = null;
    this.predicate = 'from_date_millis';
    this.rentalCost = null;
    this.reservations = null;
    this.selectedLine = null;
    this.shippingCost = null;
    this.showConfirmation = null;
    this.showSpinner = null;
    this.standName = null;
    this.stands = null;
    this.toggleFilter = appService.toggleFilter();
    this.totalCost = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        if (this._appService.bookingMsg) {
          this._appService.notify({ status: this._appService.bookingStatus, msg: this._appService.bookingMsg });
          this._appService.bookingStatus = null;
          this._appService.bookingMsg = null;
        }

        this.loadData();
      }
    });
  }

  deleteBooking() {
    if (!this.selectedLine) {
      return;
    }
    const endPoint = `/events/stand/book/${this.selectedLine.reserve_hdr_id}/`;
    this.showConfirmation = false;
    this.pageDim = true;
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - deleteBooking' });
        } else if (data && data.msg) {
          if (data.status === 0) {
            const index = this.reservations.indexOf(this.selectedLine);
            if (index !== -1) {
              this.reservations.splice(index, 1);
            }
          }
          this._appService.notify({ status: data.status, msg: data.msg });
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  editReservation(r) {
    this._appService.reservation_id = r.reserve_hdr_id;
    this._appService.editBooking = true;
    this._appService.stand_id = r.stand_id;
    this._router.navigate(['events/stands/manage']);
  }

  exportData() {
    let list = [], listData: any = {}, data = this.stands, tableData: any = {}, i, tmpData = [], tmpObj;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj.Stand = { data: data[i].stand_name };
      tmpObj['Current Location'] = { data: data[i].current_location };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    listData.tableData = tableData;
    listData.title = 'Stands';
    list.push(listData);

    if (this.reservations && this.reservations.length > 0) {
      data = this._orderBy.transform(this.reservations, this.predicate, this.desc);
      tableData = {};
      tmpData = [];
      listData = {};
      for (i = 0; i < data.length; i++) {
        tmpObj = {};
        tmpObj['#'] = { data: data[i].reserve_hdr_id };
        tmpObj.Purpose = { data: data[i].description };
        tmpObj.Location = { data: data[i].final_location };
        tmpObj.From = { data: data[i].f_from_date };
        tmpObj.To = { data: data[i].f_till_date };
        tmpObj['Reserved By'] = { data: data[i].reserved_by };
        tmpObj['Shipping Cost'] = { data: data[i].f_shipping_cost, align: 'right' };
        tmpObj['Assemble Cost'] = { data: data[i].f_assemble_cost, align: 'right' };
        tmpObj['Rental Cost'] = { data: data[i].f_rental_cost, align: 'right' };
        tmpObj['Hostess Cost'] = { data: data[i].f_hostess_cost, align: 'right' };
        tmpObj['Agent Cost'] = { data: data[i].f_agent_cost, align: 'right' };
        tmpObj['Other Cost'] = { data: data[i].f_other_cost, align: 'right' };
        tmpObj.Total = { data: data[i].f_total, align: 'right' };
        tmpObj.Status = { data: data[i].status };
        tmpData.push(tmpObj);
      }
      tableData.data = tmpData;
      tableData.footer = [{ data: '' }, { data: '' }, { data: '' }, { data: '' }, { data: '' },
        { data: this.shippingCost, align: 'right' }, { data: this.assembleCost, align: 'right' },
        { data: this.rentalCost, align: 'right' }, { data: this.hostessCost, align: 'right' },
        { data: this.agentCost, align: 'right' }, { data: this.otherCost, align: 'right' },
        { data: this.totalCost, align: 'right' }, { data: '' }];
      listData.tableData = tableData;
      listData.title = 'Reservations for ' + this.standName;
      list.push(listData);
    }

    this._appService.exportMultiTable('Stands & Reservations', list, 'export-stands');
  }

  formatData(data) {
    let shippingCost = 0, assembleCost = 0, rentalCost = 0, hostessCost = 0, otherCost = 0, totalCost = 0,
      agentCost = 0;

    for (let i = 0; i < data.length; i++) {
      data[i].f_from_date = this._formatService.formatDate(data[i].from_date);
      data[i].f_till_date = this._formatService.formatDate(data[i].till_date);
      data[i].from_date_millis = this._formatService.dateInMillis(data[i].from_date);
      data[i].till_date_millis = this._formatService.dateInMillis(data[i].till_date);

      data[i].f_shipping_cost = this._formatService.formatNumber(data[i].shipping_cost);
      data[i].f_assemble_cost = this._formatService.formatNumber(data[i].assemble_cost);
      data[i].f_rental_cost = this._formatService.formatNumber(data[i].rental_cost);
      data[i].f_hostess_cost = this._formatService.formatNumber(data[i].hostess_cost);
      data[i].f_agent_cost = this._formatService.formatNumber(data[i].agent_cost);
      data[i].f_other_cost = this._formatService.formatNumber(data[i].other_cost);

      data[i].shipping_cost = data[i].shipping_cost ? parseFloat(data[i].shipping_cost) : 0;
      data[i].assemble_cost = data[i].assemble_cost ? parseFloat(data[i].assemble_cost) : 0;
      data[i].rental_cost = data[i].rental_cost ? parseFloat(data[i].rental_cost) : 0;
      data[i].hostess_cost = data[i].hostess_cost ? parseFloat(data[i].hostess_cost) : 0;
      data[i].agent_cost = data[i].agent_cost ? parseFloat(data[i].agent_cost) : 0;
      data[i].other_cost = data[i].other_cost ? parseFloat(data[i].other_cost) : 0;

      let total = data[i].shipping_cost + data[i].assemble_cost +
        data[i].rental_cost + data[i].hostess_cost + data[i].other_cost + data[i].agent_cost;

      shippingCost += data[i].shipping_cost;
      assembleCost += data[i].assemble_cost;
      rentalCost += data[i].rental_cost;
      hostessCost += data[i].hostess_cost;
      agentCost += data[i].agent_cost;
      otherCost += data[i].other_cost;
      totalCost += total;

      data[i].total = total;
      data[i].f_total = this._formatService.formatNumber(data[i].total);
    }

    this.shippingCost = this._formatService.formatNumber(shippingCost);
    this.assembleCost = this._formatService.formatNumber(assembleCost);
    this.rentalCost = this._formatService.formatNumber(rentalCost);
    this.hostessCost = this._formatService.formatNumber(hostessCost);
    this.agentCost = this._formatService.formatNumber(agentCost);
    this.otherCost = this._formatService.formatNumber(otherCost);
    this.totalCost = this._formatService.formatNumber(totalCost);

    this.reservations = data;
    this.pageDim = false;
  }

  getReservations(s): void {
    const endPoint = `/events/stands/reservations/${s.stand_id}/`;
    this.reservations = null;
    this.standName = s.stand_name;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - getReservations' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.formatData(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadData() {
    const endPoint = '/events/stands/';
    this.showSpinner = true;
    this.stands = null;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - loadData' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          const stands = data.stands;
          for (let i = 0; i < stands.length; i++) {
            if (stands[i].next_available_date) {
              stands[i].f_next_available_date = this._formatService.formatDate(stands[i].next_available_date);
            }
          }
          this.stands = stands;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  // called when delete icon is clicked
  onDelete(line) {
    let index = this.reservations.indexOf(line);
    if (index !== -1) {
      this.selectedLine = line;
      this.showConfirmation = true; // show confirmation dialog
    }
  }

  reserveStand(s) {
    this._appService.stand_id = s.stand_id;
    this._router.navigate(['events/stands/manage']);
  }

  sort(key) {
    this.predicate = key;
    this.desc = !this.desc;
  }
}
