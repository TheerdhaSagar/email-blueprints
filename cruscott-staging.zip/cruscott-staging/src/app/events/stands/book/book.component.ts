import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';
import { APIError } from '../../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-events-stands-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.scss']
})
export class BookStandComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  addAttachments: any;
  agentCost: any;
  amountAlert: any;
  approvalStatus: any;
  approverId: any;
  assembleCost: any;
  assembleinvoice: any;
  assembleSup: any;
  assembleSupplier: any;
  availableFrom: any;
  bookingDetails: any;
  bookingFrom: any;
  bookingLines: any;
  bookingStatus: any;
  closeBooking: any;
  comment: any;
  editBooking: any;
  finalLocation: any;
  focusavailableFrom: any;
  focusbookingFrom: any;
  focuscomment: any;
  focusfinalLocation: any;
  focuspurpose: any;
  focusselectedStand: any;
  format: any;
  fromStands: any;
  hostessCost: any;
  invoiceLine: any;
  justification: any;
  otherCost: any;
  pageDim: boolean;
  purpose: any;
  randomId: any;
  rentalCost: any;
  rentinvoice: any;
  rentSup: any;
  rentSupplier: any;
  reservationId: any;
  reservations: any;
  selectedLine: any;
  selectedStand: any;
  shippingCost: any;
  showDialog: any;
  stands: any;
  suppliers: any;
  totalCost: any;
  user: any;
  userAction: any;
  wfActions: any;
  wfDialog: any;
  wfItemKey: any;
  wfType: any;
  wfUsername: any;

  constructor(appService: AppService, cacheService: CacheService, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.addAttachments = null;
    this.agentCost = null;
    this.amountAlert = null;
    this.approvalStatus = null;
    this.approverId = null;
    this.assembleCost = null;
    this.assembleinvoice = {};
    this.assembleSup = null;
    this.assembleSupplier = null;
    this.availableFrom = null;
    this.bookingDetails = null;
    this.bookingFrom = null;
    this.bookingLines = null;
    this.bookingStatus = null;
    this.closeBooking = null;
    this.comment = null;
    this.editBooking = null;
    this.finalLocation = null;
    this.focusavailableFrom = null;
    this.focusbookingFrom = null;
    this.focuscomment = null;
    this.focusfinalLocation = null;
    this.focuspurpose = null;
    this.focusselectedStand = null;
    this.format = null;
    this.fromStands = null;
    this.hostessCost = null;
    this.invoiceLine = null;
    this.justification = null;
    this.otherCost = null;
    this.purpose = null;
    this.randomId = null;
    this.rentalCost = null;
    this.rentinvoice = {};
    this.rentSup = null;
    this.rentSupplier = null;
    this.reservationId = null;
    this.reservations = null;
    this.selectedLine = null;
    this.selectedStand = null;
    this.shippingCost = null;
    this.showDialog = null;
    this.stands = null;
    this.suppliers = null;
    this.totalCost = null;
    this.user = null;
    this.userAction = null;
    this.wfActions = null;
    this.wfDialog = null;
    this.wfItemKey = null;
    this.wfType = null;
    this.wfUsername = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;

        if (this._appService.editBooking) {
          this.editBooking = true;
          this.reservationId = this._appService.reservation_id;
          this._appService.reservation_id = null;
          this._appService.editBooking = null;
        } else if (this._appService.wfType === 'QPXSTAPR') {
          this.editBooking = true;
          this.reservationId = this._appService.wfUserKey;
          this.wfType = this._appService.wfType;
          this.wfUsername = this._appService.wfUsername;
          this.wfItemKey = this._appService.wfItemKey;
          this.wfActions = true;
          this._appService.wfType = null;
          this._appService.wfUserKey = null;
          this._appService.wfItemKey = null;
          this._appService.wfUsername = null;
        }

        this.format = this.user.date_format || 'dd-MMM-yyyy';
        this.shippingCost = this._formatService.formatNumber(0);
        this.assembleCost = this._formatService.formatNumber(0);
        this.rentalCost = this._formatService.formatNumber(0);
        this.agentCost = this._formatService.formatNumber(0);
        this.hostessCost = this._formatService.formatNumber(0);
        this.otherCost = this._formatService.formatNumber(0);
        this.totalCost = this._formatService.formatNumber(0);

        if (this.editBooking) {
          this.loadReservation();
        } else {
          this.bookingLines = [{ id: 1 }];
          // addPickers();
        }

        this.loadStands();
        this.loadSuppliers();
      }
    });

  }

  addInvoice(l?) {
    if (l) {
      this.invoiceLine = l;
      if (this.editBooking && l.docs_count > 0) {
        this.justification = l.justification;
        this.loadLineDocs(l);
      } else {
        this.addAttachments = true;

        if (l.assemble) {
          this.assembleinvoice = l.assemble.invoice;
          this.assembleSup = l.assemble.supplier;
        }
        if (l.rent) {
          this.rentinvoice = l.rent.invoice;
          this.rentSup = l.rent.supplier;
        }

        this.justification = l.justification;
      }
    } else {
      let index = this.bookingLines.indexOf(this.invoiceLine);
      if (index !== -1) {
        let assemble: any = {}, rent: any = {};
        if (this.assembleinvoice) {
          assemble.supplier = this.assembleSupplier || -1;
          assemble.invoice = this.assembleinvoice;
          assemble.creation_date = this._appService.today(0);
          assemble.created_by = this.user.user_id;
          assemble.last_update_date = this._appService.today(0);
          assemble.last_updated_by = this.user.user_id;
        }
        if (this.rentinvoice) {
          rent.supplier = this.rentSupplier || -1;
          rent.invoice = this.rentinvoice;
          rent.creation_date = this._appService.today(0);
          rent.created_by = this.user.user_id;
          rent.last_update_date = this._appService.today(0);
          rent.last_updated_by = this.user.user_id;
        }

        if (assemble && assemble.invoice) {
          this.bookingLines[index].assemble = assemble;
        } else {
          this.bookingLines[index].assemble = null;
        }

        if (rent && rent.invoice) {
          this.bookingLines[index].rent = rent;
        } else {
          this.bookingLines[index].rent = null;
        }

        if (this.justification) {
          this.bookingLines[index].justification = this.justification;
        }

        this.clearAddInvoice();
      }
      this.invoiceLine = null;
      this.addAttachments = false;
    }
  }

  addLine() {
    let len, id = 1;
    if (this.bookingLines && this.bookingLines.length > 0) {
      len = this.bookingLines.length;
      id = this.bookingLines[len - 1].id;
      id += 1;
    } else {
      this.bookingLines = [];
    }
    this.bookingLines.push({ id });
    // addPickers();
  }

  addPickers(disabled) {
    this.randomId = Math.round(Math.random() * 1000000);

    jQuery('[id^=\'foopicker-from\']').remove();
    jQuery('[id^=\'foopicker-till\']').remove();

    setTimeout(() => {
      new FooPicker({
        id: 'from-date-' + this.randomId,
        dateFormat: this.format,
        disable: disabled
      });

      new FooPicker({
        id: 'till-date-' + this.randomId,
        dateFormat: this.format,
        disable: disabled
      });
    }, 10);
  }

  backToStands() {
    this._router.navigate(['events/stands']);
  }

  bookStand() {
    let endPoint = '/events/stand/book/', req: any = {};
    if (this.editBooking) {
      req.stand_id = this.bookingDetails.stand_id;
    } else {
      if (!this.validateStand()) {
        this.selectedStand = null;
        this.focusselectedStand = false;
        return;
      } else {
        req.stand_id = this.selectedStand;
      }
    }

    if (this.purpose) {
      req.description = this.purpose;
    } else {
      this.purpose = null;
      this.focuspurpose = false;
      return;
    }

    if (this.bookingFrom) {
      req.from_date = this._formatService.parseDate(this.bookingFrom);
    } else {
      this.bookingFrom = null;
      this.focusbookingFrom = false;
      return;
    }
    if (this.availableFrom) {
      req.till_date = this._formatService.parseDate(this.availableFrom);
    } else {
      this.availableFrom = null;
      this.focusavailableFrom = false;
      return;
    }
    if (this.finalLocation) {
      req.final_location = this.finalLocation;
    } else {
      this.finalLocation = null;
      this.focusfinalLocation = false;
      return;
    }

    req.reserved_by = this.user.user_description;
    req.creation_date = this._appService.today(0);
    req.created_by = this.user.user_id;
    req.last_updated_date = this._appService.today(0);
    req.last_updated_by = this.user.user_id;
    if (this.editBooking) {
      req.reserve_hdr_id = this.reservationId;
      if (this.approvalStatus || this.approverId) {
        req.approval_status = 'WF Initiated';
      } else {
        req.approval_status = '';
      }
    }
    if (this.closeBooking || this.bookingStatus === 'Closed') {
      req.status = 'Closed';
    } else {
      req.status = 'Open';
    }

    let tmpLines = [];
    if (this.bookingLines && this.bookingLines.length > 0) {
      for (let i = 0; i < this.bookingLines.length; i++) {
        let line = this.bookingLines[i];
        if (line.assemble_cost && line.shipping_cost && line.rental_cost &&
          line.agent_cost && line.hostess_cost) {
          let obj: any = {};
          if (line.assemble) {
            obj.assemble = {};
            obj.assemble.supplier_id = parseInt(line.assemble.supplier);
            obj.assemble.filetype = line.assemble.invoice.filetype;
            obj.assemble.filename = line.assemble.invoice.filename;
            obj.assemble.filesize = line.assemble.invoice.filesize;
            obj.assemble.base64 = line.assemble.invoice.base64;
            obj.assemble.created_by = this.user.user_id;
            obj.assemble.last_updated_by = this.user.user_id;
            obj.assemble.type = 'ASSEMBLE';
          } else {
            obj.assemble = '';
          }
          if (line.rent) {
            obj.rent = {};
            obj.rent.supplier_id = parseInt(line.rent.supplier);
            obj.rent.filetype = line.rent.invoice.filetype;
            obj.rent.filename = line.rent.invoice.filename;
            obj.rent.filesize = line.rent.invoice.filesize;
            obj.rent.base64 = line.rent.invoice.base64;
            obj.rent.created_by = this.user.user_id;
            obj.rent.last_updated_by = this.user.user_id;
            obj.rent.type = 'RENT';
          } else {
            obj.rent = '';
          }
          obj.from_date = line.from ? this._formatService.parseDate(line.from) : '';
          obj.till_date = line.till ? this._formatService.parseDate(line.till) : '';
          obj.location = line.location || '';
          obj.shipping_cost = this._formatService.convertNumber(line.shipping_cost);
          obj.assemble_cost = this._formatService.convertNumber(line.assemble_cost);
          obj.rental_cost = this._formatService.convertNumber(line.rental_cost);
          obj.hostess_cost = this._formatService.convertNumber(line.hostess_cost);
          obj.agent_cost = this._formatService.convertNumber(line.agent_cost);
          obj.people_cost = obj.hostess_cost + obj.agent_cost;
          obj.other_cost = line.other_cost ? this._formatService.convertNumber(line.other_cost) : 0;
          obj.justification = line.justification ? line.justification : '';
          obj.creation_date = this._appService.today(0);
          obj.created_by = this.user.user_id;
          obj.last_updated_date = this._appService.today(0);
          obj.last_updated_by = this.user.user_id;
          if (this.editBooking) {
            obj.reserve_line_id = line.reserve_line_id;
            obj.reserve_hdr_id = line.reserve_hdr_id;
            if (line.operation_code) {
              obj.operation_code = line.operation_code;
            } else {
              if (line.reserve_line_id) {
                obj.operation_code = 'UPDATE';
              } else {
                obj.operation_code = 'CREATE';
              }
            }
          }
          tmpLines.push(obj);
        }
      }
    }

    if (this.closeBooking && tmpLines.length === 0) {
      this._appService.notify({ status: 1, msg: 'Minimum one line is required in booking details' });
      this.closeBooking = false;
      return;
    }

    this.closeBooking = false;
    req.lines = tmpLines;
    this.pageDim = true;
    let type;
    if (this.editBooking) {
      type = 'PUT';
    } else {
      type = 'POST';
    }

    this._httpService.httpRequest(type, endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: bookStand()' });
      } else if (data.status === 0) {
        this._appService.bookingStatus = data.status;
        this._appService.bookingMsg = data.msg;
        this._router.navigate(['events/stands']);
      } else {
        this._appService.notify({ status: data.status, msg: data.msg });
      }
    });
  }

  calculateTotals() {
    if (this.bookingLines && this.bookingLines.length > 0) {
      let shippingCost = 0, assembleCost = 0, rentalCost = 0, otherCost = 0, hostessCost = 0, agentCost = 0;
      for (let i = 0; i < this.bookingLines.length; i++) {
        let line = this.bookingLines[i];
        if (line.operation_code !== 'DELETE') {
          shippingCost += line.shipping_cost ? this._formatService.convertNumber(line.shipping_cost) : 0;
          assembleCost += line.assemble_cost ? this._formatService.convertNumber(line.assemble_cost) : 0;
          rentalCost += line.rental_cost ? this._formatService.convertNumber(line.rental_cost) : 0;
          hostessCost += line.hostess_cost ? this._formatService.convertNumber(line.hostess_cost) : 0;
          agentCost += line.agent_cost ? this._formatService.convertNumber(line.agent_cost) : 0;
          otherCost += line.other_cost ? this._formatService.convertNumber(line.other_cost) : 0;
        }
      }

      let total = shippingCost + assembleCost + rentalCost + hostessCost + agentCost + otherCost;
      this.shippingCost = this._formatService.formatNumber(shippingCost);
      this.assembleCost = this._formatService.formatNumber(assembleCost);
      this.rentalCost = this._formatService.formatNumber(rentalCost);
      this.hostessCost = this._formatService.formatNumber(hostessCost);
      this.agentCost = this._formatService.formatNumber(agentCost);
      this.otherCost = this._formatService.formatNumber(otherCost);
      this.totalCost = this._formatService.formatNumber(total);
    }
  }

  clearAddInvoice() {
    this.assembleSupplier = null;
    this.assembleinvoice = {};
    this.rentSupplier = null;
    this.rentinvoice = {};
    this.assembleSup = null;
    this.rentSup = null;
    this.addAttachments = false;
    this.justification = null;
  }

  closeDialog() {
    this.wfDialog = false;
    this.focuscomment = true;
    this.comment = null;
  }

  downloadFile(isAssemble) {
    try {
      let data, fileType, filename;
      if (isAssemble) {
        data = this.assembleinvoice.base64;
        fileType = this.assembleinvoice.filetype;
        filename = this.assembleinvoice.filename;
      } else {
        data = this.rentinvoice.base64;
        fileType = this.rentinvoice.filetype;
        filename = this.rentinvoice.filename;
      }
      let blobFile = this._formatService.base64ToBlob(data);
      if (this._appService.isIE()) {
        let builder = new MSBlobBuilder();
        builder.append(blobFile);
        let blob = builder.getBlob(fileType);
        window.navigator.msSaveBlob(blob, filename);
      } else if (blobFile) {
        let a = document.createElement('a');
        document.body.appendChild(a);
        a.style.display = 'none';
        let url = this._window.URL.createObjectURL(blobFile);
        a.href = url;
        a.download = filename;
        a.click();
        this._window.URL.revokeObjectURL(url);
      }
    } catch (e) {
      this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
    }
  }

  formatData(data) {
    this.bookingFrom = this._formatService.formatDate(data.from_date);
    this.availableFrom = this._formatService.formatDate(data.till_date);
    this.finalLocation = data.final_location;
    this.bookingStatus = data.status;
    this.purpose = data.description;
    this.approvalStatus = data.approval_status;
    this.approverId = data.approver_id;
    this.selectedStand = data.stand_id;
    this.reservationId = data.reserve_hdr_id;

    if (data.status === 'Open') {
      new FooPicker({
        id: 'from-date',
        dateFormat: this.format
      });

      new FooPicker({
        id: 'till-date',
        dateFormat: this.format
      });
    }

    if (data.lines && data.lines.length > 0) {
      this.bookingLines = [];
      for (let i = 0; i < data.lines.length; i++) {
        let line: any = {};
        line.id = i + 1;
        line.location = data.lines[i].location;
        line.from = this._formatService.formatDate(data.lines[i].from_date);
        line.till = this._formatService.formatDate(data.lines[i].till_date);
        line.shipping_cost = '' + this._formatService.formatNumberInput(data.lines[i].shipping_cost);
        line.assemble_cost = '' + this._formatService.formatNumberInput(data.lines[i].assemble_cost);
        if (data.lines[i].rental_cost) {
          line.rental_cost = '' + this._formatService.formatNumberInput(data.lines[i].rental_cost);
        }
        if (data.lines[i].people_cost) {
          line.people_cost = '' + this._formatService.formatNumberInput(data.lines[i].people_cost);
        }
        if (data.lines[i].hostess_cost) {
          line.hostess_cost = '' + this._formatService.formatNumberInput(data.lines[i].hostess_cost);
        }
        if (data.lines[i].agent_cost) {
          line.agent_cost = '' + this._formatService.formatNumberInput(data.lines[i].agent_cost);
        }
        if (data.lines[i].other_cost) {
          line.other_cost = '' + this._formatService.formatNumberInput(data.lines[i].other_cost);
        }
        line.justification = data.lines[i].justification;
        line.reserve_line_id = data.lines[i].reserve_line_id;
        line.reserve_hdr_id = data.lines[i].reserve_hdr_id;
        line.docs_count = data.lines[i].docs_count;
        this.bookingLines.push(line);
      }
      this.calculateTotals();
      // addPickers();
    }

  }

  loadLineDocs(l) {
    const endPoint = `/events/stands/linedocs/${l.reserve_hdr_id}/${l.reserve_line_id}/`;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadLineDocs()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          if (data && data.length > 0) {
            for (let i = 0; i < data.length; i++) {
              let file: any = {};
              file.filename = data[i].filename;
              file.filesize = data[i].filesize;
              file.filetype = data[i].filetype;
              file.base64 = data[i].filedata;
              if (data[i].type === 'ASSEMBLE') {
                this.assembleinvoice = file;
                this.assembleSup = data[i].supplier_id;
              } else {
                this.rentinvoice = file;
                this.rentSup = data[i].supplier_id;
              }
            }
          }
          this.pageDim = false;
          this.addAttachments = true;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadReservation() {
    const endPoint = `/events/reservation/${this.reservationId}/`;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadReservation()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.bookingDetails = data;
          this.formatData(data);
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadStands() {
    const endPoint = '/events/stands/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadStands()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.stands = data.stands;
          this.reservations = data.reservations;
          if (this._appService.stand_id) {
            let index = data.stands.map(x => x.stand_id).indexOf(this._appService.stand_id);
            this.selectedStand = this._appService.stand_id;
            this.fromStands = true;
            if (index !== -1) {
              setTimeout(() => {
                jQuery('#stand-name').val(data.stands[index].stand_name);
              }, 100);
            }
            this._appService.stand_id = null;
            this.onStandSelection();
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadSuppliers() {
    const endPoint = '/supplier/vendorlov/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: loadSuppliers()' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.suppliers = data;
      }
    });
  }

  onCostChange(l) {
    let index;
    if (this.bookingLines && this.bookingLines.length > 0) {
      index = this.bookingLines.indexOf(l);
    }

    this.amountAlert = false;
    if (index !== -1) {
      this.bookingLines[index].shipping_cost = this.validateCost(l.shipping_cost);
      if (!this.amountAlert) {
        this.bookingLines[index].assemble_cost = this.validateCost(l.assemble_cost);
      }
      if (!this.amountAlert) {
        this.bookingLines[index].rental_cost = this.validateCost(l.rental_cost);
      }
      if (!this.amountAlert) {
        this.bookingLines[index].hostess_cost = this.validateCost(l.hostess_cost);
      }
      if (!this.amountAlert) {
        this.bookingLines[index].other_cost = this.validateCost(l.other_cost);
      }
      if (!this.amountAlert) {
        this.bookingLines[index].agent_cost = this.validateCost(l.agent_cost);
      }

      this.calculateTotals();
    }
  }

  onStandNameChange() {
    this.focusselectedStand = false;
  }

  onStandSelection() {
    let i, bookings = [], disabled = [], dateFrom, to, dateArr, fromDate, toDate, days;
    let date;
    if (this.reservations && this.reservations.length) {
      for (i = 0; i < this.reservations.length; i++) {
        if (this.reservations[i].stand_id === parseInt(this.selectedStand)) {
          if (this.editBooking) {
            if (this.reservations[i].reserve_hdr_id !== this.reservationId) {
              bookings.push(this.reservations[i]);
            }
          } else {
            bookings.push(this.reservations[i]);
          }
        }
      }

      for (i = 0; i < bookings.length; i++) {
        dateFrom = bookings[i].from_date;
        to = bookings[i].till_date;

        dateArr = dateFrom.split('-');
        dateArr[1] = dateArr[1][0] + dateArr[1].substr(1, dateArr[1].length).toLowerCase();
        fromDate = new Date();
        fromDate.setDate(dateArr[0]);
        fromDate.setMonth(this._formatService.monthNumber(dateArr[1]));
        fromDate.setYear(dateArr[2]);

        dateArr = to.split('-');
        dateArr[1] = dateArr[1][0] + dateArr[1].substr(1, dateArr[1].length).toLowerCase();
        toDate = new Date();
        toDate.setDate(dateArr[0]);
        toDate.setMonth(this._formatService.monthNumber(dateArr[1]));
        toDate.setYear(dateArr[2]);

        days = Math.round((toDate - fromDate) / (1000 * 60 * 60 * 24));
        disabled.push(this._formatService.formatDate(bookings[i].from_date));
        for (let k = 0; k < days; k++) {
          fromDate.setDate(fromDate.getDate() + 1);
          date = fromDate.getDate() + '-' + this._formatService.getMonth(fromDate.getMonth()) + '-' + fromDate.getFullYear();
          disabled.push(this._formatService.formatDate(date));
        }
      }
    }

    this.addPickers(disabled);
  }

  removeLine(line?) {
    if (line) {
      this.selectedLine = line;
      this.showDialog = true;
    } else {
      let index = this.bookingLines.map(x => x.id).indexOf(this.selectedLine.id);
      if (index !== -1) {
        this.bookingLines[index].operation_code = 'DELETE';
      }
      this.showDialog = false;
    }
    this.calculateTotals();
  }

  validateBookingDate() {
    if (!this.bookingFrom || !this.availableFrom) {
      return;
    }
    if (!this.selectedStand) {
      return;
    }
    let endPoint = '/events/stands/validate/', req: any = {};
    req.from_date = this._formatService.parseDate(this.bookingFrom);
    req.to_date = this._formatService.parseDate(this.availableFrom);
    req.stand_id = parseInt(this.selectedStand);
    req.reserve_hdr_id = this.reservationId || -1;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: validateBookingDate()' });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
        this.bookingFrom = null;
        this.availableFrom = null;
      }
    });
  }

  validateCost(cost) {
    if (parseFloat(cost) >= 0) {
      if (!this._formatService.validatePattern(cost)) {
        cost = null;
        this.amountAlert = true;
      }
    } else {
      cost = null;
    }

    let msg;
    if (this.amountAlert) {
      if (this.user.number_format) {
        msg = 'Please enter amounts in ' + this.user.number_format + ' format';
      } else {
        msg = 'Please enter valid amounts';
      }

      this._appService.notify({ status: 1, msg });
      return null;
    }
    return cost;
  }

  validateStand() {
    let id = parseInt(this.selectedStand);
    let index = this.stands.map(x => x.stand_id).indexOf(id);
    return index !== -1;

  }

  wfAction(action?) {
    if (action) {
      this.userAction = action;
      this.wfDialog = true;
    } else {
      if (!this.comment) {
        this.focuscomment = false;
        return;
      }
      let req: any = {}, endPoint = '/users/workflow/';
      req.item_key = this.wfItemKey;
      req.result = action === 'A' ? 'APPROVED' : 'REJECTED';
      req.type = this.wfType;
      req.comment = this.comment;
      req.login_user_name = this.wfUsername;
      this.closeDialog();
      this.pageDim = true;
      this._httpService.httpRequest('POST', endPoint, req, (data) => {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: wfAction()' });
        } else {
          if (data.status === 0) {
            this.wfActions = false;
            this._router.navigate(['notifications']);
          }
          this._appService.notify({ status: data.status, msg: data.msg });
        }
      });
    }
  }
}
