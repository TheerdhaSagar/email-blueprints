import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { Subscription } from 'rxjs';
import { TemplateComponent } from '../../template/template.component';
import { APIError } from '../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-events-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class EventCreationComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _sce: DomSanitizer;
  private _router: Router;
  private _window: any;

  actions: { name: string; label: string }[];
  address_flag: any;
  agency_confirmation: any;
  agency_id: any;
  compenso_hostess: any;
  copyEvent: any;
  currency: any;
  customer_email: any;
  customer_name: any;
  customer_phone: any;
  customers: any;
  dateChanged: boolean;
  dateFormatExample: any;
  dateFormats: any;
  deleteGift: any;
  deleteGiftDialog: any;
  deletedGifts: any[];
  deletedObjectives: any[];
  desc: boolean;
  editCustomer: boolean;
  editData: any;
  editShipTo: boolean;
  eventDate: any;
  eventId: any;
  eventName: any;
  eventShiptoId: any;
  eventbillacAddress: any;
  eventstatus: string;
  focus: boolean;
  focusCompensoHostess: boolean;
  focusCustomer: boolean;
  focusDate: boolean;
  focusEmail: boolean;
  focusEvent: boolean;
  focusHostess: boolean;
  fromstate: any;
  focusStatus: any;
  format: any;
  gift: any;
  giftDialog: boolean;
  giftObjectives: any[];
  hideCustomer: boolean;
  hostess: any[];
  hostessname: any;
  isEdit: any;
  mailid: any;
  no_format: any;
  not_selectedGifts: any[];
  not_selectedObjectives: any[];
  objectiveDialog: boolean;
  objective: any;
  objectives: any[];
  orgChange: any;
  org_id: any;
  parent: TemplateComponent;
  phoneno: any;
  predicate: string;
  requiredCustomer: any;
  roles: any;
  selectedGiftObjectives: any[];
  selectedObjectives: any[];
  selectedShipTo: any;
  shippingAddress: any;
  shipto: any;
  showActions: any;
  showDelete: boolean;
  showPicker: boolean;
  showSpinner: boolean;
  status: any;
  subOrgChange: Subscription;
  tmpObjectives: any[];
  toggleFilter: (e?) => void;
  update_agency: any;
  user: any;
  userDateFormat: any;

  constructor(
    appService: AppService,
    cacheService: CacheService,
    dataService: DataService,
    formatService: FormatService,
    httpService: HttpService,
    location: Location,
    sce: DomSanitizer,
    router: Router,
    parent: TemplateComponent
  ) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._sce = sce;
    this._router = router;
    this._window = window;

    this.parent = parent;

    this.actions = [
      { name: 'Event Summary', label: 'events/summary' },
      { name: 'Hostess Report', label: 'events/hostess/report' },
    ];
    this.address_flag = null;
    this.agency_confirmation = null;
    this.agency_id = null;
    this.compenso_hostess = null;
    this.copyEvent = this._appService.copyEvent;
    this.customer_email = null;
    this.customer_name = null;
    this.customer_phone = null;
    this.customers = [];
    this.dateChanged = false;
    this.deletedGifts = [];
    this.deletedObjectives = [];
    this.desc = false;
    this.editCustomer = false;
    this.editData = {};
    this.editShipTo = false;
    this.eventDate = null;
    this.eventId = this._appService.eventid;
    this.eventName = null;
    this.eventShiptoId = null;
    this.eventbillacAddress = null;
    this.eventstatus = 'Y';
    this.focus = false;
    this.focusCustomer = true;
    this.focusEmail = false;
    this.focusHostess = true;
    this.fromstate = null;
    this.focusStatus = null;
    this.format = null;
    this.giftDialog = false;
    this.giftObjectives = [];
    this.hideCustomer = true;
    this.hostessname = null;
    this.isEdit = this._appService.eventEdit;
    this.mailid = null;
    this.no_format = null;
    this.not_selectedGifts = [];
    this.not_selectedObjectives = [];
    this.not_selectedObjectives = [];
    this.objectiveDialog = false;
    this.objectives = [];
    this.orgChange = null;
    this.org_id = null;
    this.phoneno = null;
    this.predicate = 'objective_id';
    this.requiredCustomer = null;
    this.roles = this._dataService.roles;
    this.selectedGiftObjectives = [];
    this.selectedObjectives = [];
    this.selectedShipTo = '';
    this.shippingAddress = '';
    this.showDelete = false;
    this.showPicker = false;
    this.showSpinner = false;
    this.tmpObjectives = [];
    this.toggleFilter = this._appService.toggleFilter();
    this.update_agency = null;
    this.user = null;

    /* app helpers */
    this._appService.copyEvent = '';
    this._appService.eventEdit = '';
    this._appService.eventid = '';
    this._appService.updatemsg = '';
    this._appService.updatestatus = '';
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', {
      page: this._location.path(),
    });

    if (!this.roles.isHostess) {
      this.actions.push({
        name: 'View Report',
        label: 'events/reports/hostess',
      });
    }
    if (this.roles.isAdmin || this.roles.isAgent) {
      this.actions.push({
        name: 'Ambassador Visits',
        label: 'events/ambassador/summary',
      });
    }
    if (!this.roles.isAgency) {
      this.actions.push({
        name: 'View Objectives',
        label: 'events/objectives/summary',
      });
      this.actions.push({
        name: 'Create Objective',
        label: 'events/objectives/manage',
      });
    }

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        if (
          this._dataService.fromState &&
          this._dataService.fromState === '/events/hostess/report'
        ) {
          this.fromstate = 'hostessreport';
        }
        this.user = data;
        this.format = this.user.date_format
          ? this.user.date_format
          : 'dd-MMM-yyyy';
        this.toggleFilter = this._appService.toggleFilter();
        this.userDateFormat = this.user.date_format || 'dd-MMM-yyyy';
        this.eventDate = this._formatService.formatDate(
          this._appService.today(0)
        );

        this.loadDateFormats();

        if (this.user.number_format) {
          this.no_format = this.user.number_format;
        } else {
          this.no_format = '999,999.99';
        }
        if (!this.isEdit && !this.copyEvent) {
          this.showPicker = true;
          setTimeout(() => {
            new FooPicker({
              id: 'event-date',
              dateFormat: this.format,
            });
          });
        } else {
          this.showPicker = false;
        }

        this.showSpinner = true;
        this.loadObjectives();
        this.loadCurrency();
        this.loadHostess();

        if (!this.isEdit && !this.copyEvent) {
          this.loadCustomers();
        }
      }

      this.subOrgChange = this._appService.subscribeOrgChange(() => {
        if (this.orgChange) {
          this.orgChange = !this.orgChange;
          return;
        }
        if (
          this.editData &&
          this.editData.report_count > 0 &&
          !this.copyEvent
        ) {
          return;
        }
        this.customers = '';
        this.focusEmail = false;
        this.selectedShipTo = '';
        this.deleteCustomerObjectives(
          this.objectives,
          this.selectedObjectives,
          this.deletedObjectives
        );
        this.deleteCustomerObjectives(
          this.giftObjectives,
          this.selectedGiftObjectives,
          this.deletedGifts
        );
        this.deleteDuplicateTargets();
        this.deleteDuplicateGifts();
        this.loadCustomers();
        this.requiredCustomer = '';
        this.focusCustomer = true;
        this.shippingAddress = '';
        this.customer_name = '';
        this.hideCustomer = true;
        this.editShipTo = false;
      });
    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addGifts() {
    this.focus = false;
    if (this.isEdit) {
      this.selectedGiftObjectives.push({
        focus: false,
        operation_code: 'CREATE',
        add_new_gift: true,
        objective_id: '',
        objective_name: '',
        vouchers: '',
        value: '',
        f_value: '',
        currency: 'EUR',
      });
    } else {
      this.selectedGiftObjectives.push({
        focus: false,
        add_new_gift: true,
        objective_id: '',
        objective_name: '',
        vouchers: '',
        value: '',
        f_value: '',
        currency: 'EUR',
      });
    }
  }

  addObjectives() {
    this.focus = false;
    if (this.isEdit) {
      this.selectedObjectives.push({
        focus: false,
        operation_code: 'CREATE',
        add_new_objective: true,
        objective_name: '',
        target_qty: null,
        event_objective_id: '',
      });
    } else {
      this.selectedObjectives.push({
        focus: false,
        add_new_objective: true,
        objective_name: '',
        target_qty: null,
        event_objective_id: '',
      });
    }
  }

  deleteCustomerObjectives(data, selectedData, deletedData) {
    let customer_id = '',
      site_id = '',
      index,
      i,
      obj;
    if (this.selectedShipTo) {
      customer_id = this.selectedShipTo.cust_account_id;
      site_id = this.selectedShipTo.party_site_id;
    }
    if (data.length > 0 && selectedData.length > 0) {
      for (i = 0; i < data.length; i++) {
        if (
          data[i].cust_account_id &&
          data[i].cust_site_id &&
          (!customer_id ||
            !site_id ||
            data[i].cust_account_id !== customer_id ||
            data[i].cust_site_id !== site_id)
        ) {
          index = selectedData
            .map((x) => x.objective_name)
            .indexOf(data[i].objective_name);
          if (index !== -1) {
            if (selectedData[index].event_id) {
              obj = { ...selectedData[index] };
              deletedData.push(obj);
            }
            selectedData.splice(index, 1);
          }
        }
      }
    }
  }

  // To delete duplicate gifts
  deleteDuplicateGifts() {
    let i, j, flag, customer_id, site_id;
    this.not_selectedGifts = [];
    if (this.selectedShipTo) {
      customer_id = this.selectedShipTo.cust_account_id;
      site_id = this.selectedShipTo.party_site_id;
    }
    for (i = 0; i < this.giftObjectives.length; i++) {
      flag = 0;
      for (j = 0; j < this.selectedGiftObjectives.length; j++) {
        if (
          parseInt(this.giftObjectives[i].objective_id) ===
          parseInt(this.selectedGiftObjectives[j].objective_id)
        ) {
          flag = 1;
          break;
        }
      }

      if (!flag && customer_id && site_id) {
        if (
          this.giftObjectives[i].cust_account_id &&
          this.giftObjectives[i].cust_account_id !== customer_id &&
          this.giftObjectives[i].cust_site_id &&
          this.giftObjectives[i].cust_site_id !== site_id
        ) {
          flag = 1;
        }
      } else if (
        !flag &&
        this.giftObjectives[i].cust_account_id &&
        this.giftObjectives[i].cust_site_id
      ) {
        flag = 1;
      }

      if (!flag) {
        this.not_selectedGifts.push(this.giftObjectives[i]);
      }
    }
  }

  // To delete duplicate targets
  deleteDuplicateTargets() {
    let i, j, flag, customer_id, site_id;
    this.not_selectedObjectives = [];
    if (this.selectedShipTo) {
      customer_id = this.selectedShipTo.cust_account_id;
      site_id = this.selectedShipTo.party_site_id;
    }
    for (i = 0; i < this.objectives.length; i++) {
      flag = 0;
      for (j = 0; j < this.selectedObjectives.length; j++) {
        if (
          parseInt(this.objectives[i].objective_id) ===
          parseInt(this.selectedObjectives[j].event_objective_id)
        ) {
          flag = 1;
          break;
        }
      }

      if (!flag && customer_id && site_id) {
        if (
          this.objectives[i].cust_account_id &&
          this.objectives[i].cust_account_id !== customer_id &&
          this.objectives[i].cust_site_id &&
          this.objectives[i].cust_site_id !== site_id
        ) {
          flag = 1;
        }
      } else if (
        !flag &&
        this.objectives[i].cust_account_id &&
        this.objectives[i].cust_site_id
      ) {
        flag = 1;
      }
      if (!flag) {
        this.not_selectedObjectives.push(this.objectives[i]);
      }
    }
  }

  deleteGifts(gift?) {
    if (gift !== '' && gift !== undefined) {
      this.gift = gift;
      this.giftDialog = true;
    } else {
      this.giftDialog = false;
      let obj;
      obj = { ...this.selectedGiftObjectives.splice(this.gift, 1)[0] };
      this.deletedGifts.push(obj);
      this.deleteDuplicateGifts();
      this.gift = '';
    }
  }

  deleteObjective(objective?) {
    if (objective !== '' && objective !== undefined) {
      this.objective = objective;
      this.objectiveDialog = true;
    } else {
      let obj;
      obj = { ...this.selectedObjectives.splice(this.objective, 1)[0] };
      this.deletedObjectives.push(obj);
      this.objectiveDialog = false;
      this.deleteDuplicateTargets();
      this.objective = '';
    }
  }

  editAddress() {
    this.hideCustomer = true;
    this.editShipTo = true;
    if (
      (this.isEdit || this.copyEvent) &&
      (this.shipto === undefined || this.shipto === '')
    ) {
      this.address_flag = true;
      this.loadCustomerDetails();
    }
  }

  filterObjectives() {
    let tmpObjectives = [],
      count,
      i,
      obj,
      customer_id,
      site_id;
    this.deleteCustomerObjectives(
      this.objectives,
      this.selectedObjectives,
      this.deletedObjectives
    );
    this.deleteCustomerObjectives(
      this.giftObjectives,
      this.selectedGiftObjectives,
      this.deletedGifts
    );
    customer_id = this.selectedShipTo.cust_account_id;
    site_id = this.selectedShipTo.party_site_id;
    if (this.objectives && this.objectives.length) {
      count = this.objectives.length;
      tmpObjectives = this.selectedObjectives;
      for (i = 0; i < count; i++) {
        obj = {};
        if (
          this.objectives[i].cust_account_id === customer_id &&
          this.objectives[i].cust_site_id === site_id
        ) {
          obj = this.objectives[i];
          obj.target_qty = this.objectives[i].target_qty;
          if (this.isEdit) {
            delete obj.event_id;
            obj.operation_code = 'CREATE';
          }
          tmpObjectives.push(obj);
        }
      }

      this.selectedObjectives = tmpObjectives;
      this.deleteDuplicateTargets();
    }

    if (this.giftObjectives && this.giftObjectives.length) {
      count = this.giftObjectives.length;
      tmpObjectives = this.selectedGiftObjectives;
      for (i = 0; i < count; i++) {
        obj = {};
        if (
          this.giftObjectives[i].cust_account_id === customer_id &&
          this.giftObjectives[i].cust_site_id === site_id
        ) {
          obj = this.giftObjectives[i];
          obj.value = this.giftObjectives[i].target_qty;
          obj.f_value = this.giftObjectives[i].target_qty
            ? this._formatService.formatNumber(
                this.giftObjectives[i].target_qty
              )
            : '';
          if (this.isEdit) {
            delete obj.event_id;
            obj.operation_code = 'CREATE';
          }
          tmpObjectives.push(obj);
        }
      }
      this.selectedGiftObjectives = tmpObjectives;
      this.deleteDuplicateGifts();
    }
  }

  formatAddress(data) {
    let addressOne = data.billacc_address + '<br/>',
      addressTwo;
    if (data.hasOwnProperty('billing_address')) {
      addressTwo = data.billing_address;
    } else {
      addressTwo = data.shipping_address;
    }
    return this._sce.bypassSecurityTrustHtml(addressOne + addressTwo);
  }

  getIndex(data, key, value) {
    return data.map((x) => parseInt(x[key])).indexOf(value);
  }

  getShippingAddress(data) {
    this.shipto = data.shipto;
    let i, shipto;
    if (data.shipto.length === 0) {
      this._appService.notify({
        msg: 'Selected customer has no shipto. Please select another customer',
        status: 1,
      });
      this.requiredCustomer = '';
      this.focusCustomer = true;
      this.shippingAddress = '';
      this.customer_name = '';
      this.showSpinner = false;
      this.hideCustomer = true;
      this.editShipTo = false;
      return;
    }
    for (i = 0; i < data.shipto.length; i++) {
      if (data.shipto[i].site_primary_flag === 'Y') {
        shipto = data.shipto[i];
        break;
      }
    }

    if (!shipto && i > 0) {
      this.selectedShipTo = data.shipto[0];
    } else {
      this.selectedShipTo = shipto;
    }
    if (!this.selectedShipTo.billacc_address) {
      this._appService.notify({
        msg: 'Selected customer has no billacc_address. Please select another customer',
        status: 1,
      });
      this.requiredCustomer = '';
      this.focusCustomer = true;
      this.shippingAddress = '';
      this.customer_name = '';
      this.hideCustomer = true;
      this.showSpinner = false;
      this.editShipTo = false;
      return;
    }
    this.eventShiptoId = this.selectedShipTo.billacc_address;
    jQuery('#shipto').val(this.eventShiptoId);
    this.eventbillacAddress = this.selectedShipTo.billacc_address;
    this.shippingAddress = this.formatAddress(this.selectedShipTo);
    this.editCustomer = false;
    this.showSpinner = false;
    if (!this.address_flag) {
      this.filterObjectives();
    } else {
      this.address_flag = !this.address_flag;
    }
  }

  hostessDetails() {
    let index1 = this.hostess
      .map((x: any) => parseInt(x.user_id))
      .indexOf(parseInt(this.hostessname));
    if (index1 !== -1) {
      this.mailid = this.hostess[index1].email_address;
      this.phoneno = this.hostess[index1].phone;
    } else {
      this.focusHostess = false;
      this.hostessname = '';
    }
  }

  loadCurrency() {
    let endPoint = '/utilities/currencies/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadCurrency',
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.currency = data;
      }
    });
  }

  loadCustomers() {
    let endPoint, i, index;
    if (this._cacheService.customers) {
      this.customers = this._cacheService.getCustomers();
      if (this.isEdit) {
        index = this.customers
          .map((x) => x.cust_account_id)
          .indexOf(this.requiredCustomer);
        if (index === -1) {
          this.editCustomer = true;
        }
      }
    } else {
      if (this.roles.isAgency) {
        endPoint = '/customer/list/1/' + this._cacheService.getOrgId() + '/';
      } else {
        endPoint =
          '/customer/list/' +
          this.user.user_id +
          '/' +
          this._cacheService.getOrgId() +
          '/';
      }
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        try {
          if (data === null || data === undefined) {
            this.showSpinner = false;
            this._appService.notify({
              status: 1,
              msg: 'Server Error - loadCustomers()',
            });
          } else if (data.status === 1) {
            this.showSpinner = false;
            this._appService.notify(new APIError(data.msg));
          } else if (data.length > 0) {
            for (i = 0; i < data.length; i++) {
              data[i].customer_name =
                data[i].customer_name + ',' + data[i].account_number;
            }
            this.customers = data;
            this._cacheService.setCustomers(data);
            if (this.isEdit) {
              index = this.customers
                .map((x) => x.cust_account_id)
                .indexOf(this.requiredCustomer);
              if (index === -1) {
                this.editCustomer = true;
              }
            }
          }
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>',
          });
        }
      });
    }
  }

  loadCustomerDetails(changed?) {
    this.focusEmail = false;
    if (!this.requiredCustomer) {
      return;
    }
    if (!this.address_flag) {
      this.hideCustomer = false;
      this.editShipTo = false;
    }
    this.showSpinner = true;
    let org = this._cacheService.getOrgId(),
      index1,
      endPoint,
      language;
    index1 = this.customers
      .map((x) => parseInt(x.cust_account_id))
      .indexOf(parseInt(this.requiredCustomer));
    if (index1 !== -1) {
      this.customer_name = this.customers[index1].customer_name;
    } else {
      this.focusCustomer = false;
      this.requiredCustomer = '';
      this.showSpinner = false;
      this.customer_name = '';
      this.customer_email = '';
      this.customer_phone = '';
      this.shippingAddress = '';
      this.editShipTo = false;
    }
    if (!this.requiredCustomer) {
      return;
    }
    if (changed) {
      this.updateCustomerDetails();
    }
    endPoint =
      '/customer/id/' +
      this.requiredCustomer +
      '/' +
      this.user.user_id +
      '/' +
      org +
      '/';
    if (this.user.ui_language) {
      switch (this.user.ui_language) {
        case 'IT':
          language = 'I';
          break;
        case 'DE':
          language = 'D';
          break;
        case 'FR':
          language = 'F';
          break;
        case 'EN':
          language = 'US';
          break;
      }
      endPoint += language + '/';
    }
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this.showSpinner = false;
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadCustomerDetails()',
          });
        } else if (data.status === 1) {
          this.showSpinner = false;
          this._appService.notify(new APIError(data.msg));
        } else {
          this.getShippingAddress(data);
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadDateFormats() {
    let endPoint = '/preferences/dateformat/',
      i;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this.showSpinner = false;
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadDateFormats() ',
          });
        } else if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
          this.showSpinner = false;
        } else {
          this.dateFormats = data;
          for (i = 0; i < this.dateFormats.length; i++) {
            if (this.userDateFormat === this.dateFormats[i].lookup_code) {
              this.dateFormatExample = this.dateFormats[i].meaning;
              break;
            }
          }
        }
      } catch (e) {
        this._appService.notify({
          msg: e.message,
          status: 1,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadEvent(event_id) {
    let index,
      endPoint = '/events/id/' + event_id + '/',
      i,
      gifts: any = {},
      objective: any = {};
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this.showSpinner = false;
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadEvent()',
          });
        } else {
          if (data.status === 1) {
            this._appService.notify({ msg: data.msg, status: data.status });
            this.showSpinner = false;
            return;
          }
          this.editData = data;
          this.compenso_hostess = data.compenso_hostess
            ? this._formatService.formatNumber(data.compenso_hostess)
            : '';
          this.update_agency = !!(
            !this.roles.isAgency ||
            (this.roles.isAgency && data.created_by === this.user.user_id)
          );
          this.agency_id = data.agency_id;
          if (
            (this.editData.report_count === 0 && this.update_agency) ||
            this.copyEvent
          ) {
            this.showPicker = true;
            setTimeout(() => {
              new FooPicker({
                id: 'event-date',
                dateFormat: this.format,
              });
            });
          } else {
            this.showPicker = false;
          }
          if (this.copyEvent) {
            this.eventName =
              'Copy of ' +
              data.event_name +
              ' - ' +
              this._formatService.getTimeStamp();
          } else {
            this.eventName = data.event_name;
          }
          this.org_id = data.org_id;
          this.agency_confirmation = this.copyEvent
            ? false
            : data.hostess_verified === 'Y';
          if (this._dataService.orgId !== data.org_id) {
            for (i = 0; i < this.user.organizations.length; i++) {
              if (data.org_id === this.user.organizations[i].organization_id) {
                this.orgChange = true;
                this.parent.changeOrg(this.user.organizations[i]);
                break;
              }
            }
          }
          this.selectedShipTo = {
            cust_account_id: data.cust_account_id,
            party_site_id: data.party_site_id,
            billacc_address: data.address_1,
            shipping_address: data.address_2,
            primary_salesrep_id: data.salesrep_id,
          };

          this.eventstatus = data.status;
          this.eventDate = this.copyEvent
            ? this._formatService.formatDate(this._appService.today(0))
            : this._formatService.formatDate(data.event_date);
          this.requiredCustomer = data.cust_account_id;
          this.hostessname = data.hostess_id;
          this.mailid = data.email_address;
          this.phoneno = data.phone;
          this.showDelete = data.report_count === 0;
          this.loadCustomers();
          setTimeout(() => {
            jQuery('#requiredcustomer').val(data.customer_name);
            jQuery('#shipto').val(data.address_1);
            this.customer_name = data.customer_name;
            this.customer_email = data.customer_email;
            this.customer_phone = data.customer_phone;
          }, 500);

          setTimeout(() => {
            jQuery('#hostessname').val(data.user_description);
          }, 500);

          this.eventShiptoId = data.address_1;
          this.shippingAddress = this._sce.bypassSecurityTrustHtml(
            data.address_1 + '<br/>' + data.address_2
          );
          this.selectedGiftObjectives = [];
          for (i = 0; i < data.gifts.length; i++) {
            if (this.copyEvent) {
              delete data.gifts[i].event_id;
              delete data.gifts[i].event_gift_id;
            }
            index = this.getIndex(
              this.giftObjectives,
              'objective_id',
              parseInt(data.gifts[i].objective_id)
            );
            if (
              (index !== -1 &&
                this.copyEvent &&
                this.giftObjectives[index].status === 'A') ||
              this.isEdit
            ) {
              gifts = this.giftObjectives[index] || {};
              gifts.objective_name = data.gifts[i].objective_name;
              gifts.value = data.gifts[i].value;
              gifts.f_value = this._formatService.formatNumber(
                data.gifts[i].value
              );
              gifts.vouchers = '';
              gifts.currency = data.gifts[i].currency;
              gifts.objective_id = data.gifts[i].objective_id;
              gifts.event_id = data.gifts[i].event_id;
              gifts.event_gift_id = data.gifts[i].event_gift_id;
              gifts.operation_code = 'UPDATE';
              this.selectedGiftObjectives.push(gifts);
              this.giftObjectives[index] = gifts;
            }
          }
          this.selectedObjectives = [];
          for (i = 0; i < data.objectives.length; i++) {
            objective = {};
            if (this.copyEvent) {
              delete data.objectives[i].event_id;
            }
            index = this.getIndex(
              this.objectives,
              'objective_id',
              parseInt(data.objectives[i].event_objective_id)
            );
            if (
              (index !== -1 &&
                this.copyEvent &&
                this.objectives[index].status === 'A') ||
              this.isEdit
            ) {
              objective = this.objectives[index] || {};
              objective.objective_name = data.objectives[i].objective_name;
              objective.target_qty = data.objectives[i].target_qty;
              objective.event_objective_id =
                data.objectives[i].event_objective_id;
              objective.event_id = data.objectives[i].event_id;
              objective.operation_code = 'UPDATE';
              this.selectedObjectives.push(objective);
              this.objectives[index] = objective;
            }
          }
          this.deleteDuplicateTargets();
          this.deleteDuplicateGifts();
        }
        this.showSpinner = false;
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadHostess() {
    const endPoint = '/users/hostess/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this.showSpinner = false;
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadHostess()',
        });
      } else if (data.status === 1) {
        this.showSpinner = false;
        this._appService.notify(new APIError(data.msg));
      } else {
        this.hostess = data;
      }
    });
  }

  loadObjectives() {
    const endPoint = '/events/objectives/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadObjectives()',
          });
        } else if (data.status === 1) {
          this._appService.notify({ status: data.status, msg: data.msg });
        } else {
          this.parseObjectives(data);
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  moveToSummary() {
    if (this.fromstate === 'hostessreport') {
      this._router.navigate(['events/hostess/report']);
    } else {
      this._router.navigate(['events/summary']);
    }
  }

  onCustomerNameBlur() {
    this.focusCustomer = false;
  }

  onHostessNameChange() {
    this.focusHostess = false;
  }

  onSave() {
    this.showSpinner = true;
    this.focus = false;
    let i,
      req: any = {},
      index1,
      objective_count = 0,
      gift_count = 0,
      lineData,
      endPoint = '/events/';
    req.org_id = this._dataService.orgId;
    req.agency_id = this.roles.isAgency ? this.user.user_id : '';
    req.hostess_verified = this.roles.isAgency
      ? this.agency_confirmation
        ? 'Y'
        : 'N'
      : '';
    if (this.eventDate) {
      req.event_date = this._formatService.parseDate(this.eventDate);
    } else {
      this.focusDate = false;
    }

    if (!this.eventstatus) {
      this.focusStatus = false;
    } else {
      req.status = this.eventstatus;
    }

    if (this.compenso_hostess) {
      req.compenso_hostess = this._formatService.parseNumber(
        this.compenso_hostess
      );
    } else {
      this.focusCompensoHostess = true;
    }

    if (!this.hostessname) {
      this.focusHostess = false;
    } else {
      this.hostessDetails();
      req.hostess_id = parseInt(this.hostessname);
    }

    if (this.eventName) {
      req.event_name = this.eventName;
    } else {
      this.focusEvent = false;
    }
    if (this.requiredCustomer !== '' && this.requiredCustomer !== undefined) {
      if (this.customers) {
        index1 = this.customers
          .map((x) => x.cust_account_id)
          .indexOf(parseInt(this.requiredCustomer));
        if (index1 === -1) {
          this.focusCustomer = false;
          this.requiredCustomer = '';
          this.hideCustomer = true;
          this.customer_email = '';
          this.customer_phone = '';
          this.shippingAddress = '';
          this.editShipTo = false;
          this.showSpinner = false;
          return;
        } else {
          this.customer_name = this.customers[index1].customer_name;
        }
      }
      req.cust_account_id = this.requiredCustomer;
      req.customer_name = this.customer_name;
      req.customer_email = this.customer_email || '';
      req.customer_phone = this.customer_phone || '';
      if (
        this.copyEvent &&
        (this.selectedShipTo === undefined || this.selectedShipTo === '')
      ) {
        req.address_2 = this.editData.address_2;
        req.address_1 = this.editData.address_1;
        req.party_site_id = this.editData.party_site_id;
        req.salesrep_id = this.editData.salesrep_id;
      } else {
        req.address_2 = this.selectedShipTo.shipping_address;
        req.address_1 = this.selectedShipTo.billacc_address;
        req.party_site_id = this.selectedShipTo.party_site_id;
        req.salesrep_id = this.selectedShipTo.primary_salesrep_id;
      }
    } else {
      this.focusCustomer = false;
      this.hideCustomer = true;
    }

    req.creation_date = this._appService.today(0);
    req.created_by = this.user.user_id;
    req.last_updated_date = this._appService.today(0);
    req.last_updated_by = this.user.user_id;
    req.hostess_name = jQuery('#hostessname').val();
    req.objectives = [];
    // let objective_count = 0;
    // let gift_count = 0;
    for (i = 0; i < this.selectedObjectives.length; i++) {
      if (
        !this.selectedObjectives[i].objective_name ||
        this.selectedObjectives[i].target_qty === null ||
        this.selectedObjectives[i].target_qty === undefined ||
        this.selectedObjectives[i].target_qty === ''
      ) {
        this.selectedObjectives[i].focus = true;
        if (!this.selectedObjectives[i].objective_name) {
          this.selectedObjectives[i].objective_name = '';
          this.selectedObjectives[i].objective_id = '';
          this.selectedObjectives[i].event_objective_id = '';
        }
        ++objective_count;
      }
    }

    for (i = 0; i < this.selectedGiftObjectives.length; i++) {
      if (
        !this.selectedGiftObjectives[i].objective_name ||
        !this.selectedGiftObjectives[i].value ||
        !this.selectedGiftObjectives[i].currency
      ) {
        this.selectedGiftObjectives[i].focus = true;
        if (!this.selectedGiftObjectives[i].objective_name) {
          this.selectedGiftObjectives[i].objective_name = '';
          this.selectedGiftObjectives[i].objective_id = '';
          this.selectedGiftObjectives[i].event_gift_id = '';
        }
        ++gift_count;
      }
    }

    if (gift_count > 0) {
      this._appService.notify({
        msg: 'Enter all inputs in Gift Vouchers',
        status: 1,
      });
    }

    if (objective_count > 0) {
      this._appService.notify({
        msg: 'Enter all inputs in objectives',
        status: 1,
      });
    }

    if (gift_count > 0 || objective_count > 0) {
      this.showSpinner = false;
      return;
    }

    for (i = 0; i < this.selectedObjectives.length; i++) {
      this.selectedObjectives[i].creation_date = this._appService.today(0);
      this.selectedObjectives[i].last_updated_date = this._appService.today(0);
      this.selectedObjectives[i].created_by = this.user.user_id;
      this.selectedObjectives[i].last_updated_by = this.user.user_id;
      req.objectives.push(this.selectedObjectives[i]);
    }

    req.gifts = [];

    for (i = 0; i < this.selectedGiftObjectives.length; i++) {
      lineData = this.selectedGiftObjectives[i];
      lineData.created_by = this.user.user_id;
      lineData.last_updated_by = this.user.user_id;
      lineData.creation_date = this._appService.today(0);
      lineData.last_updated_date = this._appService.today(0);
      lineData.vouchers = '';

      req.gifts.push(lineData);
    }

    if (
      !this.eventDate ||
      !this.requiredCustomer ||
      !this.eventName ||
      !this.eventstatus ||
      !this.hostessname ||
      !this.compenso_hostess
    ) {
      this.showSpinner = false;
      return false;
    }
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - onSave()' });
      } else if (data.status === 0) {
        if (this.copyEvent) {
          this._appService.updatestatus = 0;
          this._appService.updatemsg =
            'Event #' + this.editData.event_id + ' copied Successfully ';
        } else {
          this._appService.updatestatus = data.status;
          this._appService.updatemsg = data.msg;
        }
        this._appService.notify({
          status: this._appService.updatestatus,
          msg: this._appService.updatemsg,
        });
        this._router.navigate(['events/summary']);
        this._cacheService.setEventData(null);
      } else {
        this.status = data.status;
        this._appService.notify({ status: data.status, msg: data.msg });
      }
      this.showSpinner = false;
    });
  }

  onShipToChange() {
    this.editShipTo = false;
    this.hideCustomer = false;
    let shipTos = this.shipto,
      i;
    for (i = 0; i < shipTos.length; i++) {
      if (shipTos[i].party_site_id === parseInt(this.eventShiptoId)) {
        this.selectedShipTo = shipTos[i];
        this.shippingAddress = this.formatAddress(this.selectedShipTo);
        break;
      }
    }
  }

  onUpdate() {
    this.showSpinner = true;
    let i,
      req: any = {},
      index1,
      objective_count = 0,
      gift_count = 0,
      lineData,
      endPoint = '/events/';
    this.focus = false;
    if (this.editData.report_count) {
      req.org_id = this.org_id;
    } else {
      req.org_id = this._dataService.orgId;
    }
    req.agency_id = this.roles.isAgency
      ? this.user.user_id
      : this.agency_id || '';
    req.hostess_verified = this.roles.isAgency
      ? this.agency_confirmation
        ? 'Y'
        : 'N'
      : this.editData.hostess_verified;
    if (this.eventName) {
      req.event_name = this.eventName;
    } else {
      this.focusEvent = false;
    }

    if (this.eventDate) {
      req.event_date = this._formatService.parseDate(this.eventDate);
    } else {
      this.focusDate = false;
    }

    if (this.compenso_hostess) {
      req.compenso_hostess = this._formatService.parseNumber(
        this.compenso_hostess
      );
    } else {
      this.focusCompensoHostess = true;
    }

    if (!this.hostessname) {
      this.focusHostess = false;
    } else {
      this.hostessDetails();
      req.hostess_id = parseInt(this.hostessname);
    }
    req.hostess_name = jQuery('#hostessname').val();

    if (this.requiredCustomer) {
      if (this.customers && !this.editCustomer) {
        index1 = this.customers
          .map((x) => x.cust_account_id)
          .indexOf(parseInt(this.requiredCustomer));
        if (index1 === -1) {
          this.focusCustomer = false;
          this.requiredCustomer = '';
          this.showSpinner = false;
          this.customer_name = '';
          this.customer_email = '';
          this.customer_phone = '';
          this.shippingAddress = '';
          this.editShipTo = false;
        } else {
          this.customer_name = this.customers[index1].customer_name;
        }
      }
      req.cust_account_id = this.requiredCustomer;
      req.customer_name = this.customer_name;
      req.customer_email = this.customer_email || '';
      req.customer_phone = this.customer_phone || '';
      if (
        this.isEdit &&
        (this.selectedShipTo === undefined || this.selectedShipTo === '')
      ) {
        req.address_2 = this.editData.address_2;
        req.address_1 = this.editData.address_1;
        req.party_site_id = this.editData.party_site_id;
        req.salesrep_id = this.editData.salesrep_id;
      } else {
        req.address_2 = this.selectedShipTo.shipping_address;
        req.address_1 = this.selectedShipTo.billacc_address;
        req.party_site_id = this.selectedShipTo.party_site_id;
        req.salesrep_id = this.selectedShipTo.primary_salesrep_id;
      }
    } else {
      this.focusCustomer = false;
      this.hideCustomer = true;
    }

    req.event_id = this.editData.event_id;
    req.status = this.eventstatus;
    // req.creation_date = this._appService.today(0);
    // req.created_by = user.user_id;
    req.last_updated_date = this._appService.today(0);
    req.last_updated_by = this.user.user_id;
    req.objectives = [];
    req.gifts = [];

    // let objective_count = 0;
    // let gift_count = 0;

    for (i = 0; i < this.selectedObjectives.length; i++) {
      if (
        !this.selectedObjectives[i].objective_name ||
        this.selectedObjectives[i].target_qty === null ||
        this.selectedObjectives[i].target_qty === undefined ||
        this.selectedObjectives[i].target_qty === ''
      ) {
        this.selectedObjectives[i].focus = true;
        if (!this.selectedObjectives[i].objective_name) {
          this.selectedObjectives[i].objective_name = '';
          this.selectedObjectives[i].objective_id = '';
          this.selectedObjectives[i].event_objective_id = '';
        }
        ++objective_count;
      }
    }

    for (i = 0; i < this.selectedGiftObjectives.length; i++) {
      if (
        !this.selectedGiftObjectives[i].objective_name ||
        !this.selectedGiftObjectives[i].value ||
        !this.selectedGiftObjectives[i].currency
      ) {
        this.selectedGiftObjectives[i].focus = true;
        if (!this.selectedGiftObjectives[i].objective_name) {
          this.selectedGiftObjectives[i].objective_name = '';
          this.selectedGiftObjectives[i].objective_id = '';
          this.selectedGiftObjectives[i].event_gift_id = '';
        }
        ++gift_count;
      }
    }

    if (gift_count > 0) {
      this._appService.notify({
        msg: 'Enter all inputs in Gift Vouchers',
        status: 1,
      });
    }

    if (objective_count > 0) {
      this._appService.notify({
        msg: 'Enter all inputs in objectives',
        status: 1,
      });
    }

    if (gift_count > 0 || objective_count > 0) {
      this.showSpinner = false;
      return;
    }

    if (this.deletedGifts.length > 0) {
      for (i = 0; i < this.deletedGifts.length; i++) {
        if (this.deletedGifts[i].event_id) {
          this.deletedGifts[i].operation_code = 'DELETE';
          this.deletedGifts[i].last_updated_by = this.user.user_id;
          this.deletedGifts[i].last_updated_date = this._appService.today(0);
          this.deletedGifts[i].vouchers = '';
          req.gifts.push(this.deletedGifts[i]);
        }
      }
    }

    if (this.deletedObjectives.length > 0) {
      for (i = 0; i < this.deletedObjectives.length; i++) {
        if (this.deletedObjectives[i].event_id) {
          this.deletedObjectives[i].operation_code = 'DELETE';
          this.deletedObjectives[i].last_updated_by = this.user.user_id;
          this.deletedObjectives[i].last_updated_date =
            this._appService.today(0);
          req.objectives.push(this.deletedObjectives[i]);
        }
      }
    }
    for (i = 0; i < this.selectedObjectives.length; i++) {
      this.selectedObjectives[i].last_updated_by = this.user.user_id;
      this.selectedObjectives[i].last_updated_date = this._appService.today(0);
      if (!this.selectedObjectives[i].event_id) {
        this.selectedObjectives[i].operation_code = 'CREATE';
        this.selectedObjectives[i].created_by = this.user.user_id;
        this.selectedObjectives[i].creation_date = this._appService.today(0);
      }
      req.objectives.push(this.selectedObjectives[i]);
    }
    for (i = 0; i < this.selectedGiftObjectives.length; i++) {
      lineData = this.selectedGiftObjectives[i];
      if (!lineData.event_id) {
        lineData.creation_date = this._appService.today(0);
        lineData.created_by = this.user.user_id;
        lineData.operation_code = 'CREATE';
      }
      lineData.last_updated_by = this.user.user_id;
      lineData.vouchers = '';
      lineData.last_updated_date = this._appService.today(0);
      req.gifts.push(lineData);
    }

    if (
      !this.eventDate ||
      !this.eventName ||
      !this.requiredCustomer ||
      !this.hostessname ||
      !this.compenso_hostess
    ) {
      this.showSpinner = false;
      return false;
    }
    this._httpService.httpRequest('PUT', endPoint, req, (data) => {
      try {
        if (data === null || data === undefined) {
          // this.status = data.status;
          // this._appService.notify({ status: data.status, msg: data.msg });
          this._appService.notify({
            status: 1,
            msg: 'Server Error - onUpdate()',
          });
        } else {
          this.status = data.status;
          if (this.status === 0) {
            this._appService.updatestatus = data.status;
            this._appService.updatemsg =
              data.msg +
              ' ' +
              'for' +
              ' ' +
              'event #' +
              ' ' +
              this.editData.event_id;
            if (this.fromstate === 'hostessreport') {
              this._router.navigate(['events/hostess/report']);
            } else {
              this._router.navigate(['events/summary']);
            }
            this._appService.notify({
              status: this._appService.updatestatus,
              msg: this._appService.updatemsg,
            });
            this._cacheService.setEventData(null);
          } else {
            this._appService.notify({ status: data.status, msg: data.msg });
          }
        }
        this.showSpinner = false;
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  parseObjectives(data) {
    this.objectives = [];
    this.giftObjectives = [];
    this.selectedObjectives = [];
    this.selectedGiftObjectives = [];
    let obj, i;
    for (i = 0; i < data.length; i++) {
      obj = data[i];
      if (data[i].status === 'A' && data[i].type === 'QUANTITY') {
        obj.focus = false;
        obj.objective_name = data[i].objective_name;
        obj.target_qty = data[i].target_qty;
        obj.event_objective_id = data[i].objective_id;
        obj.cust_account_id = data[i].cust_account_id;
        obj.cust_site_id = data[i].cust_site_id;

        if (!this.isEdit && !this.copyEvent) {
          if (!obj.cust_account_id && !obj.cust_site_id) {
            this.selectedObjectives.push(obj);
          }
        }

        this.objectives.push(obj);
      } else if (data[i].status === 'A' && data[i].type === 'VALUE') {
        obj.focus = false;
        obj.objective_id = data[i].objective_id;
        obj.objective_name = data[i].objective_name;
        obj.value = data[i].target_qty;
        obj.f_value = data[i].target_qty
          ? this._formatService.formatNumber(data[i].target_qty)
          : '';
        obj.currency = 'EUR';
        obj.vouchers = '';
        obj.cust_account_id = data[i].cust_account_id;
        obj.cust_site_id = data[i].cust_site_id;

        if (!this.isEdit && !this.copyEvent) {
          if (!obj.cust_account_id && !obj.cust_site_id) {
            this.selectedGiftObjectives.push(obj);
          }
        }

        this.giftObjectives.push(obj);
      }
    }

    if (this.isEdit || this.copyEvent) {
      this.showSpinner = true;
      this.loadEvent(this.eventId);
      this.hideCustomer = this.editShipTo = false;
    } else {
      this.eventName = 'Pet food + almore';
    }
  }

  selectAction(state_name) {
    if (state_name) {
      this._router.navigate([state_name]);
    }
  }

  updateCustomerDetails() {
    let index = this.customers
      .map((x) => parseInt(x.cust_account_id))
      .indexOf(parseInt(this.requiredCustomer));

    if (index !== -1) {
      this.customer_email = this.customers[index].email_address;
      this.customer_phone = this.customers[index].primary_phone_number;
    }
  }

  updateSelectedObjectives(objective) {
    let index = this.objectives
      .map((x) => parseInt(x.objective_id))
      .indexOf(parseInt(objective.event_objective_id));
    if (index !== -1) {
      objective.objective_name = this.objectives[index].objective_name;
      objective.objective_id = objective.event_objective_id;
      objective.target_qty = this.objectives[index].target_qty;
      delete objective.add_new_objective;
      this.deleteDuplicateTargets();
    } else {
      objective.event_objective_id = '';
      objective.focus = true;
    }
  }

  updateSelectedGifts(gift) {
    let index = this.giftObjectives
      .map((x) => parseInt(x.objective_id))
      .indexOf(parseInt(gift.objective_id));
    if (index !== -1) {
      gift.objective_name = this.giftObjectives[index].objective_name;
      gift.value = this.giftObjectives[index].target_qty;
      gift.f_value = this.giftObjectives[index].target_qty
        ? this._formatService.formatNumber(
            this.giftObjectives[index].target_qty
          )
        : '';
      delete gift.add_new_gift;
      this.deleteDuplicateGifts();
    } else {
      gift.objective_id = '';
      gift.focus = true;
    }
  }

  updateStatus() {
    if (
      this.isEdit &&
      this.editData.status === 'N' &&
      this.eventstatus === 'N' &&
      this.roles.isAgency
    ) {
      this.hostessname = this.editData.hostess_id;
      this.mailid = this.editData.email_address;
      this.phoneno = this.editData.phone;
      setTimeout(() => {
        jQuery('#hostessname').val(this.editData.user_description);
      }, 500);
    }
  }

  validateCompensoHostess() {
    if (this.compenso_hostess) {
      this.compenso_hostess = this._formatService.numberParser(
        this.compenso_hostess
      );
    }
  }

  validateDate() {
    if (!this.dateChanged || !this.eventDate) {
      return;
    }
    this.dateChanged = false;
    let result = this._formatService.validateDate(this.eventDate),
      msg;
    if (!result) {
      msg = 'Entre date in ' + this.userDateFormat + ' this.format';
      msg += ' (Ex: ' + this.dateFormatExample + ')';
      this.eventDate = '';
      this.focusDate = false;
      this._appService.notify({ msg, status: 1 });
    } else {
      this.eventDate = result;
    }
  }

  validateEmail() {
    this.focusEmail = false;
    if (
      this.customer_email &&
      !this._appService.validateEmail(this.customer_email)
    ) {
      this.customer_email = '';
      this.focusEmail = true;
    }
  }

  validateQuantity(objective) {
    objective.target_qty =
      parseInt(objective.target_qty) >= 0
        ? parseInt(objective.target_qty)
        : null;
  }

  validateValue(gift) {
    if (!gift.f_value) {
      gift.value = '';
      return;
    }
    gift.f_value = this._formatService.numberParser(gift.f_value);
    // let returnValue = this._formatService.validatePattern(gift.f_value.toString());
    if (this._formatService.parseNumber(gift.f_value)) {
      gift.value = this._formatService.parseNumber(gift.f_value);
    } else {
      gift.f_value = '';
      gift.value = '';
      gift.focus = true;
      this._appService.notify({ msg: 'Enter a non-zero value', status: 1 });
    }
  }
}
