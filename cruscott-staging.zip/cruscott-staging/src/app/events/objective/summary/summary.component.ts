import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { DataService } from '../../../globals/data.service';
import { OrderByPipe } from '../../../globals/order-by.pipe';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';

@Component({
  selector: 'app-events-objective-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [OrderByPipe]
})
export class ObjectiveSummaryComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  actions: any[];
  desc: boolean;
  no_format: any;
  objectiveDetails: any;
  objectiveDialog: boolean;
  objectives: any;
  predicate: string;
  roles: any;
  searchObjective: any;
  showActions: any;
  showSpinner: boolean;
  toggleFilter: (e?) => void;
  user: any;
  userDateFormat: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, orderBy: OrderByPipe,
              formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.actions = [];
    this.desc = true;
    this.no_format = '';
    this.objectiveDetails = '';
    this.objectiveDialog = false;
    this.objectives = '';
    this.predicate = 'objective_id';
    this.roles = dataService.roles;
    this.showSpinner = false;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.userDateFormat = '';
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.userDateFormat = this.user.date_format;
        this.showSpinner = true;
        if (this.user.number_format) {
          this.no_format = this.user.number_format;
        } else {
          this.no_format = '999,999.99';
        }
        this.loadObjectives();
      }

    });

    this.actions.push({ name: 'Event Summary', label: 'events/summary' });
    this.actions.push({ name: 'Create Event', label: 'events/manage' });
    this.actions.push({ name: 'Hostess Report', label: 'events/hostess/report' });

    if (this.roles.isAdmin || this.roles.isAgent) {
      this.actions.push({ name: 'Ambassador Visits', label: 'events/ambassador/summary' });
    }

    this.actions.push({ name: 'Create Objective', label: 'events/objectives/manage' });

    if (this.roles.isHostess) {
      this.actions.push({ name: 'View Report', label: 'events/reports/hostess' });
    }
  }

  createObjective() {
    this._router.navigate(['events/objectives/manage']);
  }

  deleteObjective(objective?) {
    const endPoint = `/events/objectives/${this.objectiveDetails.objective_id}/`;
    if (objective) {
      this.objectiveDetails = objective;
      this.objectiveDialog = true;
    } else {
      this.showSpinner = true;
      this.objectiveDialog = false;

      this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({ status: 1, msg: 'Server Error' });
          } else {
            if (data.status === 0) {
              this.loadObjectives();
            }
            this._appService.notify({ status: data.status, msg: data.msg });
          }
          this.objectiveDetails = '';
        } catch (e) {
          this._appService.notify({ msg: e.msg, status: 1, details: '<pre>' + e.stack + '</pre>' });
        }
      });
    }
  }

  editObjective(o) {
    this._appService.objectiveId = o.objective_id;
    this._router.navigate(['events/objectives/manage']);
  }

  // Exports the table data into spreadsheet
  exportTable() {
    this.toggleFilter();
    let exportdata = this._orderBy.transform(this.objectives, this.predicate, this.desc),
      tableData: any = {}, tmpData = [], i, tmpObj;

    for (i = 0; i < exportdata.length; i++) {
      tmpObj = {};
      tmpObj['Objective #'] = { data: exportdata[i].objective_id };
      tmpObj['Objective Name'] = { data: exportdata[i].objective_name };
      tmpObj.Type = { data: exportdata[i].f_type };
      tmpObj['Creation Date'] = { data: exportdata[i].f_creation_date };
      tmpObj.Status = { data: exportdata[i].status === 'A' ? 'ACTIVE' : 'INACTIVE' };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Objectives', tableData, 'exportObjectives');
  }

  loadObjectives() {
    const endPoint = '/events/objectives/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else if (data.status === 1) {
          this._appService.notify({ status: data.status, msg: data.msg });
        } else {
          for (let i = 0; i < data.length; i++) {
            data[i].f_type = data[i].type.charAt(0) + data[i].type.slice(1).toLowerCase();
            data[i].f_creation_date = this._formatService.formatDate(data[i].creation_date);
            data[i].creation_date_millis = this._formatService.dateInMillis(data[i].creation_date);
          }
          this.objectives = data;
        }
      } catch (e) {
        this._appService.notify({ msg: e.msg, status: 1, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  selectAction(state_name) {
    if (state_name) {
      this._router.navigate([state_name]);
    }
  }

  sort(key) {
    this.predicate = key;
    this.desc = !this.desc;
  }

}
