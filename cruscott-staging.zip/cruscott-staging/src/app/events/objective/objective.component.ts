import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';

@Component({
  selector: 'app-events-objective',
  templateUrl: './objective.component.html',
  styleUrls: ['./objective.component.scss']
})
export class ObjectiveComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _sce: DomSanitizer;
  private _window: any;

  billacAddress: any;
  count: number;
  customer: any;
  customer_name: any;
  customers: any[];
  editObjective: boolean;
  editShipTo: boolean;
  focus: boolean;
  focus_target: boolean;
  hasShipTo: boolean;
  hideCustomer: boolean;
  items: any[];
  no_format: any;
  objectiveId: any;
  objectiveStatus: string;
  objectiveTargets: any[];
  objectiveTitle: any;
  objectiveType: string;
  objective_types: ({ type: string, value: string })[];
  objOrgChange: any;
  report_count: number;
  selectedShipTo: any;
  shipToId: any;
  shippingAddress: any;
  shipto: any;
  showSpinner: boolean;
  target: any;
  targetDetails: any;
  targets: any[];
  targetDialog: boolean;
  toggleFilter: (e?) => void;
  user: any;
  userDateFormat: any;

  constructor(appService: AppService, cacheService: CacheService, formatService: FormatService, httpService: HttpService,
              location: Location, sce: DomSanitizer, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._sce = sce;
    this._window = window;

    this.billacAddress = '';
    this.count = 0;
    this.customer = '';
    this.customer_name = '';
    this.customers = [];
    this.editObjective = false;
    this.editShipTo = false;
    this.focus = false;
    this.focus_target = false;
    this.hasShipTo = false;
    this.hideCustomer = false;
    this.items = [];
    this.no_format = '';
    this.objectiveId = '';
    this.objectiveStatus = 'A';
    this.objectiveTargets = [];
    this.objectiveTitle = '';
    this.objectiveType = 'QUANTITY';
    this.objective_types = [{ type: 'Quantity', value: 'QUANTITY' }, { type: 'Value', value: 'VALUE' }];
    this.objOrgChange = null;
    this.report_count = 0;
    this.selectedShipTo = '';
    this.shipToId = '';
    this.shippingAddress = '';
    this.shipto = '';
    this.showSpinner = false;
    this.target = '';
    this.targetDialog = false;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.userDateFormat = '';
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', {
      page: this._location.path()
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.userDateFormat = this.user.date_format;
        if (this.user.number_format) {
          this.no_format = this.user.number_format;
        } else {
          this.no_format = '999,999.99';
        }
        this.showSpinner = true;

        this.loadLov();

        if (this._appService.objectiveId) {
          this.showSpinner = true;
          this.loadObjective(this._appService.objectiveId);
          this.objectiveId = this._appService.objectiveId;
          this._appService.objectiveId = '';
          this.editObjective = true;
          this.hasShipTo = true;
        } else {
          this.count = 1;
          this.objectiveTargets = [{ targetIndex: this.count, selectedTarget: '', target_qty: '' }];
        }

        if (!this.editObjective) {
          this.loadCustomers();
        }
      }

      this.objOrgChange = this._appService.subscribeOrgChange(() => {
        if (this.report_count > 0) {
          return;
        }
        this.customers = [];
        this.customer = '';
        this.selectedShipTo = '';
        this.shippingAddress = '';
        this.customer_name = '';
        this.hideCustomer = false;
        this.editShipTo = false;
        this.shipToId = '';
        this.billacAddress = '';
        // this.shippingAddress = '';
        this.shipto = '';
        this.hasShipTo = false;
        this._cacheService.setCustomers(null);
        this.loadCustomers();
      });
    });
  }

  ngOnDestroy() {
    if (this.objOrgChange) {
      this.objOrgChange.unsubscribe();
    }
  }


  addSegments() {
    this.objectiveTargets.push({ targetIndex: ++this.count, selectedTarget: '', target_qty: '' });
  }

  checkDuplicates(target?) {
    if ((target && !target.selectedTarget) || !target) {
      this.deleteDuplicates();
    }
  }

  deleteDuplicates() {
    let targetSelected, i, j;
    this.targets = [];
    for (i = 0; i < this.items.length; i++) {
      targetSelected = false;
      for (j = 0; j < this.objectiveTargets.length; j++) {
        if (parseInt(this.items[i].flex_value) === parseInt(this.objectiveTargets[j].selectedTarget) && this.objectiveTargets[j].operation_code !== 'DELETE') {
          targetSelected = true;
          break;
        }
      }
      if (!targetSelected) {
        this.targets.push(this.items[i]);
      }
    }
  }

  deleteTarget(target?) {
    if (target) {
      this.targetDetails = target;
      this.targetDialog = true;
    } else {
      let i, index;
      index = this.objectiveTargets.map(x => x.targetIndex).indexOf(this.targetDetails.targetIndex);
      if (index !== -1) {
        if (this.targetDetails.hasOwnProperty('objective_id')) {
          this.objectiveTargets[index].operation_code = 'DELETE';
        } else {
          this.objectiveTargets.splice(index, 1);
        }
        this.targetDialog = false;
      }
      this.count = 0;
      for (i = 0; i < this.objectiveTargets.length; i++) {
        if (this.objectiveTargets[i].operation_code !== 'DELETE') {
          this.objectiveTargets[i].targetIndex = ++this.count;
        } else {
          this.objectiveTargets[i].targetIndex = '';
        }
      }
      this.targetDetails = '';
      setTimeout(() => {
        for (i = 0; i < this.objectiveTargets.length; i++) {
          this.setDescription(this.items, this.objectiveTargets[i]);
        }
      }, 300);
    }
    this.deleteDuplicates();
  }

  editAddress() {
    this.hideCustomer = false;
    this.editShipTo = true;
    jQuery('#obj-customer').val(this.customer_name);
    if (!this.shipto) {
      this.loadCustomerDetails();
    } else {
      let index = this.shipto.map(x => x.party_site_id).indexOf(this.shipToId);
      if (index !== -1) {
        let address = this.shipto[index].billacc_address;
        jQuery('#cust-shipto').val(address);
      }
    }
  }

  formatAddress(data) {
    let addressOne = data.billacc_address + '<br/>', addressTwo;
    if (data.hasOwnProperty('billing_address')) {
      addressTwo = data.billing_address;
    } else {
      addressTwo = data.shipping_address;
    }
    return this._sce.bypassSecurityTrustHtml(addressOne + addressTwo);
  }

  getObjectiveType() {
    this.target = '';
    this.focus_target = false;
    if (this.objectiveType === 'VALUE') {
      if (this.editObjective) {
        for (let i = 0; i < this.objectiveTargets.length; i++) {
          this.objectiveTargets[i].operation_code = 'DELETE';
        }
      } else {
        this.objectiveTargets = [];
      }
    }
  }

  getTargetIndex(items, target) {
    return items.map(x => parseInt(x.flex_value)).indexOf(parseInt(target.selectedTarget));
  }

  loadCustomerDetails() {
    let org = this._cacheService.getOrgId(), index, language, i, shipto;
    let endPoint = '/customer/id/' + this.customer + '/' + this.user.user_id + '/' + org + '/';
    if (!this.customer) {
      return;
    }

    index = this.customers.map(x => parseInt(x.cust_account_id)).indexOf(parseInt(this.customer));
    if (index !== -1) {
      this.customer_name = this.customers[index].customer_name;
    } else {
      this._appService.notify({ msg: 'Customer does not belong to selected organisation', status: 1 });
      this._router.navigate(['events/objectives/summary']);
    }

    this.showSpinner = true;

    if (this.user.ui_language) {
      switch (this.user.ui_language) {
        case 'IT':
          language = 'I';
          break;
        case 'DE':
          language = 'D';
          break;
        case 'FR':
          language = 'F';
          break;
        case 'EN':
          language = 'US';
          break;
      }
      endPoint += language + '/';
    }

    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - loadCustomerDetails' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.shipto = data.shipto;
          if (data.shipto.length === 0) {
            this._appService.notify({ msg: 'Selected customer has no shipto. Please select another customer', status: 1 });
            this.customer_name = '';
            this.editShipTo = false;
            return;
          }


          if (!this.hasShipTo) {
            for (i = 0; i < data.shipto.length; i++) {
              if (data.shipto[i].site_primary_flag === 'Y') {
                shipto = data.shipto[i];
                break;
              }
            }

            if (!shipto && i > 0) {
              this.selectedShipTo = data.shipto[0];
            } else {
              this.selectedShipTo = shipto;
            }
          } else {
            for (i = 0; i < data.shipto.length; i++) {
              if (parseInt(data.shipto[i].party_site_id) === parseInt(this.shipToId)) {
                this.selectedShipTo = data.shipto[i];
                break;
              }
            }
            this.hasShipTo = false;
          }

          if (!this.selectedShipTo.billacc_address) {
            this._appService.notify({ msg: 'Selected customer has no billacc_address. Please select another customer', status: 1 });
            this.customer_name = '';
            this.editShipTo = false;
            return;
          }

          this.shipToId = this.selectedShipTo.party_site_id;
          this.billacAddress = this.selectedShipTo.billacc_address;
          this.shippingAddress = this.formatAddress(this.selectedShipTo);
          this.hideCustomer = true;
          this.editShipTo = false;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadCustomers() {
    const endPoint = `/customer/list/${this.user.user_id}/${this._cacheService.getOrgId()}/`;
    if (this._cacheService.customers) {
      this.customers = this._cacheService.getCustomers();
      this.updateCustomer();
    } else {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({ status: 1, msg: 'Server Error - loadCustomers' });
          } else if (data.status === 1) {
            this._appService.notify(new APIError(data.msg));
          } else if (data.length > 0) {
            for (let i = 0; i < data.length; i++) {
              data[i].customer_name = data[i].customer_name + ',' + data[i].account_number;
            }
            this.customers = data;
            this._cacheService.setCustomers(data);
            this.updateCustomer();
          }
        } catch (e) {
          this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
        }
      });
    }
  }

  loadObjective(objectiveId) {
    const endPoint = `/events/objectives/${objectiveId}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - loadObjective' });
        } else if (data.status === 1) {
          this._appService.notify({ status: data.status, msg: data.msg });
        } else {
          this.objectiveTitle = data[0].objective_name;
          this.objectiveType = data[0].type;
          this.target = data[0].target_qty ? this.objectiveType === 'VALUE' ?
            this._formatService.formatNumber(data[0].target_qty) : data[0].target_qty : '';
          this.objectiveStatus = data[0].status;
          this.report_count = data[0].count;
          if (data[0].targets.length > 0) {
            for (let i = 0; i < data[0].targets.length; i++) {
              data[0].targets[i].targetIndex = i + 1;
              data[0].targets[i].selectedTarget = data[0].targets[i].flex_value.toString();
              data[0].targets[i].operation_code = 'UPDATE';
            }
            setTimeout(() => {
              for (let i = 0; i < data[0].targets.length; i++) {
                jQuery('#objective' + data[0].targets[i].flex_value).val(data[0].targets[i].description);
              }
            }, 300);
          }
          this.objectiveTargets = this.objectiveType === 'QUANTITY' ? data[0].targets : [];
          this.count = this.objectiveType === 'QUANTITY' ? data[0].targets.length : 0;
          this.customer = data[0].cust_account_id;
          this.shipToId = data[0].cust_site_id;
          this.deleteDuplicates();

          if (this.editObjective) {
            this.loadCustomers();
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.msg, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadLov() {
    const endPoint = '/events/categories/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error -   loadLov()' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.targets = data;
          this.items = data;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  moveToSummary() {
    this._router.navigate(['events/objectives/summary']);
  }

  onShipToChange() {
    let shipTos = this.shipto, i;
    this.editShipTo = false;
    this.hideCustomer = true;
    for (i = 0; i < shipTos.length; i++) {
      if (shipTos[i].party_site_id === parseInt(this.shipToId)) {
        this.selectedShipTo = shipTos[i];
        this.shippingAddress = this.formatAddress(this.selectedShipTo);
        break;
      }
    }
  }

  saveObjective() {
    let objective: any = {}, i, endPoint = '/events/objectives/',
      requestMethod = this.editObjective ? 'PUT' : 'POST';
    this.showSpinner = true;
    if (!this.count && this.objectiveType === 'QUANTITY') {
      this._appService.notify({ status: 1, msg: 'Add atleast one target' });
      this.showSpinner = false;
      return;
    }
    if (!this.objectiveTitle || !this.objectiveType ||
      (this.objectiveType === 'QUANTITY' && this.objectiveTargets.length === 0)) {
      this._appService.notify({ status: 1, msg: 'Enter objective Details' });
      this.focus = true;
      this.showSpinner = false;
      return;
    }
    if (this.customer && !this.shipToId) {
      this.editShipTo = true;
      this.hideCustomer = false;
      this._appService.notify({ msg: 'Enter Ship To', status: 1 });
      this.showSpinner = false;
      return;
    }

    objective.objective_name = this.objectiveTitle;
    objective.type = this.objectiveType;
    objective.target_qty = this.target ? this.objectiveType === 'VALUE' ? this._formatService.parseNumber(this.target) : this.target : '';
    objective.cust_account_id = parseInt(this.customer) || '';
    objective.cust_site_id = parseInt(this.shipToId) || '';
    objective.status = this.objectiveStatus;
    objective.last_updated_by = this.user.user_id;
    objective.last_updated_date = this._appService.today(0);

    if (!this.editObjective) {
      objective.created_by = this.user.user_id;
      objective.creation_date = this._appService.today(0);
    } else {
      objective.operation_code = 'UPDATE';
      objective.objective_id = this.objectiveId;
    }

    if (this.objectiveType === 'QUANTITY') {
      if (!this.validateFlexValue(this.objectiveTargets)) {
        this._appService.notify({ status: 1, msg: 'Enter valid segment' });
        this.showSpinner = false;
        this.checkDuplicates();
        return;
      }

      for (i = 0; i < this.objectiveTargets.length; i++) {
        this.objectiveTargets[i].last_updated_by = this.user.user_id;
        this.objectiveTargets[i].last_updated_date = this._appService.today(0);
        if (this.editObjective) {
          if (this.objectiveTargets[i].hasOwnProperty('objective_id')) {
            delete this.objectiveTargets[i].objective_id;
          } else {
            this.objectiveTargets[i].operation_code = 'CREATE';
          }
          this.objectiveTargets[i].event_objective_id = this.objectiveId;
        }
        if (!this.editObjective || (this.editObjective && !this.objectiveTargets[i].hasOwnProperty('objective_id'))) {
          this.objectiveTargets[i].created_by = this.user.user_id;
          this.objectiveTargets[i].creation_date = this._appService.today(0);
        }
      }
    } else {
      this.objectiveTargets = [];
    }
    objective.targets = this.objectiveTargets;

    this._httpService.httpRequest(requestMethod, endPoint, objective, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else {
          this._appService.notify({ status: data.status, msg: data.msg });
          if (data.status === 0) {
            this._router.navigate(['events/objectives/summary']);
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.msg, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  setDescription(items, target) {
    let index = this.items.map(x => parseInt(x.flex_value)).indexOf(parseInt(target.selectedTarget));
    if (index !== -1) {
      jQuery('#objective' + target.selectedTarget).val(this.items[index].description);
    }
  }

  updateCustomer() {
    if (this.editObjective && this.customers && this.customer) {
      let index = this.customers.map(x => x.cust_account_id.toString()).indexOf(this.customer.toString());
      if (index !== -1) {
        this.customer_name = this.customers[index].customer_name;
        jQuery('#obj-customer').val(this.customer_name);
        this.loadCustomerDetails();
      } else {
        this._appService.notify({ msg: 'Customer does not belong to selected organisation', status: 1 });
        this._router.navigate(['events/objectives/summary']);
      }
    }
  }

  // validate target names
  validateFlexValue(targets) {
    let i, index, target, flag = true, items = this.items;
    for (i = 0; i < targets.length; i++) {
      target = targets[i];

      if (!target.objective_id || (target.objective_id && target.operation_code !== 'DELETE')) {
        index = this.getTargetIndex(items, target);

        if (index !== -1) {
          target.item_id = target.selectedTarget;
        } else {
          target.selectedTarget = '';
          this.focus = true;
          flag = false;
        }
      }
    }
    return flag;
  }

  validateTarget() {
    this.focus_target = false;
    if (this.objectiveType === 'VALUE') {
      this.target = this._formatService.numberParser(this.target.toString());
    } else {
      if (this.target && !parseInt(this.target)) {
        this._appService.notify({ msg: 'Enter valid number', status: 1 });
        this.focus_target = true;
        this.target = '';
      }
    }
  }

  validateValue() {
    this.target = parseInt(this.target) || '';
  }

}
