import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { CacheService } from '../../globals/cache.service';
import { ReportService } from '../../globals/report.service';

@Component({
  selector: 'app-events-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class EventReportComponent implements OnInit {
  private _router: Router;
  private _cacheService: CacheService;
  private _reportService: ReportService;

  constructor(cacheService: CacheService, reportService: ReportService, router: Router) {
    this._router = router;
    this._cacheService = cacheService;
    this._reportService = reportService;
  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
      }
    });
  }

  showReport(name) {
    this._reportService.selectedReportView = '';
    this._router.navigate([name]);
  }
}
