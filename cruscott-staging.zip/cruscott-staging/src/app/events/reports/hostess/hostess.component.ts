import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { DataService } from '../../../globals/data.service';
import { OrderByPipe } from '../../../globals/order-by.pipe';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';

declare var FooPicker: any;

@Component({
  selector: 'app-events-reports-hostess',
  templateUrl: './hostess.component.html',
  styleUrls: ['./hostess.component.scss'],
  providers: [OrderByPipe]
})
export class HostessReportComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  accept_policy: any;
  actions: any[];
  data: any;
  dateFormat: any;
  desc: boolean;
  displayStatus: any;
  events: any;
  eventsDesc: boolean;
  eventsPredicate: string;
  eventStatus: any;
  focusFromDate: any;
  fromDate: any;
  fromDateMsg: any;
  msg: any;
  predicate: string;
  reportStatus: ({ status: string, report_status: string })[];
  roles: any;
  searchQuery: any;
  selectedStatus: any;
  showActions: any;
  showAdvanced: any;
  showButton: any;
  showEvents: any;
  showReported: any;
  showSpinner: any;
  status: any;
  toDate: any;
  toggleFilter: (e?) => void;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, orderBy: OrderByPipe,
              formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    // scope variables
    this.accept_policy = null;
    this.actions = [];
    this.data = null;
    this.desc = true;
    this.displayStatus = null;
    this.events = [];
    this.eventsDesc = true;
    this.eventsPredicate = 'event_id';
    this.eventStatus = null;
    this.focusFromDate = null;
    this.fromDate = null;
    this.fromDateMsg = '';
    this.msg = null;
    this.predicate = 'report_id';
    this.reportStatus = [
      { status: 'All', report_status: '' },
      { status: 'Approved', report_status: 'APPROVED' },
      { status: 'Pending Approval', report_status: 'PENDING_APPROVAL' },
      { status: 'Rejected', report_status: 'REJECTED' }];
    this.roles = dataService.roles;
    this.selectedStatus = {};
    this.showButton = null;
    this.showEvents = null;
    this.showReported = null;
    this.showSpinner = null;
    this.status = null;
    this.toDate = null;
    this.toggleFilter = appService.toggleFilter();
    this.user = null;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        if (this.user) {
          let permissions = this.user.permissions,
            index = permissions.indexOf('OTHER-UI-CREATE-HOSTESS'); // to show approve button
          this.showButton = !!(index !== -1 || this.roles.isAgency);
          if (this.roles.isHostess && this.user.last_logon_date === null) {
            this.accept_policy = true;
          } else {
            this.showSpinner = true;
            this.loadEvents();
          }
        }
        this.dateFormat = this.user.date_format ? this.user.date_format : 'dd-MMM-yyyy';
        new FooPicker({
          id: 'fromdate',
          dateFormat: this.dateFormat
        });
        new FooPicker({
          id: 'todate',
          dateFormat: this.dateFormat
        });
        this.showEvents = false;
        if (this.roles.isHostess || this.roles.isAgency) {
          this.displayStatus = 'notreported';
          this.eventStatus = 'notreported';
        } else {
          this.displayStatus = 'reported';
          this.eventStatus = 'reported';
        }
        this.selectedStatus = {};
        this.showReported = true;
        if (this._appService.hostessMsg) {
          this._appService.notify({ status: this._appService.hostessStatus, msg: this._appService.hostessMsg });
          this._appService.hostessStatus = null;
          this._appService.hostessMsg = null;
        }

        if (this._dataService.fromState && this._dataService.fromState === '/events/manage') {
          if (this._appService.updatemsg !== '' && this._appService.updatestatus !== '') {
            this.msg = this._appService.updatemsg;
            this.status = this._appService.updatestatus;
            this._appService.updatemsg = '';
            this._appService.updatestatus = '';
            this._appService.notify({ status: this.status, msg: this.msg });
          }
        }
      }

      if (!this.roles.isHostess) {
        this.actions.push({ name: 'View Report', label: 'events/reports/hostess' });
      }
      if (this.showButton) {
        this.actions.push({ name: 'Create Hostess', label: 'events/hostess/create' });
        this.actions.push({ name: 'View Hostess', label: 'events/hostess' });
      }
      this.actions.push({ name: 'Events Summary', label: 'events/summary' });
      this.actions.push({ name: 'Create Event', label: 'events/manage' });
      if (this.roles.isAdmin || this.roles.isAgent) {
        this.actions.push({ name: 'Ambassador Visits', label: 'events/ambassador/summary' });
      }
      if (!this.roles.isAgency) {
        this.actions.push({ name: 'View Objectives', label: 'events/objectives/summary' });
        this.actions.push({ name: 'Create Objective', label: 'events/objectives/manage' });
      }

    });
  }

  acceptPolicy() {
    const endPoint = `/users/update/${this.user.user_id}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === undefined || data === null) {
        this._appService.notify({ status: 1, msg: 'Server Error - acceptPolicy' });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.accept_policy = false;
        this.showSpinner = true;
        this.loadEvents();
      }
    });
  }

  applyFilter() {
    if (this.fromDate && this.toDate) {
      if (this._formatService.dateInMillis(this._formatService.parseDate(this.fromDate.toString())) > this._formatService.dateInMillis(this._formatService.parseDate(this.toDate.toString()))) {
        this.fromDateMsg = 'From date greater than To date';
        this.fromDate = '';
        this.focusFromDate = true;
        return;
      }
    }
    this.focusFromDate = '';
    this.fromDateMsg = '';
    this.toggleFilter();
    this.showSpinner = true;
    this.loadEvents(true);
  }

  createNewHostess() {
    this._router.navigate(['events/hostess']);
  }

  createReport(event) {
    this._appService.report_id = null;
    if (event) {
      this._appService.event = event;
    }
    event = '';
    this._router.navigate(['events/hostess/report/manage']);
  }

  editReport(d) {
    this._appService.report_id = d.report_id;
    this._router.navigate(['events/hostess/report/manage']);
  }

  exportData() {
    let tableData: any = {}, tmpData = [], tmpObj, data, i;
    if (!this.events) { return; }
    this.toggleFilter();
    if (this.displayStatus === 'notreported') {
      data = this._orderBy.transform(this.events, this.eventsPredicate, this.eventsDesc);
      for (i = 0; i < data.length; i++) {
        tmpObj = {};
        tmpObj['Event #'] = { data: data[i].event_id };
        tmpObj['Event Name'] = { data: data[i].event_name };
        tmpObj['Customer Name'] = { data: data[i].customer_name };
        tmpObj['Customer Number'] = { data: data[i].customer_number };
        tmpObj['Site Id'] = { data: data[i].party_site_id };
        tmpObj['Address 1'] = { data: data[i].address_1 };
        tmpObj['Address 2'] = { data: data[i].address_2 };
        tmpObj['Created By'] = { data: data[i].creator_name };
        tmpObj['Creation Date'] = { data: data[i].f_creation_date };
        tmpObj['Event Date'] = { data: data[i].f_event_date };
        tmpObj['Last Update Date'] = { data: data[i].f_last_update_date };
        tmpObj['Agent Name'] = { data: data[i].agent_name };
        if (!this.roles.isHostess) {
          tmpObj['Hostess Name'] = { data: data[i].user_description };
          tmpObj['Hostess Tel No.'] = { data: data[i].phone };
          tmpObj['External Identification'] = { data: data[i].external_id };
        }
        tmpData.push(tmpObj);
      }
      tableData.data = tmpData;
    }

    if (this.displayStatus === 'reported') {
      if (!this.data) { return; }
      data = this._orderBy.transform(this.data, this.predicate, this.desc);
      for (i = 0; i < data.length; i++) {
        tmpObj = {};
        tmpObj['Report #'] = { data: data[i].report_id };
        tmpObj['Event #'] = { data: data[i].event_id };
        tmpObj['Event Name'] = { data: data[i].event_name };
        tmpObj['Hostess Name'] = { data: data[i].hostess_name };
        tmpObj['Reported By'] = { data: data[i].reported_by };
        tmpObj.Customer = { data: data[i].customer_name };
        tmpObj['Customer Number'] = { data: data[i].customer_number };
        tmpObj['Site Id'] = { data: data[i].party_site_id };
        tmpObj['Address 1'] = { data: data[i].address_1 };
        tmpObj['Event Date'] = { data: data[i].f_event_date };
        tmpObj['Report Date'] = { data: data[i].f_report_date };
        tmpObj['Agent Name'] = { data: data[i].agent_name };
        tmpObj['Report Status'] = {
          data: data[i].report_status === 'PENDING_APPROVAL' ? 'Waiting for Approval' : data[i].report_status === 'REJECTED' ? 'Rejected' : data[i].report_status === 'APPROVED' ? 'Approved' : 'Created'
        };
        tmpData.push(tmpObj);
      }
      tableData.data = tmpData;
    }
    let title = this.displayStatus === 'reported' ? 'Reported Events' : 'Events Not Reported';
    this._appService.tableToExcel(title, tableData, 'export-data');
  }

  filterEvents(data, filters) {
    if (data.hasOwnProperty('status') && data.status === 1) {
      this._appService.notify({ msg: data.msg, status: data.status });
      this.showSpinner = false;
      return;
    }
    let events = [], i;
    for (i = 0; i < data.length; i++) {
      if (data[i].status === 'Active' && !data[i].report_count) {
        data[i].f_event_date = this._formatService.formatDate(data[i].event_date);
        data[i].event_date_millis = this._formatService.dateInMillis(data[i].event_date.toString());
        data[i].f_creation_date = this._formatService.formatDate(data[i].creation_date);
        data[i].creation_date_millis = this._formatService.dateInMillis(data[i].creation_date);
        data[i].f_last_update_date = this._formatService.formatDate(data[i].last_updated_date);
        data[i].last_update_date_millis = this._formatService.dateInMillis(data[i].last_updated_date);
        data[i].external_id = data[i].external_identification !== null ? data[i].external_identification : '';
        data[i].phone = data[i].phone || '';
        events.push(data[i]);
      }
    }
    this.events = events;
    this.loadData(filters);
  }

  loadData(filters) {
    let endPoint = '/events/hostess/summary/',
      req: any = {};
    req.user_id = this.roles.isHostess ? this.user.user_id : '';
    if (filters) {
      req.from_date = this.fromDate ? this._formatService.parseDate(this.fromDate) : '';
      req.to_date = this.toDate ? this._formatService.parseDate(this.toDate) : '';
    } else {
      req.from_date = '';
      req.to_date = '';
    }
    this.data = null;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      try {
        this.parseData(data);
      } catch (e) {
        this.showSpinner = false;
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadEvents(filters?) {
    let endPoint = '/events/summary/',
      req: any = {};
    req.user_id = '';
    if (this.roles.isAgent || this.roles.isHostess) {
      req.user_id = this.user.user_id;
    } else if (!this.roles.isAdmin && !this.roles.isManager && !this.roles.isAgency) {
      endPoint += 'user/';
      req.user_id = this.user.user_id;
    }
    if (filters) {
      req.from_date = this.fromDate ? this._formatService.parseDate(this.fromDate) : '';
      req.to_date = this.toDate ? this._formatService.parseDate(this.toDate) : '';
    } else {
      req.from_date = '';
      req.to_date = '';
    }
    req.created_by = '';
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadEvents' });
      } else if (data.status === 1) {
        this._appService.notify({ status: data.status, msg: data.msg });
      } else {
        this.filterEvents(data.events, filters);
      }
    });
  }

  logout() {
    this._dataService.logout = true;
    this._cacheService.clear(); // Clear all cached data before loggin out
    this._router.navigate(['login']);
  }

  matchSalesRep(salesRep) {
    let salesReps = this.user.salesreps, i;
    if (salesReps.length > 0) {
      for (i = 0; i < salesReps.length; i++) {
        if (parseInt(salesReps[i].reference_value) === parseInt(salesRep)) {
          return true;
        }
      }
    } else if (parseInt(this.user.salesrep_id) === parseInt(salesRep)) {
      return true;
    }
    return false;
  }

  moveToEvents(event) {
    this._appService.eventid = event.event_id;
    this._appService.eventEdit = true;
    this._router.navigate(['events/manage']);
  }

  moveToReports() {
    this._router.navigate(['events/reports/hostess']);
  }

  parseData(data) {
    this.showSpinner = false;
    if (data === null || data === undefined) {
      this._appService.notify({ status: 1, msg: 'Server Error - parseData' });
    } else {
      if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
        return;
      }
      const tmpData = [];
      for (let i = 0; i < data.length; i++) {
        data[i].f_event_date = this._formatService.formatDate(data[i].event_date);
        data[i].event_date_millis = this._formatService.dateInMillis(data[i].event_date);
        data[i].f_report_date = this._formatService.formatDate(data[i].report_date);
        data[i].report_date_millis = this._formatService.dateInMillis(data[i].report_date);
        if (this.roles.isAgent) {
          if (data[i].created_user === this.user.user_id ||
            this.matchSalesRep(data[i].salesrep_id)) {
            tmpData.push(data[i]);
          }
        }
      }
      this.data = this.roles.isAgent ? tmpData : data;
    }
  }

  selectAction(state_name) {
    if (state_name) {
      this._router.navigate([state_name]);
    }
  }

  sort(key) {
    this.desc = !this.desc;
    this.predicate = key;
  }

  sortEvents(key) {
    this.eventsDesc = !this.eventsDesc;
    this.eventsPredicate = key;
  }

  toggleStatus(status) {
    if (this.eventStatus !== status) {
      this.displayStatus = status;
      this.eventStatus = status;
    }
  }

  viewReport() {
    this._router.navigate(['events/reports/hostess']);
  }

}
