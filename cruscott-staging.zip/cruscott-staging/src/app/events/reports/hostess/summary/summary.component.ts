import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppService } from '../../../../globals/app.service';
import { CacheService } from '../../../../globals/cache.service';
import { DataService } from '../../../../globals/data.service';
import { FormatService } from '../../../../globals/format.service';
import { HttpService } from '../../../../globals/http.service';
import { APIError } from '../../../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-events-reports-hostess-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class HostessReportSummaryComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  actions: any[];
  agents: any[];
  customers: any;
  dateFormat: any;
  desc: boolean;
  focusFromDate: any;
  fromDate: any;
  fromDateMsg: any;
  hostess: any;
  hostessNames: any;
  hostessSearch: any;
  objectives: any;
  predicate: string;
  rFocusFromDate: any;
  rFromDate: any;
  rFromDateMsg: any;
  roles: any;
  rToDate: any;
  showActions: any;
  selectedAgent: any;
  selectedCustomer: any;
  selectedHostess: any;
  showAdvanced: boolean;
  showSpinner: any;
  subOrgChange: any;
  toDate: any;
  toggleFilter: (e?) => void;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService,
              formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    // scope variables
    this.actions = [];
    this.agents = [];
    this.customers = null;
    this.dateFormat = null;
    this.desc = true;
    this.focusFromDate = null;
    this.fromDate = null;
    this.fromDateMsg = null;
    this.hostess = null;
    this.hostessNames = null;
    this.objectives = null;
    this.predicate = 'report_id';
    this.rFocusFromDate = null;
    this.rFromDate = null;
    this.rFromDateMsg = null;
    this.roles = dataService.roles;
    this.rToDate = null;
    this.selectedAgent = null;
    this.selectedCustomer = null;
    this.selectedHostess = null;
    this.showAdvanced = false;
    this.showSpinner = null;
    this.subOrgChange = null;
    this.toDate = null;
    this.toggleFilter = appService.toggleFilter();
    this.user = null;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.showAdvanced = true;

        this.dateFormat = this.user.date_format ? this.user.date_format : 'dd-MMM-yyyy';
        // this.showSpinner = true;
        new FooPicker({
          id: 'fromdate',
          dateFormat: this.dateFormat
        });
        new FooPicker({
          id: 'todate',
          dateFormat: this.dateFormat
        });
        new FooPicker({
          id: 'rfromdate',
          dateFormat: this.dateFormat
        });
        new FooPicker({
          id: 'rtodate',
          dateFormat: this.dateFormat
        });

        this.loadObjectives();
        this.toggleFilter();
        this.loadHostess();
        // loadSalesGroups();
        if (!this.roles.isAgent) {
          this.loadAgents();
        }
        if (!this.roles.isAgency) {
          this.loadCustomers();
        }

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.agents = [];
          this.loadAgents();
        });

      }

      this._appService.eventEdit = false;
      this.actions.push({ name: 'Event Summary', label: 'events/summary' });
      this.actions.push({ name: 'Create Event', label: 'events/manage' });
      this.actions.push({ name: 'Hostess Report', label: 'events/hostess/report' });
      if (this.roles.isAdmin || this.roles.isAgent) {
        this.actions.push({ name: 'Ambassador Visits', label: 'events/ambassador/summary' });
      }
      if (!this.roles.isAgency) {
        this.actions.push({ name: 'View Objectives', label: 'events/objectives/summary' });
        this.actions.push({ name: 'Create Objective', label: 'events/objectives/manage' });
      }

    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  applyFilter() {
    if (this.fromDate && this.toDate) {
      if (this._formatService.dateInMillis(this._formatService.parseDate(this.fromDate.toString())) > this._formatService.dateInMillis(this._formatService.parseDate(this.toDate.toString()))) {
        this.fromDateMsg = 'From date greater than To date';
        this.fromDate = '';
        this.focusFromDate = true;
        return;
      }
    }
    if (this.rFromDate && this.rToDate) {
      if (this._formatService.dateInMillis(this._formatService.parseDate(this.rFromDate.toString())) > this._formatService.dateInMillis(this._formatService.parseDate(this.rToDate.toString()))) {
        this.rFromDateMsg = 'From date greater than To date';
        this.rFromDate = '';
        this.rFocusFromDate = true;
        return;
      }
    }
    this.focusFromDate = '';
    this.fromDateMsg = '';
    this.rFocusFromDate = '';
    this.rFromDateMsg = '';
    this.toggleFilter();
    this.showSpinner = true;
    this.loadData();
  }

  // Exports the table data into spreadsheet
  exportToExcel() {
    this.toggleFilter();
    this._appService.exportUITable('hostessData', 'Hostess Report', 'exportHostess');
  }

  goToEvents(report) {
    this._appService.eventid = report.event_id;
    this._appService.eventEdit = true;
    this._router.navigate(['events/manage']);
  }

  loadAgents(): void {
    const endPoint = `/operatingunits/salesrep/${this._cacheService.getOrgId()}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadAgents' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.agents = data;
      }
    });
  }

  loadCustomers(): void {
    if (this._cacheService.customers) {
      this.customers = this._cacheService.getCustomers();
    } else {
      const endPoint = `/customer/list/${this.user.user_id}/${this._cacheService.getOrgId()}/`;
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - loadCustomers' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else if (data.length > 0) {
          for (let i = 0; i < data.length; i++) {
            data[i].customer_name = data[i].customer_name + ',' + data[i].account_number;
          }
          this.customers = data;
          this._cacheService.setCustomers(data);
        }
      });
    }
  }

  loadData() {
    let endPoint = '/events/hostess/report/',
      req: any = {}, i, j, k, flag;
    req.agent_id = this.roles.isAgent ? this.user.salesrep_id : this.selectedAgent || '';
    req.from_date = this.fromDate ? this._formatService.parseDate(this.fromDate) : '';
    req.to_date = this.toDate ? this._formatService.parseDate(this.toDate) : '';
    req.rfrom_date = this.rFromDate ? this._formatService.parseDate(this.rFromDate) : '';
    req.rto_date = this.rToDate ? this._formatService.parseDate(this.rToDate) : '';
    req.cust_id = this.selectedCustomer || '';
    req.hostess = this.selectedHostess || '';
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadData' });
      } else {
        if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
          return;
        }
        for (i = 0; i < this.objectives.length; i++) {
          for (j = 0; j < data.length; j++) {
            for (k = 0; k < data[j].objectives.length; k++) {
              if (data[j].objectives[k].event_objective_id === this.objectives[i].objective_id) {
                this.objectives[i].object_selected = true;
                break;
              }
            }
            for (k = 0; k < data[j].gift_objectives.length; k++) {
              if (data[j].gift_objectives[k].objective_id === this.objectives[i].objective_id) {
                this.objectives[i].gift_selected = true;
                break;
              }
            }
          }
        }

        for (i = 0; i < data.length; i++) {
          data[i].f_objectives = [];
          data[i].f_gifts = [];
          data[i].f_amount = this._formatService.formatNumber(data[i].amount);
          data[i].f_discount = this._formatService.formatNumber(data[i].discount);
          data[i].f_report_date = this._formatService.formatDate(data[i].report_date);
          data[i].report_date_millis = this._formatService.dateInMillis(data[i].report_date);
          data[i].f_creation_date = this._formatService.formatDate(data[i].creation_date);
          data[i].creation_date_millis = this._formatService.dateInMillis(data[i].creation_date);
          data[i].f_event_date = this._formatService.formatDate(data[i].event_date);
          data[i].event_date_millis = this._formatService.dateInMillis(data[i].event_date);
          data[i].f_report_last_updated_date = this._formatService.formatDate(data[i].report_last_updated_date);
          data[i].report_last_updated_date_millis = this._formatService.dateInMillis(data[i].report_last_updated_date);
          data[i].external_id = data[i].external_identification !== null ? data[i].external_identification : '';
          data[i].f_rimborso_extra = data[i].rimborso_extra !== null ? this._formatService.formatNumber(data[i].rimborso_extra) : '';
          data[i].f_compenso_variable = data[i].compenso_variable !== null ? this._formatService.formatNumber(data[i].compenso_variable) : '';
          data[i].f_total_compenso = data[i].f_total_compenso !== null ? this._formatService.formatNumber(data[i].total_compenso) : '';
          for (k = 0; k < this.objectives.length; k++) {
            if (this.objectives[k].object_selected) {
              flag = false;
              for (j = 0; j < data[i].objectives.length; j++) {
                if (this.objectives[k].objective_id === data[i].objectives[j].event_objective_id) {
                  data[i].f_objectives.push(data[i].objectives[j]);
                  flag = true;
                  break;
                }
              }
              if (!flag) {
                data[i].f_objectives.push({
                  event_objective_id: this.objectives[k].objective_id,
                  objective_name: this.objectives[k].objective_name,
                  target_qty: '', target_achieved: ''
                });
              }
            }
            if (this.objectives[k].gift_selected) {
              flag = false;
              for (j = 0; j < data[i].gift_objectives.length; j++) {
                if (this.objectives[k].objective_id === data[i].gift_objectives[j].objective_id) {
                  data[i].gift_objectives[j].f_value_spent = this._formatService.formatNumber(data[i].gift_objectives[j].vouchers * data[i].gift_objectives[j].value);
                  // data[i].gift_objectives[j].f_value_spent = formatService.formatNumber(data[i].gift_objectives[j].value_spent);
                  data[i].gift_objectives[j].f_value = this._formatService.formatNumber(data[i].gift_objectives[j].value);
                  data[i].f_gifts.push(data[i].gift_objectives[j]);
                  flag = true;
                  break;
                }
              }
              if (!flag) {
                data[i].f_gifts.push({
                  value: '', value_spent: '', vouchers: '', currency: '', vouchers_spent: '',
                  objective_name: this.objectives[k].objective_name,
                  objective_id: this.objectives[k].objective_id
                });
              }
            }
          }
        }
        this.hostess = data;
      }
      this.showSpinner = false;
    });
  }

  loadHostess(): void {
    const endPoint = '/users/hostess/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadHostess' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.hostessNames = data;
      }
    });
  }

  loadObjectives() {
    const endPoint = '/events/objectives/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadObjectives' });
      } else {
        if (data.status === 1) {
          this._appService.notify({ status: data.status, msg: data.msg });
          return;
        }
        for (let i = 0; i < data.length; i++) {
          data[i].object_selected = false;
          data[i].gift_selected = false;
        }
        this.objectives = data;
      }
      this.showSpinner = false;
    });
  }

  // // Load the salesGroups related to logged in user based on the
  // // selected organization
  // function loadSalesGroups() {
  //   let endPoint = '/metrics/cruscott/channels/';
  //   httpService.httpRequest('GET', endPoint, null, function (data) {
  //     try {
  //       if (data === null || data === undefined) {
  //         appService.notify({status: 1, msg: 'Server Error'});
  //       } else {
  //         let groups = cacheService.getGroupList();
  //         let tmpGroups = [];
  //         for (let i = 0; i < data.length; i++) {
  //           if (groups.indexOf(data[i].group_name) !== -1) {
  //             let obj = {};
  //             obj.group_name = data[i].group_name;
  //             tmpGroups.push(obj);
  //           }
  //         }
  //         this.salesGroups = tmpGroups;
  //         if (cacheService.selectedGroup) {
  //           this.selectedGroup = cacheService.selectedGroup;
  //           cacheService.selectedGroup = null;
  //         } else if (tmpGroups[0]) {
  //           this.selectedGroup = tmpGroups[0].group_name;
  //         }
  //         loadAgents();
  //       }
  //     } catch (e) {
  //       appService.notify({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
  //     }
  //   });
  // }

  selectAction(state_name) {
    if (state_name) {
      this._router.navigate([state_name]);
    }
  }

  // Table sorting
  sort(key) {
    this.predicate = key;
    this.desc = !this.desc;
  }

  viewReport(report_id) {
    this._appService.report_id = report_id;
    this._router.navigate(['events/hostess/report/manage']);
  }

}
