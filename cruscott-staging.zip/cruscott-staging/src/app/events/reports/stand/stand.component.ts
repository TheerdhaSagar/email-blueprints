import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { OrderByPipe } from '../../../globals/order-by.pipe';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';
import { APIError } from '../../../globals/api.error';

@Component({
  selector: 'app-reports-other-stand',
  templateUrl: './stand.component.html',
  styleUrls: ['./stand.component.scss'],
  providers: [OrderByPipe]
})
export class StandReportComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  assembleCost: any;
  desc: boolean;
  otherCost: any;
  peopleCost: any;
  predicate: string;
  rentalCost: any;
  reservations: any;
  searchQuery: any;
  shippingCost: any;
  showSpinner: boolean;
  toggleFilter: (e?) => void;
  totalCost: any;

  constructor(appService: AppService, cacheService: CacheService, orderBy: OrderByPipe, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.assembleCost = null;
    this.desc = true;
    this.otherCost = null;
    this.peopleCost = null;
    this.predicate = 'from_date_millis';
    this.rentalCost = null;
    this.reservations = null;
    this.shippingCost = null;
    this.showSpinner = true;
    this.toggleFilter = appService.toggleFilter();
    this.totalCost = null;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
      }
      this.loadData();
    });
  }

  exportData() {
    let data = this._orderBy.transform(this.reservations, this.predicate, this.desc),
      i, tableData: any = {}, tmpData = [], tmpObj;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj['#'] = { data: data[i].reserve_hdr_id };
      tmpObj['Stand Name'] = { data: data[i].stand_name };
      tmpObj.Purpose = { data: data[i].description };
      tmpObj.Location = { data: data[i].final_location };
      tmpObj.From = { data: data[i].f_from_date };
      tmpObj.To = { data: data[i].f_till_date };
      tmpObj['Reserved By'] = { data: data[i].reserved_by };
      tmpObj['Shipping Cost'] = { data: data[i].f_shipping_cost, align: 'right' };
      tmpObj['Assemble Cost'] = { data: data[i].f_assemble_cost, align: 'right' };
      tmpObj['Rental Cost'] = { data: data[i].f_rental_cost, align: 'right' };
      tmpObj['People Cost'] = { data: data[i].f_people_cost, align: 'right' };
      tmpObj['Other Cost'] = { data: data[i].f_other_cost, align: 'right' };
      tmpObj.Total = { data: data[i].f_total, align: 'right' };
      tmpObj.Status = { data: data[i].status };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    tableData.footer = [{ data: '' }, { data: '' }, { data: '' }, { data: '' }, { data: '' },
      { data: this.shippingCost, align: 'right' }, { data: this.assembleCost, align: 'right' },
      { data: this.rentalCost, align: 'right' }, { data: this.peopleCost, align: 'right' },
      { data: this.otherCost, align: 'right' }, { data: this.totalCost, align: 'right' }, { data: '' }];
    this._appService.tableToExcel('Stand Reservations', tableData, 'export-reservations');
  }

  formatData(data) {
    let assembleCost = 0, i, otherCost = 0, peopleCost = 0, rentalCost = 0,
      shippingCost = 0, totalCost = 0;
    for (i = 0; i < data.length; i++) {
      data[i].f_from_date = this._formatService.formatDate(data[i].from_date);
      data[i].f_till_date = this._formatService.formatDate(data[i].till_date);
      data[i].from_date_millis = this._formatService.dateInMillis(data[i].from_date);
      data[i].till_date_millis = this._formatService.dateInMillis(data[i].till_date);

      data[i].f_shipping_cost = this._formatService.formatNumber(data[i].shipping_cost);
      data[i].f_assemble_cost = this._formatService.formatNumber(data[i].assemble_cost);
      data[i].f_rental_cost = this._formatService.formatNumber(data[i].rental_cost);
      data[i].f_people_cost = this._formatService.formatNumber(data[i].people_cost);
      data[i].f_other_cost = this._formatService.formatNumber(data[i].other_cost);

      data[i].shipping_cost = data[i].shipping_cost ? parseFloat(data[i].shipping_cost) : 0;
      data[i].assemble_cost = data[i].assemble_cost ? parseFloat(data[i].assemble_cost) : 0;
      data[i].rental_cost = data[i].rental_cost ? parseFloat(data[i].rental_cost) : 0;
      data[i].people_cost = data[i].people_cost ? parseFloat(data[i].people_cost) : 0;
      data[i].other_cost = data[i].other_cost ? parseFloat(data[i].other_cost) : 0;

      let total = data[i].shipping_cost + data[i].assemble_cost +
        data[i].rental_cost + data[i].people_cost + data[i].other_cost;

      shippingCost += data[i].shipping_cost;
      assembleCost += data[i].assemble_cost;
      rentalCost += data[i].rental_cost;
      peopleCost += data[i].people_cost;
      otherCost += data[i].other_cost;
      totalCost += total;

      data[i].total = total;
      data[i].f_total = this._formatService.formatNumber(data[i].total);
    }

    this.shippingCost = this._formatService.formatNumber(shippingCost);
    this.assembleCost = this._formatService.formatNumber(assembleCost);
    this.rentalCost = this._formatService.formatNumber(rentalCost);
    this.peopleCost = this._formatService.formatNumber(peopleCost);
    this.otherCost = this._formatService.formatNumber(otherCost);
    this.totalCost = this._formatService.formatNumber(totalCost);

    this.reservations = data;
    this.showSpinner = false;
  }

  loadData(): void {
    const endPoint = '/events/stands/reservations/';
    this.showSpinner = true;
    this.reservations = null;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - loadData' });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.formatData(data);
        }
        this.showSpinner = false;
      } catch (e) {
        this.showSpinner = false;
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  sort(key) {
    this.desc = !this.desc;
    this.predicate = key;
  }
}
