import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';

declare var FooPicker: any;

@Component({
  selector: 'app-events-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [OrderByPipe]
})
export class EventSummaryComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _router: Router;
  private _location: Location;
  private _window: any;

  actions: any[];
  date_format: any;
  deleteEvent: boolean;
  desc: boolean;
  eventDetails: any;
  event_status: any;
  events: any[];
  events_message: any;
  focus_from_date: any;
  from_date: any;
  from_date_msg: any;
  mfocus_from_date: any;
  mfrom_date: any;
  msg: string;
  mto_date: any;
  objectives: any[];
  predicate: string;
  report_status: any;
  roles: any;
  searchEvent: any;
  showActions: boolean;
  showSpinner: boolean;
  to_date: any;
  toggleFilter: (e?) => void;
  user: any;
  user_id: any;
  windowWidth: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, orderBy: OrderByPipe,
              formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._router = router;
    this._location = location;
    this._window = window;

    this.actions = [];
    this.date_format = '';
    this.deleteEvent = false;
    this.desc = false;
    this.eventDetails = {};
    this.event_status = '';
    this.events = [];
    this.events_message = '';
    this.focus_from_date = '';
    this.from_date = '';
    this.from_date_msg = false;
    this.mfocus_from_date = '';
    this.mfrom_date = '';
    this.mto_date = '';
    this.objectives = [];
    this.predicate = 'last_updated_date_millis';
    this.report_status = '';
    this.roles = dataService.roles;
    this.showActions = false;
    this.showSpinner = false;
    this.to_date = '';
    this.toggleFilter = appService.toggleFilter();
    this.user = '';
    this.user_id = '';
    this.windowWidth = dataService.windowWidth;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', {
      page: this._location.path()
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.user_id = this.user.user_id;
        this._appService.eventEdit = false;
        this.events_message = 'Click on menu icon to filter/search data';
        this.events = [];

        if (this._dataService.fromState && this._dataService.fromState === 'events/manage') {
          if (this._appService.updatemsg) {
            this._appService.notify({ status: this._appService.updatestatus, msg: this._appService.updatemsg });
            this._appService.updatemsg = '';
            this._appService.updatestatus = '';
          }
          if (this._cacheService.getEventData()) {
            this.events = this._cacheService.getEventData();
            this.predicate = 'last_updated_date_millis';
            this.desc = true;
          }
        }
        this.date_format = this.user.date_format || 'dd-MMM-yyyy';
        new FooPicker({
          id: 'fromdate',
          dateFormat: this.date_format
        });
        new FooPicker({
          id: 'todate',
          dateFormat: this.date_format
        });
        new FooPicker({
          id: 'mfromdate',
          dateFormat: this.date_format
        });
        new FooPicker({
          id: 'mtodate',
          dateFormat: this.date_format
        });

        this.pushActions();
        this.loadObjectives();

        this.toggleFilter();
      }
    });
  }


  applyFilter() {
    if (this.from_date && this.to_date) {
      if (this._formatService.dateInMillis(this._formatService.parseDate(this.from_date.toString())) > this._formatService.dateInMillis(this._formatService.parseDate(this.to_date.toString()))) {
        this.from_date_msg = 'From date greater than To date';
        this.from_date = '';
        this.focus_from_date = true;
        return;
      }
    }
    this.from_date_msg = '';
    this.focus_from_date = false;
    this.toggleFilter();
    this.showSpinner = true;
    this.loadData();
  }

  copyEvent(e) {
    this._appService.copyEvent = true;
    this._appService.eventid = e.event_id;
    this._router.navigate(['events/manage']);
  }

  deleteEventLine(e?) {
    if (e) {
      this.deleteEvent = true;
      this.eventDetails = e;
    } else {
      this.deleteEvent = false;
      this.showSpinner = true;
      let endPoint = '/events/delete/', req: any = {};
      req.event_id = this.eventDetails.event_id;
      req.deleted_by = this.user.user_id;
      req.hostess_name = this.eventDetails.user_description;
      req.date = this._appService.today(0);
      req.customer_name = this.eventDetails.customer_name;
      req.event_name = this.eventDetails.event_name;
      req.hostess_id = this.eventDetails.hostess_id;
      req.event_date = this.eventDetails.event_date;
      this._httpService.httpRequest('POST', endPoint, req, (data) => {
        if (data === null || data === undefined) {
          this.showSpinner = false;
          this._appService.notify({ status: 1, msg: 'Server Error - deleteEventLine()' });
        } else {
          this.msg = data.msg + ' for event #' + this.eventDetails.event_id;
          this._appService.notify({ status: data.status, msg: this.msg });
          if (data.status === 0) {
            this.loadData();
          } else {
            this.showSpinner = false;
          }
        }
      });
    }
  }

  // Exports the table data into spreadsheet
  exportData() {
    this.toggleFilter();
    let exportData = this._orderBy.transform(this.events, this.predicate, this.desc),
      tableData: any = {}, tmpData = [], i, tmpObj, j;
    for (i = 0; i < exportData.length; i++) {
      tmpObj = {};
      tmpObj['Event #'] = { data: exportData[i].event_id };
      tmpObj['Created By'] = { data: exportData[i].creator_name };
      tmpObj['Agent Name'] = { data: exportData[i].name };
      tmpObj['Event Name'] = { data: exportData[i].event_name };
      tmpObj['Customer Name'] = { data: exportData[i].customer_name };
      tmpObj['Customer Number'] = { data: exportData[i].customer_number };
      tmpObj['Site Id'] = { data: exportData[i].party_site_id };
      tmpObj['Address 1'] = { data: exportData[i].address_1 };
      tmpObj['Hostess Name'] = { data: exportData[i].user_description };
      tmpObj['External Identification'] = { data: exportData[i].external_id };
      tmpObj['Event Date'] = { data: exportData[i].f_event_date };
      tmpObj['Last Updated Date'] = { data: exportData[i].f_last_updated_date };
      for (j = 0; j < this.objectives.length; j++) {
        tmpObj[this.objectives[j].objective_name + ' quantity'] = {
          data: exportData[i].target_quantities[j],
          align: 'right'
        };
      }
      tmpObj['Compenso Hostess'] = { data: exportData[i].f_compenso_hostess, align: 'right' };
      tmpObj.Status = { data: exportData[i].status };
      tmpObj.Reported = { data: exportData[i].report_count === 0 ? 'No' : 'Yes' };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Events', tableData, 'exportEvents');
  }

  filterData() {
    this.toggleFilter();
    this.focus_from_date = false;
    this.from_date_msg = '';
    this.mfocus_from_date = false;
  }

  loadData() {
    let endPoint = '/events/summary/', req: any = { user_id: '' };
    if (this.roles.isAgent) {
      req.user_id = this.user.user_id;
    } else if (!this.roles.isAdmin && !this.roles.isHostess && !this.roles.isManager && !this.roles.isAgency) {
      req.user_id = this.user.user_id;
    }
    req.created_by = '';
    req.from_date = this.from_date ? this._formatService.parseDate(this.from_date) : '';
    req.to_date = this.to_date ? this._formatService.parseDate(this.to_date) : '';
    req.mfrom_date = this.mfrom_date ? this._formatService.parseDate(this.mfrom_date) : '';
    req.mto_date = this.mto_date ? this._formatService.parseDate(this.mto_date) : '';
    req.event_status = this.event_status || '';
    req.report_status = this.report_status || '';
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadData()' });
      } else {
        if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
          return;
        }
        let i, j, k, target_quantities = [], flag,
          events = data.events,
          targets = data.targets;
        for (i = 0; i < events.length; i++) {
          events[i].f_event_date = this._formatService.formatDate(events[i].event_date);
          events[i].f_last_updated_date = this._formatService.formatDate(events[i].last_updated_date);
          events[i].last_updated_date_millis = this._formatService.dateInMillis(events[i].last_updated_date);
          events[i].event_date_millis = this._formatService.dateInMillis(events[i].event_date);
          events[i].external_id = events[i].external_identification !== null ? events[i].external_identification : '';
          events[i].f_compenso_hostess = events[i].compenso_hostess !== null ?
            this._formatService.formatNumber(events[i].compenso_hostess) : '';
          target_quantities = [];
          for (k = 0; k < this.objectives.length; k++) {
            flag = false;
            for (j = 0; j < targets.length; j++) {
              if (targets[j].event_id === events[i].event_id &&
                targets[j].event_objective_id === this.objectives[k].objective_id) {
                flag = true;
                target_quantities.push(targets[j].target_qty);
              }
            }
            if (!flag) {
              target_quantities.push(0);
            }
          }
          events[i].target_quantities = target_quantities;
        }

        this.showSpinner = false;
        this.predicate = 'last_updated_date_millis';
        this.desc = true;
        this.events = events;
        if (this.events.length === 0) {
          this.events_message = 'No data for selected filters';
        }
        this._cacheService.setEventData(events);
      }
      this.showSpinner = false;
    });
  }


  loadObjectives() {
    const endPoint = '/events/objectives/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadObjectives()' });
      } else {
        if (data.status === 1) {
          this._appService.notify({ status: data.status, msg: data.msg });
          return;
        }
        this.objectives = [];
        for (let i = 0; i < data.length; i++) {
          if (data[i].type === 'QUANTITY') {
            this.objectives.push(data[i]);
          }
        }
      }
    });
  }

  moveToCreate() {
    this._router.navigate(['events/manage']);
  }

  onEdit(d) {
    this._appService.eventEdit = true;
    this._appService.eventid = d.event_id;
    this._router.navigate(['events/manage']);
  }

  selectAction(state_name) {
    if (state_name) {
      this._router.navigate([state_name]);
    }
  }

  pushActions() {
    this.actions.push({ name: 'Create Event', label: 'events/manage' });
    this.actions.push({ name: 'Hostess Report', label: 'events/hostess/report' });
    if (!this.roles.isHostess) {
      this.actions.push({ name: 'View Report', label: 'events/reports/hostess' });
    }
    if (!this.roles.isAgency) {
      this.actions.push({ name: 'View Objectives', label: 'events/objectives/summary' });
      this.actions.push({ name: 'Create Objective', label: 'events/objectives/manage' });
    }
    if (this.roles.isAdmin || this.roles.isAgent) {
      this.actions.push({ name: 'Ambassador Visits', label: 'events/ambassador/summary' });
    }
  }

  // Table sorting
  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
    }
    this.events = this._orderBy.transform(this.events, this.predicate, this.desc);
  }

  viewObjectives() {
    this._router.navigate(['events/objectives/summary']);
  }

}
