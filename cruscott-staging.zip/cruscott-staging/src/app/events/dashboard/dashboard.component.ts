import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';

@Component({
  selector: 'app-events-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class EventDashboardComponent implements OnInit {
  private _cacheService: CacheService;
  private _router: Router;
  private _location: Location;
  private _window: any;

  cards: any[];
  cardRows: any;
  roles: any;

  constructor(cacheService: CacheService, dataService: DataService, router: Router, location: Location) {
    this._cacheService = cacheService;
    this._router = router;
    this._location = location;
    this._window = window;

    this.cards = [];
    this.roles = dataService.roles;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.generateCards();
      }
    });
  }

  generateCards() {
    this.cards = [];
    if (!this.roles.isAgency && (this.roles.isAdmin || this.roles.isManager || this.roles.UIStands)) {
      this.cards.push({ name: 'Stands', title: 'View and reserve stands', state: 'events/stands' });
    }

    if (this.roles.isAdmin || this.roles.isManager || this.roles.isAgent || this.roles.isAgency) {
      this.cards.push({ name: 'Events', title: 'Create and update events', state: 'events/summary' });
    }

    this.cards.push({ name: 'Hostess', title: 'Create or update report and create hostess', state: 'events/hostess/report' });

    if (!this.roles.isAgency && (this.roles.isAdmin || this.roles.isAgent)) {
      this.cards.push({ name: 'Ambassador', title: 'Create and update store visits', state: 'events/ambassador/summary' });
    }

    if (!this.roles.isAgency && (this.roles.isAdmin || this.roles.isManager)) {
      this.cards.push({ name: 'Reports', title: 'View stand, event, hostess and ambassador reports', state: 'events/reports' });
    }

    let cardRows = [], row = [], i;
    for (i = 0; i < this.cards.length; i++) {
      if (i > 0 && i % 4 === 0) {
        cardRows.push(row);
        row = [];
      }
      row.push(this.cards[i]);
    }
    if (row && row.length > 0) {
      cardRows.push(row);
    }

    this.cardRows = cardRows;
  }

  goToState(state) {
    this._router.navigate([state]);
  }
}
