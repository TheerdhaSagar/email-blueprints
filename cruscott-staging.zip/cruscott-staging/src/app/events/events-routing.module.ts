import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EventDashboardComponent } from './dashboard/dashboard.component';
import { AmbassadorScreenComponent } from './ambassador/screen/screen.component';
import { AmbassadorSummaryComponent } from './ambassador/ambassador.component';
import { EventCreationComponent } from './create/create.component';
import { CreateHostessComponent } from './hostess/create/create.component';
import { HostessUsersComponent } from './hostess/users/users.component';
import { HostessComponent } from './hostess/hostess.component';
import { ObjectiveSummaryComponent } from './objective/summary/summary.component';
import { ObjectiveComponent } from './objective/objective.component';
import { HostessReportSummaryComponent } from './reports/hostess/summary/summary.component';
import { HostessReportComponent } from './reports/hostess/hostess.component';
import { EventReportComponent } from './reports/reports.component';
import { StandReportComponent } from './reports/stand/stand.component';
import { BookStandComponent } from './stands/book/book.component';
import { StandComponent } from './stands/stands.component';
import { EventSummaryComponent } from './summary/summary.component';

const routes: Routes = [
  { path: 'ambassador/manage', component: AmbassadorScreenComponent },
  { path: 'ambassador/summary', component: AmbassadorSummaryComponent },
  { path: 'stands/manage', component: BookStandComponent },
  { path: 'hostess/create', component: CreateHostessComponent },
  { path: 'manage', component: EventCreationComponent },
  { path: 'dashboard', component: EventDashboardComponent },
  { path: 'reports', component: EventReportComponent },
  { path: 'summary', component: EventSummaryComponent },
  { path: 'hostess/report/manage', component: HostessComponent },
  { path: 'hostess/report', component: HostessReportComponent },
  { path: 'reports/hostess', component: HostessReportSummaryComponent },
  { path: 'hostess', component: HostessUsersComponent },
  { path: 'objectives/manage', component: ObjectiveComponent },
  { path: 'objectives/summary', component: ObjectiveSummaryComponent },
  { path: 'stands', component: StandComponent },
  { path: 'reports/stand', component: StandReportComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EventsRoutingModule {}
