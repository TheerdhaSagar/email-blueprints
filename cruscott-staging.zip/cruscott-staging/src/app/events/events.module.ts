import { NgModule } from '@angular/core';

import { EventsRoutingModule } from './events-routing.module';
import { ShareModule } from '../share/share.module';
import { AmbassadorScreenComponent } from './ambassador/screen/screen.component';
import { AmbassadorSummaryComponent } from './ambassador/ambassador.component';
import { BookStandComponent } from './stands/book/book.component';
import { CreateHostessComponent } from './hostess/create/create.component';
import { EventCreationComponent } from './create/create.component';
import { EventDashboardComponent } from './dashboard/dashboard.component';
import { EventReportComponent } from './reports/reports.component';
import { EventSummaryComponent } from './summary/summary.component';
import { HostessComponent } from './hostess/hostess.component';
import { HostessReportComponent } from './reports/hostess/hostess.component';
import { HostessReportSummaryComponent } from './reports/hostess/summary/summary.component';
import { HostessUsersComponent } from './hostess/users/users.component';
import { ObjectiveComponent } from './objective/objective.component';
import { ObjectiveSummaryComponent } from './objective/summary/summary.component';
import { StandComponent } from './stands/stands.component';
import { StandReportComponent } from './reports/stand/stand.component';

@NgModule({
  declarations: [
    AmbassadorScreenComponent,
    AmbassadorSummaryComponent,
    BookStandComponent,
    CreateHostessComponent,
    EventCreationComponent,
    EventDashboardComponent,
    EventReportComponent,
    EventSummaryComponent,
    HostessComponent,
    HostessReportComponent,
    HostessReportSummaryComponent,
    HostessUsersComponent,
    ObjectiveSummaryComponent,
    ObjectiveComponent,
    StandComponent,
    StandReportComponent
  ],
  imports: [
    ShareModule,
    EventsRoutingModule
  ]
})
export class EventsModule { }
