import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { DataService } from '../../../globals/data.service';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { APIError } from '../../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-events-ambassador-screen',
  templateUrl: './screen.component.html',
  styleUrls: ['./screen.component.scss'],
})
export class AmbassadorScreenComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  agentName: any;
  cat_samples: any;
  clientreferences: any[];
  clinicName: any;
  comments: any;
  contactPerson: any;
  count = 0;
  customernames: any[];
  customers: any[];
  deleteReference: boolean;
  deletedreference: any;
  dog_samples: any;
  focusClinic: any;
  focusDate: boolean;
  focusPerson: any;
  format: any;
  isEdit: any;
  msg: any;
  prescription: any;
  reportId: any;
  roles: any;
  samplekit: any;
  samplesQuantity: any;
  selectedCustomer: any;
  showSpinner: any;
  status: any;
  toggleFilter: (e?) => void;
  user: any;
  userDateFormat: any;
  visitDate: any;

  constructor(
    appService: AppService,
    cacheService: CacheService,
    dataService: DataService,
    formatService: FormatService,
    httpService: HttpService,
    location: Location,
    router: Router
  ) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.agentName = null;
    this.cat_samples = 0;
    this.clientreferences = [];
    this.clinicName = null;
    this.comments = null;
    this.contactPerson = null;
    this.count = 0;
    this.customernames = [];
    this.customers = [];
    this.deleteReference = false;
    this.deletedreference = '';
    this.dog_samples = 0;
    this.focusClinic = null;
    this.focusDate = true;
    this.focusPerson = null;
    this.format = null;
    this.isEdit = this._appService.ambassadorEdit;
    this.msg = '';
    this.prescription = null;
    this.reportId = null;
    this.roles = dataService.roles;
    this.samplekit = null;
    this.samplesQuantity = null;
    this.selectedCustomer = '';
    this.showSpinner = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.userDateFormat = null;
    this.visitDate = null;

    /* app helpers */
    this._appService.ambassadorMsg = '';
    this._appService.ambassadorStatus = '';
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', {
      page: this._location.path(),
    });

    // user
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.format = this.user.date_format
          ? this.user.date_format
          : 'dd-MMM-yyyy';
        this.agentName = this.user.user_description;
        new FooPicker({
          id: 'visitDate',
          dateFormat: this.format,
        });
        this.userDateFormat = this.user.date_format;
        // this.toggleFilter = appService.toggleFilter();
        this.loadCustomers();
        if (this._appService.ambassadorEdit) {
          this.loadEditCustomers();
        }
      }
    });
  }

  $doCheck() {
    this.samplesQuantity =
      parseInt(this.samplesQuantity) > 0 ? parseInt(this.samplesQuantity) : '';
    this.dog_samples =
      parseInt(this.dog_samples) > 0 ? parseInt(this.dog_samples) : '';
    this.cat_samples =
      parseInt(this.cat_samples) > 0 ? parseInt(this.cat_samples) : '';
  }

  deleteClients() {
    let flag, i, j;
    this.customernames = [];
    for (i = 0; i < this.customers.length; i++) {
      flag = 0;
      for (j = 0; j < this.clientreferences.length; j++) {
        if (
          this.customers[i].cust_account_id ===
          this.clientreferences[j].customerid
        ) {
          flag = 1;
          break;
        }
      }
      if (flag === 0) {
        this.customernames.push(this.customers[i]);
      }
    }
  }

  getCustomerName() {
    let clientreference, index;
    if (this.clientreferences.length < 5) {
      if (this.customernames) {
        index = this.customernames
          .map((x) => x.cust_account_id)
          .indexOf(parseInt(this.selectedCustomer));
        if (index !== -1) {
          clientreference = {};
          clientreference.customername =
            this.customernames[index].customer_name;
          clientreference.customerid =
            this.customernames[index].cust_account_id;
          clientreference.id = this.count;
          this.clientreferences.push(clientreference);
          this.selectedCustomer = '';
          this.deleteClients();
          this.count++;
        }
      }
    } else {
      this.selectedCustomer = '';
    }
  }

  loadCustomers() {
    let endPoint =
      '/customer/list/' +
      this.user.user_id +
      '/' +
      this._cacheService.getOrgId() +
      '/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadCustomers',
          });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else if (data.length > 0) {
          this.customernames = data;
          this.customers = data;
          if (this.isEdit) {
            this.deleteClients();
          }
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadEditCustomers() {
    this.showSpinner = true;
    this.contactPerson = this._appService.contactPerson;
    this.clinicName = this._appService.clinicName;
    this.visitDate = this._appService.visitDate;
    this.agentName = this._appService.agentName;
    this.prescription = this._appService.prescription;
    this.samplesQuantity = this._appService.samplesQuantity || '';
    this.samplekit = this._appService.kit;
    this.comments = this._appService.comments || '';
    this.reportId = this._appService.reportId;
    this.cat_samples = this._appService.cat_samples;
    this.dog_samples = this._appService.dog_samples;

    let endPoint = '/events/ambassador/clients/' + this.reportId + '/';

    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadEditCustomers',
          });
        } else {
          this.msg = data.msg;
          this.status = data.status;

          if (data.length > 0) {
            this.clientreferences = [];
            for (let i = 0; i < data.length; i++) {
              this.clientreferences.push({
                customername: data[i].customer_name,
                customerid: data[i].cust_account_id,
                id: this.count++,
              });
            }
          }
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  onSave() {
    this.showSpinner = true;
    let client,
      endPoint = '/events/ambassador/',
      i,
      req: any = {};
    req.salesrep_id = this.user.salesrep_id;
    req.agent_name = this.user.user_name;
    if (this.visitDate && this.clinicName && this.contactPerson) {
      req.clinic_name = this.clinicName;
      req.contact_person = this.contactPerson;
      req.address = '';
      req.visit_date = this._formatService.parseDate(
        jQuery('#visitDate').val()
      );
    } else {
      if (!this.clinicName) {
        this.focusPerson = false;
      }
      if (!this.contactPerson) {
        this.focusClinic = false;
      }
      if (!jQuery('#visitDate').val()) {
        this.focusDate = false;
      }
      this.showSpinner = false;
      return false;
    }

    if (this.prescription) {
      req.prescription = this.prescription;
    } else {
      req.prescription = 'N';
    }

    if (this.samplekit) {
      req.kit = this.samplekit;
    } else {
      req.kit = 'N';
    }

    req.free_samples_qty = parseInt(this.samplesQuantity) || '';
    req.comments = this.comments || '';
    req.dog_samples = this.dog_samples || '';
    req.cat_samples = this.cat_samples || '';
    req.creation_date = this._appService.today(0);
    req.clients = [];
    if (this.clientreferences.length > 0) {
      for (i = 0; i < this.clientreferences.length; i++) {
        client = {};
        client.cust_account_id = this.clientreferences[i].customerid;
        client.customer_name = this.clientreferences[i].customername;
        client.creation_date = this._appService.today(0);
        req.clients.push(client);
      }
    } else {
      req.clients = [];
    }
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - onSave' });
        } else if (data.status === 0) {
          this._router.navigate(['events/ambassador/summary']);
          this._appService.ambassadorMsg = data.msg;
          this._appService.ambassadorStatus = data.status;
        } else {
          this._appService.notify({
            status: data.status,
            msg: data.msg,
          });
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  onUpdate() {
    this.showSpinner = true;
    let client,
      endPoint = '/events/ambassador/',
      i,
      req: any = {};
    req.report_id = this.reportId;
    req.salesrep_id = this.user.salesrep_id;
    req.agent_name = this._appService.agentName;
    if (this.clinicName && this.contactPerson && this.visitDate) {
      req.clinic_name = this.clinicName;
      req.contact_person = this.contactPerson;
      req.visit_date = this._formatService.parseDate(
        jQuery('#visitDate').val()
      );
      req.address = '';
    } else {
      if (this.clinicName) {
        this.focusPerson = false;
      }
      if (this.contactPerson) {
        this.focusClinic = false;
      }
      if (!jQuery('#visitDate').val()) {
        this.focusDate = false;
      }
      this.showSpinner = false;
      return false;
    }

    req.prescription = this.prescription;
    req.free_samples_qty = parseInt(this.samplesQuantity) || '';
    req.comments = this.comments || '';
    req.dog_samples = this.dog_samples || '';
    req.cat_samples = this.cat_samples || '';
    req.kit = this.samplekit;
    req.clients = [];
    if (this.clientreferences.length > 0) {
      for (i = 0; i < this.clientreferences.length; i++) {
        client = {};
        client.cust_account_id = this.clientreferences[i].customerid;
        client.customer_name = this.clientreferences[i].customername;
        client.creation_date = this._appService.today(0);
        req.clients.push(client);
      }
    } else {
      req.clients.push();
    }

    this._httpService.httpRequest('PUT', endPoint, req, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - onUpdate',
          });
        } else if (data.status === 0) {
          this._appService.ambassadorMsg =
            data.msg + ' ' + 'for' + ' ' + '#report' + ' ' + this.reportId;
          this._appService.ambassadorStatus = data.status;
          this._router.navigate(['events/ambassador/summary']);
        } else {
          this._appService.notify({
            status: data.status,
            msg: data.msg,
          });
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
    this._appService.ambassadorEdit = false;
  }

  previousState() {
    this._router.navigate(['events/ambassador/summary']);
  }

  removeCustomer(i?) {
    if (i) {
      this.deleteReference = true;
      this.deletedreference = i;
    } else {
      let e, index;
      e = this.deletedreference;
      this.deletedreference = '';
      this.deleteReference = false;
      index = this.clientreferences.map((x) => x.id).indexOf(parseInt(e.id));
      if (index !== -1) {
        this.clientreferences.splice(index, 1);
      }
      if (this.clientreferences.length > 0) {
        this.deleteClients();
      } else {
        this.customernames = this.customers;
      }
    }
  }

  totalSamples() {
    this.samplesQuantity = this.cat_samples + this.dog_samples;
  }
}
