import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { Component, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-events-ambassador',
  templateUrl: './ambassador.component.html',
  styleUrls: ['./ambassador.component.scss'],
  providers: [OrderByPipe]
})
export class AmbassadorSummaryComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  actions: any[];
  containermsg: any;
  desc: boolean;
  format: any;
  predicate = 'report_id';
  roles: any;
  searchAmbassador: any;
  searchQuery: any;
  showActions: any;
  showSpinner: boolean;
  status: any;
  toggleFilter: (e?) => void;
  user: any;
  userDateFormat: any;
  visit_from_date: any;
  visit_to_date: any;
  visitdata: any;
  visitDate: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService,
              orderBy: OrderByPipe, formatService: FormatService, httpService: HttpService,
              location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.actions = [];
    this.containermsg = '';
    this.desc = true;
    this.format = null;
    this.predicate = 'report_id';
    this.roles = dataService.roles;
    this.searchQuery = null;
    this.showSpinner = false;
    this.status = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.userDateFormat = null;
    this.visit_from_date = null;
    this.visit_to_date = null;
    this.visitdata = null;

    /* app helpers */
    this._appService.ambassadorEdit = false;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', {
      page: this._location.path()
    });

    if (this.roles.isAgent) {
      this.actions.push({
        name: 'Create New Ambassador',
        label: 'events/ambassador/manage'
      });
    }
    this.actions.push({
      name: 'Create Event',
      label: 'events/manage'
    });
    this.actions.push({
      name: 'Event Summary',
      label: 'events/summary'
    });
    this.actions.push({
      name: 'Hostess Report',
      label: 'events/hostess/report'
    });
    /* couldn't understand kept in comments 'isHostess' */
    if (!this.roles.isHostess) {
      this.actions.push({ name: 'View Report', label: 'events/reports/hostess' });
    }
    if (!this.roles.isAgency) {
      this.actions.push({
        name: 'View Objectives',
        label: 'events/objectives/summary'
      });
      this.actions.push({
        name: 'Create Objective',
        label: 'events/objectives/manage'
      });
    }

    // user
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.userDateFormat = this.user.date_format ? this.user.date_format : '';
        this.format = this.user.date_format ? this.user.date_format : 'dd-MMM-yyyy';
        new FooPicker({
          id: 'fromdate',
          dateFormat: this.format
        });
        new FooPicker({
          id: 'todate',
          dateFormat: this.format
        });

        jQuery('#foopicker-fromdate').addClass('showdatepicker');
        jQuery('#foopicker-todate').addClass('showdatepicker');

        if (this._dataService.fromState && this._dataService.fromState === '/events/ambassador/manage') {
          if (this._cacheService.getAmbassadorSummary()) {
            this.visitdata = this._cacheService.getAmbassadorSummary();
            this.showSpinner = false;
          }
          if (this._appService.visitfromdate) {
            this.visit_from_date = this._appService.visitfromdate;
          }
          if (this._appService.visittodate) {
            this.visit_to_date = this._appService.visittodate;
          }
          if (this._appService.ambassadorMsg) {
            this._appService.notify({
              status: this._appService.ambassadorStatus,
              msg: this._appService.ambassadorMsg
            });
            this._appService.ambassadorMsg = '';
            this._appService.ambassadorStatus = '';
          }
        }
        this.showSpinner = true;
        this.loadData();

        // this.toggleFilter = this._appService.toggleFilter();
      }
    });
  }

  createScreen() {
    this._router.navigate(['events/ambassador/manage']);
  }

  // Exports the table data into spreadsheet

  exportToExcel() {
    this.toggleFilter();
    let exportdata = this._orderBy.transform(this.visitdata, this.predicate, this.desc),
      i, tableData: any = {},
      tmpData = [],
      tmpObj;
    for (i = 0; i < exportdata.length; i++) {
      tmpObj = {};
      tmpObj['Report #'] = {
        data: exportdata[i].report_id
      };
      tmpObj.Agente = {
        data: exportdata[i].agent_name
      };
      tmpObj['Data Visita'] = {
        data: exportdata[i].visit_date_new
      };
      tmpObj['Ragione Sociale Clinica'] = {
        data: exportdata[i].clinic_name
      };
      tmpObj['Nome Del Veterinario'] = {
        data: exportdata[i].contact_person
      };
      tmpObj.Prescrizione = {
        data: exportdata[i].prescription
      };
      tmpObj['Free Sample Qty'] = {
        data: exportdata[i].free_samples_qty,
        align: 'right'
      };
      tmpObj['Vendita Kit Vet'] = {
        data: exportdata[i].kit
      };
      tmpObj.Commenti = {
        data: exportdata[i].comments
      };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Visit Data', tableData, 'export-visits');
  }

  loadData() {
    let endPoint = '/events/ambassador/';
    if (this.roles.isAgent) {
      endPoint += this.user.salesrep_id + '/';
    }

    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadData'
          });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          for (let i = 0; i < data.length; i++) {
            if (data[i].visit_date) {
              data[i].visit_date_new = this._formatService.formatDate(data[i].visit_date);
              data[i].visit_date_millis = this._formatService.dateInMillis(data[i].visit_date);
            }
          }
          this.visitdata = data;
          this._cacheService.setAmbassadorSummary(this.visitdata);
        }
      } catch (e) {
        // TODO error
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    });
  }

  loadSummary() {
    this.containermsg = '';
    this.showSpinner = true;
    if (jQuery('#fromdate').val()) {
      let endPoint = '/events/ambassador/search/',
        i, req: any = {};
      req.start_date = this._formatService.parseDate(jQuery('#fromdate').val());
      if (jQuery('#todate').val()) {
        if (this._formatService.dateInMillis(jQuery('#fromdate').val()) > this._formatService.dateInMillis(jQuery('#todate').val())) {
          this.containermsg = 'Enter valid dates';
          jQuery('#fromdate').val('');
          jQuery('#todate').val('');
          this.visit_to_date = '';
          this.visit_from_date = '';
          this.status = 1;
          this.showSpinner = false;
          return false;
        }
      }
      this.toggleFilter();
      req.end_date = jQuery('#todate').val() ? this._formatService.parseDate(jQuery('#todate').val()) : this._appService.today(0);
      this.visit_to_date = this._formatService.formatDate(this._appService.today(0));
      this.visit_from_date = jQuery('#fromdate').val();
      this._appService.visitfromdate = jQuery('#fromdate').val();
      this._appService.visittodate = jQuery('#todate').val() ? jQuery('#todate').val() : this._formatService.formatDate(this._appService.today(0));
      req.salesrep_id = this.roles.isAgent ? this.user.salesrep_id : '';
      this._httpService.httpRequest('POST', endPoint, req, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: 'Server Error - loadSummary'
            });
          } else if (data.status === 1) {
            this._appService.notify(new APIError(data.msg));
          } else {
            this.visitDate = '';
            this.showSpinner = false;
            for (i = 0; i < data.length; i++) {
              if (data[i].visit_date) {
                data[i].visit_date_new = this._formatService.formatDate(data[i].visit_date);
                data[i].visit_date_millis = this._formatService.dateInMillis(data[i].visit_date);
              }
            }
            this.visitdata = data;
            this._cacheService.setAmbassadorSummary(this.visitdata);
          }
        } catch (e) {
          // TODO error
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    } else if (jQuery('#todate').val() && !jQuery('#fromdate').val()) {
      this.containermsg = 'Enter from date';
      this.status = 1;
      this.showSpinner = false;
      return false;
    } else {
      this.toggleFilter();
      this.loadData();
    }
  }

  onEdit(d) {
    this._router.navigate(['events/ambassador/manage']);
    this._appService.ambassadorEdit = true;
    this._appService.clinicName = d.clinic_name;
    this._appService.contactPerson = d.contact_person;
    this._appService.visitDate = this._formatService.formatDate(d.visit_date);
    this._appService.prescription = d.prescription;
    this._appService.samplesQuantity = d.free_samples_qty;
    this._appService.kit = d.kit;
    this._appService.comments = d.comments;
    this._appService.reportId = d.report_id;
    this._appService.agentName = d.agent_name;
    this._appService.cat_samples = d.cat_quantity;
    this._appService.dog_samples = d.dog_quantity;
  }

  selectAction(state_name) {
    if (state_name) {
      this._router.navigate([state_name]);
    }
  }

  // Table sorting
  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
    }
    if (this.searchQuery && this.searchQuery.length > 0) {
      let tmpData = this._orderBy.transform(this.visitdata, this.predicate, this.desc);
      this.visitdata = tmpData;
    } else {
      this.visitdata = this._orderBy.transform(this.visitdata, this.predicate, this.desc);
    }
  }
}
