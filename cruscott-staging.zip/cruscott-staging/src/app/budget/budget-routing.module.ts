import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BudgetLinesComponent } from './budget-lines/budget-lines.component';
import { AlmoBudgetComponent } from './budget/budget.component';
import { BudgetDashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
  { path: 'dashboard', component: BudgetDashboardComponent },
  { path: ':budgetType', component: AlmoBudgetComponent },
  { path: 'details/:budgetType', component: BudgetLinesComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BudgetRoutingModule {}
