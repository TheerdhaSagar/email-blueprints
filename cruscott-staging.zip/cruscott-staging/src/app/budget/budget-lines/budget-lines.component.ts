import { Component, Injector, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';
import { BudgetService } from '../service/budget.service';
import { Segment } from '../models/segment';
import { OrderByPipe } from 'src/app/globals/order-by.pipe';

@Component({
  selector: 'app-budget-lines',
  templateUrl: './budget-lines.component.html',
  styleUrls: ['./budget-lines.component.scss'],
})
export class BudgetLinesComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _budgetService: BudgetService = this.injector.get(BudgetService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _router: Router = this.injector.get(Router);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _window: any;

  allSegments: Segment[];
  budgetId: any;
  budgetName: any;
  desc: boolean;
  deleteDialog: boolean;
  deleteItem: any;
  filterSegments: Segment[];
  focusInsert: boolean;
  insertDialog: boolean;
  itemAlert: boolean;
  lines: any[];
  newItem = { item_code: '', sales_price: '', segment: '', segment_num: null };
  param = 'item';
  predicate = 'item_code';
  projectType = 'I';
  salesGroup: any;
  showSpinner: boolean;
  toggleFilter: any;
  user: any;
  editedLine: any;

  constructor(private injector: Injector) {
    this._window = window;

    this.budgetId = '';
    this.budgetName = '';
    this.desc = false;
    this.deleteDialog = false;
    this.deleteItem = '';
    this.focusInsert = false;
    this.insertDialog = false;
    this.itemAlert = false;
    this.lines = [];
    this.newItem = {
      item_code: '',
      sales_price: '',
      segment: '',
      segment_num: null,
    };
    this.predicate = 'item_code';
    this.salesGroup = '';
    this.showSpinner = true;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
  }

  ngOnInit(): void {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;

        if (!this._cacheService.user) {
          this._cacheService.initialize(this.user);
        }

        this.initRouteParam();

        this.budgetName = this._appService.budget.name;
        this.budgetId = this._appService.budget.id;
        this.salesGroup = this._appService.budget.sales_group;

        this._appService.budget = {
          name: '',
          id: '',
          sales_group: '',
        };
        if (this.projectType === 'S') {
          this.loadSegments();
          this.loadSegmentLines();
        } else {
          this.loadLines();
        }
      }
    });
  }

  cancelDelete(): void {
    this.deleteItem = '';
    this.deleteDialog = false;
  }

  cancelEdit(): void {
    const mapKey = this.projectType === 'I' ? 'item_code' : 'segment_num';
    const index = this.lines
      .map((x) => x[mapKey])
      .indexOf(this.editedLine[mapKey]);
    this.lines[index].sales_price = this.editedLine.sales_price;
    this.lines[index].edit = false;
  }

  cancelInsert(): void {
    this.newItem.item_code = '';
    this.newItem.sales_price = '';
    this.newItem.segment = '';
    this.newItem.segment_num = null;
    this.insertDialog = false;
    this.focusInsert = false;
  }

  deleteLine(line?): void {
    if (line) {
      this.deleteDialog = true;
      this.deleteItem = line;
    } else {
      this.deleteDialog = false;
      this.showSpinner = true;
      const deleteNum =
        this.projectType === 'I'
          ? this.deleteItem.item_code
          : this.deleteItem.segment_num;
      this._budgetService
        .deleteHeaderOrLines(this.projectType, this.budgetId, deleteNum)
        .then((data) => {
          this.deleteLineParse();
          this._appService.notify(data);
        })
        .catch((err) => {
          this._appService.notify(err);
        })
        .finally(() => {
          this.deleteItem = '';
          this.showSpinner = false;
          if (this.projectType === 'S') {
            this.loadSegmentLines();
          }
        });
    }
  }

  deleteLineParse(): void {
    const key = this.projectType === 'I' ? 'item_code' : 'segment_num';
    const index = this.lines.map((x) => x[key]).indexOf(this.deleteItem[key]);
    if (index !== -1) {
      this.lines.splice(index, 1);
    }
    if (this.projectType !== 'I') {
      const segmentDetails = this.allSegments.find(
        (segment) => segment.segment_num === this.deleteItem[key]
      );
      if (segmentDetails) {
        this.filterSegments.push(segmentDetails);
      }
    }
  }

  editLine(line): void {
    this.lines.forEach((lineDetails) => {
      lineDetails.edit = false;
    });
    this.editedLine = line;
    line.edit_price = line.f_sales_price;
    line.edit = true;
  }

  goTo(): void {
    this._router.navigate([`budget/${this.param}`]);
  }

  initRouteParam(): void {
    this._routeParams.params.subscribe((params) => {
      if (params.budgetType) {
        this.param = params.budgetType.toString();
        this.projectType = this.param === 'item' ? 'I' : 'S';
      }
    });

    if (!this._appService.budget) {
      this._router.navigate([`budget/${this.param}`]);
    }
  }

  insertLine(): void {
    if (
      (this.projectType === 'I' && !this.newItem.item_code) ||
      (this.projectType === 'S' && !this.newItem.segment_num) ||
      !this.newItem.sales_price
    ) {
      this.focusInsert = true;
      return;
    }

    const newLine: any = {};
    const mapKey = this.projectType === 'I' ? 'item_code' : 'segment_num';
    this.focusInsert = false;
    const index = this.lines
      .map((x) => x[mapKey])
      .indexOf(this.newItem[mapKey]);
    if (index !== -1) {
      this.insertDialog = false;
      this.itemAlert = true;
      this.newItem.sales_price = '';
      return;
    }
    this.showSpinner = true;
    newLine.item_code = this.newItem.item_code.toString();
    newLine.budget_id = this.budgetId;
    newLine.sales_price = this._formatService.parseNumber(
      this.newItem.sales_price
    );
    newLine.created_by = this.user.user_id;
    newLine.sales_group = this.salesGroup;
    newLine.sales_channel = this.salesGroup;
    if (this.projectType === 'S') {
      newLine.segment_num = this.newItem.segment_num;
      newLine.segment_name = this.allSegments.find(
        (segment) => segment.segment_num === this.newItem.segment_num
      ).segments;
      this.newItem.segment = this.allSegments.find(
        (segment) => segment.segment_num === this.newItem.segment_num
      ).segments;
    }
    this.insertDialog = false;
    this._budgetService
      .manageBudgetLine(this.projectType, newLine, 'POST')
      .then((data) => {
        this.lines.push({
          item_code: this.newItem.item_code,
          sales_price: this._formatService.formatNumber(
            this.newItem.sales_price,
            5
          ),
          f_sales_price: this.newItem.sales_price,
          segment_num: this.newItem.segment_num,
          segment_name: newLine.segment_name,
          budget_id: this.budgetId,
          group_name: this.salesGroup,
          item_description: data.item_description,
        });
        if (this.projectType === 'I') {
          this.lines.unshift();
        } else {
          this.lines = this._orderBy.transform(
            this.lines,
            'segment_num',
            false
          );
        }
        this._appService.notify(data);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.newItem = {
          item_code: '',
          sales_price: '',
          segment: '',
          segment_num: null,
        };
        if (this.projectType === 'S') {
          this.loadSegmentLines();
        }
        this.showSpinner = false;
      });
  }

  loadLines(): void {
    const endPoint = `/budget/${this.budgetId}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (!data) {
        this._appService.notify({
          msg: 'Server Error - loadLines()',
          status: 1,
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.parseLines(data);
      }
      this.showSpinner = false;
    });
  }

  loadSegments(): void {
    this._budgetService
      .getUniqueSegments()
      .then((data) => {
        this.allSegments = data;
        this.filterSegments = data;
        if (this.lines) {
          this.lines.forEach((line) => {
            this.filterSegments = this.filterSegments.filter(
              (segment) => segment.segment_num !== line.segment_num
            );
          });
        }
      })
      .catch((err) => {
        this._appService.notify(err);
      });
  }

  loadSegmentLines(): void {
    this._budgetService
      .getSegmentBudgetLines(this.budgetId)
      .then((data) => {
        this.parseLines(data);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
      });
  }

  parseLines(data): void {
    data.forEach((lineDetails) => {
      const line = lineDetails;
      line.f_sales_price = this._formatService.formatNumber(
        line.sales_price,
        5
      );
      if (this.filterSegments) {
        this.filterSegments = this.filterSegments.filter(
          (segment) => segment.segment_num !== lineDetails.segment_num
        );
      }
    });
    this.lines = this._orderBy.transform(data, 'segment_num', false);
  }

  sort(key) {
    if (key === this.predicate) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = false;
    }
  }

  updateLine(line): void {
    if (
      line.edit_price === '' ||
      line.edit_price === null ||
      line.edit_price === undefined
    ) {
      this.cancelEdit();
      this._appService.notify({ msg: 'Price cannot be empty', status: 1 });
      return;
    }
    const updatedLine = {
      item_code: line.item_code,
      budget_id: this.budgetId,
      sales_price: this._formatService.parseNumber(line.edit_price),
      segment_num: line.segment_num,
      segment_name: line.segment_name,
      created_by: this.user.user_id,
    };
    line.edit = false;
    this.showSpinner = true;
    this._budgetService
      .manageBudgetLine(this.projectType, updatedLine, 'PUT')
      .then((data) => {
        line.sales_price = this._formatService.parseNumber(line.edit_price);
        line.f_sales_price = this._formatService.formatNumber(
          line.sales_price,
          5
        );
        this._appService.notify(data);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
        if (this.projectType === 'S') {
          this.loadSegmentLines();
        }
      });
  }

  validateNumber(value) {
    value = value.toString();

    // if value starts with . / , append number with 0 decimal
    if (value && (value[0] === ',' || value[0] === '.')) {
      value = '0' + value;
    }
    if (value) {
      value = this._formatService.numberParser(value, 5);
    }
    return value;
  }
}
