import { Component, Injector, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CacheService } from 'src/app/globals/cache.service';
import { DataService } from 'src/app/globals/data.service';
import { User } from 'src/app/globals/user';
import { Roles } from 'src/app/objectives/roles';

@Component({
  selector: 'app-budget-dashboard',
  templateUrl: './dashboard.component.html',
})
export class BudgetDashboardComponent implements OnInit {
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _router: Router = this.injector.get(Router);

  cardRows: { name: string; state: string; subname: string; param?: string }[];
  roles: Roles;
  user: User;

  constructor(private injector: Injector) {
    this.cardRows = [];
    this.roles = this._dataService.roles;
    this.user = null;
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.setUpModules();
      }
    });
  }

  goToState(state, params?): void {
    if (params) {
      this._router.navigate([state], { queryParams: params });
    } else {
      this._router.navigate([state]);
    }
  }

  setUpModules() {
    this.cardRows = [
      {
        name: 'Items',
        state: 'budget/item',
        subname: '',
      },
      {
        name: 'Segments',
        state: 'budget/segment',
        subname: '',
      },
    ];
  }
}
