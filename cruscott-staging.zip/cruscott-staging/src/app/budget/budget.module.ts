import { NgModule } from '@angular/core';

import { BudgetRoutingModule } from './budget-routing.module';
import { AlmoBudgetComponent } from './budget/budget.component';
import { BudgetLinesComponent } from './budget-lines/budget-lines.component';
import { BudgetDashboardComponent } from './dashboard/dashboard.component';
import { ShareModule } from '../share/share.module';

@NgModule({
  declarations: [
    AlmoBudgetComponent,
    BudgetLinesComponent,
    BudgetDashboardComponent,
  ],
  imports: [ShareModule, BudgetRoutingModule],
})
export class BudgetModule {}
