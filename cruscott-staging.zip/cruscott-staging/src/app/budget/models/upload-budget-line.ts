export interface UploadBudgetLine {
  base64?: string;
  budget_name: string;
  created_by?: string;
  end_date: string;
  f_end_date?: string;
  f_start_date?: string;
  start_date: string;
  file_details: { base64: string; filename: string };
}
