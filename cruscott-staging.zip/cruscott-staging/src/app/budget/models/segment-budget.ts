export interface SegmentBudget {
  budget_id: number;
  budget_name: string;
  created_by?: number;
  end_date: string;
  sales_channel: string;
  start_date: string;
}
