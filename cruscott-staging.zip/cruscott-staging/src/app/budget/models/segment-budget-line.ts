export interface SegmentBudgetLine {
  budget_id: number;
  created_by?: number;
  group_name?: string;
  item_code?: string;
  sales_price: number;
  sales_channel?: string;
  segment_num?: number;
  segment_name?: string;
}
