export interface Segment {
  segment_num: number;
  segments: string;
}
