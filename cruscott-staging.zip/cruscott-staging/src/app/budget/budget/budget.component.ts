import {
  Component,
  ElementRef,
  Injector,
  OnInit,
  ViewChild,
} from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { BudgetService } from '../service/budget.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { environment } from '../../../environments/environment';

declare var FooPicker: any;

@Component({
  selector: 'app-almo-budget',
  templateUrl: './budget.component.html',
  styleUrls: ['./budget.component.scss'],
})
export class AlmoBudgetComponent implements OnInit {
  @ViewChild('budgetFile') budgetFile: ElementRef;
  private _appService: AppService = this.injector.get(AppService);
  private _budgetService: BudgetService = this.injector.get(BudgetService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _domSanitizer: DomSanitizer = this.injector.get(DomSanitizer);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _router: Router = this.injector.get(Router);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _window: any;

  budget = [];
  channel_prices = null;
  dateFormat = null;
  datesMsg = '';
  deleteDialog = false;
  desc = true;
  fileName = '';
  focusUpload = false;
  lines = null;
  mapDialog = false;
  mappedColumns = null;
  param = 'item';
  predicate = 'budget_id';
  projectType = 'I';
  safeDownloadUrl: SafeUrl;
  salesChannels: any;
  searchBudget: any;
  showSpinner = true;
  showUploadDialog = false;
  toggleFilter: any;
  user: any;
  uploadDetails: any;
  deletedBudget: any;
  data: any;
  url = environment.url;

  constructor(private injector: Injector) {
    this._window = window;

    this.budget = [];
    this.channel_prices = null;
    this.dateFormat = null;
    this.datesMsg = '';
    this.deleteDialog = false;
    this.desc = true;
    this.focusUpload = false;
    this.lines = null;
    this.mapDialog = false;
    this.mappedColumns = null;
    this.predicate = 'budget_id';
    this.salesChannels = '';
    this.showSpinner = true;
    this.showUploadDialog = false;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.uploadDetails = {
      budget_name: '',
      start_date: '',
      end_date: '',
      file_details: '',
    };
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', {
      page: this._location.path(),
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.dateFormat = this.user.date_format || 'dd-MM-yyyy';

        setTimeout(() => {
          ((): void =>
            new FooPicker({
              id: 'start-date',
              dateFormat: this.dateFormat,
            }))();

          ((): void =>
            new FooPicker({
              id: 'end-date',
              dateFormat: this.dateFormat,
            }))();
        });
        this._routeParams.params.subscribe((params) => {
          if (params.budgetType) {
            this.param = params.budgetType.toString();
            this.projectType = this.param === 'item' ? 'I' : 'S';
          }
        });
        if (this.projectType === 'I') {
          this.loadHeader();
          this.loadChannels();
        } else {
          this.loadHeaderSegments();
          this.generateAndLoadSampleFile();
        }
      }
    });
  }

  backToUpload(): void {
    // Show map dialog to delete existing channels for selected dates
    this.datesMsg = '';
  }

  cancelMapping() {
    this.mapDialog = false;
    this.closeUpload();
  }

  closeDeleteDialog() {
    this.deletedBudget = '';
    this.deleteDialog = false;
  }

  closeUpload() {
    this.showUploadDialog = false;
    this.uploadDetails = {
      budget_name: '',
      start_date: '',
      end_date: '',
      file_details: '',
    };
    this.budgetFile.nativeElement.value = null;
    this.focusUpload = false;
  }

  deleteBudget(budget?) {
    if (budget) {
      this.deletedBudget = budget;
      this.deleteDialog = true;
    } else {
      const finalList = this.budget.slice();
      this.deleteDialog = false;
      this.showSpinner = true;
      this.budget = [];
      if (this.projectType === 'I') {
        this.deleteBudgetItems(finalList);
      } else {
        this.deleteBudgetSegments(finalList);
      }
    }
  }

  deleteBudgetItems(finalList): void {
    const endPoint = '/budget/header/' + this.deletedBudget.budget_id + '/';
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      if (!data) {
        this._appService.notify({
          msg: 'Server Error - deleteBudget()',
          status: 1,
        });
      } else {
        this._appService.notify({ msg: data.msg, status: data.status });
        if (data.status === 0) {
          this.deleteBudgetParse(finalList);
        }
      }
      this.showSpinner = false;
      this.deletedBudget = '';
    });
  }

  deleteBudgetParse(finalList): void {
    const index = finalList
      .map((x) => x.budget_id)
      .indexOf(this.deletedBudget.budget_id);
    if (index !== -1) {
      finalList.splice(index, 1);
    }
    this.budget = finalList;
  }

  deleteBudgetSegments(finalList): void {
    this._budgetService
      .deleteHeaderOrLines(this.projectType, this.deletedBudget.budget_id)
      .then((data) => {
        this._appService.notify(data);
        this.deleteBudgetParse(finalList);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.deletedBudget = '';
        this.showSpinner = false;
        this.loadHeaderSegments();
      });
  }

  downloadFile(fileName, downloadFileName): boolean {
    const link = document.getElementById('export-data') as HTMLAnchorElement;
    if (fileName) {
      this.safeDownloadUrl = this._domSanitizer.bypassSecurityTrustUrl(
        `${this.url}/cdn/?file_name=${fileName}&download_name=${downloadFileName}`
      );
      link.download = downloadFileName;
      setTimeout(() => {
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
      }, 250);
      link.click();
      return true;
    }
    return false;
  }

  generateAndLoadSampleFile(): void {
    this._budgetService
      .generateSampleFile()
      .then((data) => {
        this.fileName = data;
      })
      .catch((err) => {
        this._appService.notify({ status: 1, msg: 'Failed to generate Excel' });
      });
  }

  // Get channels already have budget for selected start and end dates
  getChannelsDates(save) {
    let channels = [],
      i,
      endPoint,
      obj: any = {};
    for (i = 0; i < this.mappedColumns.length; i++) {
      if (this.mappedColumns[i].excel_channel) {
        channels.push(this.mappedColumns[i].oracle_channel);
      }
    }
    obj.channels = channels;
    obj.start_date = this.uploadDetails.f_start_date;
    obj.end_date = this.uploadDetails.f_end_date;
    endPoint = '/budget/dates/';
    this.showSpinner = true;
    this._httpService.httpRequest('POST', endPoint, obj, (data) => {
      if (!data) {
        this.showSpinner = false;
        this._appService.notify({
          msg: 'Server Error - getChannelsDates()',
          status: 1,
        });
      } else if (data.status === 1) {
        this.showSpinner = false;
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.datesMsg = '';
        this.showUploadDialog = false;

        // To show alert with channels already have budget for selected dates
        if (data.length !== 0) {
          this.mapDialog = true;
          this.datesMsg = data
            .map((x) => x.sales_group_name)
            .join('</div><div>');
          this.datesMsg = '<div>' + this.datesMsg + '</div>';
          this.showSpinner = false;
        } else if (save) {
          this.map(save);
        }
      }
    });
  }

  // To add / remove selected / unselected channel from drop down
  getMappedChannels(channel?) {
    if (channel) {
      channel.excel_channel = '';
    }
    let i,
      j,
      index,
      list = [];
    for (i = 0; i < this.mappedColumns.length; i++) {
      list = [];
      for (j = 0; j < this.channel_prices.length; j++) {
        index = this.mappedColumns
          .map((x) => x.excel_channel)
          .indexOf(this.channel_prices[j].excel_channel.trim());
        if (
          index === -1 ||
          this.mappedColumns[i].excel_channel ===
            this.channel_prices[j].excel_channel.trim()
        ) {
          list.push(this.channel_prices[j].excel_channel.trim());
        }
      }
      this.mappedColumns[i].list = [...list];
    }
  }

  goToLines(budget) {
    this._appService.budget = {
      name: budget.budget_name,
      id: budget.budget_id,
      sales_group: budget.sales_group_name || budget.sales_channel,
    };
    this._router.navigate([`budget/details/${this.param}`]);
  }

  loadChannels() {
    const endPoint = '/metrics/cruscott/channels/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (!data) {
        this._appService.notify({
          msg: 'Server Error - loadChannels()',
          status: 1,
        });
      } else {
        if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        }
        this.showSpinner = false;
        this.salesChannels = data;
      }
    });
  }

  loadHeader() {
    const endPoint = `/budget/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          msg: 'Server Error - loadHeader()',
          status: 1,
        });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.parseHeader(data);
      }
      this.showSpinner = false;
    });
  }

  loadHeaderSegments(): void {
    this._budgetService
      .getSegmentBudgetSummary()
      .then((data) => {
        this.parseHeader(data);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
      });
  }

  map(save?) {
    this.showSpinner = true;
    const budgetLines: any = {};
    const lines = [];
    let channelsCount = 0;
    budgetLines.sales_channels = this.mappedColumns;
    budgetLines.budget_name = this.uploadDetails.budget_name;
    budgetLines.start_date = this.uploadDetails.f_start_date;
    budgetLines.end_date = this.uploadDetails.f_end_date;
    budgetLines.created_by = this.user.user_id;

    for (let i = 0; i < this.lines.length; i++) {
      lines.push({});
      lines[i].item_code = this.lines[i].code || '';
      this.mappedColumns.forEach((column) => {
        if (column.excel_channel) {
          channelsCount++;
          lines[i][column.oracle_channel] =
            this.lines[i][column.excel_channel] || '';
        }
      });

      // Show notification if any channel is not mapped
      if (!channelsCount) {
        this.showSpinner = false;
        this._appService.notify({
          msg: 'Map atleast one sales channels',
          status: 1,
        });
        return;
      }
    }

    // Get existing channels for selected dates after mapping columns
    if (!save) {
      this.getChannelsDates(true);
      return;
    }

    budgetLines.lines = lines;
    this.mapDialog = false;
    this.showSpinner = true;
    this.closeUpload();
    this._budgetService
      .uploadItemBudget(budgetLines)
      .then((data) => {
        this._appService.notify(data);
        this.loadHeader();
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
      });
  }

  mapColumns() {
    let index;
    // Get actual channel name for each channel in uploaded file
    for (let i = 0; i < this.salesChannels.length; i++) {
      this.mappedColumns.push({});
      this.mappedColumns[i].oracle_channel = this.salesChannels[i].group_name;
      this.mappedColumns[i].excel_channel = '';
      index = this.channel_prices
        .map((x) => x.excel_channel.trim().toLowerCase())
        .indexOf(this.salesChannels[i].group_name.toLowerCase());
      if (index !== -1) {
        this.mappedColumns[i].excel_channel = this.channel_prices[
          index
        ].excel_channel.trim();
      }
    }

    this.getMappedChannels();

    // Show dialog to map if all channels are not correctly mapped
    if (
      (this.mappedColumns[0].list.length > 1 &&
        this.mappedColumns[0].excel_channel) ||
      (this.mappedColumns[0].list.length > 0 &&
        !this.mappedColumns[0].excel_channel)
    ) {
      this.showSpinner = false;
      this.mapDialog = true;
    } else {
      this.getChannelsDates(true);
    }
  }

  parseHeader(data) {
    data.forEach((header) => {
      header.f_start_date = this._formatService.formatDate(header.start_date);
      header.start_date_millis = this._formatService.dateInMillis(
        header.start_date
      );
      header.f_end_date = this._formatService.formatDate(header.end_date);
      header.end_date_millis = this._formatService.dateInMillis(
        header.end_date
      );
    });
    this.budget = data;
  }

  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = true;
    }
  }

  uploadBudget() {
    if (
      !this.uploadDetails.budget_name ||
      !this.uploadDetails.start_date ||
      !this.uploadDetails.end_date ||
      !this.uploadDetails.file_details.filename
    ) {
      this.focusUpload = true;
      return;
    }
    const filename = this.uploadDetails.file_details.filename.split('.');
    if (
      filename.length < 2 ||
      (filename[filename.length - 1] !== 'xls' &&
        filename[filename.length - 1] !== 'xlsx')
    ) {
      this.uploadDetails.file_details.filename = '';
      this.uploadDetails.file_details = '';
      this.focusUpload = true;
      return;
    }

    this.uploadDetails.f_start_date = this._formatService.parseDate(
      this.uploadDetails.start_date
    );
    this.uploadDetails.f_end_date = this._formatService.parseDate(
      this.uploadDetails.end_date
    );

    if (
      this._formatService.dateInMillis(this.uploadDetails.f_start_date) >
      this._formatService.dateInMillis(this.uploadDetails.f_end_date)
    ) {
      this._appService.notify({
        msg: 'End date should be greater than start date',
        status: 1,
      });
      this.uploadDetails.end_date = '';
      this.uploadDetails.f_end_date = '';
      this.uploadDetails.base64 = this.uploadDetails.file_details.base64;
      this.focusUpload = true;
      return;
    }
    this.showSpinner = true;
    this.focusUpload = false;
    this.datesMsg = '';

    if (this.projectType === 'I') {
      this.uploadBudgetItems();
    } else {
      this.uploadBudgetSegments();
    }
  }

  uploadBudgetItems() {
    const endPoint = '/budget/read_file/';
    this._httpService.httpRequest(
      'POST',
      endPoint,
      this.uploadDetails,
      (data) => {
        if (!data) {
          this.closeUpload();
          this._appService.notify({
            msg: 'Server Error - uploadBudget()',
            status: 1,
          });
        } else if (data.status === 1) {
          this.closeUpload();
          this._appService.notify({ msg: data.msg, status: 1 });
          this.showSpinner = false;
        } else {
          this.data = data;
          this.channel_prices = [];
          this.mappedColumns = [];
          data.channel_prices.forEach((channel) => {
            this.channel_prices.push({
              excel_channel: channel,
              oracle_channel: '',
            });
          });
          this.lines = data.data;
          this.mapColumns();
        }
        this.showUploadDialog = false;
      }
    );
  }

  uploadBudgetSegments(): void {
    this.uploadDetails.start_date = this.uploadDetails.f_start_date;
    this.uploadDetails.end_date = this.uploadDetails.f_end_date;
    this.uploadDetails.base64 = this.uploadDetails.file_details.base64;
    this.uploadDetails.created_by = this.user.user_id;
    this._budgetService
      .uploadSegmentBudget(this.uploadDetails)
      .then((data) => {
        this._appService.notify(data);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.closeUpload();
        this.loadHeaderSegments();
        this.showUploadDialog = false;
      });
  }
}
