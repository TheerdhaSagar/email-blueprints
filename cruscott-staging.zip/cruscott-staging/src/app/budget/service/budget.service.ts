import { Injectable, Injector } from '@angular/core';
import { APIError } from 'src/app/globals/api.error';
import { HttpService } from 'src/app/globals/http.service';
import { ServerError } from 'src/app/globals/server.error';
import { Segment } from '../models/segment';
import { SegmentBudget } from '../models/segment-budget';
import { SegmentBudgetLine } from '../models/segment-budget-line';
import { UploadBudgetLine } from '../models/upload-budget-line';

@Injectable({
  providedIn: 'root',
})
export class BudgetService {
  private _httpService: HttpService = this.injector.get(HttpService);

  readonly URLPREFIX = '/budget';

  constructor(private injector: Injector) {}

  deleteHeaderOrLines(
    type: string,
    budgetId: number,
    segmentNum?: number
  ): Promise<Response> {
    const urlType = type === 'I' ? 'lines' : 'segment';
    let endPoint = `${this.URLPREFIX}/${urlType}/${budgetId}/`;
    if (segmentNum) {
      endPoint += `${segmentNum}/`;
    }
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - deleteSegmentHeader()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }

  generateSampleFile(): Promise<string> {
    const endPoint = `${this.URLPREFIX}/segment/sample/excel/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - generateSampleFile()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data.file_name);
        }
      });
    });
  }

  getSegmentBudgetLines(budgetId: number): Promise<SegmentBudgetLine[]> {
    const endPoint = `${this.URLPREFIX}/segment/lines/${budgetId}/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - getSegmentBudgetLines()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data.summary);
        }
      });
    });
  }

  getSegmentBudgetSummary(): Promise<SegmentBudget[]> {
    const endPoint = `${this.URLPREFIX}/segment/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - getSegmentBudgetSummary()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data.summary);
        }
      });
    });
  }

  getUniqueSegments(): Promise<Segment[]> {
    const endPoint = `${this.URLPREFIX}/segment/lov/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - getUniqueSegments()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data.segments);
        }
      });
    });
  }

  manageBudgetLine(
    type: string,
    requestObj: SegmentBudgetLine,
    method: string
  ): Promise<Response & { item_description?: string }> {
    let endPoint;
    if (type === 'I') {
      endPoint = `${this.URLPREFIX}/line/`;
    } else {
      endPoint = `${this.URLPREFIX}/segment/lines/`;
    }
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(method, endPoint, requestObj, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - manageBudgetLine()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }

  uploadItemBudget(budgetLines: UploadBudgetLine): Promise<Response> {
    const endPoint = `${this.URLPREFIX}/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', endPoint, budgetLines, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - uploadItemBudget()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }

  uploadSegmentBudget(requestObj: UploadBudgetLine): Promise<Response> {
    const endPoint = `${this.URLPREFIX}/segment/upload/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', endPoint, requestObj, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - uploadSegmentBudget()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }
}
