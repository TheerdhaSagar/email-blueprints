import { TestBed } from '@angular/core/testing';

import { CreditnotesService } from './creditnotes.service';

describe('CreditnotesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreditnotesService = TestBed.get(CreditnotesService);
    expect(service).toBeTruthy();
  });
});
