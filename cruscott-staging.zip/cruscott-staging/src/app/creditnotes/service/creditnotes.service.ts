import { Injectable, Injector } from '@angular/core';
import { APIError } from 'src/app/globals/api.error';
import { HttpService } from 'src/app/globals/http.service';
import { ServerError } from 'src/app/globals/server.error';

@Injectable({
  providedIn: 'root',
})
export class CreditnotesService {
  private _httpService: HttpService = this.injector.get(HttpService);

  readonly URL_PREFIX = '/creditNote';
  constructor(private injector: Injector) {}

  getInvoiceDetailsOfItem(
    requestObj
  ): Promise<{
    status: number;
    invoice_number: string;
    inventory_item_id: number;
    item_code: string;
  }> {
    const endPoint = `${this.URL_PREFIX}/customer/invoice/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', endPoint, requestObj, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - getInvoiceDetailsOfItem()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }
}
