import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreditSummaryComponent } from './summary/summary.component';
import { CreateNoteComponent } from './create/create.component';
import { DisputeComponent } from './dispute/dispute.component';
import { InvoiceComponent } from './invoice/invoice.component';

const routes: Routes = [
  { path: 'summary', component: CreditSummaryComponent },
  { path: 'create', component: CreateNoteComponent },
  { path: 'dispute', component: DisputeComponent },
  { path: 'invoice', component: InvoiceComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreditnotesRoutingModule { }
