import { NgModule } from '@angular/core';
import { ShareModule } from '../share/share.module';

import { CreditnotesRoutingModule } from './creditnotes-routing.module';
import { CreditSummaryComponent } from './summary/summary.component';
import { CreateNoteComponent } from './create/create.component';
import { DisputeComponent } from './dispute/dispute.component';
import { InvoiceComponent } from './invoice/invoice.component';

@NgModule({
  declarations: [
    CreditSummaryComponent,
    CreateNoteComponent,
    DisputeComponent,
    InvoiceComponent,
  ],
  imports: [ShareModule, CreditnotesRoutingModule],
})
export class CreditnotesModule {}
