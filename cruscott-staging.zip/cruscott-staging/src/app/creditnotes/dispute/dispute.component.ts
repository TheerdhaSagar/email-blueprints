import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';
import jQuery from 'jquery';
import { APIError } from '../../globals/api.error';

@Component({
  selector: 'app-creditnotes-dispute',
  templateUrl: './dispute.component.html',
  styleUrls: ['./dispute.component.scss'],
  providers: [OrderByPipe]
})
export class DisputeComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  amount_type: any;
  attaches: any[];
  attachments: any[];
  bill_to_site_use_id: any;
  cashDiscount: any;
  currency_code: any;
  cust_account_id: any;
  debit_description: any;
  debitToList: any;
  dispute_type_label: any;
  disputeFormatTotalAmt: any;
  disputeLines: any;
  disputeSaved: any;
  disputeStatus: any;
  disputeTotalAmount: any;
  due_date: any;
  finalDisputeLines: any[];
  flex_value_meaning: any;
  focusComment: any;
  focusCredit: any;
  focusDebit: any;
  focusInternalComment: any;
  focusReason: any;
  invoice_details: any;
  invoice_line_amount: any;
  invoice_number: any;
  invoiceDetails: any;
  msg: any;
  no_format: any;
  oldStatus: boolean;
  org_id: any;
  org: any;
  reason_code: any;
  reason_meaning: any;
  reasons: any[];
  selection: any;
  ship_to_site_use_id: any;
  subOrgChange: Subscription;
  tax_amount: any;
  transactions: any;
  user: any;
  windowWidth: any;
  steps: string[];
  totalParent: any;
  invoice_total: any;
  lines: boolean;
  payment_desc: any;
  hideAfterSave: boolean;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService,
              orderBy: OrderByPipe, formatService: FormatService, httpService: HttpService,
              location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.amount_type = null;
    this.attaches = [];
    this.attachments = [];
    this.bill_to_site_use_id = null;
    this.cashDiscount = null;
    this.currency_code = null;
    this.cust_account_id = null;
    this.debit_description = null;
    this.debitToList = null;
    this.dispute_type_label = null;
    this.disputeFormatTotalAmt = null;
    this.disputeLines = null;
    this.disputeSaved = null;
    this.disputeStatus = null;
    this.disputeTotalAmount = null;
    this.due_date = null;
    this.finalDisputeLines = [];
    this.flex_value_meaning = null;
    this.focusComment = null;
    this.focusCredit = null;
    this.focusDebit = null;
    this.focusInternalComment = null;
    this.focusReason = null;
    this.invoice_details = null;
    this.invoice_line_amount = null;
    this.invoice_number = null;
    this.invoiceDetails = null;
    this.msg = null;
    this.no_format = null;
    this.oldStatus = false;
    this.org_id = null;
    this.org = dataService.orgId;
    this.reason_code = null;
    this.reason_meaning = null;
    this.reasons = [];
    this.selection = null;
    this.ship_to_site_use_id = null;
    this.steps = ['dispute', 'item', 'preview'];
    this.subOrgChange = null;
    this.tax_amount = null;
    this.totalParent = {
      accured_currenct_year_flag: 'N',
      amount: '',
      applyFlag: 'N',
      attachError: '',
      attachment: [],
      cm_apply_flag: 'N',
      comments: '',
      customerName: '',
      debitToObj: '',
      disputeType: 'false',
      headerId: '',
      ic_credit_flag: '',
      internal_comment: '',
      msgStatus: '',
      no_salesrep_flag: 'N',
      reasonObj: '',
      showErrMsg: '',
      showError: false,
      showSuccess: '',
      total: ''
    };
    this.transactions = null;
    this.user = null;
    this.windowWidth = dataService.windowWidth;
  }

  ngOnInit() {
    this.setUpDOMHandlers();

    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.no_format = this.user.number_format || '999.999,99';
        this.disputeFormatTotalAmt = this._formatService.formatNumber(0);

        this.load();
        this.discountPercent();
      }
    });

    // redirect to creditnotes summary page
    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this._router.navigate(['creditnotes/summary']);
    });
    this.selection = this.steps[0];
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  static base64ToBlob(base64) {
    let byteString = atob(base64),
      // Convert text into a byte array.
      ab = new ArrayBuffer(byteString.length),
      ia = new Uint8Array(ab), i, dataBlob;
    for (i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    // Blob for saving.
    dataBlob = new Blob([ia], {
      type: 'octet/stream'
    });

    return dataBlob ? dataBlob : null;
  }

  // Calculate total amount based on given percentage or amount
  calculateAmount(type, inputTotal) {
    let org_total = this.invoice_details.line_amount,
      i, percent, amount, quantity;
    if (!type) {
      if (inputTotal > 0 && inputTotal <= org_total) {
        this.totalParent.total = this._formatService.formatNumber(inputTotal);
        percent = (inputTotal / org_total) * 100;
        for (i = 0; i < this.disputeLines.length; i++) {
          amount = (this.disputeLines[i].line_amount * percent) / 100;
          quantity = (amount / this.disputeLines[i].line_amount) * this.disputeLines[i].quantity_invoiced;
          if (quantity % 1 === 0) {
            this.disputeLines[i].disputeQuantity = quantity;
          } else {
            this.disputeLines[i].disputeQuantity = '';
          }
          this.disputeLines[i].disputeAmount = parseFloat(amount);
          this.disputeLines[i].disputePercent = parseFloat(percent);
          this.disputeLines[i].dispFormatPercent = this._formatService.formatNumber(percent);
          this.disputeLines[i].dispFormatAmt = this._formatService.formatNumber(amount);
        }
        this.updateTotal();
      } else if (inputTotal) {
        this.totalParent.total = '';
        DisputeComponent.resetValues(this.disputeLines);
        this.updateTotal();
        this.totalParent.msgStatus = true;
        this.msg = 'Disputed amount must be within Total Amount';
        this._appService.notify({
          status: 1,
          msg: this.msg
        });
      } else {
        this.totalParent.total = '';
        DisputeComponent.resetValues(this.disputeLines);
        this.updateTotal();
      }
    } else {
      if (inputTotal > 0 && inputTotal <= 100) {
        this.totalParent.total = this._formatService.formatNumber(inputTotal);
        for (i = 0; i < this.disputeLines.length; i++) {
          amount = (this.disputeLines[i].line_amount * inputTotal) / 100;
          quantity = (amount / this.disputeLines[i].line_amount) * this.disputeLines[i].quantity_invoiced;
          if (quantity % 1 === 0) {
            this.disputeLines[i].disputeQuantity = quantity;
          } else {
            this.disputeLines[i].disputeQuantity = '';
          }
          this.disputeLines[i].disputeAmount = parseFloat(amount);
          this.disputeLines[i].disputePercent = parseFloat(inputTotal);
          this.disputeLines[i].dispFormatPercent = this._formatService.formatNumber(inputTotal);
          this.disputeLines[i].dispFormatAmt = this._formatService.formatNumber(amount);
        }
        this.updateTotal();
      } else if (inputTotal) {
        this.totalParent.total = '';
        DisputeComponent.resetValues(this.disputeLines);
        this.updateTotal();
        this.totalParent.msgStatus = true;
        this.msg = 'Percentage should be in between 0 To 100';
        this._appService.notify({
          status: 1,
          msg: this.msg
        });
      } else {
        this.totalParent.total = '';
        DisputeComponent.resetValues(this.disputeLines);
        this.updateTotal();
      }
    }
  }

  // Calculates dispute for every item
  calculateTotal(inputTotal) {
    let type, value, comma_index, dot_index, no_comma_index,
      no_dot_index, point;

    this.totalParent.DisputeLinesError = false;
    this.totalParent.msgStatus = false;
    type = this.totalParent.amount === 'true';
    value = DisputeComponent.validatePattern(inputTotal);
    if (value) {
      comma_index = inputTotal.lastIndexOf(',');
      dot_index = inputTotal.lastIndexOf('.');
      no_comma_index = this.no_format.lastIndexOf(',');
      no_dot_index = this.no_format.lastIndexOf('.');
      if ((comma_index >= dot_index) && (no_comma_index >= no_dot_index)) {
        // If user number format is '999.999.999,99'
        point = inputTotal.lastIndexOf(',');
        // we need to replace ',' with '.'
        if (point !== -1) {
          inputTotal = DisputeComponent.replaceAt(inputTotal, point, '.');
          inputTotal = DisputeComponent.removeAllButLast(inputTotal, '.');
        }
        this.calculateAmount(type, inputTotal);
      } else if ((dot_index >= comma_index) && (no_dot_index >= no_comma_index)) {
        // If user number format is '999,999,999.99'
        inputTotal = parseFloat(inputTotal.replace(/,/g, ''));
        this.calculateAmount(type, inputTotal);
      } else {
        this.totalParent.total = '';
        DisputeComponent.resetValues(this.disputeLines);
        this.updateTotal();
        this.totalParent.msgStatus = true;
        this.msg = 'Check Your Number Format,It Should Be' + ' ' + this.no_format;
        this._appService.notify({
          status: 1,
          msg: this.msg
        });
      }
    } else if (!value && inputTotal) {
      this.totalParent.total = '';
      DisputeComponent.resetValues(this.disputeLines);
      this.updateTotal();
      this.totalParent.msgStatus = true;
      this.msg = 'Check Your Number Format,It Should Be' + ' ' + this.no_format;
      this._appService.notify({
        status: 1,
        msg: this.msg
      });
    } else {
      this.totalParent.total = '';
      DisputeComponent.resetValues(this.disputeLines);
      this.updateTotal();
    }
  }

  // Cancel Dispute
  cancelDispute() {
    this._router.navigate(['creditnotes/invoice']);
  }

  createJSONDispute() {
    let header: any = {}, // For storing header related values
      lines = [], // For storing lines related data
      files = [], // For storing files related data
      i, j, dict, attachment;

    header.customer_trx_id = this.invoiceDetails.customer_trx_id;
    header.line_credits_flag = 'Y';
    header.cm_reason_code = this.reason_code;
    header.COMMENTS = this.totalParent.comments;
    header.org_id = parseInt(this.org);
    header.last_update_date = this._appService.today(0);
    header.last_updated_by = this.user.user_id;
    header.creation_date = this._appService.today(0);
    header.created_by = this.user.user_id;
    header.last_update_login = this.user.user_id;
    header.total_amount = parseFloat((this.disputeTotalAmount * -1).toFixed(2));
    header.internal_comment = this.totalParent.internal_comment;
    // TODO
    header.ATTRIBUTE1 = '';
    header.ATTRIBUTE2 = this.cust_account_id ? this.cust_account_id : '';
    header.ATTRIBUTE3 = this.bill_to_site_use_id ? this.bill_to_site_use_id : '';
    header.ATTRIBUTE4 = this.ship_to_site_use_id ? this.ship_to_site_use_id : '';
    header.ATTRIBUTE5 = this.currency_code;
    header.ATTRIBUTE6 = this.reason_code;
    header.ATTRIBUTE8 = this.flex_value_meaning;
    header.ATTRIBUTE10 = this._appService.payment_term_id;
    header.ATTRIBUTE9 = this.totalParent.cm_apply_flag;
    header.ATTRIBUTE11 = this.totalParent.no_salesrep_flag;
    header.ATTRIBUTE12 = this.totalParent.accured_currenct_year_flag;
    if (parseInt(this.org) !== 82) {
      header.ATTRIBUTE13 = this.totalParent.ic_credit_flag;
    } else {
      header.ATTRIBUTE13 = '';
    }
    for (i = 0; i < this.finalDisputeLines.length; i++) {
      dict = {};
      dict.org_id = this.org;
      dict.last_update_date = this._appService.today(0);
      dict.last_updated_by = this.user.user_id;
      dict.creation_date = this._appService.today(0);
      dict.created_by = this.user.user_id;
      dict.last_update_login = this.user.user_id;
      dict.customer_trx_line_id = this.finalDisputeLines[i].customer_trx_line_id;
      dict.extended_amount = parseFloat(this.finalDisputeLines[i].disputeAmount.toFixed(2));
      dict.quantity = this.finalDisputeLines[i].disputeQuantity ? parseInt(this.finalDisputeLines[i].disputeQuantity) : '';
      dict.price = this.finalDisputeLines[i].unit_selling_price;
      // TODO
      dict.ATTRIBUTE1 = this.finalDisputeLines[i].segment1;
      dict.ATTRIBUTE2 = '';
      dict.ATTRIBUTE3 = this.finalDisputeLines[i].description;
      dict.ATTRIBUTE4 = this.flex_value_meaning === 'SAIMA' && this.finalDisputeLines[i].saima ? this.finalDisputeLines[i].saima.toString() : '';
      dict.ATTRIBUTE5 = this.flex_value_meaning === 'SAIMA' && this.finalDisputeLines[i].saimaAmount ? this._formatService.parseNumber(this.finalDisputeLines[i].saimaAmount).toString() : '';
      lines.push(dict);
    }
    if (this.attachments.length !== 0) {
      for (j = 0; j < this.attachments.length; j++) {
        attachment = {};
        attachment.base64 = this.attachments[j].base64;
        attachment.filename = this.attachments[j].filename;
        files.push(attachment);
      }
    }
    header.lines = lines;
    header.files = files;
    return header;
  }

  // Debit to change
  debitChange() {
    let index = this.debitToList.map(debit => debit.flex_value_meaning).indexOf(this.totalParent.debitToObj);
    if (index !== -1) {
      this.flex_value_meaning = this.totalParent.debitToObj; // store the latest option meaning
      this.debit_description = this.debitToList[index].description; // store the latest option description
      if (this.totalParent.debitToObj && this.debit_description !== 'SAIMA') {
        for (let i = 0; i < this.disputeLines.length; i++) {
          this.disputeLines[i].saima = '';
          this.disputeLines[i].saimaAmount = '';
        }
      }
    }
  }

  // Delete Attachment
  deleteAttachment(attach) {
    this.totalParent.attachError = false;
    for (let i = 0; i < this.attaches.length; i++) {
      if (this.attaches[i].filename === attach.filename) {
        this.attaches.splice(i, 1);
      }
    }
    this.attachments = this.attaches;
  }

  discountPercent() {
    if (this.invoiceDetails) {
      let endPoint = '/invoice/paymentterm/' + this.invoiceDetails.term_name + '/';
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        // This service returns null when no data is present. Hence null check is not performed
        if (data && data.status && data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else if (data) {
          this.cashDiscount = parseFloat(data);
        } else {
          this.cashDiscount = '';
        }
      });
    }
  }

  // Dispute type change
  disputeChange() {
    this.totalParent.msgStatus = false;
    if (this.totalParent.amount === 'false') {
      this.amount_type = 'AMOUNT';
    } else {
      this.amount_type = 'PERCENT';
    }
    this.totalParent.total = ''; // once change assign null to total value
    DisputeComponent.resetValues(this.disputeLines);
    this.updateTotal();
  }

  // disputeDetails
  disputeDetails() {
    // reasons
    let endPoint = '/creditNote/reasons/', i;
    this._httpService.httpRequest('GET', endPoint, null, (reasons) => {
      if (reasons === null || reasons === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - disputeDetails' });
      } else if (reasons.status === 1) {
        this._appService.notify(new APIError(reasons.msg));
      } else {
        this.reasons = [];
        reasons = this._orderBy.transform(reasons, 'meaning');
        for (i = 0; i < reasons.length; i++) {
          if (!reasons[i].attribute1 || this._dataService.orgId === parseInt(reasons[i].attribute1)) {
            this.reasons.push(reasons[i]);
          }
        }
      }
    });

    // transactions
    endPoint = '/creditNote/transactionTypes/' + this.org + '/';
    this._httpService.httpRequest('GET', endPoint, null, (transactions) => {
      if (transactions === null || transactions === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - disputeDetails' });
      } else if (transactions.status === 1) {
        this._appService.notify(new APIError(transactions.msg));
      } else {
        this.transactions = transactions;
      }
    });

    // debitTO
    endPoint = '/creditNote/debitTo/';
    this._httpService.httpRequest('GET', endPoint, null, (debit) => {
      if (debit === null || debit === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - disputeDetails' });
      } else if (debit.status === 1) {
        this._appService.notify(new APIError(debit.msg));
      } else {
        this.debitToList = debit;
      }
    });
  }

  // Calculate Quantity and Percentage based on given disputed amount
  disputeLineAmount(line, disputeAmount, prevAmount) {
    if (disputeAmount === prevAmount) {
      return;
    }
    let disputePercent, disputeQuantity,
      lines = this.disputeLines,
      index = lines.indexOf(line),
      value = DisputeComponent.validatePattern(disputeAmount),
      comma_index, dot_index, no_comma_index, no_dot_index, point;

    this.totalParent.msgStatus = false;
    if (value) {
      comma_index = disputeAmount.lastIndexOf(',');
      dot_index = disputeAmount.lastIndexOf('.');
      no_comma_index = this.no_format.lastIndexOf(',');
      no_dot_index = this.no_format.lastIndexOf('.');
      if ((comma_index >= dot_index) && (no_comma_index >= no_dot_index)) {
        // If user number format is '999.999.999,99'
        point = disputeAmount.lastIndexOf(',');
        // we need to replace ',' with '.'
        if (point !== -1) {
          disputeAmount = DisputeComponent.replaceAt(disputeAmount, point, '.');
          disputeAmount = DisputeComponent.removeAllButLast(disputeAmount, '.');
        }
        if (disputeAmount <= line.line_amount && disputeAmount > 0) {
          disputePercent = (disputeAmount / line.line_amount) * (100);
          disputeQuantity = (disputeAmount / line.line_amount) * line.quantity_invoiced * 100;
          lines[index].disputeAmount = parseFloat(disputeAmount);
          lines[index].disputePercent = parseFloat(disputePercent);
          disputeQuantity = parseInt(disputeQuantity) / 100;
          if (disputeQuantity % 1 === 0) {
            lines[index].disputeQuantity = disputeQuantity;
          } else {
            lines[index].disputeQuantity = '';
          }
          lines[index].dispFormatPercent = this._formatService.formatNumber(disputePercent);
          lines[index].dispFormatAmt = this._formatService.formatNumber(disputeAmount);
          this.updateTotal();
        } else {
          DisputeComponent.resetValues([lines[index]]);
          this.updateTotal();
          this.totalParent.msgStatus = true;
          this.msg = 'Disputed amount must be with in original price';
          this._appService.notify({
            status: 1,
            msg: this.msg
          });
        }
      } else if ((dot_index >= comma_index) && (no_dot_index >= no_comma_index)) {
        // If user number format is '999,999,999.99'
        disputeAmount = parseFloat(disputeAmount.replace(/,/g, ''));
        if (disputeAmount <= line.line_amount && disputeAmount > 0) {
          disputePercent = (disputeAmount / line.line_amount) * (100);
          disputeQuantity = (disputeAmount / line.line_amount) * line.quantity_invoiced * 100;
          lines[index].disputeAmount = parseFloat(disputeAmount);
          lines[index].disputePercent = parseFloat(disputePercent);
          disputeQuantity = parseInt(disputeQuantity) / 100;
          lines[index].disputeQuantity = disputeQuantity % 1 === 0 ? disputeQuantity : '';
          lines[index].dispFormatPercent = this._formatService.formatNumber(disputePercent);
          lines[index].dispFormatAmt = this._formatService.formatNumber(disputeAmount);
          this.updateTotal();
        } else {
          DisputeComponent.resetValues([lines[index]]);
          this.updateTotal();
          this.totalParent.msgStatus = true;
          this.msg = 'Disputed amount must be with in  original price';
          this._appService.notify({
            status: 1,
            msg: this.msg
          });
        }
      } else {
        DisputeComponent.resetValues([lines[index]]);
        this.updateTotal();
        this.totalParent.msgStatus = true;
        this.msg = 'Check Your Number Format,It Should Be' + ' ' + this.no_format;
        this._appService.notify({
          status: 1,
          msg: this.msg
        });
      }
    } else if (!value && disputeAmount) {
      DisputeComponent.resetValues([lines[index]]);
      this.updateTotal();
      this.totalParent.msgStatus = true;
      this.msg = 'Check Your Number Format,It Should Be' + ' ' + this.no_format;
      this._appService.notify({
        status: 1,
        msg: this.msg
      });
    } else {
      DisputeComponent.resetValues([lines[index]]);
      this.updateTotal();
    }
  }

  // Calculates Quantity And Extended Amount Based On Given Dispute Percentage
  disputeLinePercent(line, disputePercent) {
    if (disputePercent === null || disputePercent === undefined) {
      line.disputeQuantity = null;
      line.disputeAmount = null;
      return;
    }
    let disputeAmount, disputeQuantity,
      lines = this.disputeLines,
      index = lines.indexOf(line),
      value = DisputeComponent.validatePattern(disputePercent),
      comma_index, dot_index, no_comma_index, no_dot_index, point;

    this.totalParent.msgStatus = false;
    if (value) {
      comma_index = disputePercent.lastIndexOf(',');
      dot_index = disputePercent.lastIndexOf('.');
      no_comma_index = this.no_format.lastIndexOf(',');
      no_dot_index = this.no_format.lastIndexOf('.');
      if ((comma_index >= dot_index) && (no_comma_index >= no_dot_index)) {
        // If user number format is '999.999.999,99'
        point = disputePercent.lastIndexOf(',');
        // we need to replace ',' with '.'
        if (point !== -1) {
          disputePercent = DisputeComponent.replaceAt(disputePercent, point, '.');
          disputePercent = DisputeComponent.removeAllButLast(disputePercent, '.');
        }
        if (disputePercent <= 100 && disputePercent > 0) {
          disputeAmount = (line.line_amount * disputePercent) / 100;
          disputeQuantity = (line.quantity_invoiced * disputePercent) / 100;
          lines[index].disputeQuantity = disputeQuantity % 1 === 0 ? disputeQuantity : '';
          lines[index].disputeAmount = parseFloat(disputeAmount);
          lines[index].disputePercent = parseFloat(disputePercent);
          lines[index].dispFormatAmt = this._formatService.formatNumber(disputeAmount);
          lines[index].dispFormatPercent = this._formatService.formatNumber(disputePercent);
          this.updateTotal();
        } else {
          DisputeComponent.resetValues([lines[index]]);
          this.updateTotal();
          this.totalParent.msgStatus = true;
          // this.msg = "percentage should be in between 0 To 100";
          this._appService.notify({
            status: 1,
            msg: 'Percentage should be in between 0 To 100'
          });
        }
      } else if ((dot_index >= comma_index) && (no_dot_index >= no_comma_index)) {
        // If user number format is '999,999,999.99'
        disputePercent = parseFloat(disputePercent.replace(/,/g, ''));
        if (disputePercent <= 100 && disputePercent > 0) {
          disputeAmount = (line.line_amount * disputePercent) / 100;
          disputeQuantity = (line.quantity_invoiced * disputePercent) / 100;
          lines[index].disputeQuantity = disputeQuantity % 1 === 0 ? disputeQuantity : '';
          lines[index].disputeAmount = parseFloat(disputeAmount);
          lines[index].disputePercent = parseFloat(disputePercent);
          lines[index].dispFormatAmt = this._formatService.formatNumber(disputeAmount);
          lines[index].dispFormatPercent = this._formatService.formatNumber(disputePercent);
          this.updateTotal();
        } else {
          DisputeComponent.resetValues([lines[index]]);
          this.updateTotal();
          this.totalParent.msgStatus = true;
          // this.msg = "percentage should be in between 0 To 100";
          this._appService.notify({
            status: 1,
            msg: 'Percentage should be in between 0 To 100'
          });
        }
      } else {
        DisputeComponent.resetValues([lines[index]]);
        this.updateTotal();
        this.totalParent.msgStatus = true;
        // this.msg = "Check Your Number Format,It Should Be" + " " + this.no_format;
        this._appService.notify({
          status: 1,
          msg: 'Check your number format, It should be' + ' ' + this.no_format
        });
      }
    } else if (disputePercent && !value) {
      DisputeComponent.resetValues([lines[index]]);
      this.updateTotal();
      this.totalParent.msgStatus = true;
      // this.msg = "Check Your Number Format,It Should Be" + " " + this.no_format;
      this._appService.notify({
        status: 1,
        msg: 'Check your number format, Itshould be' + ' ' + this.no_format
      });
    } else {
      DisputeComponent.resetValues([lines[index]]);
      this.updateTotal();
    }
  }

  // Calculates Percentage and Extended Amount Based on Given Quantity
  disputeLineQuantity(line, disputeQuantity) {
    let lines, index, disputeAmount, disputePercent;
    this.totalParent.msgStatus = false;
    disputeQuantity = parseFloat(disputeQuantity);
    if (parseFloat(disputeQuantity) % 1 === 0) {
      disputeQuantity = parseInt(disputeQuantity);
    }
    lines = this.disputeLines;
    index = lines.indexOf(line);
    if (disputeQuantity > 0 && disputeQuantity <= line.quantity_invoiced && !isNaN(disputeQuantity)) {
      disputeAmount = line.unit_selling_price * disputeQuantity;
      disputePercent = (disputeQuantity * 100) / line.quantity_invoiced;
      lines[index].disputeQuantity = disputeQuantity;
      lines[index].disputeAmount = parseFloat(disputeAmount);
      lines[index].disputePercent = parseFloat(disputePercent);
      lines[index].dispFormatAmt = this._formatService.formatNumber(disputeAmount);
      lines[index].dispFormatPercent = this._formatService.formatNumber(disputePercent);
      this.updateTotal();
    } else if (disputeQuantity) {
      DisputeComponent.resetValues([lines[index]]);
      this.updateTotal();
      this._appService.notify({
        status: 1,
        msg: 'Disputed quantity must be with in original quantity'
      });
      this.totalParent.msgStatus = true;
      // this.msg = "Disputed quantity must be with in original quantity";
    } else {
      DisputeComponent.resetValues([lines[index]]);
      this.updateTotal();
    }
  }

  disputeShow() {
    if (this.disputeStatus && this.oldStatus !== this.totalParent.showDispute) {
      this.totalParent.amount = 'false';
      this.totalParent.total = '';
      this.disputeStatus = false;
      for (let i = 0; i < this.disputeLines.length; i++) {
        this.disputeLines[i].saima = '';
        this.disputeLines[i].saimaAmount = '';
      }
      DisputeComponent.resetValues(this.disputeLines);
      this.updateTotal();
    }
    return true;
  }

  // Current step index
  getCurrentStepIndex() {
    return this.steps.map(x => x).indexOf(this.selection);
  }

  // get lookup code
  static getLookUpCode(meaning) {
    return meaning === true ? 'Y' : 'N';
  }

  // For ic credit flag
  // icCredit(creditflag) {
  //   this.ic_credit_flag = creditflag;
  //   this.showStatus = true;
  // }

  // go to creditnotes summary page
  // gotoCreditNotes() {
  //   this._router.navigate('app.creditnotes');
  // }

  // previous states
  goToPreviousState() {
    this._router.navigate(['creditnotes/invoice']);
  }

  // Goto specific step function
  goToStep(index) {
    if (index === 0) {
      this.selection = this.steps[index];
    } else if (!this.itemsValidations() || !this.disputeShow()) {
      return false;
    } else if (index === 1) {
      this.oldStatus = this.totalParent.showDispute;
      this.selection = this.steps[index];
    } else if (index === 2 && this.reviewDispute()) {
      this.oldStatus = this.totalParent.showDispute;
      this.totalParent.applyFlag = DisputeComponent.getLookUpCode(this.totalParent.cm_apply_flag);
      this.selection = this.steps[index];
    } else if (index === 2 && !this.reviewDispute() && this.selection === this.steps[0]) {
      this.selection = this.steps[1];
    }
    if (index === 2 && !this.finalDisputeLines.length) {
      this._appService.notify({
        status: 1,
        msg: 'Empty Dispute Fill Provided Input/s'
      });
    }
  }

  // validate Items
  itemsValidations() {
    this.totalParent.DisputeLinesError = false;
    if (!this.totalParent.reasonObj) {
      this.focusReason = false;
      return false;
    } else if (!this.totalParent.debitToObj) {
      this.focusDebit = false;
      return false;
    } else if (!this.totalParent.ic_credit_flag && this.org !== 82) {
      this.focusCredit = false;
      this._appService.notify({
        status: 1,
        msg: 'IC Credit memo required'
      });
      return false;
    } else if (!this.totalParent.internal_comment) {
      this.focusInternalComment = false;
      return false;
    } else if (!this.totalParent.comments) {
      this.focusComment = false;
      return false;
    }
    return true;
  }

  // load dispute Details
  load() {
    let due_date, invoice_total, lines, i;
    this.org = this._cacheService.getOrgId();
    this.org_id = this.org;
    // if cacheservice doesnot contains invoice details
    if (!this._cacheService.getInvoiceDetails()) {
      this._router.navigate(['creditnotes/summary']);
    } else {
      this.invoice_details = JSON.parse(this._cacheService.getInvoiceDetails());
      this.totalParent.customerName = this.invoice_details.party_name;
      due_date = this.invoice_details.term_due_date;
      this.due_date = this._formatService.formatDate(due_date);
      invoice_total = this.invoice_details.line_amount + this.invoice_details.tax_amount;
      this.invoice_line_amount = this._formatService.formatNumber(this.invoice_details.line_amount);
      this.tax_amount = this._formatService.formatNumber(this.invoice_details.tax_amount);
      this.invoice_total = invoice_total;
      this.invoiceDetails = this.invoice_details;
      lines = this.invoice_details.lines.splice(1);
      for (i = 0; i < lines.length; i++) {
        lines[i].lineAmount = this._formatService.formatNumber(lines[i].line_amount);
      }
      this.disputeLines = lines;
      this.invoice_number = this._appService.invoice_number;
      this.totalParent.disputeType = 'false';
      this.totalParent.amount = 'false';
      this.totalParent.showDispute = false;
      this.dispute_type_label = 'Specific Invoice Lines + Tax';
      this.attachments = [];
      this.lines = false;
      this.payment_desc = this._appService.payment_desc;
      this.amount_type = 'AMOUNT';
      this.bill_to_site_use_id = this.invoice_details.bill_to_site_use_id;
      this.cust_account_id = this.invoice_details.bill_to_customer_id;
      this.ship_to_site_use_id = this.invoice_details.ship_to_site_use_id;
      this.currency_code = this.invoice_details.invoice_currency_code;
      this.disputeDetails();
    }
  }

  // Download Attachment
  onDownload(data, fileName) {
    let blobFile = DisputeComponent.base64ToBlob(data),
      a, url;
    if (blobFile) {
      a = document.createElement('a');
      document.body.appendChild(a);
      url = this._window.URL.createObjectURL(blobFile);
      a.href = url;
      a.download = fileName;
      a.click();
      this._window.URL.revokeObjectURL(url);
    }
  }

  parseSaima(line, value, saima_type) {
    if (value !== null && value !== undefined && value !== '') {
      value = saima_type === 'quantity' ? parseInt(value) : this._formatService.numberParser(value);
      line.saima = saima_type === 'quantity' ? isNaN(value) ? '' : value : line.saima;
      line.saimaAmount = saima_type === 'amount' ? value : line.saimaAmount;
      if (saima_type === 'quantity' && isNaN(value)) {
        this._appService.notify({ msg: 'Enter only numeric values in SAIMA', status: 1 });
      }
    }
  }

  // reason change
  reasonChange() {
    let index = this.reasons.map(reason => reason.lookup_code).indexOf(this.totalParent.reasonObj);
    if (index !== -1) {
      this.reason_code = this.totalParent.reasonObj; // save the latest option code
      this.reason_meaning = this.reasons[index].meaning; // save the latest option meaning
    } else {
      this.totalParent.reasonObj = null;
    }
  }

  static removeAllButLast(string, token) {
    /* Requires STRING not contain TOKEN */
    let parts = string.split(token);
    return parts.slice(0, -1).join('') + token + parts.slice(-1);
  }

  static replaceAt(str, index, character) {
    return str.substr(0, index) + character + str.substr(index + character.length);
  }

  static resetValues(lines) {
    for (let i = 0; i < lines.length; i++) {
      lines[i].disputeAmount = '';
      lines[i].disputeQuantity = '';
      lines[i].disputePercent = '';
      lines[i].dispFormatAmt = '';
      lines[i].dispFormatPercent = '';
    }
  }

  // review page
  reviewDispute() {
    let lines = this.disputeLines,
      linesLength = this.disputeLines.length, i;

    this.totalParent.DisputeLinesError = false;
    this.finalDisputeLines = [];
    for (i = 0; i < linesLength; i++) {
      if (lines[i].hasOwnProperty('disputeAmount'), lines[i].hasOwnProperty('disputePercent'), lines[i].hasOwnProperty('dispFormatAmt'), lines[i].hasOwnProperty('dispFormatPercent')) {
        if (lines[i].disputeAmount) {
          this.finalDisputeLines.push(lines[i]);
        }
      } else if (lines[i].segment1 === 'CASH_DISCOUNT' && !this.totalParent.showDispute) {
        if (lines[i].hasOwnProperty('disputeAmount'), lines[i].hasOwnProperty('dispFormatAmt')) {
          if (lines[i].disputeAmount) {
            this.finalDisputeLines.push(lines[i]);
          }
        }
      }
    }
    if (this.finalDisputeLines.length > 0) {
      this.totalParent.DisputeLinesError = false;
      return true;
    } else {
      this.totalParent.DisputeLinesError = true;
      return false;
    }
  }

  // Insert dispute details
  saveDispute() {
    let header = this.createJSONDispute(),
      endPoint = '/creditNote/dispute/';

    this.totalParent.msgStatus = false;
    this.disputeSaved = true;
    this.totalParent.showSuccess = false;
    this._httpService.httpRequest('POST', endPoint, header, (debit) => {
      if (debit === null || debit === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - saveDispute' });
      } else if (debit.hasOwnProperty('status')) {
        if (debit.status === 0) {
          this.totalParent.headerId = debit.header_id;
          this.disputeSaved = false;
          this.totalParent.showSuccess = true;
          this.hideAfterSave = true;
          this._appService.disputeSaveMsg = 'Dispute #' + debit.header_id + ' created successfully';
          this._router.navigate(['creditnotes/summary']);
        } else if (debit.status === 1) {
          this._appService.notify({
            status: 1,
            msg: debit.msg
          });
        }
      }
    });
  }

  setUpDOMHandlers() {
    jQuery('.scroll-top').click(() => {
      this._appService.scrollTop();
    });
  }

  // once user changed his dispute type
  typeChange() {
    this.disputeStatus = true;
    if (this.totalParent.disputeType === 'false') {
      this.totalParent.showDispute = false;
      this.dispute_type_label = 'Specific Invoice Lines + Tax';
    } else if (this.totalParent.disputeType === 'true') {
      this.totalParent.showDispute = true;
      this.dispute_type_label = 'Total';
    }
  }

  // Calculates total amount
  updateTotal() {
    let disputeTotalAmount = 0,
      count = 0, i, index;
    this.disputeTotalAmount = 0;
    for (i = 0; i < this.disputeLines.length; i++) {
      if (this.disputeLines[i].segment1 === 'CASH_DISCOUNT' && !this.totalParent.showDispute && this.cashDiscount) {
        count = 1;
        continue;
      }
      if (this.disputeLines[i].disputeAmount) {
        disputeTotalAmount += this.disputeLines[i].disputeAmount;
      }
    }
    if (count === 1 && !this.totalParent.showDispute && this.cashDiscount) {
      index = this.disputeLines.map(x => x.segment1).indexOf('CASH_DISCOUNT');
      if (index !== -1) {
        this.disputeTotalAmount = parseFloat((disputeTotalAmount - disputeTotalAmount * this.cashDiscount / 100).toFixed(2));
        this.disputeFormatTotalAmt = '(' + this._formatService.formatNumber(this.disputeTotalAmount) + ')';
        this.disputeLines[index].disputeAmount = parseFloat((-1 * disputeTotalAmount * this.cashDiscount / 100).toFixed(2));
        this.disputeLines[index].dispFormatAmt = this._formatService.formatNumber(this.disputeLines[index].disputeAmount);
      }
    } else {
      this.disputeTotalAmount = disputeTotalAmount;
      this.disputeFormatTotalAmt = '(' + this._formatService.formatNumber(disputeTotalAmount) + ')';
    }
  }

  // attachment
  uploadAttachment(attachment) {
    (document.getElementById('uploadAttachment') as HTMLFormElement).reset();
    (document.getElementById('uploadAttachment1') as HTMLFormElement).reset();
    this.totalParent.attachError = false;
    if (attachment && (this.attaches.length > 0)) {
      for (let i = 0; i < this.attaches.length; i++) {
        if (this.attaches[i].filename === attachment.filename) {
          this.totalParent.attachError = true;
          this._appService.notify({
            status: 1,
            msg: 'Attachment already exists!'
          });
          break;
        }
      }
      if (!this.totalParent.attachError) {
        this.attaches.push(attachment);
        this.attachments = this.attaches;
      } else {
        this.attaches = this.attachments;
      }
    } else if (attachment) {
      this.attaches.push(attachment);
      this.attachments = this.attaches;
    }
  }

  // Validate Pattern
  static validatePattern(input) {
    let regex = /^[+-]?[0-9]{1,3}(?:[0-9]*(?:[.,][0-9]{1,2})?|(?:,[0-9]{3})*(?:\.[0-9]{1,2})?|(?:\.[0-9]{3})*(?:,[0-9]{1,2})?)$/;
    return input.match(regex);
  }

}
