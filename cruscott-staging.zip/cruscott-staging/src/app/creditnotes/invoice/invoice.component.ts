import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { InvoiceService } from '../../globals/invoice.service';
import { ServerError } from '../../globals/server.error';
import { APIError } from '../../globals/api.error';

declare const pdfMake;

@Component({
  selector: 'app-creditnotes-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _invoiceService: InvoiceService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  billingAddr: any;
  desc: boolean;
  displayDispute: boolean;
  disputes: any;
  due_date: any;
  emptyDisputes: any;
  hideDownload: any;
  invalidDialog: any;
  invoice_number: any;
  invoiceHeader: any;
  invoiceLines: any;
  isInterCompanyTransactionRegister: boolean;
  org_id: any;
  predicate = ['request_id'];
  print: any;
  roles: any;
  shippingAddr: any;
  showDispute: any;
  showInvoice: any;
  subOrgChange: any;
  subTotal: any;
  taxAmount: any;
  totalAmount: any;
  trx_id: any;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService,
              formatService: FormatService, httpService: HttpService, invoiceService: InvoiceService,
              location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._invoiceService = invoiceService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.billingAddr = null;
    this.desc = true;
    this.displayDispute = false;
    this.disputes = [];
    this.due_date = null;
    this.emptyDisputes = null;
    this.hideDownload = null;
    this.invalidDialog = null;
    this.invoice_number = appService.invoice_number;
    this.invoiceHeader = null;
    this.invoiceLines = null;
    this.org_id = null;
    this.predicate = ['request_id'];
    this.print = null;
    this.roles = dataService.roles;
    this.shippingAddr = null;
    this.showDispute = null;
    this.showInvoice = null;
    this.subOrgChange = null;
    this.subTotal = null;
    this.taxAmount = null;
    this.totalAmount = null;
    this.trx_id = appService.trx_id;
    this.user = null;

    // appService variables
    appService.invoice_number = '';
    this.isInterCompanyTransactionRegister = appService.isInterCompanyTransactionRegister;
    // appService.isInterCompanyTransactionRegister = false;
  }

  ngOnInit() {
    this.setUpDOMHandlers();

    this._window.ga('send', 'pageview', { page: this._location.path() });

    // user cache
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(this.user);
        }

        if (this.trx_id) {
          this.invoiceDetails(this.trx_id);
        }
      }
    });

    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this._router.navigate(['creditnotes/summary']);
    });

  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  // dispute
  dispute() {
    let endPoint = '/dispute/data/trxid/' + this.trx_id + '/',
      tmpData, i;

    this.showDispute = true;
    this.invalidDialog = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify(new ServerError('dispute'));
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.showDispute = false;
        if (data.length > 1) {
          tmpData = data.splice(1); // since first line contains data types of columns
          for (i = 0; i < tmpData.length; i++) {
            tmpData[i].amount = this._formatService.formatNumber(tmpData[i].total_amount);
            tmpData[i].date_invoice = this._formatService.formatDate(tmpData[i].requested_date);
            tmpData[i].date_request = this._formatService.formatDate(tmpData[i].invoice_date);
          }
          this.disputes = tmpData;
        } else {
          this.emptyDisputes = true;
        }
      }
    });
  }

  // goto dispute
  goDispute() {
    this._router.navigate(['creditnotes/dispute']);
  }

  // goto previous state
  goToPreviousState() {
    // TODO: change previous state
    this._router.navigate([this._dataService.fromState]);
  }

  // http call to get invoice Details
  invoiceDetails(id) {
    let endPoint = '/dispute/' + id + '/',
      total_amount, line_amount, tax_amount,
      shipTo, shipTo1, shipTo2, sarr, l, i, j,
      billTo, billTo1, billTo2, barr, tmpLines;

    this.showInvoice = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      total_amount = '';
      this.showInvoice = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - invoiceDetails' });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (data[1] === undefined || data[1] === null) {
        this._appService.notify({ status: 1, msg: 'No data to display' });
        this.hideDownload = true;
      } else if (data[1]) {
        this._cacheService.setInvoiceDetails(JSON.stringify(data[1]));
        this.invoiceHeader = data[1];
        line_amount = data[1].line_amount;
        tax_amount = data[1].tax_amount;
        total_amount = line_amount + tax_amount;
        if (total_amount > 0) {
          this.displayDispute = true;
        }
        this.taxAmount = this._formatService.formatNumber(tax_amount);
        this.subTotal = this._formatService.formatNumber(line_amount);
        this.totalAmount = this._formatService.formatNumber(total_amount);
        this.due_date = this.invoiceHeader.term_due_date ? this._formatService.formatDate(this.invoiceHeader.term_due_date) : '';
        this.shippingAddr = '';
        shipTo = this.invoiceHeader.ship_to_address;
        shipTo1 = this.invoiceHeader.ship_to_address_line2 ? this.invoiceHeader.ship_to_address_line2 : '';
        shipTo2 = this.invoiceHeader.ship_to_address3 ? this.invoiceHeader.ship_to_address3 : '';
        sarr = [shipTo, shipTo1, shipTo2];
        for (l = 0; l < sarr.length; l++) {
          if (sarr[l]) {
            this.shippingAddr += sarr[l] + ' ' + '<br>' + ' ';
          }
        }
        this.billingAddr = '';
        billTo = this.invoiceHeader.bill_to_address ? this.invoiceHeader.bill_to_address : '';
        billTo1 = this.invoiceHeader.bill_to_address_line2 ? this.invoiceHeader.bill_to_address_line2 : '';
        billTo2 = this.invoiceHeader.bill_to_address3 ? this.invoiceHeader.bill_to_address3 : '';
        barr = [billTo, billTo1, billTo2];
        for (j = 0; j < barr.length; j++) {
          if (barr[j]) {
            this.billingAddr += barr[j] + ' ' + '<br>' + ' ';
          }
        }
        tmpLines = data[1].lines.splice(1);
        for (i = 0; i < tmpLines.length; i++) {
          tmpLines[i].price = this._formatService.formatNumber(tmpLines[i].unit_selling_price);
          tmpLines[i].amount = this._formatService.formatNumber(tmpLines[i].line_amount);
        }
        this.org_id = data[1].org_id;
        this.invoiceLines = tmpLines;
        this._appService.payment_term_id = data[1].receipt_method_id;
        this._appService.payment_desc = data[1].printed_name;
      }
    });
  }

  // print Invoice
  printInvoice() {
    let endPoint = '/invoice/print/',
      profile_lang = this.user.ui_language, dict: any = {},
      invoice_data, invoice_no, header;

    this.print = true;
    dict.org_id = this.org_id;
    dict.trx_id = parseInt(this.trx_id);
    dict.language = InvoiceComponent.userLanguage(profile_lang);
    dict.intercompany = this.isInterCompanyTransactionRegister;
    this._httpService.httpRequest('POST', endPoint, dict, (print_data) => {
      if (print_data === null || print_data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - printInvoice' });
      } else if (print_data.status === 1) {
        this._appService.notify(print_data.msg);
      } else {
        invoice_data = {};
        invoice_no = null;
        header = {};
        if (print_data[0].header.length > 1) {
          invoice_no = print_data[0].header[1].trx_number;
          header = print_data[0].header[1];
        }
        header.due_date = header.due_date ? this._formatService.formatDate(header.due_date) : '';
        header.trx_date = header.trx_date ? this._formatService.formatDate(header.trx_date) : '';
        invoice_data.header = header;
        invoice_data.lines = print_data[0].lines;
        invoice_data.address = print_data[0].address[1];
        invoice_data.tax = print_data[0].tax;
        invoice_data.show_cartons = this.isInterCompanyTransactionRegister;
        invoice_data.header_logo = print_data[0].header_logo;
        invoice_data.header_text = print_data[0].header_text;
        invoice_data.footer_logo = print_data[0].footer_logo;
        if (print_data[0].notes[1]) {
          invoice_data.notes = print_data[0].notes[1];
        }
        this._invoiceService.invoice = invoice_data;
        pdfMake.createPdf(this._invoiceService.getDocDefinition()).download('Invoice #' + invoice_no + '.pdf');
        setTimeout(() => {
          this.print = false;
        }, 10);
      }
    });
  }

  setUpDOMHandlers() {
    jQuery('.scroll-top').click(() => {
      this._appService.scrollTop();
    });
  }

  // language
  static userLanguage(language) {
    let language_short_form;
    switch (language) {
      case 'EN':
        language_short_form = 'US';
        break;
      case 'DE':
        language_short_form = 'D';
        break;
      case 'IT':
        language_short_form = 'I';
        break;
      case 'FR':
        language_short_form = 'F';
        break;
      default:
        language_short_form = 'I';
        break;
    }
    return language_short_form;
  }

}
