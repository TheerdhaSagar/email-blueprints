import { Component, Injector, OnDestroy, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { Subscription } from 'rxjs';
import { APIError } from '../../globals/api.error';
import { CreditnotesService } from '../service/creditnotes.service';

@Component({
  selector: 'app-creditnotes-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss'],
  providers: [OrderByPipe],
})
export class CreateNoteComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _creditNoteService: CreditnotesService = this.injector.get(
    CreditnotesService
  );
  private _dataService: DataService = this.injector.get(DataService);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  addressToggle: any;
  allCustomers: any[];
  allTransactions: any;
  attaches: any[];
  attachmentErrorMsg: string;
  attachments: any[];
  bill_to_site_use_id: any;
  checkedCount = 0;
  count: any;
  counter = 0;
  counts = 0;
  creditLines: any[];
  creditLinesPop: any[];
  currentPage: any;
  customers: any[];
  customersVisible: any[];
  dateFormat: string;
  debitToList: any;
  deletedLines: any[];
  editCreditNote: any;
  editCreditStatus: any;
  focusApplyCredit: any;
  focusComment: any;
  focusCustomername: any;
  focusDebit: any;
  focusInternalComment: any;
  focusInvoicePeriodFrom = true;
  focusInvoicePeriodTo = true;
  focusLines: boolean;
  focusPayment: any;
  focusReason: any;
  focusTransaction: any;
  hideAdd: any;
  invalidProducts: any[];
  invoicePeriodFrom: string;
  invoicePeriodTo: string;
  isValid: any;
  itemInvoices: {
    invoice_number: string;
    inventory_item_id: number;
    item_code: string;
  }[];
  itemNew: any;
  items: any;
  itemsarray: any[];
  linesToDelete: any[];
  newAttachments: any[];
  number_format: any;
  oldOrg: any;
  org: any;
  pageDim: any;
  pageReload: boolean;
  pageSize = 100;
  periodMsg = '';
  price: any;
  profile_lang: any;
  reasons: any;
  requestHeader: any;
  resultLower: any;
  resultUpper: any;
  roles: any;
  debitToWithSaima = ['SAIMA', 'DSVROAD', 'DSVAIRSEA'];
  save: any;
  searchQuery: any;
  selected_row: any;
  selectedCustomerId: any;
  selectedIndex: any;
  selection: any;
  showCustomerDialog: any;
  ship_to_site_use_id: any;
  showCustomers: any;
  showSave: boolean;
  showSaveSubmit: boolean;
  subOrgChange: Subscription;
  toggle: any;
  toggles: any;
  total: any;
  totalPages: any;
  totalResults = 0;
  user: any;
  validProducts: any[];
  creditNotes: any;
  deletedAttachments: any;
  steps: string[];
  windowWidth: any;

  constructor(private injector: Injector) {
    this._window = window;
  }

  static base64ToBlob(base64) {
    let byteString = atob(base64),
      // Convert text into a byte array.
      ab = new ArrayBuffer(byteString.length),
      ia = new Uint8Array(ab),
      dataBlob,
      i;
    for (i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    // Blob for saving.
    dataBlob = new Blob([ia], {
      type: 'octet/stream',
    });
    if (dataBlob) {
      return dataBlob;
    } else {
      return null;
    }
  }

  // method for getting default payment methods form list of payments
  static getDefaultPayment(paymentMethods) {
    let defaultPaymentTerm, i;
    if (paymentMethods) {
      defaultPaymentTerm = {};
      for (i = 0; i < paymentMethods.length; i++) {
        if (paymentMethods[i].primary_flag === 'Y') {
          defaultPaymentTerm = paymentMethods[i];
        }
      }
      return defaultPaymentTerm;
    }
  }

  // check given item exists
  static itemIsInLines(lines, itemCode, lineIndex) {
    let status = false,
      index;
    for (index = 0; index < lines.length; index++) {
      if (lineIndex !== index) {
        if (lines[index].item_code === itemCode) {
          status = true;
        }
      }
    }
    return status;
  }

  static removeAllButLast(string, token) {
    /* Requires STRING not contain TOKEN */
    let parts = string.split(token);
    return parts.slice(0, -1).join('') + token + parts.slice(-1);
  }

  static replaceAt(str, index, character) {
    return (
      str.substr(0, index) + character + str.substr(index + character.length)
    );
  }

  // Returns date after the no. of days passed as param
  static today(days) {
    let months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ],
      date = new Date();
    if (days > 0) {
      date.setDate(date.getDate() + days);
    }
    return (
      date.getDate() + '-' + months[date.getMonth()] + '-' + date.getFullYear()
    );
  }

  // Validate Pattern
  static validatePattern(input) {
    const regex = /^[+-]?\d{1,3}(?:\d*(?:[.,]\d{1,2})?|(?:,\d{3})*(?:\.\d{1,2})?|(?:\.\d{3})*(?:,\d{1,2})?)$/;
    return input.match(regex);
  }

  ngOnInit() {
    this.init();
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  // Add Row To Item Table
  addItemRow() {
    let line = {
      item: {},
      item_code: '',
      description: '',
      quantity: '',
      price: '',
      line_price: '',
      extendedAmount: '',
      extendedTotal: '',
      saima: '',
      saimaAmount: '',
      invoiceFlag: false,
    };
    this.creditNotes.itemError = false;
    this.creditLines.push(line);
    this.focusLines = false;
  }

  cancelModal() {
    this.selected_row = '';
    this.selectedIndex = '';
    this.creditNotes.showDialog = false;
    this.creditNotes.lineName = '';
  }

  closeCustomerDialog() {
    this._router.navigate(['creditnotes/summary']);
  }

  creditLinesValidation() {
    let lines = this.creditLines,
      i;
    for (i = 0; i < lines.length; i++) {
      if (
        lines[i].item &&
        lines[i].item_code &&
        lines[i].description &&
        lines[i].quantity &&
        lines[i].line_price &&
        lines[i].price &&
        lines[i].extendedTotal &&
        lines[i].extendedAmount
      ) {
        this.focusLines = false;
      } else if (
        lines[i].item_code === 'CASH_DISCOUNT' &&
        lines[i].extendedTotal &&
        lines[i].extendedAmount &&
        lines[i].description
      ) {
        this.focusLines = false;
      } else {
        this.focusLines = true;
        return true;
      }
    }
    return false;
  }

  // customer auto suggestions
  customerAutoSuggestions() {
    if (this.allCustomers) {
      let index = this.allCustomers
        .map((x) => x.cust_account_id)
        .indexOf(parseInt(this.creditNotes.customer));
      if (index !== -1) {
        this.creditNotes.customer_name = this.allCustomers[index].customer_name;
        this.onCustomerSelection(this.allCustomers[index]);
      }
    }
  }

  // delete checkbox
  delete() {
    if (this.checkedCount > 0) {
      this.creditNotes.showDialog = true;
    }
  }

  // Delete Attachment
  deleteAttachment(attach) {
    if (
      attach.file_id &&
      this.creditNotes.editCredit &&
      (this.editCreditStatus === 'PENDING_APPROVAL' ||
        this.editCreditStatus === 'DRAFT')
    ) {
      this.deletedAttachments.request_id = attach.cm_request_id;
      this.deletedAttachments.file_ids.push(attach.file_id);
    }
    this.creditNotes.attachError = false;
    for (let i = 0; i < this.attaches.length; i++) {
      if (this.attaches[i].filename === attach.filename) {
        this.attaches.splice(i, 1);
      }
    }
    this.creditNotes.attachments = this.attaches;
  }

  deleteInvoiceRow(line) {
    this.itemInvoices = this.itemInvoices.filter(
      (invoice) => invoice.item_code !== line.item_code
    );
  }

  // Delete credit line or attachment
  deleteRow() {
    let creditLines,
      i = 0,
      index,
      line,
      lineIndex,
      deleteLine;
    if (this.creditNotes.lineName === 'credit') {
      line = this.selected_row;
      lineIndex = this.selectedIndex;
      this.creditNotes.itemError = false;
      index = this.creditLinesPop
        .map((x) => x.item_code)
        .indexOf(line.item_code);
      if (index !== -1) {
        this.creditLinesPop.splice(index, 1);
      }
      deleteLine = this.creditLines.splice(lineIndex, 1);
      this.deleteInvoiceRow(line);
      if (
        this.creditNotes.copyCredit &&
        this.editCreditStatus === 'DRAFT' &&
        deleteLine[0].request_id
      ) {
        this.deletedLines.push(deleteLine[0]);
      }
      this.updateTotal();
    } else if (this.checkedCount > 0) {
      creditLines = this.creditLines;
      this.creditLines = [];
      for (i = 0; i < creditLines.length; i++) {
        if (creditLines[i].checked !== true) {
          this.creditLines.push(creditLines[i]);
        } else {
          this.deleteInvoiceRow(creditLines[i]);
        }
      }
      this.updateTotal();
    }
    this.checkedCount = 0;
    this.creditNotes.showDialog = false;
    this.selected_row = '';
    this.selectedIndex = '';
    this.creditNotes.lineName = '';
  }

  // DownLoad sample CSV file
  downloadCSV() {
    let element = document.getElementById('example-csv') as HTMLAnchorElement;
    const b64Part1 =
      'MjU3O0NUOzM7NSwyDQoyMjI7Q1Q7MjsxNSwyDQozMDM7Q1Q7MTsxMCw0DQpEQUl';
    const b64Part2 = 'MWSBET0dTO0NUOzU7MywNCjI1ODtDVDsxOzEsMQ0K';
    element.href = `data:text/csv;base64,${b64Part1}${b64Part2}`;
    element.download = 'example.csv';
  }

  // For edit credit details
  editCreditDetails() {
    let attachments,
      baddr1,
      baddr2,
      baddr3,
      barr,
      request = this.requestHeader,
      endPoint = '/creditNote/' + request + '/',
      id,
      index,
      index1,
      saddr1,
      saddr2,
      saddr3,
      sarr,
      i,
      j,
      k,
      l,
      tmpLines,
      total;

    // when editCreditNote is empty
    if (!this.editCreditNote) {
      this.showCustomers = false;
      this.pageDim = true;
      // Get Customer Details
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (data === null && data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - editCreditDetails',
          });
        } else if (data && data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else if (data) {
          this.hideAdd = false;
          this.editCreditNote = data[0];
          this.showSave = this.editCreditNote.status === 'PENDING_APPROVAL';
          id = this.editCreditNote.cust_acc_id;
          if (
            this.creditNotes.copyCredit ||
            (this.creditNotes.editCredit &&
              this.editCreditStatus === 'PENDING_APPROVAL')
          ) {
            // if (this.creditNotes.copyCredit) {
            // if (this.editCreditNote.customer_trx_id || this.editCreditNote.invoice_number) {
            //   this.invoiceNumber = this.editCreditNote.invoice_number;
            //   // this.hideAdd = true;
            // }
            // this.customer_trx_id = this.editCreditNote.customer_trx_id || -100;
            this.showSaveSubmit =
              this.creditNotes.copyCredit && this.editCreditStatus === 'DRAFT';
            this.showSave = !(
              this.creditNotes.copyCredit && this.editCreditStatus === 'DRAFT'
            );
            // }
            this.creditNotes.customer = this.editCreditNote.cust_acc_id;
            this.bill_to_site_use_id = this.editCreditNote.bill_to_site_use_id;
            this.ship_to_site_use_id = this.editCreditNote.ship_to_site_use_id;
            if (this.allCustomers) {
              index1 = this.allCustomers
                .map((x) => x.cust_account_id)
                .indexOf(this.editCreditNote.cust_acc_id);
              if (index1 !== -1) {
                this.creditNotes.customer_name = this.allCustomers[
                  index1
                ].customer_name;
                this.onCustomerSelection(
                  this.allCustomers[index1],
                  this.bill_to_site_use_id,
                  this.ship_to_site_use_id,
                  id
                );
              }
            }
          }
          if (this.creditNotes.editCredit && !this.pageReload) {
            // Get paymentterm Details
            this.paymentTerms(id);
          }
          this.total = this.editCreditNote.total_amount;
          this.editCreditNote.receipt_method_id = parseInt(
            this.editCreditNote.receipt_method_id
          );
          if (!this.creditNotes.copyCredit) {
            this.creditNotes.shippingAddr = '';
            this.creditNotes.billingAddr = '';
            saddr1 = this.editCreditNote.ship_to_address;
            saddr2 = this.editCreditNote.ship_to_address2
              ? this.editCreditNote.ship_to_address2
              : '';
            saddr3 = this.editCreditNote.ship_to_address3
              ? this.editCreditNote.ship_to_address3
              : '';
            sarr = [saddr1, saddr2, saddr3];
            for (l = 0; l < sarr.length; l++) {
              if (sarr[l]) {
                this.creditNotes.shippingAddr += sarr[l] + ' ' + '<br>' + ' ';
              }
            }
            baddr1 = this.editCreditNote.bill_to_address;
            baddr2 = this.editCreditNote.bill_to_address2
              ? this.editCreditNote.bill_to_address2
              : '';
            baddr3 = this.editCreditNote.bill_to_address3
              ? this.editCreditNote.bill_to_address3
              : '';
            barr = [baddr1, baddr2, baddr3];
            for (j = 0; j < barr.length; j++) {
              if (barr[j]) {
                this.creditNotes.billingAddr += barr[j] + ' ' + '<br>' + ' ';
              }
            }
          }
          this.creditNotes.reason = this.editCreditNote.reason_code;
          this.creditNotes.transaction = this.editCreditNote.transaction_id;
          this.creditNotes.debitTo = this.editCreditNote.debit_to;
          this.creditNotes.customer_name = this.editCreditNote.party_name;
          this.creditNotes.internalComments = this.editCreditNote.internal_comment;
          this.creditNotes.customerComments = this.editCreditNote.comments;
          this.creditNotes.class = this.editCreditNote.type;
          if (this.creditNotes.copyCredit) {
            this.creditNotes.transactions = this.creditNotes.class
              ? this.filterTransactionsByType(this.creditNotes.class)
              : this.filterTransactionsByType('CM');
          }

          // Get respective credit note transaction type for invoice
          if (
            this.editCreditNote.customer_trx_id ||
            this.editCreditNote.invoice_number
          ) {
            this.transactionsByType();
          }
          this.creditNotes.applyCreditNoteTo = this.editCreditNote.cm_apply_flag;
          this.creditNotes.noSalesCredit = this.editCreditNote.no_salesrep_flag;
          this.creditNotes.accuredToPreviousyear = this.editCreditNote.accured_currenct_year_flag;
          this.creditNotes.relatedToObjective = this.editCreditNote.related_to_objectives;
          if (parseInt(this.org) !== 82) {
            this.creditNotes.icCreditMemoRequired = this.editCreditNote.ic_credit_flag;
          }
          tmpLines = this.editCreditNote.lines.splice(1);
          for (i = 0; i < tmpLines.length; i++) {
            if (this.creditNotes.copyCredit) {
              index = this.items
                .map((x) => x.item_code)
                .indexOf(tmpLines[i].item_code);
              if (index !== -1) {
                tmpLines[i].item = this.items[index];
              }
            }
            if (
              (this.editCreditNote.customer_trx_id ||
                this.editCreditNote.invoice_number) &&
              this.creditNotes.copyCredit
            ) {
              tmpLines[i].price = tmpLines[i].quantity
                ? tmpLines[i].price
                : tmpLines[i].extended_amount;
              tmpLines[i].quantity = tmpLines[i].quantity || 1;
            } else {
              tmpLines[i].quantity = tmpLines[i].quantity || '';
            }
            tmpLines[i].line_price = this._formatService.formatNumber(
              tmpLines[i].price
            );
            tmpLines[i].extendedAmount = this._formatService.formatNumber(
              tmpLines[i].extended_amount
            );
            tmpLines[i].extendedTotal = tmpLines[i].extended_amount;
            tmpLines[i].customer_trx_line_id =
              tmpLines[i].customer_trx_line_id || null;
            tmpLines[i].saimaAmount =
              tmpLines[i].saima_amount !== null
                ? this._formatService.formatNumber(tmpLines[i].saima_amount)
                : '';
          }
          if (this.total < 0 && this.creditNotes.class === 'CM') {
            total = this.total * -1;
            this.creditNotes.creditTotal =
              '(' + this._formatService.formatNumber(parseFloat(total)) + ')';
          } else {
            this.creditNotes.creditTotal = this._formatService.formatNumber(
              parseFloat(this.total)
            );
          }
          this.creditLines = tmpLines;
          this.creditNotes.currency = this.editCreditNote.invoice_currency_code;
          attachments = data[0].attachments;
          for (k = 0; k < attachments.length; k++) {
            attachments[k].filename = attachments[k].file_name;
            attachments[k].filetype = attachments[k].filename.split('.').pop();
            attachments[k].base64 = attachments[k].file_content;
            attachments[k].filesize = attachments[k].file_size;
          }
          this.attaches = attachments;
          this.creditNotes.attachments = attachments;
          this.pageDim = false;
          this.showCustomers = true;
        }
      });
    }
  }

  // Validations on edit
  editCreditValidation() {
    if (!this.creditNotes.transaction) {
      this.focusTransaction = false;
      return false;
    }
    return true;
  }

  // Validations
  errorValidations() {
    this.creditNotes.errorShow = false;
    if (!this.creditNotes.customer) {
      this.focusCustomername = false;
      return false;
    } else if (!this.creditNotes.transaction) {
      this.focusTransaction = false;
      return false;
    } else if (!this.creditNotes.paymentTerm) {
      this.focusPayment = false;
      return false;
    } else if (!this.creditNotes.reason) {
      this.focusReason = false;
      return false;
    } else if (!this.creditNotes.debitTo) {
      this.focusDebit = false;
      return false;
    } else if (!this.creditNotes.icCreditMemoRequired && this.org !== 82) {
      this.focusApplyCredit = false;
      return false;
    } else if (this.invoicePeriodFrom && !this.invoicePeriodTo) {
      this.focusInvoicePeriodTo = false;
      this.invoicePeriodTo = '';
      this.periodMsg = 'Invoice Period To is mandatory';
      return false;
    } else if (
      this.invoicePeriodFrom &&
      this.invoicePeriodTo &&
      this._formatService.dateInMillis(
        this._formatService.parseDate(this.invoicePeriodFrom)
      ) >
        this._formatService.dateInMillis(
          this._formatService.parseDate(this.invoicePeriodTo)
        )
    ) {
      this.focusInvoicePeriodTo = false;
      this.invoicePeriodTo = '';
      this.periodMsg =
        'Invoice Period To should be greater than Invoice Period From';
      return false;
    }
    this.focusInvoicePeriodTo = true;
    return true;
  }

  errorValidationsForComments(): boolean {
    if (!this.creditNotes.customerComments) {
      this.focusComment = false;
      return false;
    } else if (!this.creditNotes.internalComments) {
      this.focusInternalComment = false;
      return false;
    }
    return true;
  }

  async fetchInvoiceDetails(): Promise<void> {
    if (this.creditNotes.reason === 'FREE PRODUCT') {
      const promises = [];
      if (this.invoicePeriodFrom && this.invoicePeriodTo) {
        this.creditLines.forEach((item, index) => {
          if (!item.invoiceFlag) {
            this.pageDim = true;
            item.inventory_item_id = item.item.inventory_item_id;
            promises.push(this.getInvoiceNumber(item, index));
          }
        });
      }
      await Promise.all(promises);
      setTimeout(() => {
        this.generateCommentDetails();
      });
    } else {
      this.creditLines.forEach((item) => {
        item.invoiceFlag = false;
      });
      if (this.itemInvoices.length) {
        this.creditNotes.customerComments = '';
        this.creditNotes.internalComments = '';
        this.itemInvoices = [];
      }
    }
    this.pageDim = false;
  }

  filterByOrg(reasons) {
    let list = [],
      i;
    for (i = 0; i < reasons.length; i++) {
      if (
        !reasons[i].attribute1 ||
        this.org === parseInt(reasons[i].attribute1)
      ) {
        list.push(reasons[i]);
      }
    }
    return list;
  }

  filterCustomers() {
    if (this.searchQuery && this.searchQuery.length > 0) {
      if (this.customersVisible.length !== this.allCustomers.length) {
        this.customersVisible = this.allCustomers;
      }
    } else {
      this.currentPage = 1;
      this.customersVisible = this.allCustomers.slice(0, this.pageSize);
    }
  }

  // fillter transactions based on Class type
  filterTransactionsByType(type) {
    let index,
      transactions = this.allTransactions,
      transactionType = [];
    for (index = 0; index < transactions.length; index++) {
      if (transactions[index].type === type) {
        transactionType.push(transactions[index]);
      }
    }
    return transactionType;
  }

  generateCommentDetails(): void {
    let info = `${this.creditNotes.customer_name} \n`;
    const invoices = this.itemInvoices
      .filter(
        (invoice, index, self) =>
          index ===
          self.findIndex((t) => t.invoice_number === invoice.invoice_number)
      )
      .map((invoice) => {
        return {
          invoice_number: invoice.invoice_number,
          items: this.itemInvoices
            .filter((item) => item.invoice_number === invoice.invoice_number)
            .map((item) => item.item_code),
        };
      });

    invoices.forEach((invoice) => {
      info += `${invoice.invoice_number} with Items: ${invoice.items.join()}\n`;
    });
    this.creditNotes.customerComments = info;
    this.creditNotes.internalComments = info;
  }

  getCurrentStepIndex() {
    return this.steps.map((x) => x).indexOf(this.selection);
  }

  // This method will create JSON object for create creditNote
  getCreateJSON() {
    let attachment, files, header, j, lines;
    if (this.creditNotes.customer) {
      header = {};
      header.customer_trx_id = -100;
      // header.customer_trx_id = this.creditNotes.copyCredit ? this.customer_trx_id : -100;
      header.org_id = this.org;
      header.last_update_date = CreateNoteComponent.today(0);
      header.last_updated_by = this.user.user_id;
      header.creation_date = CreateNoteComponent.today(0);
      header.created_by = this.user.user_id;
      header.ATTRIBUTE1 = this.creditNotes.transaction || '';
      header.ATTRIBUTE2 =
        this.creditNotes.selectedCustomer.cust_account_id || '';
      header.ATTRIBUTE3 = this.creditNotes.billToData.site_use_id || '';
      header.ATTRIBUTE4 = this.creditNotes.shipToData.site_use_id
        ? this.creditNotes.shipToData.site_use_id
        : '';
      header.ATTRIBUTE5 = this.creditNotes.currency || '';
      header.ATTRIBUTE6 = this.creditNotes.reason || '';
      header.cm_reason_code = this.creditNotes.reason || '';
      header.ATTRIBUTE8 = this.creditNotes.debitTo || '';
      header.ATTRIBUTE9 = this.creditNotes.applyCreditNoteTo || '';
      header.ATTRIBUTE10 = this.creditNotes.paymentTerm || '';
      header.ATTRIBUTE11 = this.creditNotes.noSalesCredit || '';
      header.ATTRIBUTE12 = this.creditNotes.accuredToPreviousyear || '';
      header.ATTRIBUTE14 = this.creditNotes.relatedToObjective || '';
      if (this.org !== 82) {
        header.ATTRIBUTE13 = this.creditNotes.icCreditMemoRequired || '';
      } else {
        header.ATTRIBUTE13 = '';
      }
      header.COMMENTS = this.creditNotes.customerComments;
      header.internal_comment = this.creditNotes.internalComments;
      header.total_amount = this.total;
      lines = this.getCnLines();
      files = [];
      if (this.creditNotes.attachments.length !== 0) {
        for (j = 0; j < this.creditNotes.attachments.length; j++) {
          attachment = {};
          attachment.base64 = this.creditNotes.attachments[j].base64;
          attachment.filename = this.creditNotes.attachments[j].filename;
          files.push(attachment);
        }
      }
      header.lines = lines;
      header.files = files;
      return header;
    }
  }

  /* for credit note lines */
  getCnLines() {
    let creditLine, line, lines;
    lines = [];
    for (let i = 0; i < this.creditLines.length; i++) {
      line = this.creditLines[i];
      creditLine = {};
      if (this.creditNotes.copyCredit) {
        creditLine.customer_trx_line_id = line.customer_trx_line_id || null;
      }
      if (line.price && line.quantity) {
        creditLine.quantity = parseInt(line.quantity);
        creditLine.price = line.price;
        creditLine.extended_amount = line.extendedTotal;
        creditLine.org_id = this.org;
        creditLine.last_update_date = CreateNoteComponent.today(0);
        creditLine.last_updated_by = this.user.user_id;
        creditLine.creation_date = CreateNoteComponent.today(0);
        creditLine.created_by = this.user.user_id;
        if (line.item) {
          creditLine.ATTRIBUTE1 = line.item.item;
          creditLine.ATTRIBUTE2 = line.item.inventory_item_id.toString();
          creditLine.ATTRIBUTE3 = line.description;
          creditLine.ATTRIBUTE4 =
            this.debitToWithSaima.includes(this.creditNotes.debitTo) &&
            line.saima
              ? line.saima.toString()
              : '';
          creditLine.ATTRIBUTE5 =
            this.debitToWithSaima.includes(this.creditNotes.debitTo) &&
            line.saimaAmount
              ? this._formatService.parseNumber(line.saimaAmount).toString()
              : '';
          creditLine.ATTRIBUTE6 = line.item.primary_uom_code;
          lines.push(creditLine);
        }
      } else if (
        line.item_code === 'CASH_DISCOUNT' &&
        line.description &&
        line.extendedTotal
      ) {
        creditLine.quantity = 1;
        creditLine.price = line.price;
        creditLine.extended_amount = line.extendedTotal;
        creditLine.org_id = this.org;
        creditLine.last_update_date = CreateNoteComponent.today(0);
        creditLine.last_updated_by = this.user.user_id;
        creditLine.creation_date = CreateNoteComponent.today(0);
        creditLine.created_by = this.user.user_id;
        creditLine.ATTRIBUTE1 = line.item_code;
        creditLine.ATTRIBUTE2 = 22;
        creditLine.ATTRIBUTE3 = line.description;
        creditLine.ATTRIBUTE4 =
          this.debitToWithSaima.includes(this.creditNotes.debitTo) && line.saima
            ? line.saima.toString()
            : '';
        creditLine.ATTRIBUTE5 =
          this.debitToWithSaima.includes(this.creditNotes.debitTo) &&
          line.saimaAmount
            ? this._formatService.parseNumber(line.saimaAmount).toString()
            : '';
        creditLine.ATTRIBUTE6 = line.primary_uom_code;
        lines.push(creditLine);
      }
    }
    return lines;
  }

  getInvoiceNumber(item, creditnoteIndex): Promise<void> | void {
    if (
      this.itemInvoices.findIndex(
        (invoice) => invoice.item_code === item.item_code
      ) !== -1
    ) {
      return;
    }
    const req = {
      inventory_item_id: item.inventory_item_id,
      cust_account_id: this.creditNotes.customer,
      bill_to: this.creditNotes.billToData.site_use_id,
      item_code: item.item_code,
      period_from: this.invoicePeriodFrom
        ? this._formatService.parseDate(this.invoicePeriodFrom)
        : '',
      period_to: this.invoicePeriodTo
        ? this._formatService.parseDate(this.invoicePeriodTo)
        : '',
    };
    return new Promise((resolve, reject) => {
      this._creditNoteService
        .getInvoiceDetailsOfItem(req)
        .then((data) => {
          if (
            data.invoice_number &&
            this.itemInvoices.findIndex(
              (itemDetails) => itemDetails.item_code === data.item_code
            ) === -1
          ) {
            this.itemInvoices.push(data);
          }
          this.creditLines[creditnoteIndex].invoiceFlag = true;
          resolve();
        })
        .catch((err) => {
          err.msg += `Failed to fetch for Item:${item.item_code}`;
          this._appService.notify(err);
          reject();
        });
    });
  }

  // item object from items array
  getItemObj(itemCode) {
    for (let item = 0; item < this.items.length; item++) {
      if (this.items[item].item_code === itemCode) {
        return this.items[item];
      }
    }
  }

  // get lookup code
  // getLookUpCode(meaning){
  //   if (meaning === true) {
  //     return 'Y';
  //   } else {
  //     return 'N';
  //   }
  // }

  // redirect to Credit Notes
  goToPreviousCreditState() {
    let toState;
    if (
      this._dataService.fromState === '/reclaims/customer/create' &&
      this._appService.customerClaimId
    ) {
      toState = '/reclaims/customer/create';
    } else if (this._dataService.fromState === '/reclaims/customer/summary') {
      toState = '/reclaims/customer/summary';
    } else if (this._dataService.fromState === '/coupons/summary') {
      toState = '/coupons/summary';
    } else {
      toState = '/creditnotes/summary';
      if (
        this.editCreditStatus === 'DRAFT' ||
        this.editCreditStatus === 'PENDING'
      ) {
        this._appService.editCreditStatus = this.editCreditStatus;
      }
      this._appService.editCredit = null;
      this._appService.editCreditHeader = null;
      this._appService.copyCredit = null;
      this._appService.copyCreditHeader = null;
    }
    this._router.navigate([toState]);
  }

  // Steps wrapper Selection
  goToStep(index, validate?) {
    this.toggle = false;
    if (this.creditNotes.copyCredit && !this.count) {
      this.toggle = true;
      this.count = 2;
    } else {
      this.toggle = false;
    }
    // When Customer Details
    if (index === 0) {
      if (this.creditNotes.customer_name) {
        setTimeout(() => {
          (document.getElementById(
            'customer_name'
          ) as HTMLFormElement).value = this.creditNotes.customer_name;
          // this.$apply();
        }, 10);
      }
      this.selection = this.steps[index];
    }
    if (index === 0 && this.creditNotes.copyCredit && this.counts === 0) {
      this.counts = 1;
      this.loadCustomers();
      this.loadLovData();
    }
    // When Items selected
    if (!this.creditNotes.editCredit || this.pageReload) {
      this.creditNotes.errorShow = false;
      if (
        (index === 1 || index === 2 || index === 3) &&
        this.errorValidations()
      ) {
        if (index === 1) {
          this.selection = this.steps[index];
          this.itemsarray = this.items;
        }
        // When Comments Selected
        if (
          index === 2 &&
          (this.creditLinesValidation() || this.creditLines.length < 1)
        ) {
          if (this.creditLines.length < 1) {
            this._appService.notify({
              msg: 'Credit lines are mandatory',
              status: 1,
            });
          } else {
            this._appService.notify({
              msg: 'Enter Item, Quantity and Price for all lines',
              status: 1,
            });
          }
          return;
        } else if (index === 2 && this.creditLines.length > 0) {
          // goto preview , item records more than 0
          this.showSaveSubmit =
            this.creditNotes.copyCredit && this.editCreditStatus === 'DRAFT';
          this.showSave = !(
            this.creditNotes.copyCredit && this.editCreditStatus === 'DRAFT'
          );
          if (this.selection !== 'Preview') {
            this.fetchInvoiceDetails();
          }
          this.selection = this.steps[index];
        } else if (index === 3) {
          if (!['Comments', 'Preview'].includes(this.selection)) {
            this.fetchInvoiceDetails();
          }
          if (this.errorValidationsForComments()) {
            this.selection = this.steps[index];
          } else {
            this._appService.notify({
              status: 1,
              msg: 'Comments are mandatory',
            });
          }
        }
      } else {
        if (index === 3 && this.creditLines.length < 1) {
          this._appService.notify({
            status: 1,
            msg: 'Credit lines are mandatory',
          });
        }
        this.selection = this.steps[0];
        return;
      }
    }

    // When Items selected and edit creditnotes is true
    if (
      (index === 2 || index === 3) &&
      this.creditNotes.editCredit &&
      !this.pageReload
    ) {
      if (
        (this.editCreditStatus === 'PENDING_APPROVAL' ||
          this.editCreditStatus === 'DRAFT') &&
        validate
      ) {
        this.pageDim = true;
        this.loadCustomers();
      }
      if (this.counter !== 1) {
        // editCreditDetails();
        this.loadLovData();
        this.selection = this.steps[index];
        this.counter = 1;
      } else if (
        (index === 2 && this.editCreditValidation()) ||
        (index === 3 && this.errorValidationsForComments())
      ) {
        this.selection = this.steps[index];
      }
    }
  }

  init() {
    this.addressToggle = null;
    this.allCustomers = [];
    this.allTransactions = null;
    this.attaches = [];
    this.attachments = [];
    this.bill_to_site_use_id = null;
    this.checkedCount = 0;
    this.count = null;
    this.counter = 0;
    this.counts = 0;
    this.creditLines = [];
    this.creditLinesPop = [];
    this.creditNotes = {
      accuredToPreviousyear: 'N',
      relatedToObjective: 'N',
      applyCreditNoteTo: 'N',
      attachError: false,
      attachments: [],
      billToData: '',
      billToParty: '',
      class: '',
      class_name: '',
      classes: [
        {
          lookupcode: 'CM',
          meaning: 'Credit Memo',
        },
        {
          lookupcode: 'INV',
          meaning: 'Invoice',
        },
      ],
      copyCredit: false,
      creationErr: false,
      creationMsg: '',
      creditCreated: false,
      creditLines: [],
      creditTotal: '',
      creditUpdate: false,
      currency: '',
      customer: '',
      customer_name: '',
      customerComments: '',
      debitTo: '',
      description: '',
      editCredit: '',
      errorMessage: '',
      errorShow: false,
      extendedAmount: '',
      files: null,
      icCreditMemoRequired: '',
      internalComments: '',
      invalidDialog: '',
      item_code: '',
      itemError: false,
      itemErrMsg: '',
      lineName: '',
      msg: '',
      noSalesCredit: 'N',
      paymentTerm: '',
      paymentTerms: '',
      priceFormat: '',
      quantity: '',
      reason: '',
      selectedCustomer: '',
      shipToData: '',
      shipToParty: '',
      showDialog: false,
      status: '',
      transaction: '',
      transactions: '',
      uploadDialog: '',
    };
    this.currentPage = null;
    this.customers = [];
    this.customersVisible = [];
    this.debitToList = null;
    this.deletedLines = [];
    this.deletedAttachments = { request_id: '', file_ids: [] };
    this.editCreditNote = null;
    this.editCreditStatus = null;
    this.focusApplyCredit = null;
    this.focusComment = null;
    this.focusCustomername = null;
    this.focusDebit = null;
    this.focusInternalComment = null;
    this.focusLines = false;
    this.focusPayment = null;
    this.focusReason = null;
    this.focusTransaction = null;
    this.hideAdd = null;
    this.invalidProducts = [];
    this.isValid = null;
    this.itemInvoices = [];
    this.itemNew = null;
    this.items = null;
    this.itemsarray = [];
    this.linesToDelete = [];
    this.newAttachments = [];
    this.number_format = null;
    this.oldOrg = null;
    this.org = null;
    this.pageDim = null;
    this.pageReload = false;
    this.pageSize = 100;
    this.price = null;
    this.profile_lang = null;
    this.reasons = null;
    this.requestHeader = null;
    this.resultLower = null;
    this.resultUpper = null;
    this.roles = this._dataService.roles;
    this.save = null;
    this.searchQuery = null;
    this.selected_row = null;
    this.selectedIndex = null;
    this.selection = null;
    this.showCustomerDialog = null;
    this.ship_to_site_use_id = null;
    this.showCustomers = null;
    this.showSave = true;
    this.showSaveSubmit = false;
    this.steps = ['CustomerDetails', 'Items', 'Comments', 'Preview'];
    this.subOrgChange = null;
    this.toggle = null;
    this.toggles = null;
    this.total = null;
    this.totalPages = null;
    this.totalResults = 0;
    this.user = null;
    this.validProducts = [];
    this.setInvoiceDates();
    this.setUpDOMHandlers();

    this._window.ga('send', 'pageview', { page: this._location.path() });

    // user
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        this.dateFormat = this.user.date_format || 'dd-MMM-yyyy';
        this.profile_lang = this.user.ui_language;
        this.org = this._dataService.orgId;
        this.oldOrg = this._appService.customerOrg;
        if (this.roles.isB2b || this.roles.isAgent) {
          this._router.navigate(['quotes/summary']);
          return;
        }
        if (!this._cacheService.user) {
          this._cacheService.initialize(this.user);
        }
        this.number_format = this.user.number_format || '999,999.99';
        this.creditNotes.creditTotal = this._formatService.formatNumber(0);
        if (this._appService.editCredit) {
          this.creditNotes.editCredit = true;
          this.requestHeader = this._appService.editCreditHeader;
          this._appService.editCredit = null;
          this._appService.editCreditHeader = null;
          this.editCreditStatus = this._appService.editCreditStatus;
          this._appService.editCreditStatus = '';
          if (this._appService.editCreditOrg) {
            this.org = this._appService.editCreditOrg;
            this._appService.editCreditOrg = null;
          }
          this.goToStep(3, true);
        } else if (this._appService.copyCredit) {
          this.creditNotes.copyCredit = true;
          this.requestHeader = this._appService.copyCreditHeader;
          this._appService.copyCredit = null;
          this._appService.copyCreditHeader = null;
          if (this._appService.editCreditStatus) {
            this.editCreditStatus = this._appService.editCreditStatus;
            this._appService.editCreditStatus = '';
          }
          this.selection = this.steps[0];
          this.goToStep(0);
        } else {
          this.creditNotes.editCredit = null;
          this.creditNotes.copyCredit = null;
          this.requestHeader = null;
          this.goToStep(0);
          this.selection = this.steps[0];
          this.loadData();
        }
      }
    });

    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this._appService.lovData = null;
      this._router.navigate(['creditnotes/create']);
    });
  }

  // Price
  itemPriceRow(price, line) {
    this.creditNotes.itemError = false;
    let lines = this.creditLines,
      index = lines.indexOf(line),
      value = CreateNoteComponent.validatePattern(price),
      comma_index,
      dot_index,
      no_comma_index,
      no_dot_index,
      point;
    if (value) {
      comma_index = price.lastIndexOf(',');
      dot_index = price.lastIndexOf('.');
      no_comma_index = this.number_format.lastIndexOf(',');
      no_dot_index = this.number_format.lastIndexOf('.');
      if (comma_index >= dot_index && no_comma_index >= no_dot_index) {
        // If user number format is '999.999.999,99'
        point = price.lastIndexOf(',');
        // we need to replace ',' with '.'
        if (point !== -1) {
          price = CreateNoteComponent.replaceAt(price, point, '.');
          price = CreateNoteComponent.removeAllButLast(price, '.');
        }
        price = this._formatService.round(parseFloat(price), 2);
        if (price && price >= 0.01) {
          lines[index].price = price;
          lines[index].line_price = this._formatService.formatNumber(price);
          if (lines[index].quantity) {
            lines[index].extendedTotal = this._formatService.round(
              price * lines[index].quantity
            );
            lines[index].extendedAmount = this._formatService.formatNumber(
              lines[index].extendedTotal
            );
          } else {
            lines[index].extendedTotal = 0;
            lines[index].extendedAmount = this._formatService.formatNumber(0);
          }
        } else {
          lines[index].price = '';
          lines[index].line_price = '';
          lines[index].extendedTotal = '';
          lines[index].extendedAmount = '';
          this._appService.notify({
            status: 1,
            msg: 'Wrong price format.Valid format is ' + this.number_format,
          });
        }
      } else if (dot_index >= comma_index && no_dot_index >= no_comma_index) {
        // If user number format is '999,999,999.99'
        price = price.replace(/,/g, '');
        price = this._formatService.round(parseFloat(price), 2);
        if (price && price >= 0.01) {
          lines[index].price = price;
          lines[index].line_price = this._formatService.formatNumber(price);
          if (lines[index].quantity) {
            lines[index].extendedTotal = this._formatService.round(
              price * lines[index].quantity
            );
            lines[index].extendedAmount = this._formatService.formatNumber(
              lines[index].extendedTotal
            );
          } else {
            lines[index].extendedTotal = 0;
            lines[index].extendedAmount = this._formatService.formatNumber(0);
          }
        } else {
          lines[index].price = '';
          lines[index].line_price = '';
          lines[index].extendedTotal = '';
          lines[index].extendedAmount = '';
          this._appService.notify({
            status: 1,
            msg: 'Wrong price format.Valid format is ' + this.number_format,
          });
        }
      } else {
        lines[index].price = '';
        lines[index].line_price = '';
        lines[index].extendedTotal = '';
        lines[index].extendedAmount = '';
        this._appService.notify({
          status: 1,
          msg: 'Wrong price format.Valid format is ' + this.number_format,
        });
      }
    } else if (price) {
      lines[index].price = '';
      lines[index].line_price = '';
      lines[index].extendedTotal = '';
      lines[index].extendedAmount = '';
      this._appService.notify({
        status: 1,
        msg: 'Wrong price format.Valid format is ' + this.number_format,
      });
    } else {
      lines[index].price = '';
      lines[index].line_price = '';
      lines[index].extendedTotal = '';
      lines[index].extendedAmount = '';
    }
    this.updateTotal();
  }

  // quantity
  itemQuantityRow(quantity, line) {
    let lines, index, price;
    this.creditNotes.itemError = false;
    quantity = parseInt(quantity);
    if (quantity % 1 === 0) {
      quantity = parseInt(quantity);
    }
    lines = this.creditLines;
    index = lines.indexOf(line);
    price = lines[index].price;
    if (quantity > 0 && !isNaN(quantity)) {
      lines[index].quantity = quantity;
      if (price) {
        lines[index].extendedTotal = quantity * price;
        lines[index].extendedAmount = this._formatService.formatNumber(
          quantity * price
        );
      } else {
        lines[index].extendedTotal = 0;
        lines[index].extendedAmount = this._formatService.formatNumber(0);
      }
    } else if (quantity) {
      lines[index].quantity = '';
      lines[index].extendedTotal = '';
      lines[index].extendedAmount = '';
      this._appService.notify({
        status: 1,
        msg: 'Wrong quantity format.Valid format is ' + this.number_format,
      });
    } else {
      lines[index].quantity = '';
      lines[index].extendedTotal = '';
      lines[index].extendedAmount = '';
    }
    this.updateTotal();
  }

  // Item Changes
  itemRowChange(item, $index) {
    setTimeout(() => {
      let index = $index,
        i,
        j,
        k,
        index1,
        index2,
        item_new,
        initialItems = this.itemsarray,
        finalarray = [];
      // this.itemsarray = [];  // removed as the itemcodes are not getting populated
      if (this.creditLines.length > 0) {
        for (i = 0; i < this.creditLines.length; i++) {
          if (this.creditLines[i].item_code === 'CASH_DISCOUNT') {
            continue;
          }
          index2 = this.items
            .map((x) => x.item_code)
            .indexOf(this.creditLines[i].item_code);
          if (index2 !== -1) {
            this.creditLinesPop.push(this.items[index2]);
          }
        }
      }
      if (this.creditLines.length > 0) {
        for (j = 0; j < this.items.length; j++) {
          index1 = this.creditLinesPop
            .map((x) => x.item_code)
            .indexOf(this.items[j].item_code);
          if (index1 !== -1) {
            this.creditLinesPop.splice(index1, 1);
            continue;
          }
          finalarray[j] = this.items[j];
        }
      } else {
        for (k = 0; k < this.items.length; k++) {
          finalarray[k] = this.items[k];
        }
      }
      if (
        !CreateNoteComponent.itemIsInLines(
          this.creditLines,
          item.toUpperCase(),
          index
        )
      ) {
        item_new = this.getItemObj(item.toUpperCase());
        if (item_new) {
          if (this.creditLines[index].item.item_code !== item_new.item_code) {
            this.creditLines[index].invoiceFlag = false;
            this.deleteInvoiceRow(this.creditLines[index].item);
          }
          (document.getElementById('line-' + index) as HTMLFormElement).value =
            item_new.item_code;
          this.creditLines[index].description = item_new.description;
          this.creditLines[index].primary_uom_code = item_new.primary_uom_code;
          this.creditLines[index].item = item_new;
          if (
            !this.creditLines[index].invoiceFlag &&
            this.invoicePeriodFrom &&
            this.invoicePeriodTo &&
            this.creditNotes.reason === 'FREE PRODUCT'
          ) {
            this.getInvoiceNumber(item_new, index);
          }
        } else {
          this.creditLines[index].description = '';
          this.creditLines[index].primary_uom_code = '';
          this.creditLines[index].item = {};
        }
      } else {
        this.creditLines[index].item = {};
        this.creditLines[index].description = '';
        this.creditLines[index].primary_uom_code = '';
      }
      this.itemsarray = finalarray.length ? finalarray : initialItems;
    }, 150);
  }

  // Add file_id for newly inserted attachments in edit
  loadAttachments(attachments, request_id) {
    let i, index;
    for (i = 0; i < this.attaches.length; i++) {
      index = attachments
        .map((x) => x.filename)
        .indexOf(this.attaches[i].filename);
      if (index !== -1) {
        this.attaches[i].cm_request_id = request_id;
        this.attaches[i].file_id = attachments[index].file_id;
      }
    }
    this.creditNotes.attachments = this.attaches;
  }

  // get service call for customers
  loadCustomers() {
    if (!this._cacheService.getCustomers() || this.org !== this.oldOrg) {
      this.customersVisible = [];
      let endPoint =
        '/customer/list/' + this.user.user_id + '/' + this.org + '/';
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadCustomers',
          });
        } else if (data.status !== 1) {
          this.showCustomers = true;
          this.currentPage = 1;
          this.customers = data;
          this.allCustomers = data;
          this._cacheService.setCustomers(data);
          this._appService.customerOrg = this.org;
          this.totalPages = Math.ceil(this.customers.length / this.pageSize);
          this.customersVisible = this.customers.slice(
            this.currentPage - 1,
            this.pageSize
          );
          this.resultLower = (this.currentPage - 1) * this.pageSize + 1;
          if (this.currentPage * this.pageSize > this.customers.length) {
            this.resultUpper = this.customers.length;
          } else {
            this.resultUpper = this.currentPage * this.pageSize;
          }
          this.totalResults = this.customers.length;
          this.showCustomerDialog =
            !this.creditNotes.editCredit && !this.creditNotes.copyCredit;
        } else {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      });
    } else if (this._cacheService.getCustomers() && this.oldOrg === this.org) {
      this.currentPage = 1;
      this.customers = this._cacheService.getCustomers();
      this.allCustomers = this.customers;
      this.showCustomers = true;
      this.totalPages = Math.ceil(this.customers.length / this.pageSize);
      this.customersVisible = this.customers.slice(
        this.currentPage - 1,
        this.pageSize
      );
      this.resultLower = (this.currentPage - 1) * this.pageSize + 1;
      if (this.currentPage * this.pageSize > this.customers.length) {
        this.resultUpper = this.customers.length;
      } else {
        this.resultUpper = this.currentPage * this.pageSize;
      }
      this.totalResults = this.customers.length;
      this.showCustomerDialog =
        !this.creditNotes.editCredit && !this.creditNotes.copyCredit;
    }
    this.showCustomers = true;
  }

  // load data
  loadData() {
    this.creditNotes.class = 'CM';
    this.customers = this._cacheService.getCustomers();
    this.addressToggle = false;
    this.showCustomers = false;
    this.prepareLines();
    // load Customers
    if (this.customers && this.oldOrg === this.org) {
      this.allCustomers = this.customers;
      this.currentPage = 1;
      this.totalPages = Math.ceil(this.customers.length / this.pageSize);
      this.customersVisible = this.customers.slice(
        this.currentPage - 1,
        this.pageSize
      );
      this.showCustomerDialog =
        !this.creditNotes.editCredit && !this.creditNotes.copyCredit;
      this.resultLower = (this.currentPage - 1) * this.pageSize + 1;
      if (this.currentPage * this.pageSize > this.customers.length) {
        this.resultUpper = this.customers.length;
      } else {
        this.resultUpper = this.currentPage * this.pageSize;
      }
      this.totalResults = this.customers.length;
      this.showCustomers = true;
    } else {
      if (this.user) {
        this.loadCustomers();
      }
    }
    this.loadLovData();
  }

  // get service call for lov values
  loadLovData() {
    let endUrl, lovs;
    if (
      this._appService.lovData &&
      ((this.profile_lang &&
        this.profile_lang === this._appService.customerProfile) ||
        (!this.profile_lang && !this._appService.customerProfile)) &&
      this.org === this.oldOrg
    ) {
      lovs = this._appService.lovData;
      this.reasons = this.filterByOrg(lovs.reasons);
      this.allTransactions = lovs.transaction_types;
      if (this.creditNotes.class) {
        this.creditNotes.transactions = this.filterTransactionsByType(
          this.creditNotes.class
        );
      } else {
        this.creditNotes.transactions = this.filterTransactionsByType('CM');
      }
      this.items = lovs.items;
      this.itemsarray = this.items;
      this.creditLinesPop = [];
      this.debitToList = lovs.debit_to;
      if (
        this.items &&
        (this.creditNotes.copyCredit || this.creditNotes.editCredit)
      ) {
        setTimeout(() => {
          this.editCreditDetails();
        }, 6000);
      }
    } else {
      if (this.profile_lang) {
        this._appService.customerProfile = this.profile_lang;
        endUrl =
          '/creditNote/lovvalues/' + this.org + '/' + this.profile_lang + '/';
      } else {
        this._appService.customerProfile = null;
        endUrl = '/creditNote/lovvalues/' + this.org + '/';
      }
      this._httpService.httpRequest('GET', endUrl, null, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadLovData',
          });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          data.reasons = this._orderBy.transform(data.reasons, 'meaning');
          this._appService.lovData = data;
          // Reasons
          if (data.reasons && !this.reasons) {
            this.reasons = this.filterByOrg(data.reasons);
          }
          // Transactions
          if (data.transaction_types && !this.allTransactions) {
            this.allTransactions = data.transaction_types;
            if (this.creditNotes.class) {
              this.creditNotes.transactions = this.filterTransactionsByType(
                this.creditNotes.class
              );
            } else {
              this.creditNotes.transactions = this.filterTransactionsByType(
                'CM'
              );
            }
          }
          // Items
          if (data.items && !this.items) {
            this.items = data.items;
            this.itemsarray = this.items;
            this.creditLinesPop = [];
          }
          if (
            this.items &&
            (this.creditNotes.copyCredit || this.creditNotes.editCredit)
          ) {
            setTimeout(() => {
              this.editCreditDetails();
            }, 6000);
          }
          // Debit To
          if (data.debit_to && !this.debitToList) {
            this.debitToList = data.debit_to;
          }
        }
      });
    }
  }

  // load
  loadMore(next) {
    let page = next ? this.currentPage + 1 : this.currentPage - 1,
      startIndex = (page - 1) * this.pageSize,
      endIndex = page * this.pageSize,
      tmpData;
    this.currentPage = page;
    if (this.customers) {
      if (
        endIndex <= this.customers.length + this.pageSize &&
        (!this.searchQuery || this.searchQuery.length === 0)
      ) {
        tmpData = this.customers.slice(startIndex, endIndex);
        this.customersVisible = tmpData;
        this.resultLower = (this.currentPage - 1) * this.pageSize + 1;
        if (this.currentPage * this.pageSize > this.customers.length) {
          this.resultUpper = this.customers.length;
        } else {
          this.resultUpper = this.currentPage * this.pageSize;
        }
      }
    }
  }

  // multiple checkbox selection
  multipleCheckbox() {
    this.checkedCount = 0;
    for (let i = 0; i < this.creditLines.length; i++) {
      if (this.creditLines[i].checked === true) {
        this.checkedCount += 1;
      }
    }
  }

  // called on Ok icon click in BillTo
  onBillingOk() {
    let bill, bill1, billTo, billArray, tmpAddress, i, j;
    if (this.creditNotes.selectedCustomer.data) {
      billTo = parseInt(this.creditNotes.billToParty);
      tmpAddress = this.creditNotes.selectedCustomer.data.billto;
      for (i = 0; i < tmpAddress.length; i++) {
        if (billTo === tmpAddress[i].party_site_id) {
          this.creditNotes.paymentTerms = tmpAddress[i].payment_methods;
          this.creditNotes.paymentTerm = tmpAddress[i].receipt_method_id;
          this.creditNotes.billToData = tmpAddress[i];
          this.creditNotes.billingAddr = '';
          bill = tmpAddress[i].billacc_address
            ? tmpAddress[i].billacc_address
            : '';
          bill1 = tmpAddress[i].billing_address
            ? tmpAddress[i].billing_address
            : '';
          billArray = [bill, bill1];
          for (j = 0; j < billArray.length; j++) {
            if (billArray[j]) {
              this.creditNotes.billingAddr += billArray[j] + ' ' + '<br>' + ' ';
            }
          }
        }
      }
    }
  }

  onCustomerSelect() {
    if (this.creditNotes.customer) {
      this.showCustomerDialog = false;
      this.customerAutoSuggestions();
    }
  }

  // called on customer Selection
  onCustomerSelection(customer, billToId?, shipToId?, id?) {
    let defaultPaymentTerm,
      customerId = customer.cust_account_id,
      endPoint =
        '/customer/id/' +
        customerId +
        '/' +
        customer.cust_price_list_id +
        '/' +
        this.user.user_id +
        '/' +
        this.org +
        '/',
      billTo,
      shipTo,
      i,
      j,
      bill,
      bill1,
      billArray = [],
      index,
      ids,
      ship,
      ship1,
      shipArray = [],
      counter,
      count,
      l,
      flag;
    this.addressToggle = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - onCustomerSelection',
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        customer.data = data;
        this.creditNotes.errorShow = false;
        billTo = customer.data.billto;
        shipTo = customer.data.shipto;
        this.creditNotes.billTos = billTo;
        this.creditNotes.shipTos = shipTo;
        this.creditNotes.shippingAddr = '';
        this.creditNotes.billingAddr = '';
        if (shipToId) {
          index = customer.data.shipto
            .map((x) => x.site_use_id)
            .indexOf(parseInt(shipToId));
        }
        if (index !== -1 && index !== undefined && index !== null) {
          ship = customer.data.shipto[index].billacc_address
            ? customer.data.shipto[index].billacc_address
            : '';
          ship1 = customer.data.shipto[index].shipping_address
            ? customer.data.shipto[index].shipping_address
            : '';
          shipArray = [ship, ship1];
          this.creditNotes.shippingAddr = '';
          for (j = 0; j < shipArray.length; j++) {
            if (shipArray[j]) {
              this.creditNotes.shippingAddr +=
                shipArray[j] + ' ' + '<br>' + ' ';
            }
          }
          this.creditNotes.shipToParty =
            customer.data.shipto[index].party_site_id;
          this.creditNotes.shipToData = customer.data.shipto[index];
        } else if (customer.data.shipto[0]) {
          ship = customer.data.shipto[0].billacc_address
            ? customer.data.shipto[0].billacc_address
            : '';
          ship1 = customer.data.shipto[0].shipping_address
            ? customer.data.shipto[0].shipping_address
            : '';
          shipArray = [ship, ship1];
          for (j = 0; j < shipArray.length; j++) {
            if (shipArray[j]) {
              this.creditNotes.shippingAddr +=
                shipArray[j] + ' ' + '<br>' + ' ';
            }
          }
          this.creditNotes.shipToParty = customer.data.shipto[0].party_site_id;
          counter = 0;
          if (shipTo.length !== 0) {
            for (l = 0; l < shipTo.length; l++) {
              if (shipTo[l].site_primary_flag === 'Y') {
                counter = 1;
                this.creditNotes.shipToData = shipTo[l];
              }
            }
            if (counter !== 1) {
              this.creditNotes.shipToData = shipTo[0];
            }
          }
        } else {
          this._appService.notify({
            status: 1,
            msg: 'No Shipping address for selected customer!',
          });
        }
        if (billToId) {
          index = customer.data.billto
            .map((x) => x.site_use_id)
            .indexOf(parseInt(billToId));
        }
        if (index !== -1 && index !== undefined && index !== null) {
          bill = customer.data.billto[index].billacc_address
            ? customer.data.billto[index].billacc_address
            : '';
          bill1 = customer.data.billto[index].billing_address
            ? customer.data.billto[index].billing_address
            : '';
          billArray = [bill, bill1];
          this.creditNotes.billingAddr = '';
          for (j = 0; j < billArray.length; j++) {
            if (billArray[j]) {
              this.creditNotes.billingAddr += billArray[j] + ' ' + '<br>' + ' ';
            }
          }
          this.creditNotes.billToParty =
            customer.data.billto[index].party_site_id;
          if (id) {
            if (billTo.length !== 0) {
              flag = 0;
              for (i = 0; i < billTo.length; i++) {
                if (billTo[i].site_primary_flag === 'Y') {
                  this.creditNotes.paymentTerms = billTo[i].payment_methods;
                  flag = 1;
                }
              }
              if (flag !== 1) {
                this.creditNotes.billToData = billTo[0];
                this.creditNotes.paymentTerms = billTo[0].payment_methods;
              }
            }
            if (this.creditNotes.paymentTerms) {
              for (i = 0; i < this.creditNotes.paymentTerms.length; i++) {
                if (this.creditNotes.paymentTerms[i].primary_flag === 'Y') {
                  this.creditNotes.paymentTerms[i].primary_flag = 'N';
                }
              }
              ids = parseInt(this.editCreditNote.receipt_method_id);
              for (j = 0; j < this.creditNotes.paymentTerms.length; j++) {
                if (
                  this.creditNotes.paymentTerms[j].receipt_method_id === ids
                ) {
                  this.creditNotes.paymentTerms[j].primary_flag = 'Y';
                  this.creditNotes.paymentTerm = this.creditNotes.paymentTerms[
                    j
                  ].receipt_method_id;
                  break;
                }
              }
              this.showCustomers = true;
            }
          }
        } else if (customer.data.billto[0]) {
          bill = customer.data.billto[0].billacc_address
            ? customer.data.billto[0].billacc_address
            : '';
          bill1 = customer.data.billto[0].billing_address
            ? customer.data.billto[0].billing_address
            : '';
          billArray = [bill, bill1];
          for (j = 0; j < billArray.length; j++) {
            if (billArray[j]) {
              this.creditNotes.billingAddr += billArray[j] + ' ' + '<br>' + ' ';
            }
          }
          this.creditNotes.billToParty = customer.data.billto[0].party_site_id;
        } else {
          this._appService.notify({
            status: 1,
            msg: 'No Billing address for selected customer!',
          });
          this.creditNotes.paymentTerms = [];
          this.creditNotes.paymentTerm = '';
          this.addressToggle = false;
          this.toggle = false;
          return;
        }
        this.addressToggle = false;
        this.toggle = false;
        this.creditNotes.selectedCustomer = customer;
        this._appService.isCustomerSelected = true;

        if (customer.data.currency) {
          this.creditNotes.currency = customer.data.currency[0].currency_code;
        }
        count = 0;
        if (billTo.length !== 0) {
          for (i = 0; i < billTo.length; i++) {
            if (billTo[i].site_primary_flag === 'Y') {
              this.creditNotes.billToData = billTo[i];
              this.creditNotes.paymentTerms = billTo[i].payment_methods;
              defaultPaymentTerm = CreateNoteComponent.getDefaultPayment(
                this.creditNotes.paymentTerms
              );
              if (defaultPaymentTerm) {
                this.creditNotes.paymentTerm =
                  defaultPaymentTerm.receipt_method_id;
              }
              count = 1;
            }
          }
          if (count !== 1) {
            this.creditNotes.billToData = billTo[0];
            this.creditNotes.paymentTerms = billTo[0].payment_methods;
            defaultPaymentTerm = CreateNoteComponent.getDefaultPayment(
              this.creditNotes.paymentTerms
            );
            if (defaultPaymentTerm) {
              this.creditNotes.paymentTerm =
                defaultPaymentTerm.receipt_method_id;
            }
          }
        }
      }
    });
  }

  onCustSelect(c) {
    this.creditNotes.customer = c.cust_account_id;
    this.creditNotes.customer_name = c.customer_name;
    setTimeout(() => {
      (document.getElementById(
        'customer_name'
      ) as HTMLInputElement).value = this.creditNotes.customer_name;
      // this.$apply();
    }, 10);
  }

  onDebitChange() {
    if (
      (!this.creditNotes.debitTo ||
        !this.debitToWithSaima.includes(this.creditNotes.debitTo)) &&
      !this.creditNotes.editCredit
    ) {
      for (let i = 0; i < this.creditLines.length; i++) {
        this.creditLines[i].saima = '';
        this.creditLines[i].saimaAmount = '';
      }
    }
  }

  // Download Attachment
  onDownload(data, fileName) {
    let blobFile = CreateNoteComponent.base64ToBlob(data),
      a,
      url;
    if (blobFile) {
      a = document.createElement('a');
      document.body.appendChild(a);
      url = this._window.URL.createObjectURL(blobFile);
      a.href = url;
      a.download = fileName;
      a.click();
      this._window.URL.revokeObjectURL(url);
    }
  }

  // called on Ok icon click in ShipTo
  onShippingOk() {
    let i, j, shipTo, tmpAddress, ship, ship1, shipArray;
    if (this.creditNotes.selectedCustomer.data) {
      shipTo = parseInt(this.creditNotes.shipToParty);
      tmpAddress = this.creditNotes.selectedCustomer.data.shipto;
      for (i = 0; i < tmpAddress.length; i++) {
        if (shipTo === tmpAddress[i].party_site_id) {
          this.creditNotes.shipToData = tmpAddress[i];
          this.creditNotes.shippingAddr = '';
          ship = tmpAddress[i].billacc_address
            ? tmpAddress[i].billacc_address
            : '';
          ship1 = tmpAddress[i].shipping_address
            ? tmpAddress[i].shipping_address
            : '';
          shipArray = [ship, ship1];
          for (j = 0; j < shipArray.length; j++) {
            if (shipArray[j]) {
              this.creditNotes.shippingAddr +=
                shipArray[j] + ' ' + '<br>' + ' ';
            }
          }
        }
      }
    }
  }

  // called when class changes
  onTypeChange(lookUpCode) {
    this.creditNotes.transactions = this.filterTransactionsByType(
      this.creditNotes.class
    );
    this.creditNotes.class = lookUpCode === 'CM' ? 'CM' : 'INV';
    this.updateTotal();
  }

  parseSaima(value, line, saima_type) {
    if (value !== null && value !== undefined && value !== '') {
      value =
        saima_type === 'quantity'
          ? parseInt(value)
          : this._formatService.numberParser(value);
      if (saima_type === 'quantity') {
        line.saima = isNaN(value) ? '' : value;
      }
      line.saimaAmount = saima_type === 'amount' ? value : line.saimaAmount;
      if (saima_type === 'quantity' && isNaN(value)) {
        this._appService.notify({
          msg: 'Enter only numeric values in SAIMA',
          status: 1,
        });
      }
    }
  }

  // payment terms
  paymentTerms(id) {
    let billTo, endPoint, ids, i, j;
    if (id) {
      endPoint = '/customer/paymentterms/' + id + '/';
      this._httpService.httpRequest('GET', endPoint, null, (paymentTerms) => {
        if (paymentTerms === null || paymentTerms === undefined) {
          // Goto summary page when empty payment terms
          this._router.navigate(['creditnotes/summary']);
          this._appService.notify({
            status: 1,
            msg: 'Server Error - paymentTerms',
          });
        } else if (paymentTerms.status === 1) {
          this._appService.notify(new APIError(paymentTerms.msg));
        } else {
          ids = parseInt(this.editCreditNote.receipt_method_id);
          billTo = parseInt(this.editCreditNote.bill_to_site_use_id);
          this.creditNotes.paymentTerms = paymentTerms[billTo];
          if (this.creditNotes.paymentTerms) {
            for (i = 0; i < this.creditNotes.paymentTerms.length; i++) {
              if (this.creditNotes.paymentTerms[i].primary_flag === 'Y') {
                this.creditNotes.paymentTerms[i].primary_flag = 'N';
              }
            }
            for (j = 0; j < this.creditNotes.paymentTerms.length; j++) {
              if (
                parseInt(this.creditNotes.paymentTerms[j].receipt_method_id) ===
                ids
              ) {
                this.creditNotes.paymentTerms[j].primary_flag = 'Y';
                this.creditNotes.paymentTerm = this.creditNotes.paymentTerms[
                  j
                ].receipt_method_id;
                break;
              }
            }
            this.showCustomers = true;
          } else if (!billTo) {
            this._appService.emptyBillTo = true;
            this._router.navigate(['creditnotes/summary']);
          } else {
            // Goto summary page when empty payment terms
            this._router.navigate(['creditnotes/summary']);
          }
        }
      });
    }
  }

  periodChange(period, keyName): void {
    if (period && !this._formatService.validateDate(period)) {
      this[`focus${keyName}`] = false;
    }
    this.creditNotes.customerComments = '';
    this.creditNotes.internalComments = '';
    this.itemInvoices = [];
    this.creditLines.forEach((creditline) => {
      creditline.invoiceFlag = false;
    });
  }

  prepareLines() {
    let line = {
      item: {},
      item_code: '',
      description: '',
      quantity: '',
      price: '',
      line_price: '',
      extendedAmount: '',
      extendedTotal: '',
      invoiceFlag: false,
    };
    this.creditLines = [];
    this.creditLines.push(line);
  }

  priceValidation(price) {
    this.creditNotes.itemError = false;
    let value = CreateNoteComponent.validatePattern(price),
      comma_index,
      dot_index,
      no_comma_index,
      no_dot_index,
      point;
    if (value) {
      comma_index = price.lastIndexOf(',');
      dot_index = price.lastIndexOf('.');
      no_comma_index = this.number_format.lastIndexOf(',');
      no_dot_index = this.number_format.lastIndexOf('.');
      if (comma_index >= dot_index && no_comma_index >= no_dot_index) {
        // If user number format is '999.999.999,99'
        point = price.lastIndexOf(',');
        // we need to replace ',' with '.'
        if (point !== -1) {
          price = CreateNoteComponent.replaceAt(price, point, '.');
          price = CreateNoteComponent.removeAllButLast(price, '.');
        }
        price = this._formatService.round(parseFloat(price), 2);
        if (price && price >= 0.01) {
          return price;
        } else {
          return null;
        }
      } else if (dot_index >= comma_index && no_dot_index >= no_comma_index) {
        // If user number format is '999,999,999.99'
        price = price.replace(/,/g, '');
        price = this._formatService.round(parseFloat(price), 2);
        if (price && price >= 0.01) {
          return price;
        } else {
          return null;
        }
      } else {
        return null;
      }
    } else if (price) {
      return null;
    } else {
      return null;
    }
  }

  /* this is for reloading the page after submit /save is click in copy or edit */
  reloadPageAfterSubmit(header_id) {
    this._appService.editCredit = true;
    this._appService.editCreditHeader = header_id;
    this.requestHeader = this._appService.editCreditHeader;
    this.creditNotes.editCredit = true;
    this.pageReload = true;
    this.creditNotes.creditCreated = true;
    this.creditNotes.copyCredit = false;
    this.editCreditStatus = 'PENDING_APPROVAL';
    this.goToStep(3);
  }

  // saves credit Note
  saveCreditNote(click?) {
    let attachment, creditNote, dict, i, endData, header_id;
    this.toggles = true;
    this.save = '';
    this.creditNotes.creditUpdate = false;
    this.creditNotes.creditCreated = false;
    this.creditNotes.creationErr = false;
    if (
      this.creditNotes.editCredit ||
      (this.creditNotes.copyCredit && this.editCreditStatus === 'DRAFT')
    ) {
      this.toggle = true;
      dict = {};
      dict.COMMENTS = this.creditNotes.customerComments || '';
      dict.internal_comment = this.creditNotes.internalComments || '';
      dict.ATTRIBUTE1 = this.creditNotes.transaction || '';
      dict.ATTRIBUTE2 = this.creditNotes.selectedCustomer.cust_account_id
        ? this.creditNotes.selectedCustomer.cust_account_id
        : this.creditNotes.customer;
      dict.ATTRIBUTE3 = this.creditNotes.billToData.site_use_id
        ? this.creditNotes.billToData.site_use_id
        : this.bill_to_site_use_id;
      dict.ATTRIBUTE4 = this.creditNotes.shipToData.site_use_id
        ? this.creditNotes.shipToData.site_use_id
        : this.ship_to_site_use_id;
      dict.ATTRIBUTE6 = this.creditNotes.reason || '';
      dict.cm_reason_code = this.creditNotes.reason || '';
      dict.ATTRIBUTE8 = this.creditNotes.debitTo || '';
      dict.ATTRIBUTE10 = this.creditNotes.paymentTerm || '';
      dict.ATTRIBUTE9 = this.creditNotes.applyCreditNoteTo || '';
      dict.ATTRIBUTE11 = this.creditNotes.noSalesCredit || '';
      dict.ATTRIBUTE12 = this.creditNotes.accuredToPreviousyear || '';
      dict.ATTRIBUTE14 = this.creditNotes.relatedToObjective || '';
      if (this.org !== 82) {
        dict.ATTRIBUTE13 = this.creditNotes.icCreditMemoRequired || '';
      } else {
        dict.ATTRIBUTE13 = '';
      }
      dict.org_id = this._dataService.orgId;
      dict.request_id = this.requestHeader;
      dict.deletedAttachments = this.deletedAttachments;
      dict.attachments = [];
      dict.created_by = this.user.user_id;
      dict.last_updated_by = this.user.user_id;
      for (i = 0; i < this.attaches.length; i++) {
        attachment = {};
        if (!this.attaches[i].file_id) {
          attachment.base64 = this.attaches[i].base64;
          attachment.filename = this.attaches[i].filename;
          dict.attachments.push(attachment);
        }
      }
      dict.total_amount = 0;
      if (
        !this.debitToWithSaima.includes(this.creditNotes.debitTo) &&
        this.creditNotes.editCredit
      ) {
        if (this.creditLines.length > 0) {
          for (i = 0; i < this.creditLines.length; i++) {
            this.creditLines[i].saima = '';
            this.creditLines[i].saimaAmount = '';
          }
          dict.update_lines = this.creditLines;
        }
      }

      if (this.creditNotes.copyCredit) {
        dict.credit_lines = this.getCnLines();
        dict.user_id = this.user.user_id;
        dict.customer_trx_id = this.editCreditNote.customer_trx_id;
        dict.delete_lines = this.deletedLines;
      }
      // for submit
      if (click === 'submit') {
        dict.status = 'DRAFT';
        dict.is_submit = true;
      }
      endData = '/creditNote/';
      this._httpService.httpRequest('PUT', endData, dict, (data) => {
        this.pageDim = false;
        this.toggle = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - saveCreditNote',
          });
        } else if (data.status === 0) {
          this.toggle = false;
          this.save = 'save';
          this.creditNotes.creditUpdate = true;
          if (data.attachment_result && data.attachment_result.length > 0) {
            this.loadAttachments(data.attachment_result, this.requestHeader);
          }
          if (click === 'submit') {
            this.reloadPageAfterSubmit(this.requestHeader);
          }

          this._appService.notify({
            status: 0,
            msg: 'Credit Notes updated successfully',
          });
        } else {
          this._appService.notify({ msg: data.msg, status: data.status });
        }
      });
    } else {
      this.toggle = true;
      creditNote = this.getCreateJSON();
      this._httpService.httpRequest(
        'POST',
        '/creditNote/',
        creditNote,
        (data) => {
          this.toggle = false;
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: 'Server Error - saveCreditNote',
            });
          } else if (data && data.msg && data.status === 0 && data.header_id) {
            if (data.attachment_result && data.attachment_result.length > 0) {
              this.loadAttachments(data.attachment_result, data.header_id);
            }
            this._appService.notify({
              status: 0,
              msg: 'Credit Notes created successfully',
            });
            this.save = 'save';
            header_id = data.header_id;
            this.reloadPageAfterSubmit(header_id);
          } else if (data.status === 1) {
            this._appService.notify({ status: 1, msg: data.msg });
          }
        }
      );
    }
    this.pageDim = false;
  }

  selectedRow(line, lineName, index) {
    this.creditNotes.showDialog = true;
    this.selected_row = line;
    if (index) {
      this.selectedIndex = index;
    }
    this.creditNotes.lineName = lineName;
    this.itemsarray = this.items;
  }

  setInvoiceDates(): void {
    const todayDate = this._appService.today(0);
    const date = new Date(todayDate);
    date.setMonth(date.getMonth() - 9);
    const nineMonthDate =
      date.getDate() +
      '-' +
      this._formatService.getMonth(date.getMonth()) +
      '-' +
      date.getFullYear();
    this.invoicePeriodFrom = this._formatService.formatDate(nineMonthDate);
    this.invoicePeriodTo = this._formatService.formatDate(todayDate);
  }

  setUpDOMHandlers() {
    jQuery('.scroll-top').click(() => {
      this._appService.scrollTop();
    });
  }

  transactionsByType() {
    let transactions = this.allTransactions,
      i;
    for (i = 0; i < this.creditNotes.transactions.length; i++) {
      if (
        this.creditNotes.transactions[i].cust_trx_type_id ===
        this.creditNotes.transaction
      ) {
        break;
      }
    }
    if (i >= this.creditNotes.transactions.length) {
      for (i = 0; i < transactions.length; i++) {
        if (this.creditNotes.transaction === transactions[i].cust_trx_type_id) {
          this.creditNotes.transaction = transactions[i].credit_memo_type_id;
          break;
        }
      }
    }
  }

  // update line total
  updateTotal() {
    let total = 0,
      i;
    this.total = 0;
    for (i = 0; i < this.creditLines.length; i++) {
      if (this.creditLines[i].extendedTotal) {
        total = total + this.creditLines[i].extendedTotal;
        this.creditNotes.creditTotal = this._formatService.formatNumber(
          parseFloat(total.toString())
        );
      }
    }
    if (this.creditNotes.class === 'CM' && this.total < 0) {
      total = total * -1;
      this.creditNotes.creditTotal =
        '(' +
        this._formatService.formatNumber(parseFloat(total.toString()) * -1) +
        ')';
    }
    this.total = parseFloat(total.toFixed(2));
  }

  // upload CSV file
  upload() {
    let attachment, number_format, endPoint, req;
    if (Object.keys(this.creditNotes.files).length !== 0) {
      attachment = {};
      attachment.filename = this.creditNotes.files.filename;
      attachment.base64 = this.creditNotes.files.base64;
      attachment.filetype = this.creditNotes.files.filetype;
      this.creditNotes.files = null;
      (document.getElementById('catalog-form') as HTMLFormElement).reset(); // reset the attachment form
      if (this.number_format === '999,999.99') {
        number_format = '.';
      } else {
        number_format = ',';
      }
      endPoint = '/products/readingcsv/cm/';
      req = {};
      req.p_encoded = attachment.base64;
      req.p_org_id = this.org;
      req.p_seperator = number_format;
      this.pageDim = true;
      this.creditNotes.uploadDialog = false;
      this.invalidProducts = [];
      this.validProducts = [];
      this._httpService.httpRequest('POST', endPoint, req, (data) => {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error - upload' });
        } else if (data.status === 0) {
          this._appService.notify({ status: 0, msg: data.msg });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else {
          this.uploadedFileData(data);
        }
      });
    }
  }

  // uploadAttachment
  uploadAttachment(attachments) {
    let sizeWithinLimit;
    this.attachmentErrorMsg = '';
    (document.getElementById('uploadAttachment') as HTMLFormElement).reset();
    (document.getElementById('uploadAttachment1') as HTMLFormElement).reset();
    sizeWithinLimit = this._appService.checkFileSize(
      attachments,
      this.attaches
    );
    if (attachments && sizeWithinLimit) {
      this.creditNotes.attachError = false;
      if (this.attaches.length > 0) {
        for (let i = 0; i < this.attaches.length; i++) {
          if (this.attaches[i].filename === attachments.filename) {
            this.attachmentErrorMsg = 'File already exists!';
            return;
          }
        }
        this.attaches.push(attachments);
        this.creditNotes.attachments = this.attaches;
      } else if (attachments) {
        this.attaches.push(attachments);
        this.creditNotes.attachments = this.attaches;
      }
    } else if (attachments && !sizeWithinLimit) {
      this.attachmentErrorMsg =
        'Uploaded file/files size should not exceed 25MB';
    }
  }

  uploadedFileData(data) {
    let lines = data.valid,
      i,
      index;
    this.invalidProducts = data.invalid;
    this.pageDim = false;
    if (lines.length < 1) {
      this.creditNotes.status = true;
      this._appService.notify({
        status: 1,
        msg:
          'Uploaded file is either invalid or incorrect data. Download the sample file',
      });
    } else {
      this.creditNotes.status = false;
      this.creditNotes.msg = '';
      this.isValid = data.valid;
      for (i = 0; i < this.isValid.length; i++) {
        this.price = this.priceValidation(lines[i].price);
        if (
          lines[i].item_code &&
          lines[i].description &&
          this.price > 0 &&
          parseInt(lines[i].quantity, 10)
        ) {
          index = this.creditLines
            .map((x) => x.item_code)
            .indexOf(lines[i].item_code);
          if (index === -1) {
            lines[i].convertPrice = this.price;
            this.validProducts.push(lines[i]);
          } else {
            this.invalidProducts.push(lines[i]);
          }
        } else {
          this.invalidProducts.push(lines[i]);
        }
      }
      this.creditNotes.itemError = false;
      if (this.invalidProducts.length > 0) {
        this.price = '';
        this.creditNotes.invalidDialog = true;
      } else if (this.validProducts.length > 0) {
        this.price = '';
        this.uploadProducts();
      } else {
        this.creditNotes.status = true;
        this._appService.notify({
          status: 1,
          msg:
            'Uploaded file is either invalid or incorrect data. Download the sample file',
        });
      }
    }
  }

  // UploadProducts
  uploadProducts() {
    let lines, i, extendedAmount, line, line_price;
    if (this.validProducts.length > 0) {
      lines = this.validProducts;
      for (i = 0; i < this.validProducts.length; i++) {
        this.itemNew = this.getItemObj(lines[i].item_code.toUpperCase());
        if (
          this.itemNew.primary_uom_code.toLowerCase() !==
          lines[i].primary_uom_code.toLowerCase()
        ) {
          lines[i].quantity = parseInt(lines[i].quantity, 10) / this.itemNew.pz;
          lines[i].convertPrice = this.itemNew.pz * lines[i].convertPrice;
        } else {
          lines[i].quantity = parseInt(lines[i].quantity, 10);
        }
        extendedAmount = this._formatService.formatNumber(
          lines[i].convertPrice * lines[i].quantity
        );
        line_price = this._formatService.formatNumber(lines[i].convertPrice);
        line = {
          item: this.itemNew,
          item_code: lines[i].item_code,
          description: lines[i].description,
          primary_uom_code: this.itemNew.primary_uom_code,
          price: lines[i].convertPrice,
          line_price,
          quantity: lines[i].quantity,
          extendedTotal: lines[i].convertPrice * lines[i].quantity,
          extendedAmount,
        };
        this.creditLines.push(line);
      }
      this.updateTotal();
      this.validProducts = [];
      this._appService.notify({
        status: 0,
        msg: 'Products Uploaded successfully',
      });
    }
    this.creditNotes.invalidDialog = false;
    this.creditNotes.uploadDialog = false;
    this.creditNotes.status = false;
  }
}
