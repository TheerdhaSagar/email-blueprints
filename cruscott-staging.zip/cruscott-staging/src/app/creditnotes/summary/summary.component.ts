import {
  Component, OnDestroy, OnInit, Injector
} from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { CommonService } from '../../globals/common.service';
import { FilterPipe } from '../../globals/filter.pipe';
import { APIError } from '../../globals/api.error';
import { Customer } from '../../globals/customer';

declare var FooPicker: any;

@Component({
  selector: 'app-creditnotes-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [FilterPipe, OrderByPipe]
})
export class CreditSummaryComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _commonService: CommonService = this.injector.get(CommonService);
  private _dataService: DataService = this.injector.get(DataService);
  private _filter: FilterPipe = this.injector.get(FilterPipe);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  cacheData: any[];
  columnNames: any;
  columns: any[];
  creditNoteData: any;
  creditNotes: any[];
  creditNotesSearch: any;
  currentPage: any;
  customerNumber: number;
  customers: Customer[] = [];
  desc: boolean;
  fromDate: any;
  main_status: any;
  note: any;
  org: any;
  pageDim: any;
  pageSize: any;
  predicate: any;
  requestId: any;
  roles: any;
  salesCredit: string;
  searchIn: any;
  showAdvanced: any;
  showDialog: boolean;
  showLoading: boolean;
  showSpinner: boolean;
  status: string;
  subOrgChange: Subscription;
  toDate: any;
  toggleFilter: any;
  user: any;
  credit: any;
  statusmean: any;

  constructor(private injector: Injector) {
    this._window = window;
  }

  ngOnInit() {
    this.init();
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  advancedSearch(): void {
    this.showAdvanced = true;
    this.searchIn = 'all';
    this.requestId = '';
    this.customerNumber = null;
    this.fromDate = '';
    this.toDate = '';
    this.salesCredit = 'all';
    this.credit.dateError = false;
  }

  // ApplyFilter
  applyFilter() {
    this.pageDim = true;
    this.loadSummary();
    this.toggleFilter();
  }

  cancelModal() {
    this.note = '';
    this.showDialog = false;
  }

  compareDates() {
    this.credit.dateError = false;
    let fromDate, toDate;
    if (this.fromDate && this.toDate) {
      fromDate = this._formatService.dateInMillis(this._formatService.parseDate(this.fromDate));
      toDate = this._formatService.dateInMillis(this._formatService.parseDate(this.toDate));
      if (fromDate > 0 && toDate > 0) {
        if (fromDate > toDate) {
          this.toDate = '';
          this.credit.dateErrMsg = 'From date greater than To date';
          this._appService.notify({ status: 1, msg: this.credit.dateErrMsg });
        }
      } else {
        this.toDate = '';
        this.credit.dateErrMsg = 'Invalid Dates';
        this._appService.notify({ status: 1, msg: this.credit.dateErrMsg });
      }
    }
  }

  copyCreditNote(note) {
    this._appService.copyCredit = true;
    this._appService.copyCreditHeader = note.request_id;
    this._router.navigate(['creditnotes/create']);
  }

  createCreditNote() {
    this._appService.editCredit = false;
    this._appService.editCreditHeader = null;
    this._router.navigate(['creditnotes/create']);
  }

  deleteCreditNote(note) {
    this.note = note;
    this.showDialog = true;
  }

  deleteRow() {
    let note = this.note, requestId = note.request_id, index,
      endPoint = `/creditNote/delete/${requestId}/?status=${this.status}`;
    this.showSpinner = true;
    this.showDialog = false;
    this.note = '';
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - deleteRow' });
      } else if (data.status === 0) {
        index = this.creditNotes.map(x => x.request_id).indexOf(note.request_id);
        if (index !== -1) {
          this.creditNotes.splice(index, 1);
          this._appService.notify({ status: 0, msg: data.msg + ' for #' + requestId });
        }
        if (this.status === 'PENDING_APPROVAL') {
          this._cacheService.setCreditNotes(this.creditNotes);
        }
        this.loadSummary();
      } else {
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  editCredit(note) {
    if (note.status !== 'DRAFT') {
      this._appService.editCredit = true;
      this._appService.editCreditHeader = note.request_id;
      this._appService.editCreditStatus = note.status;
      this._router.navigate(['creditnotes/create']);
    } else {
      this._appService.editCreditStatus = note.status;
      this.copyCreditNote(note);
    }
  }

  // Export table data to excel
  exportToExcel() {
    this.toggleFilter();
    let data = this._orderBy.transform(this.creditNoteData, this.predicate, this.desc),
      tableData: any = {}, i,
      tmpData = [], tmpObj;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj.ID = {
        data: data[i].request_id
      };
      tmpObj['Created On'] = {
        data: data[i].f_requested_date
      };
      tmpObj.Customer = {
        data: data[i].party_name
      };
      tmpObj['Debit To'] = {
        data: data[i].debit_to
      };

      if (data[i].invoice_number) {
        tmpObj['Invoice #'] = {
          data: data[i].invoice_number
        };
      } else {
        tmpObj['Invoice #'] = {
          data: ''
        };
      }
      if (this.main_status === 'COMPLETE') {
        if (data[i].cm_trx_number) {
          tmpObj['Cust Trx #'] = {
            data: data[i].cm_trx_number
          };
        } else {
          tmpObj['Cust Trx #'] = {
            data: ''
          };
        }
      }

      if (data[i].approver_name) {
        tmpObj.Approver = {
          data: data[i].approver_name
        };
      } else {
        tmpObj.Approver = {
          data: ''
        };
      }
      tmpObj.Reason = {
        data: data[i].cm_reason
      };
      if (data[i].f_total_amount) {
        tmpObj.Amount = {
          data: data[i].f_total_amount,
          align: 'right'
        };
      } else {
        tmpObj.Amount = {
          data: ''
        };
      }
      tmpObj.Currency = {
        data: data[i].invoice_currency_code
      };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Credit Notes Summary', tableData, 'notes');
  }

  filterData() {
    let search = this.creditNotesSearch,
      tmp_data;
    this.currentPage = 1;
    if (search) {
      tmp_data = this._filter.transform(this.creditNoteData, search, '');
      this.creditNotes = tmp_data.slice(this.currentPage - 1, this.pageSize);
    } else {
      this.creditNotes = this.creditNoteData.slice(this.currentPage - 1, this.pageSize);
    }
  }

  goToInvoice(id, invoice) {
    this._appService.trx_id = parseInt(id);
    this._appService.invoice_number = parseInt(invoice);
    this._appService.enableDispute = this.roles.isManager || this.roles.isAdmin;
    this._router.navigate(['creditnotes/invoice']);
  }

  init() {
    this.cacheData = [];
    this.columnNames = null;
    this.columns = [];
    this.credit = {
      errMsg: null,
      successMsg: null,
      dateError: false,
      showError: false,
      showSuccess: false,
      dateErrMsg: ''
    };
    this.creditNoteData = null;
    this.creditNotes = [];
    this.creditNotesSearch = null;
    this.currentPage = null;
    this.desc = true;
    this.fromDate = null;
    this.main_status = null;
    this.org = null;
    this.pageDim = null;
    this.pageSize = this._appService.pageSize;
    this.predicate = ['request_id'];
    this.customerNumber = null;
    this.requestId = null;
    this.roles = this._dataService.roles;
    this.searchIn = 'all';
    this.showAdvanced = null;
    this.showDialog = false;
    this.showLoading = true;
    this.showSpinner = false;
    this.status = 'PENDING_APPROVAL';
    this.statusmean = {
      statusMeaning: null
    };
    this.subOrgChange = null;
    this.toDate = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;

    this.setUpDOMHandlers();
    this._window.ga('send', 'pageview', { page: this._location.path() });

    // get user
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        this.org = this._dataService.orgId;
        if (this.roles.isB2b || this.roles.isAgent) {
          this._router.navigate(['quotes/summary']);
          return;
        }

        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        new FooPicker({
          id: 'from',
          dateFormat: this.user.date_format
        });
        new FooPicker({
          id: 'to',
          dateFormat: this.user.date_format
        });
        jQuery('#foopicker-from').addClass('showdatepicker');
        jQuery('#foopicker-to').addClass('showdatepicker');
        this.cacheData = this._cacheService.getCreditNotes();
        if (this.cacheData === undefined || this.cacheData === null) {
          this.cacheData = [];
        }
        if (this._appService.emptyBillTo) {
          // this.credit.showError = true;
          this.credit.errMsg = 'Bill to is Empty';
          this._appService.emptyBillTo = false;
          this._appService.notify({ status: 1, msg: this.credit.errMsg });
        }
        if (this._appService.disputeSaveMsg) {
          this._appService.notify({ status: 0, msg: this._appService.disputeSaveMsg });
          this._appService.disputeSaveMsg = null;
        }
        if (this._appService.editCreditStatus) {
          this.status = this._appService.editCreditStatus;
          this._appService.editCreditStatus = '';
        }
        this.loadCustomers();
        if (this.cacheData.length > 0) {
          if (this.cacheData[0].org_id === this._dataService.orgId) {
            this.currentPage = 1;
            this.creditNoteData = this._orderBy.transform(this.cacheData, this.predicate, this.desc);
            // this.status = cacheService.getStatus();
            this.creditNotes = this.creditNoteData.slice(this.currentPage - 1, this.pageSize);
            this.columnNames = this._cacheService.getColumnNames();
            this.loadSummary();
          } else {
            this.creditNotes = [];
            this.columns = [];
            this.pageDim = true;
            this.loadSummary();
          }
        } else {
          this.creditNotes = [];
          this.columns = [];
          this.pageDim = true;
          this.loadSummary();
        }

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.init();
        });
      }
    });
  }

  // Load all customers in the selected organization
  loadCustomers(): void {
    const customers = this._cacheService.getCustomers();
    if (customers && this._appService.customerOrg === this._dataService.orgId) {
      this.customers = customers;
    } else if (this._commonService.customers && this._commonService.customers.length &&
      this._appService.customerOrg === this._dataService.orgId) {
      this.customers = this._commonService.customers;
    } else {
      this._commonService.customers = null;
      this.customers = [];
      this._commonService.loadCustomers(this.user.user_id, (data) => {
        this._cacheService.setCustomers(data);
        this._appService.customerOrg = this._cacheService.getOrgId();
        this.customers = data;
      });
    }
  }

  // Load more creditnotes when the page is scrolled down
  loadMore() {
    let page = this.currentPage + 1,
      startIndex = (page - 1) * this.pageSize,
      endIndex = page * this.pageSize, tempData, i;
    this.currentPage = page;
    if (this.creditNoteData) {
      tempData = this.creditNoteData.slice(startIndex, endIndex);
      for (i = 0; i < tempData.length; i++) {
        this.creditNotes.push(tempData[i]);
      }
    }
  }

  loadSummary() {
    let columns = [], displayColumns, i, keys, names, obj: any = {}, str, url;
    this.showLoading = true;
    this.statusmean.statusMeaning = this.status.split('_').join(' ').toLowerCase();
    if (this.status === 'ALL') {
      url = '/creditNote/Summary/' + this.org + '/';
    } else {
      url = '/creditNote/Summary/' + this.org + '/' + this.status + '/';
    }
    this.main_status = '';
    this._httpService.httpRequest('GET', url, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadSummary' });
      } else if (data.status === 1) {
        this.showLoading = false;
        this._appService.notify(new APIError(data.msg));
      } else {
        this.showLoading = false;
        if (data.length > 1) {
          this.main_status = data[1].status;
          if (data[1].org_id === this._dataService.orgId) {
            names = data.splice(0, 1);
            this.loadTable(data);
            displayColumns = ['request_id', 'f_requested_date', 'party_name',
              'debit_to', 'invoice_number', 'approver_name', 'cm_reason',
              'f_total_amount', 'invoice_currency_code', 'status'
            ];
            keys = Object.keys(names[0]);
            for (i = 0; i < keys.length; i++) {
              str = this._formatService.formatColumnName(keys[i]);
              if (displayColumns.indexOf(keys[i]) === -1 && str.toLowerCase().search('id') === -1 &&
                str !== 'Cm Trx Number' && str !== 'Cm Trx Date' &&
                str !== 'Accured Currenct Year Flag' && str !== 'Reason Code' && str !== 'Total Amount' &&
                str !== 'Requested Date' && str !== 'Status Meaning') {
                obj.id = 'col-' + i;
                obj.label = this._formatService.formatColumnName(keys[i]);
                obj.name = keys[i];
                obj.checked = false;
                columns.push(obj);
              }
            }
            this.columnNames = columns;
            if (this.status === 'PENDING_APPROVAL' || this.status === 'DRAFT') {
              this._cacheService.setColumnNames(this.columnNames);
            }
          }
        } else {
          this.creditNotes = [];
        }
      }
    });
  }

  loadTable(data) {
    let j;
    for (j = 0; j < data.length; j++) {
      if (data[j].requested_date) {
        data[j].f_requested_date = this._formatService.formatDate(data[j].requested_date);
        data[j].creation_date_millis = this._formatService.dateInMillis(data[j].requested_date);
      }
      if (data[j].total_amount) {
        data[j].f_total_amount = this._formatService.formatNumber(data[j].total_amount);
      }
      if (data[j].status) {
        switch (data[j].status) {
          case 'DRAFT':
            data[j].f_status = 'Draft';
            break;
          case 'PENDING_APPROVAL':
            data[j].f_status = 'Pending Approval';
            break;
          case 'CANCELLED':
            data[j].f_status = 'Cancelled';
            break;
          case 'COMPLETE':
            data[j].f_status = 'Complete';
            break;
          case 'NOT_APPROVED':
            data[j].f_status = 'Not Approved';
            break;
          case 'APPROVED_PEND_COMP':
            data[j].f_status = 'Approved Pending Completion';
            break;
          default:
            break;
        }
      }
    }
    this.currentPage = 1;
    if (this.status === 'PENDING_APPROVAL' || this.status === 'DRAFT') {
      this._cacheService.setCreditNotes(data);
    }
    this.creditNoteData = this._orderBy.transform(data, this.predicate, this.desc);
    this.creditNotes = this.creditNoteData.slice(this.currentPage - 1, this.pageSize);
    this.pageDim = false;
    this.showSpinner = false;
  }

  search() {
    this.showAdvanced = false;
  }

  searchCN() {
    let endPoint = '/creditNote/search', j,
      searchObj: any = {};
    if (this.fromDate && !this.toDate) {
      this.credit.dateErrMsg = 'To date is Mandatory';
      this._appService.notify({ status: 1, msg: this.credit.dateErrMsg });
      return;
    }
    if (!this.fromDate && this.toDate) {
      this.credit.dateErrMsg = 'From date is Mandatory';
      this._appService.notify({ status: 1, msg: this.credit.dateErrMsg });
      return;
    }
    this.showSpinner = true;
    if (this.requestId) {
      searchObj.request_id = this.requestId;
    }
    if (this.customerNumber) {
      searchObj.customer_number = this.customerNumber;
    }
    if (this.fromDate && this.toDate) {
      // TODO: Changed logic need to test code
      searchObj.start_date = this._formatService.parseDate(this.fromDate);
      searchObj.end_date = this._formatService.parseDate(this.toDate);
    }
    searchObj.status = this.searchIn;
    searchObj.org_id = this._cacheService.getOrgId();
    if (this.salesCredit !== 'all') {
      searchObj.no_salesrep_flag = this.salesCredit;
    }
    this.showAdvanced = false;
    this.searchIn = 'all';
    this.requestId = '';
    this.customerNumber = null;
    this.fromDate = '';
    this.toDate = '';
    this.main_status = '';
    this.credit.dateError = false;
    this.toggleFilter();
    this.credit.dateError = false;
    this._httpService.httpRequest('POST', endPoint, searchObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - searchCN' });
      } else {
        this.pageDim = false;
        this.showSpinner = false;
        if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else {
          if (data.length > 0) {
            for (j = 0; j < data.length; j++) {
              if (data[j].requested_date) {
                data[j].f_requested_date = this._formatService.formatDate(data[j].requested_date);
                data[j].creation_date_millis = this._formatService.dateInMillis(data[j].requested_date);
              }
              if (data[j].total_amount) {
                data[j].f_total_amount = this._formatService.formatNumber(data[j].total_amount);
              }
              if (data[j].status) {
                switch (data[j].status) {
                  case 'DRAFT':
                    data[j].f_status = 'Draft';
                    break;
                  case 'PENDING_APPROVAL':
                    data[j].f_status = 'Pending Approval';
                    break;
                  case 'CANCELLED':
                    data[j].f_status = 'Cancelled';
                    break;
                  case 'COMPLETE':
                    data[j].f_status = 'Complete';
                    this.main_status = 'COMPLETE';
                    break;
                  case 'NOT_APPROVED':
                    data[j].f_status = 'Not Approved';
                    break;
                  case 'APPROVED_PEND_COMP':
                    data[j].f_status = 'Approved Pending Completion';
                    break;
                  default:
                    break;
                }
              }
            }
            this.currentPage = 1;
            this.creditNoteData = this._orderBy.transform(data, this.predicate, this.desc);
            this.creditNotes = this.creditNoteData.slice(this.currentPage - 1, this.pageSize);
          } else {
            this.creditNoteData = [];
            this.creditNotes = [];
          }
        }
      }
    });
  }

  setUpDOMHandlers() {
    jQuery('.scroll-top').click(() => {
      this._appService.scrollTop();
    });
  }

  sort(key) {
    this.desc = !this.desc;
    this.predicate = key;
    this.creditNoteData = this._orderBy.transform(this.creditNoteData, this.predicate, this.desc);
    this.currentPage = 1;
    this.creditNotes = this.creditNoteData.slice(this.currentPage - 1, this.pageSize);
  }

  toggleColumn(column) {
    let columns = this.columns, index;
    if (columns) {
      index = columns.indexOf(column);
      if (index > -1) {
        if (columns.length > 1) {
          this.columns.splice(index, 1);
        } else {
          this.columns = [];
        }
      } else {
        this.columns.push(column);
      }
    } else {
      this.columns = [];
      this.columns.push(column);
    }
  }

}
