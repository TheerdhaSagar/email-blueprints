export interface ApplicationFilter {
  campaignId?: string;
  email?: string;
  endDate?: string;
  locales?: string[];
  receipt?: string;
  receiptId?: string;
  startDate?: string;
  status?: string[];
  summary?: boolean;
}
