export interface ProductReport {
  approved_quantity?: number;
  booked_quantity?: number;
  boxes?: string;
  description: string;
  dtc_shipped?: number;
  inventory_item_id?: number;
  item_display_seq?: number;
  needed_quantity?: number;
  needed_quantity_ct?: number;
  ordered_item: string;
  ordered_quantity?: number;
  pz_in_ct?: number;
  selected?: boolean;
  shipped_quantity?: number;
  tot_in_pz?: number;
  total_dtc_quantity?: number;
}
