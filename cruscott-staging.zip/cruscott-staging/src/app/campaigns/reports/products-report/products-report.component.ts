import { Component, OnInit, Injector, ViewChild } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { AgentTargetsService } from '../../../agent-targets/agent-targets.service';
import { Salesrep } from '../../../agent-targets/salesrep';
import { ProductReport } from '../../product-report';
import { QuotePreviewComponent } from '../../quote-preview/quote-preview.component';

@Component({
  templateUrl: './products-report.component.html',
})
export class ProductsReportComponent implements OnInit {
  private _agentTargetsService: AgentTargetsService =
    this.injector.get(AgentTargetsService);
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _router: Router = this.injector.get(Router);

  @ViewChild('quotePreview') quotePreviewCmp: QuotePreviewComponent;

  isAdoptMe = false;
  isQuote = false;
  pageDim: boolean;
  reportData: ProductReport[];
  routerEvents$: Subscription;
  salesrepId: number;
  salesreps: Salesrep[];
  toggleFilter: (e?) => void = this._appService.toggleFilter();
  userId: number;

  constructor(private injector: Injector) {
    this.routerEvents$ = this._router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        if (event.url && event.url.indexOf('adopt-me') !== -1) {
          this.isAdoptMe = true;
        }
      }
    });
  }

  ngOnInit(): void {
    this._cacheService.getUser((user) => {
      if (user) {
        if (!this._cacheService.user) {
          this._cacheService.initialize(user);
        }
        this.userId = user.user_id;
      }
    });
    this.loadAgents();
  }

  createQuote(): void {
    this.pageDim = true;
    this.quotePreviewCmp.createQuote();
  }

  exportToExcel(): void {
    this.quotePreviewCmp.exportToExcel();
  }

  loadAgents(): void {
    this.pageDim = true;
    this._agentTargetsService
      .loadSalesreps()
      .then((result) => {
        this.salesreps = result;
        this.toggleFilter();
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  loadReport(): void {
    if (!this.salesrepId) {
      return;
    }
    this.toggleFilter();
    this.quotePreviewCmp.loadReport();
    this.pageDim = true;
  }
}
