export interface Coordinates {
  lat: number;
  lng: number;
}

export interface ShippingAddress {
  addressType: string;
  businessName?: string;
  carrierNote?: string;
  city: string;
  coordinates: Coordinates;
  country: string;
  doorNumber: string;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  postalCode: string;
  province: string;
  state: string;
  streetAddress: string;
}
