import { ShippingAddress } from './shipping-address';
import { GenericFile } from './campaign-application';
import { Item } from './product';

export interface PetAge {
  birthDate: Date | string;
  months: number;
  years: number;
}

export interface Pet {
  adoptionCertificates: GenericFile[];
  adoptionDate: Date | string;
  age: PetAge;
  gender: string;
  id?: string;
  name: string;
  petAge: string;
  petSize: string;
  photoList: GenericFile[];
  shelter: string;
  status: string;
  type: string;
  welcomeKit: AdoptMeWelcomeKit;
}

export interface AdoptMeWelcomeKit {
  petAge: string;
  petSize: string[];
  petType: string;
  products: Item[];
  welcomeKit: string;
  welcomeKitImage: string;
}

export interface AdoptMeApplication {
  approverId?: number;
  approverName?: string;
  batchId: number;
  createdDate: Date | string;
  email: string;
  id?: string;
  language: string;
  lastUpdatedUserId?: number;
  lastUpdatedUserName?: string;
  orderNumber: string;
  pets: Pet[];
  quoteNumber: number;
  receiptName: string;
  receiptType: string;
  receiptUrl: string;
  rejectReason?: string;
  selected: boolean;
  shippingAddress: ShippingAddress;
  status?: string;
  welcomeKit: AdoptMeWelcomeKit;
}
