import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SummaryComponent } from './summary/summary.component';
import { RegistrationsComponent } from './registrations/registrations.component';
import { ProductsReportComponent } from './reports/products-report/products-report.component';

const routes: Routes = [
  { path: '', component: DashboardComponent },
  { path: 'summary', component: SummaryComponent },
  { path: 'registrations', component: RegistrationsComponent },
  { path: 'adopt-me', component: RegistrationsComponent },
  { path: 'products-report', component: ProductsReportComponent },
  { path: 'adopt-me/products-report', component: ProductsReportComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CampaignsRoutingModule { }
