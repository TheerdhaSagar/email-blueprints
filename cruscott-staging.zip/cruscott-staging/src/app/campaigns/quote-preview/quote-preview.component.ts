import {
  Component,
  Injector,
  Input,
  OnInit,
  Output,
  EventEmitter,
} from '@angular/core';
import { AppService } from 'src/app/globals/app.service';
import { CampaignsService } from '../campaigns.service';
import { ProductReport } from '../product-report';
import { Item } from '../product';
import { productsPzQty } from '../adoptme-mapping';
import { availableLanguages } from '../language';
import { CacheService } from 'src/app/globals/cache.service';
import { CampaignApplication } from '../campaign-application';
import { ApplicationFilter } from '../application-filter';
import { AdoptMeApplication } from '../adoptme-application';
import { OrderByPipe } from 'src/app/globals/order-by.pipe';
import { DTCQuote, DTCQuoteLine } from '../dtc-quote';

@Component({
  templateUrl: './quote-preview.component.html',
  selector: '<app-quote-preview-component></app-quote-preview-component>',
})
export class QuotePreviewComponent implements OnInit {
  private appService: AppService = this.injector.get(AppService);
  private cacheService: CacheService = this.injector.get(CacheService);
  private campaignsService: CampaignsService =
    this.injector.get(CampaignsService);
  private orderBy: OrderByPipe = this.injector.get(OrderByPipe);

  @Input() isAdoptMe = false;
  @Input() salesrepId: number;
  @Input() isQuote = false;
  @Input() userId: number;

  @Output() loadFinish = new EventEmitter();

  firebaseData: ProductReport[];
  oracleData: ProductReport[];
  reportData: ProductReport[];

  constructor(private injector: Injector) {}

  static getAdoptMeProduct(status: string, product: Item): ProductReport {
    const bookedQty = status === 'Booked' ? product.qty : 0;
    const approvedQty = status === 'Approved' ? product.qty : 0;
    const pzQty = productsPzQty[product.item_code] || 1;
    return {
      ordered_item: product.item_code,
      description: product.description,
      pz_in_ct: pzQty,
      booked_quantity: bookedQty,
      approved_quantity: approvedQty,
      total_dtc_quantity: bookedQty + approvedQty,
    };
  }

  static getAdoptMeProductData(
    application: AdoptMeApplication
  ): ProductReport[] {
    const { welcomeKit } = application.pets[0];
    if (!welcomeKit || !welcomeKit.products) {
      return [];
    }
    const products = [];
    welcomeKit.products.forEach((product) => {
      products.push(
        QuotePreviewComponent.getAdoptMeProduct(application.status, product)
      );
    });
    const box = QuotePreviewComponent.getWelcomeKitBox(
      welcomeKit.petType,
      welcomeKit.petSize
    );
    const boxProduct = { item_code: box, qty: 1, description: box } as Item;
    products.push(
      QuotePreviewComponent.getAdoptMeProduct(application.status, boxProduct)
    );
    return products;
  }

  static getExcelRow(row: ProductReport): object {
    const colorCode =
      row.needed_quantity && row.needed_quantity >= 0 ? '#ec8385' : '';
    return {
      'Item Code': { data: row.ordered_item },
      Description: { data: row.description },
      'Qty in Pz': { data: row.pz_in_ct, align: 'right' },
      'Oracle Qty in OM (Ct)': { data: row.ordered_quantity, align: 'right' },
      'Oracle Qty in OM (Pz)': { data: row.tot_in_pz, align: 'right' },
      'Shipped Qty in Pz': { data: row.booked_quantity, align: 'right' },
      'To be Shipped Qty in Pz': {
        data: row.approved_quantity,
        align: 'right',
      },
      'Total Qty in Pz': { data: row.total_dtc_quantity, align: 'right' },
      'Available Qty in Pz': {
        data: row.needed_quantity ? row.needed_quantity * -1 : '',
        align: 'right',
        color_code: colorCode,
      },
      'Available Qty in Ct': {
        data: row.needed_quantity_ct ? row.needed_quantity_ct * -1 : '',
        align: 'right',
        color_code: colorCode,
      },
    };
  }

  static getSelectedProduct(application: CampaignApplication): ProductReport {
    if (!application.selectedFlavour) {
      return null;
    }
    const product = application.selectedFlavour;
    const bookedQty = application.status === 'Booked' ? 1 : 0;
    const approvedQty = application.status === 'Approved' ? 1 : 0;
    const pzQty = parseInt(product.no_of_pieces, 10) || 1;
    return {
      ordered_item: product.item_code,
      description: product.description,
      pz_in_ct: pzQty,
      booked_quantity: bookedQty,
      approved_quantity: approvedQty,
      total_dtc_quantity: bookedQty + approvedQty,
    };
  }

  static getWelcomeKitBox(petType: string, petSize: string[]): string {
    if (
      petType === 'dog' &&
      petSize.indexOf('medium') !== -1 &&
      petSize.indexOf('large') !== -1
    ) {
      return 'ADOPTMEBOX2';
    }
    return 'ADOPTMEBOX1';
  }

  ngOnInit(): void {
    this.loadReport();
  }

  buildReport(): void {
    this.formatOracleData();
    this.reportData = [...this.oracleData];
    this.firebaseData.forEach((row) => {
      let item = this.reportData.find(
        (product) => product.ordered_item === row.ordered_item
      );
      if (item) {
        item.booked_quantity += row.booked_quantity;
        item.approved_quantity += row.approved_quantity;
        item.total_dtc_quantity = item.booked_quantity + item.approved_quantity;
        item.needed_quantity = item.approved_quantity - (item.tot_in_pz || 0);
        item.needed_quantity_ct = Math.ceil(
          item.needed_quantity / item.pz_in_ct
        );
      } else {
        item = { ...row };
        item.needed_quantity = row.approved_quantity;
        item.needed_quantity_ct = Math.ceil(
          item.needed_quantity / item.pz_in_ct
        );
        this.reportData.push(item);
      }
    });
    if (!this.isAdoptMe) {
      this.updateBoxes();
    }
    if (this.isQuote) {
      this.showQuoteProducts();
    }
    this.loadFinish.emit();
  }

  calculateBoxesToBeShipped(box: string): number {
    return this.reportData.reduce(
      (total, row) =>
        total + (row.boxes === box ? row.approved_quantity || 0 : 0),
      0
    );
  }

  createQuote(): void {
    let quote = this.getDTCQuote();
    this.campaignsService
      .createOrder(quote)
      .then((result) => {
        this.appService.notify(result);
        if (result.status === 0) {
          this.isQuote = false;
          this.reportData.forEach((_, index) => {
            this.reportData[index].selected = false;
          });
        }
      })
      .catch((error) => {
        this.appService.notify(error);
      })
      .finally(() => {
        this.loadFinish.emit();
      });
  }

  exportToExcel(): void {
    if (!this.reportData) {
      return;
    }
    const tableData = { data: [] };
    const data = this.orderBy.transform(
      this.reportData,
      'item_display_seq',
      false
    );
    data.forEach((row: ProductReport) => {
      tableData.data.push(QuotePreviewComponent.getExcelRow(row));
    });
    this.appService.tableToExcel(
      'DTC Products Report',
      tableData,
      'export-data'
    );
  }

  formatOracleData(): void {
    this.oracleData.forEach((product) => {
      product.booked_quantity = product.dtc_shipped || 0;
      product.approved_quantity = product.approved_quantity || 0;
      product.total_dtc_quantity =
        product.booked_quantity + product.approved_quantity;
      product.needed_quantity =
        product.approved_quantity - (product.tot_in_pz || 0);
      product.needed_quantity_ct = Math.ceil(
        product.needed_quantity / product.pz_in_ct
      );
    });
  }

  getDTCQuote(): DTCQuote {
    let selectedItems = this.reportData.filter(
      (item) => item.selected === true
    );
    if (selectedItems.length === 0) {
      selectedItems = this.reportData.filter(
        (item) => item.needed_quantity_ct > 0
      );
    }
    const dtcQuote: DTCQuote = {} as DTCQuote;
    dtcQuote.user_id = this.userId;
    dtcQuote.org_id = this.cacheService.getOrgId();
    dtcQuote.is_adoptme = this.isAdoptMe ? 'Y' : 'N';
    dtcQuote.lines = [];
    selectedItems.forEach((item) => {
      dtcQuote.lines.push({
        item_code: item.ordered_item,
        quantity: item.needed_quantity_ct,
      });
    });
    return dtcQuote;
  }

  getFilterData(): ApplicationFilter {
    const filters = {} as ApplicationFilter;
    filters.locales = this.getLocalesForOrg();
    filters.status = ['Approved', 'Booked'];
    filters.receipt = this.isAdoptMe ? '' : 'Y';
    return filters;
  }

  getLocalesForOrg(): string[] {
    return availableLanguages
      .filter((lang) => lang.orgId === this.cacheService.getOrgId())
      .map((lang) => lang.locale);
  }

  getQuoteLines(): DTCQuoteLine[] {
    const lines: DTCQuoteLine[] = [];
    this.reportData.forEach((row: ProductReport) => {
      lines.push({
        item_code: row.ordered_item,
        quantity: row.needed_quantity_ct,
      });
    });
    return lines;
  }

  async loadAdoptMeApplications(): Promise<void> {
    this.firebaseData = [];
    const filters = this.getFilterData();
    filters.status = ['Approved'];
    const approvedApplications =
      await this.campaignsService.getAdoptMeApplications(filters);
    filters.status = ['Booked'];
    const bookedApplications =
      await this.campaignsService.getAdoptMeApplications(filters);
    if (approvedApplications) {
      approvedApplications.forEach((application) => {
        this.firebaseData = this.firebaseData.concat(
          QuotePreviewComponent.getAdoptMeProductData(application)
        );
      });
    }
    if (bookedApplications) {
      bookedApplications.forEach((application) => {
        this.firebaseData = this.firebaseData.concat(
          QuotePreviewComponent.getAdoptMeProductData(application)
        );
      });
    }
    this.buildReport();
  }

  loadReceipts(): void {
    this.firebaseData = [];
    const filters = {
      locales: this.getLocalesForOrg(),
      status: ['Approved'],
      receipt: 'Y',
    };
    this.campaignsService
      .getReceipts(filters)
      .then((result) => {
        (result as CampaignApplication[]).forEach((appl) => {
          const product = QuotePreviewComponent.getSelectedProduct(appl);
          if (product) {
            this.firebaseData.push(product);
          }
        });
        this.buildReport();
      })
      .catch((error) => {
        this.appService.notify(error);
      });
  }

  loadReport(): void {
    if (!this.salesrepId) {
      return;
    }
    const orgId = this.cacheService.getOrgId();
    this.oracleData = [];
    this.campaignsService
      .getProductReport(
        this.salesrepId,
        CampaignsService.getCountryCodeForOrg(orgId)
      )
      .then((result) => {
        this.oracleData = result;
        if (this.isAdoptMe) {
          this.loadAdoptMeApplications();
        } else {
          this.loadReceipts();
        }
      })
      .catch((error) => {
        this.appService.notify(error);
      });
  }

  showQuoteProducts(): void {
    this.reportData = this.reportData.filter(
      (row: ProductReport) => row.needed_quantity_ct > 0
    );
  }

  updateBoxes(): void {
    const dtcBoxes = ['DTCBOX1', 'DTCBOX2', 'DTCBOX3', 'DTCBOX4'];
    dtcBoxes.forEach((box) => {
      const count = this.calculateBoxesToBeShipped(box);
      const index = this.reportData.findIndex(
        (row) => row.ordered_item === box
      );
      if (index !== -1) {
        const shipped = this.reportData[index].dtc_shipped;
        const toBeShipped = count;
        this.reportData[index].booked_quantity = shipped;
        this.reportData[index].approved_quantity = toBeShipped;
        this.reportData[index].total_dtc_quantity = shipped + toBeShipped;
        this.reportData[index].needed_quantity =
          this.reportData[index].approved_quantity -
          (this.reportData[index].tot_in_pz || 0);
        this.reportData[index].needed_quantity_ct =
          this.reportData[index].needed_quantity;
      }
    });
  }
}
