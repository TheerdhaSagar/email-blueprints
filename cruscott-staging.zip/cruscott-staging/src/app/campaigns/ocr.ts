export interface OCRVendor {
  address: string;
  category: string;
  email: string;
  fax_number: string;
  name: string;
  phone_number: string;
  raw_name: string;
  vendor_type: string;
  web: string;
}

export interface OCRLine {
  date: string;
  description: string;
  discount: number;
  hsn: string;
  id: number;
  matchedProduct?: string;
  order: number;
  price: number;
  quantity: number;
  sku: string;
  tags: string[];
  tax: number;
  tax_rate: number;
  total: number;
  type: string;
  unit_of_measure: string;
}

export interface OCR {
  account_number: string;
  created: string;
  currency_code: string;
  date: string;
  discount: number;
  document_reference_number: string;
  id: number;
  invoice_number: string;
  line_items: OCRLine[];
  ocr_text: string;
  order_date: string;
  phone_number: string;
  subtotal: number;
  tax: number;
  total: number;
  vat_number: string;
  vendor: OCRVendor;
}
