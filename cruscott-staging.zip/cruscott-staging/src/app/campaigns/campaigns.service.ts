import { Injectable, Injector } from '@angular/core';
import { AngularFireFunctions } from '@angular/fire/functions';
import { AngularFireStorage } from '@angular/fire/storage';
import { finalize } from 'rxjs/operators';
import { FormatService } from '../globals/format.service';
import { HttpService } from '../globals/http.service';
import { ServerError } from '../globals/server.error';
import { APIError } from '../globals/api.error';
import { Campaign } from './campaign';
import { CampaignApplication } from './campaign-application';
import { OCR } from './ocr';
import { Item, ProductMetaData } from './product';
import { ApplicationFilter } from './application-filter';
import { DTCQuote, DTCQuoteResponse } from './dtc-quote';
import { AdoptMeApplication } from './adoptme-application';
import { ProductReport } from './product-report';

@Injectable({
  providedIn: 'root',
})
export class CampaignsService {
  private _formatService: FormatService = this.injector.get(FormatService);
  private _fns: AngularFireFunctions = this.injector.get(AngularFireFunctions);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _storage: AngularFireStorage = this.injector.get(AngularFireStorage);

  constructor(private injector: Injector) {}

  createOrder(quote: DTCQuote): Promise<DTCQuoteResponse> {
    return new Promise((resolve, reject) => {
      const url = '/dtc/order/create/';
      this._httpService.httpRequest('POST', url, quote, (response) => {
        if (!response) {
          reject(new ServerError('createOrder'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  createQuote(quote: DTCQuote): Promise<DTCQuoteResponse> {
    return new Promise((resolve, reject) => {
      const url = '/dtc/quote/create/';
      this._httpService.httpRequest('POST', url, quote, (response) => {
        if (!response) {
          reject(new ServerError('createQuote'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  getAdoptMeApplications(
    filters: ApplicationFilter
  ): Promise<AdoptMeApplication[]> {
    const data = { ...filters };
    if (data.startDate) {
      data.startDate = this._formatService.parseDate(
        data.startDate,
        'dd-MMM-yyyy'
      );
    }
    if (data.endDate) {
      data.endDate = this._formatService.parseDate(data.endDate, 'dd-MMM-yyyy');
    }
    return this._fns
      .httpsCallable('cruscott-getApplications')(data)
      .toPromise();
  }

  getCampaigns(country, campaignId: string = null): Promise<Campaign[]> {
    return this._fns
      .httpsCallable('cruscott-getCampaigns')({ country, id: campaignId })
      .toPromise();
  }

  static getCountryCodeForOrg(orgId: number): string {
    return {
      82: 'IT',
      83: 'DE',
      84: 'CH',
      101: 'FR',
      121: 'GB',
      141: 'CA',
      181: 'NL',
      202: 'US',
    }[orgId];
  }

  getProductReport(
    salesrepId: number,
    country: string
  ): Promise<ProductReport[]> {
    return new Promise((resolve, reject) => {
      const url = `/dtc/products/report/${salesrepId}/${country}/`;
      this._httpService.httpRequest('GET', url, null, (data) => {
        if (!data) {
          reject(new ServerError('getProductReport'));
        } else {
          resolve(data);
        }
      });
    });
  }

  getProductFlavours(
    country: string,
    language: string,
    petType: string
  ): Promise<string[]> {
    return new Promise((resolve, reject) => {
      const url = `/cms/filters/?lang=${language}&country=${country}&pet_type=${petType}`;
      this._httpService.httpRequest('GET', url, null, (data) => {
        if (!data) {
          reject(new ServerError('getProductFlavours'));
        } else {
          const flavours = data.food_flavour;
          resolve(flavours.map((flavour) => flavour.flavour));
        }
      });
    });
  }

  getProductMetaData(
    itemCode: string,
    country: string,
    language: string
  ): Promise<ProductMetaData> {
    return new Promise((resolve, reject) => {
      const url = `/cms/recipes/?item_code=${itemCode}&language=${language}&country=${country}&meta_data=Y`;
      this._httpService.httpRequest('GET', url, null, (data) => {
        if (!data) {
          reject(new ServerError('getProductMetaData'));
        } else {
          resolve(data);
        }
      });
    });
  }

  getProducts(
    animal: string,
    country: string,
    language: string
  ): Promise<Item[]> {
    const url = `/cms/recipes/?language=${language}&country=${country}&animal=${animal}&no_cache=true&group_by=no`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', url, null, (data) => {
        if (!data) {
          reject(new ServerError('getProducts'));
        } else {
          resolve(CampaignsService.parseProductsData(data));
        }
      });
    });
  }

  getReceipts(
    filters: ApplicationFilter
  ): Promise<CampaignApplication[] | OCR[]> {
    const data = { ...filters };
    if (data.startDate) {
      data.startDate = this._formatService.parseDate(data.startDate);
    }
    if (data.endDate) {
      data.endDate = this._formatService.parseDate(data.endDate);
    }
    return this._fns.httpsCallable('cruscott-getReceipts')(data).toPromise();
  }

  getReceiptProductData(locales: string[]): Promise<CampaignApplication[]> {
    const data = { locales: [...locales] };
    return this._fns
      .httpsCallable('cruscott-getReceiptProductData')(data)
      .toPromise();
  }

  manageCampaign(campaign: Campaign): Promise<Campaign> {
    const data = { ...campaign };
    if (data.startDate) {
      data.startDate = this._formatService.parseDate(data.startDate);
    }
    if (data.endDate) {
      data.endDate = this._formatService.parseDate(data.endDate);
    }
    return this._fns
      .httpsCallable('cruscott-manageCampaign')({ campaign: data })
      .toPromise();
  }

  manageAdoptionApplication(
    receipt: AdoptMeApplication
  ): Promise<{ status: string }> {
    const data = { ...receipt };
    delete data.welcomeKit;
    return this._fns
      .httpsCallable('cruscott-manageAdoptionApplication')({
        application: data,
      })
      .toPromise();
  }

  manageReceipt(receipt: CampaignApplication): Promise<{ status: string }> {
    const data = { ...receipt };
    delete data.ocr;
    return this._fns
      .httpsCallable('cruscott-manageReceipt')({ receipt: data })
      .toPromise();
  }

  static parseProductsData(data): Item[] {
    const products = [];
    data.forEach((item) => {
      let weight = '';
      if (item.weight && Array.isArray(item.weight)) {
        weight = `${item.weight[0].weight} ${item.weight[0].weight_uom}`;
      }
      products.push({
        item_code: item.item_code,
        bar_code: item.bar_code,
        description: `${item.brand_name_new} ${item.segment_range_new} ${item.recipe}`,
        ean_code: item.ean_code,
        card_image_main: item.card_image_main,
        weight,
        no_of_pieces: item.no_of_pieces || '',
      });
    });
    return products;
  }

  uploadAttachment(filePath: string, file: File): Promise<string> {
    return new Promise((resolve) => {
      const fileRef = this._storage.ref(filePath);
      const task = this._storage.upload(filePath, file);
      task
        .snapshotChanges()
        .pipe(
          finalize(() => {
            fileRef.getDownloadURL().subscribe((url) => {
              resolve(url);
            });
          })
        )
        .subscribe();
    });
  }
}
