import { Product, Segment } from './product';

export interface Campaign {
  active: string;
  animal: string;
  animalSize: string;
  campaignImageUrl: string;
  campaignType: string;
  campaignUrl: string;
  country: string;
  description: string;
  endDate: string;
  flavour: string[];
  id: string;
  imageUrl: string;
  language: string;
  name: string;
  productConfig: string;
  products: Product[];
  quantity: number;
  segments: Segment[];
  startDate: string;
}
