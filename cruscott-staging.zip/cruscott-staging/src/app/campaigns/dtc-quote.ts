import { DTCShipment } from './dtc-shipment';
import { Response } from '../globals/response';

export interface QuotePreviewLineItem {
  description: string;
  fulfilled_orders: number;
  item_code: string;
  order_numbers: string[];
  pending_orders: number;
  qty_in_pz: number;
  qty_in_ct: number;
  selected: boolean;
}

export interface DTCQuoteHeader {
  user_id: number;
  org_id: number;
  is_adoptme?: string;
  quote_id?: number;
  quote_name?: string;
}

export interface DTCQuoteLine {
  item_code: string;
  quantity: number;
}

export interface DTCQuote extends DTCQuoteHeader {
  lines: DTCQuoteLine[];
  shipments: DTCShipment[];
}

export interface DTCQuoteResponse extends Response {
  batch_id: number;
}
