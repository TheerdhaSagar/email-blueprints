import { ShippingAddress } from './shipping-address';
import { Item } from './product';
import { OCR, OCRLine } from './ocr';

export interface GenericFile {
  fileName: string;
  fileType: string;
  fileUrl: string;
}

export interface CampaignApplication {
  animalPhoto?: GenericFile;
  approverId?: number;
  approverName?: string;
  batchId: number;
  campaignId: string;
  campaignName: string;
  createdDate: string;
  description?: string;
  email: string;
  id: string;
  item_code?: string;
  language: string;
  lastUpdatedUserId?: number;
  lastUpdatedUserName?: string;
  message?: string;
  ocr: OCR;
  ocrAvailable: boolean;
  orderNumber: string;
  no_of_pieces?: number;
  productsPhoto?: GenericFile;
  quantity?: number;
  quoteNumber: number;
  receiptName: string;
  receiptType: string;
  receiptUrl: string;
  rejectReason?: string;
  selected?: boolean;
  selectedFlavour?: Item;
  selectedProducts?: Array<{ campaignProduct: Item; receiptProduct: OCRLine }>;
  shippingAddress: ShippingAddress;
  status: string;
}
