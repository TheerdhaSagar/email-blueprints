import {
  Component,
  OnInit,
  Injector,
  OnDestroy,
  ViewChild,
} from '@angular/core';
import { FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { CampaignsService } from '../campaigns.service';
import { availableLanguages } from '../language';
import { Campaign } from '../campaign';
import { Prediction } from '../prediction';
import { OCR } from '../ocr';
import { CampaignApplication, GenericFile } from '../campaign-application';
import { AdoptMeApplication } from '../adoptme-application';
import { Item } from '../product';
import { ApplicationFilter } from '../application-filter';
import { DTCQuote, QuotePreviewLineItem } from '../dtc-quote';
import { DTCShipment, DTCShipmentLine } from '../dtc-shipment';
import { FilterPipe } from 'src/app/globals/filter.pipe';
import { QuotePreviewComponent } from '../quote-preview/quote-preview.component';

@Component({
  selector: 'app-registrations',
  templateUrl: './registrations.component.html',
  styleUrls: ['./registrations.component.scss'],
  providers: [FilterPipe],
})
export class RegistrationsComponent implements OnInit, OnDestroy {
  private appService: AppService = this.injector.get(AppService);
  private cacheService: CacheService = this.injector.get(CacheService);
  private campaignsService: CampaignsService =
    this.injector.get(CampaignsService);
  private filterPipe: FilterPipe = this.injector.get(FilterPipe);
  private routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private router: Router = this.injector.get(Router);

  @ViewChild('quotePreview') quotePreviewCmp: QuotePreviewComponent;

  addressFieldValidations = [
    ['firstName', 18],
    ['lastName', 17],
    ['address', 35],
    ['city', 25],
    ['postalCode', 5],
    ['province', 2],
    ['phoneNumber', 20],
  ];
  adoptMeCertificates: GenericFile[];
  applications: CampaignApplication[] | AdoptMeApplication[];
  campaigns: Campaign[];
  canSelect: boolean;
  dateFormat: string;
  editShippingDialog = false;
  filter = 'Processing';
  filter$: Subscription;
  image: HTMLImageElement;
  imageHeight: number;
  imageWidth: number;
  isAdoptMe = false;
  org$: Subscription;
  pageDim: boolean;
  quotePreviewItems: QuotePreviewLineItem[];
  rejectReason: string;
  routerEvents$: Subscription;
  salesrepId = 100438304;
  searchQuery: string;
  selectedApplication: CampaignApplication | AdoptMeApplication;
  selectedPrediction: Prediction;
  showFilter: boolean;
  showGenerateBtn = false;
  showQuotePreview: boolean;
  showRejectDialog: boolean;
  showShippingDetails: boolean;
  showShippingPreview: boolean;
  userId: number;
  userName: string;
  validationErrorMessage: string;
  withReceipt: string;
  zoom: boolean;

  searchForm = this.fb.group({
    campaignId: '',
    startDate: '',
    email: '',
    endDate: '',
    status: 'Processing',
    receipt: '',
    receiptId: '',
  });

  addressForm = this.fb.group({
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    postalCode: '',
    province: '',
    phoneNumber: '',
  });

  get form(): { [key: string]: AbstractControl } {
    return this.addressForm.controls;
  }

  get recordCount(): number {
    if (!this.applications) {
      return 0;
    }
    if (this.searchQuery) {
      return this.filterPipe.transform(this.applications, this.searchQuery)
        .length;
    }
    return this.applications.length;
  }

  get shippingCountry(): string {
    if (
      !this.selectedApplication ||
      !this.selectedApplication.shippingAddress
    ) {
      return '';
    }
    return this.selectedApplication.shippingAddress.country;
  }

  static clearCanvas(): void {
    const canvas = document.getElementById('canvas') as HTMLCanvasElement;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  }

  static checkItemExists(item: QuotePreviewLineItem, flavour: Item): boolean {
    return (
      item.item_code === flavour.item_code &&
      item.fulfilled_orders % item.qty_in_ct !== 0
    );
  }

  static getExistingQuoteItem(
    id: string,
    flavour: Item,
    quoteItem: QuotePreviewLineItem
  ): QuotePreviewLineItem {
    const item = { ...quoteItem };
    const fulfilledOrders = item.fulfilled_orders + 1;
    item.fulfilled_orders = fulfilledOrders;
    item.order_numbers.push(id);
    if (fulfilledOrders % quoteItem.qty_in_pz === 0) {
      item.qty_in_ct += 1;
      item.pending_orders = 0;
      return item;
    }
    if (item.pending_orders > 0) {
      item.pending_orders -= 1;
      return item;
    }
    return RegistrationsComponent.getNewQuoteItem(id, flavour);
  }

  static getNewQuoteItem(id: string, flavour: Item): QuotePreviewLineItem {
    const noOfPieces = parseInt(flavour.no_of_pieces, 10) || 0;
    return {
      item_code: flavour.item_code,
      description: flavour.description,
      qty_in_pz: noOfPieces,
      qty_in_ct: noOfPieces === 1 ? 1 : 0,
      fulfilled_orders: 1,
      pending_orders: noOfPieces - 1,
      selected: false,
      order_numbers: [id],
    };
  }

  static getShipmentLinesDTC(
    application: CampaignApplication
  ): DTCShipmentLine[] {
    if (!application.selectedFlavour) {
      return [];
    }
    return [
      {
        product_code: application.selectedFlavour.item_code,
        quantity: application.selectedFlavour.quantity || 1,
        line_num: 1,
      },
    ];
  }

  static getShipmentLinesAdoptMe(
    application: AdoptMeApplication
  ): DTCShipmentLine[] {
    const { welcomeKit } = application.pets[0];
    const lines = [];
    if (!welcomeKit || !welcomeKit.products) {
      return lines;
    }
    welcomeKit.products.forEach((product, index) => {
      lines.push({
        product_code: product.item_code,
        quantity: product.qty,
        line_num: index + 1,
      });
    });
    lines.push({
      product_code: RegistrationsComponent.getWelcomeKitBox(
        welcomeKit.petType,
        welcomeKit.petSize
      ),
      quantity: 1,
      line_num: lines.length + 1,
    });
    return lines;
  }

  static getSplitShipments(shipment: DTCShipment): DTCShipment[] {
    const splitShipments = [];
    shipment.lines.forEach((line) => {
      const obj = { ...shipment };
      delete obj.lines;
      splitShipments.push({ ...line, ...obj });
    });
    return splitShipments;
  }

  static getWelcomeKitBox(petType: string, petSize: string[]): string {
    if (
      petType === 'dog' &&
      petSize.indexOf('medium') !== -1 &&
      petSize.indexOf('large') !== -1
    ) {
      return 'ADOPTMEBOX2';
    }
    return 'ADOPTMEBOX1';
  }

  constructor(
    private domSanitizer: DomSanitizer,
    private injector: Injector,
    private fb: FormBuilder
  ) {
    this.routerEvents$ = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        if (event.url && event.url.indexOf('adopt-me') !== -1) {
          this.isAdoptMe = true;
        }
      }
    });
  }

  ngOnInit(): void {
    this.cacheService.getUser((user) => {
      if (!user) {
        this.router.navigate(['login']);
      } else {
        if (!this.cacheService.user) {
          this.cacheService.initialize(user);
        }
        this.userId = user.user_id;
        this.dateFormat = 'dd-MMM-yyyy';
        this.userName = user.user_description;
        this.addSubscriptions();
        if (!this.isAdoptMe) {
          this.loadCampaigns();
        } else {
          this.loadAdoptMeApplications();
        }
      }
    });
  }

  ngOnDestroy(): void {
    if (this.filter$) {
      this.filter$.unsubscribe();
    }
    if (this.routerEvents$) {
      this.routerEvents$.unsubscribe();
    }
    if (this.org$) {
      this.org$.unsubscribe();
    }
  }

  addSubscriptions(): void {
    if (!this.isAdoptMe) {
      this.routeParams.queryParams.subscribe((params) => {
        this.withReceipt = params.receipt;
        this.searchForm
          .get('receipt')
          .patchValue(this.withReceipt === 'no' ? 'N' : 'Y');
        this.loadReceipts();
      });
    }
    this.filter$ = this.searchForm
      .get('status')
      .valueChanges.subscribe((value) => {
        this.filter = value;
      });
    this.org$ = this.appService.subscribeOrgChange(() => {
      if (this.isAdoptMe) {
        this.loadAdoptMeApplications();
      } else {
        this.loadReceipts();
      }
    });
  }

  cancelSelection(): void {
    this.applications = (this.applications as CampaignApplication[]).map(
      (application) => {
        const temp = { ...application };
        temp.selected = false;
        return temp;
      }
    );
  }

  canCreateQuote(): boolean {
    return (
      this.quotePreviewItems &&
      this.quotePreviewItems.some((item) => item.selected === true)
    );
  }

  createQuote(): void {
    const quote = this.generateShippingFiles();
    this.pageDim = true;
    this.campaignsService
      .createQuote(quote)
      .then((result) => {
        this.appService.notify(result);
        if ('batch_id' in result) {
          this.updateApplications(quote, result.batch_id);
        }
      })
      .catch((error) => {
        this.appService.notify(error);
      })
      .finally(() => {
        this.showShippingPreview = false;
        this.pageDim = false;
      });
  }

  editAddress(): void {
    const shippingAddress = JSON.parse(
      JSON.stringify(this.selectedApplication.shippingAddress)
    );
    const { streetAddress, doorNumber } = shippingAddress;
    this.addressForm.setValue({
      address: `${streetAddress} ${doorNumber}`,
      city: shippingAddress.city,
      province: this.shippingCountry === 'IT' ? shippingAddress.province : ' ',
      postalCode: shippingAddress.postalCode,
      firstName: shippingAddress.firstName,
      lastName: shippingAddress.lastName,
      phoneNumber: shippingAddress.phoneNumber,
    });
    this.editShippingDialog = true;
    this.setAddressValidators();
  }

  getApplicationIndex(id: string): number {
    if (this.isAdoptMe) {
      return (this.applications as AdoptMeApplication[]).findIndex(
        (appl) => appl.id === id
      );
    }
    return (this.applications as CampaignApplication[]).findIndex(
      (appl) => appl.id === id
    );
  }

  generateShippingFiles(): DTCQuote {
    this.showShippingPreview = false;
    const dtcQuote: DTCQuote = {} as DTCQuote;
    dtcQuote.user_id = this.userId;
    dtcQuote.org_id = this.cacheService.getOrgId();
    dtcQuote.shipments = [];
    for (let i = 0; i < this.applications.length; i++) {
      const shipment = this.getShipmentDetails(this.applications[i]);
      shipment.user_id = this.userId;
      shipment.campaign_identifier = !this.isAdoptMe
        ? (this.applications[i] as CampaignApplication).campaignId
        : 'ADOPTME';
      shipment.dtc_customer_identifier = this.applications[i].id;
      shipment.dtc_order_number = this.applications[i].orderNumber;
      dtcQuote.shipments = dtcQuote.shipments.concat(
        RegistrationsComponent.getSplitShipments(shipment)
      );
    }
    return dtcQuote;
  }

  getDTCQuote(): DTCQuote {
    const selectedItems = this.quotePreviewItems.filter(
      (item) => item.selected === true
    );
    const dtcQuote: DTCQuote = {} as DTCQuote;
    dtcQuote.user_id = this.userId;
    dtcQuote.org_id = this.cacheService.getOrgId();
    dtcQuote.shipments = [];
    dtcQuote.lines = [];
    for (let i = 0; i < selectedItems.length; i++) {
      selectedItems[i].order_numbers.forEach((orderId) => {
        const index = this.getApplicationIndex(orderId);
        const shipment = this.getShipmentDetails(
          this.applications[index] as CampaignApplication
        );
        shipment.user_id = this.userId;
        shipment.dtc_customer_identifier = this.applications[index].id;
        shipment.dtc_order_number = this.applications[index].orderNumber;
        dtcQuote.shipments.push(shipment);
      });
      dtcQuote.lines.push({
        item_code: selectedItems[i].item_code,
        quantity: selectedItems[i].qty_in_ct,
      });
    }
    return dtcQuote;
  }

  getLocalesForOrg(): string[] {
    return availableLanguages
      .filter((lang) => lang.orgId === this.cacheService.getOrgId())
      .map((lang) => lang.locale);
  }

  getShipmentDetails(
    application: CampaignApplication | AdoptMeApplication
  ): DTCShipment {
    const shipment: DTCShipment = {} as DTCShipment;
    shipment.business_name = application.shippingAddress.businessName || '';
    shipment.receiver_first_name = application.shippingAddress.firstName;
    shipment.receiver_last_name = application.shippingAddress.lastName;
    shipment.receiver_email_address = application.shippingAddress.email;
    shipment.receiver_phone_no = application.shippingAddress.phoneNumber;
    shipment.door_number = application.shippingAddress.doorNumber;
    shipment.street_name = application.shippingAddress.streetAddress;
    shipment.city = application.shippingAddress.city;
    shipment.province = application.shippingAddress.province || '';
    shipment.state = application.shippingAddress.state || '';
    shipment.country = application.shippingAddress.country;
    shipment.delivery_instructions =
      application.shippingAddress.carrierNote || '';
    shipment.zip_code = application.shippingAddress.postalCode;
    shipment.lines = this.isAdoptMe
      ? RegistrationsComponent.getShipmentLinesAdoptMe(
          application as AdoptMeApplication
        )
      : RegistrationsComponent.getShipmentLinesDTC(
          application as CampaignApplication
        );
    return shipment;
  }

  loadAdoptMeApplications(): void {
    this.pageDim = true;
    if (this.showFilter) {
      this.showFilter = !this.showFilter;
    }
    this.selectedApplication = null;
    const filters = this.searchForm.value as ApplicationFilter;
    filters.locales = this.getLocalesForOrg();
    filters.status = this.searchForm.get('status').value
      ? [this.searchForm.get('status').value]
      : null;
    this.campaignsService
      .getAdoptMeApplications(filters)
      .then((result) => {
        this.applications = result;
        this.showGenerateBtn =
          this.applications.every((appl) => appl.status === 'Approved') &&
          this.filter === 'Approved';
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  loadCampaigns(): void {
    let country = CampaignsService.getCountryCodeForOrg(
      this.cacheService.getOrgId()
    );
    country += country === 'NL' ? ',BE' : '';
    this.campaignsService.getCampaigns(country).then((result) => {
      this.campaigns = result;
    });
  }

  loadImage(): void {
    this.image = new Image();
    this.image.src = this.selectedApplication.receiptUrl;
    this.image.addEventListener('load', () => {
      this.imageWidth = this.image.width;
      this.imageHeight = this.image.height;
      if (!this.isAdoptMe) {
        this.loadReceiptOCR();
      } else {
        this.redrawCanvas();
      }
    });
  }

  loadReceiptOCR(): void {
    const filters = this.searchForm.value as ApplicationFilter;
    filters.receiptId = this.selectedApplication.id;
    this.campaignsService
      .getReceipts(filters)
      .then((result) => {
        if (result && result.length) {
          [(this.selectedApplication as CampaignApplication).ocr] =
            result as OCR[];
        } else {
          this.showShippingDetails = true;
        }
        if (this.selectedApplication.receiptType !== 'application/pdf') {
          this.redrawCanvas();
        }
        this.updateOCRSelectedProducts();
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  loadReceipts(): void {
    this.pageDim = true;
    if (this.showFilter) {
      this.showFilter = !this.showFilter;
    }
    this.selectedApplication = null;
    const filters = this.searchForm.value as ApplicationFilter;
    filters.locales = this.getLocalesForOrg();
    filters.status = this.searchForm.get('status').value
      ? [this.searchForm.get('status').value]
      : null;
    filters.summary = true;
    this.campaignsService
      .getReceipts(filters)
      .then((data) => {
        this.applications = data as CampaignApplication[];
        this.showGenerateBtn =
          this.applications.every((appl) => appl.status === 'Approved') &&
          this.filter === 'Approved';
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  previewQuote(): void {
    const quoteItems: QuotePreviewLineItem[] = [];
    for (let i = this.applications.length - 1; i >= 0; i--) {
      const { selectedFlavour, id } = this.applications[
        i
      ] as CampaignApplication;
      const index = quoteItems.findIndex((item) =>
        RegistrationsComponent.checkItemExists(item, selectedFlavour)
      );
      if (index !== -1) {
        const item = RegistrationsComponent.getExistingQuoteItem(
          id,
          selectedFlavour,
          quoteItems[index]
        );
        if (item.fulfilled_orders === 1) {
          quoteItems.push(item);
        } else {
          quoteItems[index] = item;
        }
      } else {
        quoteItems.push(
          RegistrationsComponent.getNewQuoteItem(id, selectedFlavour)
        );
      }
    }
    quoteItems.sort((a, b) => b.qty_in_ct - a.qty_in_ct);
    this.quotePreviewItems = quoteItems;
    this.showQuotePreview = true;
  }

  redrawCanvas(): void {
    const canvas = document.getElementById('canvas') as HTMLCanvasElement;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(this.image, 0, 0, canvas.width, canvas.height);
  }

  sanitizeUrl(url: string): SafeResourceUrl {
    return this.domSanitizer.bypassSecurityTrustResourceUrl(url);
  }

  saveAddress(): void {
    const address = this.addressForm.value;
    const application = JSON.parse(JSON.stringify(this.selectedApplication));
    const { doorNumber } = application.shippingAddress;
    application.shippingAddress.firstName = address.firstName;
    application.shippingAddress.lastName = address.lastName;
    application.shippingAddress.streetAddress = address.address;
    application.shippingAddress.city = address.city;
    application.shippingAddress.postalCode = address.postalCode;
    application.shippingAddress.province = address.province;
    application.shippingAddress.phoneNumber = address.phoneNumber || '';
    // In IT door number and street address are saved in a single field
    // i.e. streetAddress field contain door number as well.
    // For other countries if doorNumber is present in streetAddress
    // remove it before saving
    if (doorNumber && address.address.indexOf(doorNumber) !== -1) {
      if (this.shippingCountry === 'IT') {
        application.shippingAddress.doorNumber = '';
      } else {
        application.shippingAddress.streetAddress =
          application.shippingAddress.streetAddress
            .replace(doorNumber, '')
            .trim();
      }
    }
    this.editShippingDialog = false;
    if (this.isAdoptMe) {
      this.updateAdoptMeApplication(application.status, application);
    } else {
      this.updateReceipt(application.status, application);
    }
    this.selectedApplication.shippingAddress = JSON.parse(
      JSON.stringify(application.shippingAddress)
    );
  }

  setAddressValidators(): void {
    for (const [field, length] of this.addressFieldValidations) {
      if (this.shippingCountry === 'IT') {
        this.addressForm
          .get(`${field}`)
          .setValidators([
            Validators.required,
            Validators.maxLength(length as number),
          ]);
      } else {
        this.addressForm.get(`${field}`).setValidators([Validators.required]);
      }
    }
    this.addressForm.updateValueAndValidity();
  }

  showDialog(): void {
    this.showShippingPreview = true;
  }

  updateAdoptMeApplication(
    status: string,
    adoptMeApplication: AdoptMeApplication = null
  ): void {
    this.showRejectDialog = false;
    this.pageDim = true;
    let application = adoptMeApplication
      ? { ...adoptMeApplication }
      : ({ ...this.selectedApplication } as AdoptMeApplication);
    application.status = status;
    if (status === 'Rejected') {
      application.rejectReason = this.rejectReason;
      this.rejectReason = null;
    }
    application = this.updateAuditInfo(
      status,
      application
    ) as AdoptMeApplication;
    this.campaignsService
      .manageAdoptionApplication(application)
      .then((result) => {
        if (result.status === 'OK') {
          this.updateApplicationStatus(status, application.id);
        }
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  updateApplications(quote: DTCQuote, batchId: number): void {
    const orders = quote.shipments;
    orders.forEach((order) => {
      const index = this.getApplicationIndex(order.dtc_customer_identifier);
      this.applications[index].batchId = batchId;
      if (this.isAdoptMe) {
        this.updateAdoptMeApplication(
          'Booked',
          this.applications[index] as AdoptMeApplication
        );
      } else {
        this.updateReceipt(
          'Booked',
          this.applications[index] as CampaignApplication
        );
      }
    });
  }

  updateApplicationStatus(status: string, id: string): void {
    const index = this.getApplicationIndex(id);
    if (index !== -1) {
      this.selectedApplication = null;
      this.applications[index].status = status;
      this.applications = (this.applications as CampaignApplication[]).filter(
        (appl) => appl.status === this.filter
      );
    }
  }

  updateAuditInfo(
    status: string,
    application: CampaignApplication | AdoptMeApplication
  ): CampaignApplication | AdoptMeApplication {
    const appl = { ...application };
    if (['Approved', 'Rejected'].includes(status)) {
      appl.approverId = this.userId;
      appl.approverName = this.userName;
    }
    appl.lastUpdatedUserId = this.userId;
    appl.lastUpdatedUserName = this.userName;
    return appl;
  }

  updateReceipt(
    status: string,
    campaignApplication: CampaignApplication = null
  ): void {
    this.showRejectDialog = false;
    this.pageDim = true;
    let application = campaignApplication
      ? { ...campaignApplication }
      : { ...this.selectedApplication };
    application.status = status;
    if (status === 'Rejected') {
      application.rejectReason = this.rejectReason;
      this.rejectReason = null;
    }
    application = this.updateAuditInfo(status, application);
    this.campaignsService
      .manageReceipt(application as CampaignApplication)
      .then((result) => {
        if (result.status === 'OK') {
          this.updateApplicationStatus(status, application.id);
        }
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  updateOCRSelectedProducts(): void {
    if (
      !this.selectedApplication ||
      !(this.selectedApplication as CampaignApplication).ocr
    ) {
      return;
    }
    const { line_items } = (this.selectedApplication as CampaignApplication)
      .ocr;
    const { selectedProducts } = this
      .selectedApplication as CampaignApplication;
    for (let i = 0; i < line_items.length; i++) {
      const itemIndex = selectedProducts.findIndex(
        (product) => product.receiptProduct.id === line_items[i].id
      );
      line_items[i].matchedProduct =
        selectedProducts[itemIndex].campaignProduct.description;
    }
  }

  validateApplication(
    application: CampaignApplication | AdoptMeApplication
  ): void {
    const { shippingAddress } = application;
    if (
      !shippingAddress ||
      !shippingAddress.city ||
      !shippingAddress.country ||
      !shippingAddress.streetAddress ||
      !shippingAddress.postalCode
    ) {
      this.validationErrorMessage = 'Shipping Address';
    }

    if (!shippingAddress.email) {
      this.validationErrorMessage = 'Email Address';
    }

    if (
      this.isAdoptMe &&
      !(application as CampaignApplication).selectedFlavour
    ) {
      this.validationErrorMessage = 'Product';
    }

    if (
      !this.isAdoptMe &&
      !(application as AdoptMeApplication).pets[0].welcomeKit
    ) {
      this.validationErrorMessage = 'Welcome Kit';
    }
  }

  viewAdoptMeRegistration(applicationId: string): void {
    const index = this.getApplicationIndex(applicationId);
    this.selectedApplication = this.applications[index] as AdoptMeApplication;
    const { pets } = this.selectedApplication;
    if (pets) {
      this.adoptMeCertificates = [];
      pets.forEach((pet) => {
        this.adoptMeCertificates = this.adoptMeCertificates.concat(
          pet.adoptionCertificates
        );
      });
      this.selectedApplication.welcomeKit = pets[0].welcomeKit;
    }
  }

  viewRegistration(applicationId: string): void {
    const index = this.getApplicationIndex(applicationId);
    this.showShippingDetails = false;
    this.selectedApplication = this.applications[index] as CampaignApplication;
    this.pageDim = true;
    if (
      !this.selectedApplication.receiptUrl &&
      this.selectedApplication.animalPhoto
    ) {
      this.selectedApplication.receiptUrl =
        this.selectedApplication.animalPhoto.fileUrl;
    }
    if (this.selectedApplication.receiptType !== 'application/pdf') {
      RegistrationsComponent.clearCanvas();
      this.loadImage();
    } else {
      this.loadReceiptOCR();
    }
  }
}
