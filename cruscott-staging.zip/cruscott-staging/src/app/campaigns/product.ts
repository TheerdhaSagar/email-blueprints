export interface Item {
  animal: string;
  bar_code: string;
  card_image_main: string;
  description: string;
  ean_code: string;
  item_code: string;
  no_of_pieces?: string;
  qty: number;
  quantity?: number;
  weight: string;
}

export interface Product {
  items: Item[];
  freeItems?: Item[];
  petAge?: string;
  quantity?: number;
}

export interface ProductMetaData {
  brand_name_new: string;
  package_type: string;
  page_image_main: string;
  pet_type: string;
  recipe: string;
  segment_range_new: string;
  weight: number;
  weight_uom: string;
}

export interface Segment {
  descriptions: string[];
  freeItems?: Item[];
  petAge?: string;
  quantity?: number;
}
