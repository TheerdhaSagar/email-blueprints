import { Component, OnInit, OnDestroy, Injector } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { CampaignsService } from '../campaigns.service';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { EditorSettings } from '../../globals/editor-settings';
import { FormatService } from '../../globals/format.service';
import { AutocompleteComponent } from '../../globals/autocomplete/autocomplete.component';
import { Campaign } from '../campaign';
import { Item, Segment, Product } from '../product';
import { Language, getLocalesForOrg } from '../language';

declare let FooPicker;

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
})
export class SummaryComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _campaignsService: CampaignsService =
    this.injector.get(CampaignsService);
  private _sanitizer: DomSanitizer = this.injector.get(DomSanitizer);
  private _router: Router = this.injector.get(Router);

  animalOldValue: string;
  animalSubscription: Subscription;
  campaigns: Campaign[];
  dateFormat: string;
  editorSettings: EditorSettings;
  flavourSubscription: Subscription;
  flavours: string[];
  pageDim: boolean;
  isAddFreeItem: boolean;
  isAddItem: boolean;
  isAddSegmentItem: boolean;
  isEditing: boolean;
  itemCodeSubscription: Subscription;
  items: Item[];
  languageOldValue: string;
  languageSubscription: Subscription;
  loadFlavoursInProgress: boolean;
  locales: Language[];
  orgId: number;
  selectedProductIndex: number;
  selectedSegmentIndex: number;
  showItemLOV: boolean;
  subOrgChange: Subscription;

  form = this.fb.group({
    id: '',
    campaignType: ['', Validators.required],
    quantity: ['', Validators.required],
    animal: ['', Validators.required],
    animalSize: '',
    country: '',
    language: ['', Validators.required],
    active: 'Y',
    name: ['', Validators.required],
    campaignImageUrl: '',
    campaignUrl: '',
    description: ['', Validators.required],
    startDate: ['', Validators.required],
    endDate: '',
    itemCode: '',
    selectedFlavor: '',
    flavour: this.fb.array([]),
    productConfig: '',
    products: this.fb.array([]),
    segments: this.fb.array([]),
  });

  get campaignImage(): string {
    return this.form.get('campaignImageUrl').value as string;
  }

  constructor(private fb: FormBuilder, private injector: Injector) {}

  ngOnInit(): void {
    this._cacheService.getUser(async (data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.setEditorSettings();
        this.orgId = this._cacheService.getOrgId();
        this.dateFormat = data.date_format || 'dd-MMM-yyyy';
        this.loadCampaigns();
        this.addSubscriptions();
        this.locales = getLocalesForOrg(this.orgId);
      }
    });
  }

  ngOnDestroy(): void {
    if (this.animalSubscription) {
      this.animalSubscription.unsubscribe();
    }
    if (this.itemCodeSubscription) {
      this.itemCodeSubscription.unsubscribe();
    }
    if (this.languageSubscription) {
      this.languageSubscription.unsubscribe();
    }
    if (this.flavourSubscription) {
      this.flavourSubscription.unsubscribe();
    }
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addFlavour(value: string): void {
    const flavours = this.form.get('flavour') as FormArray;
    flavours.push(this.fb.control(value));
    this.form.patchValue({ selectedFlavor: '' });
    this.flavours = this.flavours.filter((flavour) => flavour !== value);
  }

  async addFreeItem(product: Item): Promise<void> {
    if (this.selectedProductIndex === -1) {
      return;
    }
    const freeItem = this.getProductFormGroup(product);
    const products = this.form.get('products') as FormArray;
    const freeItems = products.controls[this.selectedProductIndex].get(
      'freeItems'
    ) as FormArray;
    freeItems.push(freeItem);
    this.isAddFreeItem = false;
    this.showItemLOV = false;
    if (!this.isEditing) {
      this.selectedProductIndex = -1;
    }
  }

  addProduct(product: Item): void {
    if (this.selectedProductIndex === -1) {
      return;
    }
    const newProduct = this.getProductFormGroup(product);
    const products = this.form.get('products') as FormArray;
    const items = products.controls[this.selectedProductIndex].get(
      'items'
    ) as FormArray;
    items.push(newProduct);
    this.isAddItem = false;
    this.showItemLOV = false;
    if (!this.isEditing) {
      this.selectedProductIndex = -1;
    }
  }

  addProductGroup(product: Product): void {
    const products = this.form.get('products') as FormArray;
    const productGroup = this.fb.group({
      items: this.fb.array([]),
      freeItems: this.fb.array([]),
      quantity: (product && product.quantity) || '',
      petAge: (product && product.petAge) || '',
    });
    products.push(productGroup);
  }

  addSegment(segment: Segment): void {
    const newSegment = this.fb.group({});
    newSegment.addControl('descriptions', this.getSegmentFormArray(segment));
    newSegment.addControl(
      'quantity',
      this.fb.control(segment ? segment.quantity : '')
    );
    newSegment.addControl(
      'petAge',
      this.fb.control(segment ? segment.petAge : '')
    );
    if (segment) {
      newSegment.addControl(
        'freeItems',
        this.getFreeItemsFormArray(segment.freeItems)
      );
    } else {
      newSegment.addControl('freeItems', this.getFreeItemsFormArray(null));
    }
    const control = this.form.get('segments') as FormArray;
    control.push(newSegment);
  }

  addSegmentDescription(index: number): void {
    const segments = this.form.get('segments') as FormArray;
    const descriptions = segments.controls[index].get(
      'descriptions'
    ) as FormArray;
    descriptions.push(this.fb.control(''));
  }

  addSegmentFreeItem(product: Item): void {
    if (this.selectedSegmentIndex === -1) {
      return;
    }
    const freeItem = this.getProductFormGroup(product);
    const segments = this.form.get('segments') as FormArray;
    const freeItems = segments.controls[this.selectedSegmentIndex].get(
      'freeItems'
    ) as FormArray;
    freeItems.push(freeItem);
    this.isAddSegmentItem = false;
    this.showItemLOV = false;
    this.selectedSegmentIndex = -1;
  }

  addSubscriptions(): void {
    this.subscribeAnimalChange();
    this.subscribeItemCodeChange();
    this.subscribeLanguageChange();
    this.subscribeFlavourChange();
    this.subscribeOrgChange();
  }

  deleteFreeItem(productIndex: number, itemIndex: number): void {
    const products = this.form.get('products') as FormArray;
    (products.controls[productIndex].get('freeItems') as FormArray).removeAt(
      itemIndex
    );
  }

  deleteItem(productIndex: number, itemIndex: number): void {
    const products = this.form.get('products') as FormArray;
    (products.controls[productIndex].get('items') as FormArray).removeAt(
      itemIndex
    );
  }

  deleteProduct(productIndex: number): void {
    (this.form.get('products') as FormArray).removeAt(productIndex);
  }

  deleteSegment(segmentIndex: number): void {
    (this.form.get('segments') as FormArray).removeAt(segmentIndex);
  }

  deleteSegmentDescription(
    segmentIndex: number,
    descriptionIndex: number
  ): void {
    const segments = this.form.get('segments') as FormArray;
    (segments.controls[segmentIndex].get('descriptions') as FormArray).removeAt(
      descriptionIndex
    );
  }

  deleteSegmentFreeItem(segmentIndex: number, itemIndex: number): void {
    const segments = this.form.get('segments') as FormArray;
    (segments.controls[segmentIndex].get('freeItems') as FormArray).removeAt(
      itemIndex
    );
  }

  editCampaign(index: number): void {
    this.loadFlavoursInProgress = true;
    this.resetForm();
    this.form.patchValue(this.campaigns[index]);
    this.isEditing = true;
    if (this.campaigns[index].productConfig === 'SEGMENT') {
      this.editCampaignSegments(index);
    } else {
      this.editCampaignProducts(index);
    }
  }

  editCampaignProducts(index: number): void {
    const { products } = this.campaigns[index];
    products.forEach((product, productIndex) => {
      this.addProductGroup(product);
      this.selectedProductIndex = productIndex;
      product.items.forEach((item) => this.addProduct(item));
      product.freeItems.forEach((item) => this.addFreeItem(item));
    });
    this.selectedProductIndex = -1;
  }

  editCampaignSegments(index: number): void {
    const { segments } = this.campaigns[index];
    segments.forEach((segment) => this.addSegment(segment));
  }

  getEditorSettings(): EditorSettings {
    return { ...this.editorSettings };
  }

  getFlavour(product: string): string {
    if (!this.flavours) {
      return '';
    }
    for (let i = 0; i < this.flavours.length; i++) {
      if (product.indexOf(this.flavours[i]) !== -1) {
        return this.flavours[i];
      }
    }
    return '';
  }

  getFreeItemsFormArray(products: Item[]): FormArray {
    const freeItems = this.fb.array([]);
    if (products) {
      products.forEach((product) => {
        freeItems.push(this.getProductFormGroup(product));
      });
    }
    return freeItems;
  }

  getProductFormGroup(product: Item): FormGroup {
    return this.fb.group({
      animal: product.animal || '',
      bar_code: product.bar_code || '',
      description: product.description || '',
      ean_code: product.ean_code || '',
      item_code: product.item_code || '',
      card_image_main: product.card_image_main || '',
      weight: product.weight || '',
      no_of_pieces: product.no_of_pieces || '',
    });
  }

  getSegmentFormArray(segment: Segment): FormArray {
    const descriptions = this.fb.array([]);
    if (segment && segment.descriptions) {
      segment.descriptions.forEach((description) =>
        descriptions.push(this.fb.control(description))
      );
    } else {
      descriptions.push(this.fb.control(''));
    }
    return descriptions;
  }

  loadCampaigns(): void {
    this.pageDim = true;
    let country = CampaignsService.getCountryCodeForOrg(this.orgId);
    country += country === 'NL' ? ',BE' : '';
    this._campaignsService
      .getCampaigns(country)
      .then((data) => {
        this.campaigns = data;
        this.campaigns.forEach((campaign, index) => {
          if (campaign.startDate) {
            this.campaigns[index].startDate = this._formatService.formatDate(
              campaign.startDate
            );
          }
          if (campaign.endDate) {
            this.campaigns[index].endDate = this._formatService.formatDate(
              campaign.endDate
            );
          }
        });
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  async loadFlavours(): Promise<void> {
    const campaign = this.form.value as Campaign;
    if (!(campaign.language && campaign.animal)) {
      return;
    }
    this.loadFlavoursInProgress = true;
    this.flavours = null;
    const [language, country] = campaign.language.toUpperCase().split('-');
    this.flavours = await this._campaignsService.getProductFlavours(
      country,
      language,
      campaign.animal
    );
    this.loadFlavoursInProgress = false;
  }

  loadProducts(): void {
    const locale = this.form.get('language').value;
    const animal = this.form.get('animal').value;
    if (!(locale && animal)) {
      return;
    }
    const [language, country] = locale.toUpperCase().split('-');
    this._campaignsService
      .getProducts(animal, country, language)
      .then((data) => {
        this.items = data;
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  onItemSelect(itemCode: string): void {
    if (!itemCode) {
      return;
    }
    const index = this.items.findIndex((item) => item.item_code === itemCode);
    if (index === -1) {
      return;
    }
    if (this.isAddItem) {
      this.addProduct(this.items[index]);
    }
    if (this.isAddFreeItem) {
      this.addFreeItem(this.items[index]);
    }
    if (this.isAddSegmentItem) {
      this.addSegmentFreeItem(this.items[index]);
    }
    this.form.patchValue({ itemCode: '' });
  }

  onSelect(): void {
    try {
      if (this instanceof AutocompleteComponent) {
        const nodes = this.element.childNodes;
        const inputElement = nodes[0].childNodes[0];
        inputElement.value = null;
      }
    } catch (e) {
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: `<pre>${e.stack}</pre>`,
      });
    }
  }

  removeFlavour(index): void {
    const controls = this.form.get('flavour') as FormArray;
    this.flavours.push(controls.at(index).value);
    controls.removeAt(index);
  }

  removeProduct(index): void {
    const controls = this.form.get('products') as FormArray;
    controls.removeAt(index);
  }

  resetForm(): void {
    (this.form.get('products') as FormArray).controls = [];
    (this.form.get('segments') as FormArray).controls = [];
    (this.form.get('flavour') as FormArray).controls = [];
    this.form.reset();
    this.form.patchValue({
      active: 'Y',
      country: CampaignsService.getCountryCodeForOrg(this.orgId),
      animal: 'CAT',
      productConfig: 'ITEM',
    });
  }

  sanitizeStyle(style): SafeStyle {
    return this._sanitizer.bypassSecurityTrustStyle(`url(${style})`);
  }

  saveCampaign(): void {
    const campaign = { ...this.form.value } as Campaign;
    if (!campaign.id) {
      delete campaign.id;
    }
    this.pageDim = true;
    this._campaignsService
      .manageCampaign(campaign)
      .then(() => {
        this.isEditing = false;
        this.loadCampaigns();
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  setEditorSettings(): void {
    this.editorSettings = {
      menubar: false,
      branding: false,
      statusbar: false,
      placeholder: '',
      forced_root_block: 'div',
      force_br_newlines: true,
      force_p_newlines: false,
      plugins: 'link autoresize lists',
      block_formats:
        'Paragraph=p;Header 1=h1;Header 2=h2;Header 3=h3;Header 4=h4;',
      content_style: `@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600,700');
            body { font-family: "Source Sans Pro", sans-serif; font-size: 10pt; }`,
      toolbar:
        'fontsizeselect | bold italic underline strikethrough forecolor | blockquote bullist numlist | ' +
        'alignleft aligncenter alignright alignjustify | removeformat',
    };
  }

  subscribeAnimalChange(): void {
    this.animalSubscription = this.form
      .get('animal')
      .valueChanges.subscribe((value) => {
        if (value && value !== this.animalOldValue) {
          this.animalOldValue = value;
          this.loadFlavours();
          this.loadProducts();
        }
      });
  }

  subscribeFlavourChange(): void {
    this.itemCodeSubscription = this.form
      .get('selectedFlavor')
      .valueChanges.subscribe((value) => {
        if (value) {
          this.addFlavour(value);
        }
      });
  }

  subscribeItemCodeChange(): void {
    this.itemCodeSubscription = this.form
      .get('itemCode')
      .valueChanges.subscribe((value) => {
        this.onItemSelect(value);
      });
  }

  subscribeLanguageChange(): void {
    this.languageSubscription = this.form
      .get('language')
      .valueChanges.subscribe((value) => {
        setTimeout(() => {
          if (
            value &&
            !this.loadFlavoursInProgress &&
            value !== this.languageOldValue
          ) {
            this.loadFlavours();
          }
          if (value !== this.languageOldValue) {
            this.languageOldValue = value;
            this.loadProducts();
          }
          if (['nl-BE', 'fr-BE'].includes(value)) {
            this.form.patchValue({ country: 'BE' });
          } else if (value === 'nl-NL') {
            this.form.patchValue({ country: 'NL' });
          }
        }, 250);
      });
  }

  subscribeOrgChange(): void {
    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this.orgId = this._cacheService.getOrgId();
      this.campaigns = [];
      this.locales = getLocalesForOrg(this.orgId);
      this.loadCampaigns();
    });
  }

  uploadCampaignImage(event): void {
    const file = event.target.files[0];
    this._campaignsService
      .uploadAttachment(`campaigns/${file.name}`, file)
      .then((fileUrl) => {
        if (fileUrl) {
          this.form.patchValue({ campaignImageUrl: fileUrl });
        }
      });
  }
}
