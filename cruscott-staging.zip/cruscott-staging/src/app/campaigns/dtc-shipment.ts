export interface DTCShipment {
  business_name: string;
  campaign_identifier: string;
  city: string;
  country: string;
  delivery_instructions: string;
  door_number: string;
  dtc_customer_identifier: string;
  dtc_order_number: string;
  line_num?: number;
  lines?: DTCShipmentLine[];
  product_code?: string;
  province: string;
  quantity?: number;
  receiver_email_address: string;
  receiver_first_name: string;
  receiver_last_name: string;
  receiver_phone_no: string;
  state: string;
  street_name: string;
  user_id: number;
  zip_code: string;
}

export interface DTCShipmentLine {
  product_code: string;
  quantity: number;
  line_num: number;
}
