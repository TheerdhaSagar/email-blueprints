interface BasePrediction {
  label: string;
  ocr_text: string;
  score: number;
  xmax: number;
  xmin: number;
  ymax: number;
  ymin: number;
  type?: string;
}

interface PredictionCell extends BasePrediction {
  col: number;
  col_span: number;
  row: number;
  row_label: string;
  row_span: number;
  status: string;
  text: string;
}

export interface Prediction extends PredictionCell {
  cells: PredictionCell[];
}
