export interface Language {
  country: string;
  countryCode: string;
  langCode: string;
  language: string;
  locale: string;
  orgId: number;
}

export const availableLanguages: Language[] = [
  {
    language: 'Italian',
    country: 'Italy',
    langCode: 'it',
    countryCode: 'IT',
    locale: 'it-IT',
    orgId: 82
  },
  {
    language: 'German',
    country: 'Germany',
    langCode: 'de',
    countryCode: 'DE',
    locale: 'de-DE',
    orgId: 83
  },
  {
    language: 'French',
    country: 'Switzerland',
    langCode: 'fr',
    countryCode: 'CH',
    locale: 'fr-CH',
    orgId: 84
  },
  {
    language: 'German',
    country: 'Switzerland',
    langCode: 'de',
    countryCode: 'CH',
    locale: 'de-CH',
    orgId: 84
  },
  {
    language: 'Italian',
    country: 'Switzerland',
    langCode: 'it',
    countryCode: 'CH',
    locale: 'it-CH',
    orgId: 84
  },
  {
    language: 'French',
    country: 'France',
    langCode: 'fr',
    countryCode: 'FR',
    locale: 'fr-FR',
    orgId: 101
  },
  {
    language: 'English',
    country: 'United Kingdom',
    langCode: 'en',
    countryCode: 'GB',
    locale: 'en-GB',
    orgId: 121
  },
  {
    language: 'English',
    country: 'Canada',
    langCode: 'en',
    countryCode: 'CA',
    locale: 'en-CA',
    orgId: 141
  },
  {
    language: 'Dutch',
    country: 'Netherlands',
    langCode: 'nl',
    countryCode: 'NL',
    locale: 'nl-NL',
    orgId: 181
  },
  {
    language: 'Dutch',
    country: 'Belgium',
    langCode: 'nl',
    countryCode: 'BE',
    locale: 'nl-BE',
    orgId: 181
  },
  {
    language: 'French',
    country: 'Belgium',
    langCode: 'fr',
    countryCode: 'BE',
    locale: 'fr-BE',
    orgId: 181
  },
  {
    language: 'English',
    country: 'United States',
    langCode: 'en',
    countryCode: 'US',
    locale: 'en-US',
    orgId: 202
  }
];

export function getLocalesForOrg(orgId: number): Language[] {
  return availableLanguages.filter((language) => language.orgId === orgId);
}
