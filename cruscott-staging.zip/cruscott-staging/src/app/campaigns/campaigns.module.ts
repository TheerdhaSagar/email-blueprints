import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ShareModule } from '../share/share.module';
import { CampaignsRoutingModule } from './campaigns-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SummaryComponent } from './summary/summary.component';
import { RegistrationsComponent } from './registrations/registrations.component';
import { ProductsReportComponent } from './reports/products-report/products-report.component';
import { QuotePreviewComponent } from './quote-preview/quote-preview.component';

@NgModule({
  declarations: [
    DashboardComponent,
    SummaryComponent,
    RegistrationsComponent,
    ProductsReportComponent,
    QuotePreviewComponent,
  ],
  imports: [ReactiveFormsModule, ShareModule, CampaignsRoutingModule],
  providers: [],
})
export class CampaignsModule {}
