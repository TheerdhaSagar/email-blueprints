export interface ContactReason {
  lastUpdatedBy?: number;
  locale: string[];
  order: number;
  reason: string;
  reasonId: string;
  subReasons: {
    subReason: string;
    locale: {
      add?: boolean;
      confirm?: boolean;
      country?: string;
      edit?: boolean;
      language?: string;
      locale: string;
      mailToCC: '';
      order: number;
      ownerId: number;
      supportEmail: string;
      translation: string;
    }[];
  }[];
  translations: { [key: string]: string };
  translationsArr: Array<{
    add: boolean;
    country: string;
    edit: boolean;
    language: string;
    value: string;
  }>;
}
