import { Component, Injector, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { DataService } from '../globals/data.service';
import { User } from '../globals/user';
import { ContactReason } from './models/contact-reason';
import { ContactReasonsService } from './services/contact-reasons.service';
import * as _lodash from 'lodash';

@Component({
  selector: 'app-contact-reasons',
  templateUrl: './contact-reasons.component.html',
  styleUrls: ['./contact-reasons.component.scss'],
})
export class ContactReasonsComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _reasonService: ContactReasonsService = this.injector.get(
    ContactReasonsService
  );
  private _router: Router = this.injector.get(Router);

  countries: {
    key: string;
    value: string;
  }[] = [
    { key: 'DE', value: 'German' },
    { key: 'FR', value: 'France' },
    { key: 'IT', value: 'Italy' },
    { key: 'NL', value: 'Netherland' },
    { key: 'SV', value: 'El Salvador' },
    { key: 'FI', value: 'Finland' },
    { key: 'UK', value: 'United Kingdom' },
    { key: 'US', value: 'United States' },
    { key: 'CA', value: 'Canada' },
    { key: 'CH', value: 'Switzerland' },
    { key: 'BE', value: 'Belgium' },
    { key: 'ES', value: 'Spain' },
  ];
  languages: string[] = [
    'de',
    'fr',
    'it',
    'nl',
    'en',
    'fi',
    'sv',
    'es',
    'ca',
    'gb',
  ];
  pageDim = false;
  reasonSummary: ContactReason[];
  searchQuery: string;
  showDeleteReason = null;
  showDeleteTranslation = null;
  showDetailsPage = false;
  showSubReason = false;
  subReasonIndex: number;
  user: User;
  windowWidth: number;

  reasonForm = this.fb.group({
    reasonId: '',
    order: ['', Validators.required],
    reason: ['', Validators.required],
    translations: {},
    translationsArr: this.fb.array([]),
    subReasons: [],
    locale: [],
  });

  subReasonForm = this.fb.group({
    subReason: ['', Validators.required],
    locale: this.fb.array([]),
  });

  constructor(private fb: FormBuilder, private injector: Injector) {
    this.windowWidth = this._dataService.windowWidth;
  }

  get reasonFormDetails(): ContactReason {
    return (this.reasonForm as FormGroup).value;
  }

  get subReason() {
    return (this.subReasonForm as FormGroup).value;
  }

  get subReasonLocale() {
    return this.subReasonForm.get('locale') as FormArray;
  }

  ngOnInit() {
    this._appService.scrollTop();
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.pageDim = true;
        this.loadContactReasons();
      }
    });
  }

  createReason(value): void {
    this.reasonForm.patchValue({
      locale: value.locale || [],
      reasonId: value.reasonId || '',
      reason: value.reason || '',
      order: value.order || '',
      translations: value.translations || {},
      subReasons: value.subReasons || [],
    });
    if (value.translationsArr) {
      value.translationsArr.forEach((transArr) =>
        (this.reasonForm.get('translationsArr') as FormArray).push(
          this.getTranslation(transArr)
        )
      );
    }
  }

  createSubReason(): void {
    this.showSubReason = true;
    this.subReasonIndex = null;
    this.subReasonLocale.controls = [];
    this.subReasonForm.reset();
    this.subReasonForm.patchValue({
      subReason: '',
    });
  }

  createSubReasonTranslation(value): void {
    (this.subReasonForm.get('locale') as FormArray).push(
      this.subReasonTranslation(value || {})
    );
  }

  createTranslation(): void {
    (this.reasonForm.get('translationsArr') as FormArray).push(
      this.getTranslation({})
    );
  }

  deleteReason(): void {
    const reasonId = this.showDeleteReason;
    this.pageDim = true;
    this._reasonService
      .deleteContactReasons(reasonId)
      .then((data) => {
        this._appService.notify(data);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.pageDim = false;
        this.reasonSummary = this.reasonSummary.filter(
          (reason) => reason.reasonId !== reasonId
        );
        this.showDeleteReason = false;
        this.showDetailsPage = false;
        this.loadContactReasons();
      });
  }

  deleteSubReasons(index): void {
    this.reasonFormDetails.subReasons.splice(index, 1);
  }

  deleteTranslation(): void {
    const line = (this.showDeleteTranslation as FormGroup).value;
    const locale = line.language + '-' + line.country;
    const newSubReasons = this.reasonFormDetails.subReasons.map(
      (contactsub) => {
        contactsub.locale = contactsub.locale.filter(
          (localeline) => localeline.locale !== locale
        );
        return contactsub;
      }
    );
    this.reasonForm.get('subReasons').patchValue(newSubReasons);
    this.reasonFormDetails.locale = this.reasonFormDetails.locale.filter(
      (val) => val !== locale
    );
    (this.reasonForm.get('translationsArr') as FormArray).removeAt(
      this.subReasonIndex
    );
    this.subReasonIndex = null;
    this.showDeleteTranslation = null;
  }

  emailAddressExists(
    control: AbstractControl
  ): Promise<ValidationErrors | null> {
    const emailAddress = control.value;
    return new Promise((resolve) => {
      if (!this._appService.validateEmail(emailAddress)) {
        resolve({ emailInvalid: true });
      }
    });
  }

  emailAddressValidation(productIndex): boolean {
    const cardId = (this.subReasonLocale.controls[
      `${productIndex}`
    ] as FormGroup).get('supportEmail');
    return (
      cardId.dirty &&
      cardId.hasError('emailInvalid') &&
      !this.requiredSubReasonLocaleField(productIndex, 'supportEmail')
    );
  }

  getSubReason(reason) {
    const subreason = this.fb.group({
      subReason: reason.subReason || '',
      locale: this.fb.array([]),
    });
    reason.locale.forEach((translate) =>
      (subreason.get('locale') as FormArray).push(
        this.subReasonTranslation(translate)
      )
    );
    return subreason;
  }

  getTranslation(translation) {
    return this.fb.group({
      country: [translation.country || '', Validators.required],
      countryFullName: translation.countryFullName || '',
      language: [translation.language || '', Validators.required],
      value: [translation.value || '', Validators.required],
      edit: false,
      add: !(translation && translation.country),
    });
  }

  getRequiredContactFields() {
    const req = _lodash.cloneDeep(this.reasonFormDetails);
    req.lastUpdatedBy = this.user.user_id;
    req.locale = [];
    req.translations = {};
    req.translationsArr.forEach((line) => {
      const key = `${line.language}-${line.country}`;
      req.translations[key] = line.value;
      req.locale.push(key);
    });
    delete req.translationsArr;
    req.subReasons = req.subReasons.map((subreason) => {
      return {
        subReason: subreason.subReason,
        locale: subreason.locale.map((localeline) => {
          return {
            mailToCC: localeline.mailToCC,
            supportEmail: localeline.supportEmail,
            supportLink: localeline.supportLink,
            locale:
              localeline.locale ||
              `${localeline.language}-${localeline.country}`,
            translation: localeline.translation,
            translationSupport: localeline.translationSupport,
            ownerId: localeline.ownerId,
            order: localeline.order,
          };
        }),
      };
    });
    return req;
  }

  getValidity(): boolean {
    for (let i = 0; i < this.subReasonLocale.value.length; i++) {
      const formGroup = this.subReasonLocale.controls[i].value;
      if (
        !formGroup.language ||
        !formGroup.country ||
        !formGroup.translation ||
        !formGroup.order ||
        !formGroup.translationSupport ||
        (formGroup.translationSupport === 'email' && !formGroup.supportEmail) ||
        (formGroup.translationSupport === 'link' && !formGroup.supportLink)
      ) {
        return true;
      }
    }
    return this.subReasonForm.invalid;
  }

  goToCreateScreen() {
    this._appService.scrollTop();
    this.showDetailsPage = true;
    (this.reasonForm.get('translationsArr') as FormArray).controls = [];
    this.reasonForm.reset();
    this.createReason({});
  }

  loadContactReasons(): void {
    this._reasonService
      .loadContactReasons()
      .then((data) => {
        this.reasonSummary = data;
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  requiredReasonField(formKey): boolean {
    const formField = (this.reasonForm as FormGroup).get(`${formKey}`);
    return formField.hasError('required') && formField.touched;
  }

  requiredSubReasonField(formKey): boolean {
    const formField = (this.subReasonForm as FormGroup).get(`${formKey}`);
    return formField.hasError('required') && formField.touched;
  }

  requiredSubReasonLocaleField(productIndex, formKey): boolean {
    const formField = (this.subReasonLocale.controls[
      `${productIndex}`
    ] as FormGroup).get(`${formKey}`);
    return formField.hasError('required') && formField.invalid;
  }

  removeSubReasonTranslation(product, index) {
    this.subReasonLocale.removeAt(index);
  }

  saveContactReason(): void {
    const req = this.getRequiredContactFields();
    if (Object.keys(req.translations).length === 0) {
      this._appService.notify({
        status: 1,
        msg: 'No Translations found for the reason',
      });
      return;
    }
    this.pageDim = true;
    this._reasonService
      .manageContactReasons(req)
      .then((data) => {
        if (this.reasonFormDetails.reasonId) {
          this._appService.notify({
            status: 0,
            msg: 'Contact Reason Updated Successfully',
          });
        } else {
          this._appService.notify({
            status: 0,
            msg: 'Contact Reason Added Successfully',
          });
        }
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.pageDim = false;
        (this.reasonForm.get('translationsArr') as FormArray).controls = [];
        this.reasonForm.reset();
        this.showDetailsPage = false;
        this.loadContactReasons();
      });
  }

  saveSubReason() {
    const subReasonForm = (this.subReasonForm as FormGroup).value;
    subReasonForm.locale.forEach((subReason) => {
      subReason.locale = `${subReason.language}-${subReason.country}`;
    });
    if (this.subReasonIndex !== null && this.subReasonIndex !== undefined) {
      this.reasonFormDetails.subReasons[this.subReasonIndex] = subReasonForm;
    } else {
      this.reasonFormDetails.subReasons.push(subReasonForm);
    }
    this.showSubReason = false;
  }

  subReasonTranslation(value) {
    return this.fb.group({
      mailToCC: value.mailToCC || '',
      order: [value.order || '', Validators.required],
      ownerId: value.ownerId || '',
      translationSupport: [value.translationSupport || '', Validators.required],
      supportEmail: [value.supportEmail || ''],
      supportLink: [value.supportLink || ''],
      translation: [value.translation || '', Validators.required],
      locale: value.locale || '',
      edit: false,
      country: [value.country || '', Validators.required],
      countryFullName: value.countryFullName || '',
      language: [value.language || '', Validators.required],
      add: typeof value.add === 'boolean' ? value.add : true,
      confirm: false,
    });
  }

  translationSupportChangeEvent(event, index): void {
    const supportEmail = this.subReasonLocale.controls[index].get(
      'supportEmail'
    );
    const supportLink = this.subReasonLocale.controls[index].get('supportLink');
    if (
      (event.target && event.target.value === 'email') ||
      event.translationSupport === 'email'
    ) {
      supportEmail.setValidators(Validators.required);
      supportEmail.setAsyncValidators(this.emailAddressExists.bind(this));
      supportLink.clearValidators();
      supportEmail.updateValueAndValidity();
      supportLink.updateValueAndValidity();
    } else if (
      (event.target && event.target.value === 'link') ||
      event.translationSupport === 'link'
    ) {
      supportLink.setValidators(Validators.required);
      supportEmail.clearValidators();
      supportEmail.updateValueAndValidity();
      supportLink.updateValueAndValidity();
    } else {
      supportLink.clearValidators();
      supportEmail.clearValidators();
      supportEmail.updateValueAndValidity();
      supportLink.updateValueAndValidity();
    }
  }

  viewDetails(contactReason): void {
    (this.reasonForm.get('translationsArr') as FormArray).controls = [];
    this.reasonForm.reset();
    contactReason.translationsArr = [];
    Object.keys(contactReason.translations).forEach((key) => {
      const countryLang = key.split('-');
      contactReason.translationsArr.push({
        country: countryLang[1],
        countryFullName: this.countries.find(
          (val) => val.key === countryLang[1]
        ).value,
        language: countryLang[0],
        value: contactReason.translations[key],
        edit: false,
        add: false,
      });
    });
    this.createReason(_lodash.cloneDeep(contactReason));
    this.showDetailsPage = true;
  }

  viewSubReasons(subreason, index): void {
    this.subReasonLocale.controls = [];
    this.subReasonForm.reset();
    this.subReasonForm.patchValue({
      subReason: subreason.subReason,
    });
    subreason.locale.forEach((val) => {
      val.country = val.country || val.locale.split('-')[1];
      val.countryFullName = this.countries.find(
        (country) => val.country === country.key
      ).value;
      val.language = val.language || val.locale.split('-')[0];
      val.translationSupport = val.supportEmail ? 'email' : 'link';
      val.supportLink = val.supportLink || '';
      val.edit = false;
      val.confirm = false;
      val.add = val.add || false;
      this.createSubReasonTranslation(val);
    });

    setTimeout(() => {
      for (let i = 0; i < this.subReasonLocale.value.length; i++) {
        this.translationSupportChangeEvent(
          this.subReasonLocale.controls[i].value,
          i
        );
      }
    }, 250);

    this.subReasonIndex = index;
    this.showSubReason = true;
  }
}
