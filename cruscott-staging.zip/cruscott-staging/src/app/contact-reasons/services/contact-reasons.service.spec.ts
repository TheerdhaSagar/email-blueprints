import { TestBed } from '@angular/core/testing';

import { ContactReasonsService } from './contact-reasons.service';

describe('ContactReasonsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContactReasonsService = TestBed.get(ContactReasonsService);
    expect(service).toBeTruthy();
  });
});
