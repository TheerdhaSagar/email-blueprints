import { Injectable, Injector } from '@angular/core';
import { AngularFireFunctions } from '@angular/fire/functions';
import { ContactReason } from '../models/contact-reason';

@Injectable({
  providedIn: 'root',
})
export class ContactReasonsService {
  private _fns: AngularFireFunctions = this.injector.get(AngularFireFunctions);

  constructor(private injector: Injector) {}

  loadContactReasons(): Promise<ContactReason[]> {
    return this._fns
      .httpsCallable('cruscott-readAllContactReasons')(null)
      .toPromise();
  }

  manageContactReasons(reqObj: ContactReason): Promise<ContactReason[]> {
    return this._fns
      .httpsCallable('cruscott-manageContactReasons')(reqObj)
      .toPromise();
  }

  deleteContactReasons(reasonId): Promise<Response> {
    return this._fns
      .httpsCallable('cruscott-deleteContactReason')({ reasonId })
      .toPromise();
  }
}
