import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactReasonsComponent } from './contact-reasons.component';

describe('ContactReasonsComponent', () => {
  let component: ContactReasonsComponent;
  let fixture: ComponentFixture<ContactReasonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactReasonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactReasonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
