import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactReasonsComponent } from './contact-reasons.component';

const routes: Routes = [
  {
    path: '',
    component: ContactReasonsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ContactReasonsRoutingModule {}
