import { NgModule } from '@angular/core';

import { ContactReasonsRoutingModule } from './contact-reasons-routing.module';
import { ContactReasonsComponent } from './contact-reasons.component';
import { ShareModule } from '../share/share.module';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [ContactReasonsComponent],
  imports: [ShareModule, ContactReasonsRoutingModule, ReactiveFormsModule],
})
export class ContactReasonsModule {}
