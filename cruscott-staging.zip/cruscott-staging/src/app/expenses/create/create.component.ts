import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { ExpenseService } from '../../globals/expense.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';
import { OrderByPipe } from '../../globals/order-by.pipe';
import jQuery from 'jquery';
import { APIError } from '../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-expenses-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss'],
  providers: [OrderByPipe],
})
export class ExpenseCreateComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _expenseService: ExpenseService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _orderBy: OrderByPipe;
  private _router: Router;
  private _window: any;

  amount: any;
  amount_msg: any;
  attaches: any[];
  attachmentDialog: boolean;
  attachments: any[];
  cardNumber: any;
  codeCombinationId: any;
  columnname: any;
  copyExpense: any;
  creditCardFlag: string;
  creditLimit: any;
  currencies: any;
  currency_code: any;
  date: any;
  dateChanged: boolean;
  dateFormat: any;
  dateFormatExample: any;
  dateFormats: any;
  date_msg: any;
  defaultCurrency: any;
  deletedAttachments: any[];
  deletedLines: any[];
  desc: any;
  editExpense: any;
  editExpenseData: any;
  employee: any;
  employeeName: any;
  exchange_msg: any;
  exchange_rate: any;
  exchangerate: any;
  expense: any;
  expenseAttachment: any[];
  expenseAttachments: any;
  expenseLine: any[];
  expenseLines: any[];
  expense_report_id: any;
  f_amount: any;
  f_exchange_rate: any;
  focusAmount: any;
  focusCurrency: any;
  focusDate: any;
  focusEmployee: boolean;
  focusExchange: any;
  focusJustification: any;
  focusPrompt: any;
  focusPurpose: any;
  format: any;
  fromNotifications: boolean;
  fromState: boolean;
  history: any[];
  index: any;
  invoiceAmount: any;
  invoiceAmountError: boolean;
  invoiceFlag: string;
  invoiceNumber: any;
  invoiceNumberError: boolean;
  isViewMode: boolean;
  justification: any;
  limitMsg: any;
  lineAttachments: any;
  lines: any[];
  missingreceipt: string;
  msg: any;
  new_exp_msg: any;
  notificationDetails: any;
  number_format: any;
  org: any;
  permissions: any;
  personId: any;
  persons: any;
  predicate: any;
  projectId: number;
  prompt: any;
  prompts: any[];
  promptName: any;
  varPromptName: any;
  purpose: any;
  reportHeaderId: any;
  selectedCurrency: any;
  selectedLine: any;
  showCurrency: boolean;
  showDetails: boolean;
  showDialog: boolean;
  showSpinner: boolean;
  statementData: any;
  statementData1: any;
  statements: any[];
  status: any;
  submit: boolean;
  submitDialog: boolean;
  supplierError: boolean;
  supplierId: any;
  supplier: any;
  suppliers: any;
  subOrgChange: Subscription;
  taskDetails: any;
  template: any;
  tmp_attachments: any;
  total: any;
  user: any;
  viewExpense: boolean;

  constructor(
    appService: AppService,
    cacheService: CacheService,
    dataService: DataService,
    expenseService: ExpenseService,
    formatService: FormatService,
    httpService: HttpService,
    location: Location,
    orderBy: OrderByPipe,
    router: Router
  ) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._expenseService = expenseService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._orderBy = orderBy;
    this._router = router;
    this._window = window;

    this.amount = null;
    this.amount_msg = '';
    this.attaches = [];
    this.attachmentDialog = false;
    this.attachments = [];
    this.cardNumber = null;
    this.codeCombinationId = null;
    this.columnname = null;
    this.copyExpense = this._appService.copyExpense;
    this.creditCardFlag = 'N';
    this.creditLimit = null;
    this.currencies = null;
    this.currency_code = null;
    this.date = null;
    this.dateChanged = false;
    this.dateFormat = null;
    this.dateFormatExample = null;
    this.dateFormats = null;
    this.date_msg = '';
    this.defaultCurrency = null;
    this.deletedAttachments = [];
    this.deletedLines = [];
    this.desc = null;
    this.editExpense = this._appService.editExpense;
    this.editExpenseData = null;
    this.employee = '';
    this.employeeName = null;
    this.exchange_msg = '';
    this.exchange_rate = null;
    this.exchangerate = null;
    this.expense = null;
    this.expenseAttachment = [];
    this.expenseAttachments = [];
    this.expenseLine = [];
    this.expenseLines = [];
    this.expense_report_id = null;
    this.f_amount = '';
    this.f_exchange_rate = '';
    this.focusAmount = null;
    this.focusCurrency = null;
    this.focusDate = null;
    this.focusExchange = null;
    this.focusJustification = null;
    this.focusPrompt = null;
    this.focusPurpose = null;
    this.format = null;
    this.fromNotifications = false;
    this.fromState = false;
    this.history = [];
    this.index = null;
    this.invoiceAmount = null;
    this.invoiceAmountError = false;
    this.invoiceFlag = 'N';
    this.invoiceNumber = null;
    this.invoiceNumberError = false;
    this.isViewMode = false;
    this.justification = null;
    this.limitMsg = '';
    this.lineAttachments = null;
    this.lines = [];
    this.missingreceipt = 'N';
    this.msg = '';
    this.new_exp_msg = '';
    this.notificationDetails = null;
    this.number_format = null;
    this.org = null;
    this.permissions = null;
    this.personId = null;
    this.persons = null;
    this.predicate = null;
    this.projectId = null;
    this.prompt = null;
    this.promptName = '';
    this.varPromptName = '';
    this.purpose = '';
    this.reportHeaderId = this._appService.reportHeaderId;
    this.selectedCurrency = null;
    this.showCurrency = false;
    this.showDetails = false;
    this.showDialog = false;
    this.showSpinner = false;
    this.statementData = this._appService.statementData;
    this.statementData1 = this._appService.statementData1;
    this.statements = [];
    this.statements.push(this.statementData);
    this.statements.push(this.statementData1);
    this.status = null;
    this.submit = false;
    this.submitDialog = false;
    this.supplierError = false;
    this.supplierId = null;
    this.supplier = null;
    this.suppliers = null;
    this.taskDetails = { employee_number: null, tasks: [] };
    this.template = null;
    this.tmp_attachments = null;
    this.total = null;
    this.user = [];
    this.viewExpense = false;

    /* app helpers */
    this._appService.copyExpense = '';
    this._appService.editExpense = '';
    this._appService.reportHeaderId = '';
    this._appService.selectedOrg = '';
    this._appService.statementData = '';
    this._appService.statementData1 = '';
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', {
      page: this._location.path(),
    });

    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this._router.navigate(['expenses/summary']);
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.format = this.user.date_format || 'dd-MMM-yyyy';
        this.number_format = this.user.number_format || '999,999.99';
        this.dateFormat = this.format;

        this.loadDateFormats();
        this.loadCardLimitDetails();
        this.loadSuppliers();

        setTimeout(() => {
         (() => new FooPicker({
            id: 'expense-date',
            dateFormat: this.format,
          }))();
        });
        if (
          (this._dataService.fromState &&
            this._dataService.fromState === '/notifications') ||
          this.editExpense
        ) {
          this.permissions = this.user.permissions;

          if (this.permissions.indexOf('OTHER-UI-EXPENSE-EDIT') !== -1) {
            this.notificationDetails = this._appService.notificationDetails;
            this._appService.notificationDetails = '';
            this.fromState = true;
            this.fromNotifications = !!(
              this._dataService.fromState &&
              this._dataService.fromState === '/notifications'
            );
          } else {
            this.fromState = false;
            this._appService.notificationDetails = '';
          }
        } else {
          this.fromState = false;
        }
        if (!this.editExpense) {
          this.employee = this.user.user_name;
          this.employeeName = this.user.user_description;
          this.personId = this.user.person_id;
        }
        for (let i = 0; i < this.user.organizations.length; i++) {
          if (
            this._dataService.orgId ===
            this.user.organizations[i].organization_id
          ) {
            this.defaultCurrency = this.user.organizations[i].currency_code;
            this.selectedCurrency = this.user.organizations[i].currency_code;
            break;
          }
        }
        this.cardNumber = this.user.card_number;

        this.org = this._cacheService.getOrgId();
        this.total = this._formatService.formatNumber('0');
        this.showSpinner = true;
        if (!this._cacheService.getPersonsData()) {
          this.loadPersons();
        } else {
          this.persons = this._cacheService.getPersonsData();
          this.setEmployeeName();
        }
        this.loadCurrencies();
        // loadPrompts();

        if (this.editExpense || this.copyExpense) {
          if (this._appService.expenseId) {
            this.reportHeaderId = this._appService.expenseId;
            this._appService.expenseId = null;
          }
          this.showSpinner = true;
          this.onEdit();
        } else {
          this.loadPrompts(this.org, '');
        }
      }
    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addLine() {
    this.limitMsg = '';
    this.promptName = '';
    this.dateChanged = false;
    this.msg = '';
    this.currency_code = this.selectedCurrency;
    this.checkCurrency();
    this.showDetails = true;
    this.expenseAttachments = [];
  }

  calculateCreditLimit() {
    const expenseLimit = {
      half_day: '',
      full_day: '',
      accomodation: '',
      abroad: '',
      travel: '',
      telephone_cellphone: '',
      telephone_internet: '',
    };
    let prompt;
    this.limitMsg = '';
    if (!this.promptName) {
      return;
    }
    prompt = this.promptName.toLowerCase();
    if (prompt.indexOf('food') !== -1 || prompt.indexOf('accomod') !== -1) {
      expenseLimit.half_day = this.getLimit(
        this.currency_code,
        'food',
        'half-day',
        this.org
      );

      expenseLimit.full_day = this.getLimit(
        this.currency_code,
        'food',
        'full-day',
        this.org
      );

      expenseLimit.accomodation = this.getLimit(
        this.currency_code,
        'accomodation',
        'full-day',
        this.org
      );
    }

    if (
      prompt.indexOf('travel') !== -1 ||
      prompt.indexOf('kilometric') !== -1
    ) {
      expenseLimit.travel = this.getLimit(
        this.currency_code,
        'travel',
        'per km',
        this.org
      );
    }

    if (
      prompt.indexOf('telephone') !== -1
    ) {
      expenseLimit.telephone_cellphone = this.getLimit(
        this.currency_code,
        'telephone - cellphone',
        'month',
        this.org
      );

      expenseLimit.telephone_internet = this.getLimit(
        this.currency_code,
        'telephone - internet',
        'month',
        this.org
      );
    }
    this.limitMsg = '';
    if (expenseLimit.half_day) {
      this.limitMsg += 'Food Expense (Half-day): ';
      this.limitMsg += expenseLimit.half_day;
      this.limitMsg += '<br/>';
    }
    if (expenseLimit.full_day) {
      this.limitMsg += 'Food Expense (Full-day): ';
      this.limitMsg += expenseLimit.full_day;
      this.limitMsg += '<br/>';
    }
    if (expenseLimit.accomodation) {
      this.limitMsg += 'Accomodation: ';
      this.limitMsg += expenseLimit.accomodation;
      this.limitMsg += '<br/>';
    }
    if (expenseLimit.travel) {
      this.limitMsg += 'Kilometric Expense: ';
      this.limitMsg += expenseLimit.travel;
      this.limitMsg += '<br/>';
    }
    if (expenseLimit.telephone_cellphone) {
      this.limitMsg += 'Cell Phone: max ';
      this.limitMsg += expenseLimit.telephone_cellphone;
      this.limitMsg += '<br/>';
    }
    if (expenseLimit.telephone_internet) {
      this.limitMsg += 'Internet: max ';
      this.limitMsg += expenseLimit.telephone_internet;
      this.limitMsg += '<br/>';
    }
    if (this.limitMsg) {
      this.limitMsg = '<b>Credit limit on</b> <br/>' + this.limitMsg;
    }
  }

  checkCurrency() {
    if (this.selectedCurrency !== this.currency_code) {
      this.exchangerate = false;
    } else {
      this.exchange_rate = '';
      this.f_exchange_rate = '';
      this.exchangerate = true;
    }
    this.calculateCreditLimit();
  }

  checkExchange(exchange) {
    if (!exchange) {
      this.f_exchange_rate = '';
      return;
    }
    this.exchange_rate = this._formatService.numberParser(exchange);
    this.f_exchange_rate = this._formatService.parseNumber(this.exchange_rate);
    if (this.f_exchange_rate <= 0) {
      this.focusExchange = false;
      this.exchange_rate = '';
      this.f_exchange_rate = '';
      this.exchange_msg = 'Enter Exchange Rate greater than 0';
      return false;
    }
    return true;
  }

  checkHeaderCurrency() {
    for (let i = 0; i < this.expenseLines.length; i++) {
      if (this.selectedCurrency === this.expenseLines[i].currency_code) {
        this.expenseLines[i].exchange_rate = this.expenseLines[
          i
        ].f_exchange_rate = '1';
        this.expenseLines[i].reimbursable_amount =
          this._formatService.formatNumber(
            parseFloat(this.expenseLines[i].f_amount) *
              parseFloat(this.expenseLines[i].f_exchange_rate)
          );
      }
    }
    this.updateLinesTotal();
  }

  checkNo(amt) {
    if (!amt) {
      this.f_amount = '';
      return;
    }
    this.amount = this._formatService.numberParser(amt);
    this.f_amount = this._formatService.parseNumber(this.amount);
    if (this.f_amount <= 0) {
      this.amount_msg = 'Enter amount greater than 0';
      this.amount = '';
      this.f_amount = '';
      this.focusAmount = false;
      return false;
    }
    return true;
  }

  closeDetailsDialog() {
    if (this.expense) {
      this.expense.lineAttaches = this.tmp_attachments;
    }
    this.updateVariables();
  }

  create() {
    let attachmentsCount = 0,
      attachmentsDetails,
      emp_name,
      endPoint,
      expense: any = {},
      expenses = [],
      index,
      line,
      lineData,
      lines = [];
    emp_name = (document.getElementById('userName') as HTMLFormElement).value;
    if (!emp_name) {
      this.focusEmployee = false;
      this.employeeName = '';
      return;
    }
    if (!this.employeeName && emp_name) {
      this._appService.notify({
        msg: emp_name + ' has no employee id',
        status: 1,
      });
      return;
    }
    this.showSpinner = true;
    expense.history = {};
    expense.history.status = this.submit ? 'S' : 'D';
    expense.history.comments = this.submit ? 'submitted' : 'created';
    expense.history.name = '';
    expense.history.creation_date = this._formatService.getTimeStamp();
    expense.history.user = this.user.user_description;
    index = this.persons.findIndex(
      (person) => parseInt(person.person_id) === parseInt(this.employeeName)
    );

    if (index !== -1) {
      expense.employee_id = this.employeeName;
    } else {
      this.employeeName = '';
      this._appService.notify({
        msg: 'Invalid Employee Name',
        status: 1,
      });
      this.focusEmployee = false;
      this.showSpinner = false;
      return;
    }
    expense.creation_date = this._appService.today(0);
    expense.created_by = this.user.user_id;
    expense.last_update_date = this._appService.today(0);
    expense.last_updated_by = this.user.user_id;
    expense.total = this._formatService.parseNumber(this.total.toString());
    if (!this.submit) {
      expense.email_address = '';
      expense.user_name = '';
    }
    expense.expense_report_id = this.expense_report_id;
    if (this.purpose) {
      expense.description = this.purpose;
    } else {
      this.focusPurpose = false;
      this.showSpinner = false;
      this.submit = false;
      return;
    }
    expense.org_id = this.org;
    expense.default_currency_code = this.selectedCurrency;
    expense.project_id = this.projectId || '';
    if (this.expenseLines.length > 0) {
      for (let i = 0; i < this.expenseLines.length; i++) {
        lineData = this.expenseLines[i];
        if (
          lineData.date &&
          lineData.prompt &&
          lineData.currency_code &&
          lineData.amount
        ) {
          line = {};
          line.last_updated_by = this.user.user_id;
          line.last_update_date = this._appService.today(0);
          if (isFinite(this.expenseLines[i].prompt)) {
            index = this.prompts.findIndex(
              (prompt) =>
                prompt.parameter_id === parseInt(this.expenseLines[i].prompt)
            );
            if (index === -1) {
              this.expenseLines[i].prompt = '';
              this.msg = 'Enter valid Expense Type';
              this.status = 1;
              this.showSpinner = false;
              this._appService.notify({
                status: this.status,
                msg: this.msg,
              });
              this.submit = false;
              return;
            }
          }
          line.item_description = this.expenseLines[i].prompt;
          line.amount = parseFloat(
            this._formatService.parseNumber(
              this.expenseLines[i].reimbursable_amount.toString()
            )
          );
          line.exchange_rate = this.expenseLines[i].exchange_rate
            ? parseFloat(
                this._formatService.parseNumber(
                  this.expenseLines[i].exchange_rate.toString()
                )
              )
            : 1;
          line.receipt_currency_amount = parseFloat(
            this._formatService.parseNumber(
              this.expenseLines[i].amount.toString()
            )
          );
          line.currency_code = this.expenseLines[i].currency_code;
          line.creation_date = this._formatService.parseDate(
            this.expenseLines[i].date
          );
          line.created_by = this.user.user_id;
          line.receipt_verified_flag = lineData.receiptstatus;
          line.pay_with_credit_card = lineData.pay_with_credit_card;
          line.code_combination_id = lineData.code_combination_id;
          line.justification = this.expenseLines[i].justification
            ? this.expenseLines[i].justification
            : '';
          if (this.editExpense && lineData.report_line_id) {
            line.report_line_id = lineData.report_line_id;
          }
          line.org_id = this.org;
          line.invoice = lineData.invoice;
          line.supplier_id = lineData.supplier_id;
          line.invoice_amount = lineData.invoice_amount;
          line.supplier_name = lineData.supplier_name || '';
          line.invoice_number = lineData.invoice_number;
          line.attachments = [];
          if (
            this.expenseLines[i].lineAttaches &&
            this.expenseLines[i].lineAttaches.length > 0
          ) {
            attachmentsCount += this.expenseLines[i].lineAttaches.length;
            for (let j = 0; j < this.expenseLines[i].lineAttaches.length; j++) {
              attachmentsDetails = {};
              attachmentsDetails.title = 'Expenses Lines';
              attachmentsDetails.entity_name = 'AP_EXPENSES';
              attachmentsDetails.category_name = 'Miscellaneous';
              attachmentsDetails.description = 'expense lines';
              attachmentsDetails.file_blob =
                this.expenseLines[i].lineAttaches[j].base64;
              attachmentsDetails.file_name =
                this.expenseLines[i].lineAttaches[j].filename;
              if (this.expenseLines[i].lineAttaches[j].filetype) {
                attachmentsDetails.file_content_type =
                  this.expenseLines[i].lineAttaches[j].filetype;
              } else {
                attachmentsDetails.file_content_type = '';
              }
              line.attachments.push(attachmentsDetails);
            }
          }

          lines.push(line);
        } else {
          this.msg = 'Enter all input values in Expense Details';
          this.status = 1;
          this.showSpinner = false;
          this._appService.notify({
            status: this.status,
            msg: this.msg,
          });
          this.submit = false;
          return;
        }
      }

      if (attachmentsCount > 25) {
        this.msg =
          'Cannot add more than 25 attachments. To add more, zip and add the attachments';
        this.status = 1;
        this.showSpinner = false;
        this._appService.notify({
          msg: this.msg,
          status: 1,
        });
        this.submit = false;
        return;
      }
    } else {
      this.msg = 'Add atleast one expense';
      this.status = 1;
      this.showSpinner = false;
      this._appService.notify({
        status: this.status,
        msg: this.msg,
      });
      this.submit = false;
      return;
    }
    expense.lines = lines;
    if (this.submit === true) {
      endPoint = '/expenses/submit/';
    } else {
      endPoint = '/expenses/';
    }
    expenses.push(expense);
    this._expenseService.insertExpenses(endPoint, expenses, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - create()',
          });
        } else {
          this.msg = data.msg;
          this.showSpinner = false;
          this.status = data.status;
          if (data.status === 0) {
            if (this.submit === true) {
              this._appService.expensemsg = 'Expense submitted successfully';
            } else if (this.copyExpense === true) {
              this._appService.expensemsg = 'Expense copied successfully';
            } else {
              this._appService.expensemsg = data.msg;
            }
            this._appService.status = data.status;
            if (this._dataService.fromState === '/activity-planner') {
              this._router.navigate(['/activity-planner']);
            } else {
              this._router.navigate(['expenses/summary']);
            }
          } else {
            this._appService.notify({
              status: data.status,
              msg: data.msg,
            });
          }
          this.submit = false;
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  createExpense() {
    if (this.copyExpense) {
      this.loadAttachmentsData();
    } else {
      this.create();
    }
  }

  deleteLine(line?) {
    this.columnname = 'delete';
    if (line) {
      this.selectedLine = line;
      this.showDialog = true;
    } else {
      let index = this.expenseLines.findIndex(
        (line) => line.id === this.selectedLine.id
      );
      if (index !== -1) {
        if (this.editExpenseData && this.expenseLines[index].report_line_id) {
          if (this.deletedLines) {
            this.deletedLines.push(this.expenseLines[index].report_line_id);
          } else {
            this.deletedLines = [];
            this.deletedLines.push(this.expenseLines[index].report_line_id);
          }
        }
        this.expenseLines.splice(index, 1);
        this.updateLinesTotal();
        this.showDialog = false;
      }
    }
  }

  deleteLineAttachment(index?) {
    setTimeout(() => {
      (document.getElementById('inputtitle') as HTMLFormElement).value = '';
    }, 1);
    if (index !== '' && index !== undefined) {
      this.index = index;
      this.attachmentDialog = true;
    } else {
      this.attachmentDialog = false;
      if (
        this.expenseAttachments[this.index].file_id &&
        this.expenseAttachments[this.index].attached_document_id
      ) {
        this.deletedAttachments.push({
          file_id: this.expenseAttachments[this.index].file_id,
          attached_document_id:
            this.expenseAttachments[this.index].attached_document_id,
        });
      }
      this.expenseAttachments.splice(this.index, 1);
    }
  }

  downloadAttachment(attachment) {
    let a,
      blobFile = this._formatService.base64ToBlob(attachment.base64),
      url;
    if (blobFile) {
      a = document.createElement('a');
      document.body.appendChild(a);
      url = this._window.URL.createObjectURL(blobFile);
      a.href = url;
      a.download = attachment.filename;
      a.click();
      this._window.URL.revokeObjectURL(url);
    }
  }

  editExpenseDetails(expenseIndex, colname) {
    let index;
    this.dateChanged = false;
    this.new_exp_msg = '';
    this.deletedAttachments = [];
    setTimeout(() => {
      (document.getElementById('inputtitle') as HTMLFormElement).value = '';
    }, 1);
    if (colname !== 'delete') {
      this.expense = this.expenseLines[expenseIndex];
      this.new_exp_msg = '';
      this.msg = '';
      this.showDetails = true;
      this._appService.scrollTo('#expense-details-container', 0);
      index = this.prompts.findIndex(
        (prompt) => prompt.prompt === this.expense.prompt
      );
      if (index !== -1) {
        this.promptName = this.prompts[index].prompt;
        this.prompt = this.prompts[index].parameter_id;
      }
      this.justification = this.expense.justification
        ? this.expense.justification
        : '';
      this.date = this.expense.date;
      this.amount = this.expense.amount;
      this.exchange_rate = this.expense.exchange_rate
        ? this.expense.exchange_rate
        : '';
      this.currency_code = this.expense.currency_code;
      this.calculateCreditLimit();
      this.missingreceipt = this.expense.receiptstatus;
      this.creditCardFlag = this.expense.pay_with_credit_card || 'N';
      this.codeCombinationId = this.expense.code_combination_id;
      this.checkCurrency();
      this.expenseAttachments = [];
      if (this.expense.lineAttaches && this.expense.lineAttaches.length > 0) {
        this.expenseAttachments = this.expense.lineAttaches;
      }
      this.tmp_attachments = [...this.expenseAttachments];
      if (
        this.expense.deletedAttachments &&
        this.expense.deletedAttachments.length > 0
      ) {
        this.deletedAttachments = [...this.expense.deletedAttachments];
      }
      this.supplierId = this.expense.supplier_id;
      this.supplier = this.expense.supplier
        ? this.expense.supplier
        : this.expense.supplier_name
        ? this.expense.supplier_name
        : '';
      setTimeout(() => {
        (document.getElementById('supplierName') as HTMLFormElement).value =
          this.supplier;
      });
      this.invoiceFlag = this.expense.invoice || 'N';
      this.invoiceAmount = this._formatService.numberParser(
        this.expense.invoice_amount
      );
      this.invoiceNumber = this.expense.invoice_number;
    } else {
      this.showDetails = false;
    }
  }

  getLimit(currency, prompt, duration, org) {
    let index;

    // To get abroad limit
    if (prompt === 'accomodation' && currency !== this.defaultCurrency) {
      index = this.creditLimit.findIndex(
        (limit) =>
          limit.prompt + limit.duration + limit.org_id ===
          prompt + duration + org
      );
      if (index !== -1 && this.creditLimit[index].abroad) {
        return this.creditLimit[index].abroad + ' ' + this.defaultCurrency;
      }
    }
    index = this.creditLimit.findIndex(
      (limit) =>
        limit.currency + limit.prompt + limit.duration + limit.org_id ===
        currency + prompt + duration + org
    );
    if (index === -1) {
      index = this.creditLimit.findIndex(
        (cLimit) =>
          cLimit.currency + cLimit.prompt + cLimit.duration ===
          currency + prompt + duration
      );
    }
    // To get telephone refund
    if (index !== -1 && prompt.indexOf('telephone') !== -1) {
      return `${this.creditLimit[index].limit} ${currency}/${this.creditLimit[index].duration}`;
    }
    return index !== -1 ? this.creditLimit[index].limit + ' ' + currency : '';
  }

  goToSummary() {
    if (this._dataService.fromState === '/activity-planner') {
      this._router.navigate(['/activity-planner']);
    } else {
      this._router.navigate(['expenses/summary']);
    }
  }

  insertCodeCombination() {
    let index = this.prompts.findIndex(
      (prompt) => prompt.parameter_id === parseInt(this.prompt)
    );
    if (index !== -1) {
      this.promptName = this.prompts[index].prompt;
      this.codeCombinationId = this.prompts[index].code_combination_id;
    }
    this.calculateCreditLimit();
  }

  loadAttachmentsData() {
    this.showSpinner = true;
    let attachment_ids = [],
      endPoint,
      lineAttachments;
    for (let i = 0; i < this.expenseLines.length; i++) {
      if (
        this.expenseLines[i].lineAttaches &&
        this.expenseLines[i].lineAttaches.length > 0
      ) {
        for (let j = 0; j < this.expenseLines[i].lineAttaches.length; j++) {
          if (this.expenseLines[i].lineAttaches[j].file_id) {
            attachment_ids.push({
              pk1_value: this.expenseLines[i].lineAttaches[j].pk1_value,
              notification_type: 'expenses',
              file_name: this.expenseLines[i].lineAttaches[j].filename,
            });
          }
        }
      }
    }
    if (attachment_ids.length > 0) {
      endPoint = '/expenses/attachments/';
      this._httpService.httpRequest(
        'POST',
        endPoint,
        attachment_ids,
        (data) => {
          try {
            if (data === null || data === undefined) {
              this._appService.notify({
                status: 1,
                msg: 'Server Error - loadAttachmentsData()',
              });
            } else if (data.status === 1) {
              this._appService.notify({
                msg: data.msg,
                status: data.status,
              });
            } else {
              for (let i = 0; i < data.length; i++) {
                for (let j = 0; j < this.expenseLines.length; j++) {
                  if (
                    this.expenseLines[j].lineAttaches &&
                    this.expenseLines[j].lineAttaches.length > 0
                  ) {
                    lineAttachments = this.expenseLines[j].lineAttaches;
                    for (let k = 0; k < lineAttachments.length; k++) {
                      if (
                        lineAttachments[k].pk1_value &&
                        data[i][0].pk1_value.toString() ===
                          lineAttachments[k].pk1_value.toString() &&
                        data[i][0].file_name === lineAttachments[k].filename
                      ) {
                        this.expenseLines[j].lineAttaches[k].base64 =
                          data[i][0].file_data;
                      }
                    }
                  }
                }
              }
              if (this.copyExpense) {
                this.create();
              }
            }
            this.showSpinner = false;
          } catch (e) {
            this._appService.notify({
              msg: e.message,
              status: 1,
              details: '<pre>' + e.stack + '</pre>',
            });
          }
        }
      );
    } else if (this.copyExpense) {
      this.create();
    }
  }

  loadCardLimitDetails(): void {
    const endPoint = '/expenses/limit/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadCardLimitDetails()',
        });
      } else if (data.status === 1) {
        this._appService.notify({
          msg: data.msg,
          status: data.status,
        });
      } else {
        this.creditLimit = data;
      }
    });
  }

  loadCurrencies(): void {
    const endPoint = '/expenses/currencies/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadCurrencies()',
        });
        this.showSpinner = false;
      } else if (data.status === 1) {
        this.showSpinner = false;
        this._appService.notify(new APIError(data.msg));
      } else {
        this.currencies = data;
      }
    });
  }

  loadDateFormats(): void {
    const endPoint = '/preferences/dateformat/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadDateFormats()',
        });
        this.showSpinner = false;
      } else if (data.status === 1) {
        this._appService.notify({
          msg: data.msg,
          status: data.status,
        });
      } else {
        this.dateFormats = data;
        for (let i = 0; i < this.dateFormats.length; i++) {
          if (this.dateFormat === this.dateFormats[i].lookup_code) {
            this.dateFormatExample = this.dateFormats[i].meaning;
            break;
          }
        }
      }
    });
  }

  loadPersons(): void {
    const endPoint = '/users/persons/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadPersons()',
          });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this._cacheService.setPersonsData(data);
          this.persons = data;
          this.setEmployeeName();
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadPrompts(org_id, expense_data) {
    const endPoint = `/expenses/prompts/${org_id}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadPrompts()',
          });
          this.showSpinner = false;
        } else if (data.status === 1) {
          this.showSpinner = false;
          this._appService.notify(new APIError(data.msg));
        } else if (data.length > 0) {
          this.prompts = data;
          this.template = data[0].report_type;
          this.expense_report_id = data[0].expense_report_id;
          if (!this.editExpense && !this.copyExpense) {
            this.showSpinner = false;
          } else {
            this.onEditExpense(expense_data);
          }
        } else {
          this.showSpinner = false;
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadSuppliers(): void {
    const endPoint = `/supplier/vendorlov/${this._dataService.orgId}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error => loadSuppliers() ',
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.suppliers = data;
      }
    });
  }

  loadTasks(): void {
    const employee = this.persons.find(
      (user) => user.person_id === parseInt(this.employeeName, 10)
    );
    if (employee) {
      const endPoint = `/activityplanner/tasks/${employee.employee_number}/`;
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error => loadTasks() ',
          });
        } else if (data.status === 0) {
          this.taskDetails.tasks = data.tasks;
        } else {
          this._appService.notify(new APIError(data.msg));
        }
      });
    }
  }

  onDownload(attachment) {
    let attachment_id = [],
      endPoint = '/expenses/attachments/';
    if (attachment.base64) {
      this.downloadAttachment(attachment);
      return;
    }
    this.showSpinner = true;
    attachment_id.push({
      pk1_value: attachment.pk1_value,
      notification_type: 'expenses',
      file_name: attachment.filename,
    });
    /* to service */
    this._httpService.httpRequest('POST', endPoint, attachment_id, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - onDownload()',
          });
        } else if (data.status === 1) {
          this._appService.notify({
            msg: data.msg,
            status: data.status,
          });
        } else {
          attachment.base64 = data[0][0].file_data;
          this.downloadAttachment(attachment);
        }
        this.showSpinner = false;
      } catch (e) {
        this._appService.notify({
          msg: e.message,
          status: 1,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  onEdit() {
    let endPoint = `/expenses/${this.reportHeaderId}/`;
    this.editExpenseData = [];
    this.expenseLines = [];
    this._expenseService.loadExpenses(endPoint, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - onEdit()',
          });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          // $scope.showSpinner = false;
          this.loadPrompts(data[0].org_id, data);
          // _this.onEditExpense(data);
        }
        this.showSpinner = false;
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  onEditExpense(data) {
    let attachment,
      date_arr,
      editAttachments,
      expenseLines,
      f_date,
      history = {},
      index;
    this.editExpenseData = data;
    this.predicate = 'exp_history_id';
    this.desc = true;
    this.purpose = this.editExpenseData[0].description;
    this.total = this._formatService.formatNumber(
      this.editExpenseData[0].total
    );
    this.employeeName = this.editExpenseData[0].employee_id;
    this.projectId = this.editExpenseData[0].project_id;
    this.viewExpense =
      (this.editExpenseData[0].core_wf_status_flag === 'C' &&
        this.editExpenseData[0].workflow_approved_flag === 'A') ||
      (this.editExpenseData[0].core_wf_status_flag === 'I' &&
        !this.editExpenseData[0].workflow_approved_flag);
    if (
      (this.editExpenseData[0].core_wf_status_flag === 'C' &&
        (this.editExpenseData[0].workflow_approved_flag === 'A' ||
          this.editExpenseData[0].workflow_approved_flag === 'R')) ||
      (this.editExpenseData[0].core_wf_status_flag === null &&
        this.editExpenseData[0].workflow_approved_flag === null)
    ) {
      this.fromState = false;
    }

    setTimeout(() => {
      (document.getElementById('userName') as HTMLFormElement).value =
        this.editExpenseData[0].employee_name;
    }, 1);
    this.selectedCurrency = this.editExpenseData[0].default_currency_code;
    this.history = [];
    for (let k = 0; k < this.editExpenseData[0].history.length; k++) {
      date_arr = this.editExpenseData[0].history[k].creation_date.split(' ');
      f_date = this._formatService.formatDate(date_arr[0]);
      this.editExpenseData[0].history[k].f_creation_date =
        f_date + ' ' + date_arr[1];
      history = {};
      history = {
        exp_history_id: this.editExpenseData[0].history[k].exp_history_id,
        description: this.editExpenseData[0].history[k].description,
        f_creation_date: this.editExpenseData[0].history[k].f_creation_date,
        creation_date: this.editExpenseData[0].history[k].creation_date,
        approver_name: this.editExpenseData[0].history[k].approver_name,
        approver_comments: this.editExpenseData[0].history[k].approver_comments,
      };
      this.history.push(history);
    }
    if (this.editExpenseData[0].lines.length > 0) {
      for (let i = 0; i < this.editExpenseData[0].lines.length; i++) {
        expenseLines = {};
        expenseLines.amount = this._formatService.formatNumber(
          this.editExpenseData[0].lines[i].receipt_currency_amount
        );
        expenseLines.f_amount =
          this.editExpenseData[0].lines[i].receipt_currency_amount;
        expenseLines.reimbursable_amount = this._formatService.formatNumber(
          this.editExpenseData[0].lines[i].amount
        );
        expenseLines.has_line_id = 1;
        if (this.prompts) {
          index = this.prompts.findIndex(
            (prompt) =>
              prompt.prompt ===
              this.editExpenseData[0].lines[i].item_description
          );
          if (index !== -1) {
            expenseLines.prompt =
              this.editExpenseData[0].lines[i].item_description;
          }
        }
        expenseLines.justification = this.editExpenseData[0].lines[i]
          .justification
          ? this.editExpenseData[0].lines[i].justification
          : '';
        expenseLines.exchange_rate = this._formatService.formatNumber(
          parseFloat(this.editExpenseData[0].lines[i].exchange_rate)
        );
        expenseLines.f_exchange_rate =
          this.editExpenseData[0].lines[i].exchange_rate;
        expenseLines.currency_code =
          this.editExpenseData[0].lines[i].currency_code;
        expenseLines.date = this._formatService.formatDate(
          this.editExpenseData[0].lines[i].creation_date
        );
        expenseLines.report_line_id =
          this.editExpenseData[0].lines[i].report_line_id;
        expenseLines.code_combination_id =
          this.editExpenseData[0].lines[i].code_combination_id;
        expenseLines.receiptstatus =
          this.editExpenseData[0].lines[i].receipt_verified_flag;
        expenseLines.pay_with_credit_card =
          this.editExpenseData[0].lines[i].pay_with_credit_card;
        expenseLines.org_id = this.editExpenseData[0].lines[i].org_id;
        expenseLines.invoice = this.editExpenseData[0].lines[i].invoice;
        expenseLines.supplier_id = this.editExpenseData[0].lines[i].supplier_id;
        expenseLines.invoice_amount =
          this.editExpenseData[0].lines[i].invoice_amount;
        expenseLines.supplier = this.editExpenseData[0].lines[i].supplier_name || '';
        expenseLines.invoice_number =
          this.editExpenseData[0].lines[i].invoice_number;
        expenseLines.deletedAttachments = [];
        expenseLines.id = i;

        expenseLines.lineAttaches = [];
        if (this.editExpenseData[0].lines[i].attachments.length > 0) {
          expenseLines.attachmentmsg =
            this.editExpenseData[0].lines[i].attachments.length;
          for (
            let j = 0;
            j < this.editExpenseData[0].lines[i].attachments.length;
            j++
          ) {
            attachment = this.editExpenseData[0].lines[i].attachments[j];
            editAttachments = {};
            editAttachments.filename = attachment.file_name;
            editAttachments.filetype = attachment.file_content_type;
            // editAttachments.base64 = attachment.file_data;
            editAttachments.filesize = attachment.file_size;
            editAttachments.file_id = attachment.file_id;
            editAttachments.pk1_value = attachment.pk1_value;
            editAttachments.attached_document_id =
              attachment.attached_document_id;
            expenseLines.lineAttaches.push(editAttachments);
          }
        } else {
          expenseLines.attachmentmsg = 'No';
        }
        this.expenseLines.push(expenseLines);
      }
    }
    this.showSpinner = false;
  }

  // Selecting an employee from auto-complete
  onEmployeeNameChange() {
    setTimeout(() => {
      const index = this.persons.findIndex(
        (person) =>
          parseInt(person.person_id, 10) === parseInt(this.employeeName, 10)
      );
      // Load the relevant projects for the selected user
      if (!this.employeeName) {
        this.projectId = null;
      } else if (this.taskDetails.employee_number !== this.employeeName) {
        this.taskDetails.employee_number = this.employeeName;
        this.loadTasks();
      }
      if (index !== -1) {
        (document.getElementById('userName') as HTMLFormElement).value =
          this.persons[index].full_name;
      }
    });
  }

  onInvoiceAmtChange() {
    this.invoiceAmount = this._formatService.numberParser(this.invoiceAmount);
  }

  onSubmit(e?) {
    if (e) {
      if (this.purpose && this.expenseLines.length > 0) {
        this.submitDialog = true;
      } else {
        if (!this.purpose) {
          this.focusPurpose = false;
          this.showSpinner = false;
        } else {
          this.msg = 'Add atleast one expense';
          this.status = 1;
          this._appService.notify({
            status: this.status,
            msg: this.msg,
          });
        }
      }
    } else {
      this.submitDialog = false;
      this.submit = true;
      if (this.editExpense) {
        this.updateExpense();
      } else {
        this.createExpense();
      }
    }
  }

  onSupplierSelect() {
    if (this.supplier) {
      let index = this.suppliers.findIndex(
        (supplier) => supplier.vendor_id === parseInt(this.supplier)
      );
      if (index !== -1) {
        this.supplierId = this.suppliers[index].vendor_id;
        this.supplier = this.suppliers[index].vendor_name;
        setTimeout(() => {
          (document.getElementById('supplierName') as HTMLFormElement).value =
            this.supplier;
        });
      }
    }
  }

  resetInvoiceDetails() {
    this.invoiceNumber = null;
    this.supplier = null;
    this.supplierId = null;
    this.invoiceAmount = null;
  }

  saveExpenseDetails() {
    let index;
    if (!this.prompt || !this.date || !this.amount || !this.currency_code) {
      this.focusPrompt = false;
      this.focusJustification = false;
      this.focusDate = false;
      this.focusCurrency = false;
      this.focusAmount = false;
      this.focusExchange = false;
      this.exchange_msg = 'Exchange Rate is required';
      this.amount_msg = 'Amount is required';
      this.date_msg = 'Start Date is required';
      return;
    } else {
      if (!this.checkNo(this.amount)) {
        return;
      }
      index = this.prompts.findIndex(
        (prompt) => prompt.parameter_id === parseInt(this.prompt)
      );
      if (index !== -1) {
        this.varPromptName = this.prompts[index].prompt;
      }
    }

    this.supplierError = false;
    this.invoiceAmountError = false;
    this.invoiceNumberError = false;

    if (this.invoiceFlag === 'Y') {
      if (!this.supplier) {
        this.supplierError = true;
      }
      if (!this.invoiceAmount) {
        this.invoiceAmountError = true;
      }
      if (!this.invoiceNumber) {
        this.invoiceNumberError = true;
      }
    } else {
      this.resetInvoiceDetails();
    }

    if (
      this.supplierError ||
      this.invoiceAmountError ||
      this.invoiceNumberError
    ) {
      return;
    }

    this.new_exp_msg = '';
    this.checkCurrency();

    if (this.expense) {
      this.updateExpenseLine();
    } else {
      this.saveExpenseLine();
    }
  }

  saveExpenseLine() {
    let expensedate = this._formatService.dateInMillis(
        this._formatService.parseDate(this.date)
      ),
      linesDate,
      newLine: any = {};

    for (let i = 0; i < this.expenseLines.length; i++) {
      linesDate = this._formatService.dateInMillis(
        this._formatService.parseDate(this.expenseLines[i].date)
      );
      if (
        this.varPromptName === this.expenseLines[i].prompt &&
        expensedate === linesDate
      ) {
        this.prompt = '';
        this.focusPrompt = false;
        this.new_exp_msg = 'Expense with duplicate Expense Type and Date';
        this.status = 1;
        return;
      }
    }
    if (!this.exchangerate) {
      if (this.exchange_rate) {
        newLine.exchange_rate = this.exchange_rate;
        newLine.f_exchange_rate = this.f_exchange_rate;
      } else {
        this.focusExchange = false;
        this.exchange_msg = 'Exchange Rate is required';
        return;
      }
    } else {
      newLine.exchange_rate = '1';
      newLine.f_exchange_rate = '1';
    }
    if (this.missingreceipt === 'N') {
      if (this.expenseAttachments.length === 0) {
        this.new_exp_msg =
          'Add atleast one receipt or change the receipt missing status to yes';
        this.status = 1;
        return;
      }
      newLine.lineAttaches = this.expenseAttachments;
      newLine.attachmentmsg = this.expenseAttachments.length;
    } else {
      newLine.attachmentmsg = 'No';
      newLine.lineAttaches = [];
    }

    newLine.prompt = this.varPromptName;
    newLine.id = this.expenseLines.length;
    newLine.justification = this.justification ? this.justification : '';
    newLine.date = this.date;
    newLine.currency_code = this.currency_code;
    newLine.reimbursable_amount = this._formatService.formatNumber(
      parseFloat(this.f_amount) * (parseFloat(this.f_exchange_rate) || 1)
    );
    newLine.amount = this.amount;
    newLine.f_amount = this.f_amount;
    newLine.code_combination_id = this.codeCombinationId;
    newLine.receiptstatus = this.missingreceipt;
    newLine.pay_with_credit_card = this.creditCardFlag;
    // newLine.has_line_id = 1;
    newLine.invoice = this.invoiceFlag;
    newLine.supplier_id = this.supplierId;
    newLine.invoice_amount = this._formatService.parseNumber(
      this.invoiceAmount
    );
    newLine.supplier_name = this.supplier || '';
    newLine.invoice_number = this.invoiceNumber;
    this.expenseLines.push(newLine);
    this.updateVariables();
  }

  setEmployeeName() {
    if (this.user.user_id && !this.editExpense && !this.copyExpense) {
      this.employeeName = this.user.person_id;
      setTimeout(() => {
        let index = this.persons.findIndex(
          (person) =>
            parseInt(person.person_id) === parseInt(this.user.person_id)
        );
        if (index !== -1) {
          (document.getElementById('userName') as HTMLFormElement).value =
            this.persons[index].full_name;
        }
      }, 1);
    }
  }

  updateExpense() {
    let attachmentDetails,
      attachmentsCount = 0,
      endPoint,
      expense: any = {},
      line,
      lineData,
      lines: any = [];
    this.showSpinner = true;
    expense.employee_id = this.employeeName;
    if (this.submit) {
      expense.submit_code = 'SUBMIT';
    } else {
      expense.submit_code = 'UPDATE';
    }
    expense.history = {};
    expense.history.status = this.submit ? 'S' : 'U';
    expense.history.comments = this.submit ? 'submitted' : 'updated';
    expense.history.name = '';
    expense.history.creation_date = this._appService.today(0);
    expense.history.user = this.user.user_description;
    if (
      this.editExpenseData[0].core_wf_status_flag === 'C' &&
      this.editExpenseData[0].workflow_approved_flag === 'R'
    ) {
      expense.core_wf_status_flag = '';
      expense.workflow_approved_flag = '';
    }
    expense.project_id = this.projectId || '';
    expense.report_header_id = this.reportHeaderId;
    expense.creation_date = this.editExpenseData[0].creation_date;
    expense.created_by = this.editExpenseData[0].created_by;
    expense.last_update_date = this._appService.today(0);
    expense.last_updated_by = this.user.user_id;
    expense.last_updated_name = this.user.user_description;
    expense.total = this._formatService.parseNumber(this.total.toString());
    expense.expense_report_id = this.expense_report_id;
    if (this.purpose) {
      expense.description = this.purpose;
    } else {
      this.focusPurpose = false;
      this.showSpinner = false;
      this.submit = false;
      return;
    }
    expense.org_id = this.editExpenseData[0].org_id;
    expense.default_currency_code = this.selectedCurrency;
    expense.deleteLines = this.deletedLines;
    if (this.expenseLines.length > 0) {
      for (let i = 0; i < this.expenseLines.length; i++) {
        lineData = this.expenseLines[i];
        if (lineData.deletedAttachments) {
          lines.deletedAttachments = lineData.deletedAttachments;
        }
        if (
          lineData.date &&
          lineData.prompt &&
          lineData.currency_code &&
          lineData.amount
        ) {
          line = {};
          line.last_updated_by = this.user.user_id;
          line.last_update_date = this._appService.today(0);

          line.item_description = this.expenseLines[i].prompt;
          line.amount = parseFloat(
            this._formatService.parseNumber(
              this.expenseLines[i].reimbursable_amount.toString()
            )
          );
          line.exchange_rate = this.expenseLines[i].exchange_rate
            ? parseFloat(
                this._formatService.parseNumber(
                  this.expenseLines[i].exchange_rate.toString()
                )
              )
            : 1;
          line.receipt_currency_amount = parseFloat(
            this._formatService.parseNumber(
              this.expenseLines[i].amount.toString()
            )
          );
          line.currency_code = this.expenseLines[i].currency_code;
          line.creation_date = this._formatService.parseDate(lineData.date);
          if (!lineData.hasOwnProperty('report_line_id')) {
            line.created_by = this.user.user_id;
            line.org_id = this.expenseLines[i].org_id;
          }
          line.justification = this.expenseLines[i].justification
            ? this.expenseLines[i].justification
            : '';
          line.receipt_verified_flag = this.expenseLines[i].receiptstatus;
          line.pay_with_credit_card =
            this.expenseLines[i].pay_with_credit_card || 'N';
          line.code_combination_id = this.expenseLines[i].code_combination_id;
          line.report_line_id = this.expenseLines[i].report_line_id
            ? this.expenseLines[i].report_line_id
            : '';
          line.supplier_id = this.expenseLines[i].supplier_id || '';
          line.invoice = this.expenseLines[i].invoice || '';
          line.invoice_amount = this.expenseLines[i].invoice_amount || '';
          line.supplier_name = this.expenseLines[i].supplier_name || '';
          line.invoice_number = this.expenseLines[i].invoice_number || '';
          if (
            this.expenseLines[i].deletedAttachments &&
            this.expenseLines[i].report_line_id
          ) {
            line.deletedAttachments = [];
            line.deletedAttachments = this.expenseLines[i].deletedAttachments;
          }
          line.attachments = [];
          if (
            this.expenseLines[i].lineAttaches &&
            this.expenseLines[i].lineAttaches.length > 0
          ) {
            attachmentsCount += this.expenseLines[i].lineAttaches.length;
            for (let j = 0; j < this.expenseLines[i].lineAttaches.length; j++) {
              if (!this.expenseLines[i].lineAttaches[j].file_id) {
                attachmentDetails = {};
                attachmentDetails.title = 'Expenses Lines';
                attachmentDetails.entity_name = 'AP_EXPENSES';
                attachmentDetails.category_name = 'Miscellaneous';
                attachmentDetails.description = 'expense lines';
                attachmentDetails.file_name =
                  this.expenseLines[i].lineAttaches[j].filename;
                attachmentDetails.file_blob =
                  this.expenseLines[i].lineAttaches[j].base64;
                attachmentDetails.file_content_type =
                  this.expenseLines[i].lineAttaches[j].filetype;
                attachmentDetails.file_id = '';
                attachmentDetails.ref_id = '';
                line.attachments.push(attachmentDetails);
              }
            }
          }

          lines.push(line);
        } else {
          this.msg = 'Enter all input values in Expense Details';
          this.status = 1;
          this.showSpinner = false;
          this._appService.notify({
            status: this.status,
            msg: this.msg,
          });
          this.submit = false;
          return;
        }
      }

      if (attachmentsCount > 25) {
        this.msg =
          'Cannot add more than 25 attachments. To add more, zip and add the attachments';
        this.status = 1;
        this.showSpinner = false;
        this._appService.notify({
          msg: this.msg,
          status: this.status,
        });
        this.submit = false;
        return;
      }
    } else {
      this.msg = 'Add atleast one expense';
      this.status = 1;
      this.showSpinner = false;
      this._appService.notify({
        status: this.status,
        msg: this.msg,
      });
      this.submit = false;
      return;
    }

    expense.lines = lines;
    endPoint = '/expenses/';
    this._httpService.httpRequest('PUT', endPoint, expense, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - updateExpense()',
          });
        } else {
          if (data.status === 0 && this.submit) {
            this._appService.status = data.status;
            this._appService.expensemsg =
              data.msg +
              ' ' +
              'for' +
              ' ' +
              'report #' +
              ' ' +
              this.reportHeaderId;
            if (this._dataService.fromState === '/activity-planner') {
              this._router.navigate(['/activity-planner']);
            } else {
              this._router.navigate(['expenses/summary']);
            }
          } else if (data.status === 0) {
            this._appService.notify({
              status: data.status,
              msg: data.msg,
            });
            if (this.fromState && this.fromNotifications) {
              this._appService.notificationDetails = this.notificationDetails;
              this._router.navigate(['notifications']);
            } else {
              this.onEdit();
            }
          } else {
            this._appService.notify({
              status: data.status,
              msg: data.msg,
            });
            if (this._dataService.fromState === '/activity-planner') {
              this._router.navigate(['/activity-planner']);
            } else {
              this._router.navigate(['expenses/summary']);
            }
          }
          this.submit = false;
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  updateExpenseLine() {
    if (!this.exchangerate) {
      if (this.exchange_rate) {
        this.f_exchange_rate = this.f_exchange_rate
          ? this.f_exchange_rate
          : this._formatService.convertNumber(this.exchange_rate);
      } else {
        this.focusExchange = false;
        this.exchange_msg = 'Exchange Rate is required';
        return;
      }
    } else {
      this.exchange_rate = '1';
      this.f_exchange_rate = '1';
    }
    this.expense.deletedAttachments = this.deletedAttachments;
    if (this.missingreceipt === 'N') {
      if (this.expenseAttachments.length === 0) {
        this.new_exp_msg =
          'Add atleast one receipt or change the receipt missing status to yes';
        this.status = 1;
        return;
      }

      this.expense.lineAttaches = this.expenseAttachments;
      this.expense.attachmentmsg = this.expenseAttachments.length;
    } else {
      this.expense.attachmentmsg = 'No';
      if (this.expenseAttachments.length > 0 && this.expense.report_line_id) {
        for (let i = 0; i < this.expenseAttachments.length; i++) {
          if (
            this.expenseAttachments[i].file_id &&
            this.expenseAttachments[i].attached_document_id
          ) {
            this.deletedAttachments.push({
              file_id: this.expenseAttachments[i].file_id,
              attached_document_id:
                this.expenseAttachments[i].attached_document_id,
            });
          }
        }
      }
      this.expense.lineAttaches = [];
    }

    this.expense.justification = this.justification ? this.justification : '';
    this.expense.amount = this.amount;
    this.f_amount = this.f_amount
      ? this.f_amount
      : this._formatService.convertNumber(this.amount);
    this.expense.f_amount = this.f_amount;
    this.expense.exchange_rate = this.exchange_rate ? this.exchange_rate : '';
    this.expense.f_exchange_rate = this.exchange_rate
      ? this.f_exchange_rate
      : '';
    this.expense.currency_code = this.currency_code;
    this.expense.date = this.date;
    this.expense.code_combination_id = this.codeCombinationId;
    this.expense.receiptstatus = this.missingreceipt;
    this.expense.pay_with_credit_card = this.creditCardFlag;
    this.expense.reimbursable_amount = this._formatService.formatNumber(
      parseFloat(this.f_amount) *
        (this.exchange_rate ? parseFloat(this.f_exchange_rate) : 1)
    );
    this.expense.prompt = this.varPromptName;
    this.expense.invoice = this.invoiceFlag;
    this.expense.supplier_id = this.supplierId;
    this.expense.invoice_amount = this._formatService.parseNumber(
      this.invoiceAmount
    );
    this.expense.supplier_name = this.supplier || '';
    this.expense.invoice_number = this.invoiceNumber;
    this.updateVariables();
  }

  updateLinesTotal() {
    let lines = this.expenseLines,
      total = 0;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].amount) {
        if (lines[i].exchange_rate) {
          total =
            total +
            parseFloat(lines[i].f_amount) *
              parseFloat(lines[i].f_exchange_rate);
        } else {
          total = total + parseFloat(lines[i].f_amount);
        }
      }
    }
    this.total = this._formatService.formatNumber(total);
  }

  updateVariables() {
    this.prompt = '';
    this.justification = '';
    this.date = '';
    this.currency_code = '';
    this.missingreceipt = '';
    this.amount = '';
    this.new_exp_msg = '';
    this.f_amount = '';
    this.f_exchange_rate = '';
    this.exchange_rate = '';
    this.focusPrompt = true;
    this.focusJustification = true;
    this.focusDate = true;
    this.date_msg = '';
    this.focusCurrency = true;
    this.focusAmount = true;
    this.focusExchange = true;
    this.missingreceipt = 'N';
    this.creditCardFlag = 'N';
    this.expenseAttachments = [];
    this.codeCombinationId = '';
    this.tmp_attachments = [];
    this.deletedAttachments = [];
    setTimeout(() => {
      (document.getElementById('inputtitle') as HTMLFormElement).value = '';
      (document.getElementById('supplierName') as HTMLFormElement).value = '';
    }, 1);
    this.expense = '';
    this.showDetails = false;
    this.updateLinesTotal();
    this.limitMsg = '';
    this.promptName = '';
    this.invoiceFlag = 'N';
    this.resetInvoiceDetails();
  }

  uploadLineAttachment(lineAttachments) {
    let sizeWithinLimit,
      dialogDescElement = jQuery('.dialog-description');
    sizeWithinLimit = this._appService.checkFileSize(
      lineAttachments,
      this.expenseAttachments
    );
    if (sizeWithinLimit) {
      this.new_exp_msg = '';
      if (
        lineAttachments &&
        this.expenseAttachments &&
        this.expenseAttachments.length > 0
      ) {
        setTimeout(() => {
          (document.getElementById('inputtitle') as HTMLFormElement).value = '';
        }, 1);
        for (let i = 0; i < this.expenseAttachments.length; i++) {
          if (
            this.expenseAttachments[i].filename === lineAttachments.filename
          ) {
            this.lineAttachments = '';
            this.new_exp_msg = 'File already exists';
            this.status = 1;
            dialogDescElement.animate(
              {
                scrollTop: 0,
              },
              500
            );
            return;
          }
        }
        this.expenseAttachments.push(lineAttachments);
      } else {
        if (lineAttachments) {
          this.expenseAttachments = [];
          this.expenseAttachments.push(lineAttachments);
        }
      }
    } else {
      this.lineAttachments = '';
      this.new_exp_msg = 'Uploaded file/files size should not exceed 25MB';
      this.status = 1;
      dialogDescElement.animate(
        {
          scrollTop: 0,
        },
        500
      );
      return;
    }
    this.lineAttachments = {};
    setTimeout(() => {
      (document.getElementById('inputtitle') as HTMLFormElement).value = '';
    }, 1);
  }

  validateDate() {
    if (!this.dateChanged || !this.date) {
      return;
    }
    this.dateChanged = false;
    let result = this._formatService.validateDate(this.date);
    if (!result) {
      this.date_msg = 'Enter date in ' + this.dateFormat + ' format';
      this.date_msg += ' (Ex: ' + this.dateFormatExample + ')';
      this.date = '';
      this.focusDate = false;
    } else {
      this.date = result;
    }
  }
}
