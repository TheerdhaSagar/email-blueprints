import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { ExpenseService } from '../../globals/expense.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { APIError } from '../../globals/api.error';

declare var FooPicker: any;

@Component({
  selector: 'app-expenses-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [OrderByPipe],
  encapsulation: ViewEncapsulation.None
})
export class ExpenseSummaryComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _expenseService: ExpenseService;
  private _orderBy: OrderByPipe;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  cardArray: any[];
  cardAttachment: any;
  cardDetails: any[];
  cardNumber: any;
  currencies: any[];
  dateChanged: boolean;
  dateFlag: any;
  dateFormats: any[];
  dateFormatExample: any;
  desc: boolean;
  employeeExpenses: any[];
  enterDetails: boolean;
  expStatus: any;
  expenseList: any[];
  expenseOption: string;
  expensesSearch: any;
  expenseStatus: any;
  expenseStatusList: ({ id: string, status: string })[];
  expense_report_id: any;
  expenses: any;
  focus: boolean;
  focusDate: boolean;
  focusUpload: boolean;
  focus_amount: boolean;
  focus_card_no: boolean;
  focus_currency: boolean;
  focus_date: boolean;
  focus_date_search: boolean;
  focus_exchange: boolean;
  focus_justification: boolean;
  from_date: any;
  invalidAmountFlag: any;
  lineData: any;
  missingdata: any[];
  months: string[];
  numberFormat: any;
  org: any;
  pageDim: boolean;
  personId: any;
  personIdFlag: any;
  persons: any[];
  pickerDate: any;
  predicate: string;
  prompts: any[];
  report_id: any;
  roles: any;
  searchQuery: any;
  selectedCurrency: any;
  selectedEmployee: any;
  selectedFormat: string;
  selectedLine: any;
  selectedOrg: string;
  selectedTemplate: string;
  showDialog: boolean;
  showExpenseDialog: boolean;
  showSpinner: boolean;
  statementData: any[];
  subOrgChange: Subscription;
  template: any;
  templateDialog: boolean;
  templateValue: ({ id: string, value: string })[];
  to_date: any;
  toggleFilter: (e?) => void;
  total: any;
  uploadDialog: boolean;
  user: any;
  userId: any;
  viewData: any[];

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, expenseService: ExpenseService,
              orderBy: OrderByPipe, formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._expenseService = expenseService;
    this._orderBy = orderBy;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', {
      page: this._location.path()
    });

    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this.init();
    });

    this.init();
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  applyFilter() {
    let fromdate_millis, todate_millis;
    this.expenseStatus = this.expStatus;
    this.focus_date_search = false;
    if (this.from_date && this.to_date) {
      fromdate_millis = this._formatService.dateInMillis(this._formatService.parseDate(this.from_date));
      todate_millis = this._formatService.dateInMillis(this._formatService.parseDate(this.to_date));
      if (fromdate_millis > todate_millis) {
        this.focus_date_search = true;
        this.from_date = '';
        return;
      }
    }
    this.pageDim = true;
    this.loadData();
    this.toggleFilter();
  }


  checkCardNumber(expense) {
    if (!expense.employee_card_no) {
      expense.employee_card_no = '';
      expense.employee_name = '';
      expense.enableEmployee = true;
      this.groupByEmployees();
    } else {
      this.updateByCardNumber(expense);
    }
  }

  checkExchange(d) {
    if (d.exchange_rate) {
      let result = this._formatService.validatePattern(d.exchange_rate.toString(), 3);
      if (result) {
        if (!parseFloat(this._formatService.parseNumber(d.exchange_rate.toString()))) {
          this._appService.notify({
            msg: 'Enter exchange rate greater than 0',
            status: 1
          });
          d.exchange_rate = '';
          this.focus_exchange = true;
        }
      } else {
        this._appService.notify({
          msg: 'Enter in ' + this.numberFormat + ' format',
          status: 1
        });
        d.exchange_rate = '';
        this.focus_exchange = true;
      }
    }
  }

  checkHeaderCurrency(d) {
    if (this.selectedCurrency === d.currency_code) {
      d.exchange_rate = this._formatService.formatNumber('1');
      d.exchangerate = true;
    } else {
      d.exchangerate = false;
    }
  }

  checkNo(d) {
    if (d.receipt_currency_amount) {
      let result = this._formatService.validatePattern(d.receipt_currency_amount.toString());
      if (result) {
        if (!parseFloat(this._formatService.parseNumber(d.receipt_currency_amount.toString()))) {
          d.receipt_currency_amount = '';
          this.focus_amount = true;
          this._appService.notify({
            msg: 'Enter amount greater than 0',
            status: 1
          });
        }
      } else {
        d.receipt_currency_amount = '';
        this.focus_amount = true;
        this._appService.notify({
          msg: 'Enter amount in ' + this.numberFormat + ' format',
          status: 1
        });
      }
    }
  }

  checkNumber(expenseAmount) {
    if (!expenseAmount) {
      return;
    }
    let result = this._formatService.validatePattern(expenseAmount.toString());
    if (result) {
      return expenseAmount;
    } else {
      this.focus_amount = true;
      this.invalidAmountFlag = true;
      return '';
    }
  }

  closeDialog() {
    this.enterDetails = false;
    this.missingdata = [];
    this.selectedTemplate = 'generic';
    this.selectedFormat = 'Generic';
    this.cardAttachment = '';
    this.pageDim = false;
  }

  closeUpload() {
    this.cardAttachment = '';
    this.templateDialog = false;
    this.selectedTemplate = 'generic';
  }

  convertDate(date, template?) {
    let alphaMonth, date_array = [],
      parsedDate;
    if (!template) {
      if (this._formatService.isDateFormattable(this._formatService.parseDate(date))) {
        return date;
      } else {
        date = '';
        this.focus_date = true;
        this.dateFlag = true;
      }
    } else {
      if (template === 'it') {
        date_array[0] = date.substr(0, 2);
        date_array[1] = date.substr(2, 2);
        date_array[2] = date.substr(4, 2);
        alphaMonth = this.months[parseInt(date_array[1]) - 1];
        if (alphaMonth === undefined || alphaMonth === null) {
          this._appService.notify({
            msg: 'Invalid date. Please select valid date',
            status: 1
          });
          date = '';
          this.focus_date = true;
          return date;
        }
        parsedDate = date_array[2] + '-' + alphaMonth + '-' + '20' + date_array[0];
      } else if (template === 'us') {
        date_array = date.split('/');
        alphaMonth = this.months[parseInt(date_array[0]) - 1];
        if (alphaMonth === undefined || alphaMonth === null) {
          this._appService.notify({
            msg: 'Invalid date. Please select valid date',
            status: 1
          });
          date = '';
          this.focus_date = true;
          return date;
        }
        parsedDate = date_array[1] + '-' + alphaMonth + '-' + '20' + date_array[2];
      } else if (template === 'ics') {
        date_array = date.split('/');
        alphaMonth = this.months[parseInt(date_array[1]) - 1];
        if (alphaMonth === undefined || alphaMonth === null) {
          this._appService.notify({
            msg: 'Invalid date. Please select valid date',
            status: 1
          });
          date = '';
          this.focus_date = true;
          return date;
        }
        parsedDate = date_array[0] + '-' + alphaMonth + '-' + date_array[2];
      }
      return this._formatService.formatDate(parsedDate);
    }
  }

  copyQuote(e) {
    if (e) {
      this._appService.reportHeaderId = e.report_header_id;
      this._appService.copyExpense = true;
      let index = this.persons.map(x => x.person_id).indexOf(e.employee_id);
      this._appService.expenseEmpNo = this.persons[index].employee_number;
      this._router.navigate(['expenses/manage']);
    }
  }

  createExpense(expenses) {
    let endPoint = '/expenses/';
    this._expenseService.insertExpenses(endPoint, expenses, (data) => {
      try {
        this.cardAttachment = '';
        this.expenseList = [];
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - createExpense()'
          });
        } else {
          if (data.status === 0) {
            this._appService.notify({
              status: data.status,
              msg: data.msg
            });
          } else {
            this._appService.notify({
              status: data.status,
              msg: data.msg
            });
            return;
          }
          this.loadData();
        }
      } catch (e) {
        // this.cardAttachment = '';
        // expenseList = [];
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    });
  }

  createNewExpense() {
    this._router.navigate(['expenses/manage']);
  }

  deleteExistingExpense(c?) {
    if (c) {
      this.showDialog = true;
      this.report_id = c.report_header_id;
    } else {
      this.showDialog = false;
      this.pageDim = true;
      let endPoint = '/expenses/' + this.report_id + '/';
      this._expenseService.deleteExpense(endPoint, (data) => {
        try {
          this.pageDim = false;
          if (data === null || data === undefined) {
            this._appService.notify({ status: 1, msg: 'Server Error - deleteExistingExpense()' });
          } else if (data.status === 1) {
            this._appService.notify(new APIError(data.msg));
          } else {
            this._appService.notify({
              status: data.status,
              msg: data.msg + ' ' + 'for' + ' #' + this.report_id
            });
            this.loadData();
          }
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }
  }

  deleteExpenseLine(line?) {
    let i, index;
    if (line) {
      this.selectedLine = line;
      this.showExpenseDialog = true;
    } else {
      this.showExpenseDialog = false;
      index = this.viewData.map(x =>
        x.id
      ).indexOf(this.selectedLine.id);
      if (index !== -1) {
        this.viewData.splice(index, 1);
      }
      for (i = 0; i < this.viewData.length; i++) {
        this.viewData[i].id = i;
        new FooPicker({
          id: 'date' + (Math.random() * 1000),
          dateFormat: this.pickerDate
        });
      }
      this.groupByEmployees();
    }
  }

  downloadCSV() {
    let cartasi = 'data:text/csv;base64,RGF0YSBWYWx1dGEsSW5zZWduYSxJbXBvcnRvIFNwZXNhLENvZGljZSBWYWx1dGEsRXhjaGFuZ2UgUmF0ZSxDb2RpY2UgQ2FydGEKMTIvMDQvMjAxNixPWk8gSE9URUwgQlYsNjYsRVVSLDEsMTExMTExMTExMTExMTExMAoyMC8wNS8yMDE2LFBBUEVSIE1BUlQsMjEwLEVVUiwxLDExMTExMTExMTExMTExMTAK',
      cornercard = 'data:text/csv;base64,RGF0YSxEZXNjcml6aW9uZSxBZGRlYml0byBFVVIsQ3VycmVuY3kgQ29kZSxFeGNoYW5nZSBSYXRlLE51bWVybyBDYXJ0YQoxMi8wNC8yMDE2LFNDQU5ESUMgSE9URUxTIEFOR0xBSVMgODEsMjEwLEVVUiwxLDExMTExMTExMTExMTExMTAKMjAvMDYvMjAxNixPWk8gSE9URUwgQlYsMzAwLEVVUiwxLDExMTExMTExMTExMTExMTAK',
      element = document.getElementById('example-csv') as HTMLAnchorElement,
      generic = 'data:text/csv;base64,RGF0ZSxEZXNjcmlwdGlvbixBbW91bnQsQ3VycmVuY3kgQ29kZSxFeGNoYW5nZSBSYXRlLENhcmQgTnVtYmVyCjEyLzA2LzIwMTYsQWNjb21vZGF0aW9uLDIwMCxFVVIsMSwxMTExMTExMTExMTExMTEwCjIwLzExLzIwMTUsSG90ZWwsMTAwLFBMTiwxMiwyMjIyMjIyMjIyMjIyMjIwCg==',
      hsbc_ca = 'data:text/csv;base64,VHJhbnNhY3Rpb24gRGF0ZSxUcmFuc2FjdGlvbiBEZXNjcmlwdGlvbixBbW91bnQsQ3VycmVuY3kgQ29kZSxFeGNoYW5nZSBSYXRlLENhcmQgTnVtYmVyCjEyLzA0LzIwMTYsT1pPIEhPVEVMIEJWLDIxMCxFVVIsMSwxMTExMTExMTExMTExMTEwCjIwLzA2LzIwMTYsQk9MRU5JVVMgUkVTVEFVUkFOVCwzMDAsRVVSLDEsMTExMTExMTExMTExMTExMAo=',
      hsbc_us = 'data:text/csv;base64,VHJhbnNhY3Rpb24gRGF0ZSxKdXN0aWZpY2F0aW9uLEFtb3VudCxDdXJyZW5jeSBDb2RlLEV4Y2hhbmdlIFJhdGUsQ2FyZCBOdW1iZXIKMTIvMDQvMjAxNixCT0xFTklVUyBSRVNUQVVSQU5ULDIwMSxFVVIsMSwxMTExMTExMTExMTExMTEwCjIwLzA2LzIwMTYsT1pPIEhPVEVMIEJWLDMwMCxFVVIsMSwxMTExMTExMTExMTExMTEwCg==',
      ics_nl = 'data:text/csv;base64,VHJhbnNhY3Rpb24gRGF0ZSxEZXNjcmlwdGlvbixBbW91bnQsQ3VycmVuY3ksRXhjaGFuZ2UgUmF0ZSxDYXJkIE51bWJlcgoxMi8wNC8yMDE2LE9aTyBIT1RFTCBCViwyMDEsRVVSLDEsMTExMTExMTExMTExMTExMAoyMC8wNi8yMDE2LEJPTEVOSVVTIFJFU1RBVVJBTlQsMzAwLEVVUiwxLDExMTExMTExMTExMTExMTEK';
    if (this.selectedTemplate === 'cartasi') {
      element.href = cartasi;
    } else if (this.selectedTemplate === 'generic') {
      element.href = generic;
    } else if (this.selectedTemplate === 'cornercard') {
      element.href = cornercard;
    } else if (this.selectedTemplate === 'ca') {
      element.href = hsbc_ca;
    } else if (this.selectedTemplate === 'us') {
      element.href = hsbc_us;
    } else if (this.selectedTemplate === 'ics') {
      element.href = ics_nl;
    }

    element.download = 'example.csv';
  }

  editExpense(e) {
    this._appService.reportHeaderId = e.report_header_id;
    this._appService.editExpense = true;
    let index = this.persons.map(x => x.person_id).indexOf(e.employee_id);
    if (index !== -1) {
      this._appService.expenseEmpNo = this.persons[index].employee_number;
    }
    this._router.navigate(['expenses/manage']);
  }

  expensesList(expenseDetails) {
    let expense: any = {},
      i, lineData, line: any = {},
      lines = [];
    this.pageDim = true;
    this.total = 0;
    this.showSpinner = true;
    expense.history = {};
    expense.history.status = 'D';
    expense.history.comments = 'created';
    expense.history.name = '';
    expense.history.creation_date = this._appService.today(0);
    expense.history.user = this.user.user_description;
    expense.employee_id = expenseDetails.person_id;
    expense.creation_date = this._appService.today(0);
    expense.created_by = this.userId;
    expense.last_update_date = this._appService.today(0);
    expense.last_updated_by = this.userId;
    expense.expense_report_id = -1;
    expense.org_id = expenseDetails.default_org_id;
    expense.default_currency_code = expenseDetails.reimbursableCurrency;
    expense.description = expenseDetails.purpose;
    expense.email_address = expenseDetails.email_address;
    expense.user_name = expenseDetails.employeeName;
    for (i = 0; i < expenseDetails.lines.length; i++) {
      lineData = expenseDetails.lines[i];
      line = {};
      line.last_updated_by = this.user.user_id;
      line.last_update_date = this._appService.today(0);
      line.code_combination_id = '';
      line.amount = this._formatService.parseNumber(this._formatService.formatNumber((this._formatService.parseNumber(lineData.receipt_currency_amount.toString()) *
        this._formatService.parseNumber(lineData.exchange_rate.toString())).toString()).toString());
      line.exchange_rate = this._formatService.parseNumber(lineData.exchange_rate.toString());
      line.receipt_currency_amount = this._formatService.parseNumber(lineData.receipt_currency_amount.toString());
      line.currency_code = lineData.currency_code;
      line.creation_date = lineData.creation_date ? this._formatService.parseDate(lineData.creation_date) : '';
      this.total = this._formatService.formatNumber((this._formatService.parseNumber(this.total.toString()) + line.amount).toString());
      line.created_by = this.user.user_id;
      line.receipt_verified_flag = 'Y';
      line.justification = lineData.justification ? lineData.justification : '';
      line.org_id = this._cacheService.getOrgId();
      lines.push(line);
    }
    expense.total = this._formatService.parseNumber(this.total.toString());
    expense.lines = lines;
    this.expenseList.push(expense);

  }

  // Exports the table data into spreadsheet
  exportToExcel() {
    this.toggleFilter();
    let exportdata = this._orderBy.transform(this.expenses, this.predicate, this.desc),
      i, tableData: any = {},
      tmpObj, tmpData = [];
    for (i = 0; i < exportdata.length; i++) {
      tmpObj = {};
      tmpObj['Report #'] = {
        data: exportdata[i].report_header_id
      };
      tmpObj['Employee Name'] = {
        data: exportdata[i].employee_name
      };
      tmpObj.Description = {
        data: exportdata[i].description
      };
      tmpObj['Created On'] = {
        data: exportdata[i].f_created_on
      };
      tmpObj['Created By'] = {
        data: exportdata[i].user_description
      };
      tmpObj['Current Approver'] = {
        data: exportdata[i].approver
      };
      tmpObj.Amount = {
        data: exportdata[i].amount,
        align: 'right'
      };
      tmpObj.Currency = {
        data: exportdata[i].default_currency_code
      };
      tmpObj.Status = {
        data: exportdata[i].exp_status
      };

      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Expenses', tableData, 'expenses');
  }

  getEmployeeDetails(data) {
    let card_substr, emp_card_substr, f, i, j;
    this.cardDetails = data;
    if (data.length > 0) {
      // this.enterDetails = false;
      for (i = 0; i < this.viewData.length; i++) {
        if (!this.viewData[i].employee_card_no) {
          continue;
        }
        for (j = 0; j < this.cardDetails.length; j++) {
          emp_card_substr = this.viewData[i].employee_card_no.substr(this.viewData[i].employee_card_no.length - 4, this.viewData[i].employee_card_no.length);
          card_substr = this.cardDetails[j].card_number.substr(this.cardDetails[j].card_number.length - 4, this.cardDetails[j].card_number.length);
          if (emp_card_substr === card_substr) {
            this.viewData[i].employee_name = this.cardDetails[j].user_description;
            this.viewData[i].person_id = this.cardDetails[j].person_id;
            this.viewData[i].default_org_id = this.cardDetails[j].default_org_id;
            this.viewData[i].email_address = this.cardDetails[j].email_address;
            break;
          }
        }
      }
    }
    if (data.length !== this.cardArray.length) {
      this.pageDim = false;
      this._appService.notify({
        status: 1,
        msg: 'Invalid card number'
      });
      for (i = 0; i < this.viewData.length; i++) {
        f = 0;
        for (j = 0; j < this.cardDetails.length; j++) {
          if (this.viewData[i].employee_card_no.substr(this.viewData[i].employee_card_no.length - 4, this.viewData[i].employee_card_no.length) ===
            this.cardDetails[j].card_number.substr(this.cardDetails[j].card_number.length - 4, this.cardDetails[j].card_number.length)) {
            f = 1;
            break;
          }
        }
        if (f === 0) {
          this.viewData[i].employee_card_no = '';
          this.viewData[i].employee_name = '';
          this.viewData[i].enableEmployee = true;
          this.focus_card_no = true;
        }
      }
      this.cardAttachment = '';
    }
    this.groupByEmployees();
  }


  getEmployeeNames() {
    let card = [],
      endPoint = '/users/cardnumber/',
      i;
    if (!this.cardArray.length) {
      return;
    }
    for (i = 0; i < this.cardArray.length; i++) {
      card.push({
        card_number: this.cardArray[i]
      });
    }
    this._httpService.httpRequest('POST', endPoint, card, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this.cardAttachment = '';
          this._appService.notify({
            status: 1,
            msg: 'Server Error - getEmployeeNames()'
          });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else {
          this.getEmployeeDetails(data);
        }
      } catch (err) {
        this.cardAttachment = '';
        this._appService.notify({
          status: 1,
          msg: err.message,
          details: '<pre>' + err.stack + '</pre>'
        });
      }
    });
    this.groupByEmployees();
  }

  groupByEmployees() {
    let employeeExpense: any = {},
      employeeExpenses = [],
      i, index;
    this.employeeExpenses = [];
    for (i = 0; i < this.viewData.length; i++) {
      employeeExpense = {
        purpose: '',
        reimbursableCurrency: '',
        total: '',
        cardNumber: '',
        employeeName: '',
        lines: [],
        person_id: '',
        expense_org_id: '',
        email_address: ''
      };
      if (employeeExpenses.length > 0) {
        index = employeeExpenses.map((x) =>
          x.person_id
        ).indexOf(this.viewData[i].person_id);
        if (index !== -1) {
          employeeExpenses[index].total = parseFloat(employeeExpenses[index].total) + (this.viewData[i].receipt_currency_amount * this.viewData[i].exchange_rate);
          employeeExpenses[index].email_address = this.viewData[i].email_address;
          employeeExpenses[index].person_id = this.viewData[i].person_id;
          employeeExpenses[index].lines.push(this.viewData[i]);
        } else {
          employeeExpense.default_org_id = this.viewData[i].default_org_id;
          employeeExpense.person_id = this.viewData[i].person_id;
          employeeExpense.employeeName = this.viewData[i].employee_name;
          employeeExpense.email_address = this.viewData[i].email_address;
          employeeExpense.cardNumber = this.viewData[i].employee_card_no;
          employeeExpense.total = this.viewData[i].receipt_currency_amount * this.viewData[i].exchange_rate;
          employeeExpense.lines.push(this.viewData[i]);
          employeeExpenses.push(employeeExpense);
        }
      } else {
        employeeExpense.default_org_id = this.viewData[i].default_org_id;
        employeeExpense.person_id = this.viewData[i].person_id;
        employeeExpense.employeeName = this.viewData[i].employee_name;
        employeeExpense.cardNumber = this.viewData[i].employee_card_no;
        employeeExpense.email_address = this.viewData[i].email_address;
        employeeExpense.total = this.viewData[i].receipt_currency_amount * this.viewData[i].exchange_rate;
        employeeExpense.lines.push(this.viewData[i]);
        employeeExpenses.push(employeeExpense);
      }
    }
    this.pageDim = false;
    this.employeeExpenses = employeeExpenses;
  }

  init() {
    this.cardArray = [];
    this.cardAttachment = '';
    this.cardDetails = [];
    this.cardNumber = null;
    this.dateChanged = false;
    this.dateFlag = null;
    this.dateFormats = [];
    this.desc = true;
    this.employeeExpenses = [];
    this.enterDetails = false;
    this.expStatus = null;
    this.expenseList = [];
    this.expenseOption = 'ALL';
    this.expenseStatus = null;
    this.expenseStatusList = [{
      id: 'DRAFTS',
      status: 'Drafts'
    }, {
      id: 'INPROCESS',
      status: 'Processing'
    }, {
      id: 'APPROVED',
      status: 'Approved'
    }, {
      id: 'REJECTED',
      status: 'Rejected'
    }, {
      id: 'ALL',
      status: 'All'
    }];
    this.expense_report_id = null;
    this.expenses = null;
    this.focus = false;
    this.focusUpload = false;
    this.focus_amount = false;
    this.focus_card_no = false;
    this.focus_currency = true;
    this.focus_date = true;
    this.focus_date_search = false;
    this.focus_exchange = false;
    this.focus_justification = true;
    this.from_date = null;
    this.invalidAmountFlag = null;
    this.lineData = null;
    this.missingdata = [];
    this.months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    this.numberFormat = null;
    this.org = null;
    this.pageDim = false;
    this.personId = null;
    this.personIdFlag = null;
    this.persons = [];
    this.pickerDate = null;
    this.predicate = 'report_header_id';
    this.prompts = [];
    this.report_id = null;
    this.roles = this._dataService.roles;
    this.searchQuery = null;
    this.selectedCurrency = null;
    this.selectedFormat = 'Generic';
    this.selectedLine = null;
    this.selectedTemplate = 'generic';
    this.showDialog = false;
    this.showExpenseDialog = false;
    this.showSpinner = false;
    this.statementData = [];
    this.template = null;
    this.templateDialog = false;
    this.templateValue = [{
      id: 'generic',
      value: 'Generic'
    }, {
      id: 'cartasi',
      value: 'CartaSi IT'
    }, {
      id: 'cornercard',
      value: 'Cornercard CH'
    }, {
      id: 'ca',
      value: 'HSBS CA'
    }, {
      id: 'us',
      value: 'HSBC US'
    }, {
      id: 'ics',
      value: 'ICS NL'
    }];
    this.to_date = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.total = null;
    this.uploadDialog = false;
    this.user = null;
    this.userId = null;
    this.viewData = [];

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.pickerDate = this.user.date_format || 'dd-MMM-yyyy';
        this.loadDateFormats();
        this.numberFormat = this.user.number_format || '999,999.99';
        new FooPicker({
          id: 'fromdate',
          dateFormat: this.pickerDate
        });
        new FooPicker({
          id: 'todate',
          dateFormat: this.pickerDate
        });

        for (let i = 0; i < this.user.organizations.length; i++) {
          if (this._dataService.orgId === this.user.organizations[i].organization_id) {
            this.selectedCurrency = this.user.organizations[i].currency_code;
            break;
          }
        }
        this.personId = this.user.person_id;
        this.userId = this.user.user_id;
        this.cardNumber = this.user.card_number;
        this.pageDim = true;
        if (this._dataService.fromState && this._dataService.fromState === 'expenses/manage' && this._appService.expensemsg) {
          this._appService.notify({
            status: this._appService.status,
            msg: this._appService.expensemsg
          });
          this._appService.status = '';
          this._appService.expensemsg = '';
        }
        this.loadPersons();
        if (this._dataService.fromState && this._dataService.fromState === 'expenses/manage' && !this._appService.expensemsg &&
          this.org === this._cacheService.getOrgId()) {
          if (this._cacheService.getExpenseData()) {
            this.pageDim = false;
            this.expenses = this._cacheService.getExpenseData();
            this._cacheService.setExpenseData(null);
            this.expStatus = this.expenseStatus = this._appService.selectedStatus;
            this._appService.selectedStatus = '';
          } else {
            this.org = this._cacheService.getOrgId();
            this.expStatus = this.expenseStatus = 'ALL';
            this.loadData();
          }
        } else {
          this.org = this._cacheService.getOrgId();
          this.expStatus = this.expenseStatus = 'ALL';
          this.loadData();
        }
        if (this.expStatus) {
          switch (this.expStatus) {
            case 'DRAFTS':
              this.expenseOption = 'Drafts';
              break;
            case 'INPROCESS':
              this.expenseOption = 'Processing';
              break;
            case 'APPROVED':
              this.expenseOption = 'Approved';
              break;
            case 'REJECTED':
              this.expenseOption = 'Rejected';
              break;
            case 'ALL':
              this.expenseOption = 'All';
              break;
            default:
              break;
          }
        }
        this.loadPrompts();
        this.loadCurrencies();
      }
    });
  }

  loadCurrencies(): void {
    const endPoint = '/expenses/currencies/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadCurrencies()'
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.currencies = data;
      }
    });
  }

  loadData() {
    let endPoint = '/expenses/summary/',
      req: any = {};
    if (this.expStatus) {
      switch (this.expStatus) {
        case 'DRAFTS':
          this.expenseOption = 'Drafts';
          break;
        case 'INPROCESS':
          this.expenseOption = 'Processing';
          break;
        case 'APPROVED':
          this.expenseOption = 'Approved';
          break;
        case 'REJECTED':
          this.expenseOption = 'Rejected';
          break;
        case 'ALL':
          this.expenseOption = 'All';
          break;
        default:
          break;
      }
    }

    if (this._appService.status === 0) {
      this._appService.status = null;
      this._appService.expensemsg = null;
    }
    this.expenses = null;
    req.status = this.expStatus;
    req.org_id = this.org;
    req.from_date = this.from_date ? this._formatService.parseDate(this.from_date) : '';
    req.to_date = this.to_date ? this._formatService.parseDate(this.to_date) : '';
    if (this.roles.isAdmin || this.roles.UIExpensesAll) {
      req.person_id = '';
      req.created_by = '';
    } else {
      req.created_by = this.user.user_id;
      req.person_id = this.personId;
    }
    this._expenseService.insertExpenses(endPoint, req, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - loadData()'
          });
          this.pageDim = false;
        } else {
          if (data.hasOwnProperty('status') && data.status === 1) {
            this._appService.notify({
              msg: data.msg,
              status: data.status
            });
            this.showSpinner = false;
            return;
          }
          this.parseExpensesData(data);
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    });
  }

  loadDateFormats() {
    let endPoint = '/preferences/dateformat/',
      i;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadDateFormats()'
        });
        this.showSpinner = false;
      } else if (data.status === 1) {
        this._appService.notify({
          msg: data.msg,
          status: data.status
        });
      } else {
        this.dateFormats = data;
        for (i = 0; i < this.dateFormats.length; i++) {
          if (this.pickerDate === this.dateFormats[i].lookup_code) {
            this.dateFormatExample = this.dateFormats[i].meaning;
            break;
          }
        }
      }
    });
  }

  loadPersons(): void {
    const endPoint = '/users/persons/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadPersons()'
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this.persons = data;
      }
    });
  }

  loadPrompts(): void {
    const endPoint = `/expenses/prompts/${this.org}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadPrompts()'
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (data.length > 0) {
        this.prompts = data;
        this.template = data[0].report_type;
        this.expense_report_id = data[0].expense_report_id;
      }
    });
  }


  onExpenseCreation() {
    if (this.viewData.length === 0) {
      this._appService.notify({
        msg: 'No lines to create expense.Upload a file with atleast one expense',
        status: 1
      });
      this.employeeExpenses = [];
      this.selectedTemplate = 'generic';
      this.selectedFormat = 'Generic';
      this.cardAttachment = '';
      this.enterDetails = false;
      return;
    }
    this.pageDim = true;
    this.personIdFlag = false;
    for (let i = 0; i < this.viewData.length; i++) {
      if (!parseFloat(this.viewData[i].receipt_currency_amount) || !(this.viewData[i].employee_card_no ||
        this.viewData[i].employee_name) || !this.viewData[i].exchange_rate ||
        !this.viewData[i].creation_date || !this.viewData[i].currency_code || !this.viewData[i].justification) {
        this._appService.notify({
          status: 1,
          msg: 'Enter all inputs'
        });
        this.pageDim = false;
        this.focus_currency = true;
        this.focus_exchange = true;
        this.focus_date = true;
        this.focus_justification = true;
        this.focus_card_no = true;
        this.focus_amount = true;
        if (!parseFloat(this.viewData[i].receipt_currency_amount)) {
          this.viewData[i].receipt_currency_amount = '';
        }
        return;
      }
    }
    for (let i = 0; i < this.employeeExpenses.length; i++) {
      if (!this.employeeExpenses[i].person_id) {
        this._appService.notify({
          msg: this.employeeExpenses[i].employeeName + ' has no employee id. Delete expenses for this employee and upload the file',
          status: 1
        });
        this.personIdFlag = true;
      }
    }
    if (this.personIdFlag) {
      this.pageDim = false;
      this.personIdFlag = false;
      return;
    }
    for (let i = 0; i < this.employeeExpenses.length; i++) {
      this.employeeExpenses[i].purpose = 'Credit Card Statement for ' + this.employeeExpenses[i].employeeName + '';
      this.employeeExpenses[i].reimbursableCurrency = this.selectedCurrency;
      this.expensesList(this.employeeExpenses[i]);
    }
    this.createExpense(this.expenseList);
    this.enterDetails = false;

    this.selectedTemplate = 'generic';
    this.selectedFormat = 'Generic';
  }


  // Parse the data from web service and assign it to scope
  parseExpensesData(data) {
    try {
      this._expenseService.parseExpensesData(data, this.expenseStatus, (parsedData) => {
        this.expenses = parsedData;
        this._cacheService.setExpenseData(this.expenses);
        this._appService.selectedStatus = this.expStatus;
      });
    } catch (e) {
      this.pageDim = false;
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: '<pre>' + e.stack + '</pre>'
      });
    }
    this.pageDim = false;
  }

  // Table sorting
  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
    }
    if (this.searchQuery && this.searchQuery.length > 0) {
      this.expenses = this._orderBy.transform(this.expenses, this.predicate, this.desc);
    } else {
      this.expenses = this._orderBy.transform(this.expenses, this.predicate, this.desc);
    }
  }

  updateByCardNumber(expense) {
    let card, card_length, card_no, card_string, endPoint = '/users/cardnumber/';
    card_string = expense.employee_card_no.toString();
    card_length = card_string.length;
    card_no = card_string.substr(card_length - 4, card_length);
    card = [{
      card_number: '%' + card_no
    }];
    this._httpService.httpRequest('POST', endPoint, card, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - updateByCardNumber()'
          });
        } else {
          this.employeeExpenses = [];
          if (data && data.length > 0) {
            expense.employee_name = data[0].user_description;
            expense.default_org_id = data[0].default_org_id;
            expense.person_id = data[0].person_id;
            expense.email_address = data[0].email_address;
            expense.enableEmployee = false;
          } else {
            expense.employee_card_no = '';
            expense.employee_name = '';
            expense.enableEmployee = true;
            this.focus_card_no = true;
            this._appService.notify({
              status: 1,
              msg: 'Invalid card number'
            });
          }
          this.groupByEmployees();
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.msg,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    });
  }

  updateByEmployeeName(expense) {
    let index = this.persons.map(person => person.full_name).indexOf(expense.selectedEmployee),
      selectedEmp = index !== -1 ? this.persons[index] : '';
    if (selectedEmp && selectedEmp.person_id === '' || selectedEmp.person_id === undefined) {
      this._appService.notify({
        msg: this.selectedEmployee.full_name + ' has no employee_id. Select another employee or delete the line to continue',
        status: 1
      });
      expense.person_id = '';
      expense.employee_name = '';
      expense.email_address = '';
      expense.employee_card_no = '';
      expense.default_org_id = '';
    } else {
      expense.employee_name = selectedEmp.full_name;
      expense.default_org_id = selectedEmp.default_org_id;
      expense.person_id = selectedEmp.person_id;
      expense.employee_card_no = selectedEmp.card_number;
      expense.email_address = selectedEmp.email_address;
    }
    this.groupByEmployees();
  }

  updateSelectedFormat() {
    let index = this.templateValue.map(x =>
      x.id
    ).indexOf(this.selectedTemplate);
    if (index !== -1) {
      this.selectedFormat = this.templateValue[index].value;
    }
  }

  // Upload attachment
  upload() {
    this.templateDialog = false;
    this.invalidAmountFlag = false;
    this.dateFlag = false;
    this.focus = false;
    this.viewData = [];
    this.cardArray = [];
    this.lineData = '';
    let attachment: any = {},
      endPoint = '/expenses/readingcsv/';
    this.missingdata = [];
    this.pageDim = true;
    attachment.filename = this.cardAttachment.filename;
    attachment.base64 = this.cardAttachment.base64;
    attachment.filetype = this.cardAttachment.filetype;
    this.uploadDialog = false;
    /* Todo to service */
    this._httpService.httpRequest('POST', endPoint, attachment, (data) => {
      try {
        if (data === null || data === undefined) {
          this.cardAttachment = '';
          this._appService.notify({
            status: 1,
            msg: 'Server Error - upload()'
          });
          this.pageDim = false;
        } else if (data.status === 1) {
          this._appService.notify({
            status: data.status,
            msg: data.msg
          });
          this.pageDim = false;
          this.cardAttachment = '';
          this.selectedTemplate = 'generic';
          this.selectedFormat = 'Generic';
        } else {
          this.validateUploadedData(data);
        }
      } catch (e) {
        this.cardAttachment = '';
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    });
  }

  uploadStatement() {
    this._appService.statementData = this.statementData;
    this._appService.importData = true;
    this._router.navigate(['expenses/manage']);
  }

  validateCardNumber() {
    let i, c, card_no, card_string;
    this.cardArray = [];
    for (i = 0; i < this.viewData.length; i++) {
      if (!this.viewData[i].employee_card_no) {
        this.viewData[i].enableEmployee = true;
        continue;
      }
      card_string = this.viewData[i].employee_card_no.toString();
      card_no = card_string.substr(card_string.length - 4, card_string.length);
      if (this.cardArray.length === 0) {
        if (card_no) {
          this.cardArray.push('%' + card_no);
        }
      } else {
        for (c = 0; c < this.cardArray.length; c++) {
          if (this.cardArray[c] === '%' + card_no) {
            break;
          }
        }
        if (c === this.cardArray.length) {
          this.cardArray.push('%' + card_no);
        }
      }
    }
  }

  validateDate(expense) {
    let msg, result;
    if (!expense.dateChanged || !expense.creation_date) {
      return;
    }
    expense.dateChanged = false;
    result = this._formatService.validateDate(expense.creation_date);
    if (!result) {
      msg = 'Enter date in ' + this.pickerDate + ' format';
      msg += ' (Ex: ' + this.dateFormatExample + ')';
      this._appService.notify({
        msg,
        status: 1
      });
      expense.creation_date = '';
      this.focusDate = false;
    } else {
      expense.creation_date = result;
    }
  }

  validateFile() {
    let extension, file_name, filename, nameLength;
    this.focusUpload = false;
    filename = this.cardAttachment.filename;
    file_name = filename.split('.');
    nameLength = file_name.length;
    extension = file_name[nameLength - 1];
    if (extension.toUpperCase() !== 'XLS' && extension.toUpperCase() !== 'XLSX' &&
      extension.toUpperCase() !== 'CSV') {
      this.cardAttachment.filename = '';
      this.cardAttachment = '';
      this.focusUpload = true;
    }
  }

  validateUploadedData(data) {
    this.statementData = data;
    let i, index;
    // this.selectedTemplate = 'generic';
    for (i = 0; i < this.statementData.length; i++) {
      this.statementData[i].id = i;
      this.viewData.push(this.statementData[i]);
    }
    this.lineData = this.viewData[0];
    if (this.selectedTemplate === 'generic') {
      if (!this.lineData.hasOwnProperty('date') || !this.lineData.hasOwnProperty('description') || !this.lineData.hasOwnProperty('amount') ||
        !this.lineData.hasOwnProperty('currency_code') || !this.lineData.hasOwnProperty('card_number')) {
        this._appService.notify({
          status: 1,
          msg: 'Uploaded file format doesnt match with selected format (' + this.selectedFormat + ')'
        });
        this.selectedTemplate = 'generic';
        this.selectedFormat = 'Generic';
        this.cardAttachment = '';
        this.pageDim = false;
        return;
      }
    } else if (this.selectedTemplate === 'cartasi') {
      if (!this.lineData.hasOwnProperty('data_valuta') || !this.lineData.hasOwnProperty('insegna') || !this.lineData.hasOwnProperty('importo_spesa') ||
        !this.lineData.hasOwnProperty('codice_valuta') || !this.lineData.hasOwnProperty('codice_carta')) {
        this._appService.notify({
          status: 1,
          msg: 'Uploaded file format doesnt match with selected format (' + this.selectedFormat + ')'
        });
        this.selectedTemplate = 'generic';
        this.selectedFormat = 'Generic';
        this.cardAttachment = '';
        this.pageDim = false;
        return;
      }
    } else if (this.selectedTemplate === 'cornercard') {
      if (!this.lineData.hasOwnProperty('name_karteninhaber') || !this.lineData.hasOwnProperty('datum') || !this.lineData.hasOwnProperty('beschreibung') || !this.lineData.hasOwnProperty('belastung_eur') ||
        !this.lineData.hasOwnProperty('kartennummer')) {
        this._appService.notify({
          status: 1,
          msg: 'Uploaded file format doesnt match with selected format (' + this.selectedFormat + ')'
        });
        this.selectedTemplate = 'generic';
        this.selectedFormat = 'Generic';
        this.cardAttachment = '';
        this.pageDim = false;
        return;
      }
    } else if (this.selectedTemplate === 'ca') {
      if (!this.lineData.hasOwnProperty('transaction_date') || !this.lineData.hasOwnProperty('transaction_description') || !this.lineData.hasOwnProperty('amount') ||
        !this.lineData.hasOwnProperty('currency_code') || !this.lineData.hasOwnProperty('card_number')) {
        this._appService.notify({
          status: 1,
          msg: 'Uploaded file format doesnt match with selected format (' + this.selectedFormat + ')'
        });
        this.selectedTemplate = 'generic';
        this.selectedFormat = 'Generic';
        this.cardAttachment = '';
        this.pageDim = false;
        return;
      }
    } else if (this.selectedTemplate === 'us') {
      if (!this.lineData.hasOwnProperty('transaction_detail') || !this.lineData.hasOwnProperty('transaction_date') || !this.lineData.hasOwnProperty('amount')) {
        this._appService.notify({
          status: 1,
          msg: 'Uploaded file format doesnt match with selected format (' + this.selectedFormat + ')'
        });
        this.selectedTemplate = 'generic';
        this.selectedFormat = 'Generic';
        this.cardAttachment = '';
        this.pageDim = false;
        return;
      }
    } else if (this.selectedTemplate === 'ics') {
      if (!this.lineData.hasOwnProperty('name_cardholder') || !this.lineData.hasOwnProperty('transactiondate') || !this.lineData.hasOwnProperty('description') || !this.lineData.hasOwnProperty('amount') ||
        !this.lineData.hasOwnProperty('currency') || !this.lineData.hasOwnProperty('card_number')) {
        this._appService.notify({
          status: 1,
          msg: 'Uploaded file format doesnt match with selected format (' + this.selectedFormat + ')'
        });
        this.selectedTemplate = 'generic';
        this.selectedFormat = 'Generic';
        this.cardAttachment = '';
        this.pageDim = false;
        return;
      }
    }
    for (i = 0; i < this.viewData.length; i++) {
      this.lineData = this.viewData[i];
      if (this.selectedTemplate === 'ics') {
        this.selectedOrg = 'Netherlands';
        this.lineData.exchange_rate = this._formatService.formatNumber('1');
        this.lineData.receipt_currency_amount = this._formatService.formatNumber(this.lineData.amount);
        if (this.lineData.currency) {
          index = this.currencies.map(x =>
            x.currency_code
          ).indexOf(this.lineData.currency);
          if (index !== -1) {
            this.lineData.currency_code = this.lineData.currency;
          } else {
            this.lineData.currency_code = '';
          }
        } else {
          this.lineData.currency_code = this.selectedCurrency;
        }
        this.lineData.exchangerate = this.selectedCurrency === this.lineData.currency_code;
        this.lineData.creation_date = this.lineData.transactiondate ? this.convertDate(this.lineData.transactiondate, 'ics') : '';
        this.lineData.justification = this.lineData.description;
        this.lineData.employee_card_no = this.lineData.card_number || '';
      } else if (this.selectedTemplate === 'ca') {
        this.selectedOrg = 'Canada';
        this.lineData.currency_code = this.lineData.currency_code || this.selectedCurrency;
        this.lineData.exchange_rate = this.lineData.currency_code || this.selectedCurrency ? this._formatService.formatNumber('1') :
          this.lineData['Exchange Rate'] ? this.checkNumber(this.lineData['Exchange Rate']) : '1';
        this.lineData.justification = this.lineData.transaction_description || '';
        this.lineData.receipt_currency_amount = this.lineData.amount ? this.checkNumber(this.lineData.amount) : '';
        this.lineData.creation_date = this.lineData.transaction_date ? this.convertDate(this.lineData.transaction_date) : '';
        this.lineData.employee_card_no = this.lineData.card_number || '';
        this.lineData.exchangerate = this.selectedCurrency === this.lineData.currency_code;
      } else if (this.selectedTemplate === 'us') {
        this.selectedOrg = 'USA';
        this.lineData.currency_code = this.selectedCurrency;
        this.lineData.exchange_rate = this._formatService.formatNumber('1');
        this.lineData.receipt_currency_amount = this.lineData.amount ? this._formatService.formatNumber(this.lineData.amount) : '';
        this.lineData.creation_date = this.lineData.transaction_date ? this.convertDate(this.lineData.transaction_date, 'us') : '';
        this.lineData.justification = '';
        this.lineData.employee_card_no = '';
        this.lineData.exchangerate = this.selectedCurrency === this.lineData.currency_code;
      } else if (this.selectedTemplate === 'cornercard') {
        this.selectedOrg = 'Swiss';
        this.lineData.currency_code = 'EUR';
        this.lineData.exchange_rate = this._formatService.formatNumber('1');
        this.lineData.receipt_currency_amount = this.lineData.belastung_eur ? this._formatService.formatNumber(this.lineData.belastung_eur) : '';
        this.lineData.creation_date = this.lineData.datum ? this.convertDate(this.lineData.datum, 'ics') : '';
        this.lineData.justification = this.lineData.beschreibung || '';
        this.lineData.employee_card_no = this.lineData.kartennummer || '';
        this.lineData.exchangerate = this.selectedCurrency === this.lineData.currency_code;
      } else if (this.selectedTemplate === 'generic') {
        this.selectedOrg = 'cartasi';
        this.lineData.exchange_rate = this.lineData.currency_code === this.selectedCurrency ? '1' : this.lineData.exchange_rate || '';
        this.lineData.receipt_currency_amount = this.lineData.amount ? this.checkNumber(this.lineData.amount) : '';
        this.lineData.currency_code = this.lineData.currency_code || this.selectedCurrency;
        this.lineData.creation_date = this.lineData.date ? this.convertDate(this.lineData.date) : '';
        this.lineData.justification = this.lineData.description || '';
        this.lineData.employee_card_no = this.lineData.card_number || '';
        this.lineData.exchangerate = this.selectedCurrency === this.lineData.currency_code;
      } else if (this.selectedTemplate === 'cartasi') {
        this.selectedOrg = 'Italy';
        this.lineData.exchange_rate = !this.lineData.importo_movimento_in_valuta ? this._formatService.formatNumber('1') :
          !this.lineData.importo_spesa ? '' : this._formatService.formatNumber(this.lineData.importo_spesa / this.lineData.importo_movimento_in_valuta, 3);
        this.lineData.receipt_currency_amount = this.lineData.importo_movimento_in_valuta ? this._formatService.formatNumber(this.lineData.importo_movimento_in_valuta) :
          this._formatService.formatNumber(this.lineData.importo_spesa);
        if (this.lineData.codice_valuta) {
          index = this.currencies.map(x =>
            x.currency_code
          ).indexOf(this.lineData.codice_valuta);
          if (index !== -1) {
            this.lineData.currency_code = this.lineData.codice_valuta;
          } else {
            this.lineData.currency_code = '';
          }
        } else {
          this.lineData.currency_code = this.selectedCurrency;
        }
        this.lineData.creation_date = this.lineData.data_valuta ? this.convertDate(this.lineData.data_valuta, 'it') : '';
        this.lineData.justification = this.lineData.insegna || '';
        this.lineData.employee_card_no = this.lineData.codice_carta || '';
        this.lineData.exchangerate = this.selectedCurrency === this.lineData.currency_code;
      } else {
        this.cardAttachment = '';
        this._appService.notify({
          status: 1,
          msg: 'Upload a valid statement'
        });
        this.pageDim = false;
        return;
      }
    }
    if (this.invalidAmountFlag) {
      this._appService.notify({
        msg: 'Invalid number format. Enter Amount/Exchange Rate in ' + this.numberFormat + ' format',
        status: 1
      });
      this.invalidAmountFlag = false;
    }
    if (this.dateFlag) {
      this._appService.notify({
        msg: 'Invalid date format',
        status: 1
      });
      this.dateFlag = false;
    }
    this.validateCardNumber();
    this.getEmployeeNames();
    this.enterDetails = true;
    this.pageDim = false;
    setTimeout(() => {
      for (i = 0; i < this.viewData.length; i++) {
        new FooPicker({
          id: 'date' + this.viewData[i].id,
          dateFormat: this.pickerDate
        });
      }
    }, 100);
  }

}
