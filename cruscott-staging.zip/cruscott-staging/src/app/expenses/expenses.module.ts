import { NgModule } from '@angular/core';
import { ExpensesRoutingModule } from './expenses-routing.module';
import { ShareModule } from '../share/share.module';
import { ExpensesApprovalFlowComponent } from './approvalflow/approvalflow.component';
import { ExpenseCreateComponent } from './create/create.component';
import { ExpensesDashboardComponent } from './dashboard/dashboard.component';
import { ExpenseSummaryComponent } from './summary/summary.component';

@NgModule({
  declarations: [
    ExpensesApprovalFlowComponent,
    ExpenseCreateComponent,
    ExpensesDashboardComponent,
    ExpenseSummaryComponent
  ],
  imports: [
    ExpensesRoutingModule,
    ShareModule
  ]
})
export class ExpensesModule { }
