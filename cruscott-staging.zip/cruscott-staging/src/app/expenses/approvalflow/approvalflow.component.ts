import {
  Component, OnDestroy, OnInit, ViewChild
} from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { HttpService } from '../../globals/http.service';
import { TabletemplateComponent } from '../../globals/tabletemplate/tabletemplate.component';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { Settings } from '../../globals/tabletemplate/models/settings';

@Component({
  selector: 'app-approvalflow',
  templateUrl: './approvalflow.component.html',
  styleUrls: ['./approvalflow.component.scss'],
  providers: [OrderByPipe]
})
export class ExpensesApprovalFlowComponent implements OnInit, OnDestroy {
  @ViewChild(TabletemplateComponent) child: TabletemplateComponent;

  private _appService: AppService;
  private _cacheService: CacheService;
  private _httpService: HttpService;
  private _location: Location;
  private _orderBy: OrderByPipe;
  private _router: Router;
  private _window: any;

  allUsers: any[];
  deleteDialog: boolean;
  deleteFlowId: number;
  desc: boolean;
  expensesApprovalFlowDetails: any;
  expensesApprovalFlowSummary: any[];
  focusManager: boolean;
  focusUser: boolean;
  headerDetails: any[];
  isEdit: boolean;
  managerId: number;
  openApprovalFlowDialog: boolean;
  orgId: number;
  pageDim: boolean;
  persons: any[];
  predicate: string;
  searchQuery: string;
  showSpinner: boolean;
  subOrgChange: any;
  tableSettings: Settings;
  toggleFilter: (e?) => void;
  user: any;
  userId: number;
  usersList: any[];

  constructor(appService: AppService, cacheService: CacheService, httpService: HttpService, location: Location, orderBy: OrderByPipe, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._httpService = httpService;
    this._location = location;
    this._orderBy = orderBy;
    this._router = router;
    this._window = window;

    this.allUsers = [];
    this.deleteDialog = false;
    this.deleteFlowId = null;
    this.desc = false;
    this.expensesApprovalFlowDetails = {
      emp_id: '',
      mgr_id: ''
    };
    this.expensesApprovalFlowSummary = [];
    this.focusManager = true;
    this.focusUser = true;
    this.headerDetails = [
      { title: 'User Name', keyName: 'full_name', redirect: 'emp_id' },
      { title: 'Manager Name', keyName: 'manager_name' },
      { title: 'Org ID', keyName: 'default_org_id' }
    ];
    this.isEdit = false;
    this.managerId = null;
    this.openApprovalFlowDialog = false;
    this.orgId = null;
    this.pageDim = false;
    this.persons = [];
    this.predicate = 'full_name';
    this.showSpinner = false;
    this.subOrgChange = null;
    this.tableSettings = new Settings({ headers: [] });
    this.toggleFilter = this._appService.toggleFilter();
    this.user = '';
    this.userId = null;
    this.usersList = [];
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.orgId = this._cacheService.getOrgId();
        this._appService.scrollTop();
        this.setTableProperties();
        this.showSpinner = true;
        this.loadRequiredData();
        this.onOrgChange();
      }
    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  closeApprovalFlowDialog() {
    this.openApprovalFlowDialog = false;
    if (this.isEdit) {
      this.usersList.splice(
        this.allUsers.find((user) => user.access_to_oracle === this.expensesApprovalFlowDetails.emp_id), 1
      );
    }
  }

  // To create new approval flow
  createExpensesApprovalFlow() {
    this.isEdit = false;
    this.userId = null;
    this.managerId = null;
    this.expensesApprovalFlowDetails = {
      emp_id: '',
      mgr_id: ''
    };
    this.openDialog();
  }

  deleteExpensesApprovalFlow(empId): void {
    const endPoint = `/expenses/approvals/${this.orgId}/${empId}/`;
    this.pageDim = true;
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - deleteExpensesApprovalFlow' });
      } else {
        this._appService.notify({ status: data.status, msg: data.msg });
        this.deleteDialog = false;
        if (data.status === 0) {
          this.usersList = [...this.allUsers];
          this.loadExpensesApprovalFlowSummary();
        }
      }
    });
  }

  // export to excel sheet
  exportData() {
    this.toggleFilter();
    this.child.exportData('Expenses Approval Flow');
  }

  getManagerName(data) {
    let index;
    data.forEach((flow) => {
      const selectedFlow = flow;
      selectedFlow.displayConditions = { delete: true };
      index = this.persons.findIndex((person) => person.person_id === selectedFlow.mgr_id);
      if (index !== -1) {
        selectedFlow.manager_name = this.persons[index].full_name;
      }
    });
  }

  // View requested approval flow details
  goToExpensesApprovalFlow(event) {
    const flowDetails = this.expensesApprovalFlowSummary.find((flow) => flow.emp_id === event.value);
    this.isEdit = true;
    this.usersList.push(this.allUsers.find((user) => user.access_to_oracle === event.value));
    this.openDialog();
    this.expensesApprovalFlowDetails = flowDetails;
    this.managerId = flowDetails.mgr_id;
    this.userId = flowDetails.emp_id;
  }

  loadExpensesApprovalFlowSummary(): void {
    const endPoint = `/expenses/approvals/${this.orgId}/`;
    this._appService.scrollTop();
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadExpensesApprovalFlowSummary' });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.getManagerName(data);
        this.expensesApprovalFlowSummary = data;
        this.spliceExistingUsers();
      }
    });
  }

  loadPersons(): void {
    const endPoint = '/users/persons/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      let output = data;
      if (output === null || output === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadPersons()' });
      } else if (output.status === 1) {
        this._appService.notify({ status: 1, msg: output.msg });
      } else {
        output = this._orderBy.transform(output, 'full_name', false);
        this._cacheService.setPersonsData(output);
        this.persons = output;
        this.loadExpensesApprovalFlowSummary();
      }
    });
  }

  loadRequiredData() {
    this.loadUsers();
    if (!this._cacheService.getPersonsData()) {
      this.loadPersons();
    } else {
      this.persons = this._cacheService.getPersonsData();
      this.loadExpensesApprovalFlowSummary();
    }
  }

  loadUsers(): void {
    const endPoint = '/expenses/users/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      let output = data;
      if (output === null || output === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadUsers()' });
      } else if (output.status === 1) {
        this._appService.notify({ status: 1, msg: output.msg });
      } else {
        output = this._orderBy.transform(output, 'full_name', false);
        this.allUsers = [...output];
        this.usersList = output;
      }
    });
  }

  onOrgChange() {
    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      if (this.orgId === this._cacheService.getOrgId()) {
        return;
      }
      this._router.routeReuseStrategy.shouldReuseRoute = () => false;
      this._router.navigate(['expenses/approvalflow']);
    });
  }

  openDeleteDialog(event): void {
    this.deleteFlowId = event.emp_id;
    this.deleteDialog = true;
  }

  // Open approval flow dialog
  openDialog() {
    this.setFocus();
    this.openApprovalFlowDialog = true;
  }

  removeFocus() {
    this.focusManager = false;
    this.focusUser = false;
  }

  // Save approval flow details
  saveApprovalFlowDetails(): void {
    const endPoint = '/expenses/approvals/';
    if (this.validateApprovalFlowDetails()) {
      this.removeFocus();
      return;
    }
    const payload = this.savePayload();
    this._httpService.httpRequest(payload.method, endPoint, payload.req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - saveApprovalFlowDetails()' });
      } else {
        this._appService.notify({ status: data.status, msg: data.msg });
        this.openApprovalFlowDialog = false;
        if (data.status === 0) {
          this.loadExpensesApprovalFlowSummary();
        }
      }
    });
  }

  savePayload() {
    this.pageDim = true;
    this.expensesApprovalFlowDetails.emp_id = this.userId;
    this.expensesApprovalFlowDetails.mgr_id = this.managerId;
    const req = this.expensesApprovalFlowDetails;
    req.org_id = this.orgId;
    const method = !this.isEdit ? 'POST' : 'PUT';
    return { req, method };
  }

  selectAction(event): void {
    if (event.action === 'icon-trash2') {
      this.openDeleteDialog(event.data);
    }
  }

  setFocus() {
    this.focusManager = true;
    this.focusUser = true;
  }

  setTableProperties() {
    this.tableSettings = new Settings({
      headers: this.headerDetails,
      sortHeader: true,
      predicate: this.predicate,
      desc: this.desc,
      icons: [{ iconType: 'icon', iconStyle: 'icon-trash2', iconAction: 'delete' }]
    });
  }

  spliceExistingUsers() {
    let index;
    this.expensesApprovalFlowSummary.forEach((value) => {
      index = this.usersList.findIndex((user) => user.access_to_oracle === value.emp_id);
      if (index !== -1) {
        this.usersList.splice(index, 1);
      }
    });
  }

  validateApprovalFlowDetails() {
    this.setFocus();
    return (this.focusManager && !this.managerId) || (this.focusUser && !this.userId);
  }
}
