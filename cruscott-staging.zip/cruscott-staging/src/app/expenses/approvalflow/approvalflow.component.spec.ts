import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpensesApprovalFlowComponent } from './approvalflow.component';

describe('ExpensesApprovalFlowComponent', () => {
  let component: ExpensesApprovalFlowComponent;
  let fixture: ComponentFixture<ExpensesApprovalFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpensesApprovalFlowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpensesApprovalFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
