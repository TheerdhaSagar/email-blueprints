import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExpensesDashboardComponent } from './dashboard/dashboard.component';
import { ExpenseSummaryComponent } from './summary/summary.component';
import { ExpenseCreateComponent } from './create/create.component';
import { ExpensesApprovalFlowComponent } from './approvalflow/approvalflow.component';

const routes: Routes = [
  { path: 'dashboard', component: ExpensesDashboardComponent },
  { path: 'summary', component: ExpenseSummaryComponent },
  { path: 'manage', component: ExpenseCreateComponent },
  { path: 'approvalflow', component: ExpensesApprovalFlowComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class ExpensesRoutingModule { }
