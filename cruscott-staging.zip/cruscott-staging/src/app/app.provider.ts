import { TitleCasePipe, DatePipe } from '@angular/common';
import { REGION } from '@angular/fire/functions';
import { AppService } from './globals/app.service';
import { DataService } from './globals/data.service';
import { HttpService } from './globals/http.service';
import { CacheService } from './globals/cache.service';
import { FormatService } from './globals/format.service';
import { InvoiceService } from './globals/invoice.service';
import { ReportService } from './globals/report.service';
import { ExpenseService } from './globals/expense.service';
import { PaymentService } from './globals/payment.service';
import { ProductService } from './globals/product.service';
import { OnBoardService } from './globals/onboard.service';
import { RecipeService } from './globals/recipe.service';
import { OrderByPipe } from './globals/order-by.pipe';
import { FilterPipe } from './globals/filter.pipe';
import { FormArrayFilterPipe } from './globals/form-array-filter-pipe';
import { environment } from '../environments/environment';

export const providers = [
  AppService,
  CacheService,
  DataService,
  DatePipe,
  ExpenseService,
  FormatService,
  HttpService,
  InvoiceService,
  OnBoardService,
  PaymentService,
  ProductService,
  RecipeService,
  ReportService,
  OrderByPipe,
  FilterPipe,
  TitleCasePipe,
  FormArrayFilterPipe,
  { provide: REGION, useValue: environment.firebase.region },
];
