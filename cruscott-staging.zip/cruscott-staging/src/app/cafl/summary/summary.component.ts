import {
  Component, OnInit, OnDestroy, Injector
} from '@angular/core';
import { Location, TitleCasePipe } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { CaflApplicationService } from '../cafl-application.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { CaflApplication } from '../cafl-application';
import { Role } from '../../globals/role';
import { User } from '../../globals/user';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [OrderByPipe, TitleCasePipe]
})
export class CaflSummaryComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _caflApplicationService: CaflApplicationService = this.injector.get(CaflApplicationService);
  private _dataService: DataService = this.injector.get(DataService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _router: Router = this.injector.get(Router);
  private _titleCase: TitleCasePipe = this.injector.get(TitleCasePipe);
  private _window: any;

  allApplications: any;
  caflApplications: any;
  deleteCaflApplication: CaflApplication;
  deleteDialog: boolean;
  desc: boolean;
  orgCountries: any[];
  orgId: any;
  pageDim: boolean;
  predicate: any;
  requestStatus: any[];
  roles: Role;
  searchQuery: any;
  status: any;
  subOrgChange: Subscription;
  toggleFilter: (e?) => void;
  user: User;

  constructor(private injector: Injector) {
    this._window = window;

    this.allApplications = null;
    this.caflApplications = [];
    this.deleteDialog = false;
    this.desc = true;
    // Map org_ids to country
    this.orgCountries = [
      {
        org: 82,
        country: 'IT'
      },
      {
        org: 101,
        country: 'FR'
      },
      {
        org: 181,
        country: 'BE_FR'
      },
      {
        org: 83,
        country: 'DE'
      },
      {
        org: 181,
        country: 'BE'
      },
      {
        org: 181,
        country: 'BE_NL'
      },
      {
        org: 181,
        country: 'NL'
      },
      {
        org: 84,
        country: 'CH'
      },
      {
        org: 141,
        country: 'CA'
      }
    ];
    this.orgId = null;
    this.pageDim = null;
    this.predicate = 'pet_parent_id';
    this.requestStatus = [{
      label: 'Under Review',
      status: 'U'
    }, {
      label: 'Approved',
      status: 'A'
    }, {
      label: 'Rejected',
      status: 'R'
    }];
    this.roles = this._dataService.roles;
    this.status = 'U';
    this.subOrgChange = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
  }

  ngOnInit(): void {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this.pageDim = true;
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.orgId = this._cacheService.getOrgId();
        this.pageDim = true;
        this.loadCAFLApplications();

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.pageDim = true;
          this.orgId = this._cacheService.getOrgId();
          this.status = 'U';
          this.loadCAFLApplications();
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  applyFilter(): void {
    this.pageDim = true;
    let filterData = [...this.allApplications];
    this.toggleFilter();
    filterData = filterData.filter((x) => x.request_status === this.status);
    this.caflApplications = filterData;
    setTimeout(() => {
      this.pageDim = false;
    }, 500);
  }

  continueToDelete(): void {
    this.pageDim = true;
    const endPoint = '/donation/acaifl/pet_parent/delete/';
    this.deleteDialog = false;
    this._caflApplicationService.managePostRequests('POST',
      {
        pet_parent_id: this.deleteCaflApplication.pet_parent_id,
        email: this.deleteCaflApplication.email,
        user_id: this.user.user_id
      }, endPoint)
      .then((response) => {
        this._appService.notify(response);
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.loadCAFLApplications();
        this.deleteCaflApplication = null;
        this.deleteDialog = false;
      });
  }

  deleteApplication(cafl?): void {
    if (!this.deleteDialog) {
      this.deleteDialog = true;
      this.deleteCaflApplication = cafl;
    } else {
      this.continueToDelete();
    }
  }

  exportToExcel(): void {
    const data = this._orderBy.transform(this.caflApplications, this.predicate, this.desc);
    const tableData: any = {};
    const tmpData = [];
    let tmpObj;
    let status;
    for (let i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj['Application No.'] = { data: data[i].pet_parent_id };
      tmpObj['Pet Parent Name'] = { data: data[i].full_name };
      tmpObj['Pet Parent Address'] = { data: CaflSummaryComponent.formatAddress(data[i]) };
      tmpObj['Email Address '] = { data: data[i].email };
      tmpObj.Telephone = { data: data[i].telephone };
      tmpObj['Partner Association'] = { data: data[i].association_id ? 'Yes' : 'No' };
      tmpObj['Association Name'] = { data: this._titleCase.transform(data[i].association_name) };
      tmpObj.Town = { data: this._titleCase.transform(data[i].town) };
      tmpObj['Shop Name'] = { data: this._titleCase.transform(data[i].shop_name) };
      tmpObj['Shop Address'] = { data: this._titleCase.transform(data[i].shop_address) };
      tmpObj.City = { data: this._titleCase.transform(data[i].city) };
      tmpObj.Province = { data: this._titleCase.transform(data[i].province) };
      tmpObj['Pet Type'] = { data: this._titleCase.transform(data[i].pet_type) };
      tmpObj['Pet Age'] = { data: this._titleCase.transform(data[i].pet_age) };
      tmpObj['Pet Size'] = { data: this._titleCase.transform(data[i].pet_size) };
      if (this.status === 'A') {
        tmpObj['Approver Name'] = { data: this._titleCase.transform(data[i].approver_name) };
      }
      tmpObj['Created Date'] = { data: data[i].f_created_date };
      tmpObj['Adoption Date'] = { data: data[i].f_adoption_date };
      if (data[i].request_status === 'U') {
        status = 'Under Review';
      } else if (data[i].request_status === 'A') {
        status = 'Approved';
      } else if (data[i].request_status === 'R') {
        status = 'Rejected';
      }
      tmpObj['Request Status'] = { data: status };
      tmpObj['Coupon Number'] = { data: data[i].coupon_code };
      tmpObj.Comments = { data: data[i].approver_comments };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('CAFL Applications', tableData, 'export-data');
  }

  static formatAddress(adopterAddress): string {
    let formattedAddress = `${adopterAddress.address}, ${adopterAddress.postal_code}, `;
    formattedAddress += adopterAddress.city;
    formattedAddress += ` ${adopterAddress.province && adopterAddress.province !== '-' ? adopterAddress.province : ''}`;
    return formattedAddress;
  }

  loadCAFLApplications(): void {
    const endPoint = '/donation/acaifl/pet_parent/summary/';
    let result;
    let filterData;
    const reqObj = {
      countries: this.orgCountries.filter((x) => x.org === this.orgId).map((x) => x.country)
    };
    this.caflApplications = [];
    this.allApplications = [];
    if (!reqObj.countries.length) {
      this._appService.notify({ msg: 'No applications for selected country', status: 1 });
      this.pageDim = false;
      return;
    }
    this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadcaflApplications()' });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else {
          result = data;
          for (let i = 0; i < result.length; i++) {
            result[i].f_adoption_date = result[i].adoption_date ? this._formatService.formatDate(result[i].adoption_date) : '';
            result[i].f_created_date = this._formatService.formatDate(result[i].creation_date);
            result[i].creation_date_millis = this._formatService.dateInMillis(result[i].creation_date);
            result[i].request_status = result[i].is_approved === 'Y' ? 'A' : result[i].is_approved === 'N' ? 'R' : 'U';
            result[i].shop_name = result[i].shop_name ? result[i].shop_name.toLowerCase() : '-';
            result[i].association_name = result[i].association_name ? result[i].association_name.toLowerCase().replace(/\\/g, '') : '-';
            result[i].shop_address = result[i].shop_address ? result[i].shop_address.toLowerCase().replace(/\\/g, '') : '-';
            result[i].city = result[i].city ? result[i].city.toLowerCase() : '-';
            result[i].province = result[i].province ? result[i].province.toLowerCase() : '-';
            result[i].pet_type = result[i].pet_type ? result[i].pet_type.toLowerCase() : '-';
            result[i].pet_age = result[i].pet_age ? result[i].pet_age.toLowerCase() : '-';
            result[i].pet_size = result[i].pet_size ? result[i].pet_size.toLowerCase() : '-';
            result[i].approver_name = result[i].approver_name ? result[i].approver_name.toLowerCase() : '-';
            result[i].first_name = result[i].first_name ? result[i].first_name.toUpperCase() : '';
            result[i].last_name = result[i].last_name ? result[i].last_name.toUpperCase() : '';
            result[i].full_name = result[i].first_name + ' ' + result[i].last_name;
          }
          this.allApplications = result;
          filterData = [...this.allApplications];
          filterData = filterData.filter((x) => {
            return x.request_status === this.status;
          });
          this.caflApplications = filterData;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  sort(key): void {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = true;
    }
  }

  viewApplication(application): void {
    this._appService.petParentId = application.pet_parent_id;
    this._router.navigate(['cafl/application']);
  }
}
