export interface CaflSalesAgents {
  back_office_manager_email: string;
  back_office_manager_name: string;
  checked?: boolean;
  cust_account_id: number;
  email_address: string;
  name: string;
  sales_manager_email: string;
  sales_manager_name: string;
  salesrep_id: number;
  shop_email: string;
  user_description: string;
  user_name: string;
}

export interface CaflSalesAgentObject {
  filtered_by: string;
  sales_back_office: CaflSalesAgents[];
}
