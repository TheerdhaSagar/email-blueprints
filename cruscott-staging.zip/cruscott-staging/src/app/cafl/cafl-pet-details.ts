export interface CaflPetDetails {
  key: string;
  type?: string;
  value: string;
}
