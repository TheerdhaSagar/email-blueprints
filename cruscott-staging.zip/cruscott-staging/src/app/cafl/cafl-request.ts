import { CaflApplication } from './cafl-application';

export interface CaflRequest extends CaflApplication {
  address?: string;
  adoptme?: string;
  all_stores?: string;
  approved_by?: string;
  brand_code?: string;
  cc?: string;
  city?: string;
  comments?: string;
  country_code?: string;
  customer_id?: number;
  field_type?: string;
  new_email?: string;
  is_approved?: string;
  radius?: number;
  recent_update_user_id?: number;
  records?: number;
  send_email_to_shop?: string;
  shop_name?: string;
  shop_seq?: number;
  shop_type?: string;
  show_brand?: string;
  user_id?: number;
}
