import {
  Component, OnDestroy, OnInit, Injector
} from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import jQuery from 'jquery';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { CaflApplication } from '../cafl-application';
import { CaflApplicationService } from '../cafl-application.service';
import { CaflPetDetails } from '../cafl-pet-details';
import { CaflRequest } from '../cafl-request';
import { CaflSalesAgents } from '../cafl-sales-agents';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { Role } from '../../globals/role';
import { CommonService } from '../../globals/common.service';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.scss', '../../donation/donation.scss',
    '../../storelocator/storelocator.scss']
})
export class CaflApplicationComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _caflApplicationService: CaflApplicationService = this.injector.get(CaflApplicationService);
  private _commonService: CommonService = this.injector.get(CommonService);
  private _dataService: DataService = this.injector.get(DataService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location;
  private _orderBy: OrderByPipe;
  private _router: Router;
  _sce: DomSanitizer;
  private _window: any;

  agentsByCity: boolean;
  application: any;
  approvalStatus: any;
  associationName: string;
  associations: any;
  attachmentData: string;
  attachmentType: string;
  cc: string;
  ccNote: string;
  comment: any;
  dateFormat: string;
  deleteDialog: any;
  document: any;
  documentType: any;
  editAssociation: boolean;
  editAssociationDetails: boolean;
  editEmail: boolean;
  editObject: CaflRequest;
  editPetDetails: boolean;
  editShopDetails: boolean;
  editType: string;
  emailErrorMessage: string;
  fileData: any;
  focusCC: boolean;
  focuscomment: boolean;
  focusEdit: boolean;
  focusEmail: boolean;
  focusUpload: boolean;
  isOffline: boolean;
  orgId: any;
  pageDim: boolean;
  parentId: any;
  petAge: Array<CaflPetDetails>;
  petGender: Array<CaflPetDetails>;
  petSize: Array<CaflPetDetails>;
  petTypes: Array<CaflPetDetails>;
  randomString: string;
  roles: Role;
  salesAgents: Array<CaflSalesAgents>;
  selectedAgent: string;
  sendAutomaticEmail: string;
  shopUserEmail: string;
  shopUserName: string;
  shops: Array<CaflApplication>;
  showAttachment: boolean;
  showCommentDialog: boolean;
  subOrgChange: Subscription;
  uploadDialog: boolean;
  user: any;

  constructor(
      private injector: Injector, location: Location, orderBy: OrderByPipe,
      router: Router, sce: DomSanitizer
  ) {
    this._location = location;
    this._orderBy = orderBy;
    this._sce = sce;
    this._router = router;
    this._window = window;

    this.application = null;
    this.approvalStatus = null;
    this.associationName = null;
    this.associations = [];
    this.cc = '';
    this.comment = null;
    this.deleteDialog = null;
    this.document = null;
    this.documentType = null;
    this.editAssociation = false;
    this.editPetDetails = false;
    this.fileData = null;
    this.focusCC = true;
    this.focuscomment = true;
    this.focusUpload = false;
    this.orgId = this._dataService.orgId;
    this.pageDim = null;
    this.parentId = null;
    this.petAge = [
      {
        type: 'dog', key: 'Puppy', value: 'puppy'
      },
      {
        type: 'dog', key: 'Adult', value: 'adult'
      },
      {
        type: 'cat', key: 'Adult', value: 'adult'
      },
      {
        type: 'cat', key: 'Kitten', value: 'kitten'
      }
    ];
    this.petTypes = [
      {
        key: 'Cat', value: 'cat'
      },
      {
        key: 'Dog', value: 'dog'
      }
    ];
    this.petGender = [
      {
        key: 'Male',
        value: 'male',
      },
      {
        key: 'Female',
        value: 'female',
      },
    ];
    this.petSize = [
      {
        type: 'dog', key: 'Small', value: 'small'
      },
      {
        type: 'dog', key: 'Medium', value: 'medium'
      },
      {
        type: 'dog', key: 'Large', value: 'large'
      }
    ];
    this.randomString = '';
    this.roles = this._dataService.roles;
    this.salesAgents = [];
    this.selectedAgent = '';
    this.sendAutomaticEmail = 'N';
    this.showAttachment = false;
    this.subOrgChange = null;
    this.uploadDialog = false;
    this.user = null;
  }

  ngOnInit(): void {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.dateFormat = this.user.date_format;
        this.removeSuggestions = this.removeSuggestions.bind(this);

        if (this._appService.petParentId) {
          this.parentId = this._appService.petParentId;
          this._appService.petParentId = null;
          this.loadApplication();
        } else {
          this._router.navigate(['cafl/summary']);
        }

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.backToSummary();
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addCC(): void {
    const agentIndex = this.salesAgents.findIndex((agent) => agent.user_name === this.selectedAgent);
    this.salesAgents[agentIndex].checked = true;
    this.selectedAgent = '';
    this.getCCList();
  }

  attachmentPreview(attachment?): void {
    if (this.showAttachment) {
      this.showAttachment = false;
      this.attachmentData = '';
      this.attachmentType = '';
    } else {
      this.attachmentData = attachment.file_data;
      this.attachmentType = attachment.file_type;
      setTimeout(() => {
        this.showAttachment = true;
      }, 200);
    }
  }

  backToSummary(): void {
    this._router.navigate(['cafl/summary']);
  }

  changeStatus(): void {
    if (!this.comment && this.approvalStatus === 'R') {
      this.focuscomment = false;
      return;
    }
    const req = this.getRequestObject();
    this.pageDim = true;
    const endPoint = '/donation/acaifl/coupon/status/';
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      this.showCommentDialog = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: changeStatus()' });
      } else {
        this._appService.notify({ status: data.status, msg: data.msg });
        this._router.navigate(['cafl/summary']);
      }
    });
  }

  // Check if the option to Enter Non partner association is selected
  checkAssociationType(): void {
    setTimeout(() => {
      if (this.editObject.association_id && this.editObject.association_id.toString() === '-1') {
        this.editObject.association_id = null;
        this.editObject.association_name = !this.application.association_id ? this.application.association_name : '';
        this.editPetDetails = false;
        this.onEditAssociationDetails();
      }
    }, 200);
  }

  // Check the type of details user is trying to edit and show error message only for those fields
  checkEditType(type): boolean {
    return this.focusEdit && this.editType === type;
  }

  // When user cancel the action check the type of details and cancel that particular edit
  clearEdit(type?): void {
    this.editType = type || this.editType;
    this.editPetDetails = this.editType === 'pet_details' ? false : this.editPetDetails;
    this.editAssociationDetails = this.editType === 'pet_details' ? false : this.editAssociationDetails;
    this.editShopDetails = this.editType === 'shop_details' ? false : this.editShopDetails;
    this.editEmail = this.editType === 'email' ? false : this.editEmail;
    this.focusEdit = false;
    this.focusEmail = false;
    this.pageDim = false;
  }

  closeApprovalDialog(): void {
    this.selectedAgent = '';
    this.cc = '';
    this.sendAutomaticEmail = 'N';
    if (document.getElementById('select-cc')) {
      (document.getElementById('select-cc') as HTMLFormElement).value = '';
    }
    this.showCommentDialog = false;
    this.focuscomment = true;
    this.comment = null;
    for (let i = 0; i < this.salesAgents.length; i++) {
      this.salesAgents[i].checked = false;
    }
  }

  closeDialog(close): void {
    this.document = '';
    this.uploadDialog = !close;
    (document.getElementById('upload-doc') as HTMLFormElement).value = '';
    // if close is true clear warning
    this.focusUpload = close ? false : this.focusUpload;
    this.documentType = close ? '' : this.documentType;
  }

  // To copy the coupon code or coupon link
  copyLink(link, addRandomString?): void {
    const copyElement = document.createElement('textarea');
    copyElement.value = `${link}${addRandomString ? this.randomString : ''}`;
    document.body.appendChild(copyElement);
    copyElement.style.position = 'fixed';
    copyElement.select();
    document.execCommand('copy');
    document.body.removeChild(copyElement);
  }

  deleteAgent(agent): void {
    const salesAgent: CaflSalesAgents = agent;
    salesAgent.checked = false;
    this.selectedAgent = '';
    (document.getElementById('select-cc') as HTMLFormElement).value = '';
    this.getCCList();
  }

  deleteAttachment(attachment?): void {
    let endPoint;
    let fileId;
    let fileIndex;
    if (attachment) {
      this.deleteDialog = attachment;
    } else {
      fileId = this.deleteDialog.file_id;
      endPoint = `/donation/acaifl/pet_parent/${fileId}/`;
      fileIndex = this.application.files.findIndex(x => x.file_id === fileId);
      if (fileIndex !== -1) {
        this.application.files.splice(fileIndex, 1);
      }
      this.deleteDialog = null;
      this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({ msg: 'Server Error - deleteAttachment', status: 1 });
        } else {
          this._appService.notify({ status: data.status, msg: data.msg });
        }
      });
    }
  }

  downloadAttachment(caflAttachment, download): void {
    const attachment = caflAttachment;
    if (attachment.file_data) {
      if (download) {
        this.downloadFile(attachment);
      } else {
        this.attachmentPreview(attachment);
      }
    } else {
      const endPoint = `/donation/acaifl/files/${attachment.file_id}/`;
      this.pageDim = true;
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: downloadAttachment()' });
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
        } else if (data.file_data && data.file_data !== '') {
          attachment.file_data = data.file_data;
          if (download) {
            this.downloadFile(attachment);
          } else {
            this.attachmentPreview(attachment);
          }
        } else {
          this._appService.notify({ status: 1, msg: 'File is not found' });
        }
      });
    }
  }

  downloadFile(attachment): void {
    this.fileData = attachment.file_data;
    let blobFile = this._formatService.base64ToBlob(this.fileData, attachment.file_type),
        builder, blob, url, a;
    if (this._appService.isIE()) {
      builder = new MSBlobBuilder();
      builder.append(blobFile);

      blob = builder.getBlob(attachment.file_type);
      window.navigator.msSaveBlob(blob, attachment.file_name);
    } else {
      url = this._window.URL.createObjectURL(blobFile);
      a = document.createElement('a');
      document.body.appendChild(a);
      a.style.display = 'none';
      a.href = url;
      a.download = attachment.file_name;
      a.click();
    }
  }

  formatAddress(data): SafeHtml {
    let formattedAddress = `${data.address}<br/>${data.postal_code} ${data.city} `;
    if (data.province) {
      formattedAddress += `${data.province}<br/>`;
    }
    formattedAddress += (data.country === 'IT' ? 'ITALY' : data.country);
    formattedAddress += `<br/>Tel: ${data.telephone}`;
    return this._sce.bypassSecurityTrustHtml(formattedAddress.toUpperCase());
  }

  formatAgents(response): void {
    this.salesAgents = response.sales_back_office;
    this.agentsByCity = false;
    this.ccNote = '';
    this.cc = '';
    this.shopUserEmail = response.shop_email;
    this.shopUserName = response.shop_user_name;
    for (let i = 0; i < this.salesAgents.length; i++) {
      this.salesAgents[i].checked = false;
    }
    if (response.filtered_by === 'shop_id') {
      this.ccNote = 'Automatic email will be sent to client, ' +
        'selected sales agents and related back office managers in CC';
      this.ccNote += ' Select the sales agents from dropdown to send automatic email.';
    } else {
      this.agentsByCity = true;
      this.ccNote = 'Selected shop has no sales agents. Below are sales agents from that region. ' +
        'Select the sales agents to send automatic email';
    }
  }

  // If customer_id is null set shop_id to customer_id
  formatShopIds(): void {
    for (let i = 0; i < this.shops.length; i++) {
      this.shops[i].customer_id = this.shops[i].customer_id || this.shops[i].shop_id;
    }
  }

  getCCList(): void {
    this.cc = '';
    for (let i = 0; i < this.salesAgents.length; i++) {
      if (this.salesAgents[i].checked) {
        this.cc += this.salesAgents[i].email_address ?
          `${this.cc ? ', ' : ''}${this.salesAgents[i].email_address}` : '';
        this.cc += this.salesAgents[i].back_office_manager_email ?
          `${this.cc ? ', ' : ''}${this.salesAgents[i].back_office_manager_email}` : '';
        this.cc += this.salesAgents[i].sales_manager_email ?
          `${this.cc ? ', ' : ''}${this.salesAgents[i].sales_manager_email}` : '';
      }
    }
  }

  getRequestObject(): CaflRequest {
    if (this.sendAutomaticEmail === 'Y' && !this.agentsByCity) {
      this.cc = '';
      this.cc += `${this.cc ? ', ' : ''}${this.salesAgents[0].email_address}`;
      this.cc += `${this.cc ? ', ' : ''}${this.salesAgents[0].back_office_manager_email}`;
      this.cc += `${this.cc ? ', ' : ''}${this.salesAgents[0].sales_manager_email}`;
    }
    return {
      pet_parent_id: this.application.pet_parent_id,
      is_approved: this.approvalStatus === 'A' ? 'Y' : 'N',
      approved_by: this.user.user_id,
      comments: this.comment,
      user_id: this.user.user_id,
      cc: this.cc || '',
      send_email_to_shop: this.sendAutomaticEmail || 'N'
    };
  }

  // To validate the user selected shop and get name and address for the selected shop
  getShopNameAndAddress(): void {
    this.editType = 'shop_details';
    if (!this.editObject.shop_seq) {
      this.focusEdit = true;
      return;
    }
    this.editObject.field_type = 'SHOP ADDRESS';
    const selectedShop = this.shops.find((shop) => shop.shop_id === this.editObject.shop_seq);
    if (selectedShop) {
      this.editObject.shop_id = selectedShop.customer_id;
      this.editObject.shop_name = selectedShop.company;
      this.editObject.shop_address = selectedShop.address;
      this.editObject.shop_address += `, ${selectedShop.city}`;
      this.editObject.shop_address += `, ${selectedShop.country_name}`;
      this.editObject.shop_address += `, ${selectedShop.zip}`;
      this.updateShopDetails();
    } else {
      this.focusEdit = true;
      this.editObject.shop_id = null;
    }
  }

  initializeEditObject(): void {
    this.editObject = {
      pet_id: null,
      pet_name: '',
      pet_age: '',
      pet_size: '',
      pet_type: '',
      pet_gender: '',
      pet_dob: '',
      association_name: this.application.association_name,
      association_id: this.application.association_id || null,
      coupon_code: this.application.coupon_code || '',
      pet_parent_id: this.application.pet_parent_id,
      shop_id: this.application.shop_id || null,
      field_type: '',
      email: this.application.email,
      shop_type: this.isOnline() ? 'ONLINE' : 'OFFLINE',
      contact_by: this.application.contact_by || '',
      new_email: this.application.email,
      recent_update_user_id: this.user.user_id
    };
  }

  isOnline(): boolean {
    return !this.application.shop_id && (this.application.country !== 'FR' ||
      (this.application.country === 'FR' && this.application.contact_customer === 'N'));
  }

  loadAgents(): void {
    if ((this.roles.UICouponApprover || this.roles.isAdmin) &&
        !this.application.is_approved && this.application.shop_id && this.application.country === 'IT') {
      this.salesAgents = [];
      const requestObject = {
        customer_id: this.application.shop_id,
        address: this.application.shop_address,
        city: this.application.city,
        shop_name: this.application.shop_name
      };
      this._caflApplicationService.loadAgents('/donation/sales_agents/', requestObject)
        .then((response) => {
          this.formatAgents(response);
        }).catch((error) => {
          this._appService.notify(error);
        }).finally(() => {
          this.pageDim = false;
        });
    }
  }

  loadApplication(): void {
    const endPoint = `/donation/acaifl/pet_parent/${this.parentId}/`;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadApplication()' });
          this.backToSummary();
        } else if (data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
          this.backToSummary();
        } else {
          this.application = data[0];
          this.loadAssociations();
          this.loadShops();
          this.initializeEditObject();
          this.loadAgents();
          this.editObject.town = this.application.town || null;
          this.editObject.shop_seq = this.application.shop_id;
          this.application.f_created_date = this._formatService.formatDate(this.application.creation_date);
          this.application.formatted_address = this.formatAddress(this.application);
          this.application.association_name = this.application.association_name ?
            this.application.association_name.replace(/\\/g, '') : '';
          this.application.shop_name = this.application.shop_name ?
            this.application.shop_name.replace(/\\/g, '') : '';
          this.application.association_city = this.application.pets[0].association_city;
          this.application.association_province = this.application.pets[0].association_province;
          this.application.association_phone = this.application.pets[0].association_phone;
          this.editObject.association_city = this.application.association_city;
          this.editObject.association_province = this.application.association_province;
          this.editObject.association_phone = this.application.association_phone;

          for (let i = 0; i < this.application.pets.length; i++) {
            this.application.pets[i].f_adoption_date =
              this._formatService.formatDate(this.application.pets[i].adoption_date);
            this.application.pets[
              i
            ].f_pet_dob = this._formatService.formatDate(
              this.application.pets[i].pet_dob
            );
          }
          this.isOffline = this.application.shop_id || this.application.country === 'FR';

          // To get coupon pdf link from oracle or hubspot
          this.application.coupon_pdf = this.application.o_coupon_pdf ||
            this.application.h_coupon_pdf || this.application.coupon_pdf;
          this.application.coupon_pdf_additional = this.application.o_coupon_pdf_additional ||
            this.application.h_coupon_pdf_additional || this.application.coupon_pdf_additional;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: `<pre>${e.stack}</pre>` });
      }
    });
  }

  loadAssociations(): void {
    const endPoint = '/donation/associations/search/';
    const country = this.application.country === 'BE' ||
      this.application.country === 'BE_NL' ||
      this.application.country === 'BE_FR' ? 'BE' : this.application.country;
    const reqObj = {
      zip_code: '',
      address: '',
      country,
      city: '',
      radius: 10000,
      records: 10000
    };
    this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadAssociations()', status: 1 });
      } else if (data.status === 1 || data.status === 'ERROR') {
        this._appService.notify({ msg: data.msg, status: 1 });
      } else {
        this.associations = this._orderBy.transform(data.data, 'association_name', false);
        this.associations.unshift({ association_name: 'Enter Non Partner Association', association_id: -1 });
      }
    });
  }

  // load shops by taking country from the cafl application
  loadShops(): void {
    const endPoint = '/wordpress/search/';
    const requestObject: CaflRequest = {
      country_code: this.application.country === 'BE_NL' ||
      this.application.country === 'BE_FR' ? 'BE' : this.application.country,
      brand_code: '',
      radius: 10000,
      records: 10000,
      all_stores: 'Y',
      show_brand: 'N',
      adoptme: 'Y'
    };
    this.shops = [];
    this._caflApplicationService.loadShopDetails('POST', requestObject, endPoint)
      .then((response) => {
        this.shops = response;
        this.formatShopIds();
      }).catch((error) => {
        this._appService.notify(error);
      });
  }

  onEditAssociationDetails(): void {
    if (this.application.pets.length) {
      this.editObject.pet_id = this.application.pets[0].pet_id;
      this.editObject.pet_name = this.application.pets[0].pet_name;
      this.editObject.pet_age = this.application.pets[0].pet_age;
      this.editObject.pet_size = this.application.pets[0].pet_size;
      this.editObject.pet_type = this.application.pets[0].pet_type;
      this.editObject.pet_gender = this.application.pets[0].pet_gender;
      this.editObject.f_pet_dob = this.application.pets[0].f_pet_dob;
    }
    this.editType = 'pet_details';
    this.focusEdit = false;
    this.editAssociationDetails = true;
  }

  onEditEmail(): void {
    this.editObject.new_email = this.application.email;
    this.focusEdit = false;
    this.editEmail = true;
    this.editType = 'email';
  }

  onEditPetDetails(pet): void {
    this.editType = 'pet_details';
    this.editObject.pet_id = pet.pet_id;
    this.editObject.pet_name = pet.pet_name;
    this.editObject.pet_age = pet.pet_age;
    this.editObject.pet_size = pet.pet_size;
    this.editObject.pet_type = pet.pet_type;
    this.editObject.pet_gender = pet.pet_gender;
    this.editObject.pet_dob = pet.pet_dob;
    this.editObject.f_pet_dob = pet.f_pet_dob;
    if (this.application.association_id) {
      this.editObject.association_id = parseInt(this.application.association_id, 10);
    } else {
      (document.getElementById('association-name') as HTMLFormElement).value = this.application.association_name;
    }
    this.editObject.association_name = this.application.association_name;
    this.editObject.association_id = this.application.association_id || null;
    this.editPetDetails = true;
  }

  onEditShopDetails(): void {
    this.editType = 'shop_details';
    this.focusEdit = false;
    this.editObject.shop_id = this.application.shop_id;
    const caflShop = this.shops.find((shop) => shop.customer_id === this.application.shop_id);
    if (caflShop) {
      this.editObject.shop_seq = caflShop.shop_id;
    }
    setTimeout(() => {
      (document.getElementById('shops') as HTMLFormElement).value = this.application.shop_name;
    }, 100);
    this.editShopDetails = true;
  }

  openUploadDialog(): void {
    this.uploadDialog = true;
    this.documentType = '';
    (document.getElementById('upload-doc') as HTMLFormElement).value = '';
  }

  removeSuggestions(): void {
    setTimeout(() => {
      const autoSuggestionsClass = '.fd-suggestions';
      if (jQuery(document).find(autoSuggestionsClass)[0]) {
        jQuery(autoSuggestionsClass)[0].remove();
      }
    }, 200);
    this.checkAssociationType();
  }

  resendCoupon(): void {
    this.pageDim = true;
    const endPoint = '/donation/coupon/resend/';
    this._caflApplicationService.managePostRequests('POST', this.editObject, endPoint)
      .then((response) => {
        this._appService.notify((response));
        if (this.editObject.shop_type === 'ONLINE') {
          this.application.shop_address = response.coupon_link;
          this.application.coupon_code = response.coupon_code;
          this.editObject.coupon_code = response.coupon_code;
        } else {
          this.application.coupon_pdf = response.coupon_pdf;
          // Append some random string to open new pdf every time resend coupon is clicked
          // If random string is not appended the pdf in system cache will be loaded
          this.randomString = `?reload=${this._appService.getRandomNum(1000)}`;
        }
      }).catch((error) => {
        this._appService.notify((error));
      }).finally(() => {
        this.pageDim = false;
      });
  }

  updateEmail(): void {
    this.pageDim = true;
    this.editObject.field_type = 'EMAIL';
    this._caflApplicationService.managePostRequests('POST', this.editObject)
      .then((response) => {
        this._appService.notify(response);
        this.application.email = this.editObject.new_email;
        this.editObject.email = this.editObject.new_email;
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.clearEdit();
      });
  }

  updatePetDetails(data): void {
    const pet = data;
    this.pageDim = true;
    this.editObject.field_type = 'PET DETAILS';
    this.editObject.pet_dob = this.editObject.f_pet_dob ? this._formatService.parseDate(this.editObject.f_pet_dob) : null;
    this.editObject.association_id = this.editObject.association_id.toString() ===
          this.editObject.association_name.toString() ? null : this.editObject.association_id;
    this._caflApplicationService.managePostRequests('POST', this.editObject)
      .then((response) => {
        this._appService.notify(response);
        pet.pet_name = this.editObject.pet_name;
        pet.pet_age = this.editObject.pet_age;
        pet.pet_size = this.editObject.pet_size || '';
        pet.pet_type = this.editObject.pet_type;
        pet.pet_gender = this.editObject.pet_gender;
        pet.pet_dob = this.editObject.pet_dob;
        pet.f_pet_dob = this.editObject.f_pet_dob;
        this.application.association_name = this.editObject.association_name;
        this.application.association_id = this.editObject.association_id || null;
        this.application.town = this.editObject.town;
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.clearEdit();
      });
  }

  updateShopDetails(): void {
    this.pageDim = true;
    // If shop is from FR, BE the stores will not have customer_id. So set 90269 as default
    this.editObject.shop_id = this.application.country === 'FR' || this.application.country === 'BE_FR' ||
      this.application.country === 'BE_NL' || this.application.country === 'BE' ? 90269 : this.editObject.shop_id;
    this._caflApplicationService.managePostRequests('POST', this.editObject)
      .then((response) => {
        this._appService.notify(response);
        this.application.shop_id = this.editObject.shop_id;
        this.application.shop_name = this.editObject.shop_name;
        this.application.shop_address = this.editObject.shop_address;
        this.loadAgents();
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.clearEdit();
      });
  }

  uploadDocument(): void {
    let reqObj;
    if (this.document && this.documentType) {
      this.focusUpload = false;
      const endPoint = '/donation/acaifl/files/';
      reqObj = {
        reference_id: this.application.pet_parent_id,
        reference_type: 'PET',
        attachment_type: this.documentType,
        file_type: this.document.filetype,
        file_data: this.document.base64,
        file_name: this.document.filename,
        user_id: this.user.user_id
      };
      this.focusUpload = false;
      this.uploadDialog = false;
      this.documentType = null;
      this.pageDim = true;
      this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({ msg: 'Server Error - uploadDocument', status: 1 });
        } else {
          this._appService.notify({ msg: data.msg, status: data.status });
          this.document = null;
          (document.getElementById('upload-doc') as HTMLFormElement).value = '';
          if (data.status === 0) {
            reqObj.file_id = data.file_id;
            this.application.files.push(reqObj);
          }
        }
        this.pageDim = false;
      });
    } else {
      this.focusUpload = true;
    }
  }

  validateCCEmail(): void {
    this.focusCC = !(this.cc && !this._commonService.checkCCOrBCCDetails(this.cc));
  }

  // Get association name from id
  validateAssociation(): boolean {
    const associationName = (document.getElementById('association-name') as HTMLFormElement).value;
    if (!associationName) {
      this.editObject.association_name = '';
      this.editObject.association_id = null;
      return false;
    }
    const association = this.associations.find((assoc) => assoc.association_name === associationName);
    this.editObject.association_name = associationName;
    this.editObject.association_id = association ? association.association_id : associationName;
    return true;
  }

  validateNonPartnerAssociation(): void {
    if (!this.editObject.association_name || !this.editObject.town) {
      this.focusEdit = true;
    } else {
      this.editObject.field_type = 'PET DETAILS';
      this._caflApplicationService.managePostRequests('POST', this.editObject)
        .then((response) => {
          this._appService.notify(response);
          this.application.association_name = this.editObject.association_name;
          this.application.association_id = this.editObject.association_id || null;
          this.application.town = this.editObject.town;
        }).catch((error) => {
          this._appService.notify(error);
        }).finally(() => {
          this.clearEdit();
        });
    }
  }

  validatePetDetails(data): void {
    this.editType = 'pet_details';
    if (!this.editObject.pet_name || !this.editObject.pet_type || !this.editObject.pet_age ||
      (this.editObject.pet_type === 'dog' && !this.editObject.pet_size) || !this.validateAssociation()) {
      this.focusEdit = true;
    } else {
      this.updatePetDetails(data);
    }
  }

  // Clear pet age and pet size details if pet type is changed
  validatePetSize(): void {
    this.editObject.pet_size = '';
    this.editObject.pet_age = this.editObject.pet_age === 'adult' ? this.editObject.pet_age : '';
  }

  validateEmail(): void {
    this.editType = 'email';
    if (this.editObject.new_email && this._appService.validateEmail(this.editObject.new_email)) {
      this.updateEmail();
    } else {
      this.focusEmail = true;
      this.focusEdit = true;
      this.emailErrorMessage = this.editObject.new_email ? 'Enter valid Email' : 'Email is required';
    }
  }
}
