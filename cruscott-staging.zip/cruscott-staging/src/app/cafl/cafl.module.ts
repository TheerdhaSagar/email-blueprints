import { NgModule } from '@angular/core';
import { CaflRoutingModule } from './cafl-routing.module';
import { ShareModule } from '../share/share.module';
import { CaflSummaryComponent } from './summary/summary.component';
import { CaflApplicationComponent } from './application/application.component';

@NgModule({
  declarations: [
    CaflApplicationComponent,
    CaflSummaryComponent
  ],
  imports: [
    CaflRoutingModule,
    ShareModule
  ]
})
export class CaflModule { }
