import { TestBed } from '@angular/core/testing';

import { CaflApplicationService } from './cafl-application.service';

describe('CaflApplicationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CaflApplicationService = TestBed.get(CaflApplicationService);
    expect(service).toBeTruthy();
  });
});
