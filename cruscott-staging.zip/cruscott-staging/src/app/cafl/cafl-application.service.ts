import { Injectable, Injector } from '@angular/core';
import { HttpService } from '../globals/http.service';
import { CaflApplication } from './cafl-application';
import { ServerError } from '../globals/server.error';
import { APIError } from '../globals/api.error';
import { CaflRequest } from './cafl-request';
import { CaflSalesAgentObject } from './cafl-sales-agents';

@Injectable({
  providedIn: 'root'
})
export class CaflApplicationService {
  private readonly URL_PREFIX;
  private _httpService: HttpService = this.injector.get(HttpService);

  constructor(private injector: Injector) {
    this.URL_PREFIX = '/donation';
  }

  managePostRequests(method: string, requestObject: CaflApplication & { user_id?: number }, endPoint?: string):
    Promise<CaflApplication> {
    return new Promise((resolve, reject) => {
      const api = endPoint || `${this.URL_PREFIX}/acaifl/fields/`;
      this._httpService.httpRequest(method, api, requestObject, (response) => {
        if (!response) {
          reject(new ServerError('managePostRequests'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  loadAgents(endPoint: string, requestObject: CaflRequest): Promise<CaflSalesAgentObject> {
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', endPoint, requestObject, (data) => {
        if (!data) {
          reject(new ServerError('loadAgents'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }

  loadShopDetails(method: string, requestObject: CaflRequest, endPoint: string): Promise<CaflApplication[]> {
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', endPoint, requestObject, (response) => {
        if (!response) {
          reject(new ServerError('managePostRequests'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response.stores);
        }
      });
    });
  }
}
