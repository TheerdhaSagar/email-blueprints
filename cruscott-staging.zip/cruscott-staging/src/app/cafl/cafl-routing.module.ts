import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CaflSummaryComponent } from './summary/summary.component';
import { CaflApplicationComponent } from './application/application.component';

const routes: Routes = [
  { path: 'summary', component: CaflSummaryComponent },
  { path: 'application', component: CaflApplicationComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CaflRoutingModule { }
