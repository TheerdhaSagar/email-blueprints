import { Injectable, Injector } from '@angular/core';
import { APIError } from 'src/app/globals/api.error';
import { HttpService } from 'src/app/globals/http.service';
import { ServerError } from 'src/app/globals/server.error';
import { ChewyLabel } from '../models/chewy-label';

@Injectable({
  providedIn: 'root',
})
export class ChewyShippingService {
  private _httpService: HttpService = this.injector.get(HttpService);

  constructor(private injector: Injector) {}

  downloadChewyLabel(
    requestData: ChewyLabel
  ): Promise<{ file_data: string; file_name: string; file_type?: string }> {
    const endPoint = '/dsv/chewy/label/';
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        'POST',
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('Server Error: downloadChewyLabel()'));
          } else if (response.status && response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  loadChewy(orderId?: number): Promise<ChewyLabel[]> {
    let endPoint = '/dsv/chewy/';
    if (orderId) {
      endPoint += `${orderId}/`;
    }
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('Server Error: loadChewy()'));
        } else if (response.status && response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response.chewy_labels);
        }
      });
    });
  }
}
