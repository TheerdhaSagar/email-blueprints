import { Injectable, Injector } from '@angular/core';
import { APIError } from '../../globals/api.error';
import { HttpService } from '../../globals/http.service';
import { ServerError } from '../../globals/server.error';
import { Response } from '../../globals/response';
import { DsvHistory } from '../models/dsv-history';
import { DsvInvoice } from '../models/dsv-invoice';
import { DSVUploadResponse } from '../models/dsv-upload-response';
import { DsvSupplier } from '../models/dsv-supplier';
import { DSVUpload } from '../models/dsv-upload';

@Injectable({
  providedIn: 'root',
})
export class DsvService {
  private _httpService = this.injector.get(HttpService);

  readonly URL_PREFIX = '/dsv';

  constructor(private injector: Injector) {}

  // for deleting the imported invoice details
  deleteInvoiceDetails(dsvHeaderId: number): Promise<Response> {
    const endPoint = `${this.URL_PREFIX}/invoice/${dsvHeaderId}/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - deleteInvoiceDetails()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }

  downloadInvoiceCSV(req): Promise<Response & { file_name?: string }> {
    const endPoint = `${this.URL_PREFIX}/export/?type=txt`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', endPoint, req, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - downloadInvoiceCSV()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }

  // getting summary details in DSV
  getDsvSummary(): Promise<DsvInvoice[]> {
    const endPoint = `${this.URL_PREFIX}/invoice/summary/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - getDsvSummary()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data.invoice_details);
        }
      });
    });
  }

  // getting suppliers details in DSV
  getDsvSuppliers(): Promise<DsvSupplier[]> {
    const endPoint = `${this.URL_PREFIX}/suppliers/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - getDsvSuppliers()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data.suppliers);
        }
      });
    });
  }

  // get single invoice details with items
  getInvoiceDetails(dsvHeaderId: number): Promise<DsvInvoice> {
    const endPoint = `${this.URL_PREFIX}/invoice/${dsvHeaderId}/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - getInvoiceDetails()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data.invoice_details);
        }
      });
    });
  }

  // import excel sheet into db by parsing the excel data
  importExcelToDb(requestObj: DSVUpload): Promise<DSVUploadResponse> {
    const endPoint = `${this.URL_PREFIX}/import/excel/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', endPoint, requestObj, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - importExcelToDb()'));
        } else if (data.status === 1) {
          reject(new APIError(data.sheet_msg || data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }

  // insert history of when the user u=is downloading the csv file
  insertHistory(requestObj: DsvHistory): Promise<Response> {
    const endPoint = `${this.URL_PREFIX}/invoice/history/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('POST', endPoint, requestObj, (data) => {
        if (!data) {
          reject(new ServerError('SERVER ERROR - insertHistory()'));
        } else if (data.status === 1) {
          reject(new APIError(data.msg));
        } else {
          resolve(data);
        }
      });
    });
  }
}
