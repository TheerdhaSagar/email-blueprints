import { TestBed } from '@angular/core/testing';

import { ChewyShippingService } from './chewy-shipping.service';

describe('ChewyShippingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ChewyShippingService = TestBed.get(ChewyShippingService);
    expect(service).toBeTruthy();
  });
});
