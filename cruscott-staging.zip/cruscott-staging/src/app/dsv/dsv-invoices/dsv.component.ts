import {
  Component,
  ElementRef,
  Injector,
  OnInit,
  ViewChild,
} from '@angular/core';
import * as _lodash from 'lodash';
import { Router } from '@angular/router';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { Settings } from '../../globals/tabletemplate/models/settings';
import { User } from '../../globals/user';
import { DsvInvoice } from '../models/dsv-invoice';
import { DsvService } from '../service/dsv.service';
import { ColumnSettings } from '../../globals/tabletemplate/models/layout';
import { DSVUpload } from '../models/dsv-upload';
import { DSVUploadResponse } from '../models/dsv-upload-response';
import { DsvSupplier } from '../models/dsv-supplier';

@Component({
  selector: 'app-dsv',
  templateUrl: './dsv.component.html',
  styleUrls: ['./dsv.component.scss'],
})
export class DsvComponent implements OnInit {
  @ViewChild('fileUpload') fileUpload: ElementRef;
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dsvService: DsvService = this.injector.get(DsvService);
  private _router: Router = this.injector.get(Router);

  deleteHeaderDetails: DsvInvoice;
  desc: boolean;
  dsvInvoiceDetails: DsvInvoice;
  dsvInvoiceSummary: DsvInvoice[];
  duplicateInvoiceDetails: DSVUploadResponse;
  excelFile: { base64: string; filename: string };
  focusExcelError: boolean;
  focusSupplier: boolean;
  historyInvoiceSettings: Settings;
  invoiceTableSettings: Settings;
  itemsInvoiceSettings: Settings;
  pageDim: boolean;
  searchQuery: string;
  selectedSupplier = '';
  showExcelDialog: boolean;
  showDownloadDialog: boolean;
  showInvoiceDialog: boolean;
  showSpinner: boolean;
  suppliers: DsvSupplier[] = [];
  toggleFilter: (e?) => void;
  user: User;

  constructor(private injector: Injector) {
    this.desc = false;
    this.dsvInvoiceSummary = [];
    this.duplicateInvoiceDetails = null;
    this.excelFile = null;
    this.showSpinner = false;
    this.focusExcelError = false;
    this.focusSupplier = false;
    this.showInvoiceDialog = false;
    this.showDownloadDialog = false;
    this.toggleFilter = this._appService.toggleFilter();
    this.initializeTableSettings();
    this.initializeItemsTableSettings();
    this.initializeHistorySettings();
  }

  static initializeTableHeaderDetails(): Array<ColumnSettings> {
    return [
      { title: 'Invoice #', keyName: 'invoice_no', redirect: 'dsv_header_id' },
      { title: 'Container #', keyName: 'container_no' },
      {
        title: 'Net Weight',
        keyName: 'net_weight',
        styles: { format: 'numberformat' },
      },
      {
        title: 'Gross Weight',
        keyName: 'gross_weight',
        styles: { format: 'numberformat' },
      },
      { title: 'UOM', keyName: 'uom' },
      {
        title: 'Total Cartons',
        keyName: 'total_cartons',
        styles: { format: 'numberformat' },
      },
      {
        title: 'Created On',
        keyName: 'created_date',
        styles: { format: 'date' },
      },
      {
        title: 'Last Downloaded',
        keyName: 'last_downloaded_on',
        styles: { format: 'date' },
      },
      {
        title: 'Uploaded File',
        keyName: 'uploaded_filename',
        styles: { 'word-break': 'break-all' },
      },
      { title: 'Downloaded File', keyName: 'exported_filename' },
    ];
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.pageDim = true;
        this.loadSuppliers();
        this.loadSummary();
      }
    });
  }

  closeExcelDialog(): void {
    this.showExcelDialog = false;
    this.excelFile = null;
    if (this.fileUpload) {
      this.fileUpload.nativeElement.value = null;
    }
    this.duplicateInvoiceDetails = null;
    this.selectedSupplier = null;
  }

  deleteDSVInvoiceDetails(): void {
    this.pageDim = true;
    this._dsvService
      .deleteInvoiceDetails(this.deleteHeaderDetails.dsv_header_id)
      .then((data) => {
        this._appService.notify(data);
        this.loadSummary();
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.pageDim = false;
        this.deleteHeaderDetails = null;
      });
  }

  downloadCSVFile(): void {
    this.pageDim = true;
    const req = {
      header_id: this.dsvInvoiceDetails.dsv_header_id,
      created_id: this.user.user_id,
      description: `${this.user.user_description} has downloaded excel with filename`,
    };
    this._dsvService
      .downloadInvoiceCSV(req)
      .then((response) => {
        this.parseDownloadedFile(response.file_name);
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
        this.showDownloadDialog = false;
      });
  }

  editInvoiceDetails(headerDetails): void {
    this.pageDim = true;
    this.loadDsvInvoiceDetails(headerDetails.value);
  }

  initializeHistorySettings(): void {
    this.historyInvoiceSettings = new Settings({
      headers: [
        {
          title: 'Last Downloaded On',
          keyName: 'created_date',
          styles: { format: 'date' },
        },
        { title: 'Description', keyName: 'description' },
      ],
      sortHeader: false,
      predicate: 'dsv_history_id',
      desc: true,
    });
  }

  initializeItemsTableSettings(): void {
    this.itemsInvoiceSettings = new Settings({
      headers: [
        {
          title: 'Item #',
          keyName: 'item_code',
          styles: { 'min-width': '60px' },
        },
        {
          title: 'Codes #',
          keyName: 'codes',
          styles: { 'min-width': '200px' },
        },
        {
          title: 'Cartons',
          keyName: 'cartons',
          styles: { 'min-width': '60px' },
        },
        { title: 'Expiry Date', keyName: 'expiry_date' },
        {
          title: 'Batch Number',
          keyName: 'batch_number',
          styles: { 'min-width': '60px' },
        },
      ],
      sortHeader: true,
      predicate: 'buyer_id',
      checkboxes: false,
      desc: false,
    });
  }

  initializeTableSettings(): void {
    this.invoiceTableSettings = new Settings({
      headers: DsvComponent.initializeTableHeaderDetails(),
      sortHeader: true,
      icons: [
        { iconType: 'icon', iconStyle: 'icon-upload2', iconAction: 'export' },
        { iconType: 'icon', iconStyle: 'icon-trash2', iconAction: 'delete' },
      ],
      predicate: 'dsv_header_id',
      desc: this.desc,
    });
  }

  loadDsvInvoiceDetails(headerId): void {
    this._dsvService
      .getInvoiceDetails(headerId)
      .then((data) => {
        this.dsvInvoiceDetails = data;
        this.showInvoiceDialog = true;
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  loadSummary(): void {
    this._dsvService
      .getDsvSummary()
      .then((data) => {
        this.dsvInvoiceSummary = data;
        this.dsvInvoiceSummary.forEach((invoiceDetails) => {
          const invoice = invoiceDetails;
          invoice.expand = false;
          invoice.displayConditions = { export: true, delete: true };
          invoice.items = [];
          invoice.history = [];
        });
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  loadSuppliers(): void {
    this._dsvService
      .getDsvSuppliers()
      .then((data) => {
        this.suppliers = data;
      })
      .catch((err) => {
        this._appService.notify(err);
      });
  }

  openDeleteDialog(headerDetails): void {
    this.deleteHeaderDetails = headerDetails;
  }

  openExcelDialog(): void {
    this.excelFile = null;
    this.showExcelDialog = true;
    this.selectedSupplier = null;
  }

  openDownloadDialog(data): void {
    this.dsvInvoiceDetails = data;
    if (data.exported_filename) {
      this.showDownloadDialog = true;
    } else {
      this.downloadCSVFile();
    }
  }

  parseDownloadedFile(fileName): void {
    this.dsvInvoiceDetails.exported_filename = fileName;
    this.dsvInvoiceSummary.find(
      (invoice) =>
        invoice.dsv_header_id === this.dsvInvoiceDetails.dsv_header_id
    ).exported_filename = fileName;
    this._appService.notify({ status: 0, msg: 'File exported successfully' });
    this.loadSummary();
  }

  parseUploadResponse(data): void {
    if (data.msg) {
      if (data.cans_error) {
        data.cans_error.forEach((invoice) => {
          if (invoice.cans_error.length) {
            const canItems = invoice.cans_error.filter(
              (item, index, self) => self.indexOf(item) === index
            );
            data.msg += `\nInvoice:${
              invoice.invoice_no
            } failed to convert cans info to cartons for items:${canItems.join(
              ','
            )}`;
          }
        });
      }
      if (data.err_sheet.length) {
        data.msg += `\n${data.sheet_msg}`;
      }
      this._appService.notify(data);
      this.closeExcelDialog();
      this.loadSummary();
    } else {
      data.invoice_dict.forEach((invoice) => {
        invoice.checkFlag = true;
      });
      this.duplicateInvoiceDetails = data;
    }
  }

  selectAction(event): void {
    if (event.action === 'icon-trash2') {
      this.openDeleteDialog(event.data);
    } else {
      this.openDownloadDialog(event.data);
    }
  }

  uploadExcel(): void {
    if (!this.validateFile()) {
      return;
    }
    const req = this.uploadRequestObj();
    if (this.duplicateInvoiceDetails && req.invoice_arr.length === 0) {
      this._appService.notify({ status: 1, msg: 'No invoices are selected' });
      return;
    }
    this.pageDim = true;
    this._dsvService
      .importExcelToDb(req)
      .then((data) => {
        this.parseUploadResponse(data);
      })
      .catch((err) => {
        this._appService.notify(err);
        this.closeExcelDialog();
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  uploadRequestObj(): DSVUpload {
    let invoiceArr = [];
    if (this.duplicateInvoiceDetails) {
      const invoiceDictArr = _lodash.cloneDeep(
        this.duplicateInvoiceDetails.invoice_dict
      );
      invoiceArr = _lodash.cloneDeep(this.duplicateInvoiceDetails.invoice_arr);
      invoiceDictArr.forEach((invoice) => {
        if (!invoice.checkFlag) {
          const index = invoiceArr.findIndex(
            (invoiceDict) => invoiceDict.invoice_no === invoice.invoice_no
          );
          if (index !== -1) {
            invoiceArr.splice(index, 1);
          }
        }
      });
    }
    return {
      base64: this.excelFile.base64,
      created_id: this.user.user_id,
      filename: this.excelFile.filename,
      supplier_lookup: this.selectedSupplier,
      invoice_dict: this.duplicateInvoiceDetails
        ? this.duplicateInvoiceDetails.invoice_dict
        : null,
      row_index: this.duplicateInvoiceDetails
        ? this.duplicateInvoiceDetails.row_index
        : null,
      invoice_arr: this.duplicateInvoiceDetails ? invoiceArr : null,
    };
  }

  validateFile(): boolean {
    if (!(this.excelFile && this.excelFile.base64) || !this.selectedSupplier) {
      this.focusSupplier = !this.selectedSupplier;
      this.focusExcelError = !(this.excelFile && this.excelFile.base64);
      return false;
    }
    const fileName = this.excelFile.filename.split('.');
    const fileExtension = fileName[fileName.length - 1];
    if (
      fileExtension.toUpperCase() !== 'XLS' &&
      fileExtension.toUpperCase() !== 'XLSX'
    ) {
      this.excelFile = { filename: '', base64: '' };
      (document.getElementById('dsv-file') as HTMLFormElement).value = null;
      this.focusExcelError = true;
      return false;
    }
    return true;
  }
}
