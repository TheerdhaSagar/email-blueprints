import { NgModule } from '@angular/core';
import { DsvComponent } from './dsv-invoices/dsv.component';
import { DsvRoutingModule } from './dsv-routing.module';
import { ShareModule } from '../share/share.module';
import { DSVDashboardComponent } from './dashboard/dashboard.component';
import { ChewyShippingComponent } from './chewy-shipping/chewy-shipping.component';

@NgModule({
  declarations: [ChewyShippingComponent, DsvComponent, DSVDashboardComponent],
  imports: [DsvRoutingModule, ShareModule],
})
export class DsvModule {}
