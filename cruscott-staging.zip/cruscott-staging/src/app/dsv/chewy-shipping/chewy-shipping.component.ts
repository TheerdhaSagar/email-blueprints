import { Component, Injector, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { CommonService } from '../../globals/common.service';
import { ColumnSettings } from '../../globals/tabletemplate/models/layout';
import { Settings } from '../../globals/tabletemplate/models/settings';
import { User } from '../../globals/user';
import { ChewyLabel } from '../models/chewy-label';
import { ChewyShippingService } from '../service/chewy-shipping.service';

@Component({
  selector: 'app-chewy-shipping',
  templateUrl: './chewy-shipping.component.html',
  styleUrls: ['./chewy-shipping.component.scss'],
})
export class ChewyShippingComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _chewyService: ChewyShippingService = this.injector.get(
    ChewyShippingService
  );
  private _commonService: CommonService = this.injector.get(CommonService);
  private _router: Router = this.injector.get(Router);

  chewyShippingDetails: ChewyLabel[];
  headerDetails: ColumnSettings[];
  searchQuery: string;
  showDetails = false;
  showSpinner = false;
  tableSettings: Settings;
  shippingDetail: ChewyLabel;
  user: User;

  constructor(private injector: Injector) {
    this.chewyShippingDetails = [];
    this.shippingDetail = null;
    this.initTableDetails();
  }

  static tableHeaderArr(): ColumnSettings[] {
    return [
      {
        title: 'Order #',
        keyName: 'order_number',
        styles: { width: '100px', format: 'number' },
      },
      { title: 'B/L Number', keyName: 'bol', styles: { width: '100px' } },
      {
        title: 'Delivery Number',
        keyName: 'delivery_number',
        styles: { width: '100px' },
      },
      {
        title: 'Ship From Name',
        keyName: 'ship_from_name',
        styles: { width: '150px' },
      },
      {
        title: 'Ship From Address',
        keyName: 'ship_from_address',
        styles: { width: '300px' },
      },
      {
        title: 'Ship To Name',
        keyName: 'ship_to_name',
        styles: { width: '150px' },
      },
      {
        title: 'Ship To Address',
        keyName: 'ship_to_address',
        styles: { width: '300px' },
      },
      {
        title: 'PO Number',
        keyName: 'po_number',
        styles: { width: '100px' },
      },
      {
        title: 'Creation Date',
        keyName: 'label_creation_date',
        styles: { width: '100px', format: 'date' },
      },
    ];
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.showSpinner = true;
        this.loadChewyDetails();
      }
    });
  }

  initTableDetails(): void {
    this.tableSettings = new Settings({
      headers: ChewyShippingComponent.tableHeaderArr(),
      sortHeader: true,
      icons: [
        {
          iconType: 'icon',
          iconStyle: 'icon-eye',
          iconAction: 'view',
        },
        {
          iconType: 'icon',
          iconStyle: 'icon-download2',
          iconAction: 'download',
        },
      ],
      checkboxes: false,
      predicate: 'rvf_transaction_id',
      desc: true,
      fileName: 'rvf-Inventory-Summary',
    });
  }

  loadChewyDetails(): void {
    this._chewyService
      .loadChewy()
      .then((data) => {
        data.forEach((chewyDetails) => {
          const chewy = chewyDetails;
          chewy.displayConditions = { view: true, download: true };
        });
        this.chewyShippingDetails = data;
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
      });
  }

  loadSingleChewyDetails(orderDetails): void {
    this.showSpinner = true;
    this._chewyService
      .loadChewy(orderDetails.order_number)
      .then((data) => {
        [this.shippingDetail] = data;
        this.shippingDetail.ship_from_address = orderDetails.ship_from_address;
        this.shippingDetail.ship_to_address = orderDetails.ship_to_address;
        this.showDetails = true;
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
      });
  }

  downloadChewyLabels(labelData: ChewyLabel): void {
    this.showSpinner = true;
    this._chewyService
      .downloadChewyLabel({ ...labelData, created_by: this.user.user_id })
      .then((response) => {
        const data = response;
        data.file_type = 'application/pdf';
        this._commonService.downloadFile(data);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.showSpinner = false;
        this.loadChewyDetails();
      });
  }

  iconClickEvent(event): void {
    if (event.action === 'icon-eye') {
      this.loadSingleChewyDetails(event.data);
    } else {
      this.downloadChewyLabels(event.data);
    }
  }
}
