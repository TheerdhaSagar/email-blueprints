import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChewyShippingComponent } from './chewy-shipping.component';

describe('ChewyShippingComponent', () => {
  let component: ChewyShippingComponent;
  let fixture: ComponentFixture<ChewyShippingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChewyShippingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChewyShippingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
