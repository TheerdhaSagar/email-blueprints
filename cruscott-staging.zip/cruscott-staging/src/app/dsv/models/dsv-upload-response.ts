import { Response } from '../../globals/response';

export interface DSVUploadResponse extends Response {
  cans_error?: { invoice_no: string; cans_error: string[] }[];
  err_sheet?: number[];
  invoice_dict?: {
    invoice_no: number;
    container_no: string;
    checkFlag: boolean;
  }[];
  invoice_arr?: { invoice_no: number; container_no: string }[];
  row_index?: number;
  sheet_msg?: string;
}
