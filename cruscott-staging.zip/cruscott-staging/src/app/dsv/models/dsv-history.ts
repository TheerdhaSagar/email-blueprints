export interface DsvHistory {
  dsv_header_id?: number;
  dsv_history_id?: number;
  description?: string;
  notes?: string;
  created_date?: string;
}
