import { Pallet } from './pallet';

export interface ChewyLabel {
  bol: string;
  carrier?: string;
  created_by?: number;
  delivery_id?: number;
  delivery_number: string;
  description?: string;
  displayConditions?: { download: boolean; view: boolean };
  label_created_by?: number;
  label_creation_date?: string;
  order_number: number;
  pallets?: Pallet[];
  po_number: string;
  pro?: number;
  ship_from_address: string;
  ship_from_address1?: string;
  ship_from_address2?: string;
  ship_from_address3?: string;
  ship_from_address4?: string;
  ship_from_city?: string;
  ship_from_country?: string;
  ship_from_name?: string;
  ship_from_postal_code?: string;
  ship_from_state?: string;
  ship_to_address?: string;
  ship_to_address_1?: string;
  ship_to_address_2?: string;
  ship_to_address_3?: string;
  ship_to_address_4?: string;
  ship_to_city?: string;
  ship_to_name?: string;
  ship_to_postal_code?: string;
  ship_to_state?: string;
}
