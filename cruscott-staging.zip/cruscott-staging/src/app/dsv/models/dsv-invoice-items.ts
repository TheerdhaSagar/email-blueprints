export interface DsvInvoiceItems {
  cartons: number;
  codes: string;
  expiry_date: string;
  item_code: string;
}
