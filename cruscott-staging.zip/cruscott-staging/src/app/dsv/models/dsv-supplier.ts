export interface DsvSupplier {
  dsv_supplier_id: number;
  supplier_lookup: string;
  supplier_name: string;
}
