export interface DSVUpload {
  base64: string;
  created_id: number;
  filename: string;
  invoice_arr?: { invoice_no: number; container_no: string }[];
  invoice_dict?: { invoice_no: number; container_no: string }[];
  row_index?: number;
  supplier_lookup: string;
}
