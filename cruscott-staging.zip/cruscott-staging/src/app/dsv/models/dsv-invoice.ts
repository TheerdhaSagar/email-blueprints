import { DsvHistory } from './dsv-history';
import { DsvInvoiceItems } from './dsv-invoice-items';

export interface DsvInvoice {
  container_no: string;
  created_date?: string;
  created_id?: number;
  displayConditions?: { [key: string]: boolean };
  exported_filename: string;
  dsv_header_id?: number;
  expand?: boolean;
  fileName?: string;
  gross_weight: number;
  history?: DsvHistory[];
  invoice_no: number;
  items?: DsvInvoiceItems[];
  last_downloaded_date?: string;
  net_weight: number;
  total_cartons?: number;
  uploaded_filename: string;
  uom: string;
}
