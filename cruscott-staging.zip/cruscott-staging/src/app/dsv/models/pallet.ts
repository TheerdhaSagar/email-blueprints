export interface Pallet {
  ct_qty?: number;
  num_of_cts: number;
  sku: string;
  sscc: string;
}
