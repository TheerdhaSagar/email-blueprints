import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChewyShippingComponent } from './chewy-shipping/chewy-shipping.component';
import { DSVDashboardComponent } from './dashboard/dashboard.component';
import { DsvComponent } from './dsv-invoices/dsv.component';

const routes: Routes = [
  { path: 'dashboard', component: DSVDashboardComponent },
  { path: 'summary', component: DsvComponent },
  { path: 'chewy', component: ChewyShippingComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DsvRoutingModule {}
