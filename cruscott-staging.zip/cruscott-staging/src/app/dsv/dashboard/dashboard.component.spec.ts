import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DSVDashboardComponent } from './dashboard.component';

describe('DSVDashboardComponent', () => {
  let component: DSVDashboardComponent;
  let fixture: ComponentFixture<DSVDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DSVDashboardComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DSVDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
