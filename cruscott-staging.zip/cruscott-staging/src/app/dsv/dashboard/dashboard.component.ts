import { Component, Injector, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CacheService } from 'src/app/globals/cache.service';
import { DataService } from 'src/app/globals/data.service';

@Component({
  selector: 'app-dsv-dashboard',
  templateUrl: './dashboard.component.html',
})
export class DSVDashboardComponent implements OnInit {
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _router: Router = this.injector.get(Router);

  cardRows: any[];
  notificationCount: any;
  roles: any;
  user: any;
  windowWidth: any;

  constructor(private injector: Injector) {
    this.cardRows = [];
    this.roles = this._dataService.roles;
    this.user = null;
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.setUpModules();
      }
    });
  }

  goToState(state, params?): void {
    if (params) {
      this._router.navigate([state], { queryParams: params });
    } else {
      this._router.navigate([state]);
    }
  }

  setUpModules() {
    if (this.roles.UIDSVInvoices) {
      this.cardRows.push({
        name: 'Container Packing List',
        state: 'dsv/summary',
        subname: '',
      });
    }
    if (this.roles.UIDSVShippingLabels) {
      this.cardRows.push({
        name: 'Shipping Labels',
        state: 'dsv/chewy',
        subname: '',
      });
    }
  }
}
