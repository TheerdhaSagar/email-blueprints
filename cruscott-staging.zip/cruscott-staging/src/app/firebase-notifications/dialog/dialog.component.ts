import {
  Component,
  Injector,
  Input,
  OnInit,
  OnDestroy,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { FirebaseMessageService } from '../service/firebase-message.service';
import { FirebaseUsersService } from '../service/firebase-users.service';
import { AppService } from '../../globals/app.service';
import { Message } from '../models/message';

@Component({
  selector: 'app-firebase-dialog',
  templateUrl: './dialog.component.html'
})
export class DialogComponent implements OnInit, OnDestroy {
  @Input() userId: number;

  private _appService: AppService = this.injector.get(AppService);
  private _messageService: FirebaseMessageService = this.injector.get(FirebaseMessageService);
  private _usersService: FirebaseUsersService = this.injector.get(FirebaseUsersService);

  messages: Array<Message>;
  moduleName: string;
  month: Array<string>;
  notificationTitle = 'Updates';
  notifyHeaders: Subscription;
  notifyModule: Subscription;
  showNotificationDialog = false;
  templateHeaders: Array<string>;

  constructor(private injector: Injector) {
    this.messages = [];
    this.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
      'August', 'September', 'October', 'November', 'December', 'Planned'
    ];
    this.templateHeaders = ['body', 'moduleName'];
  }

  ngOnInit(): void {
    this.showNotificationDialog = false;
    this.notifyHeaders = this._appService.subscribeNotificationHeaderChange((headers: Array<string>) => {
      this.templateHeaders = headers;
    });

    this.notifyModule = this._appService.subscribeModuleNameChange((module: string) => {
      this.moduleName = module;
    });
  }

  ngOnDestroy(): void {
    if (this.notifyHeaders) {
      this.notifyHeaders.unsubscribe();
    }

    if (this.notifyModule) {
      this.notifyModule.unsubscribe();
    }
  }

  dataModify(payload): Message {
    const data = payload;
    if (this.templateHeaders.findIndex((val) => val === 'monthName') !== -1) {
      data.monthName = this.month[data.month];
    }
    return data;
  }


  notificationCancel(): void {
    this.showNotificationDialog = false;
    if (this.moduleName) {
      this._usersService.moduleName = this.moduleName;
      this._usersService.manageCruscottUsers({ updateDate: true }).then(() => {
        this._appService.onFirebaseNotifications(this.messages);
        this.messages = [];
      });
    } else {
      this.messages = [];
    }
  }

  notificationPopUp(): void {
    this._messageService.receiveMessage().subscribe((payload) => {
      if (payload.data && parseInt(payload.data.updatedBy, 10) !== this.userId) {
        this._appService.cacheFirebaseNotifications = this._appService.cacheFirebaseNotifications.concat([
          payload.data]);
        if (this.moduleName === payload.data.moduleName || this.moduleName === '') {
          this.notificationTitle = this.moduleName === '' ? 'Updates' : `${this.moduleName} Updates`;
          if (!this.messages.find((obj) => obj.url === payload.data.url)) {
            this.messages.push(this.dataModify(payload.data));
          }
        }
        if (this.messages.length) {
          this.showNotificationDialog = true;
        }
      }
    });
  }
}
