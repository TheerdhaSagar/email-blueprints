import { TestBed } from '@angular/core/testing';

import { FirebaseObservablesService } from './firebase-observables.service';

describe('FirebaseObservablesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FirebaseObservablesService = TestBed.get(FirebaseObservablesService);
    expect(service).toBeTruthy();
  });
});
