import { TestBed } from '@angular/core/testing';

import { FirebaseUsersService } from './firebase-users.service';

describe('FirebaseUsersService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FirebaseUsersService = TestBed.get(FirebaseUsersService);
    expect(service).toBeTruthy();
  });
});
