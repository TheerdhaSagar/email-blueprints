import { Injectable, Injector } from '@angular/core';
import { AngularFireFunctions } from '@angular/fire/functions';
import { Subject } from 'rxjs';
import { APIError } from 'src/app/globals/api.error';
import { FirebaseUser, FbUserInput } from '../models/firebase-users';
import { AppService } from '../../globals/app.service';
import { Users } from '../../usermanagement/users';

@Injectable({
  providedIn: 'root',
})
export class FirebaseUsersService {
  private _appService: AppService = this.injector.get(AppService);
  private _fireFunc: AngularFireFunctions =
    this.injector.get(AngularFireFunctions);

  moduleName: string;
  rolePermission: string;
  notificationSideBar: Subject<boolean>;
  user: Users;

  constructor(private injector: Injector) {
    this.notificationSideBar = new Subject<boolean>();
    this.moduleName = null;
    this.rolePermission = null;
  }

  getFirebaseUser(): Promise<FirebaseUser> {
    const getUserResult = this._fireFunc.httpsCallable(
      'cruscott-readCruscottUser'
    )({ id: this.user.user_id.toString() });
    return getUserResult.toPromise();
  }

  findModularNotifications(showPopup = false): Promise<FirebaseUser> {
    let modulesFlag = [];
    return new Promise((resolve, reject) => {
      this.getFirebaseUser()
        .then((output: FirebaseUser) => {
          this._appService.cacheFirebaseUser = output;
          if (output.modules) {
            modulesFlag = output.modules.filter((data) => data.moduleSubscribe);
          }
          this.notificationSideBar.next(modulesFlag.length > 0);
          resolve(output);
        })
        .catch(() => {
          if (showPopup) {
            this._appService.notify(
              new APIError('Failed to get Firebase details')
            );
          }
          reject();
        });
    });
  }

  manageCruscottUsers(updateDetails: FbUserInput): Promise<string> {
    const fbUserDetails = this.requestObj(
      updateDetails.updateDate || false,
      updateDetails.logoutTime || false
    );
    if (updateDetails.fcmToken) {
      fbUserDetails.fcmToken = updateDetails.fcmToken;
    }
    if (typeof updateDetails.moduleSubscribe === 'boolean') {
      fbUserDetails.moduleSubscribe = updateDetails.moduleSubscribe;
    }
    return new Promise((resolve, reject) => {
      const manageUser = this._fireFunc.httpsCallable(
        'cruscott-manageCruscottUser'
      )(fbUserDetails);
      manageUser.subscribe(
        (data) => {
          this.findModularNotifications();
          resolve(data);
        },
        (err) => reject(err)
      );
    });
  }

  requestObj(updateDate, logoutTime): FbUserInput {
    return {
      role: this.rolePermission,
      id: this.user.user_id.toString(),
      moduleName: this.moduleName,
      updateDate,
      logoutTime,
    };
  }
}
