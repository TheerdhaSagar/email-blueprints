import { Injectable, Injector } from '@angular/core';
import { APIError } from 'src/app/globals/api.error';
import { AngularFireMessaging } from '@angular/fire/messaging';
import { AngularFireFunctions } from '@angular/fire/functions';
import { Observable } from 'rxjs';
import { mergeMap, first } from 'rxjs/operators';
import { AppService } from '../../globals/app.service';
import { FirebaseNotifications } from '../models/firebase-notifications';


@Injectable({
  providedIn: 'root'
})
export class FirebaseMessageService {
  private _angularFireMessaging: AngularFireMessaging = this.injector.get(AngularFireMessaging);
  private _angularFireFun: AngularFireFunctions = this.injector.get(AngularFireFunctions);
  private _appService: AppService = this.injector.get(AppService);

  topic: string;

  constructor(private injector: Injector) {
    this._angularFireMessaging.messaging.subscribe(
      (messaging) => {
        const _messaging = messaging;
        _messaging.onMessage = _messaging.onMessage.bind(_messaging);
        _messaging.onTokenRefresh = _messaging.onTokenRefresh.bind(_messaging);
      }
    );
  }

  deleteToken(): Promise<string> {
    return new Promise((resolve) => {
      this._angularFireMessaging.getToken
        .pipe(mergeMap((token) => {
          this.unsubscribeUserFromTopic(token, true);
          return this._angularFireMessaging.deleteToken(token);
        }))
        .subscribe(
          () => {
            resolve('unsubscribed');
          },
          () => {
            this._appService.notify(new APIError('Failed to unsubscribe'));
          }
        );
    });
  }

  getRefreshToken(): Promise<string> {
    return this._angularFireMessaging.tokenChanges.pipe(first()).toPromise();
  }


  getToken(): Promise<string> {
    return this._angularFireMessaging.tokenChanges.pipe(first()).toPromise();
  }


  /**
   * hook method when new notification received in foreground
   */
  receiveMessage(): Observable<FirebaseNotifications| any> {
    return this._angularFireMessaging.messages;
  }

  requestPermission(): Promise<void> {
    return this._angularFireMessaging.requestPermission.toPromise();
  }

  /*
   * request permission for notification from firebase cloud messaging
   */
  requestToken(): Promise<string> {
    return this._angularFireMessaging.requestToken.pipe(first()).toPromise();
  }

  // create the notifications in database, and database in turn triggers the push notifications
  sendNotificationToUser(notificationDetails): void {
    // const callable = this._angularFireFun.httpsCallable('sendNotification');
    // callable({ notification: notificationDetails, topic: this.topic });
    const notification = notificationDetails;
    const callable = this._angularFireFun.httpsCallable('createNotification');
    notification.topic = this.topic;
    callable({ ...notification });
  }

  subscribeUserToTopic(tokenId, topic): Promise<string> {
    const callable = this._angularFireFun.httpsCallable('subscribeToTopic')({ token: tokenId, topic });
    return callable.toPromise();
  }

  // user details are updated in notifications for showing notifications as read
  updateNotificationDetails(notificationId: string, userId: string): Promise<string> {
    const notificationCallable = this._angularFireFun.httpsCallable('updateNotification');
    return notificationCallable({ notificationId, userId }).toPromise();
  }

  unsubscribeUserFromTopic(tokenId, showNotification = false): void {
    const callable = this._angularFireFun.httpsCallable('unsubscribeFromTopic');
    const subscribeResult = callable({ token: tokenId, topic: this.topic });
    subscribeResult.subscribe(() => {
      if (showNotification) {
        this._appService.notify({ status: 0, msg: 'Unsubscribed successfully' });
      }
    }, () => {
      if (showNotification) {
        this._appService.notify(new APIError('Failed to unsubscribe'));
      }
    });
  }
}
