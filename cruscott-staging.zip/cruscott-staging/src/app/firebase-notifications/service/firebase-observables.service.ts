import { Injectable } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { ProductsNotification } from 'src/app/products-calendar/products-notification';
import { CalendarNotification } from 'src/app/sales-calendar/calendar-notification';

@Injectable({
  providedIn: 'root'
})
export class FirebaseObservablesService {
  public salesCalendarNotify: Subject<CalendarNotification>;
  public productsCalendarNotify: Subject<ProductsNotification>;

  constructor() {
    this.salesCalendarNotify = new Subject<CalendarNotification>();
    this.productsCalendarNotify = new Subject<ProductsNotification>();
  }

  onProductCalendarNotificationChange(productCalendarNotification: ProductsNotification): void {
    this.productsCalendarNotify.next(productCalendarNotification);
  }

  onSalesCalendarNotificationChange(salesCalendarNotification: CalendarNotification): void {
    this.salesCalendarNotify.next(salesCalendarNotification);
  }

  productsCalendarNotificationSubscription(callback): Subscription {
    return this.productsCalendarNotify.subscribe(callback);
  }

  salesCalendarNotificationSubscription(callback): Subscription {
    return this.salesCalendarNotify.subscribe(callback);
  }
}
