import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-firebase-highlighter',
  templateUrl: './highlighter.component.html',
  styleUrls: ['./highlighter.component.scss']
})
export class HighlighterComponent {
  @Input() hideRipple = false;
}
