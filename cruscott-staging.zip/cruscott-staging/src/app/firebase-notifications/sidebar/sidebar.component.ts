import { Component, HostListener, Injector, OnInit } from '@angular/core';
import * as _lodash from 'lodash';
import { Subject } from 'rxjs';
import jQuery from 'jquery';
import { AngularFireFunctions } from '@angular/fire/functions';
import { APIError } from 'src/app/globals/api.error';
import { DataService } from 'src/app/globals/data.service';
import { DatePipe } from '@angular/common';
import { OrderByPipe } from 'src/app/globals/order-by.pipe';
import { Router } from '@angular/router';
import { AppService } from 'src/app/globals/app.service';
import { User } from 'src/app/globals/user';
import { CacheService } from 'src/app/globals/cache.service';
import { FirebaseObservablesService } from '../service/firebase-observables.service';
import { ModuleDetails } from '../models/module-details';
import { FirebaseUsersService } from '../service/firebase-users.service';
import { FirebaseMessageService } from '../service/firebase-message.service';
import { CruscottNotifications } from '../models/cruscott-notifications';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit {
  private _angularFireFunc: AngularFireFunctions =
    this._injector.get(AngularFireFunctions);
  private _appService: AppService = this._injector.get(AppService);
  private _cacheService: CacheService = this._injector.get(CacheService);
  private _dataService: DataService = this._injector.get(DataService);
  private _datePipe: DatePipe = this._injector.get(DatePipe);
  private _firebaseObservables: FirebaseObservablesService = this._injector.get(
    FirebaseObservablesService
  );
  private _firebaseMessage: FirebaseMessageService = this._injector.get(
    FirebaseMessageService
  );
  private _firebaseUser: FirebaseUsersService =
    this._injector.get(FirebaseUsersService);
  private _orderBy: OrderByPipe = this._injector.get(OrderByPipe);
  private _router: Router = this._injector.get(Router);

  notificationAll: Array<CruscottNotifications>;
  notificationCount: number;
  redirectFirebaseNotificationId: string;
  roles: { UISalesCalendar: boolean; UISalesCalendarCommon: boolean };
  routerDetails: Array<ModuleDetails>;
  showSideBar = false;
  showNotification: Subject<boolean>;
  user: User;

  constructor(private _injector: Injector) {
    this.notificationAll = [];
    this.notificationCount = 0;
    this.roles = this._dataService.roles;
    this.showNotification = this._firebaseUser.notificationSideBar;
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (data) {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        if (this._appService.firebaseNotificationId) {
          this.redirectFirebaseNotificationId =
            this._appService.firebaseNotificationId;
        }
        if (!this._appService.cacheFirebaseUser) {
          this._firebaseUser.user = this.user;
          this._firebaseUser.findModularNotifications();
        }
        this.getRouterWithFunctions();
        this.loadNotifications();
        this.recieveNotificationDetails();
      }
    });
  }

  calendarNotificationRoute(selectedNotification): void {
    let params = '';
    let timeout = 500;
    if (!this.roles.UISalesCalendar && this.roles.UISalesCalendarCommon) {
      params = selectedNotification.params;
    }
    if (!this._router.url.includes(selectedNotification.state)) {
      this.routerNavigation(selectedNotification.state, params);
      timeout = 7000;
    }
    setTimeout(() => {
      this._firebaseObservables.onSalesCalendarNotificationChange(
        selectedNotification.additionalInfo
      );
    }, timeout);
  }

  cancelNotifications(): void {
    this.showSideBar = false;
    jQuery('body').css('overflow', 'auto');
  }

  static calendarRouterDetails(): ModuleDetails {
    return {
      name: 'Communications Calendar',
      state: 'sales-calendar',
      params: { calendarType: 'common' },
      icon: 'sales-calendar.png',
      function: 'calendarNotificationRoute',
    };
  }

  createNotificationObject(data): CruscottNotifications {
    return {
      topic: data.topic,
      id: data.id,
      moduleName: data.moduleName,
      updatedBy: data.updatedBy,
      additionalInfo: data,
      userDetails: [],
      createdOn: data.createdOn,
      f_CreatedOn: this._datePipe.transform(data.createdOn, 'medium'),
      status: true,
    };
  }

  findUserDetails(notification): boolean {
    return (
      notification.userDetails.findIndex(
        (user: { userId: string }) =>
          parseInt(user.userId, 10) === this.user.user_id
      ) === -1
    );
  }

  getRouterWithFunctions(): void {
    this.routerDetails = [
      SidebarComponent.calendarRouterDetails(),
      SidebarComponent.productCalendarRuteDetails(),
    ];
  }

  goToNotificationModule(notification): void {
    this.showSideBar = false;
    jQuery('body').css('overflow', 'auto');
    this[notification.function](notification);
    this.updateNotificationDetails(notification.id);
  }

  loadNotifications(): void {
    this.notificationCount = 0;
    if (this.user) {
      const notificationCallable = this._angularFireFunc.httpsCallable(
        'cruscott-getNotificationDetails'
      );
      notificationCallable({ userId: this.user.user_id.toString() }).subscribe(
        (notificationDetails) => {
          this.parseNotifications(notificationDetails);
        },
        (err) => {
          this._appService.notify(new APIError(err.message));
        }
      );
    }
  }

  openNotifications(): void {
    this.showSideBar = true;
    jQuery('body').css('overflow', 'hidden');
  }

  parseNotifications(notificationDetails): void {
    const redirectFirebaseNotificationId =
      this._appService.firebaseNotificationId;
    if (notificationDetails) {
      this.notificationAll = notificationDetails.filter(
        (data) =>
          parseInt(data.additionalInfo.updatedBy, 10) !== this.user.user_id
      );
      this.notificationAll.forEach((element: CruscottNotifications) => {
        let notify = element;
        notify = _lodash.merge(
          element,
          this.routerDetails.find((rd) => rd.name === notify.moduleName)
        );
        notify.f_CreatedOn = this._datePipe.transform(
          notify.createdOn._seconds * 1000,
          'medium'
        );
        notify.status =
          redirectFirebaseNotificationId &&
          redirectFirebaseNotificationId === notify.id
            ? false
            : this.findUserDetails(notify);
        if (notify.status) {
          this.notificationCount += 1;
        }
      });
    }
    this.notificationAll = this._orderBy.transform(
      this.notificationAll,
      'f_CreatedOn',
      true
    );
  }

  productsCalendarNotificationRoute(selectedNotification): void {
    let timeout = 500;
    if (!this._router.url.includes(selectedNotification.state)) {
      this.routerNavigation(selectedNotification.state);
      timeout = 5000;
    }
    setTimeout(() => {
      this._firebaseObservables.onProductCalendarNotificationChange(
        selectedNotification.additionalInfo
      );
    }, timeout);
  }

  static productCalendarRuteDetails(): ModuleDetails {
    return {
      name: 'Product Calendar',
      state: 'products-calendar',
      icon: 'product-calendar.png',
      function: 'productsCalendarNotificationRoute',
    };
  }

  recieveNotificationDetails(): void {
    this._firebaseMessage.receiveMessage().subscribe((payload) => {
      let notificationData: CruscottNotifications =
        this.createNotificationObject(payload.data);
      notificationData = _lodash.merge(
        notificationData,
        this.routerDetails.find((rd) => rd.name === notificationData.moduleName)
      );
      if (
        payload.data &&
        parseInt(payload.data.updatedBy, 10) !== this.user.user_id
      ) {
        notificationData.status = true;
        this.notificationAll.push(notificationData);
        this.notificationCount = this.notificationAll.filter(
          (notification) => notification.status === true
        ).length;
        this.loadNotifications();
      }
      this.notificationAll = this._orderBy.transform(
        this.notificationAll,
        'f_CreatedOn',
        true
      );
    });
  }

  routerNavigation(state, params?): void {
    if (params) {
      this._router.navigate([state], { queryParams: params });
    } else {
      this._router.navigate([state]);
    }
  }

  updateNotificationDetails(notificationId: string): void {
    this._firebaseMessage
      .updateNotificationDetails(notificationId, this.user.user_id.toString())
      .then(() => {
        const notify = this.notificationAll.find(
          (notification: CruscottNotifications) =>
            notification.id === notificationId
        );
        if (notify.status) {
          notify.status = false;
          this.notificationCount -= 1;
        }
      });
  }

  @HostListener('document:visibilitychange', ['$event'])
  visibilityChange(): void {
    if (
      !document.hidden &&
      this._appService.cacheFirebaseUser &&
      'modules' in this._appService.cacheFirebaseUser
    ) {
      this.loadNotifications();
    }
  }
}
