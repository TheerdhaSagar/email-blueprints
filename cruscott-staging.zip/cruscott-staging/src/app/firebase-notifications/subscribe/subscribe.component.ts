import {
  Component,
  Injector,
  Input,
  OnInit
} from '@angular/core';
import { APIError } from 'src/app/globals/api.error';
import { FirebaseMessageService } from '../service/firebase-message.service';
import { FirebaseUsersService } from '../service/firebase-users.service';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { User } from '../../globals/user';
import { FirebaseUser } from '../models/firebase-users';

@Component({
  selector: 'app-firebase-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.scss']
})
export class SubscribeComponent implements OnInit {
  @Input() moduleName: string;
  @Input() rolePermission: string;
  @Input() topic: string;

  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _messageService: FirebaseMessageService = this.injector.get(FirebaseMessageService);
  private _userService: FirebaseUsersService = this.injector.get(FirebaseUsersService);

  activity: string;
  showDialog: boolean;
  showSubscribe: boolean;
  user: User;

  constructor(private injector: Injector) {
    this.showDialog = false;
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (data) {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this._userService.rolePermission = this.rolePermission;
        this._userService.moduleName = this.moduleName;
        this._messageService.topic = this.topic;
        this.showSubscribe = false;
        this.checkFirebaseUserDetails();
      }
    });
  }

  buttonEnable(userDetails): void {
    const firebaseUserDetails = userDetails;
    if (firebaseUserDetails && firebaseUserDetails.modules) {
      const moduleDetails = firebaseUserDetails.modules.find((module) => module.moduleName === this.moduleName);
      if (moduleDetails) {
        this.showSubscribe = moduleDetails.moduleSubscribe;
        if (this.showSubscribe) {
          this._messageService.requestToken().then((token) => {
            this._messageService.subscribeUserToTopic(token, this.topic).then();
          });
        }
      }
    }
  }

  async checkFirebaseUserDetails(): Promise<void> {
    if (Notification.permission === 'granted') {
      if (!this._appService.cacheFirebaseUser) {
        this._userService.user = this.user;
        await this._userService.findModularNotifications().then((output: FirebaseUser) => {
          if (output && !('msg' in output)) {
            this.buttonEnable(output);
          }
        });
      } else {
        this.buttonEnable(this._appService.cacheFirebaseUser);
      }
    }
  }

  confirmationDialog(activity?): void {
    if (Notification.permission === 'denied') {
      this._appService.notify(new APIError(
        'Please allow browser notifications before subscribing'
      ));
      return;
    }
    if (activity) {
      this.showDialog = true;
      this.activity = activity;
    } else {
      this.showDialog = false;
      this.activity = '';
    }
  }

  manageSubscription(): void {
    if (this.activity === 'subscribe') {
      this.subscribeModule();
    } else {
      this.unsubscribeModule();
    }
    this.confirmationDialog();
  }

  subscribeModule(): void {
    this._messageService.requestToken().then((token) => {
      this._messageService.subscribeUserToTopic(token, this.topic).then(() => {
        this._appService.notify({ status: 0, msg: 'Subscribed successfully' });
      });
      this._userService.manageCruscottUsers({ updateDate: false, moduleSubscribe: true, fcmToken: token }).then(() => {
        this.showSubscribe = true;
      }).catch(() => {
        this._appService.notify(new APIError('Failed to subscribe'));
        this.showSubscribe = false;
      });
    }).catch(() => {
      this._appService.notify(new APIError(
        'Please allow browser notifications before subscribing'
      ));
      this.showSubscribe = false;
    });
  }

  unsubscribeModule(): void {
    this._messageService.deleteToken().then(() => {
      this._userService.manageCruscottUsers({ updateDate: false, moduleSubscribe: false }).then(() => {
        this.showSubscribe = false;
      }).catch(() => {
        this._appService.notify(new APIError('Failed to unsubscribe'));
        this.showSubscribe = true;
      });
    });
  }
}
