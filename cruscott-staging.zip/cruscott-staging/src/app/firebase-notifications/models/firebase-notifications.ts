import { Message } from './message';

export interface FirebaseNotifications {
  collapse_key: string;
  data: Message;
  from: string;
}
