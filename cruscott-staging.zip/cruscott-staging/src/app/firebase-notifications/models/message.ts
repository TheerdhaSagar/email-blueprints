export interface Message {
  body: string;
  moduleName: string;
  notificationTitle?: string;
  tag?: string;
  url?: string;
  updatedBy: string;
}
