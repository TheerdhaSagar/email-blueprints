export interface ModuleDetails {
    function: string;
    icon: string;
    name: string;
    params?: { [key: string]: string };
    state: string;
}
