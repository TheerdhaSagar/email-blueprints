export interface CruscottNotifications {
    // additional Info of notifications are saved
    additionalInfo: { [key: string]: string };
    createdOn?: {_seconds: number; _nanoseconds: number};
    f_CreatedOn?: string;
    id?: string;
    moduleName?: string;
    status?: boolean;
    topic?: string;
    updatedBy?: number | null;
    userDetails?: Array<{ lastLogin: {_seconds: number; _nanoseconds: number}; userId: string }> | [];
}
