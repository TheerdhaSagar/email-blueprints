export interface FirebaseUser {
  fcmToken?: string;
  modules?: ModuleRole[];
}

export interface ModuleRole {
  lastUpdatedDate: {_seconds: number; _nanoseconds: number};
  moduleName: string;
  moduleSubscribe: boolean;
  role: string;
  timeInSeconds: number;
}

export interface FbUserInput {
  fcmToken?: string;
  id?: string;
  logoutTime?: boolean;
  moduleName?: string;
  moduleSubscribe?: boolean;
  role?: string;
  updateDate?: boolean;
}
