import { Component, OnInit, Injector } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';

@Component({
  selector: 'app-donation-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DonationDashboardComponent implements OnInit {
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _location: Location = this.injector.get(Location);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  projectType: string;
  roles: any;

  constructor(private injector: Injector) {
    this._window = window;
    this.roles = this._dataService.roles;
  }

  ngOnInit(): void {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });

    this._routeParams.queryParams.subscribe((params) => {
      if (params.project) {
        this.projectType = params.project.toString();
      }
    });
  }

  moveTo(stateName): void {
    if (this.projectType) {
      this._router.navigate([stateName], { queryParams: { project: this.projectType } });
    } else {
      this._router.navigate([stateName]);
    }
  }
}
