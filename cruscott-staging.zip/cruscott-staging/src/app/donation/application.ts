export interface Application {
  address: string;
  application_no: string;
  association_type: string;
  cat_meals: string;
  cats: number;
  city: string;
  contact_phone: string;
  country: string;
  created_date: string;
  dog_meals: string;
  dogs: number;
  org_id: number;
  org_name: string;
  phone: string;
  quote_header_id: number;
  quote_number: number;
  quote_price: number;
  request_header_id: number;
  request_status: string;
  request_type: string;
  ricevuta: string;
  ship_address: string;
  user_email: string;
  waiting_for: string;
  zip: string;
}
