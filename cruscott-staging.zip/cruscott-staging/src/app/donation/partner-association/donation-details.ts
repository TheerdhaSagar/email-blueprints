export interface DonationDetailsEntity {
  created_by?: number;
  donation_date: string;
  partner_association_id?: number;
  partner_donation_id?: number;
  quantity: number;
}
