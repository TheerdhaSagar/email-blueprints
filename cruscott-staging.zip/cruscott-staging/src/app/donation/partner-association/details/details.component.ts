import { Component, OnInit, Injector } from '@angular/core';
import * as _lodash from 'lodash';
import { Router } from '@angular/router';
import { SafeHtml } from '@angular/platform-browser';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { FormatService } from '../../../globals/format.service';
import { DonationService } from '../../donationservice/donation.service';
import { PartnerAssociation} from '../partner-association';
import { PetDetailsEntity } from '../pet-details';
import { DonationDetailsEntity } from '../donation-details';
import { AddressEntity } from '../address';
import { User } from '../../../globals/user';

declare const FooPicker;
declare const google;

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class PartnerAssociationDetailsComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _donationService: DonationService = this.injector.get(DonationService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _router: Router = this.injector.get(Router);

  addDonationDialog: boolean;
  addPetDialog: boolean;
  address: string;
  addressRecord: AddressEntity;
  autocomplete: any;
  bioDiversityImpact: Array<string>;
  city: string;
  countries: Array<{country: string; country_code: string}>;
  country: string;
  dateFormat: string;
  deleteType: string;
  donationDateMsg: string;
  editPetDetails: boolean;
  editType: string;
  facebookMsg: string;
  focusDonationDate: boolean;
  focusEdit: boolean;
  focusFacebook: boolean;
  focusInstagram: boolean;
  focusQuantity: boolean;
  focusWebsite: boolean;
  foodDonationDetails: DonationDetailsEntity;
  instagramMsg: string;
  numberFormat: string;
  partnerAssocDetails: PartnerAssociation & { formatted_address?: SafeHtml };
  partnerAssociationId: number;
  partnerPetDetails: Array<PetDetailsEntity & { edit?: boolean }>;
  petDetails: PetDetailsEntity;
  primaryCertificates: Array<string>;
  primarySales: Array<string>;
  primaryTypes: Array<string>;
  province: string;
  showDeleteDialog: number;
  showDonationDialog: boolean;
  showError: boolean;
  showPartnerAssocDialog: boolean;
  showSpinner: boolean;
  updatePartnerAssoc: PartnerAssociation;
  user: User;
  websiteMsg: string;
  zip: number;

  constructor(private injector: Injector) {
    this.addDonationDialog = false;
    this.addPetDialog = false;
    this.donationDateMsg = 'Add Donation Date';
    this.editPetDetails = false;
    this.showDeleteDialog = -1;
    this.showDonationDialog = false;
    this.showPartnerAssocDialog = false;
    this.showSpinner = false;
    this.updatePartnerAssoc = {
      association_id: null,
      association_name: null,
      partner_association_id: null,
      partner_association_name: null,
      org_id: null
    };
    this.setInitFocusFields();
  }

  ngOnInit(): void {
    this.showSpinner = true;
    this.loadPartnerAssociationJSON();
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']).then();
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.cacheDetails();
      }
    });
  }

  addDonation(): void {
    this.addDonationDialog = true;
    this.foodDonationDetails = { donation_date: '', quantity: null };
  }

  addPet(): void {
    this.addPetDialog = true;
    this.editType = 'add_pet';
    this.petDetails = {
      pet_name: '',
      pet_age: null,
      pet_race: '',
      health_rating: null,
      partner_association_id: this.partnerAssocDetails.partner_association_id,
      tourist_attitude_rating: null,
      training_received: '',
      work_attitude_rating: null
    };
  }

  backToSummary(): void {
    this._router.navigate(['donation/partner-association/summary'],
      { queryParams: { project: 'humans-and-wild-life' } }).then();
  }

  cacheDetails(): void {
    this.numberFormat = this.user.number_format || '999,999.99';
    this.dateFormat = this.user.date_format;
    if (this._appService.partnerAssociationId) {
      this.partnerAssociationId = this._appService.partnerAssociationId;
      this._appService.partnerAssociationId = null;
      this.loadCountries();
      this.loadPartnerAssociationDetails();
    } else {
      this._router.navigate(['donation/partner-association/summary'],
        { queryParams: { project: 'humans-and-wild-life' } }).then();
    }
    setTimeout(() => {
      ((): void => new FooPicker({
        id: 'donationDate',
        dateFormat: this.dateFormat
      }))();
    });
  }

  // Check the type of details user is trying to edit and show error message only for those fields
  checkEditType(type): boolean {
    return this.focusEdit && this.editType === type;
  }

  clearEdit(petDetails): void {
    const index = this.partnerPetDetails.findIndex((pet) => pet.pet_id === petDetails.pet_id);
    if (index !== -1) {
      this.partnerPetDetails[index] = this.partnerAssocDetails.pet_details[index];
      this.partnerPetDetails[index].edit = false;
    }
  }

  closePartnerPopUp(): void {
    this.showPartnerAssocDialog = false;
    this.setPartnerAssocFields();
  }

  dateCheck(): void {
    setTimeout(() => {
      if (!this.foodDonationDetails.donation_date || (this.foodDonationDetails.donation_date &&
        !this._formatService.validateDate(this.foodDonationDetails.donation_date))) {
        this.focusDonationDate = false;
        this.donationDateMsg = this.foodDonationDetails.donation_date ? 'Invalid Date' : 'Add Donation Date';
        this.foodDonationDetails.donation_date = '';
      }
    });
  }

  deletePetDonationDetails(): void {
    this.showSpinner = true;
    this._donationService.deleteDonationOrPetDetails(this.showDeleteDialog, this.deleteType)
      .then((response) => {
        this._appService.notify(response);
        this.deletePetDonationUpdate();
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.showSpinner = false;
        this.showDeleteDialog = -1;
        this.deleteType = '';
      });
  }

  deletePetDonationDialog(type: string, type_id: number): void {
    this.deleteType = type;
    this.showDeleteDialog = type_id;
  }

  deletePetDonationUpdate(): void {
    let index;
    if (this.deleteType === 'donations') {
      index = this.getDonationIndex(this.showDeleteDialog);
      if (index !== -1) {
        this.partnerAssocDetails.donation_details.splice(index);
      }
    } else {
      index = this.partnerPetDetails.findIndex((pet) => pet.pet_id ===
        this.showDeleteDialog);
      if (index !== -1) {
        this.partnerAssocDetails.pet_details.splice(index);
        this.partnerPetDetails.splice(index);
      }
    }
  }

  getDonationIndex(donationId): number {
    const donationDetails = this.partnerAssocDetails.donation_details;
    return donationDetails.findIndex((donation) => donation.partner_donation_id ===
      donationId);
  }

  getPartnerPetIndex(petId): number {
    return this.partnerPetDetails.findIndex((pet) => pet.pet_id === petId);
  }

  initializeAddressAutoComplete(fieldId): void {
    setTimeout(() => {
      const address = document.getElementById(fieldId);
      if (address) {
        if (google && google.maps) {
          const country = this.setDefaultCountry();
          this.autocomplete = new google.maps.places.Autocomplete(address, {
            componentRestrictions: { country: country ? country.toLowerCase() : '' }
          });
          google.maps.event.addListener(this.autocomplete, 'place_changed',
            this.onPartnerAddressChange.bind(this));
        }
      }
    }, 100);
  }

  loadCountries(): void {
    this._donationService.loadCountries()
      .then((response) => {
        this.countries = response;
      }).catch((error) => {
        this._appService.notify(error);
      });
  }

  loadPartnerAssociationDetails(): void {
    this._donationService.getDetailsHWPartnerAssociation(this.partnerAssociationId)
      .then((response) => {
        this.partnerAssocDetails = response;
        this.parsePartnerAssociation(this.partnerAssocDetails);
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.showSpinner = false;
      });
  }

  loadPartnerAssociationJSON(): void {
    this._donationService.getPartnerAssociationJSONFile()
      .then((response) => {
        this.primaryTypes = response.product_types;
        this.primarySales = response.primary_sales;
        this.primaryCertificates = response.primary_certificates;
        this.bioDiversityImpact = response.biodiversity_impact;
      });
  }

  managePartnerAssociationDetails(partnerAssocDetails): void {
    const method = this.updatePartnerAssoc.partner_association_id ? 'PUT' : 'POST';
    if (method === 'PUT') {
      delete this.updatePartnerAssoc.donation_details;
      delete this.updatePartnerAssoc.pet_details;
    }
    this.showPartnerAssocDialog = false;
    this._donationService.manageHWPartnerAssociation(method, partnerAssocDetails)
      .then((response) => {
        this._appService.notify(response);
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.loadPartnerAssociationDetails();
      });
  }

  managePartnerAssociationDonationDetails(): void {
    const method: string = this.foodDonationDetails.partner_donation_id ? 'PUT' : 'POST';
    this._donationService.manageHWPartnerAssocDonationDetails(method, this.foodDonationDetails)
      .then((response) => {
        this._appService.notify(response);
        this.foodDonationDetails.partner_donation_id = response.partner_donation_id;
        this.partnerAssocDetails.donation_details.push(this.foodDonationDetails);
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.showSpinner = false;
      });
  }

  managePartnerAssociationPetDetails(method, petDetails): void {
    const pet = petDetails;
    this._donationService.manageHWPartnerAssocPetDetails(method, pet)
      .then((response) => {
        this._appService.notify(response);
        pet.edit = false;
        this.parsePartnerAssocPetDetails(method, pet, response);
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.showSpinner = false;
        this.addPetDialog = false;
      });
  }

  static matchAddressType(types): string {
    const addressTypes = ['route', 'locality', 'administrative_area_level_2', 'postal_code'];
    for (let i = 0; i < types.length; i++) {
      for (let j = 0; j < addressTypes.length; j++) {
        if (types[i] === addressTypes[j]) {
          return types[i];
        }
      }
    }
    return '';
  }

  onEditPetDetails(pet): void {
    this.editType = 'pet_details';
    const index = this.partnerPetDetails.findIndex((p) => p.pet_id === pet.pet_id);
    if (index !== -1) {
      this.partnerPetDetails[index].edit = true;
    }
  }

  onPartnerAddressChange(): void {
    const components = this.autocomplete.getPlace().address_components;
    for (let i = 0; i < components.length; i++) {
      this.onPartnerUpdate(components[i]);
    }
    this.updatePartnerAssoc.address[0].lat = this.autocomplete.getPlace().geometry.location.lat;
    this.updatePartnerAssoc.address[0].lng = this.autocomplete.getPlace().geometry.location.lng;
  }

  onPartnerUpdate(component): void {
    switch (PartnerAssociationDetailsComponent.matchAddressType(component.types)) {
    case 'route':
      this.addressRecord.address_line_1 = component.long_name;
      break;
    case 'locality':
      this.addressRecord.city = component.long_name;
      break;
    case 'administrative_area_level_2':
      this.addressRecord.province = component.short_name;
      break;
    case 'postal_code':
      this.addressRecord.zip = component.long_name;
      break;
    default:
      break;
    }
  }

  onRateChange(score): void {
    let id;
    const keys = ['health_rating', 'work_attitude_rating', 'tourist_attitude_rating'];
    if (score.key.includes('editImpact')) {
      id = score.key.split('-').pop();
      this.updatePartnerAssoc.biodiversity_impact[id] = score.value;
    } else {
      id = parseInt(score.key.split('_').pop(), 10);
      for (let i = 0; i < keys.length; i++) {
        if (score.key.includes('edit') && score.key.includes(keys[i])) {
          const index = this.getPartnerPetIndex(id);
          if (index !== -1) {
            this.partnerPetDetails[index][keys[i]] = score.value;
          }
        } else {
          this.petDetails[keys[i]] = score.value;
        }
      }
    }
  }

  parsePartnerAssociation(result): void {
    this.partnerAssocDetails = result;
    this.partnerAssocDetails.facebook_url = PartnerAssociationDetailsComponent.parseUrls(
      this.partnerAssocDetails.facebook_url
    );
    this.partnerAssocDetails.website_url = PartnerAssociationDetailsComponent.parseUrls(
      this.partnerAssocDetails.website_url
    );
    this.partnerAssocDetails.formatted_address = this._donationService.formatAddress(
      this.partnerAssocDetails.address[0]
    );
    this.partnerAssocDetails.created_date = this._formatService.formatDate(this.partnerAssocDetails.created_date);
    this.setPartnerAssocFields();
    this.partnerPetDetails = this.partnerAssocDetails.pet_details.map((pet) => ({ ...pet }));
    for (let i = 0; i < this.partnerPetDetails.length; i++) {
      this.partnerPetDetails[i].edit = false;
    }
  }

  parsePartnerAssocPetDetails(method, pet, response): void {
    const petDetails = pet;
    if (method === 'PUT') {
      const index = this.partnerPetDetails.findIndex((pets) => pets.pet_id ===
        petDetails.pet_id);
      if (index !== -1) {
        this.partnerPetDetails[index] = petDetails;
        this.partnerAssocDetails.pet_details[index] = petDetails;
      }
    } else {
      petDetails.pet_id = response.pet_id;
      this.partnerPetDetails.push(petDetails);
      this.partnerAssocDetails.pet_details.push(petDetails);
    }
  }

  static parseUrls(url): string {
    let parseUrl = null;
    if (url && url.indexOf('http://') === -1 && url.indexOf('https://') === -1) {
      parseUrl = `https://${url}`;
    }
    return parseUrl;
  }

  setAddressDetails(): void {
    if (this.partnerAssocDetails && this.partnerAssocDetails.address.length > 0) {
      this.addressRecord = _lodash.cloneDeep(this.partnerAssocDetails.address[0]);
    } else {
      this.addressRecord = {
        address_id: null,
        address_line_1: null,
        address_line_2: null,
        city: null,
        country: null,
        location_id: null,
        province: null,
        zip: null,
        lat: null,
        lng: null,
        type: null
      };
    }
    this.initializeAddressAutoComplete('address_1');
  }

  setDefaultCountry(): string {
    const orgId = this._cacheService.getOrgId();
    let country = '';
    if (orgId === 82) {
      country = 'IT';
    } else if (orgId === 83) {
      country = 'DE';
    } else if (orgId === 101) {
      country = 'FR';
    } else if (orgId === 181) {
      country = 'NL';
    }
    return country;
  }

  setFocusFields(fieldType): void {
    if (fieldType === 'donation') {
      this.focusQuantity = true;
      this.focusDonationDate = true;
    } else if (fieldType === 'website') {
      this.focusWebsite = true;
    } else if (fieldType === 'facebook') {
      this.focusFacebook = true;
    } else {
      this.focusInstagram = true;
    }
  }

  setInitFocusFields(): void {
    this.focusDonationDate = true;
    this.focusFacebook = false;
    this.focusInstagram = false;
    this.focusQuantity = true;
    this.focusWebsite = false;
    this.foodDonationDetails = { donation_date: '', quantity: null };
    this.partnerAssociationId = null;
    this.setAddressDetails();
    this.setPetDetails();
  }

  setPartnerAssocFields(): void {
    this.updatePartnerAssoc = {
      address: [this.addressRecord],
      association_id: null,
      association_name: null,
      facebook_url: null,
      instagram_url: null,
      no_of_livestock: null,
      org_id: this._cacheService.getOrgId(),
      partner_association_name: null,
      website_url: null,
      primary_sales: null,
      primary_certifications: null,
      product_types: null,
      created_by: null
    };
    if (this.partnerAssocDetails) {
      this.updatePartnerAssoc = _lodash.cloneDeep(this.partnerAssocDetails);
      this.updatePartnerAssoc.created_by = this.user.user_id;
    }
    this.setAddressDetails();
  }

  setPetDetails(): void {
    this.petDetails = {
      pet_name: '',
      pet_age: null,
      pet_race: '',
      health_rating: null,
      partner_association_id: null,
      tourist_attitude_rating: null,
      training_received: '',
      work_attitude_rating: null
    };
  }

  async updatePartnerAssocDetails() {
    if (!this.updatePartnerAssoc.partner_association_name || !this.addressRecord.address_line_1 ||
        !this.addressRecord.province || !this.addressRecord.city ||
        !this.addressRecord.country || !this.addressRecord.zip) {
      this.showError = true;
      return;
    }
    this.showSpinner = true;
    const validateFacebook = this.validateMaxLength(this.updatePartnerAssoc.facebook_url, 'facebook');
    const validateInstagram = this.validateMaxLength(this.updatePartnerAssoc.instagram_url, 'instagram');
    const validateWebsite = this.validateMaxLength(this.updatePartnerAssoc.website_url, 'website');
    if (!(validateFacebook || validateInstagram || validateWebsite)) {
      this.showSpinner = true;
      await this.validateUrl(this.updatePartnerAssoc.facebook_url, 'facebook');
      await this.validateUrl(this.updatePartnerAssoc.instagram_url, 'instagram');
      await this.validateUrl(this.updatePartnerAssoc.website_url, 'website');
    }
    if (this.focusFacebook || this.focusInstagram || this.focusWebsite) {
      this.showSpinner = false;
      return;
    }
    this.managePartnerAssociationDetails(this.updatePartnerAssoc);
  }

  updateToggleValue(toggle): void {
    if (toggle.id.includes('certifi')) {
      this.updatePartnerAssoc.primary_certifications[toggle.key] = toggle.value;
    } else if (toggle.id.includes('product')) {
      this.updatePartnerAssoc.product_types[toggle.key] = toggle.value;
    } else {
      this.updatePartnerAssoc.primary_sales[toggle.key] = toggle.value;
    }
  }

  validateMaxLength(value, fieldType): boolean {
    let result = false;
    const max_text = `Maximum Length of ${fieldType === 'instagram' ? 250 : 300} characters in ${fieldType} URL`;
    if (value) {
      if (fieldType === 'facebook') {
        this.focusFacebook = value.indexOf('facebook') === -1 || value.length >= 300;
        this.facebookMsg = value.length >= 300 ? max_text : 'Enter a valid facebook URL';
        result = true;
      } else if (fieldType === 'website') {
        this.focusWebsite = value.length >= 300;
        this.websiteMsg = value.length >= 300 ? max_text : 'Enter a valid Website';
        result = true;
      } else if (fieldType === 'instagram') {
        this.focusInstagram = value.indexOf('instagram') === -1 || value.length >= 250;
        this.instagramMsg = value.length >= 250 ? max_text : 'Enter a valid instagram page';
        result = true;
      }
    }
    return result;
  }

  validateParameters(partnertype): boolean {
    this.setFocusFields(partnertype);
    return (this.focusDonationDate && !this.foodDonationDetails.donation_date) ||
      (this.focusQuantity && !this.foodDonationDetails.quantity);
  }

  validateDonationDetails(): void {
    if (this.validateParameters('donation')) {
      this.focusQuantity = false;
      this.focusDonationDate = false;
      return;
    }
    this.showSpinner = true;
    this.foodDonationDetails.donation_date = this._formatService.parseDate(
      this.foodDonationDetails.donation_date
    ).toUpperCase();
    this.foodDonationDetails.partner_association_id = this.partnerAssocDetails.partner_association_id;
    this.foodDonationDetails.created_by = this.user.user_id;
    this.addDonationDialog = false;
    this.managePartnerAssociationDonationDetails();
  }

  validatePetDetails(display, pet): void {
    const petDetails = pet;
    this.showSpinner = true;
    if (Object.values(petDetails).includes('') || Object.values(petDetails).includes(null)) {
      this.focusEdit = true;
      this.showSpinner = false;
      return;
    }
    const method = display === 'add' ? 'POST' : 'PUT';
    petDetails.created_by = this.user.user_id;
    this.managePartnerAssociationPetDetails(method, pet);
  }

  validateUrl(url, fieldType): Promise<void> {
    return new Promise((resolve) => {
      if (url) {
        this._donationService.validateUrl({ url })
          .catch(() => {
            this.setFocusFields(fieldType);
          })
          .finally(() => {
            resolve();
          });
      } else {
        resolve();
      }
    });
  }
}
