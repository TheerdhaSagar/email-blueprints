import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerAssociationDetailsComponent } from './details.component';

describe('PartnerAssociationDetailsComponent', () => {
  let component: PartnerAssociationDetailsComponent;
  let fixture: ComponentFixture<PartnerAssociationDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PartnerAssociationDetailsComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerAssociationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
