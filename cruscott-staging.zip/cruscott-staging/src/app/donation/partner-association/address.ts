export interface AddressEntity {
  address?: string;
  address_id?: number;
  address_line_1: string;
  address_line_2: string;
  city: string;
  country: string;
  lat: number;
  location_id?: number;
  lng: number;
  phone?: string;
  province: string;
  type?: string;
  zip: number;
}
