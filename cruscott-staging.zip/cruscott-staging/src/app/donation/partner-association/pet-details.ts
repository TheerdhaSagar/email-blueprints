export interface PetDetailsEntity {
  created_by?: number;
  health_rating: number;
  partner_association_id: number;
  pet_age: number;
  pet_id?: number;
  pet_name: string;
  pet_race: string;
  tourist_attitude_rating: number;
  training_received: string;
  work_attitude_rating: number;
}
