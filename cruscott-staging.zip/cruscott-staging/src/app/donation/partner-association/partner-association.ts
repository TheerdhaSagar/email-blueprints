import { AddressEntity } from './address';
import { DonationDetailsEntity } from './donation-details';
import { PetDetailsEntity } from './pet-details';
import { Record } from './record';

export interface PartnerAssociation {
  address?: Array<AddressEntity> | null;
  association_id: number;
  association_name: string;
  biodiversity_impact?: Record<number>;
  created_by?: number;
  created_date?: string;
  donation_details?: (DonationDetailsEntity)[] | null;
  facebook_url?: string;
  instagram_url?: string;
  no_of_livestock?: number;
  org_id: number;
  partner_association_id?: number;
  partner_association_name: string;
  pet_details?: (PetDetailsEntity)[] | null;
  primary_certifications?: Record<boolean | string>;
  primary_sales?: Record<boolean | string>;
  product_types?: Record<boolean | string>;
  recent_updated_date?: string;
  status?: string;
  website_url?: string;
}

export interface PartnerSummary extends PartnerAssociation {
  address_line_1?: string;
  address_line_2?: string;
  city?: string;
  country?: string;
  province?: string;
  zip?: number;
}
