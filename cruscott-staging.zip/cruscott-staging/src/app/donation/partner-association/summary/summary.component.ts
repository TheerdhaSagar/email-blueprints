import {
  Component,
  OnInit,
  Injector,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { DonationService } from '../../donationservice/donation.service';
import { TabletemplateComponent } from '../../../globals/tabletemplate/tabletemplate.component';
import { PartnerSummary } from '../partner-association';
import { AddressEntity } from '../address';
import { Settings } from '../../../globals/tabletemplate/models/settings';
import { ColumnSettings } from '../../../globals/tabletemplate/models/layout';
import { User } from '../../../globals/user';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html'
})
export class PartnerAssociationSummaryComponent implements OnInit, OnDestroy {
  @ViewChild(TabletemplateComponent) child: TabletemplateComponent;

  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _donationService: DonationService = this.injector.get(DonationService);
  private _router: Router = this.injector.get(Router);

  address: AddressEntity;
  headerDetails: Array<ColumnSettings>;
  org_id: number;
  partnerAssocDetails: Array<PartnerSummary>;
  predicate: string;
  searchTerm: string;
  showSpinner: boolean;
  subOrgChange: Subscription;
  tableSettings: Settings;
  toggleFilter: (e?) => void;
  user: User;

  constructor(private injector: Injector) {
    this.partnerAssocDetails = [];
    this.predicate = 'partner_association_id';
    this.searchTerm = null;
    this.showSpinner = false;
    this.subOrgChange = null;
    this.tableSettings = new Settings({ headers: [] });
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.addHeaderDetails();
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']).then();
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.addTableProperties();
      }
    });
    this.loadSummaryPartnerAssociations();
    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this.showSpinner = true;
      this.loadSummaryPartnerAssociations();
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addHeaderDetails(): void {
    this.headerDetails = [
      {
        title: 'Partner Association Name',
        keyName: 'partner_association_name',
        redirect: 'partner_association_id',
        styles: { 'word-break': 'break-word', 'text-align': 'left' }
      },
      {
        title: 'Organization Name',
        keyName: 'association_name',
        redirect: 'association_id',
        styles: { 'word-break': 'break-word', 'text-align': 'left' }
      },
      { title: 'Address', keyName: 'address_line_1', styles: { 'word-break': 'break-word', 'text-align': 'left' } },
      { title: 'City', keyName: 'city' }, { title: 'Province', keyName: 'province' },
      { title: 'Country', keyName: 'country' }, { title: 'Zip', keyName: 'zip' },
      { title: 'Created Date', keyName: 'created_date', styles: { format: 'date' } }
    ];
  }

  addTableProperties(): void {
    this.tableSettings = new Settings({
      headers: this.headerDetails,
      sortHeader: true,
      predicate: this.predicate
    });
  }

  exportData(): void {
    this.toggleFilter();
    this.child.exportData('partner_association');
  }

  loadSummaryPartnerAssociations(): void {
    this.showSpinner = true;
    this._donationService.getSummaryHWPartnerAssociation(this._cacheService.getOrgId())
      .then((response) => {
        this.partnerAssocDetails = response;
        this.parsePartnerAssocDetails();
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.showSpinner = false;
      });
  }

  parsePartnerAssocDetails(): void {
    for (let i = 0; i < this.partnerAssocDetails.length; i++) {
      if (this.partnerAssocDetails[i].address.length) {
        this.partnerAssocDetails[i].address_line_1 = this.partnerAssocDetails[i].address[0].address_line_1;
        this.partnerAssocDetails[i].address_line_2 = this.partnerAssocDetails[i].address[0].address_line_2;
        this.partnerAssocDetails[i].province = this.partnerAssocDetails[i].address[0].province;
        this.partnerAssocDetails[i].city = this.partnerAssocDetails[i].address[0].city;
        this.partnerAssocDetails[i].country = this._donationService.findCountry(
          this.partnerAssocDetails[i].address[0].country
        );
        this.partnerAssocDetails[i].zip = this.partnerAssocDetails[i].address[0].zip;
      }
    }
  }

  redirectTo(event): void {
    if (event.key === 'partner_association_id') {
      this._appService.partnerAssociationId = event.value;
      this._router.navigate(['donation/partner-association/details']).then();
    } else {
      this._appService.associationId = event.value;
      this._cacheService.humansAndWildLifeRequest = 'humans-and-wild-life';
      this._appService.associationNavParent = 'donation/partner-association/summary';
      this._router.navigate(['donation/association/profile'],
        { queryParams: { project: 'humans-and-wild-life' } }).then();
    }
  }
}
