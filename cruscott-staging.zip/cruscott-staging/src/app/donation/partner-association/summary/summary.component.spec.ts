import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerAssociationSummaryComponent } from './summary.component';

describe('PartnerAssociationSummaryComponent', () => {
  let component: PartnerAssociationSummaryComponent;
  let fixture: ComponentFixture<PartnerAssociationSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartnerAssociationSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerAssociationSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
