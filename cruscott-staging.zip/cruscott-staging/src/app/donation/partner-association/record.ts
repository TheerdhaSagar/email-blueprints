export interface Record<T> {
  [key: string]: T;
}
