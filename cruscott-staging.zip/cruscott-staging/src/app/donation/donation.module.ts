import { NgModule } from '@angular/core';

import { AdoptionsComponent } from './adoptions/adoptions.component';
import { AssociationFinderComponent } from './association-finder/association-finder.component';
import { AssociationComponent } from './association/association.component';
import { DonationDashboardComponent } from './dashboard/dashboard.component';
import { ManageAdoptionComponent } from './manage/adoption/adoption.component';
import { ManageApplicationComponent } from './manage/application/application.component';
import { PartnerAssociationDetailsComponent } from './partner-association/details/details.component';
import { PartnerAssociationSummaryComponent } from './partner-association/summary/summary.component';
import { ProductMappingComponent } from './product-mapping/product-mapping.component';
import { AcaflMetricsComponent } from './reports/acafl-metrics/acafl-metrics.component';
import { DonationByProvinceDrillDownComponent } from './reports/byprovince-drilldown/byprovince-drilldown.component';
import { DonationProvinceReportComponent } from './reports/byprovince/byprovince.component';
import { DonationReportDashboardComponent } from './reports/dashboard/dashboard.component';
import { DonationDrillDownComponent } from './reports/drilldown/drilldown.component';
import { DonationMonthlyReportComponent } from './reports/monthly/monthly.component';
import { DonationReportsComponent } from './reports/reports.component';
import { ApplicationSummaryComponent } from './summary/summary.component';
import { DonationUsersComponent } from './users/users.component';

import { DonationRoutingModule } from './donation-routing.module';
import { ShareModule } from '../share/share.module';
import { StarRatingComponent } from '../globals/star-rating/star-rating.component';

@NgModule({
  declarations: [
    AcaflMetricsComponent,
    AdoptionsComponent,
    ApplicationSummaryComponent,
    AssociationComponent,
    AssociationFinderComponent,
    DonationByProvinceDrillDownComponent,
    DonationDashboardComponent,
    DonationDrillDownComponent,
    DonationMonthlyReportComponent,
    DonationProvinceReportComponent,
    DonationReportsComponent,
    DonationReportDashboardComponent,
    DonationUsersComponent,
    ManageAdoptionComponent,
    ManageApplicationComponent,
    PartnerAssociationDetailsComponent,
    PartnerAssociationSummaryComponent,
    ProductMappingComponent,
    StarRatingComponent
  ],
  imports: [
    DonationRoutingModule,
    ShareModule
  ]
})
export class DonationModule { }
