export interface PetDetails {
  created_date: string;
  no_of_meals?: string;
  no_of_pets: number;
  no_of_qty: number;
  pet_size: string;
  pet_type: string;
  recent_update_date: string;
  request_line_id: number;
}
