import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';
import { ServerError } from '../../../globals/server.error';
import { APIError } from '../../../globals/api.error';

declare const FooPicker;

@Component({
  selector: 'app-donation-manage-adoption',
  templateUrl: './adoption.component.html',
  styleUrls: ['./adoption.component.scss']
})
export class ManageAdoptionComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  adoption: any;
  adoptionId: any;
  attachments: any;
  dateFormat: string;
  pageDim: any;
  petAges: any[];
  petSizes: any[];
  petTypes: any[];
  readOnly: boolean;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.adoption = null;
    this.adoptionId = null;
    this.attachments = null;
    this.dateFormat = null;
    this.pageDim = null;
    this.petAges = [{
      age: 'PUPPY',
      label: 'Puppy'
    }, {
      age: 'ADULT',
      label: 'Adult'
    }];
    this.petSizes = [{
      size: 'SMALL',
      label: 'Small'
    }, {
      size: 'MEDIUM',
      label: 'Medium'
    }, {
      size: 'BIG',
      label: 'Big'
    }];
    this.petTypes = [{
      type: 'CAT',
      label: 'Cat'
    }, {
      type: 'DOG',
      label: 'Dog'
    }];
    this.readOnly = true;
    this.user = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.dateFormat = this._cacheService.getUserDateFormat();

        if (this._appService.adoptionId) {
          this.adoptionId = this._appService.adoptionId;
          this._appService.adoptionId = null;
          this.loadAdoption();
        } else {
          this._router.navigate(['donation/adoptions']);
        }
      }
    });
  }

  backToSummary() {
    if (this._appService.adoptionNavParent) {
      this._router.navigate([this._appService.adoptionNavParent]);
    } else {
      this._router.navigate(['donation/adoptions']);
    }
  }

  downloadDocument(document): void {
    if (!document) {
      return;
    }

    const endPoint = `/donation/adoption/documents/${this.adoption.adoption_id}/${document.attachment_id}/`;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (data && data.status === 'OK') {
        document.file_data = data.result[0].file_data;
        this.downloadFile(document);
      } else {
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  downloadFile(attachment) {
    let blob = this._formatService.base64ToBlob(attachment.file_data, attachment.file_type);
    let url = this._window.URL.createObjectURL(blob),
      a = document.createElement('a');
    document.body.appendChild(a);
    a.style.display = 'none';
    a.href = url;
    a.download = attachment.file_name;
    a.click();
  }

  loadAdoption() {
    let endPoint = '/donation/adoptions/' + this.adoptionId + '/';
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadAdoption()' });
      } else if (data.status && data.status !== 'OK') {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        const adoption = data.result[0];
        adoption.f_adoption_date = this._formatService.formatDate(adoption.adoption_date, this.dateFormat);
        adoption.created_date = this._formatService.formatDate(adoption.created_date);
        adoption.pet_parent_name = this._formatService.removeEscapeCharacter(adoption.pet_parent_name);
        adoption.org_name = this._formatService.removeEscapeCharacter(adoption.org_name);
        adoption.pet_name = this._formatService.removeEscapeCharacter(adoption.pet_name);
        adoption.old_email = adoption.email;

        const { attachments } = adoption;
        for (let i = 0; i < attachments.length; i++) {
          attachments[i].f_create_date = this._formatService.formatDate(attachments[i].create_date);
        }

        this.adoption = adoption;
        this.attachments = attachments;
        setTimeout(() => {
          new FooPicker({
            id: 'pp-adoption-date',
            dateFormat: this.dateFormat
          });
        }, 10);
      }
    });
  }

  resendEmail(): void {
    const endPoint = '/donation/adoption/resend/';
    const reqObject = {
      adoption_id: this.adoption.adoption_id,
      email: this.adoption.email
    };
    this._httpService.httpRequest('POST', endPoint, reqObject, (data) => {
      if (!data) {
        this._appService.notify(new ServerError('Resend email'));
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else {
        this._appService.notify({ msg: data.msg, status: 0 });
      }
    });
  }

  updateDetails() {
    const endPoint = '/donation/register/pet_parent/';
    this.adoption.user_id = this.user.user_id;
    this.adoption.name = this.adoption.pet_parent_name;
    this.adoption.comments = this.adoption.comments || '';
    this.adoption.place_of_birth = '';
    this.adoption.date_of_birth = '';
    this.adoption.place_date = '';
    this.adoption.adoption_date = this.adoption.f_adoption_date ?
      this._formatService.parseDate(this.adoption.f_adoption_date) : '';
    this.adoption.assoc_name = this.adoption.org_name;
    this.adoption.assoc_address = this.adoption.address;
    this.adoption.assoc_email = this.adoption.email;
    this.adoption.attachments = [];
    this.pageDim = true;
    this._httpService.httpRequest('PUT', endPoint, this.adoption, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - updateDetails()' });
      } else {
        const status = data.status && data.status === 'OK' ? 0 : 1;
        this._appService.notify({ status, msg: data.msg });

        if (status === 0) {
          this.readOnly = true;
        }
      }
    });
  }
}
