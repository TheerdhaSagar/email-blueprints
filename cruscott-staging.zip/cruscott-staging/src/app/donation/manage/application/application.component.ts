import {
  Component,
  ElementRef,
  Injector,
  OnInit,
  ViewChild,
} from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { DataService } from '../../../globals/data.service';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';
import { DonationService } from '../../donationservice/donation.service';
import { Application } from '../../application';
import { APIError } from '../../../globals/api.error';
import { CommonService } from 'src/app/globals/common.service';
import { OrderByPipe } from 'src/app/globals/order-by.pipe';

declare const MSBlobBuilder;

@Component({
  selector: 'app-donation-manage-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.scss'],
})
export class ManageApplicationComponent implements OnInit {
  @ViewChild('appDocUpload') appDocUpload: ElementRef;
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _commonService: CommonService = this.injector.get(CommonService);
  private _dataService: DataService = this.injector.get(DataService);
  private _donationService: DonationService = this.injector.get(
    DonationService
  );
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _sce: DomSanitizer = this.injector.get(DomSanitizer);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  address1: any;
  address2: any;
  address3: any;
  addressVerified: any;
  addressVerifyError: any;
  allApplications: Array<Application>;
  application: any;
  applicationId: any;
  applicationName: string;
  approvalStatus: any;
  auditLog: any;
  cancelDialog: boolean;
  carrierNote: any;
  city: any;
  comment: any;
  copyConfirm: boolean;
  copyStatus: boolean;
  countries: any;
  country: any;
  currentStep: any;
  document: any;
  documentType: any;
  documentTypes: any;
  editCatMeals = false;
  editDogMeals = false;
  editLineType: any;
  editOrganization = false;
  f_address1: any;
  f_carrierNote: string;
  f_city: any;
  f_country: any;
  f_province: any;
  f_zipCode: any;
  fileConfirm: any;
  fileData: any;
  fileDialog: any;
  focuscomment: any;
  focusMessage: any;
  informUser: any;
  kitsLov: number[];
  msgToUser: any;
  newLine: any;
  noOfMeals: any;
  orgId: any;
  orgs: any[];
  organization: number;
  pageDim: boolean;
  petAges: any;
  petDetails: any[];
  petSizes: any;
  province: any;
  quoteName: any;
  requestType: any;
  roles: any;
  selectedAttachment: any;
  showAddressDialog: any;
  showApprovalControls: any;
  showCommentDialog: any;
  showDialog: any;
  showNewLine: boolean;
  user: any;
  viewLog: boolean;
  zipCode: any;

  constructor(private injector: Injector) {
    this._window = window;

    this.address1 = null;
    this.address2 = null;
    this.address3 = null;
    this.addressVerified = null;
    this.addressVerifyError = null;
    this.allApplications = [];
    this.application = {};
    this.applicationId = null;
    this.applicationName = '';
    this.auditLog = null;
    this.cancelDialog = false;
    this.carrierNote = null;
    this.city = null;
    this.comment = null;
    this.copyStatus = true;
    this.countries = null;
    this.country = null;
    this.currentStep = null;
    this.document = null;
    this.documentType = null;
    this.documentTypes = null;
    this.editLineType = null;
    this.f_address1 = null;
    this.f_city = null;
    this.f_country = null;
    this.f_province = null;
    this.f_zipCode = null;
    this.fileConfirm = null;
    this.fileData = null;
    this.fileDialog = null;
    this.focuscomment = null;
    this.focusMessage = null;
    this.informUser = null;
    this.msgToUser = null;
    this.newLine = null;
    this.noOfMeals = null;
    this.orgs = [];
    this.orgId = this._dataService.orgId;
    this.pageDim = null;
    this.petDetails = [
      {
        type: 'DOG',
        label: 'Dog',
        sizes: [
          {
            size: 'SMALL',
            label: 'Small',
          },
          {
            size: 'MEDIUM',
            label: 'Medium',
          },
          {
            size: 'LARGE',
            label: 'Large',
          },
        ],
        ages: [
          {
            age: 'PUPPY',
            label: 'Puppy',
          },
          {
            age: 'ADULT',
            label: 'Adult',
          },
        ],
      },
      {
        type: 'CAT',
        label: 'Cat',
        sizes: [
          {
            size: 'KITTEN',
            label: 'Kitten',
          },
          {
            size: 'CAT',
            label: 'Cat',
          },
        ],
      },
    ];
    this.province = null;
    this.quoteName = null;
    this.requestType = null;
    this.roles = this._dataService.roles;
    this.selectedAttachment = null;
    this.showAddressDialog = null;
    this.showApprovalControls = null;
    this.showCommentDialog = null;
    this.showDialog = null;
    this.showNewLine = false;
    this.user = null;
    this.viewLog = false;
    this.zipCode = null;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.kitsLov = [];
        for (let i = 0; i < 20; i++) {
          this.kitsLov.push(12 * (i + 1));
        }
        this.loadOrgs();
        if (this._appService.requestHeaderId) {
          this.applicationId = this._appService.requestHeaderId;
          this.showApprovalControls = false;
          this._appService.requestHeaderId = null;
          this.loadApplication();
          this.loadCountries();
          this.loadDocumentTypes();
          this.loadAuditLog();
        } else if (
          this._cacheService.humansAndWildLifeRequest === 'humans-and-wild-life'
        ) {
          this._router.navigate(['donation/applications'], {
            queryParams: { project: 'humans-and-wild-life' },
          });
        } else {
          this._router.navigate(['donation/applications']);
        }
      }
    });
  }

  // Provide an option to add a new pet
  addLine() {
    this.newLine = { pet_type: this.petDetails[0].type };
    if (this.application.request_type === 'A') {
      this.setSizes();
    }
    this.showNewLine = true;
  }

  backToSummary(): void {
    let state;
    if (this._appService.applicationNavParent) {
      state = this._appService.applicationNavParent;
    } else {
      state = 'donation/applications';
    }
    if (
      this._cacheService.humansAndWildLifeRequest === 'humans-and-wild-life'
    ) {
      this._router.navigate([state], {
        queryParams: { project: 'humans-and-wild-life' },
      });
    } else {
      this._router.navigate([state]);
    }
  }

  /*
   * Calculate estimated no. of meals/quantity to be
   * donated based on the no. of cats/dogs
   *
   * For Love Food 1 meal is
   * Cat => 110g wet, 30g dry
   * Dog => 30g dry
   *
   * For Adopt Me 1 meal is
   * Cat => 100g wet, 30g dry & (1 bag of Cat litter for 30 days)
   * Dog => XS/S -> 70g wet, 80g dry
   *        M -> 200g dry
   *        L -> 350g dry
   *
   * For Humans & Wild Life 1 meal is
   * Dog => 500g Dry
   */
  calculateMeals() {
    let lines = this.application.lines,
      catWetFood,
      catDryFood,
      dogWetFood,
      dogDryFood,
      petCount,
      noOfMeals = 30, // For 30 days
      petSize,
      catWetMeals,
      catDryMeals,
      catMeals = 0,
      dogMeals = 0;
    // L - Donation AdoptMe, DL - Donation LoveFood, A - Welcome Kit Adopt Me, H - Humans & Wild Life
    if (
      this.application.request_type === 'L' ||
      this.application.request_type === 'DL' ||
      this.application.request_type === 'LB'
    ) {
      catWetFood = 110; // 110g wet food
      catDryFood = 30; // 30g dry food
      dogDryFood = 300; // 300g dry food
    } else if (this.application.request_type === 'H') {
      dogDryFood = 500;
      noOfMeals = 120;
    } else {
      catWetFood = 100; // 100g wet food
      catDryFood = 30; // 30g dry food
    }
    // this.application.cat_meals = 0;
    // this.application.dog_meals = 0;
    for (let i = 0; i < lines.length; i++) {
      petCount = parseInt(lines[i].no_of_pets) || 0;
      dogWetFood = 0;
      if (lines[i].pet_type === 'CAT') {
        catWetMeals = catWetFood * petCount * noOfMeals;
        catDryMeals = catDryFood * petCount * noOfMeals;

        if (catWetMeals && catDryMeals) {
          lines[i].no_of_meals =
            catWetMeals / 1000 +
            ' Kg Wet, ' +
            catDryMeals / 1000 +
            ' Kg Dry Food';
        }

        if (this.application.request_type === 'A') {
          catMeals += petCount;
        } else {
          catMeals += petCount * noOfMeals;
        }
      } else {
        if (this.application.request_type === 'A') {
          // we have 3 pet sizes XS/S - Small, M - Medium, L - Large
          petSize = lines[i].pet_size;
          if (petSize) {
            if (petSize.indexOf('PUPPY') !== -1 || petSize === 'ADULT-SMALL') {
              dogWetFood = 70 * petCount * noOfMeals; // 70g wet food
              dogDryFood = 80; // 80g dry food
            } else if (petSize === 'ADULT-MEDIUM') {
              dogDryFood = 200; // 200g dry food
            } else if (petSize === 'ADULT-LARGE') {
              dogDryFood = 350; // 350g dry food
            }
          }
        }
        dogDryFood *= petCount * noOfMeals;

        if (dogWetFood && dogDryFood) {
          lines[i].no_of_meals =
            dogWetFood / 1000 +
            ' Kg Wet, ' +
            dogDryFood / 1000 +
            ' Kg Dry Food';
        } else if (dogDryFood) {
          lines[i].no_of_meals = dogDryFood / 1000 + ' Kg Dry Food';
        }

        if (this.application.request_type === 'A') {
          dogMeals += petCount;
        } else {
          dogMeals += petCount * noOfMeals;
        }
      }
    }

    if (
      (!this.application.cat_meals && !this.editLineType) ||
      this.editLineType === 'CAT'
    ) {
      this.application.cat_meals = catMeals;
    }

    if (
      (!this.application.dog_meals && !this.editLineType) ||
      this.editLineType === 'DOG'
    ) {
      this.application.dog_meals = dogMeals;
    }

    this.noOfMeals =
      parseInt(this.application.dog_meals || 0) +
      parseInt(this.application.cat_meals || 0);
  }

  cancelApplication() {
    this.approvalStatus = 'C';
    this.changeStatus(this.approvalStatus);
  }

  changeStatus(status) {
    if (
      status !== 'R' &&
      status !== 'C' &&
      (this.application.request_status === 'U' ||
        this.application.request_status === 'R') &&
      !this.addressVerified
    ) {
      this.addressVerifyError = true;
      this._appService.notify({
        status: 1,
        msg: 'Please verify shipping address before approving the application',
      });
      return;
    }
    let endPoint = '/donation/application/update/';
    let wfName = this.getWorkflowName(this.application.request_type);
    let addressVerified;
    let noOfCats, noOfDogs;
    for (let i = 0; i < this.application.lines.length; i++) {
      if (this.application.lines[i].pet_type === 'CAT') {
        noOfCats = this.application.lines[i].no_of_pets;
      } else {
        noOfDogs = this.application.lines[i].no_of_pets;
      }
    }

    if (
      status === 'A' &&
      (this.application.request_status === 'U' ||
        this.application.request_status === 'R') &&
      this.addressVerified
    ) {
      addressVerified = 'Y';
    } else {
      addressVerified = this.application.address_verified;
    }

    let req = {
      header_id: this.applicationId,
      user_id: this.user.user_id,
      status,
      appl_no: this.application.application_no,
      comments: this.comment || '',
      user: this.user.user_description,
      inform_user: this.informUser || '',
      user_msg: this.msgToUser || '',
      dog_count: noOfDogs || 0,
      cat_count: noOfCats || 0,
      wf_name: wfName,
      lines: this.application.lines,
      address_verified: addressVerified,
    };
    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: changeStatus()',
        });
      } else if (data.status === 'OK') {
        this._appService.notify({ status: 0, msg: data.msg });
        this.showApprovalControls = false;
        this.cancelDialog = false;
        if (!data.hasOwnProperty('approver_id')) {
          this.application.request_status = status;
        } else {
          if (
            this.roles.hasForceApproveDonation &&
            data.approver_id === this.user.user_id
          ) {
            this.showApprovalControls = true;
          }
        }
        this.loadAuditLog();
      } else {
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  changeStep(step) {
    if (step === 2) {
      if (!this.validate()) {
        this._appService.notify({
          status: 1,
          msg: 'Please fill all mandatory fields',
        });
        return;
      }
    }
    this.currentStep = step;
  }

  closeAddressDialog() {
    this.showAddressDialog = false;
  }

  closeDialog() {
    this.showDialog = false;
  }

  closeFileDialog() {
    this.document = null;
    this.documentType = '';
    this.fileDialog = false;
    this.appDocUpload.nativeElement.value = null;
  }

  copyApplication(requestType?: string): void {
    let endPoint = '/donation/application/copy/',
      req = { ...this.application },
      lines = [];
    if (requestType) {
      req.request_type = requestType;
      req.is_copy = 'N';
    } else {
      req.is_copy = 'Y';
    }
    req.user_name = req.user_name || '';
    req.need_desc = req.need_desc || '';
    for (let i = 0; i < req.lines.length; i++) {
      let petType = req.lines[i].pet_type;
      let index = lines.map((x) => x.pet_type).indexOf(petType);
      if (index === -1) {
        req.lines[i].pet_size = null;
        lines.push(req.lines[i]);
      } else {
        lines[index].no_of_pets += req.lines[i].no_of_pets;
      }
    }
    req.lines = lines;
    req.wf_name = this.getWorkflowName(requestType);
    req.user_id = this.user.user_id;
    req.assoc_type = req.association_type || '';
    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - copyApplication()',
        });
      } else if (data.hasOwnProperty('status')) {
        this._appService.notify({
          status: data.status,
          msg: JSON.stringify(data.msg),
        });
        if (data.status === 0) {
          if (
            this._cacheService.humansAndWildLifeRequest ===
            'humans-and-wild-life'
          ) {
            this._router.navigate(['donation/applications'], {
              queryParams: { project: 'humans-and-wild-life' },
            });
          } else {
            this._router.navigate(['donation/applications']);
          }
        }
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  createOrder() {
    let dogMeals = this.application.dog_meals,
      catMeals = this.application.cat_meals;
    if (this.carrierNote && this.carrierNote.length > 180) {
      return;
    }

    if (!dogMeals && !catMeals) {
      this._appService.notify({ status: 1, msg: 'Please enter no. of meals' });
      return;
    }

    if (dogMeals && isNaN(parseInt(dogMeals))) {
      this.application.dog_meals = null;
      this._appService.notify({
        status: 1,
        msg: 'Please enter valid no. of dog meals',
      });
      return;
    }

    if (catMeals && isNaN(parseInt(catMeals))) {
      this.application.cat_meals = null;
      this._appService.notify({
        status: 1,
        msg: 'Please enter valid no. of cat meals',
      });
      return;
    }

    let endPoint = '/donation/address/add/';
    let req: any = {};
    req.address1 = this.address1.toUpperCase().trim();
    req.address2 = this.address2 ? this.address2.toUpperCase().trim() : '';
    req.address3 = this.address3 ? this.address3.toUpperCase().trim() : '';
    req.city = this.city.toUpperCase().trim();
    req.town = this.province ? this.province.toUpperCase().trim() : '';
    req.country = this.country.toUpperCase().trim();
    req.postal_code = this.zipCode
      ? this.zipCode.toString().toUpperCase().trim()
      : '';
    req.org_id = this._cacheService.getOrgId() || this.orgId;
    req.assoc_name = this.application.org_name.toUpperCase().trim();
    req.quote_name =
      this.quoteName ||
      'Donation application: ' + this.application.application_no;
    req.request_id = this.application.request_header_id;
    req.request_type = this.application.request_type;
    req.phone_number = this.getContactPhoneNumber();
    let carrierNoteContact =
      'PRENOTARE SCARICO 1 GIORNO PRIMA AL N. ' +
      this.application.contact_phone;
    if (this.carrierNote) {
      req.carrier_note = this.carrierNote.trim() + ' - ' + carrierNoteContact;
    } else {
      req.carrier_note = carrierNoteContact;
    }
    req.dog_meals = parseInt(dogMeals) || '';
    req.cat_meals = parseInt(catMeals) || '';
    req.org_type = this.application.association_type || 'O';
    req.user_id = this.user.user_id;
    this.showDialog = false;

    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: createAddress()',
        });
      } else if (data.hasOwnProperty('status')) {
        if (data.status === 'OK') {
          this._appService.notify({ status: 0, msg: data.msg });
          this.loadApplication();
          this.loadAuditLog();
        } else {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      }

      this.pageDim = false;
    });
  }

  deleteDocument() {
    let attachment = this.selectedAttachment;
    let index = this.application.attachments.indexOf(attachment);
    if (index === -1) {
      return;
    }

    this.application.attachments.splice(index, 1);
    this.fileConfirm = false;
    this.selectedAttachment = null;
    let endPoint =
      '/donation/document/' +
      attachment.atthmt_id +
      '/' +
      this.applicationId +
      '/';
    endPoint += this.user.user_id + '/';
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: deleteDocument()',
        });
      } else if (
        data.status &&
        (data.status === 'ERROR' || data.status === 1)
      ) {
        this._appService.notify({ status: 1, msg: data.msg });
        this.application.attachments.push(attachment);
      } else {
        this.loadAuditLog();
      }
    });
  }

  downloadAttachment(attachment): void {
    if (attachment.file_data) {
      this.downloadFile(attachment);
    } else {
      const endPoint = `/donation/application/docs/download/${this.applicationId}/${attachment.atthmt_id}/`;
      this.pageDim = true;
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error: downloadAttachment()',
          });
        } else if (data.status === 'OK') {
          attachment.file_data = data.result[0].file_data;
          this.downloadFile(attachment);
        } else {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      });
    }
  }

  downloadFile(attachment): void {
    this.fileData = attachment.file_data;
    // Convert blob to base64 formatHelper
    const blobFile = this._formatService.base64ToBlob(
      this.fileData,
      attachment.file_type
    );
    if (this._appService.isIE()) {
      const builder = new MSBlobBuilder();
      builder.append(blobFile);

      const blob = builder.getBlob(attachment.file_type);
      window.navigator.msSaveBlob(blob, attachment.file_name);
    } else {
      const url = this._window.URL.createObjectURL(blobFile);
      const a = document.createElement('a');
      document.body.appendChild(a);
      a.style.display = 'none';
      a.href = url;
      a.download = attachment.file_name;
      a.click();
    }
  }

  downloadShippingDocument() {
    let endPoint =
      '/donation/documents/shipping/' +
      this.application.quote_number +
      '/' +
      this.orgId +
      '/';
    endPoint += '?delivery=N';
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - downloadShippingDocument()',
        });
      } else if (data.status && data.status !== 'OK') {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (data.file_data) {
        const attachment = {
          file_name: 'Bolla #' + this.application.waybill + '.pdf',
          file_data: data.file_data,
          file_type: 'application/pdf',
        };

        this.downloadFile(attachment);
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  fileConfirmDialog(attachment): void {
    this.selectedAttachment = attachment;
    this.fileConfirm = true;
  }

  formatAddress(data) {
    let formattedAddress =
      data.address + '<br/>' + data.zip + ' ' + data.city + ' ';
    if (data.province) {
      formattedAddress += data.province + '<br/>';
    }
    formattedAddress += data.country === 'IT' ? 'ITALY' : data.country;
    formattedAddress += '<br/>Tel: ' + (data.phone || '-');
    return this._sce.bypassSecurityTrustHtml(formattedAddress.toUpperCase());
  }

  getContactPhoneNumber(): string {
    return (
      (this.application.contact_phone
        ? this.application.contact_phone.toString().trim()
        : '') ||
      (this.application.phone ? this.application.phone.toString().trim() : '')
    );
  }

  getDocumentType(documentType): string {
    if (!this.documentTypes) {
      return '';
    }
    let docType: string;
    const index = this.documentTypes
      .map((x) => x.lookup_key)
      .indexOf(documentType);

    if (index !== -1) {
      docType = this.documentTypes[index].lookup_value;
    }
    return docType;
  }

  getOrgName(orgId): string {
    return this.orgs.length
      ? this.orgs.find((org) => org.organization_id === orgId).name
      : '';
  }

  getWorkflowName(requestType?): string {
    if (this.application.workflow_name) return this.application.workflow_name;

    if (requestType === 'H') return 'QPEX_DDESK_HW_IT';

    if (
      this.application.country === 'BE' ||
      this.application.country === 'BE_FR' ||
      this.application.country === 'BE_NL'
    ) {
      return this.getWorkflowNameForBE(requestType);
    }

    return this.getOrgWorkflowName();
  }

  getOrgWorkflowName(): string {
    switch (this.orgId) {
      case 82:
        return 'QPEX_DDESK_LF_IT';
      case 101:
        return 'QPEX_DDESK_LF_FR';
      case 181:
        return 'QPEX_DDESK_LF_NL';
      case 83:
        return 'QPEX_DDESK_LF_DE';
      case 84:
        return `QPEX_DDESK_LF_${this.application.country}_${this.application.language}`;
      default:
        return '';
    }
  }

  getWorkflowNameForBE(requestType?): string {
    if (requestType === 'DL' || requestType === 'LB') {
      return 'QPEX_DDESK_LF_IT';
    }
    if (requestType === 'A') {
      return 'QPEX_DDESK_LF_NL';
    }
    if (
      this.application.application_no.indexOf('BE_NL') !== -1 ||
      (this.application.country === 'BE' && this.application.language === 'NL')
    ) {
      return 'QPEX_DDESK_LF_BE_NL';
    }
    return 'QPEX_DDESK_LF_BE_FR';
  }

  loadApplication() {
    let endPoint = '/donation/applications/' + this.applicationId + '/';
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error: loadApplication()',
          });
        } else if (data.status === 'OK') {
          this.application = data.result[0];
          this.application.f_created_date = this._formatService.formatDate(
            this.application.created_date
          );
          this.application.f_application_no = this._formatService.removeEscapeCharacter(
            this.application.application_no
          );
          if (this.application.website_url) {
            if (
              this.application.website_url.indexOf('http://') === -1 &&
              this.application.website_url.indexOf('https://') === -1
            ) {
              this.application.website_url =
                'http://' + this.application.website_url;
            }
          }
          if (this.application.facebook_page) {
            if (
              this.application.facebook_page.indexOf('http://') === -1 &&
              this.application.facebook_page.indexOf('https://') === -1
            ) {
              this.application.facebook_page =
                'https://' + this.application.facebook_page;
            }
          }
          this.application.org_name = this._formatService.removeEscapeCharacter(
            this.application.org_name
          );
          this.application.comments = this._formatService.removeEscapeCharacter(
            this.application.comments
          );
          this.application.formatted_address = this.formatAddress(
            this.application
          );
          this._donationService.formatAttachmentName(
            this.application.attachments
          );
          if (this.application.ship_address) {
            let shipAddress = this.application.ship_address
              .toUpperCase()
              .split('@@');
            this.address1 = shipAddress[0];
            this.city = shipAddress[1];
            if (shipAddress.length === 5) {
              this.province = shipAddress[2];
              this.zipCode = shipAddress[3];
              this.country = shipAddress[4];
            } else {
              this.zipCode = shipAddress[2];
              this.country = shipAddress[3];
            }
          } else {
            this.address1 = this.application.address.toUpperCase();
            this.city = this.application.city.toUpperCase();
            this.province = this.application.province
              ? this.application.province.toUpperCase()
              : '';
            this.country = this.application.country.toUpperCase();
            this.zipCode = this.application.zip.toUpperCase();
          }
          this.application.contact_phone = this.getContactPhoneNumber();
          this.f_address1 = this.address1;
          this.f_city = this.city;
          this.f_province = this.province;
          this.f_country = this.country;
          this.f_zipCode = this.zipCode;
          this.f_carrierNote = this.application.carrier_note;
          this.carrierNote = this.application.carrier_note;
          switch (this.application.request_type) {
            case 'L':
              this.requestType = 'Donation AdoptMe';
              break;
            case 'A':
              this.requestType = 'Welcome Kit AdoptMe';
              break;
            case 'H':
              this.requestType = 'Habitat';
              break;
            case 'DL':
              this.requestType = 'Donation LoveFood';
              break;
            case 'LB':
              this.requestType = 'Donation LoveFood Bank';
              break;
            default:
              break;
          }

          if (
            this.application.request_status !== 'A' &&
            this.application.request_status !== 'O'
          ) {
            this.showApprovalControls =
              this.user.user_id === this.application.approver_id ||
              this.roles.hasForceApproveDonation ||
              this.application.request_status === 'R';
          }

          if (this.application.quote_number) {
            this.loadShippingDetails();
          }

          this.calculateMeals();
          this.loadAllApplications();
        } else {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadAllApplications(): void {
    this.pageDim = true;
    let endPoint = `/donation/applications/?assoc_id=${this.application.org_id}`;
    endPoint +=
      this._cacheService.humansAndWildLifeRequest === 'humans-and-wild-life' ||
      this._cacheService.humansAndWildLifeRequest === 'donation-request'
        ? '&org_type=humansandwildlife'
        : '';
    this._donationService
      .loadApplications(endPoint)
      .then((response) => {
        this.allApplications = response;
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  loadAuditLog(): void {
    if (!this.applicationId) {
      return;
    }
    const endPoint = `/donation/application/log/${this.applicationId}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadAuditLog()',
        });
      } else if (data.status === 'ERROR') {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        const result = data.result;
        for (let i = 0; i < result.length; i++) {
          result[i].f_creation_date = this._formatService.formatDate(
            result[i].created_date
          );
        }
        this.auditLog = data.result;
      }
    });
  }

  loadCountries(): void {
    const endPoint = '/registration/countries/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error: loadCountries()',
          });
        } else if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          this.countries = data;
        }
      } catch (e) {
        this._appService.notify({
          msg: e.message,
          status: 1,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadDocumentTypes() {
    let endPoint = '/donation/lookup/DOCUMENTS/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadDocumentTypes()',
        });
      } else if (data.status === 'ERROR' || data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.documentTypes = data.result;
      }
    });
  }

  // Load all organizations
  loadOrgs(): void {
    this._commonService.loadOrgs((data) => {
      this.orgs = data;
      this.orgs.push({ name: 'All', organization_id: '' });
      this.orgs = this._orderBy.transform(this.orgs, 'name', false);
    });
  }

  loadShippingDetails(): void {
    const endPoint = '/donation/application/details/shipping/';
    const req = {
      org_id: this.application.almo_org_id || this._cacheService.getOrgId(),
      quote_number: this.application.quote_number,
    };
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadShippingDetails()',
        });
      } else if (data.status && data.status !== 'OK') {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        const result =
          data.result && data.result.length > 0 ? data.result[0] : false;
        if (result) {
          this.application.waybill = result.waybill;
          this.application.invoice_number = result.trx_number;
          this.application.delivery_id = result.delivery_id;
        }
      }
    });
  }

  onAddressChange() {
    if (this.addressVerified) {
      this.addressVerifyError = false;
    }
  }

  openCancelDialog() {
    this.cancelDialog = true;
  }

  openDialog() {
    this.showDialog = true;
    this.currentStep = 1;
  }

  openShippingAddressDialog() {
    this.f_address1 = this.address1;
    this.f_city = this.city;
    this.f_province = this.province;
    this.f_country = this.country;
    this.f_zipCode = this.zipCode;
    this.f_carrierNote = this.carrierNote;
    this.showAddressDialog = true;
  }

  openQuote() {
    let endPoint = '/quotes/headerid/' + this.application.quote_header_id + '/';
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: openQuote()',
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (data && data.length > 1) {
        this._appService.editQuote = true;
        this._appService.quoteHeader = data[1];
        this._appService.fromDonation = true;
        this._router.navigate(['quotes/manage']);
      } else {
        this._appService.notify({ status: 1, msg: 'Unable to open the Quote' });
      }
    });
  }

  setSizes() {
    if (this.newLine.pet_type === 'DOG') {
      this.petSizes = this.petDetails[0].sizes;
      this.petAges = this.petDetails[0].ages;
      this.newLine.pet_age = this.petAges[0].age;
    } else {
      this.petSizes = this.petDetails[1].sizes;
    }
    this.newLine.pet_size = this.petSizes[0].size;
  }

  submitLine() {
    if (this.newLine.no_of_pets) {
      this.newLine.isNewLine = true;
      this.newLine.request_line_id = '';
      this.newLine.no_of_qty = '';
      if (this.application.request_type === 'A') {
        this.newLine.pet_size =
          this.newLine.pet_type === 'DOG'
            ? this.newLine.pet_age + '-' + this.newLine.pet_size
            : this.newLine.pet_size;
      } else {
        this.newLine.pet_size = null;
      }
      this.updateLine(this.newLine);
      this.showNewLine = false;
    } else if (this.newLine.no_of_pets < 1) {
      this._appService.notify({
        msg: 'No. of pets should be greater than 0',
        status: 1,
      });
    } else {
      this._appService.notify({
        msg: 'Please enter No. of pets value',
        status: 1,
      });
    }
  }

  updateAddress() {
    if (
      !this.f_address1 ||
      !this.f_city ||
      !this.f_zipCode ||
      !this.f_country
    ) {
      this._appService.notify({
        status: 1,
        msg: 'Please fill all mandatory fields',
      });
      return;
    }

    if (this.f_carrierNote && this.f_carrierNote.length > 180) {
      this._appService.notify({
        status: 1,
        msg: 'Carrier Notes text length exceeds',
      });
      return;
    }

    let endPoint = '/donation/association/address/',
      req: any = {},
      address;
    address = this.f_address1.trim() + '@@' + this.f_city.trim() + '@@';
    if (this.f_province) {
      address += this.f_province.trim() + '@@';
    }
    address += this.f_zipCode.trim() + '@@' + this.f_country;
    req.address = address;
    req.carrier_note = this.f_carrierNote;
    req.header_id = this.applicationId;
    this.closeAddressDialog();
    this.pageDim = true;
    this._httpService.httpRequest('PUT', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: updateAddress()',
        });
      } else if (data.status) {
        this._appService.notify({
          status: data.status === 'OK' ? 0 : 1,
          msg: data.msg,
        });
        if (data.status === 'OK') {
          this.address1 = this.f_address1;
          this.city = this.f_city;
          this.province = this.f_province;
          this.country = this.f_country;
          this.zipCode = this.f_zipCode;
          this.carrierNote = this.f_carrierNote;
        }
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  updateDocument(attachment) {
    let endPoint = '/donation/document/',
      req: any = {},
      index;
    req.header_id = this.applicationId;
    req.attachment_id = attachment.atthmt_id;
    req.document_type = attachment.document_type_code;
    req.verified_flag = attachment.verified_flag;
    req.verified_by = '';
    if (attachment.verified_flag === 'Y') {
      req.verified_by = attachment.verified_by
        ? attachment.verified_by
        : this.user.user_id;
    }
    req.updated_by = this.user.user_id;

    index = this.application.attachments.indexOf(attachment);
    this.application.attachments[index].document_type = this.getDocumentType(
      attachment.document_type_code
    );
    this._httpService.httpRequest('PUT', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: updateDocument()',
        });
      } else if (data.status === 'ERROR' || data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.loadAuditLog();
      }
    });
  }

  updateLine(line) {
    let endPoint = '/donation/application/',
      existingLine;
    let req: any = {
      header_id: this.applicationId,
      no_of_pets: line.no_of_pets,
      no_of_qty: line.no_of_qty || '',
      user_id: this.user.user_id,
    };
    if (line.isNewLine) {
      req.pet_type = line.pet_type;
      req.pet_size = line.pet_size;
      existingLine = this.application.lines.some((appline) => {
        if (
          appline.pet_type === line.pet_type &&
          appline.pet_size === line.pet_size
        ) {
          req.request_line_id = appline.request_line_id;
          appline.no_of_pets =
            parseInt(appline.no_of_pets) + parseInt(line.no_of_pets);
          req.no_of_pets = appline.no_of_pets;
          return true;
        }
      });
      req.request_line_id = req.request_line_id || '';
      req.pet_size = req.pet_size || '';
    } else {
      req.request_line_id = line.request_line_id;
      req.no_of_pets = line.no_of_pets;
    }
    this.pageDim = true;
    this._httpService.httpRequest('PUT', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: updateLine()',
        });
      } else if (data.status && data.status !== 'OK') {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        if (line.isNewLine && !existingLine && data.line_id) {
          line.request_line_id = data.line_id;
          line.isNewLine = false;
          this.application.lines.push(line);
        }
        this.editLineType = line.pet_type;
        this.calculateMeals();
        this.updateMeals(line.pet_type);
        this.loadAuditLog();
      }
    });
  }

  updateMeals(petType) {
    if (
      (petType === 'DOG' && !this.application.dog_meals) ||
      (petType === 'CAT' && !this.application.cat_meals)
    ) {
      return;
    }
    let endPoint = '/donation/meals/update/',
      req: any = {};
    req.request_id = this.applicationId;
    req.meals =
      petType === 'DOG'
        ? this.application.dog_meals
        : this.application.cat_meals;
    req.type = petType;
    const noOfMealsOld = this.noOfMeals;
    this.noOfMeals =
      parseInt(this.application.dog_meals) +
      parseInt(this.application.cat_meals);
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error => updateMeals()',
        });
        return;
      }
      if (data.status && (data.status === 'ERROR' || data.status === 1)) {
        this.noOfMeals = noOfMealsOld;
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  updateOrganizationId(organization) {
    const req = { application_id: this.applicationId, org_id: organization };
    this._donationService
      .uploadApplicationOrg(req)
      .then(() => {
        this.application.almo_org_id = parseInt(organization, 10);
      })
      .catch((err) => {
        this._appService.notify(err);
      })
      .finally(() => {
        this.editOrganization = false;
      });
  }

  uploadDocument() {
    if (!this.document || !this.documentType) {
      this._appService.notify({
        status: 1,
        msg: 'Please fill all mandatory fields',
      });
      return;
    }
    let endPoint = '/donation/document/',
      req: any = {};
    req.header_id = this.applicationId;
    req.file_name = this._formatService.removeEscapeCharacter(
      this.document.filename
    );
    req.file_type = this.document.filetype || '';
    req.file_data = this.document.base64;
    req.document_type = this.documentType;
    req.verified_flag = 'Y';
    req.user_id = this.user.user_id;

    this.application.attachments.push({
      file_name: req.file_name,
      file_type: req.file_type,
      file_data: req.file_data,
      document_type: this.getDocumentType(this.documentType),
      document_type_code: this.documentType,
      verified_flag: 'Y',
    });
    this.closeFileDialog();
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: uploadDocument()',
        });
      } else {
        const count = this.application.attachments.length;
        if (data.status && data.status !== 'OK') {
          this._appService.notify({ status: 1, msg: data.msg });
          this.application.attachments.splice(count - 1, 1);
        } else {
          this.application.attachments[count - 1].atthmt_id =
            data.attachment_id;
          this.loadAuditLog();
        }
      }
    });
  }

  validate() {
    return (
      this.address1 &&
      this.city &&
      this.country &&
      this.zipCode &&
      this.application.contact_phone
    );
  }

  validateAllApplications(isValid) {
    if (this.allApplications.length) {
      this.copyConfirm =
        this._donationService.validateApplication(
          this.applicationName,
          this.allApplications,
          !isValid
        ) && isValid;
    } else {
      this.copyConfirm = isValid;
      if (!isValid) {
        this._appService.notify({
          status: 1,
          msg: `Ricevuta document is missing for ${this.applicationName.slice(
            0,
            -2
          )}.
           Can't create / copy a new application`,
        });
      }
    }
  }

  validateCopyApplication(): void {
    const index = this.allApplications.findIndex(
      (application) =>
        application.application_no === this.application.f_application_no
    );
    this.allApplications.splice(index, 1);
    const isValid = this.validateCurrentApplication();
    this.applicationName = !isValid
      ? `${this.application.f_application_no}, `
      : '';
    this.allApplications.forEach((application) => {
      this.applicationName +=
        !this._donationService.validateApplicationForCountry(application) &&
        application.request_status === 'O' &&
        application.ricevuta === 'N'
          ? `${application.application_no}, `
          : '';
    });
    this.validateAllApplications(isValid);
  }

  validateCurrentApplication(): boolean {
    let isValid = true;
    if (this._donationService.validateApplicationForCountry(this.application)) {
      isValid = true;
    } else if (this.application.request_status === 'O') {
      isValid = false;
      this.application.attachments.forEach((attach) => {
        if (attach.document_type_code === 'RICEVUTA') {
          isValid = true;
        }
      });
    }
    return isValid;
  }

  viewProfile(): void {
    this._appService.associationId = this.application.org_id;
    this._appService.requestHeaderId = this.applicationId;
    this._appService.associationNavParent = 'donation/application';
    if (
      this._cacheService.humansAndWildLifeRequest === 'humans-and-wild-life'
    ) {
      this._router.navigate(['donation/association/profile'], {
        queryParams: { project: 'humans-and-wild-life' },
      });
    } else {
      this._router.navigate(['donation/association/profile']);
    }
  }

  wfAction() {
    if (!this.comment && this.approvalStatus === 'R') {
      this.focuscomment = false;
      return;
    }

    if (this.informUser === 'Y' && !this.msgToUser) {
      this.focusMessage = false;
      return;
    }

    this.changeStatus(this.approvalStatus);
    this.showCommentDialog = false;
  }
}
