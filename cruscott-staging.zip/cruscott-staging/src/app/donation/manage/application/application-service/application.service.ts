import { Injectable, Injector } from '@angular/core';
import { HttpService } from '../../../../globals/http.service';
import { APIError } from '../../../../globals/api.error';
import { ServerError } from '../../../../globals/server.error';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {
  private _httpService: HttpService = this.injector.get(HttpService);

  constructor(private injector: Injector) { }

  updateApplicationStatus(requestObj): Promise<Response> {
    const endPoint = '/login/donation/application/status/';
    return new Promise((resolve, reject) => {
      this._httpService.postRequest(endPoint, requestObj, (response) => {
        if (!response) {
          reject(new ServerError('Could not update application status'));
        } else if (response.status === 1 || response.status === 'ERROR') {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }
}
