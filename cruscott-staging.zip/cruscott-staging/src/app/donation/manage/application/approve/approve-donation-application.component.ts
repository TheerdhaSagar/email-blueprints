import { Component, Injector, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { AppService } from '../../../../globals/app.service';
import { DonationApplication } from '../../../donation-application';
import { ApplicationService } from '../application-service/application.service';

@Component({
  selector: 'app-approve-application',
  templateUrl: './approve-donation-application.component.html',
  styleUrls: ['./approve-donation-application.component.scss']
})
export class ApproveDonationApplicationComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _applicationService: ApplicationService = this.injector.get(ApplicationService);
  private _location: Location = this.injector.get(Location);
  private _router: Router = this.injector.get(Router);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _sce: DomSanitizer;
  private _window: any;

  applicationDetails: DonationApplication;
  approvalStatus: string;
  comment: string;
  commentDialog: boolean;
  focusComment: boolean;
  focusMessage: boolean;
  informUser: string;
  isChrome: boolean;
  msg: string;
  msgToUser: string;
  pageDim: boolean;
  status: number;
  token: string;
  user: { user_id: number; user_description: string };

  constructor(private injector: Injector, sce: DomSanitizer) {
    this._sce = sce;
    this._window = window;

    this.applicationDetails = null;
    this.approvalStatus = '';
    this.comment = '';
    this.commentDialog = false;
    this.focusComment = true;
    this.focusMessage = true;
    this.informUser = 'N';
    this.isChrome = null;
    this.msg = '';
    this.msgToUser = '';
    this.pageDim = false;
    this.status = null;
    this.token = null;
    this.user = null;
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this.isChrome = this._appService.isChrome();
    // Encoded application data will be passed as parameter for approve application state
    this.token = this._routeParams.snapshot.params.token;
    // If there is token in request then get the application details based on token
    if (this.token) {
      this.getApplicationDetails();
    } else {
      this.status = 1;
      this.msg = 'Invalid Token. Login to Approve/Reject';
    }
  }

  changeStatus(): void {
    if (!this.comment && this.approvalStatus === 'R') {
      this.focusComment = false;
      return;
    }
    if (this.informUser === 'Y' && !this.msgToUser) {
      this.focusMessage = false;
      return;
    }
    this.updateApplicationStatus();
    this.commentDialog = false;
  }

  formatAddress(data): SafeHtml {
    let formattedAddress = `${data.address}<br/>${data.city}<br/> `;
    formattedAddress += `${data.country} - ${data.zip}`;
    return this._sce.bypassSecurityTrustHtml(formattedAddress.toUpperCase());
  }

  getApplicationDetails(): void {
    try {
      this.applicationDetails = JSON.parse(atob(this.token));
      this.applicationDetails.formatted_address = this.formatAddress(this.applicationDetails);
      this.approvalStatus = this.applicationDetails.status;
      this.openCommentDialog();
    } catch (e) {
      this.status = 1;
      this.msg = 'Invalid Token. Log in to Cruscott to approve/reject the application.';
    }
  }

  getRequestObject(): DonationApplication {
    const requestObj = this.applicationDetails;
    requestObj.comments = this.comment || '';
    requestObj.inform_user = this.informUser || '';
    requestObj.user_msg = this.msgToUser || '';
    return requestObj;
  }

  goToLogin(): void {
    this._router.navigate(['login']);
  }

  openCommentDialog(): void {
    this.commentDialog = true;
  }

  updateApplicationStatus(): void {
    try {
      const requestObj = this.getRequestObject();
      this.pageDim = true;
      this._applicationService.updateApplicationStatus(requestObj)
        .then((response) => {
          this.status = 0;
          this.msg = `Application ${requestObj.status === 'A' ? 'Approved' : 'Rejected'} successfully`;
        }).catch((error) => {
          this.status = 1;
          this.msg = error.msg;
        }).finally(() => {
          this.pageDim = false;
        });
    } catch (e) {
      this.status = 1;
      this.msg = 'Invalid Token';
    }
  }
}
