import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproveDonationApplicationComponent } from './approve-donation-application.component';

describe('ApproveApplicationComponent', () => {
  let component: ApproveDonationApplicationComponent;
  let fixture: ComponentFixture<ApproveDonationApplicationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproveDonationApplicationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproveDonationApplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
