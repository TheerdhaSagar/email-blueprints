import { SafeHtml } from '@angular/platform-browser';
import { PetDetails } from './pet-details';

export interface DonationApplication {
  address: string;
  address_verified: string;
  appl_no: string;
  cat_count: number;
  city: string;
  comments: string;
  contact_email: string;
  contact_name: string;
  country: string;
  dog_count: number;
  formatted_address: SafeHtml;
  header_id: number;
  inform_user: string;
  lines: Array<PetDetails>;
  org_name: string;
  phone: number;
  status: string;
  user: string;
  user_id: number;
  user_msg: string;
  wf_name: string;
  zip: string;
}
