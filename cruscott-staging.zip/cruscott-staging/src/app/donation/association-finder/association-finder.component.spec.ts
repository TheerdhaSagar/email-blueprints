import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociationFinderComponent } from './association-finder.component';

describe('AssociationFinderComponent', () => {
  let component: AssociationFinderComponent;
  let fixture: ComponentFixture<AssociationFinderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociationFinderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociationFinderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
