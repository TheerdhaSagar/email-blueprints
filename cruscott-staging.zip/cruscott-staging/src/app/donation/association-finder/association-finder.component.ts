import { Component, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { HttpService } from '../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';

declare var google: any;

@Component({
  selector: 'app-donation-association-finder',
  templateUrl: './association-finder.component.html',
  styleUrls: ['./association-finder.component.scss'],
  providers: [OrderByPipe]
})
export class AssociationFinderComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _orderBy: OrderByPipe;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  activeTab = 'valid';
  addressAutoSuggestion: any;
  addressChanged: boolean;
  addressError: any;
  association_name: any;
  autocomplete: any;
  autocompleteListener: any;
  cities: any[];
  citiesInCountry: any[];
  cityAutocomplete: any;
  cityError: any;
  contact_data: any;
  contactTypes: any[];
  count = 0;
  countries: any[];
  countriesList: any[];
  countryError: any;
  deleteDialog: boolean;
  deletedContacts: any[];
  dragStart: boolean;
  duplicateContacts: boolean;
  editInfoWindow: any;
  editMarker: any;
  editShop: boolean;
  focusAddress: boolean;
  focusCity: boolean;
  focusContactData: boolean;
  focusCountry: boolean;
  focusProvince: boolean;
  focusSearch: boolean;
  focusShopName: boolean;
  focusZipCode: boolean;
  fromGoogle: boolean;
  geocoder: any;
  googleMap: any;
  infoWindows: any[];
  invalidInfo: boolean;
  invalidSelectAll: boolean;
  invalidStores: any[];
  isNewStore: boolean;
  loading: boolean;
  markers: any[];
  misMatch: boolean;
  newAddress: any;
  newPage: boolean;
  place: any;
  provinceError: any;
  searchObj: any;
  searchResult: any;
  searchStore: any;
  selectedLine: any;
  selectedStore: any;
  setOnMap: boolean;
  shops: any[];
  shopsInCountry: any[];
  showContactsNotification: boolean;
  showData: boolean;
  showSpinner: boolean;
  storeAutoSuggestion: any;
  storeData: any;
  storeIndex: any;
  successDialog: boolean;
  updateMap: any;
  user: any;
  validSelectAll: boolean;
  validStores: any[];
  zipCodeError: any;

  constructor(appService: AppService, cacheService: CacheService, orderBy: OrderByPipe,
              httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._orderBy = orderBy;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.activeTab = 'valid';
    this.addressAutoSuggestion = '';
    this.addressChanged = false;
    this.addressError = '';
    this.association_name = '';
    this.autocomplete = '';
    this.autocompleteListener = '';
    this.cities = [];
    this.citiesInCountry = [];
    this.cityAutocomplete = '';
    this.cityError = '';
    this.contact_data = '';
    this.contactTypes = [
      { type_name: 'Select' },
      { type_name: 'Mobile' },
      { type_name: 'Landline' },
      { type_name: 'WhatsApp' },
      { type_name: 'Email' },
      { type_name: 'Fax' },
      { type_name: 'Skype' }
    ];
    this.count = 0;
    this.countries = [];
    this.countriesList = [];
    this.countryError = '';
    this.deleteDialog = false;
    this.deletedContacts = [];
    this.dragStart = false;
    this.duplicateContacts = false;
    this.editInfoWindow = '';
    this.editMarker = '';
    this.editShop = false;
    this.focusAddress = false;
    this.focusCity = false;
    this.focusContactData = false;
    this.focusCountry = false;
    this.focusProvince = false;
    this.focusSearch = false;
    this.focusShopName = false;
    this.focusZipCode = false;
    this.fromGoogle = false;
    this.googleMap = '';
    this.infoWindows = [];
    this.invalidInfo = false;
    this.invalidSelectAll = false;
    this.invalidStores = [];
    this.isNewStore = false;
    this.loading = false;
    this.markers = [];
    this.misMatch = false;
    this.newAddress = '';
    this.newPage = true;
    this.place = '';
    this.provinceError = '';
    this.searchObj = {
      country: '', city: '', association_name: '',
      association_id: '',
      address: '', zip_code: '',
      address_status: '',
      status: '',
      dogs: '',
      cats: '',
      user_verified_flag: '',
      adopt_me: ''
    };
    this.searchResult = '';
    this.selectedLine = '';
    this.selectedStore = {};
    this.setOnMap = false;
    this.shops = [];
    this.shopsInCountry = [];
    this.showContactsNotification = false;
    this.showData = false;
    this.showSpinner = false;
    this.storeAutoSuggestion = '';
    this.storeData = '';
    this.storeIndex = '';
    this.updateMap = '';
    this.user = '';
    this.validSelectAll = false;
    this.validStores = [];
    this.zipCodeError = '';
  }

  ngOnInit() {
    this._window.ga('send', 'pageview', {
      page: this._location.path()
    });

    this._appService.scrollTop();

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        setTimeout(() => {
          this.editMap();
          this.initMap();
          this.geocoder = new google.maps.Geocoder();
        }, 500);
        this.loadCities();
        this.loadCountries();
        this.loadAssociationNames();
        this.countriesLov();
      }
    });

  }

  actionChanged() {
    if (!this.newPage) {
      this.clearEdit();
    } else {
      this.showData = false;
      this.validStores = [];
      this.invalidStores = [];
      this.searchStore = '';
      this.contact_data = [];
    }
    this.newPage = true;
    this.count = 0;
  }

  addContactData() {
    this.contact_data.push({
      contact_id: -1,
      contact_type: 'Select',
      contact_method: '',
      data_source: 'Cruscott',
      contact_person_name: '',
      status: 'A',
      primary_flag: 'N'
    });

    jQuery('#insert-dialog').animate({
      scrollTop: 1000
    }, 500, 'linear');
  }

  addMarker(setMarker?) {
    this.fromGoogle = false;
    this.geocoder.geocode({
      componentRestrictions: {
        locality: this.selectedStore.city,
        country: this.selectedStore.country
      }
    }, (results, status) => {
      if (status === 'OK') {
        setTimeout(() => {
          const { location } = results[0].geometry;
          this.selectedStore.latitude =
            typeof location.lat === 'function' ? location.lat() : location.lat;
          this.selectedStore.longitude =
            typeof location.lng === 'function' ? location.lng() : location.lng;
          if (!setMarker) {
            this.misMatch = true;
            this.showMarker(this.selectedStore, true);
          } else {
            this.showMarker(this.selectedStore, false);
            this.misMatch = false;
            this.updateMap.setCenter(results[0].geometry.location);
            google.maps.event.trigger(this.updateMap, 'resize');
          }
        });
      } else {
        this.misMatch = true;
        this.selectedStore.setOnMap = false;
        this.cityError = 'Invalid City';
        this.focusCity = true;
      }
    });
  }

  addMarkerOnMap(position, index, store, center?) {
    let infoText, marker, infoWindow;
    infoText = store.association_name ? '<b>' + store.association_name + '</b>' : '';
    infoText += store.address_line_1 ? '<div>' + store.address_line_1 + '</div>' : '';
    infoText += store.address_line_2 ? '<div>' + store.address_line_2 + '</div>' : '';
    infoText += store.address_line_3 ? '<div>' + store.address_line_3 + '</div>' : '';
    infoText += store.zip_code ? '<div>' + store.zip_code + '</div>' : '';
    infoText += store.city ? '<div>' + store.city + '</div>' : '';
    infoText += store.province ? '<div>' + store.province + '</div>' : '';
    infoText += store.country ? '<div>' + store.country + '</div>' : '';
    marker = new google.maps.Marker({
      position,
      zoom: 7,
      title: store.association_name,
      map: this.googleMap
    });
    if (index !== '') {
      marker.setLabel(index.toString());
    }
    if (center) {
      this.googleMap.setCenter(position);
    }
    infoWindow = new google.maps.InfoWindow({
      content: infoText,
      maxWidth: 200,
      maxHeight: 300
    });
    this.infoWindows.push(infoWindow);
    marker.addListener('mouseover', () => {
      this.clearInfoWindows(true);
      infoWindow.open(this.googleMap, marker);
    });

    marker.addListener('click', () => {
      this.clearInfoWindows(true);
      infoWindow.open(this.googleMap, marker);
    });
    this.markers.push(marker);
  }

  addMarkers(storesType) {
    let i, stores, validIndex = '';
    this.selectedLine = '';
    this.clearInfoWindows();
    this.activeTab = storesType;
    stores = storesType === 'valid' ? this.validStores : this.invalidStores;
    for (i = 0; i < stores.length; i++) {
      if (stores[i].latitude !== null && stores[i].longitude !== null) {
        validIndex = validIndex !== '' ? validIndex : i;
        this.addMarkerOnMap({
            lat: parseFloat(stores[i].latitude),
            lng: parseFloat(stores[i].longitude)
          }, (i + 1).toString(),
          stores[i]);
        this.googleMap.setCenter({
          lat: parseFloat(stores[validIndex].latitude),
          lng: parseFloat(stores[validIndex].longitude)
        });
      }
    }
    if (stores.length > 0 && validIndex !== '') {
      this.googleMap.setZoom(7);
      setTimeout(() => {
        google.maps.event.trigger(this.googleMap, 'resize');
        this.googleMap.setCenter({
          lat: parseFloat(stores[validIndex].latitude),
          lng: parseFloat(stores[validIndex].longitude)
        });
      });
    }

  }

  addStore() {
    this.newPage = false;
    jQuery('#insert-dialog').animate({
      scrollTop: 0
    }, 500, 'linear');

    this.contact_data = [];
    this.newPage = false;
    this.addressAutocomplete();
    this.association_name = '';
    this.isNewStore = true;
    this.setOnMap = false;
    this.fromGoogle = false;
    this.selectedLine = '';
    this.selectedStore = {};
    this.selectedStore.country = this.validStores.length > 0 ? this.validStores[0].country : '';
    this.selectedStore.cats = 'N';
    this.selectedStore.dogs = 'N';
    this.selectedStore.status = 'A';
    this.selectedStore.datasource = 'cruscott';
    if (this.validStores.length > 0) {
      this.selectCountry();
    }
    // places = null;
    this.selectedStore.province = '';
    this.selectedStore.city = '';
    this.selectedStore.address_line_1 = '';
    this.selectedStore.address_line_2 = '';
    this.selectedStore.address_line_3 = '';
    this.selectedStore.user_verified_flag = false;
    this.selectedStore.created_by = this.user.user_id;
    this.selectedStore.last_updated_by = this.user.user_id;
    this.selectedStore.association_name = '';
    this.selectedStore.latitude = null;
    this.selectedStore.longitude = null;
    if (this.editMarker) {
      this.editMarker.setMap(null);
    }
    setTimeout(() => {
      this.updateMap.setZoom(15);
      google.maps.event.trigger(this.updateMap, 'resize');
    }, 50);
  }

  addressAutocomplete() {
    this.storeAutoSuggestion = new google.maps.places.Autocomplete(
      document.getElementById('search-by-store'), {}
    );
    this.storeAutoSuggestion.addListener('place_changed', () => {
      this.onAddressChange();
    });

    if (this.showData && this.activeTab === 'invalid') {
      this.addressAutoSuggestion = new google.maps.places.Autocomplete(
        document.getElementById('search-by-address'), {}
      );
      this.addressAutoSuggestion.addListener('place_changed', () => {
        this.onAddressChangeOne();
      });
    }
  }

  autoFillAddress(result) {
    if (result && result.geometry) {
      this.misMatch = false;
      let addressArray, i, address_components;
      this.clearNotifications();
      this.updateMap.setCenter(result.geometry.location);
      this.selectedStore.latitude = typeof result.geometry.location.lat === 'function' ? result.geometry.location.lat() : result.geometry.location.lat;
      this.selectedStore.longitude = typeof result.geometry.location.lng === 'function' ? result.geometry.location.lng() : result.geometry.location.lng;
      this.selectedStore.address_line_1 = '';
      this.selectedStore.address_line_2 = '';
      this.selectedStore.address_line_3 = '';
      this.selectedStore.association_name = this.selectedStore.association_name || result.name;
      for (i = 0; i < result.address_components.length; i++) {
        address_components = result.address_components[i];
        switch (this.matchAddressType(address_components.types)) {
          case 'locality':
            this.selectedStore.city = address_components.long_name;
            this.cityAutocomplete = address_components.long_name;
            break;
          case 'sublocality':
            if (!this.selectedStore.city) {
              this.selectedStore.city = address_components.long_name;
              this.cityAutocomplete = address_components.long_name;
            }
            break;
          case 'administrative_area_level_2':
            this.selectedStore.province = address_components.long_name;
            break;
          case 'postal_code':
            this.selectedStore.zip_code = address_components.long_name;
            break;
          case 'country':
            this.selectedStore.country = address_components.long_name;
            this.selectedStore.country_code = address_components.short_name;
            this.placesAutoComplete();
            break;
        }
      }
      addressArray = result.formatted_address.split(',');
      for (i = 0; i < addressArray.length; i++) {
        if (addressArray[i].indexOf(this.selectedStore.country) === -1 &&
          addressArray[i].indexOf(this.selectedStore.zip_code) === -1 &&
          addressArray[i].indexOf(this.selectedStore.province) === -1 &&
          addressArray[i].indexOf(this.selectedStore.city) === -1) {
          this.selectedStore.address_line_1 += this.selectedStore.address_line_1 ? ', ' : '';
          this.selectedStore.address_line_1 += addressArray[i];
        }
      }
      this.selectedStore.address_line_1 = this.selectedStore.address_line_1 || result.formatted_address;

      this.showMarker(this.selectedStore);
    }
  }

  checkCount(event) {
    event.stopPropagation();
    setTimeout(() => {
      this.newPage = true;
      let i;
      this.count = 0;
      for (i = 0; i < this.validStores.length; i++) {
        if (this.validStores[i].checked) {
          this.count++;
        }
      }
      for (i = 0; i < this.invalidStores.length; i++) {
        if (this.invalidStores[i].checked) {
          this.count++;
        }
      }
    }, 50);
  }

  clearEdit() {
    this.newPage = true;
    if (this.editMarker) {
      this.editMarker.setMap(null);
      this.editInfoWindow.close();
    }
    this.selectedStore = '';
    this.focusCity = false;
    this.focusAddress = false;
    this.focusCountry = false;
    this.focusProvince = false;
    this.focusZipCode = false;
    this.focusShopName = false;
    this.cityAutocomplete = '';
    this.cityError = '';
    this.zipCodeError = '';
    this.addressError = '';
    this.countryError = '';
    this.contact_data = [];
    this.focusContactData = false;
    this.loading = false;

    this.isNewStore = false;
    this.misMatch = false;
    if (this.autocomplete) {
      google.maps.event.clearInstanceListeners(this.autocomplete);
    }
    this.storeIndex = '';
    this.newAddress = '';
    jQuery('.pac-container').remove();
  }

  // Close all info windows
  clearInfoWindows(clearMarker?) {
    for (let i = 0; i < this.infoWindows.length; i++) {
      this.infoWindows[i].close();
      if (!clearMarker) {
        this.markers[i].setMap(null);
      }
    }
    if (!clearMarker) {
      this.infoWindows = [];
      this.markers = [];
    }
  }

  clearNotifications() {
    this.focusCity = false;
    this.focusAddress = false;
    this.focusCountry = false;
    this.focusProvince = false;
    this.focusZipCode = false;
    this.focusShopName = false;
    this.cityError = '';
    this.zipCodeError = '';
    this.addressError = '';
    this.countryError = '';
    this.provinceError = '';
  }

  continueAction() {
    this.invalidInfo = false;
    this.showData = false;
    if (this.validStores.length === 0) {
      this.activeTab = 'invalid';
    }
  }

  countriesLov(): void {
    const endPoint = '/registration/countries/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - countriesLov()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.countriesList = data;
      }
    });
  }

  deleteAssociations() {
    this.validSelectAll = false;
    this.invalidSelectAll = false;
    let i, shopIds = [], validStores = [], invalidStores = [];
    this.deleteDialog = false;
    for (i = 0; i < this.validStores.length; i++) {
      if (this.validStores[i].checked) {
        shopIds.push(this.validStores[i].association_id);
      } else {
        validStores.push(this.validStores[i]);
      }
    }
    for (i = 0; i < this.invalidStores.length; i++) {
      if (this.invalidStores[i].checked) {
        shopIds.push(this.invalidStores[i].association_id);
      } else {
        invalidStores.push(this.invalidStores[i]);
      }
    }
    this.count = 0;
    this.validStores = validStores;
    this.invalidStores = invalidStores;
    this.reset();
    const endPoint = '/donation/associations/';
    this._httpService.httpRequest('DELETE', endPoint, shopIds, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - deleteAssociations()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      }
    });
  }

  deleteContact(index) {
    this.contact_data.splice(index, 1);
    this.updatePrimaryFlag();
  }

  // Initialize map to edit or point store location
  editMap() {
    this.updateMap = new google.maps.Map(document.getElementById('edit-map'), {
      zoom: 15,
      center: { lat: 41.872, lng: 12.567 },
      mapTypeControl: true
    });
    this.addressAutocomplete();
  }

  editStore(store, event, type) {
    this.addressAutocomplete();
    let i, stores;
    this.deletedContacts = [];
    this.contact_data = [...store.contacts];
    stores = this.activeTab === 'valid' ? this.validStores : this.invalidStores;
    for (i = 0; i < stores.length; i++) {
      if (store.id === stores[i].id) {
        this.storeIndex = i;
        break;
      }
    }

    if (event && !event.target.id && !type) {
      this.viewStore(store, this.storeIndex);
      return;
    }
    this.setOnMap = false;
    this.newPage = false;
    this.selectedStore = { ...store };
    this.addressChanged = false;
    this.misMatch = false;
    this.editShop = false;
    this.isNewStore = false;
    this.loading = false;
    this.fromGoogle = false;

    if (this.selectedStore.country) {
      this.placesAutoComplete();
    }
    this.association_name = this.selectedStore.association_name || '';
    this.selectedStore.user_verified_flag = this.selectedStore.user_verified_flag === 'Y';
    if (type === 'invalid' || !this.selectedStore.country || !this.selectedStore.country_code) {
      this.selectCountry();
      this.cityAutocomplete = this.selectedStore.city || '';
    }
    if (store.latitude && store.longitude) {
      this.showMarker(store);
    } else {
      if (this.editMarker) {
        this.editMarker.setMap(null);
      }
      setTimeout(() => {
        google.maps.event.trigger(this.updateMap, 'resize');
      }, 50);
    }
  }

  // Export store data
  exportData(data) {
    let tableData: any = {}, tmpData = [], i, tmpObj;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj['Association Name'] = {
        data: data[i].association_name
      };
      tmpObj['Address Line 1'] = {
        data: data[i].address_line_1
      };
      tmpObj['Address Line 2'] = {
        data: data[i].address_line_2
      };
      tmpObj['Address Line 3'] = {
        data: data[i].address_line_3
      };
      tmpObj.City = {
        data: data[i].city
      };
      tmpObj['Zip Code'] = {
        data: data[i].zip_code
      };
      tmpObj.Province = {
        data: data[i].province
      };
      tmpObj.Country = {
        data: data[i].country
      };
      tmpObj.Website = {
        data: data[i].website
      };
      tmpObj['Association Status'] = {
        data: data[i].status
      };
      tmpObj.cats = {
        data: data[i].cats
      };
      tmpObj.dogs = {
        data: data[i].dogs
      };
      tmpData.push(tmpObj);
    }
    this.showSpinner = false;
    tableData.data = tmpData;

    // to export to excel sheet
    this._appService.tableToExcel('Associations', tableData);
  }

  // To export  all/selected stores to excel
  exportToExcel() {
    this.showSpinner = true;
    this.validSelectAll = false;
    this.invalidSelectAll = false;
    let i, shops = [];
    // to get all the selected valid stores and push into shop array
    for (i = 0; i < this.validStores.length; i++) {
      if (this.validStores[i].checked) {
        shops.push(this.validStores[i]);
        this.validStores[i].checked = false;
      }
    }
    // to get all the selected invalid stores and push into shop array
    for (i = 0; i < this.invalidStores.length; i++) {
      if (this.invalidStores[i].checked) {
        shops.push(this.invalidStores[i]);
        this.invalidStores[i].checked = false;
      }
    }

    this.exportData(shops.length > 0 ? shops : this.validStores.concat(this.invalidStores));
    this.count = 0;
  }

  formatData(data) {
    this.validStores = [];
    this.invalidStores = [];
    this.storeIndex = '';
    this.invalidSelectAll = false;
    this.validSelectAll = false;
    this.activeTab = 'valid';
    for (let i = 0; i < data.length; i++) {
      data[i].province = data[i].province || '';
      data[i].city = data[i].city || '';
      data[i].country = data[i].country || '';
      data[i].address_line_1 = data[i].address_line_1 || '';
      data[i].address_line_2 = data[i].address_line_2 || '';
      data[i].address_line_3 = data[i].address_line_3 || '';
      data[i].latitude = data[i].latitude || null;
      data[i].longitude = data[i].longitude || null;
      data[i].zip_code = data[i].zip_code || '';
      if (data[i].latitude) {
        data[i].id = this.validStores.length + 1;
        this.validStores.push(data[i]);
      } else {
        data[i].id = this.invalidStores.length + 1;
        this.invalidStores.push(data[i]);
      }
    }
    if (this.validStores.length === 0) {
      this.clearInfoWindows();
      this.activeTab = 'invalid';
      setTimeout(() => {
        google.maps.event.trigger(this.googleMap, 'resize');
      }, 50);
    } else {
      this.addMarkers('valid');
    }
    this.showData = true;

    this.storeData = data;
    this.showSpinner = false;
  }

  getTitle(contact) {
    return contact.contact_type === 'Select' ? '' : contact.primary_flag === 'Y' ? 'Primary ' + contact.contact_type + ' contact' : 'Set as primary ' + contact.contact_type + ' contact';
  }

  // initialize the map
  initMap() {
    this.googleMap = new google.maps.Map(document.getElementById('map'), {
      zoom: 7,
      center: { lat: 41.872, lng: 12.567 },
      mapTypeControl: true,
      mapTypeControlOptions: {
        style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
        position: google.maps.ControlPosition.BOTTOM_LEFT
      },
      fullScreenControl: true
    });
  }

  loadAssociationNames(): void {
    const endPoint = '/donation/associations/names/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadAssociationNames()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.shops = this._orderBy.transform(data, 'association_name', false);
        this.shopsInCountry = this._orderBy.transform(data, 'association_name', false);
      }
    });
  }

  loadCities(): void {
    const endPoint = '/donation/associations/cities/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadCities()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.cities = this._orderBy.transform(data, 'city', false);
        this.citiesInCountry = this._orderBy.transform(data, 'city', false);
      }
    });
  }

  loadCountries(): void {
    const endPoint = '/donation/associations/countries/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadCountries()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: 1 });
      } else {
        this.countries = this._orderBy.transform(data, 'country', false);
      }
    });
  }

  matchAddressType(types) {
    let type_index, i,
      addressTypes = ['street_number', 'route', 'locality', 'administrative_area_level_2',
        'administrative_area_level_1', 'country', 'postal_code', 'sublocality'];
    for (i = 0; i < types.length; i++) {
      type_index = addressTypes.map(x => x).indexOf(types[i]);
      if (type_index !== -1) {
        return types[i];
      }
    }
    return '';
  }

  onAddressChange() {
    setTimeout(() => {
      this.searchResult = this.storeAutoSuggestion.getPlace();
      this.autoFillAddress(this.searchResult);
    }, 10);
  }

  onAddressChangeOne() {
    setTimeout(() => {
      this.searchResult = this.addressAutoSuggestion.getPlace();
      this.autoFillAddress(this.searchResult);
    }, 10);
  }

  onPlaceChange() {
    let i, address_components;
    setTimeout(() => {
      this.place = this.autocomplete.getPlace();
      if (this.place.geometry && this.place.geometry.location) {
        if (!this.selectedStore.address_line_1) {
          this.updateMap.setCenter(this.place.geometry.location);
        }
        this.selectedStore.latitude =
          typeof this.place.geometry.location.lat === 'function' ?
            this.place.geometry.location.lat() : this.place.geometry.location.lat;
        this.selectedStore.longitude =
          typeof this.place.geometry.location.lng === 'function' ?
            this.place.geometry.location.lng() : this.place.geometry.location.lng;
      } else {
        this.focusCity = true;
      }
      if (this.place.geometry) {
        this.focusCity = false;
        this.focusProvince = false;
        this.focusAddress = false;
        this.focusZipCode = false;
        this.focusCountry = false;
        for (i = 0; i < this.place.address_components.length; i++) {
          address_components = this.place.address_components[i];
          switch (this.matchAddressType(address_components.types)) {
            case 'locality':
              this.selectedStore.city = address_components.long_name;
              this.cityAutocomplete = address_components.long_name;
              (document.getElementById('autocomplete') as HTMLFormElement).value = address_components.long_name;
              break;
            case 'sublocality':
              if (!this.selectedStore.city) {
                this.selectedStore.city = address_components.long_name;
                this.cityAutocomplete = address_components.long_name;
                (document.getElementById('autocomplete') as HTMLFormElement).value = address_components.long_name;
              }
              break;
            case 'administrative_area_level_2':
              this.selectedStore.province = address_components.long_name;
              break;
          }
        }
      }
    }, 50);
  }

  placesAutoComplete() {
    // Remove city auto suggestions for previously selected country
    if (this.autocomplete) {
      google.maps.event.removeListener(this.autocompleteListener);
      google.maps.event.clearInstanceListeners(this.autocomplete);
      jQuery('.pac-container').remove();
      this.addressAutocomplete();
    }
    let options = {
      types: ['(cities)'],
      componentRestrictions: {
        country: this.selectedStore.country
      }
    };
    this.autocomplete = new google.maps.places.Autocomplete(
      document.getElementById('autocomplete'), options
    );
    // places = new google.maps.places.PlacesService(this.updateMap);
    this.autocompleteListener = this.autocomplete.addListener('place_changed', () => {
      this.onPlaceChange();
    });
  }

  // Set store location on map to center
  reposition() {
    if (this.selectedStore.user_verified_flag) {
      this.showMarker(this.selectedStore);
    } else {
      this.validateAddress('', true);
    }
    this.setOnMap = false;
    this.focusCountry = !(this.selectedStore.country && this.selectedStore.country_code);
    this.focusCity = !this.selectedStore.city;
    this.countryError = this.selectedStore.country ? '' : 'Country is required';
    this.cityError = this.selectedStore.city ? '' : 'City is required';
    this.loading = false;
  }

  // Reset map to initial position pointing all stores
  reset() {
    this.selectedLine = '';
    this.clearInfoWindows();
    let stores, validIndex = '', i;
    stores = this.activeTab === 'valid' ? this.validStores : this.invalidStores;
    for (i = 0; i < stores.length; i++) {
      if (stores[i].latitude && stores[i].longitude) {
        validIndex = validIndex !== '' ? validIndex : i;
        this.addMarkerOnMap({ lat: parseFloat(stores[i].latitude), lng: parseFloat(stores[i].longitude) },
          (i + 1).toString(), stores[i]);
      }
    }
    this.googleMap.setZoom(6);
    if (validIndex !== '') {
      this.googleMap.setCenter({
        lat: parseFloat(stores[validIndex].latitude),
        lng: parseFloat(stores[validIndex].longitude)
      });
    }
    google.maps.event.trigger(this.googleMap, 'resize');
  }

  save() {
    let dict = [], validStoresLength, id, i, index, j, contactIds = [], cid;
    this.loading = false;
    this.focusContactData = false;

    for (i = 0; i < this.contact_data.length; i++) {
      if (!this.contact_data[i].contact_method || this.contact_data[i].contact_type === 'Select') {
        this.focusContactData = true;
        jQuery('#insert-dialog').animate({
          scrollTop: 1000
        }, 500, 'linear');
        return;
      }
      if (this.contact_data[i].contact_error) {
        this._appService.notify({ msg: 'Enter valid contact data. Only numbers are allowed', status: 1 });
        jQuery('#insert-dialog').animate({
          scrollTop: 1000
        }, 500, 'linear');
        return;
      }

      if (this.contact_data[i].contact_name_error) {
        this._appService.notify({
          msg: 'Enter valid contact person name. Only Characters, space and numbers are allowed',
          status: 1
        });
        jQuery('#insert-dialog').animate({
          scrollTop: 1000
        }, 500, 'linear');
        return;
      }
      for (j = 0; j < this.contact_data.length; j++) {
        if (j !== i && this.contact_data[i].contact_type === this.contact_data[j].contact_type &&
          this.contact_data[i].contact_method === this.contact_data[j].contact_method &&
          this.contact_data[i].contact_person_name === this.contact_data[j].contact_person_name) {
          this.duplicateContacts = true;
          return;
        }
      }

      // Show warning if inactive contact is selected as primary contact
      if (this.contact_data[i].primary_flag === 'Y' &&
        this.contact_data[i].status === 'I' &&
        !this.showContactsNotification) {
        this.showContactsNotification = true;
        return;
      }
    }

    this.duplicateContacts = false;
    this.showContactsNotification = false;
    this.focusCountry = false;
    this.focusCity = false;
    this.focusProvince = false;
    this.focusAddress = false;
    this.focusZipCode = false;
    this.newPage = true;
    this.cityAutocomplete = '';
    this.cityError = '';
    this.zipCodeError = '';
    this.addressError = '';
    this.countryError = '';
    this.provinceError = '';
    this.newAddress = '';
    this.selectedStore.user_verified_flag = this.selectedStore.user_verified_flag ? 'Y' : 'N';

    validStoresLength = this.validStores.length;
    if (validStoresLength > 0) {
      id = this.validStores[validStoresLength - 1].id + 1;
    } else {
      id = 1;
    }
    if (this.selectedStore.association_id) {
      if (this.activeTab === 'invalid') {
        this.selectedStore.id = id;
        this.validStores.unshift(this.invalidStores[this.storeIndex]);
        this.invalidStores.splice(this.storeIndex, 1);
        this.storeIndex = 0;
      }
    }

    if (this.validStores.length > 0 && !this.isNewStore) {
      index = this.storeIndex;
      this.validStores[index].id = this.selectedStore.id;
      this.validStores[index].association_name = this.selectedStore.association_name;
      this.validStores[index].country = this.selectedStore.country;
      this.validStores[index].country_code = this.selectedStore.country_code;
      this.validStores[index].city = this.selectedStore.city;
      this.validStores[index].province = this.selectedStore.province;
      this.validStores[index].zip_code = this.selectedStore.zip_code;
      this.validStores[index].address_line_1 = this.selectedStore.address_line_1;
      this.validStores[index].address_line_2 = this.selectedStore.address_line_2;
      this.validStores[index].address_line_3 = this.selectedStore.address_line_3;
      this.validStores[index].user_verified_flag = this.selectedStore.user_verified_flag;
      this.validStores[index].latitude = this.selectedStore.latitude;
      this.validStores[index].longitude = this.selectedStore.longitude;
      this.validStores[index].created_by = this.user.user_id;
      this.validStores[index].last_updated_by = this.user.user_id;
      this.validStores[index].contacts = this.contact_data;
      this.validStores[index].cats = this.selectedStore.cats;
      this.validStores[index].dogs = this.selectedStore.dogs;
      this.validStores[index].website = this.selectedStore.website;
      this.validStores[index].status = this.selectedStore.status;
    }
    this.selectedStore.created_user_id = this.user.user_id;
    this.selectedStore.create_date = this._appService.today(0);


    if (this.selectedStore.contacts) {
      for (i = 0; i < this.selectedStore.contacts.length; i++) {
        index = this.contact_data.map(x => x.contact_id).indexOf(this.selectedStore.contacts[i].contact_id);

        if (index === -1) {
          this.deletedContacts.push(this.selectedStore.contacts[i].contact_id);
        }
      }
    }

    delete this.selectedStore.id;
    this.selectedStore.contact_data = this.contact_data;
    this.selectedStore.association_id = this.selectedStore.association_id || '';
    this.selectedStore.address_line_2 = this.selectedStore.address_line_2 || '';
    this.selectedStore.address_line_3 = this.selectedStore.address_line_3 || '';
    this.selectedStore.province = this.selectedStore.province || '';
    this.selectedStore.website = this.selectedStore.website || '';
    dict.push(this.selectedStore);
    dict[0].delete_contacts = this.deletedContacts;
    if (this.selectedLine !== '' && this.selectedLine !== undefined) {
      setTimeout(() => {
        this.googleMap.setCenter({
          lat: parseFloat(this.selectedStore.latitude),
          lng: parseFloat(this.selectedStore.longitude)
        });
        google.maps.event.trigger(this.googleMap, 'resize');
        this.selectedStore = '';
      }, 50);
    }

    this.deletedContacts = [];
    this.successDialog = true;
    this.isNewStore = false;
    jQuery('.pac-container').remove();

    const endPoint = '/donation/association/insert/';
    this._httpService.httpRequest('POST', endPoint, dict, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - save()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        if (data.contact_ids && data.contact_ids.length > 0) {
          cid = 0;
          index = this.storeIndex;
          for (i = 0; i < this.validStores[index].contacts.length; i++) {
            contactIds = data.contact_ids.split(',');
            if (this.validStores[index].contacts[i].contact_id === -1) {
              this.validStores[index].contacts[i].contact_id = parseInt(contactIds[cid++]);
            }
          }
        }
        this.loadCountries();
        this.loadCities();
        this.loadAssociationNames();
      }
    });
  }

  saveShopName(save) {
    if (save && this.association_name) {
      this.selectedStore.association_name = this.association_name;
    }
    this.association_name = '';
    this.editShop = false;
  }

  search() {
    if ((!this.searchObj.address_status || this.searchObj.address_status === 'Y') &&
      !this.searchObj.country) {
      this.focusSearch = !this.searchObj.country;
      this._appService.scrollTop();
      return;
    }
    this.focusSearch = false;
    this.showSpinner = true;
    const endPoint = '/donation/association/search/';
    this._httpService.httpRequest('POST', endPoint, this.searchObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - search()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else if (data.length === 0) {
        this.invalidInfo = true;
      } else {
        this.formatData(data);
      }
      this.showSpinner = false;
    });
  }

  searchByCountry() {
    let index;
    this.citiesInCountry = [];
    this.shopsInCountry = [];
    for (let i = 0; i < this.cities.length; i++) {
      if (!this.searchObj.country || (this.searchObj.country &&
        this.cities[i].country === this.searchObj.country)) {
        this.citiesInCountry.push(this.cities[i]);
      }
    }

    for (let i = 0; i < this.shops.length; i++) {
      if ((!this.searchObj.country || (this.searchObj.country && this.searchObj.country === this.shops[i].country)) &&
        (!this.searchObj.city || (this.searchObj.city && this.shops[i].city && this.searchObj.city.toLowerCase() === this.shops[i].city.toLowerCase()))) {
        this.shopsInCountry.push(this.shops[i]);
      }
    }

    setTimeout(() => {
      if (!this.searchObj.city) {
        (document.getElementById('cityName') as HTMLFormElement).value = '';
      } else {
        index = this.citiesInCountry.map(x => x.city).indexOf(this.searchObj.city);
        if (index !== -1) {
          (document.getElementById('cityName') as HTMLFormElement).value = this.citiesInCountry[index].city;
        }
      }

      if (!this.searchObj.association_name) {
        (document.getElementById('associationName') as HTMLFormElement).value = '';
      } else {
        index = this.shopsInCountry.map(x => x.association_name).indexOf(this.searchObj.association_name);
        if (index !== -1) {
          (document.getElementById('associationName') as HTMLFormElement).value = this.shopsInCountry[index].association_name;
        }
      }
    });
  }

  searchFromGoogle(event) {
    this.misMatch = false;
    if (event.keyCode !== 13) {
      return;
    }
    if ((event.target.id === 'search-by-store' && this.newAddress) ||
      (event.target.id === 'search-by-address' && this.showData &&
        this.activeTab === 'invalid' && this.selectedStore)) {
      this.geocoder.geocode({
        address: event.target.id === 'search-by-store' ? this.newAddress : this.selectedStore.address_line_1
      }, (results, status) => {
        if (status === 'OK') {
          this.autoFillAddress(results[results.length - 1]);
          this.misMatch = false;
        } else {
          this.misMatch = true;
          this.fromGoogle = true;
        }
      });
    }
  }

  selectAll() {
    let stores, selectAllStores, i;
    this.count = 0;
    stores = this.activeTab === 'valid' ? this.validStores : this.invalidStores;
    selectAllStores = this.activeTab === 'valid' ? this.validSelectAll : this.invalidSelectAll;
    for (i = 0; i < stores.length; i++) {
      stores[i].checked = selectAllStores;
    }
    for (i = 0; i < this.validStores.length; i++) {
      if (this.validStores[i].checked) {
        this.count++;
      }
    }
    for (i = 0; i < this.invalidStores.length; i++) {
      if (this.invalidStores[i].checked) {
        this.count++;
      }
    }
  }

  selectCountry(validate?) {
    let index;
    let result;

    index = this.countriesList.map(x => x.country).indexOf(this.selectedStore.country);
    if (index !== -1) {
      this.selectedStore.country = this.countriesList[index].country;
      this.selectedStore.country_code = this.countriesList[index].country_code;
    } else {
      index = this.countriesList.map(x => x.country_code).indexOf(this.selectedStore.country);
      if (index !== -1) {
        this.selectedStore.country = this.countriesList[index].country;
        this.selectedStore.country_code = this.countriesList[index].country_code;
      }
    }

    if (!this.selectedStore.country || !this.selectedStore.country_code) {
      return;
    }

    this.geocoder.geocode({
      componentRestrictions: {
        country: this.selectedStore.country
      }
    }, (results, status) => {
      if (status === 'OK') {
        result = results[0];
        this.updateMap.setCenter(result.geometry.location);
        this.updateMap.setZoom(15);
        this.placesAutoComplete();
        if (this.selectedStore.country && this.selectedStore.city) {
          this.addMarker(true);
        }
        this.misMatch = false;
        if (validate) {
          this.validateAddress('country');
        }
      }
    });
  }

  setPrimaryData(contact, contactIndex, inputType) {
    if (contact.contact_type === 'Select' || (contact.primary_flag === 'Y' && inputType === 'radio')) {
      return;
    }
    let i, index;
    if (inputType === 'radio') {
      for (i = 0; i < this.contact_data.length; i++) {
        this.contact_data[i].primary_flag = this.contact_data[i].contact_type === contact.contact_type ? 'N' : this.contact_data[i].primary_flag;
      }
      contact.primary_flag = 'Y';
    } else {
      index = this.contact_data.map(x => x.contact_type + x.primary_flag).indexOf(contact.contact_type + 'Y');
      if (index === -1 || index === contactIndex) {
        contact.primary_flag = 'Y';
      } else {
        contact.primary_flag = 'N';
      }
    }
    this.validateData(contact, 'data');
    this.updatePrimaryFlag();
  }

  showMarker(store, hideAddress?) {
    let infoText = store.association_name ? '<b>' + store.association_name + '</b>' : '';
    if (!hideAddress) {
      infoText += store.address_line_1 ? '<div>' + store.address_line_1 + '</div>' : '';
      infoText += store.address_line_2 ? '<div>' + store.address_line_2 + '</div>' : '';
      infoText += store.address_line_3 ? '<div>' + store.address_line_3 + '</div>' : '';
      infoText += store.zip_code ? '<div>' + store.zip_code + '</div>' : '';
    }
    infoText += store.city ? '<div>' + store.city + '</div>' : '';
    infoText += store.country ? '<div>' + store.country + '</div>' : '';
    if (this.editMarker) {
      this.editMarker.setMap(null);
    }
    this.editMarker = new google.maps.Marker({
      position: { lat: parseFloat(store.latitude), lng: parseFloat(store.longitude) },
      draggable: true,
      map: this.updateMap,
      zoom: 15,
      title: store.association_name
    });
    this.updateMap.setZoom(15);
    this.editInfoWindow = new google.maps.InfoWindow({
      content: infoText,
      maxWidth: 200,
      maxHeight: 300
    });
    this.editInfoWindow.open(this.updateMap, this.editMarker);
    this.editMarker.addListener('dragstart', () => {
      this.dragStart = true;
      this.editInfoWindow.close();
    });

    this.updateMap.addListener('click', (event) => {
      if (this.dragStart) {
        google.maps.event.trigger(this.editMarker, 'dragend', event);
      }
    });

    this.editMarker.addListener('drag', () => {
      this.editInfoWindow.close();
    });

    // get latlng from marker position
    this.editMarker.addListener('dragend', (event) => {
      this.dragStart = false;
      this.updateMap.setCenter(event.latLng);
      setTimeout(() => {
        this.selectedStore.latitude = event.latLng.lat();
        this.selectedStore.longitude = event.latLng.lng();
        this.misMatch = false;
        this.setOnMap = true;
        this.showMarker(this.selectedStore);
        this.clearNotifications();
      }, 10);
    });
    this.editMarker.addListener('mouseover', () => {
      this.editInfoWindow.open(this.updateMap, this.editMarker);
    });
    setTimeout(() => {
      google.maps.event.trigger(this.updateMap, 'resize');
      this.updateMap.setCenter({ lat: parseFloat(store.latitude), lng: parseFloat(store.longitude) });
    }, 50);

  }

  updatePrimaryFlag() {
    let i, j, primaryFlag, index;
    for (i = 0; i < this.contactTypes.length; i++) {
      primaryFlag = false;
      for (j = 0; j < this.contact_data.length; j++) {
        if (this.contactTypes[i].type_name === this.contact_data[j].contact_type && this.contact_data[j].primary_flag === 'Y') {
          primaryFlag = true;
          break;
        }
      }
      if (!primaryFlag) {
        index = this.contact_data.map(x => x.contact_type).indexOf(this.contactTypes[i].type_name);
        if (index !== -1) {
          this.contact_data[index].primary_flag = 'Y';
        }
      }
    }
  }

  validate() {
    if (this.isNewStore || this.activeTab === 'invalid') {
      this.selectedStore.city = this.cityAutocomplete;
    }
    this.focusCity = false;
    this.focusProvince = false;
    this.focusAddress = false;
    this.focusZipCode = false;
    this.focusCountry = false;
    this.loading = true;
    if (!this.selectedStore.country || !this.selectedStore.city || !this.selectedStore.address_line_1 ||
      !this.selectedStore.zip_code || !this.selectedStore.association_name || !this.selectedStore.country_code) {
      this.focusShopName = !this.selectedStore.association_name;
      this.focusCity = !this.selectedStore.city;
      this.focusCountry = !(this.selectedStore.country && this.selectedStore.country_code);
      this.focusZipCode = !this.selectedStore.zip_code;
      this.focusAddress = !this.selectedStore.address_line_1;
      this.zipCodeError = 'ZIP Code is required';
      this.countryError = 'Country is required';
      this.cityError = 'City is required';
      this.addressError = 'Address Line 1 is required';
      this.misMatch = false;
      this.loading = false;
    } else if (this.setOnMap ||
      (this.activeTab === 'valid' && this.storeIndex !== null && this.storeIndex !== undefined &&
        this.storeIndex !== '' && this.selectedStore.city === this.validStores[this.storeIndex].city &&
        this.selectedStore.zip_code === this.validStores[this.storeIndex].zip_code &&
        this.selectedStore.address_line_1 === this.validStores[this.storeIndex].address_line_1 &&
        this.selectedStore.province === this.validStores[this.storeIndex].province &&
        this.selectedStore.country === this.validStores[this.storeIndex].country &&
        this.selectedStore.latitude && this.selectedStore.longitude)) {
      this.loading = false;
      this.save();
    } else {
      this.validateAddress('', '', true);
    }
  }

  validateAddress(addressComponent, reset?, save?) {
    // do not validate if any address component is changed after user setting marker on map
    if ((this.setOnMap && !reset) ||
      (this.selectedStore.user_verified_flag && this.selectedStore.latitude && this.selectedStore.longitude)) {
      if (!addressComponent && save) {
        this.save();
      }
      return;
    }

    if (addressComponent === 'association_name' && this.selectedStore.latitude && this.selectedStore.longitude) {
      this.showMarker(this.selectedStore);
      return;
    }

    // Add marker on map only if country and city are selected
    if (!this.selectedStore.country || !this.selectedStore.country_code ||
      (!this.isNewStore && !this.selectedStore.city) || (this.isNewStore && !this.cityAutocomplete)) {
      this.focusCity = !((!this.isNewStore && this.selectedStore.city) || (this.isNewStore && this.cityAutocomplete));
      this.cityError = (!this.isNewStore && this.selectedStore.city) ||
      (this.isNewStore && this.cityAutocomplete) ? '' : 'City is required';
      this.focusCountry = !(this.selectedStore.country && this.selectedStore.country_code);
      return;
    }

    this.selectedStore.city = this.isNewStore ? this.cityAutocomplete : this.selectedStore.city;
    this.setOnMap = reset ? false : this.setOnMap;


    let address = '';
    let result;

    if (this.isNewStore || this.activeTab === 'invalid') {
      this.selectedStore.city = this.cityAutocomplete;
    }
    if (this.selectedStore.address_line_1) {
      address += this.selectedStore.address_line_1;
    }

    if (this.selectedStore.address_line_2) {
      address += ',' + this.selectedStore.address_line_2;
    }

    if (this.selectedStore.address_line_3) {
      address += ',' + this.selectedStore.address_line_3;
    }

    if (this.selectedStore.city &&
      address.indexOf(this.selectedStore.city) === -1) {
      address += ',' + this.selectedStore.city;
    }

    if (this.selectedStore.province) {
      address += ',' + this.selectedStore.province;
    }

    if (this.selectedStore.country &&
      address.indexOf(this.selectedStore.country) === -1) {
      address += ',' + this.selectedStore.country;
    }

    if (this.selectedStore.zip_code &&
      address.indexOf(this.selectedStore.zip_code) === -1) {
      address += ',' + this.selectedStore.zip_code;
    }

    this.focusCity = false;
    this.focusProvince = false;
    this.focusAddress = false;
    this.focusZipCode = false;
    this.focusCountry = false;
    this.misMatch = false;

    this.geocoder.geocode({
      address: address || '\'\''
    }, (results, status) => {
      if (status === 'OK') {
        result = results[0];
        this.focusCity = false;
        this.focusProvince = false;
        this.focusAddress = false;
        this.focusZipCode = false;
        this.selectedStore.latitude =
          typeof result.geometry.location.lat === 'function' ?
            result.geometry.location.lat() : result.geometry.location.lat;
        this.selectedStore.longitude =
          typeof result.geometry.location.lng === 'function' ?
            result.geometry.location.lng() : result.geometry.location.lng;
        this.misMatch = false;
        this.showMarker(this.selectedStore);
        if (this.selectedStore.latitude && this.selectedStore.longitude && save) {
          this.save();
        }
      } else {
        if (save && this.selectedStore.user_verified_flag && this.selectedStore.latitude && this.selectedStore.longitude) {
          this.save();
        } else {
          this.selectedStore.latitude = null;
          this.selectedStore.longitude = null;
          this.setOnMap = false;
          if (this.editMarker) {
            this.editMarker.setMap(null);
          }
          if (this.editInfoWindow) {
            this.editInfoWindow.close();
          }
          if (reset) {
            this.addMarker();
          } else {
            this.misMatch = true;
          }
        }
      }
    });
  }

  validateData(contact, dataType) {
    let regEx;
    if (dataType === 'data' && (contact.contact_type === 'Select' || !contact.contact_method)) {
      contact.contact_error = false;
      return;
    }

    if (dataType === 'name' && !contact.contact_person_name) {
      contact.contact_name_error = false;
      return;
    }

    // Allow digits, characters, space in contact person name
    if (dataType === 'name') {
      contact.contact_name_error = false;
      regEx = /^([0-9 a-z A-Z ])+$/;
      if (!regEx.test(contact.contact_person_name)) {
        contact.contact_name_error = true;
      }
    } else {
      contact.contact_error = false;
      if (contact.contact_type === 'Email' && !this._appService.validateEmail(contact.contact_method)) {
        contact.contact_error = true;
      }

      // Allow digits, +, space if contact type is mobile or WhatsApp
      if (contact.contact_type === 'Mobile' || contact.contact_type === 'WhatsApp') {
        regEx = /^([0-9+ ])+$/;
        if (!regEx.test(contact.contact_method)) {
          contact.contact_error = true;
        }
      }

      // Allow digits, -, space if contact type is fax or landline
      if (contact.contact_type === 'Fax' || contact.contact_type === 'Landline') {
        regEx = /^([0-9 +-])+$/;
        if (!regEx.test(contact.contact_method)) {
          contact.contact_error = true;
        }
      }
    }
  }

  // To point store on map
  viewStore(store, index) {
    this.clearInfoWindows();
    if (!store.latitude || !store.longitude) {
      return;
    }
    this.addMarkerOnMap({ lat: parseFloat(store.latitude), lng: parseFloat(store.longitude) },
      '', store, true);
    // map.setCenter({lat: parseFloat(store.lat), lng: parseFloat(store.lng)});
    this.infoWindows[0].open(this.googleMap, this.markers[0]);
    this.googleMap.setZoom(15);
    setTimeout(() => {
      google.maps.event.trigger(this.googleMap, 'resize');
    }, 100);
    this.selectedLine = index;
  }
}
