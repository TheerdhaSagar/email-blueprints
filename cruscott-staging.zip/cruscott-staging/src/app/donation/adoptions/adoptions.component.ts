import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { DataService } from '../../globals/data.service';
import { DonationService } from '../donationservice/donation.service';
import { Adoption } from '../adoption';

@Component({
  selector: 'app-donation-adoptions',
  templateUrl: './adoptions.component.html',
  styleUrls: ['./adoptions.component.scss'],
  providers: [OrderByPipe]
})
export class AdoptionsComponent implements OnInit, OnDestroy {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _donationService: DonationService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _orderBy: OrderByPipe;
  private _router: Router;
  private _window: any;

  adoptions: any;
  allAdoptions: any[];
  deletedAdoption: Adoption;
  deleteDialog: boolean;
  desc: boolean;
  orgId: number;
  pageDim: boolean;
  predicate: string;
  roles: any;
  searchQuery: any;
  selectedYear: string;
  showSpinner: boolean;
  subOrgChange: any;
  toggleFilter: (e?) => void;
  yearsList: any[];

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, donationService: DonationService,
              orderBy: OrderByPipe, formatService: FormatService, httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._donationService = donationService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._orderBy = orderBy;
    this._router = router;
    this._window = window;

    this.adoptions = null;
    this.allAdoptions = [];
    this.deletedAdoption = null;
    this.deleteDialog = false;
    this.desc = true;
    this.orgId = null;
    this.pageDim = false;
    this.predicate = 'adoption_id';
    this.roles = dataService.roles;
    this.selectedYear = '';
    this.showSpinner = null;
    this.subOrgChange = null;
    this.toggleFilter = appService.toggleFilter();
    this.yearsList = [];
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.orgId = this._cacheService.getOrgId();
        this.loadAdoptions();
        this.onOrgChange();
      }
    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  applyFilter(isToggle?) {
    if (isToggle) {
      this.toggleFilter();
    }
    if (this.selectedYear === 'ALL') {
      this.adoptions = this.allAdoptions;
    } else {
      this.adoptions = this.allAdoptions.filter((adoption) => adoption.adoption_year ===
        parseInt(this.selectedYear, 10));
    }
  }

  deleteAdoption(adoption): void {
    this.pageDim = true;
    this._donationService.deleteAdoption(adoption.adoption_id)
      .then((response) => {
        this.deleteDialog = false;
        this.loadAdoptions();
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.pageDim = false;
      });
  }

  exportData() {
    const data = this._orderBy.transform(this.adoptions, this.predicate, this.desc);
    const tableData: any = {};
    const tmpData = [];
    let dataObj: any;
    for (let i = 0; i < data.length; i++) {
      dataObj = {};
      dataObj['Association Name'] = { data: data[i].org_name };
      dataObj['Adopter Name'] = { data: data[i].pet_parent_name };
      dataObj.Address = { data: data[i].address };
      dataObj.City = { data: data[i].city };
      dataObj.Province = { data: data[i].province };
      dataObj.Country = { data: data[i].country };
      dataObj.Zip = { data: data[i].zip };
      dataObj.Email = { data: data[i].email };
      dataObj.Phone = { data: data[i].phone };
      dataObj['Adoption Date'] = { data: data[i].f_adoption_date };
      dataObj['Pet Name'] = { data: data[i].pet_name };
      dataObj['Pet Type'] = { data: data[i].pet_type };
      dataObj['Pet Age'] = { data: data[i].pet_age };
      dataObj['Pet Size'] = { data: data[i].pet_size };
      dataObj['Pet Breed'] = { data: data[i].pet_breed };
      dataObj['Created Date'] = { data: data[i].f_created_date };
      dataObj.Consent = { data: data[i].consent };
      tmpData.push(dataObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel('Adoptions', tableData, 'export-adoptions');
  }

  getCurrentYear() {
    const currentYear = new Date().getFullYear();
    const index = this.yearsList.findIndex((year) => year === currentYear);
    this.selectedYear = index !== -1 ? currentYear.toString() : 'ALL';
  }

  // Get the adopted year of the adoption
  getYearsList(adoption) {
    const adoptionDetails = adoption;
    if (adoptionDetails.adoption_date) {
      const year = adoptionDetails.adoption_date.split('-');
      adoptionDetails.adoption_year = parseInt(year[2], 10);
      const index = this.yearsList.findIndex((value) => value === parseInt(year[2], 10));
      if (index === -1) {
        this.yearsList.push(parseInt(year[2], 10));
      }
    }
  }

  loadAdoptions() {
    const endPoint = `/donation/adoptions/?user_org=${this.orgId}`;
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - loadAdoptions()' });
      } else if (data.status && data.status !== 'OK') {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        const adoptions = data.result;
        this.parseAdoptionDetails(adoptions);
        this.yearsList = [...this.yearsList].sort();
        this.yearsList.unshift('ALL');
        this.getCurrentYear();
        this.allAdoptions = adoptions;
        this.applyFilter();
      }
    });
  }

  onOrgChange() {
    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      if (this.orgId === this._cacheService.getOrgId()) {
        return;
      }
      this._router.routeReuseStrategy.shouldReuseRoute = () => false;
      this._router.navigate(['donation/adoptions']);
    });
  }

  openDeleteDialog(adoption) {
    this.deleteDialog = true;
    this.deletedAdoption = adoption;
  }

  parseAdoptionDetails(adoptionDetails) {
    const adoptions = adoptionDetails;
    for (let i = 0; i < adoptions.length; i++) {
      adoptions[i].adoption_date = adoptions[i].adoption_date || adoptions[i].created_date;
      adoptions[i].f_created_date = this._formatService.formatDate(adoptions[i].created_date);
      adoptions[i].f_adoption_date = this._formatService.formatDate(adoptions[i].adoption_date);
      adoptions[i].created_date_millis = this._formatService.dateInMillis(adoptions[i].created_date);
      adoptions[i].adoption_date_millis = this._formatService.dateInMillis(adoptions[i].adoption_date);
      adoptions[i].pet_type = adoptions[i].pet_type === 'DOG' ? 'Dog' : 'Cat';
      adoptions[i].pet_name = this._formatService.removeEscapeCharacter(adoptions[i].pet_name);
      adoptions[i].city = this._formatService.removeEscapeCharacter(adoptions[i].city);
      adoptions[i].org_name = this._formatService.removeEscapeCharacter(adoptions[i].org_name);
      adoptions[i].pet_parent_name = this._formatService.removeEscapeCharacter(adoptions[i].pet_parent_name);
      this.getYearsList(adoptions[i]);
    }
  }

  showDetails(adoption) {
    if (!adoption) {
      return;
    }

    this._appService.adoptionId = adoption.adoption_id;
    this._router.navigate(['donation/adoption']);
  }

  sort(key) {
    if (key === this.predicate) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
    }
  }

  viewProfile(adoption) {
    this._appService.associationId = adoption.org_id;
    this._appService.associationNavParent = 'donation/adoptions';
    this._router.navigate(['donation/association/profile']);
  }
}
