import {
  Component,
  ElementRef,
  Injector,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/globals/common.service';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { DonationService } from '../donationservice/donation.service';
import { Adoption } from '../adoption';
import { environment } from '../../../environments/environment';
import { APIError } from '../../globals/api.error';
import { Application } from '../application';
import { DonationOrganization } from '../organization';

declare const google;
declare const MSBlobBuilder;

@Component({
  selector: 'app-donation-association',
  templateUrl: './association.component.html',
  styleUrls: ['./association.component.scss'],
})
export class AssociationComponent implements OnInit, OnDestroy {
  @ViewChild('associationUpload') associationUpload: ElementRef;
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _commonService: CommonService = this.injector.get(CommonService);
  private _dataService: DataService = this.injector.get(DataService);
  private _donationService: DonationService = this.injector.get(
    DonationService
  );
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpClient: HttpClient = this.injector.get(HttpClient);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _sce: DomSanitizer = this.injector.get(DomSanitizer);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  private readonly WEBSITELINK: string;

  activeApplicationsTab: string;
  address: any;
  address1: any;
  addUser: any;
  adoptions: any;
  adoptionActivites: string;
  adoptMe: boolean;
  adoptMeApplications: any[];
  applicationNotes: any;
  applications: any;
  applicationName: string;
  applicationType: string;
  applicationTypes: any[];
  association: any;
  associationId: any;
  associationPhone: string;
  associationType: any;
  assocTypes: any[];
  autocomplete;
  city: any;
  countries: any;
  country: any;
  createApplicationError: boolean;
  createApplicationErrorMsg: string;
  deleteAdoption: Adoption;
  deleteAdoptionDialog: boolean;
  document: any;
  documentType: any;
  documentTypes: any;
  donationLoveFoodApplications: any[];
  donationLoveFoodBankApplications: any[];
  donationLoveFoodMeals: { catMeals: number; dogMeals: number; total: number };
  donationLoveFoodBankMeals: { catMeals: number; dogMeals: number; total: number };
  editUserLine: any;
  email: any;
  emailMsg: string;
  facebookPage: any;
  facebookMsg: string;
  fileData: any;
  fileDialog: any;
  firstName: any;
  focusEmail: boolean;
  focusFacebook: boolean;
  focusInstagram: boolean;
  focusLanguage: boolean;
  focusPhone: boolean;
  focusSelectedWorkFlow: boolean;
  focusWebsite: boolean;
  hasAccount: any;
  instagramMsg: string;
  instagramUrl: any;
  knownAs: any;
  lastName: any;
  loveFoodApplications: any[];
  newApplication: {
    address: string;
    city: string;
    province?: string;
    country: string;
    zip: string;
    contact_phone: string;
    cats: number;
    dogs: number;
    carrier_note: string;
  };
  newApplicationError: boolean;
  newOrCopy: string;
  noofCats: number;
  noofDogs: number;
  notes: any;
  orgName: any;
  pageDim: any;
  password: any;
  phone: any;
  projectType: string;
  province: any;
  purpose: any;
  recentApplication: Application;
  rePassword: any;
  roles: any;
  selectedApplicationId: string;
  selectedDocument: any;
  selectedUser: any;
  selectedWorkflow: string;
  shelterActivities: string;
  showAddressDialog: any;
  showChangePassword: boolean;
  showCreateApplicationDialog: boolean;
  showCreateCredentials: boolean;
  showDeleteDialog: any;
  showError: boolean;
  showUserDialog: any;
  subOrgChange: Subscription;
  totalCatMeals: any;
  totalDogMeals: any;
  totalKits: any;
  totalMeals: any;
  updateContactPassword: boolean;
  updateUser: any;
  user: any;
  username: any;
  users: any;
  usersWarning: boolean;
  website: any;
  websiteLanguage: string;
  websiteMsg: string;
  wildLifeApplications: any[];
  wildLifeTotalMeals: any;
  workflows: [];
  zipCode: any;

  constructor(private injector: Injector) {
    this._window = window;
    this.WEBSITELINK = environment.website_link;

    this.initializeApplication();
    this.activeApplicationsTab = 'adoptme';
    this.address = null;
    this.address1 = null;
    this.addUser = null;
    this.adoptions = null;
    this.adoptMe = false;
    this.adoptMeApplications = [];
    this.applicationNotes = [];
    this.applications = null;
    this.applicationName = '';
    this.applicationTypes = [
      {
        label: 'Welcome Kit AdoptMe',
        request_type: 'A',
      },
      {
        label: 'Donation AdoptMe',
        request_type: 'L',
      },
      {
        label: 'Donation LoveFood',
        request_type: 'DL',
      },
      {
        label: 'Habitat',
        request_type: 'H',
      },
      {
        label: 'Donation LoveFood Bank',
        request_type: 'LB',
      },
    ];
    this.association = null;
    this.associationId = this._appService.associationId;
    this.associationType = null;
    this.assocTypes = [
      {
        label: 'Onlus',
        value: 'ONLUS',
      },
      {
        label: 'Non Onlus',
        value: 'NON ONLUS',
      },
    ];
    this.city = null;
    this.countries = [];
    this.country = null;
    this.deleteAdoption = null;
    this.deleteAdoptionDialog = false;
    this.document = null;
    this.documentType = null;
    this.documentTypes = [];
    this.donationLoveFoodApplications = [];
    this.donationLoveFoodBankApplications = [];
    this.editUserLine = null;
    this.email = null;
    this.emailMsg = '';
    this.facebookPage = null;
    this.facebookMsg = '';
    this.fileData = null;
    this.fileDialog = null;
    this.firstName = null;
    this.focusEmail = false;
    this.focusFacebook = false;
    this.focusInstagram = false;
    this.focusLanguage = true;
    this.focusPhone = false;
    this.focusSelectedWorkFlow = true;
    this.focusWebsite = false;
    this.instagramMsg = '';
    this.instagramUrl = null;
    this.knownAs = '';
    this.lastName = null;
    this.loveFoodApplications = [];
    this.notes = '';
    this.pageDim = false;
    this.password = null;
    this.phone = null;
    this.province = null;
    this.purpose = null;
    this.roles = this._dataService.roles;
    this.selectedDocument = null;
    this.selectedUser = null;
    this.showAddressDialog = null;
    this.showChangePassword = false;
    this.showCreateCredentials = false;
    this.showDeleteDialog = null;
    this.showError = false;
    this.showUserDialog = null;
    this.totalKits = null;
    this.totalMeals = null;
    this.updateContactPassword = false;
    this.updateUser = null;
    this.user = null;
    this.users = null;
    this.usersWarning = false;
    this.website = null;
    this.websiteLanguage = '';
    this.websiteMsg = '';
    this.wildLifeApplications = [];
    this.zipCode = null;

    this._appService.associationId = null;
  }
  static trimStrings(val): string {
    if (val) {
      return val.trim();
    }
    return val;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._routeParams.queryParams.subscribe((params) => {
      if (params.project) {
        this.projectType = params.project.toString();
        if (this.projectType === 'humans-and-wild-life') {
          this.applicationType = 'H';
          this.activeApplicationsTab = 'humansandwildlife';
          this.newApplication.cats = 0;
        }
      }
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;

        if (!this.associationId) {
          if (
            this._cacheService.humansAndWildLifeRequest ===
            'humans-and-wild-life'
          ) {
            this._router.navigate(['donation/dashboard'], {
              queryParams: { project: 'humans-and-wild-life' },
            });
          } else {
            this._router.navigate(['donation/dashboard']);
          }
          return;
        }
        this._appService.associationChanged = false;
        this.loadData();
        this.loadApplications();
        this.loadNotes();
        this.loadDocumentTypes();
        this.loadAdoptions();
        this.loadCountries();

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this._cacheService.clearAssociations();
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  addNote() {
    if (!this.notes) {
      this._appService.notify({
        status: 1,
        msg: 'Nothing to add! Notes is empty',
      });
      return;
    }

    if (this.notes.length > 500) {
      return;
    }

    let endPoint = '/donation/association/notes/',
      req: any = {};
    req.org_id = this.associationId;
    req.notes = this.notes;
    req.user_id = this.user.user_id;

    this.applicationNotes.push({
      creation_date: this._formatService.formatDate(
        this._formatService.today(0)
      ),
      creation_time: '',
      created_by: this.user.user_description,
      notes: this.notes,
    });

    this.notes = '';
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: addNote()' });
      } else if (data.status === 'ERROR' || data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.loadNotes();
      }
    });
  }

  backToSummary(): void {
    let state;
    if (this._appService.associationNavParent) {
      state = this._appService.associationNavParent;
    } else {
      state = 'donation/users';
    }
    if (
      this._cacheService.humansAndWildLifeRequest === 'humans-and-wild-life'
    ) {
      this._router.navigate([state], {
        queryParams: { project: 'humans-and-wild-life' },
      });
    } else {
      this._router.navigate([state]);
    }
  }

  calculateTotalMeals(applications) {
    let totalMeals = 0,
      catMeals = 0,
      dogMeals = 0,
      mealDetails;
    applications.forEach((application) => {
      if (application.request_status === 'O') {
        catMeals += parseInt(application.cat_meals) || 0;
        dogMeals += parseInt(application.dog_meals) || 0;
      }
    });

    totalMeals = catMeals + dogMeals;

    catMeals = catMeals
      ? this._formatService.formatNumber(catMeals, 0, true)
      : 0;
    dogMeals = dogMeals
      ? this._formatService.formatNumber(dogMeals, 0, true)
      : 0;
    totalMeals = totalMeals
      ? this._formatService.formatNumber(totalMeals, 0, true)
      : 0;
    mealDetails = { catMeals, dogMeals, total: totalMeals };
    return mealDetails;
  }

  closeAddressDialog(): void {
    this.showAddressDialog = false;
    this.focusFacebook = false;
    this.focusInstagram = false;
    this.focusWebsite = false;
  }

  closeContactPasswordDialog(): void {
    this.updateContactPassword = false;
    this.showChangePassword = false;
    this.websiteLanguage = '';
    this.focusLanguage = true;
  }

  closeFileDialog(): void {
    this.document = null;
    this.documentType = null;
    this.purpose = null;
    this.fileDialog = false;
    this.associationUpload.nativeElement.value = null;
  }

  closeUserDialog(): void {
    this.firstName = null;
    this.lastName = null;
    this.email = null;
    this.phone = null;
    this.address = null;
    this.showUserDialog = false;
    this.focusEmail = false;
    this.focusPhone = false;
    this.emailMsg = '';
  }

  createApplication(): void {
    if (this.newOrCopy === 'copy') {
      this.focusSelectedWorkFlow = true;
      if (
        !this.validateCopyApplication() ||
        (this.focusSelectedWorkFlow && !this.selectedWorkflow)
      ) {
        this.focusSelectedWorkFlow = false;
        return;
      }

      this.createCopyApplication();
    } else {
      if (!this.validateNewApplication()) {
        return;
      }

      this.createNewApplication();
    }
  }

  createCognitoCredentials(user): void {
    this.pageDim = true;
    this.showCreateCredentials = false;
    let req = {
      role: ['donation-desk'],
      assoc_id: this.associationId,
      name: user.first_name,
      username: user.user_email,
      language: user.ui_language,
    };
    this._donationService
      .createCognitoCredentials(req)
      .then((response) => {
        let index = this.association.users.findIndex(
          (userDetails) => userDetails.user_email === user.user_email
        );
        this.association.users[index].resend_flag = true;
        this._appService.notify({ status: 0, msg: response });
      })
      .catch((error) => {
        this._appService.notify({ status: 1, msg: error });
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  createCopyApplication(): void {
    const endPoint = '/donation/application/copy/';
    const req = this.getCopyApplicationRequestData();
    this.pageDim = true;
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - createCopyApplication()',
        });
      } else if (data.msg) {
        this._appService.notify({
          status: data.status,
          msg: JSON.stringify(data.msg),
        });
        if (data.status === 0) {
          this.navigateToApplicationsSummary();
        }
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  createNewApplication(): void {
    let req = this.getNewApplicationRequestObject();
    const contactDetails = this.getApplicationContactDetails();
    req = { ...req, ...contactDetails };
    this.pageDim = true;
    this._httpService.httpRequest(
      'POST',
      '/donation/application/',
      req,
      (data) => {
        this.pageDim = false;
        if (!data) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error - createNewApplication()',
          });
        } else if (data.msg) {
          const status = data.status === 'OK' ? 0 : 1;
          this._appService.notify({ status, msg: data.msg });
          if (data.status === 'OK') {
            this.navigateToApplicationsSummary();
          }
        }
      }
    );
  }

  credentialsDialog(user): void {
    this.selectedUser = user;
    this.showCreateCredentials = true;
  }

  deleteAdoptionDetails(): void {
    this.pageDim = true;
    this._donationService
      .deleteAdoption(this.deleteAdoption.adoption_id)
      .then((response) => {
        this.deleteAdoptionDialog = false;
        this.loadAdoptions();
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  deleteData(): void {
    if (this.selectedUser) {
      this.deleteUser();
    } else if (this.selectedDocument) {
      this.deleteDocument();
    }
  }

  deleteDocument() {
    if (!this.selectedDocument) {
      return;
    }

    let index,
      endPoint =
        '/donation/association/documents/' +
        this.selectedDocument.atthmt_id +
        '/' +
        this.associationId +
        '/';

    index = this.association.documents.indexOf(this.selectedDocument);
    if (index === -1) {
      return;
    }

    this.association.documents.splice(index, 1);
    this.showDeleteDialog = false;

    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: deleteDocument()',
        });
      } else if (data.status === 'ERROR' || data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
        this.association.documents.push(this.selectedDocument);
      }
    });
  }

  deleteFileDialog(doc): void {
    this.selectedDocument = doc;
    this.selectedUser = null;
    this.showDeleteDialog = true;
  }

  deleteUser() {
    if (!this.selectedUser) {
      return;
    }
    let endPoint =
        '/donation/users/' +
        this.selectedUser.user_id +
        '/' +
        this.selectedUser.org_id +
        '/',
      index = this.association.users.indexOf(this.selectedUser);
    this.association.users.splice(index, 1);

    this.showDeleteDialog = false;
    this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: deleteUser()',
        });
      } else {
        if (data.status === 'ERROR' || data.status === 1) {
          this.association.users.push(this.selectedUser);
          this._appService.notify({ status: 1, msg: data.msg });
        }
        this._appService.associationChanged = true;
        this.selectedUser = null;
      }
    });
  }

  deleteUserDialog(assocUser): void {
    this.usersWarning = false;
    if (this.association.users.length === 1) {
      this.usersWarning = true;
      setTimeout(() => {
        this.usersWarning = false;
      }, 5000);
      return;
    }
    this.selectedUser = assocUser;
    this.selectedDocument = null;
    this.showDeleteDialog = true;
  }

  downloadDocument(document): void {
    const endPoint = `/donation/association/documents/${this.associationId}/${document.atthmt_id}/`;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: downloadDocument()',
        });
      } else if (data && data.status) {
        if (data.status === 'OK') {
          document.file_data = data.result[0].file_data;
          this.downloadFile(document);
        } else {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  downloadFile(attachment): void {
    this.fileData = attachment.file_data;
    // Convert blob to base64 formatHelper
    const blobFile = this._formatService.base64ToBlob(
      this.fileData,
      attachment.file_type
    );
    if (this._appService.isIE()) {
      const builder = new MSBlobBuilder();
      builder.append(blobFile);

      const blob = builder.getBlob(attachment.file_type);
      window.navigator.msSaveBlob(blob, attachment.file_name);
    } else {
      const url = this._window.URL.createObjectURL(blobFile);
      const a = document.createElement('a');
      document.body.appendChild(a);
      a.style.display = 'none';
      a.href = url;
      a.download = attachment.file_name;
      a.click();
    }
  }

  editActivityDetails(): void {
    this.noofCats = this.association.no_of_cat_sterilizations;
    this.noofDogs = this.association.no_of_dog_sterilizations;
    this.shelterActivities = this.association.shelter_activities;
    this.adoptionActivites = this.association.sterilization_adoption_act;
  }

  editDetails(): void {
    this.showError = false;
    this.orgName = this._formatService.removeEscapeCharacter(
      this.association.org_name
    );
    this.address1 = this.association.address;
    this.city = this.association.city;
    this.province = this.association.province || '';
    this.zipCode = this.association.zip;
    this.country = this.association.country || this.setDefaultCountry();
    this.associationPhone = this.association.telephone;
    this.website = this.association.website_url;
    this.facebookPage = this.association.facebook_page;
    this.instagramUrl = this.association.instagram_url;
    this.showAddressDialog = true;
    this.associationType = this.association.association_type
      ? this.association.association_type.toUpperCase()
      : '';
    this.adoptMe = this.association.adopt_me === 'Y';
    this.knownAs = this.association.known_as;
    this.editActivityDetails();
    this.initializeAddressAutoComplete('address1');
  }

  editUser(assocUser): void {
    this.focusEmail = false;
    this.focusPhone = false;
    this.firstName = assocUser.first_name;
    this.lastName = assocUser.last_name;
    this.email = assocUser.user_email;
    this.phone = assocUser.user_telephone;
    this.address = assocUser.address;
    this.addUser = false;
    this.updateUser = true;
    this.editUserLine = { ...assocUser };
    this.showUserDialog = true;
  }

  fillApplicationAddress(): void {
    if (this.recentApplication && this.recentApplication.ship_address) {
      const shipAddress = this.recentApplication.ship_address.split('@@');
      this.newApplication.address = shipAddress[0];
      this.newApplication.city = shipAddress[1];
      if (shipAddress.length === 5) {
        this.newApplication.province = shipAddress[2];
        this.newApplication.zip = shipAddress[3];
        this.newApplication.country = shipAddress[4];
      } else {
        this.newApplication.zip = shipAddress[2];
        this.newApplication.country = shipAddress[3];
      }
    } else {
      this.newApplication.address = this.association.address;
      this.newApplication.city = this.association.city;
      this.newApplication.province = this.association.province;
      this.newApplication.country = this.association.country;
      this.newApplication.zip = this.association.zip;
    }
  }

  formatAddress(data): SafeHtml {
    let formattedAddress = `${data.address || ''}<br/>${data.zip || ''} ${
      data.city || ''
    } `;
    if (data.province) {
      formattedAddress += `${data.province || ''}<br/>`;
    }
    formattedAddress += data.country === 'IT' ? 'ITALY' : data.country || '';
    if (data.telephone) {
      formattedAddress += `<br/>Tel: ${data.telephone || '-'}`;
    }
    return this._sce.bypassSecurityTrustHtml(formattedAddress.toUpperCase());
  }

  getApplicationContactDetails(): object {
    return {
      contact_phone: this.newApplication.contact_phone
        ? this.newApplication.contact_phone.toString().trim()
        : this.association.telephone,
    };
  }

  getCopyApplicationIndex(): number {
    return this.applications
      .map((appl) => appl.request_header_id)
      .indexOf(parseInt(this.selectedApplicationId, 10));
  }

  getCopyApplicationRequestData(): object {
    let req;
    const index = this.getCopyApplicationIndex();
    if (index !== -1) {
      req = { ...this.applications[index] };
      req.is_copy = 'N';
      req.lines = [
        {
          pet_type: 'DOG',
          no_of_pets: req.dogs,
          user_id: this.user.user_id,
        },
      ];
      req.wf_name = this.getWorkflowName(
        req.request_type,
        req.country,
        req.language,
        req.application_no
      );
      req.user_id = this.user.user_id;
      req.assoc_type = req.association_type || '';
      if (this.applicationType) {
        req.request_type = this.applicationType;
      }
    }
    return req;
  }

  getLanguage(country): string {
    this.focusLanguage = true;
    let websiteUrlLang = '';
    if (['BE_FR', 'BE_NL'].indexOf(country) !== -1) {
      let language = this.association.country.split('_');
      this.websiteLanguage = language[1].toLowerCase();
      websiteUrlLang = language[1].toLowerCase() + '_' + language[0];
    } else if (country !== 'BE') {
      this.websiteLanguage = this.association.country.toLowerCase();
      websiteUrlLang = this.websiteLanguage;
    } else {
      websiteUrlLang = this.websiteLanguage + '_' + country;
    }
    if (!this.websiteLanguage) {
      this.focusLanguage = false;
      return;
    }
    return `${this.WEBSITELINK}/${websiteUrlLang}/reset-password/`;
  }

  getNewApplicationRequestObject(): object {
    return {
      user_id: this.user.user_id,
      org_id: this.associationId,
      org_name: this.association.org_name,
      address: this.newApplication.address,
      province: this.newApplication.province,
      city: this.newApplication.city,
      zip: this.newApplication.zip,
      country: this.newApplication.country,
      language: this.association.language,
      ship_address: this.getShippingAddress(),
      request_type: this.applicationType,
      assoc_type: this.association.association_type,
      lines: this.getPetDetails(),
      wf_name:
        this.selectedWorkflow ||
        this.getWorkflowName(
          this.applicationType,
          this.newApplication.country,
          this.association.language
        ),
      appl_source: 'CRUSCOTT',
      user_name: this.association.user_name,
      user_email: this.association.user_email,
      carrier_note: this.newApplication.carrier_note,
    };
  }

  getPetDetails(): object {
    const pets = [];
    if (this.newApplication.dogs) {
      pets.push({
        pet_type: 'DOG',
        no_of_pets: this.newApplication.dogs,
      });
    }
    if (this.newApplication.cats) {
      pets.push({
        pet_type: 'CAT',
        no_of_pets: this.newApplication.cats,
      });
    }
    return pets;
  }

  getRecentApplication(): void {
    if (this.applications.length) {
      [this.recentApplication] = this.applications;
      const finalDate = this._formatService.dateInMillis(
        this._formatService.parseDate(this.recentApplication.created_date)
      );
      this.applications.forEach((application) => {
        const appDate = this._formatService.dateInMillis(
          this._formatService.parseDate(application.created_date)
        );
        this.recentApplication =
          finalDate < appDate ? application : this.recentApplication;
      });
    }
  }

  getShippingAddress(): string {
    let shippingAddress = `${this.newApplication.address}@@${this.newApplication.city}@@`;
    if (this.newApplication.province) {
      shippingAddress += `${this.newApplication.province}@@`;
    }
    shippingAddress += `${this.newApplication.zip}@@${this.newApplication.country}`;
    return shippingAddress;
  }

  getWorkflowName(reqType, country, language, applicationNo?) {
    if (reqType === 'H') {
      return 'QPEX_DDESK_HW_IT';
    }
    if (country === 'BE' || country === 'BE_FR' || country === 'BE_NL') {
      if (
        (applicationNo && applicationNo.indexOf('BE_NL') !== -1) ||
        (country === 'BE' && language === 'NL')
      ) {
        return 'QPEX_DDESK_LF_BE_NL';
      }
      return 'QPEX_DDESK_LF_BE_FR';
    }
    switch (this._cacheService.getOrgId()) {
      default:
      case 82:
        return 'QPEX_DDESK_LF_IT';
      case 101:
        return 'QPEX_DDESK_LF_FR';
      case 181:
        return 'QPEX_DDESK_LF_NL';
      case 83:
        return 'QPEX_DDESK_LF_DE';
    }
  }

  initializeAddressAutoComplete(fieldId): void {
    setTimeout(() => {
      const address = document.getElementById(fieldId);
      if (address) {
        if (google && google.maps) {
          this.autocomplete = new google.maps.places.Autocomplete(address, {
            componentRestrictions: {
              country: this.newApplication.country.toLowerCase(),
            },
          });
          if (fieldId === 'address1') {
            google.maps.event.addListener(
              this.autocomplete,
              'place_changed',
              this.onAssociationAddressChange.bind(this)
            );
          } else {
            google.maps.event.addListener(
              this.autocomplete,
              'place_changed',
              this.onPlaceChange.bind(this)
            );
          }
        }
      }
    }, 100);
  }

  initializeApplication(): void {
    this.newApplication = {
      address: null,
      city: null,
      province: null,
      country: null,
      zip: null,
      contact_phone: null,
      cats: null,
      dogs: null,
      carrier_note: '',
    };
    this.setDefaultCountry();
    this.loadWorkflows();
  }

  loadAdoptions(): void {
    this._httpService.httpRequest(
      'GET',
      `/donation/adoptions/?assoc_id=${this.associationId}`,
      null,
      (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error: loadAdoptions()',
          });
        } else if (data.status && data.status !== 'OK') {
          this._appService.notify({ status: 1, msg: data.msg });
        } else {
          const adoptions = data.result;
          for (let i = 0; i < adoptions.length; i++) {
            adoptions[i].f_created_date = this._formatService.formatDate(
              adoptions[i].created_date
            );
            adoptions[i].f_adoption_date = this._formatService.formatDate(
              adoptions[i].adoption_date
            );
            adoptions[i].pet_type =
              adoptions[i].pet_type === 'DOG' ? 'Dog' : 'Cat';
            adoptions[i].f_pet_name = this._formatService.removeEscapeCharacter(
              adoptions[i].pet_name
            );
            adoptions[
              i
            ].f_pet_parent_name = this._formatService.removeEscapeCharacter(
              adoptions[i].pet_parent_name
            );
            adoptions[i].f_city = this._formatService.removeEscapeCharacter(
              adoptions[i].city
            );
          }
          this.adoptions = adoptions;
        }
      }
    );
  }

  loadApplications() {
    let endPoint = '/donation/applications/?assoc_id=' + this.associationId;
    if (
      this._cacheService.humansAndWildLifeRequest === 'humans-and-wild-life'
    ) {
      endPoint += '&org_type=humansandwildlife';
    }
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadApplications()',
        });
      } else if (data.status === 'OK') {
        const applications = data.result;
        for (let i = 0; i < applications.length; i++) {
          applications[i].f_created_date = this._formatService.formatDate(
            applications[i].created_date
          );
          applications[i].f_recent_update_date = this._formatService.formatDate(
            applications[i].recent_update_date
          );
          applications[
            i
          ].f_application_no = this._formatService.removeEscapeCharacter(
            applications[i].application_no
          );
          this.applicationName +=
            !this._donationService.validateApplicationForCountry(
              applications[i]
            ) &&
            applications[i].request_status === 'O' &&
            applications[i].ricevuta === 'N'
              ? `${applications[i].application_no}, `
              : '';
        }

        applications.forEach((application) => {
          if (application.request_type === 'L') {
            this.loveFoodApplications.push(application);
          } else if (application.request_type === 'A') {
            this.adoptMeApplications.push(application);
          } else if (application.request_type === 'H') {
            this.wildLifeApplications.push(application);
          } else if (application.request_type === 'DL') {
            this.donationLoveFoodApplications.push(application);
          } else if (application.request_type === 'LB') {
            this.donationLoveFoodBankApplications.push(application);
          }
        });

        this.applications = applications;
        this.getRecentApplication();
        this.totalMeals = this.calculateTotalMeals(this.loveFoodApplications);
        this.totalKits = this.calculateTotalMeals(this.adoptMeApplications);
        this.wildLifeTotalMeals = this.calculateTotalMeals(
          this.wildLifeApplications
        );
        this.donationLoveFoodMeals = this.calculateTotalMeals(
          this.donationLoveFoodApplications
        );
        this.donationLoveFoodBankMeals = this.calculateTotalMeals(
          this.donationLoveFoodBankApplications
        );
      } else {
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  loadCountries(): void {
    const endPoint = '/registration/countries/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadCountries()',
        });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.countries = data;
      }
    });
  }

  loadData() {
    let endPoint = '/donation/associations/' + this.associationId + '/';
    this.pageDim = true;

    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: loadData()' });
      } else if (data.status === 'OK') {
        this.association = data.result[0];
        this.association.org_name = this._formatService.removeEscapeCharacter(
          this.association.org_name
        );
        this.association.address = this._formatService.removeEscapeCharacter(
          this.association.address
        );
        this.association.city = this._formatService.removeEscapeCharacter(
          this.association.city
        );
        this.association.association_type =
          this.association.association_type === 'NON ONLUS'
            ? 'NON ONLUS'
            : 'ONLUS';
        if (this.association.website_url) {
          if (
            this.association.website_url.indexOf('http://') === -1 &&
            this.association.website_url.indexOf('https://') === -1
          ) {
            this.association.website_url =
              'http://' + this.association.website_url;
          }
        }
        if (this.association.facebook_page) {
          if (
            this.association.facebook_page.indexOf('http://') === -1 &&
            this.association.facebook_page.indexOf('https://') === -1
          ) {
            this.association.facebook_page =
              'https://' + this.association.facebook_page;
          }
        }
        if (this.association.instagram_url) {
          if (
            this.association.instagram_url.indexOf('http://') === -1 &&
            this.association.instagram_url.indexOf('https://') === -1
          ) {
            this.association.instagram_url =
              'https://' + this.association.instagram_url;
          }
        }
        this.association.formatted_address = this.formatAddress(
          this.association
        );
        this.association.no_of_cat_sterilizations = this.association
          .no_of_cat_sterilizations
          ? this._formatService.formatNumber(
              this.association.no_of_cat_sterilizations
            )
          : null;
        this.association.no_of_dog_sterilizations = this.association
          .no_of_cat_sterilizations
          ? this._formatService.formatNumber(
              this.association.no_of_dog_sterilizations
            )
          : null;
        this._donationService.formatAttachmentName(this.association.documents);
        this.users = data.result[0].users;
      } else {
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  loadDocumentTypes(): void {
    const endPoint = '/donation/lookup/DOCUMENTS/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadDocumentTypes()',
        });
      } else if (data.status === 'ERROR' || data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.documentTypes = data.result;
      }
    });
  }

  loadNotes(): void {
    const endPoint = `/donation/association/notes/${this.associationId}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadNotes()',
        });
      } else {
        if (data.status === 'ERROR' || data.status === 1) {
          this._appService.notify({ status: 1, msg: data.msg });
          return;
        }
        const result = data.result;
        for (let i = 0; i < result.length; i++) {
          result[i].f_creation_date = this._formatService.formatDate(
            result[i].creation_date
          );
          result[i].notes = this._appService.replaceAll(
            result[i].notes,
            '\n',
            '<br>'
          );
        }

        this.applicationNotes = result;
      }
    });
  }

  loadWorkflows(): void {
    const endPoint = '/workflows/?module=Donation Desk';
    this._httpService.httpRequest('GET', endPoint, null, (response) => {
      if (!response) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadWorkflows()',
        });
      } else if (response.msg) {
        this._appService.notify({ status: response.status, msg: response.msg });
      } else {
        this.workflows = response.filter((workflow) => workflow.active === 'Y');
      }
    });
  }

  async manageUser() {
    this.pageDim = true;
    if (this.addUser && (await this.validateEmailAddress(this.email, true))) {
      this.focusEmail = true;
      this.pageDim = false;
      return;
    }

    if (this.phone) {
      let regEx = /^([0-9 +-])+$/;
      if (!regEx.test(this.phone)) {
        this.focusPhone = true;
        return;
      }
    }
    this.pageDim = false;
    if (!this.validateUser()) {
      this._appService.notify({
        status: 1,
        msg: 'Please fill all mandatory fields',
      });
      return;
    }
    let endPoint = '/donation/users/',
      method,
      req: any = {},
      index,
      assocUser,
      reqMsg;
    method = this.addUser ? 'POST' : 'PUT';
    this.focusEmail = false;
    this.focusPhone = false;
    req.first_name = this.firstName;
    req.last_name = this.lastName || '';
    req.user_email = this.email;
    req.user_telephone = this.phone;
    req.address = this.address;
    req.site_id = '';
    req.approval_status = '';
    req.ui_language = this.association.language;
    req.org_id = this.associationId;
    req.updated_user_id = this.user.user_id;
    req.subscribe_to_advs = '';
    req.cust_acct_site_id = '';
    req.user_name = '';
    req.password = '';

    this.closeUserDialog();

    if (this.addUser) {
      req.resend_flag = true;
      this.association.users.push(req);
    } else {
      if (this.editUserLine) {
        index = this.association.users
          .map((x) => x.user_id)
          .indexOf(this.editUserLine.user_id);

        assocUser = this.association.users[index];
        assocUser.first_name = req.first_name;
        assocUser.last_name = req.last_name;
        assocUser.user_email = req.user_email;
        assocUser.user_telephone = req.user_telephone;
        assocUser.address = req.address;

        this.association.users[index] = assocUser;
        req.user_id = this.editUserLine.user_id;
        req.approval_status = this.editUserLine.approval_status || '';
      } else {
        this._appService.notify({
          status: 1,
          msg: 'User details not found / invalid user',
        });
        return;
      }
    }

    this._httpService.httpRequest(method, endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: manageUser()',
        });
      } else {
        try {
          let length = this.association.users.length;
          if (data.status && data.status === 1) {
            this._appService.notify({ status: 1, msg: data.msg });
          } else if (data.status === 'ERROR') {
            if (this.addUser) {
              this.association.users.splice(length - 1, 1);
            } else {
              this.association.users[index] = this.editUserLine;
            }
            this._appService.notify({ status: 1, msg: data.msg });
          } else {
            if (data.msg) {
              this._appService.notify({ msg: data.msg, status: 0 });
            }
            if (this.addUser) {
              this.association.users[length - 1].user_id = data.user_id;
              if ('resend_flag' in data) {
                this.association.users[length - 1].resend_flag =
                  data.resend_flag;
              }
            }
          }
          this._appService.associationChanged = true;
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>',
          });
        }
      }
    });
  }

  static matchAddressType(types): string {
    const addressTypes = [
      'route',
      'locality',
      'administrative_area_level_2',
      'postal_code',
    ];
    for (let i = 0; i < types.length; i++) {
      for (let j = 0; j < addressTypes.length; j++) {
        if (types[i] === addressTypes[j]) {
          return types[i];
        }
      }
    }
    return '';
  }

  navigateToApplicationsSummary(): void {
    if (this.projectType && this.projectType === 'humans-and-wild-life') {
      this._router.navigate(['donation/applications'], {
        queryParams: { project: 'humans-and-wild-life' },
      });
    } else {
      this._router.navigate(['donation/applications']);
    }
  }

  onAssociationAddressChange(): void {
    const components = this.autocomplete.getPlace().address_components;
    for (let i = 0; i < components.length; i++) {
      switch (AssociationComponent.matchAddressType(components[i].types)) {
        case 'route':
          this.address1 = components[i].long_name;
          break;
        case 'locality':
          this.city = components[i].long_name;
          break;
        case 'administrative_area_level_2':
          this.province = components[i].short_name;
          break;
        case 'postal_code':
          this.zipCode = components[i].long_name;
          break;
        default:
          break;
      }
    }
  }

  onPlaceChange(): void {
    const components = this.autocomplete.getPlace().address_components;
    for (let i = 0; i < components.length; i++) {
      switch (AssociationComponent.matchAddressType(components[i].types)) {
        case 'route':
          this.newApplication.address = components[i].long_name;
          break;
        case 'locality':
          this.newApplication.city = components[i].long_name;
          break;
        case 'administrative_area_level_2':
          this.newApplication.province = components[i].short_name;
          break;
        case 'postal_code':
          this.newApplication.zip = components[i].long_name;
          break;
        default:
          break;
      }
    }
  }

  openDeleteAdoptionDialog(adoption): void {
    this.deleteAdoptionDialog = true;
    this.deleteAdoption = adoption;
  }

  resetPasswordLink(): void {
    this.pageDim = true;
    let resetLink = this.getLanguage(this.association.country);
    if (!resetLink) {
      this.pageDim = false;
      return;
    }
    let requestData = {
      username: this.selectedUser.user_email,
      language: this.websiteLanguage,
      reset_link: resetLink,
    };
    this.closeContactPasswordDialog();
    this._donationService
      .resendContactPasswordLink(requestData)
      .then((response) => {
        this._appService.notify(response);
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  setDefaultCountry(): void {
    const orgId = this._cacheService.getOrgId();
    if (orgId === 82) {
      this.country = 'IT';
      this.newApplication.country = 'IT';
    } else if (orgId === 83) {
      this.country = 'DE';
      this.newApplication.country = 'DE';
    } else if (orgId === 101) {
      this.country = 'FR';
      this.newApplication.country = 'FR';
    } else if (orgId === 181) {
      this.country = 'NL';
      this.newApplication.country = 'NL';
    }
  }

  setFocus(type): void {
    if (type === 'website') {
      this.focusWebsite = true;
    } else if (type === 'facebook') {
      this.focusFacebook = true;
    } else {
      this.focusInstagram = true;
    }
  }

  setUpdateFocus(): void {
    this.showError = false;
    this.focusFacebook = false;
    this.focusInstagram = false;
    this.focusWebsite = false;
    this.facebookMsg = '';
    this.instagramMsg = '';
    this.websiteMsg = '';
    this.showAddressDialog = false;
  }

  showDetails(adoption): void {
    if (!adoption) {
      return;
    }

    this._appService.adoptionNavParent = 'donation/association/profile';
    this._appService.associationId = this.associationId;
    this._appService.adoptionId = adoption.adoption_id;
    this._router.navigate(['donation/adoption']);
  }

  async updateAddress(): Promise<void> {
    if (
      !this.orgName ||
      !this.address1 ||
      !this.city ||
      !this.zipCode ||
      !this.country ||
      !this.associationPhone
    ) {
      this._appService.notify({
        status: 1,
        msg: 'Please enter all mandatory fields',
      });
      this.showError = true;
      return;
    }
    await this.updateAddressUrl();
    if (this.focusFacebook || this.focusInstagram || this.focusWebsite) {
      this.pageDim = false;
      return;
    }
    const req = {
      org_id: this.association.org_id,
      user_id: this.user.user_id,
      assoc_type: this.associationType,
      known_as: this.knownAs,
      ...this.updateAddressRequest(),
    };
    this.updateAddressHttp(req);
  }

  updateAddressHttp(req): void {
    this.setUpdateFocus();
    const endPoint = '/donation/organization/';
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if ('status' in data) {
        if (data.status === 'OK') {
          this.updateAddressResponse();
          this._appService.associationChanged = true;
        }
        this._appService.notify({
          status: data.status === 'OK' ? 0 : 1,
          msg: data.msg,
        });
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  updateAddressRequest(): DonationOrganization {
    return {
      org_name: AssociationComponent.trimStrings(this.orgName).toUpperCase(),
      telephone: this.associationPhone
        ? this.associationPhone.toString().trim()
        : '',
      address: AssociationComponent.trimStrings(this.address1).toUpperCase(),
      city: AssociationComponent.trimStrings(this.city).toUpperCase(),
      province: AssociationComponent.trimStrings(this.province).toUpperCase(),
      zip_code:
        this.zipCode && this.zipCode instanceof String
          ? AssociationComponent.trimStrings(this.zipCode).toUpperCase()
          : this.zipCode,
      country: this.country ? this.country.trim().toUpperCase() : '',
      website_url: this.website ? this.website.trim() : '',
      facebook_page: this.facebookPage ? this.facebookPage.trim() : '',
      instagram_url: this.instagramUrl ? this.instagramUrl.trim() : '',
      org_type: this.association.org_type,
      adopt_me: this.adoptMe ? 'Y' : 'N',
      no_of_cat_sterilizations: this.noofCats
        ? this._formatService.parseNumber(this.noofCats)
        : null,
      no_of_dog_sterilizations: this.noofDogs
        ? this._formatService.parseNumber(this.noofDogs)
        : null,
      sterilization_adoption_act: this.adoptionActivites,
      shelter_activities: this.shelterActivities,
    };
  }

  updateAddressResponse(): void {
    this.association.association_type = this.associationType;
    this.association.org_name = this.orgName;
    this.association.address = this.address1;
    this.association.city = this.city;
    this.association.zip = this.zipCode;
    this.association.country = this.country;
    this.association.province = this.province || '';
    this.association.telephone = this.associationPhone;
    this.association.website_url = this.website;
    this.association.facebook_page = this.facebookPage;
    this.association.instagram_url = this.instagramUrl;
    this.association.formatted_address = this.formatAddress(this.association);
    this.association.adopt_me = this.adoptMe ? 'Y' : 'N';
    this.association.known_as = this.knownAs;
    this.association.no_of_cat_sterilizations = this.noofCats;
    this.association.no_of_dog_sterilizations = this.noofDogs;
    this.association.sterilization_adoption_act = this.adoptionActivites;
    this.association.shelter_activities = this.shelterActivities;
  }

  async updateAddressUrl(): Promise<void[]> {
    const promise = [];
    this.validateNumber('noofCats', this.noofCats);
    this.validateNumber('noofDogs', this.noofDogs);
    const validateFacebook = this.validateMaxLength(
      this.facebookPage,
      'facebook'
    );
    const validateInstagram = this.validateMaxLength(
      this.instagramUrl,
      'instagram'
    );
    const validateWebsite = this.validateMaxLength(this.website, 'website');
    if (!(validateFacebook || validateInstagram || validateWebsite)) {
      this.pageDim = true;
      promise.push(await this.validateUrl(this.facebookPage, 'facebook'));
      // promise.push(await this.validateUrl(this.instagramUrl, 'instagram'));
      promise.push(await this.validateUrl(this.website, 'website'));
    }
    return promise;
  }

  uploadDocument() {
    if (!this.documentType || !this.purpose || !this.document) {
      this._appService.notify({
        status: 1,
        msg: 'Please fill all mandatory fields',
      });
      return;
    }

    let endPoint = '/donation/association/documents/',
      req: any = {},
      length,
      index;
    req.org_id = this.associationId;
    req.file_name = this._formatService.removeEscapeCharacter(
      this.document.filename
    );
    req.file_type = this.document.filetype || '';
    req.file_data = this.document.base64;
    req.document_type = this.documentType;
    req.purpose = this.purpose || '';
    req.created_by = this.user.user_id;

    this.closeFileDialog();
    index = this.documentTypes
      .map((x) => x.lookup_key)
      .indexOf(req.document_type);

    this.association.documents.push(JSON.parse(JSON.stringify(req)));
    length = this.association.documents.length;
    this.association.documents[length - 1].document_type = this.documentTypes[
      index
    ].lookup_value;

    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: uploadDocument()',
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (data.status === 'ERROR') {
        this.association.documents.splice(length - 1, 1);
      } else {
        this.association.documents[length - 1].atthmt_id = data.attachment_id;
      }
    });
  }

  validationApplication(): boolean {
    this.createApplicationError = false;
    if (!this.applicationType) {
      this.createApplicationError = true;
      this.createApplicationErrorMsg = 'Please select application type';
      return false;
    }
    return true;
  }

  validateCopyApplication(): boolean {
    this.createApplicationError = false;
    if (!this.selectedApplicationId) {
      this.createApplicationError = true;
      this.createApplicationErrorMsg =
        'Please select an application to continue';
      return false;
    }
    if (this.getCopyApplicationIndex() === -1) {
      this.createApplicationError = true;
      this.createApplicationErrorMsg = `There is an error with the selected application. Please
        select another application to continue`;
      return false;
    }

    return this.validationApplication();
  }

  validateCreateApplication(): void {
    this.newApplicationError = false;
    this.createApplicationError = false;
    this.focusSelectedWorkFlow = true;
    if (
      this._donationService.validateApplication(
        this.applicationName,
        this.applications
      )
    ) {
      this.newOrCopy = null;
      this.showCreateApplicationDialog = true;
      this.fillApplicationAddress();
      this.newApplication.contact_phone = this.association.telephone;
    }
  }

  validateNumber(key, val): void {
    this[key] = this._commonService.validateNumber(val).val;
  }

  updatePasswordDetails(event): void {
    this.pageDim = true;
    let passwordDetails = event;
    passwordDetails.username = this.selectedUser.user_email;
    this.closeContactPasswordDialog();
    this._donationService
      .changeContactPassword(passwordDetails)
      .then((response) => {
        this._appService.notify(response);
      })
      .catch((error) => {
        this._appService.notify(error);
      })
      .finally(() => {
        this.pageDim = false;
      });
  }

  updatePasswordDialog(user) {
    this.selectedUser = user;
    this.updateContactPassword = true;
  }

  validateEmailAddress(emailAddress, flag): Promise<boolean> {
    return new Promise((resolve) => {
      if (emailAddress && this._appService.validateEmail(emailAddress)) {
        this._donationService
          .validateEmailInCognito(emailAddress)
          .then(() => {
            if (flag) {
              this.emailMsg = '';
            }
            resolve(false);
          })
          .catch((error) => {
            if (flag) {
              this.emailMsg = error.msg;
            }
            resolve(true);
          });
      } else {
        resolve(true);
      }
    });
  }

  validateMaxLength(value, type): boolean {
    let result = false;
    if (value) {
      if (
        type === 'facebook' &&
        (value.indexOf('facebook') === -1 || value.length >= 300)
      ) {
        this.focusFacebook = true;
        this.facebookMsg =
          value.length >= 300
            ? 'Maximum Length of 300 characters in facebook Page'
            : 'Enter a valid facebook URL';
        result = true;
      } else if (type === 'website' && value.length >= 300) {
        this.focusWebsite = true;
        this.websiteMsg =
          value.length >= 300
            ? 'Maximum Length of 300 characters in Website'
            : 'Enter a valid Website';
        result = true;
      } else if (
        type === 'instagram' &&
        (value.indexOf('instagram') === -1 || value.length >= 250)
      ) {
        this.focusInstagram = true;
        this.instagramMsg =
          value.length >= 300
            ? 'Maximum Length of 250 characters in Instagram Url'
            : 'Enter a valid instagram page';
        result = true;
      }
    }
    return result;
  }

  validateNewApplication(): boolean {
    this.newApplicationError = false;
    this.focusSelectedWorkFlow = true;
    if (
      !this.validationApplication() ||
      (this.focusSelectedWorkFlow && !this.selectedWorkflow) ||
      !this.newApplication.address ||
      !this.newApplication.city ||
      !this.newApplication.zip ||
      !this.newApplication.country ||
      !this.newApplication.contact_phone ||
      this.newApplication.cats === null ||
      this.newApplication.cats < 0 ||
      this.newApplication.dogs === null ||
      this.newApplication.dogs < 0 ||
      (this.newApplication.carrier_note &&
        this.newApplication.carrier_note.length > 180)
    ) {
      this.newApplicationError = true;
      this.focusSelectedWorkFlow = false;
      return false;
    }

    return true;
  }

  validateUrl(url, type): Promise<void> {
    return new Promise((resolve) => {
      if (url) {
        this._donationService
          .validateUrl({ url })
          .catch(() => {
            this.setFocus(type);
          })
          .finally(() => {
            resolve();
          });
      } else {
        resolve();
      }
    });
  }

  validateUser(): boolean {
    return this.firstName && this.email;
  }

  viewApplication(application): void {
    this._appService.applicationNavParent = 'donation/association/profile';
    this._appService.associationId = this.associationId;
    this._appService.requestHeaderId = application.request_header_id;
    if (this.projectType && this.projectType === 'humans-and-wild-life') {
      this._router.navigate(['donation/application'], {
        queryParams: { project: this.projectType },
      });
    } else {
      this._router.navigate(['donation/application']);
    }
  }
}
