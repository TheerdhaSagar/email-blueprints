export interface DonationOrganization {
  address: string;
  adopt_me: string;
  city: string;
  country: string;
  facebook_page: string;
  instagram_url: string;
  no_of_cat_sterilizations: number;
  no_of_dog_sterilizations: number;
  org_id?: number;
  org_name: string;
  org_type: string;
  province: string;
  shelter_activities: string;
  sterilization_adoption_act: string;
  telephone: string;
  website_url: string;
  zip_code: string;
}
