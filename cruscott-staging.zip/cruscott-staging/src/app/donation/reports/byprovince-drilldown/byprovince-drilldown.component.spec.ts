import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ByprovinceDrilldownComponent } from './byprovince-drilldown.component';

describe('ByprovinceDrilldownComponent', () => {
  let component: ByprovinceDrilldownComponent;
  let fixture: ComponentFixture<ByprovinceDrilldownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ByprovinceDrilldownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ByprovinceDrilldownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
