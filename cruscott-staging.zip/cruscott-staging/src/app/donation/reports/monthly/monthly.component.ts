import {
  Component,
  OnDestroy,
  OnInit,
  Injector
} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { DataService } from '../../../globals/data.service';
import { FormatService } from '../../../globals/format.service';
import { HttpService } from '../../../globals/http.service';

@Component({
  selector: 'app-donation-reports-monthly',
  templateUrl: './monthly.component.html',
  styleUrls: ['./monthly.component.scss']
})
export class DonationMonthlyReportComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _router: Router = this.injector.get(Router);

  currentYear: any;
  currentYearTotal = 0;
  data: any;
  drillDownData: any;
  fromDate: any;
  monthlyReportData: any[];
  months: ({ full_name: string; name: string })[];
  names: any[];
  previousYearTotal = 0;
  projectType: string;
  selectedYear: any;
  showSpinner: boolean;
  subOrgChange: any;
  toDate: any;
  toggleFilter: any;
  years: any[];
  yearsList: any[];

  constructor(private injector: Injector) {

    this.currentYear = '';
    this.currentYearTotal = 0;
    this.data = '';
    this.drillDownData = '';
    this.fromDate = '';
    this.monthlyReportData = [];
    this.months = [
      { name: 'JAN', full_name: 'January' },
      { name: 'FEB', full_name: 'Febuary' },
      { name: 'MAR', full_name: 'March' },
      { name: 'APR', full_name: 'April' },
      { name: 'MAY', full_name: 'May' },
      { name: 'JUN', full_name: 'June' },
      { name: 'JUL', full_name: 'July' },
      { name: 'AUG', full_name: 'August' },
      { name: 'SEP', full_name: 'September' },
      { name: 'OCT', full_name: 'October' },
      { name: 'NOV', full_name: 'November' },
      { name: 'DEC', full_name: 'December' }
    ];
    this.names = [];
    this.previousYearTotal = 0;
    this.selectedYear = '';
    this.showSpinner = false;
    this.subOrgChange = '';
    this.toDate = '';
    this.toggleFilter = this._appService.toggleFilter();
    this.years = [];
    this.yearsList = [];
  }

  ngOnInit() {
    this._routeParams.queryParams.subscribe((params) => {
      this.projectType = params.project;
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.currentYear = new Date().getFullYear();
        this.selectedYear = this.currentYear;
        this.showSpinner = true;
        this.loadYears();
        this.loadData();
      }
    });

    this.subOrgChange = this._appService.subscribeOrgChange(() => {
      this.showSpinner = true;
      this.loadData();
    });
  }

  ngOnDestroy() {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  applyFilter() {
    this.toggleFilter();
    this.showSpinner = true;
    this.loadData();
  }

  exportData() {
    this.toggleFilter();
    const reportName = this.projectType ? 'H&W ' : 'Donation ';
    let monthData, i, j, k, list = [], tableData: any = {}, tmpData = [], tmpObj: any = {},
      listData: any = {}, excelName;
    monthData = this.monthlyReportData;

    for (i = 0; i < monthData.length; i++) {
      tableData = {};
      tmpData = [];
      listData = {};
      for (j = 0; j < monthData[i].data.length; j++) {
        tmpObj = {};
        tmpObj.Year = { data: monthData[i].data[j].year };
        for (k = 0; k < this.months.length; k++) {
          tmpObj[this.months[k].full_name] = { data: monthData[i].data[j].data[k].total_meals || '0', align: 'right' };
        }
        tmpObj.Total = {
          data: parseInt(monthData[i].data[j].year) === parseInt(this.selectedYear) ? monthData[i].currentYearTotal.toString() : monthData[i].previousYearTotal.toString(),
          align: 'right'
        };
        tmpData.push(tmpObj);
      }

      tmpObj = {};
      tmpObj.Year = { data: '% Inc' };
      for (k = 0; k < this.months.length; k++) {
        tmpObj[this.months[k].full_name] = { data: monthData[i].inc_data[k], align: 'right' };
      }
      tmpData.push(tmpObj);
      tableData.data = tmpData;
      listData.tableData = tableData;
      listData.title = monthData[i].name;
      list.push(listData);
    }
    excelName = `${reportName + this._dataService.orgName} Monthly Report (${this.selectedYear})`;
    this._appService.exportMultiTable(excelName, list, 'monthly-report');
  }

  formatData(reportData) {
    let i, j, k, yearData, index, incrementData = [];

    // Check and add both current year and previous year
    if (this.years.length === 0) {
      this.years = [this.selectedYear, this.selectedYear - 1];
    } else if (this.years.length === 1) {
      if (parseInt(this.years[0]) === parseInt(this.selectedYear)) {
        this.years.push(this.selectedYear - 1);
      } else {
        this.years.push(this.selectedYear);
      }
    }

    // Sort and order years in descending order
    this.years.sort();
    this.years.reverse();

    // Format to get data for each month and year for all applications
    for (i = 0; i < this.names.length; i++) {
      yearData = [{ year: '', data: [] }, { year: '', data: [] }];
      for (j = 0; j < this.years.length; j++) {
        yearData[j].year = this.years[j];
        for (k = 0; k < this.months.length; k++) {
          // Check if record exists for that month and year
          index = reportData[i].data.map(x => x.year.toString() + '-' + x.month.toLowerCase()
          ).indexOf(this.years[j].toString() + '-' + this.months[k].name.toLowerCase());

          if (index === -1) {
            yearData[j].data.push({
              org_name: 82,
              name: this.names[i],
              month: this.months[k].name,
              billacc_country: '',
              total_meals: 0,
              year: this.years[j]
            });
          } else {
            yearData[j].data.push(reportData[i].data[index]);
          }
        }
      }
      incrementData = [];
      this.currentYearTotal = 0;
      this.previousYearTotal = 0;
      for (j = 0; j < yearData[0].data.length; j++) {
        this.currentYearTotal += parseInt(yearData[0].data[j].total_meals);
        this.previousYearTotal += parseInt(yearData[1].data[j].total_meals);
        yearData[0].data[j].color = yearData[0].data[j].total_meals < yearData[1].data[j].total_meals ? 'text--alert' : 'text--success';
        yearData[1].data[j].color = yearData[1].data[j].total_meals < yearData[0].data[j].total_meals ? 'text--alert' : 'text--success';
        incrementData.push(this.getPercentInc(yearData[0].data[j].total_meals || 0, yearData[1].data[j].total_meals || 0));
      }

      this.monthlyReportData.push({
        name: this.names[i],
        data: yearData,
        inc_data: incrementData,
        currentYearTotal: this.currentYearTotal,
        previousYearTotal: this.previousYearTotal
      });
    }
  }

  getIndex(data, attribute, value) {
    return data.map(x => attribute ? x[attribute].toString() : x.toString()).indexOf(value.toString());
  }

  getPercentInc(current, previous) {
    let temp;
    if (!previous || previous === 0) {
      temp = current < 0 ? current * -1 : current;
    } else if (previous < 0) {
      temp = -1 * previous;
    } else {
      temp = previous;
    }
    return this._formatService.formatNumber(((current - previous) / temp) * 100);
  }

  loadData() {
    this.names = [];
    this.years = [];
    this.monthlyReportData = [];
    let i, index, reportData = [],
      endPoint = '/donation/monthlyreport/' + this._dataService.orgId + '/';
    endPoint += `${this.selectedYear}/?org_type=${this.projectType ? 'humansandwildlife' : 'association'}`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadData()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        // Group application wise data
        for (i = 0; i < data.length; i++) {
          if (reportData.length === 0) {
            reportData.push({
              name: data[i].name,
              data: [data[i]]
            });

            // Get distinct years and application names
            this.names.push(data[i].name);
            this.years.push(data[i].year);
          } else {
            index = this.getIndex(this.years, '', parseInt(data[i].year));
            if (index === -1) {
              this.years.push(data[i].year);
            }

            index = this.getIndex(reportData, 'name', data[i].name);
            if (index === -1) {
              reportData.push({
                name: data[i].name,
                data: [data[i]]
              });
              this.names.push(data[i].name);
            } else {
              reportData[index].data.push(data[i]);
            }
          }
        }

        this.formatData(reportData);
      }
      this.showSpinner = false;
    });
  }

  loadYears() {
    this.yearsList = [];
    for (let i = this.currentYear; i >= 2017; i--) {
      this.yearsList.push({ year: i });
    }
  }
}
