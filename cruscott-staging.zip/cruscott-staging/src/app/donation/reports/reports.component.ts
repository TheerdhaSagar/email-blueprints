import { Component, OnInit, Injector } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';

declare let FooPicker: any;

@Component({
  selector: 'app-donation-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
  providers: [OrderByPipe]
})
export class DonationReportsComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _router: Router = this.injector.get(Router);

  data: any[];
  dateFormat: any;
  desc: boolean;
  drillDownData: any;
  fromDate: any;
  overviewYear: number;
  predicate: any;
  projectType: string;
  searchText: any;
  selectedYear: number;
  showSpinner: boolean;
  toDate: any;
  toggleFilter: any;
  total_cat_meals = 0;
  total_dog_meals = 0;
  total_meals = 0;
  total_payment_amount = 0;
  total_pets = 0;
  user: any;
  years: any[];

  constructor(private injector: Injector) {

    this.data = [];
    this.dateFormat = '';
    this.desc = false;
    this.drillDownData = '';
    this.fromDate = '';
    this.overviewYear = null;
    this.predicate = '';
    this.projectType = '';
    this.selectedYear = null;
    this.showSpinner = false;
    this.toDate = '';
    this.toggleFilter = this._appService.toggleFilter();
    this.total_cat_meals = 0;
    this.total_dog_meals = 0;
    this.total_meals = 0;
    this.total_payment_amount = 0;
    this.total_pets = 0;
    this.user = '';
    this.years = [];
  }

  ngOnInit(): void {
    this._routeParams.queryParams.subscribe((params) => {
      this.projectType = params.project;
    });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;
        this.dateFormat = this.user.date_format || 'dd-MMM-yyyy';

        setTimeout(() => {
          new FooPicker({
            id: 'from-date',
            dateFormat: this.dateFormat
          });

          new FooPicker({
            id: 'to-date',
            dateFormat: this.dateFormat
          });
        });

        this.showSpinner = true;
        this.loadYears();
        this.loadData();
      }
    });
  }

  applyFilter() {
    this.toggleFilter();
    this.overviewYear = this.selectedYear;
    this.data = [];

    let dateArray = '';

    // Check if selected year and from date are from same year
    if (this.selectedYear && this.fromDate) {
      dateArray = this._formatService.parseDate(this.fromDate, this.dateFormat).split('-');
      if (this.selectedYear !== parseInt(dateArray[2])) {
        this._appService.notify({ msg: 'From date and Period should be from same year', status: 1 });
        this.fromDate = '';
        return;
      }
    }

    // Check if selected year and to date are from same year
    if (this.selectedYear && this.toDate) {
      dateArray = this._formatService.parseDate(this.toDate, this.dateFormat).split('-');
      if (this.selectedYear !== parseInt(dateArray[2])) {
        this._appService.notify({ msg: 'To date and Period should be from same year', status: 1 });
        this.toDate = '';
        return;
      }
    }

    // Check if from date is less than to date
    if (this.fromDate && this.toDate) {
      if (this._formatService.dateInMillis(this._formatService.parseDate(this.fromDate, this.dateFormat)
      ) > this._formatService.dateInMillis(this._formatService.parseDate(this.toDate, this.dateFormat))) {
        this._appService.notify({ msg: 'From Date should be less than to date', status: 1 });
        this.fromDate = '';
        return;
      }
    }
    this.showSpinner = true;
    this.loadData();
  }

  // Exports the table data into spreadsheet
  exportReport() {
    this.toggleFilter();
    const filename = this.projectType ? 'H&W Report' : 'Donation Report';
    let tableData: any = {}, exportData, tmpData = [], tmpObj: any = {}, i;
    exportData = this._orderBy.transform(this.data, this.predicate, this.desc);
    for (i = 0; i < exportData.length; i++) {
      tmpObj = {};
      tmpObj.Country = { data: exportData[i].billacc_country };
      tmpObj.Name = { data: exportData[i].name };
      tmpObj['No of Dog Meals'] = { data: exportData[i].no_dog_meals, align: 'right' };
      if (!this.projectType) {
        tmpObj['No of cat Meals'] = { data: exportData[i].no_cat_meals, align: 'right' };
      }
      tmpObj['Total pets'] = { data: exportData[i].total_pets, align: 'right' };
      tmpObj['Total meals'] = { data: exportData[i].total_meals, align: 'right' };
      tmpObj['Total Amount'] = { data: exportData[i].f_payment_amount, align: 'right' };
      tmpObj[''] = { data: exportData[i].transactional_curr_code };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;

    let footer = [{ data: '' }, { data: '' },
      { data: this.total_dog_meals, align: 'right' }];
    if (!this.projectType) {
      footer.push({ data: this.total_cat_meals, align: 'right' });
    }
    tableData.footer = footer.concat([{ data: this.total_pets, align: 'right' },
      { data: this.total_meals, align: 'right' },
      { data: this.total_payment_amount, align: 'right' }]);

    this._appService.tableToExcel(filename, tableData, 'donation-report');
  }

  loadData() {
    let i, endPoint = '/donation/report/',
      requestObj = {
        year: null,
        from_date: '',
        to_date: '',
        org_type: this.projectType ? 'humansandwildlife' : 'association'
      };
    requestObj.from_date = this.fromDate ? this._formatService.parseDate(this.fromDate, this.dateFormat) : '';
    requestObj.to_date = this.toDate ? this._formatService.parseDate(this.toDate, this.dateFormat) : '';
    requestObj.year = this.selectedYear || '';

    this._httpService.httpRequest('POST', endPoint, requestObj, (data) => {
      this.data = [];
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadData()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.total_pets = 0;
        this.total_meals = 0;
        this.total_cat_meals = 0;
        this.total_dog_meals = 0;
        this.total_payment_amount = 0;

        for (i = 0; i < data.length; i++) {
          data[i].total_meals = 0;
          data[i].total_meals += parseInt(data[i].no_dog_meals) || 0;
          data[i].total_meals += parseInt(data[i].no_cat_meals) || 0;

          data[i].total_pets = 0;
          data[i].total_pets += parseInt(data[i].no_dogs) || 0;
          data[i].total_pets += parseInt(data[i].no_cats) || 0;
          data[i].f_payment_amount = data[i].payment_amount !== null ? this._formatService.formatNumber(data[i].payment_amount) : '';

          this.total_meals += parseInt(data[i].total_meals);
          this.total_cat_meals += parseInt(data[i].no_cat_meals) || 0;
          this.total_dog_meals += parseInt(data[i].no_dog_meals) || 0;
          this.total_pets += parseInt(data[i].total_pets);
          this.total_payment_amount += parseFloat(data[i].payment_amount) || 0;
        }
        this.total_payment_amount = this._formatService.formatNumber(this.total_payment_amount);
        this.data = data;
      }
      this.showSpinner = false;
    });
  }

  // Load years
  loadYears() {
    let years = [], i,
      currentYear = new Date().getFullYear();
    for (i = currentYear; i >= 2017; i--) {
      years.push({
        year: i,
        yearCode: '' + i
      });
    }
    this.years = years;
    this.selectedYear = currentYear;
    this.overviewYear = currentYear;
  }

  moveToDrillDownreport(line) {
    this._appService.typeofDonation = line.name;
    this._appService.donationCountry = line.billacc_country;
    this._appService.fromDate = this.fromDate || '';
    this._appService.toDate = this.toDate || '';
    this._appService.selectedYear = this.selectedYear;
    if (this.projectType) {
      this._router.navigate(['donation/reports/detail'], { queryParams: { project: this.projectType } }).then();
    } else {
      this._router.navigate(['donation/reports/detail']).then();
    }
  }

  sort(key) {
    if (key === this.predicate) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = false;
    }
  }
}
