import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ByprovinceComponent } from './byprovince.component';

describe('ByprovinceComponent', () => {
  let component: ByprovinceComponent;
  let fixture: ComponentFixture<ByprovinceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ByprovinceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ByprovinceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
