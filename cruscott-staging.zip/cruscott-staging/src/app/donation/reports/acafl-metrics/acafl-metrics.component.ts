import { Component, OnInit, Injector } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from '../../../globals/app.service';
import { CacheService } from '../../../globals/cache.service';
import { HttpService } from '../../../globals/http.service';
import { OrderByPipe } from '../../../globals/order-by.pipe';

@Component({
  selector: 'app-acafl-metrics',
  templateUrl: './acafl-metrics.component.html',
  styleUrls: ['./acafl-metrics.component.scss'],
  providers: [OrderByPipe]
})
export class AcaflMetricsComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _router: Router = this.injector.get(Router);

  adoptionCount: any;
  catCount: any;
  catMealsCount: any;
  desc: boolean;
  dogCount: any;
  dogMealsCount: any;
  metricsData: any;
  petCount: any;
  predicate: string;
  projectType: string;
  shelterCount: any;
  showSpinner: boolean;
  toggleFilter: (e?) => void;
  waitingForAdoptionsCount: any;

  constructor(private injector: Injector) {
    this.adoptionCount = null;
    this.catCount = null;
    this.catMealsCount = null;
    this.desc = true;
    this.dogCount = null;
    this.dogMealsCount = null;
    this.metricsData = null;
    this.petCount = null;
    this.predicate = 'year';
    this.shelterCount = null;
    this.showSpinner = false;
    this.toggleFilter = this._appService.toggleFilter();
    this.waitingForAdoptionsCount = null;
  }

  ngOnInit() {
    this.showSpinner = true;

    this._routeParams.queryParams.subscribe((params) => {
      this.projectType = params.project;
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
      this.loadMetricsData();
    });
  }

  // Exports the table data into spreadsheet
  exportMetrics() {
    this.toggleFilter();
    const petsData = [];
    const sheltersData = [];
    let petsMetrics: any = {};
    let sheltersMetrics: any = {};
    let i;
    let footer;
    const exportData = this._orderBy.transform(this.metricsData, this.predicate, this.desc);
    for (i = 0; i < exportData.length; i++) {
      petsMetrics = {};
      sheltersMetrics = {};
      petsMetrics.Year = { data: exportData[i].year };
      sheltersMetrics.Year = { data: exportData[i].year };
      if (!this.projectType) {
        petsMetrics['Cat Meals'] = { data: exportData[i].cat_meals, align: 'right' };
      }
      petsMetrics['Dog Meals'] = { data: exportData[i].dog_meals, align: 'right' };
      if (!this.projectType) {
        petsMetrics['Total Cats'] = { data: exportData[i].total_cats, align: 'right' };
      }
      petsMetrics['Total Dogs'] = { data: exportData[i].total_dogs, align: 'right' };
      petsMetrics['Total Pets'] = { data: exportData[i].total_pets, align: 'right' };
      sheltersMetrics['Total Shelters'] = { data: exportData[i].total_shelters, align: 'right' };
      sheltersMetrics['Total Adoptions'] = { data: exportData[i].total_adoptions, align: 'right' };
      sheltersMetrics['Waiting for Adoption'] = { data: exportData[i].waiting_for_adoption, align: 'right' };
      petsData.push(petsMetrics);
      sheltersData.push(sheltersMetrics);
    }

    if (!this.projectType) {
      footer = [
        { data: '' },
        { data: this.catMealsCount, align: 'right' },
        { data: this.dogMealsCount, align: 'right' },
        { data: this.catCount, align: 'right' },
        { data: this.dogCount, align: 'right' },
        { data: this.petCount, align: 'right' }
      ];
    } else {
      footer = [
        { data: '' },
        { data: this.dogMealsCount, align: 'right' },
        { data: this.dogCount, align: 'right' },
        { data: this.petCount, align: 'right' }
      ];
    }

    const list = [
      {
        tableData: {
          data: petsData,
          footer
        },
        title: 'Pets / Meals Metrics'
      }
    ];
    if (!this.projectType) {
      list.push(
        {
          tableData: {
            data: sheltersData,
            footer: [
              { data: '' },
              { data: this.shelterCount, align: 'right' },
              { data: this.adoptionCount, align: 'right' },
              { data: this.waitingForAdoptionsCount, align: 'right' }
            ]
          },
          title: 'Shelter / Adoption Metrics'
        }
      );
    }
    const filename = this.projectType ? 'H&W Metrics' : 'Companion Animal Metrics';
    this._appService.exportMultiTable(filename, list, 'metrics-report');
  }

  loadMetricsData(): void {
    const endPoint = this.projectType ? '/donation/hw/metrics/' : '/donation/metrics/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadMetricsData()', status: 1 });
      } else if (data.status === 1) {
        this._appService.notify({ msg: data.msg, status: data.status });
      } else {
        this.parseMetricsData(data);
      }
      this.showSpinner = false;
    });
  }

  parseMetricsData(data) {
    this.dogMealsCount = 0;
    this.catMealsCount = 0;
    this.waitingForAdoptionsCount = 0;
    this.dogCount = 0;
    this.catCount = 0;
    this.petCount = 0;
    this.shelterCount = 0;
    this.adoptionCount = 0;
    for (let i = 0; i < data.length; i++) {
      this.dogMealsCount += parseInt(data[i].dog_meals) || 0;
      this.catMealsCount += parseInt(data[i].cat_meals) || 0;
      this.waitingForAdoptionsCount += parseInt(data[i].waiting_for_adoption) || 0;
      this.dogCount += parseInt(data[i].total_dogs) || 0;
      this.catCount += parseInt(data[i].total_cats) || 0;
      this.petCount += parseInt(data[i].total_pets) || 0;
      this.shelterCount += parseInt(data[i].total_shelters) || 0;
      this.adoptionCount += parseInt(data[i].total_adoptions) || 0;
    }
    this.metricsData = data;
  }
}
