import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcaflMetricsComponent } from './acafl-metrics.component';

describe('AcaflMetricsComponent', () => {
  let component: AcaflMetricsComponent;
  let fixture: ComponentFixture<AcaflMetricsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcaflMetricsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcaflMetricsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
