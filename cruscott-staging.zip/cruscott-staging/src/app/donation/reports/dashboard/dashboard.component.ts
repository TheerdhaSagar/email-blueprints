import { Component, OnInit, Injector } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CacheService } from '../../../globals/cache.service';

@Component({
  selector: 'app-donation-reports-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DonationReportDashboardComponent implements OnInit {
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _router: Router = this.injector.get(Router);

  projectType: string;

  constructor(private injector: Injector) {
    this.projectType = null;
  }

  ngOnInit(): void {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']).then();
      } else if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });

    this._routeParams.queryParams.subscribe((params) => {
      if (params.project) {
        this.projectType = params.project.toString();
      }
    });
  }

  moveTo(stateName): void {
    if (this.projectType) {
      this._cacheService.humansAndWildLifeRequest = this.projectType;
      this._router.navigate([stateName], { queryParams: { project: this.projectType } }).then();
    } else {
      this._router.navigate([stateName]).then();
    }
  }
}
