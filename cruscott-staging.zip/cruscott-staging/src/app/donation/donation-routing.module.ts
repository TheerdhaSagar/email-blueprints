import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdoptionsComponent } from './adoptions/adoptions.component';
import { AssociationFinderComponent } from './association-finder/association-finder.component';
import { AssociationComponent } from './association/association.component';
import { DonationDashboardComponent } from './dashboard/dashboard.component';
import { ManageAdoptionComponent } from './manage/adoption/adoption.component';
import { ManageApplicationComponent } from './manage/application/application.component';
import { PartnerAssociationDetailsComponent } from './partner-association/details/details.component';
import { PartnerAssociationSummaryComponent } from './partner-association/summary/summary.component';
import { ProductMappingComponent } from './product-mapping/product-mapping.component';
import { AcaflMetricsComponent } from './reports/acafl-metrics/acafl-metrics.component';
import { DonationByProvinceDrillDownComponent } from './reports/byprovince-drilldown/byprovince-drilldown.component';
import { DonationProvinceReportComponent } from './reports/byprovince/byprovince.component';
import { DonationReportDashboardComponent } from './reports/dashboard/dashboard.component';
import { DonationDrillDownComponent } from './reports/drilldown/drilldown.component';
import { DonationMonthlyReportComponent } from './reports/monthly/monthly.component';
import { DonationReportsComponent } from './reports/reports.component';
import { ApplicationSummaryComponent } from './summary/summary.component';
import { DonationUsersComponent } from './users/users.component';

const routes: Routes = [
  { path: 'dashboard', component: DonationDashboardComponent },
  { path: 'adoptions', component: AdoptionsComponent },
  { path: 'association/profile', component: AssociationComponent },
  { path: 'association/search', component: AssociationFinderComponent },
  { path: 'adoption', component: ManageAdoptionComponent },
  { path: 'application', component: ManageApplicationComponent },
  { path: 'applications', component: ApplicationSummaryComponent },
  { path: 'reports/province', component: DonationProvinceReportComponent },
  { path: 'reports/province/details', component: DonationByProvinceDrillDownComponent },
  { path: 'reports/dashboard', component: DonationReportDashboardComponent },
  { path: 'reports/detail', component: DonationDrillDownComponent },
  { path: 'reports/month', component: DonationMonthlyReportComponent },
  { path: 'reports/country', component: DonationReportsComponent },
  { path: 'report/metrics', component: AcaflMetricsComponent },
  { path: 'users', component: DonationUsersComponent },
  { path: 'product-mapping', component: ProductMappingComponent },
  { path: 'partner-association/summary', component: PartnerAssociationSummaryComponent },
  { path: 'partner-association/details', component: PartnerAssociationDetailsComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DonationRoutingModule { }
