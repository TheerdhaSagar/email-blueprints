import { Component, OnDestroy, OnInit, Injector } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from 'jquery';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { DataService } from '../../globals/data.service';
import { APIError } from '../../globals/api.error';

@Component({
  selector: 'app-donation-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [OrderByPipe],
})
export class ApplicationSummaryComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _dataService: DataService = this.injector.get(DataService);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  applications: any;
  approved: any;
  checkedCount: any;
  created: any;
  desc: boolean;
  emailRecipients: any[];
  emailSubject: any;
  emailText: any;
  emailTextErr: any;
  fileData: any;
  orgId: any;
  pageDim: any;
  pending: any;
  predicate: string;
  projectType: string;
  rejected: any;
  receiptReceived: any;
  receiptStatus: any[];
  requestStatus: { label: string; status: string }[];
  reqType: any;
  requestTypes: any[];
  selectAll: boolean;
  selectedApplication: any;
  selectedWorkflow: any;
  selectedYear: any;
  searchQuery: any;
  showApprovalFlowDialog = false;
  showMenu: boolean;
  status: any;
  subOrgChange: any;
  toggleFilter: (e?) => void;
  workflowApprovers: [];
  workflows: any[];
  years: any;

  constructor(private injector: Injector) {
    this._window = window;

    this.applications = this._cacheService.getDonationApplications();
    this.approved = null;
    this.checkedCount = null;
    this.created = null;
    this.desc = true;
    this.emailRecipients = [];
    this.emailSubject = null;
    this.emailText = null;
    this.emailTextErr = null;
    this.fileData = null;
    this.orgId = null;
    this.pageDim = null;
    this.pending = null;
    this.predicate = 'request_header_id';
    this.rejected = null;
    this.receiptReceived = this._cacheService.donationApplReceipt || 'ALL';
    this.receiptStatus = [
      {
        label: 'Yes',
        status: 'Y',
      },
      {
        label: 'No',
        status: 'N',
      },
      {
        label: 'All',
        status: 'ALL',
      },
    ];
    this.requestStatus = [
      {
        label: 'Under Review',
        status: 'U',
      },
      {
        label: 'In Progress',
        status: 'I',
      },
      {
        label: 'Approved',
        status: 'A',
      },
      {
        label: 'Rejected',
        status: 'R',
      },
      {
        label: 'Cancelled',
        status: 'C',
      },
      {
        label: 'Created',
        status: 'O',
      },
    ];
    this.reqType = this._cacheService.donationApplType || 'ALL';
    this.requestTypes = [
      {
        label: 'Donation AdoptMe',
        status: 'L',
      },
      {
        label: 'Donation LoveFood',
        status: 'DL',
      },
      {
        label: 'Welcome Kit AdoptMe',
        status: 'A',
      },
      {
        label: 'Habitat',
        status: 'H',
      },
      {
        label: 'Donation LoveFood Bank',
        status: 'LB',
      },
      {
        label: 'All',
        status: 'ALL',
      },
    ];
    this.searchQuery = this._cacheService.donationApplSearchQuery || '';
    this.selectedYear = null;
    this.status = this._cacheService.donationApplStatus || 'U';
    this.subOrgChange = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.years = [];
  }

  ngOnInit() {
    this._routeParams.queryParams.subscribe((params) => {
      this.projectType = params.project;
      this._cacheService.humansAndWildLifeRequest = this.projectType;
    });

    if (this._dataService.fromState === '/humans-and-wild-life/dashboard') {
      this.projectType = 'donation-request';
      this._cacheService.humansAndWildLifeRequest = this.projectType;
    }

    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.orgId = this._cacheService.getOrgId();

        const todaysDate = new Date();
        if (this._appService.donationYear) {
          this.selectedYear = this._appService.donationYear;
        } else {
          this.selectedYear = todaysDate.getFullYear();
          this._appService.donationYear = this.selectedYear;
        }

        if (this.applications) {
          this.applications.forEach((application) => {
            if (application.checked) {
              application.checked = false;
            }
          });
        }

        this.loadApplications();
        this.loadWorkflows();

        for (let i = 2015; i <= todaysDate.getFullYear(); i++) {
          this.years.push(i);
        }

        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this._cacheService.setDonationApplications(null);
          this.orgId = this._cacheService.getOrgId();
          this.checkedCount = 0;
          this.applications = null;
          this.approved = null;
          this.rejected = null;
          this.pending = null;
          this.created = null;
          this.loadApplications();
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  applyFilter(): void {
    this._cacheService.setDonationApplications(null);
    this._appService.donationYear = this.selectedYear;
    this._cacheService.donationApplStatus = this.status;
    this._cacheService.donationApplType = this.reqType;
    this._cacheService.donationApplReceipt = this.receiptReceived;
    this._cacheService.donationApplSearchQuery = this.searchQuery;
    this.checkedCount = 0;
    this.applications = null;
    this.toggleFilter();
    this.loadApplications();
  }

  downloadFile(attachment) {
    this.fileData = attachment.file_data;
    // Convert blob to base64 formatHelper
    let blobFile = this._formatService.base64ToBlob(
      this.fileData,
      attachment.file_type
    );
    if (this._appService.isIE()) {
      let builder = new MSBlobBuilder();
      builder.append(blobFile);

      let blob = builder.getBlob(attachment.file_type);
      window.navigator.msSaveBlob(blob, attachment.file_name);
    } else {
      let url = this._window.URL.createObjectURL(blobFile);
      let a = document.createElement('a');
      document.body.appendChild(a);
      a.style.display = 'none';
      a.href = url;
      a.download = attachment.file_name;
      a.click();
    }
  }

  downloadShippingDocument(a) {
    let endPoint =
      '/donation/documents/shipping/' +
      a.quote_number +
      '/' +
      this._cacheService.getOrgId() +
      '/';
    endPoint += '?delivery=N';
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - downloadShippingDocument()',
        });
      } else if (data.status && data.status !== 'OK') {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (data.file_data) {
        const attachment = {
          file_name: 'Bolla #' + a.waybill + '.pdf',
          file_data: data.file_data,
          file_type: 'application/pdf',
        };

        this.downloadFile(attachment);
      } else {
        this._appService.notify({
          status: 1,
          msg: 'Unknown Error! Please try again',
        });
      }
    });
  }

  exportToExcel() {
    let data = this._orderBy.transform(
        this.applications,
        this.predicate,
        this.desc
      ),
      tableData: any = {},
      tmpData = [],
      i,
      tmpObj,
      status;
    for (i = 0; i < data.length; i++) {
      tmpObj = {};
      tmpObj['Application No.'] = { data: data[i].application_no };
      tmpObj['Org Name'] = { data: data[i].org_name };
      tmpObj.Type = { data: data[i].association_type };
      tmpObj['No. of Dogs'] = { data: data[i].dogs, align: 'right' };
      tmpObj['No. of Cats'] = { data: data[i].cats, align: 'right' };
      if (data[i].request_status === 'O') {
        tmpObj['Quote #'] = { data: data[i].quote_number };
        tmpObj['Order Amount'] = {
          data: data[i].f_quote_price,
          align: 'right',
        };
        tmpObj.Waybill = { data: data[i].waybill };
        tmpObj.Invoice = { data: data[i].invoice };
      }
      tmpObj['Request Type'] = {
        data: ApplicationSummaryComponent.getRequestTypeDescription(
          data[i].request_type
        ),
      };
      tmpObj['Created Date'] = { data: data[i].f_created_date };
      tmpObj['Waiting For'] = { data: data[i].waiting_for };
      if (data[i].request_status === 'U') {
        status = 'Under Review';
      } else if (data[i].request_status === 'O') {
        status = 'Order Created';
      } else if (data[i].request_status === 'A') {
        status = 'Approved';
      } else if (data[i].request_status === 'R') {
        status = 'Rejected';
      } else if (data[i].request_status === 'C') {
        status = 'Cancelled';
      } else if (data[i].request_status === 'I') {
        status = 'In Progress';
      }
      tmpObj['Request Status'] = { data: status };
      tmpObj.Receipt = { data: data[i].ricevuta === 'Y' ? 'Yes' : 'No' };
      tmpData.push(tmpObj);
    }
    tableData.data = tmpData;
    this._appService.tableToExcel(
      'Donation Applications',
      tableData,
      'export-data'
    );
  }

  static getRequestTypeDescription(requestType: string): string {
    switch (requestType) {
      case 'L':
        return 'Donation AdoptMe';
      case 'DL':
        return 'Donation LoveFood';
      case 'A':
        return 'Welcome Kit AdoptMe';
      case 'H':
        return 'Habitat';
      case 'LB':
        return 'Donation LoveFood Bank';
      default:
        return '';
    }
  }

  getWorkflowRequest(): object {
    return {
      header_id: this.selectedApplication.request_header_id,
      org_id: this.selectedApplication.org_id,
      wf_name: this.selectedWorkflow,
    };
  }

  loadApplications() {
    let endPoint =
      '/donation/applications/?org=' +
      this._cacheService.getOrgId() +
      '&status=' +
      this.status;
    if (
      this.projectType &&
      (this.projectType === 'humans-and-wild-life' ||
        this.projectType === 'donation-request')
    ) {
      endPoint += '&org_type=humansandwildlife';
    }
    if (this.status === 'O') {
      endPoint += '&year=' + this.selectedYear;
      endPoint +=
        this.receiptReceived !== 'ALL'
          ? '&ricevuta=' + this.receiptReceived
          : '';
    }
    endPoint += this.reqType !== 'ALL' ? '&donation_type=' + this.reqType : '';
    if (!this.applications) {
      this.pageDim = true;
    }
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error: loadApplications()',
          });
        } else if (data.status === 1) {
          this._appService.notify(new APIError(data.msg));
        } else if (data.status === 'OK') {
          const result = data.result;
          for (let i = 0; i < result.length; i++) {
            result[i].f_quote_price = this._formatService.formatNumber(
              result[i].quote_price
            );
            result[i].f_created_date = this._formatService.formatDate(
              result[i].created_date
            );
            result[i].creation_date_millis = this._formatService.dateInMillis(
              result[i].created_date
            );
            result[i].f_org_name = this._formatService.removeEscapeCharacter(
              result[i].org_name
            );
            result[
              i
            ].f_application_no = this._formatService.removeEscapeCharacter(
              result[i].application_no
            );
          }
          this.applications = result;
          this._cacheService.setDonationApplications(result);
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>',
        });
      }
    });
  }

  loadWorkflows(): void {
    const endPoint = '/workflows/?module=Donation Desk';
    this._httpService.httpRequest('GET', endPoint, null, (response) => {
      if (!response) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadWorkflows()',
        });
      } else if (response.msg) {
        this._appService.notify({ status: response.status, msg: response.msg });
      } else {
        this.workflows = response.filter((workflow) => workflow.active === 'Y');
      }
    });
  }

  onLineSelection(): void {
    let receiptApplications = this.applications.filter(
      (application) => application.ricevuta === 'N' && application.checked
    );
    this.selectAll = false;
    this.checkedCount = receiptApplications.length;
  }

  onWorkflowChange(): void {
    const index = this.workflows
      .map((workflow) => workflow.workflow_name)
      .indexOf(this.selectedWorkflow);
    if (index === -1) {
      return;
    }
    const endPoint = `/workflows/${this.workflows[index].workflow_id}/`;
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (response) => {
      this.pageDim = false;
      if (!response) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: onWorkflowChange()',
        });
      } else if (response.msg) {
        this._appService.notify({ status: response.status, msg: response.msg });
      } else {
        this.workflowApprovers = response[0].approvers;
      }
    });
  }

  openQuote(application) {
    let endPoint = '/quotes/headerid/' + application.quote_header_id + '/';
    this.pageDim = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: openQuote()',
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (data && data.length > 1) {
        this._appService.editQuote = true;
        this._appService.quoteHeader = data[1];
        this._appService.fromDonation = true;
        this._router.navigate(['quotes/manage']);
      } else {
        this._appService.notify({ status: 1, msg: 'Unable to open the Quote' });
      }
    });
  }

  prepareEmailRecipients() {
    this.emailTextErr = false;
    switch (this.orgId) {
      case 82:
        this.emailSubject =
          'Importante Documento mancante relativo alla  Ricezione merce';
        this.emailText =
          'Buongiorno,\n\nin seguito ad una verifica interna, risulta mancante la Ricevuta relativa alla merce che è stata consegnata.' +
          '\nTale documento è fondamentale per ottemperare a quanto prevede la normativa fiscale.' +
          '\nVi chiediamo cortesemente di compilare il modello di Ricevuta  allegato in tutte le sue parti compreso di firma e timbro e di caricarlo nella vostra area riservata, cliccando sul tasto  denominato "Carica ricevuta e Documento di Trasporto".' +
          '\n\nGrazie per la collaborazione.' +
          '\n\nTeam Companion Animal For Life' +
          '\nAlmo Nature Fondazione Capellino';
        break;
      case 83:
        this.emailSubject =
          'Belangrijk: ontbrekend ontvangstdocument van goederen';
        this.emailText =
          'Wij hebben uw gegevens gecontroleerd maar we schijnen het ontvangstdocument van de goederen te missen. Dit document is voor ons belangrijk om te kunnen voldoen aan de fiscale regelgeving.' +
          '\nZou u zo vriendelijk willen zijn om alle vereiste informatie in te vullen op het bijgevoegde ontvangstbewijs? Voeg ook uw stempel (als u deze heeft) en uw handtekening toe aan het document voordat u er een scan van maakt en het op onze website uploadt. U kunt dit doen door naar uw persoonlijke pagina op onze website te gaan en te klikken op “ontvangstbewijs uploaden”.' +
          '\nBedankt voor uw medewerking,\n\n' +
          'Companion Animal For Life Team \n' +
          'Almo Nature - Fondazione Capellino';
        break;
      case 101:
        this.emailSubject =
          'Important : document manquant relatif à la réception des marchandises';
        this.emailText =
          'Après vérification en interne, il semble qu’il nous manque le reçu des produits qui vous ont été envoyés. Ce document est indispensable pour se conformer avec le régime fiscal en vigueur.' +
          '\n\n' +
          'Merci de remplir toutes les informations demandées dans le formulaire attaché à cet email. Une fois rempli, merci d’y apposer votre tampon et votre signature, de le scanner et de le téléchargez sur notre site depuis votre espace personnel, grâce au bouton « upload receipt » / « télécharger la facture »' +
          '\n\n' +
          'Merci pour votre coopération' +
          '\n\n' +
          'L’équipe “Companion Animal For Life Team”\n' +
          'Almo Nature - Fondazione Capellino';
        break;
      default:
        this.emailSubject = 'Missing delivery receipt for application';
        this.emailText = '';
        break;
    }
    this.showMenu = !this.showMenu;
    this.emailRecipients = this.applications
      .filter(
        (application) => application.checked && application.ricevuta === 'N'
      )
      .map((application) => application.user_email);
  }

  restartWorkflow(): void {
    if (!this.selectedApplication || !this.selectedWorkflow) {
      return;
    }
    this.showApprovalFlowDialog = false;
    this.pageDim = true;
    const endPoint = '/donation/restart-workflow/';
    this._httpService.httpRequest(
      'POST',
      endPoint,
      this.getWorkflowRequest(),
      (response) => {
        this.pageDim = false;
        if (!response) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error: restartWorkflow()',
          });
        } else {
          this._appService.notify({
            status: response.status,
            msg: response.msg,
          });
          if (response.status === 0) {
            this.loadApplications();
          }
        }
      }
    );
  }

  selectAllApplications() {
    let i;
    this.checkedCount = 0;
    if (jQuery('#select-all').is(':checked')) {
      for (i = 0; i < this.applications.length; i++) {
        if (this.applications[i].ricevuta === 'N') {
          this.checkedCount += 1;
          this.applications[i].checked = true;
        }
      }
    } else {
      for (i = 0; i < this.applications.length; i++) {
        if (this.applications[i].ricevuta === 'N') {
          this.applications[i].checked = false;
        }
      }
    }
  }

  sendEmail() {
    let selectedApplications = [],
      req: any = {},
      endPoint = '/donation/send/email/';
    if (this.emailText) {
      this.applications.forEach((application) => {
        if (application.checked && application.ricevuta === 'N') {
          let tmpApp: any = {};
          tmpApp.application_no = application.application_no;
          tmpApp.org_id = application.org_id;
          selectedApplications.push(tmpApp);
          application.checked = false;
        }
      });
      req.greeting = 'Hi';
      req.request_text_1 = 'Please upload ricevuta';
      req.request_text_2 = 'here';
      req.request_text_3 = 'for the application number :';
      req.rights_text = 'All rights reserved.';
      req.mailing_text = 'Our mailing address is:';
      switch (this.orgId) {
        case 181:
          req.language = 'nl'; // NL Organization
          break;
        case 101:
          req.language = 'fr'; // FR Organization
          req.greeting = 'Cher / Chère';
          req.request_text_1 = 'Téléchargez votre reçu en cliquant';
          req.request_text_2 = 'ici';
          req.request_text_3 = 'pour la demande d’inscription no :';
          break;
        case 83:
          req.language = 'de'; // DE Organization
          req.greeting = 'Beste';
          req.request_text_1 = 'Upload uw ontvangstbewijs door';
          req.request_text_2 = 'hier';
          req.request_text_3 = 'te klikken voor het aanvraagnummer :';
          break;
        case 82:
          req.language = 'it'; // IT Organization
          req.greeting = 'Ciao';
          req.request_text_1 = 'Puoi caricare la tua ricevuta';
          req.request_text_2 = 'qui';
          req.request_text_3 = 'per la richiesta numero :';
          req.rights_text = 'tutti i diritti riservati.';
          req.mailing_text = 'Il nostro indirizzo mail è:';
          break;
      }
      req.body = this.emailText;
      req.subject =
        this.emailSubject || 'Missing Delivery receipt for application';
      req.recipients = selectedApplications;
      this.checkedCount = 0;
      this.pageDim = true;
      this._httpService.httpRequest('POST', endPoint, req, (data) => {
        this.pageDim = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: 'Server Error: sendEmail()',
          });
        } else if (data.status === 'SUCCESS') {
          this.selectAll = false;
          this._appService.notify({ status: 0, msg: data.msg });
        } else {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      });
      this.showMenu = false;
    } else {
      this.emailTextErr = true;
    }
  }

  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
    }
  }

  viewApplication(application): void {
    this._appService.requestHeaderId = application.request_header_id;
    this._appService.donationYear = this.selectedYear;
    this._cacheService.donationApplSearchQuery = this.searchQuery;
    if (
      this.projectType === 'humans-and-wild-life' ||
      this.projectType === 'donation-request'
    ) {
      this._router.navigate(['donation/application'], {
        queryParams: { project: this.projectType },
      });
    } else {
      this._router.navigate(['donation/application']);
    }
  }

  viewProfile(application): void {
    this._appService.associationId = application.org_id;
    this._appService.donationYear = this.selectedYear;
    this._appService.associationNavParent = 'donation/applications';
    if (this.projectType === 'humans-and-wild-life') {
      this._router.navigate(['donation/association/profile'], {
        queryParams: { project: 'humans-and-wild-life' },
      });
    } else {
      this._router.navigate(['donation/association/profile']);
    }
  }
}
