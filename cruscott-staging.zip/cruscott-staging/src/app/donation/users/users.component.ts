import { Component, Injector, OnDestroy, OnInit } from '@angular/core';
import jQuery from 'jquery';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { CommonService } from '../../globals/common.service';
import { DataService } from '../../globals/data.service';
import { DonationService } from '../donationservice/donation.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { OrderByPipe } from '../../globals/order-by.pipe';

interface Association {
  address: string;
  association_id: string;
  association_name: string;
  city: string;
  country: string;
  facebook_page?: string;
  first_name?: string;
  instagram_url?: string;
  language?: string;
  last_name?: string;
  notify?: string;
  org_unique_code: string;
  org_name: string;
  org_type: string;
  password?: string;
  province: string;
  receiver: string;
  site_id?: string;
  telephone: string;
  ui_language: string;
  user_email: string;
  user_name?: string;
  user_telephone: string;
  website_url?: string;
  zip: string;
}

const PROJECTS = {
  Cafl: 'cafl',
  HumansAndWildLife: 'humans-and-wild-life'
};

@Component({
  selector: 'app-donation-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
  providers: [OrderByPipe]
})
export class DonationUsersComponent implements OnInit, OnDestroy {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _commonService: CommonService = this.injector.get(CommonService);
  private _dataService: DataService = this.injector.get(DataService);
  private _donationService: DonationService = this.injector.get(DonationService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _routeParams: ActivatedRoute = this.injector.get(ActivatedRoute);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  activeStatus: any[];
  adoptMe: string;
  assocLov: any[];
  association: Association;
  associations: any[];
  associationTypes: Array<{ label: string; value: string }>;
  checkedCount: any;
  countries: Array<{ country: string; country_code: string }>;
  desc: boolean;
  dialogContent: string;
  dialogTitle: string;
  existingAssociation: any;
  focusAssocName: boolean;
  focusAssocType: boolean;
  focusCountry: boolean;
  focusEmail: boolean;
  focusName: boolean;
  inviteDialog: boolean;
  languages: Array<{ language_code: string; language_name: string }>;
  mergeUser: boolean;
  mutlipleEmails: boolean;
  orgId: number;
  predicate: any;
  primaryUser: any;
  projectType: string;
  searchTerm: any;
  selectAll: any;
  shops: any[];
  showCreateAssociationDialog: boolean;
  showMenu: boolean;
  showSpinner: boolean;
  status: any;
  subOrgChange: Subscription;
  toggleFilter: (e?) => void;
  type: any;
  ui_language: any;
  userId: any;
  usersToMerge: any[];

  constructor(private injector: Injector) {
    this._window = window;

    this.activeStatus = [{
      label: 'Active',
      status: 'A'
    }, {
      label: 'In-Active',
      status: 'I'
    }];
    this.adoptMe = '';
    this.assocLov = [];
    this.associations = [];
    this.associationTypes = [{
      label: 'Onlus',
      value: 'ONLUS'
    }, {
      label: 'Non Onlus',
      value: 'NON ONLUS'
    }];
    this.checkedCount = null;
    this.desc = false;
    this.existingAssociation = '';
    this.focusAssocName = true;
    this.focusAssocType = true;
    this.focusCountry = true;
    this.focusEmail = true;
    this.focusName = true;
    this.inviteDialog = false;
    this.languages = this._commonService.languages;
    this.mergeUser = false;
    this.orgId = this._cacheService.getOrgId();
    this.predicate = '';
    this.primaryUser = null;
    this.selectAll = null;
    this.shops = [];
    this.showSpinner = false;
    this.status = null;
    this.toggleFilter = this._appService.toggleFilter();
    this.type = '';
    this.userId = null;

    this.initializeAssociation();
  }

  ngOnInit(): void {
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._routeParams.queryParams.subscribe((params) => {
      this.projectType = params.project;
    });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        // user = data;
        this.userId = data.user_id;
        if (this._cacheService.donationUserType) {
          this.type = this._cacheService.donationUserType;
        } else {
          this.type = 'association';
          this._cacheService.donationUserType = this.type;
        }
        this.existingAssociation = 'N';

        this.status = this._cacheService.associationsStatus || 'A';
        this.adoptMe = this._cacheService.adoptMe || '';

        this._cacheService.adoptMe = null;
        this._cacheService.associationsStatus = null;
        if (this._cacheService.humansAndWildLifeRequest === this.projectType) {
          this.loadAssociationsFromCache();
        }
        if (!this.associations || this.associations.length === 0 || this._appService.associationChanged) {
          this.loadUsers();
          if (!this._appService.associationChanged && this.projectType !== 'humans-and-wild-life') {
            this.toggleFilter();
          }
        } else {
          this.clearSelections();
        }
        this.loadCountries();
        this.loadAssociations();
        this.subOrgChange = this._appService.subscribeOrgChange(() => {
          this.orgId = this._cacheService.getOrgId();
          this.clearCachedAssociations();
          this.loadAssociations();
          this.loadUsers();
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.subOrgChange) {
      this.subOrgChange.unsubscribe();
    }
  }

  applyFilter(): void {
    this.clearSelections();
    this.loadAssociationsFromCache();
    this.toggleFilter();
    if (!this.associations) {
      this.loadUsers();
    }
  }

  changeUserStatus(action): void {
    const endPoint = '/donation/associations/status/';
    const selectedUsers = [];
    const lines = this.type === 'shops' ? this.shops : this.associations;
    const req: any = {};
    req.user_id = this.userId;
    req.status = action === 'I' ? 'A' : 'I';
    lines.forEach((user) => {
      if (user.checked) {
        selectedUsers.push(user.org_id);
        user.checked = false;
      }
    });
    req.org_id = selectedUsers;
    this.showMenu = false;
    this.showSpinner = true;
    this._httpService.httpRequest('PUT', endPoint, req, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - changeUserStatus()' });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.clearSelections();
        this.clearCachedAssociations();
        this.loadUsers();
        this._appService.notify({ status: 0, msg: data.msg });
      }
    });
  }

  clearCachedAssociations(): void {
    this._cacheService.clearAssociations();
    this.associations = null;
  }

  clearSelections(): void {
    this.selectAll = false;
    this.checkedCount = 0;
    if (this.associations) {
      this.associations.forEach((app) => {
        if (app.checked) {
          app.checked = false;
        }
      });
    }
  }

  exportUsers(): void {
    this.toggleFilter();
    let tempObj;
    const exportData = this._orderBy.transform(this.associations, this.predicate, this.desc);
    const tableData = { data: null };
    const tempData = [];
    for (let i = 0; i < exportData.length; i++) {
      tempObj = {};
      tempObj['Organisation Name'] = { data: exportData[i].org_name };
      tempObj.Email = { data: exportData[i].all_user_emails };
      tempObj.Type = { data: exportData[i].type };
      if (this.status === 'A') {
        tempObj.Applications = { data: exportData[i].application_count };
      }
      tempObj['AdoptMe?'] = { data: exportData[i].adopt_me };
      tempObj['Registration Date'] = { data: exportData[i].f_registration_date };
      tempObj.Address = { data: exportData[i].address };
      tempObj.City = { data: exportData[i].city };
      tempObj.Province = { data: exportData[i].province };
      tempObj['Postal Code'] = { data: exportData[i].zip_code };
      tempObj.Country = { data: exportData[i].country };
      tempData.push(tempObj);
    }
    tableData.data = tempData;
    this._appService.tableToExcel('Associations', tableData, 'export-data');
  }

  footerActions(action): void {
    if (action === 'A' || action === 'I') {
      this.mergeUser = false;
      this.dialogTitle = action === 'I' ? 'Activate' : 'De-activate';
      this.dialogContent = 'Do you want to make the selected users ' + (action === 'I' ? 'Active' : 'In-active') + '?';
    } else {
      this.mergeUser = true;
      this.dialogTitle = 'Merge';
      let lines = this.type === 'shops' ? this.shops : this.associations;
      this.usersToMerge = [];
      let mergeUserEmails = [];
      this.mutlipleEmails = false;
      lines.forEach((user) => {
        if (user.checked) {
          this.usersToMerge.push(user);
          if (!mergeUserEmails.includes(user.user_email)) {
            mergeUserEmails.push(user.user_email);
          }
        }
      });
      if (mergeUserEmails.length > 1) {
        this.mutlipleEmails = true;
        this.dialogContent = 'Associations with multiple E-mail Ids have been selected. Do you want to merge them?';
      } else {
        this.dialogContent = 'Please select a primary user for merging';
      }
      this.primaryUser = this.usersToMerge[0].user_id;
    }
    this.showMenu = !this.showMenu;
  }

  initializeAssociation(): void {
    this.association = {
      association_id: '',
      association_name: '',
      org_name: '',
      org_type: 'association',
      org_unique_code: '',
      telephone: '',
      address: '',
      province: '',
      city: '',
      zip: '',
      country: '',
      user_email: '',
      user_telephone: '',
      site_id: '',
      receiver: '',
      ui_language: ''
    };

    switch (this._dataService.orgId) {
      case 82:
        this.association.country = 'IT';
        this.association.ui_language = 'IT';
        break;
      case 83:
        this.association.country = 'DE';
        this.association.ui_language = 'DE';
        break;
      case 101:
        this.association.country = 'FR';
        this.association.ui_language = 'FR';
        break;
      case 181:
        this.association.country = 'NL';
        this.association.ui_language = 'NL';
        break;
    }
  }

  inviteAssociation(): void {
    this.focusAssocType = true;
    if (!this.association.association_name) {
      this.focusAssocName = false;
    }

    if (!this.association.receiver) {
      this.focusAssocType = false;
    }

    if (!this.association.first_name) {
      this.focusName = false;
    }

    if (!this.association.user_email) {
      this.focusEmail = false;
    }

    if (!this.association.country) {
      this.focusCountry = false;
    }

    if (!(this.focusAssocName && this.focusAssocType && this.focusName && this.focusEmail && this.focusCountry)) {
      return;
    }

    let details: any = {
      name: this.association.first_name,
      email: this.association.user_email
    }, endPoint, status;
    if (this.existingAssociation === 'N') {
      endPoint = '/donation/register/';
      this.association.org_unique_code = this._appService.replaceAll(this.association.association_name, ' ', '').toUpperCase();
      this.association.org_unique_code += this.association.country;
      this.association.user_name = this._appService.replaceAll(this.association.first_name, ' ', '').toLowerCase();
      if (this.projectType === PROJECTS.HumansAndWildLife) {
        this.association.notify = 'N';
        this.association.org_type = 'humansandwildlife';
      } else {
        this.association.notify = 'Y';
      }
      this.association.website_url = '';
      this.association.facebook_page = '';
      this.association.language = this.association.ui_language;
      this.inviteDialog = false;
      this.showSpinner = true;

      this._httpService.httpRequest('POST', endPoint, this.association, (data) => {
        this.showSpinner = true;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: inviteAssociation()' });
        } else if (data.status) {
          status = data.status === 'OK' ? 0 : 1;
          this._appService.notify({ status, msg: data.msg });
          this._cacheService.associations = null;
          this._cacheService.donationShops = null;
          this.loadUsers();
        } else {
          this._appService.notify({ status: 1, msg: 'Unknown Error! Please try again' });
        }
      });
    } else {
      this.inviteDialog = false;
      details.assoc_id = this.association.association_id;
      details.country = this.association.country;
      endPoint = '/aws/cognito/users/validate/' + details.email + '/';
      this._httpService.httpRequest('GET', endPoint, null, data => {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: validating association' });
        } else if (data.status_code === 'USER_EXISTS') {
          this.resendPassword(details);
        } else {
          this.registerUser(details);
        }
      });
    }
  }

  loadAssociations(): void {
    const endPoint = `/donation/associations/?almo_org_id=${this.orgId}`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: loadAssociations()' });
      } else if (data.status === 'OK') {
        this.assocLov = data.result;
        this.assocLov = this._orderBy.transform(this.assocLov, 'org_name', false);
      } else {
        this._appService.notify({ status: 1, msg: data.msg });
      }
    });
  }

  loadAssociationsFromCache(): void {
    const assocStatus = this.status === 'A' ? 'active' : 'inactive';
    if (this.adoptMe === 'Y' && this._cacheService[`${assocStatus}AdoptedAssociations`] &&
      this._cacheService[`${assocStatus}AdoptedAssociations`].projectType === this.projectType &&
      this._cacheService[`${assocStatus}AdoptedAssociations`].orgId === this.orgId) {
      this.associations = this._cacheService[`${assocStatus}AdoptedAssociations`].associations;
    } else if (this.adoptMe === 'N' && this._cacheService[`${assocStatus}NotAdoptedAssociations`] &&
      this._cacheService[`${assocStatus}NotAdoptedAssociations`].projectType === this.projectType &&
      this._cacheService[`${assocStatus}NotAdoptedAssociations`].orgId === this.orgId) {
      this.associations = this._cacheService[`${assocStatus}NotAdoptedAssociations`].associations;
    } else if (!this.adoptMe && this._cacheService[`${assocStatus}Associations`] &&
      this._cacheService[`${assocStatus}Associations`].projectType === this.projectType &&
      this._cacheService[`${assocStatus}Associations`].orgId === this.orgId) {
      this.associations = this._cacheService[`${assocStatus}Associations`].associations;
    } else {
      this.associations = [];
    }
  }

  loadAssociationsToCache(): void {
    const assocStatus = this.status === 'A' ? 'active' : 'inactive';
    const data = {
      projectType: this.projectType,
      orgId: this.orgId,
      associations: this.associations
    };
    if (this.adoptMe === 'Y') {
      this._cacheService[`${assocStatus}AdoptedAssociations`] = data;
    } else if (this.adoptMe === 'N') {
      this._cacheService[`${assocStatus}NotAdoptedAssociations`] = data;
    } else {
      this._cacheService[`${assocStatus}Associations`] = data;
    }
    this._cacheService.humansAndWildLifeRequest = this.projectType;
  }


  loadCountries(): void {
    this._donationService.loadCountries()
      .then((response) => {
        this.countries = response;
      }).catch((error) => {
        this._appService.notify(error);
      });
  }

  loadUsers(): void {
    const endPoint = '/donation/users/summary/';
    const reqObj = {
      adopt_me: this.adoptMe,
      status: this.status,
      org_type: '',
      almo_org_id: this.orgId
    };
    if (this.projectType && this.projectType === PROJECTS.HumansAndWildLife) {
      reqObj.org_type = 'humansandwildlife';
    }
    this.shops = [];
    this.associations = [];
    this.showSpinner = true;
    this._httpService.httpRequest('POST', endPoint, reqObj, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - loadUsers()', status: 1 });
      } else if (data.status === 'ERROR' || data.status === 1) {
        this._appService.notify({ msg: data.msg, status: 1 });
      } else {
        this.predicate = 'user_id';
        this.desc = false;
        for (let i = 0; i < data.result.length; i++) {
          const associationObj = data.result[i];
          if (associationObj.association_type) {
            associationObj.type = associationObj.association_type.toUpperCase() === 'NON ONLUS' ? 'NON ONLUS' : 'ONLUS';
          } else {
            associationObj.type = '';
          }
          associationObj.type = associationObj.association_type &&
          associationObj.association_type.toUpperCase() === 'NON ONLUS' ? 'NON ONLUS' : 'ONLUS';
          associationObj.org_name = this._formatService.removeEscapeCharacter(associationObj.org_name);
          associationObj.address = this._formatService.removeEscapeCharacter(associationObj.address);
          associationObj.city = this._formatService.removeEscapeCharacter(associationObj.city);
          associationObj.f_registration_date = this._formatService.formatDate(associationObj.registration_date);
          associationObj.registration_date_millis = this._formatService.dateInMillis(associationObj.registration_date);
          this.associations.push(associationObj);
        }
        this.loadAssociationsToCache();
      }
      this.showSpinner = false;
    });
  }

  mergeUsers(): void {
    let endPoint = '/donation/associations/merge/', req: any = {}, selectedUsers = [], lines, selectedUser: any = {};
    lines = this.type === 'shops' ? this.shops : this.associations;
    req.user_id = this.userId;
    lines.filter(user => user.checked).forEach((user) => {
      if (user.user_id !== parseInt(this.primaryUser, 10)) {
        selectedUser = {};
        selectedUser.org_id = user.org_id;
        selectedUser.email = user.user_email;
        selectedUser.user_id = user.user_id;
        selectedUsers.push(selectedUser);
      } else {
        req.primary_org_id = user.org_id;
      }
      user.checked = false;
    });
    req.org_ids = selectedUsers;
    this.showMenu = false;
    this.showSpinner = true;
    this._httpService.httpRequest('PUT', endPoint, req, (data) => {
      this.showSpinner = false;
      this.clearSelections();
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - mergeUsers()' });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.clearCachedAssociations();
        this.loadUsers();
        this._appService.notify({ status: 0, msg: data.msg });
      }
    });
  }

  onAssociationChange(): void {
    const index = this.assocLov.findIndex((value) => value.org_id === parseInt(this.association.association_id, 10));
    if (index !== -1) {
      this.association.association_name = this.assocLov[index].org_name;
      this.association.first_name = this.assocLov[index].user_name;
      this.association.user_email = this.assocLov[index].user_email;
      this.association.receiver = this.assocLov[index].association_type === 'NON ONLUS' ? 'NON ONLUS' : 'ONLUS';
      this.association.country = this.assocLov[index].country.split('_')[0];
      this.association.language = this.assocLov[index].language;
    }
  }

  onLineSelection(): void {
    let checkedCount = 0;
    const lines = this.type === 'shops' ? this.shops : this.associations;
    this.selectAll = false;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].checked) {
        checkedCount += 1;
      }
    }
    this.checkedCount = checkedCount;
  }

  onStatusChange(status): void {
    this.status = status;
    this.clearSelections();
    this.loadAssociationsFromCache();
    if (!this.associations || this.associations.length === 0) {
      this.loadUsers();
    }
  }

  prepareInvite(): void {
    this.focusAssocName = true;
    this.focusAssocType = true;
    this.focusName = true;
    this.focusEmail = true;
    this.focusCountry = true;
    this.initializeAssociation();
    this.inviteDialog = true;
  }

  registerUser(user): void {
    const req = {
      role: ['donation-desk'],
      assoc_id: user.assoc_id,
      name: user.name,
      username: user.email,
      notify: 'Y'
    };
    this._httpService.httpRequest('POST', '/aws/cognito/register/', req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: registerUser()' });
      } else if (data.msg && data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (data.status === 0) {
        this._appService.notify({ stauts: 0, msg: 'Invitation sent successfully' });
      } else {
        this._appService.notify({ status: 1, msg: 'Unknown Error! Please try again' });
      }
    });
  }

  resendPassword(user): void {
    const endPoint = '/aws/cognito/password/resend/';
    let link = 'https://www.almonature.com/';
    link += `${user.country.toLowerCase()}/donation-desk/?action=login&email=${user.email}`;
    const req = { email: user.email, name: user.name, link };
    this._httpService.httpRequest('POST', endPoint, req, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: resentPassword()' });
      } else if (data.msg && data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else if (data.status === 0) {
        this._appService.notify({ status: 0, msg: 'Invitation sent successfully' });
      } else {
        this._appService.notify({ status: 1, msg: 'Unknown Error! Please try again' });
      }
    });
  }

  selectAllLines(type): void {
    const lines = type === 'shops' ? this.shops : this.associations;
    if (jQuery(`#select-all-${type}`).is(':checked')) {
      for (let i = 0; i < lines.length; i++) {
        lines[i].checked = true;
      }
      this.checkedCount = lines.length;
    } else {
      for (let i = 0; i < lines.length; i++) {
        lines[i].checked = false;
      }
      this.checkedCount = 0;
    }
  }

  sort(key): void {
    if (key === this.predicate) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = false;
    }
  }

  updateStatus(status, shop): void {
    const endPoint = `/donation/user/${status === 'A' ? 'approve' : 'reject'}/${shop.user_id}/`;
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ msg: 'Server Error - updateStatus()', status: 1 });
      } else if (data.status === 'ERROR' || data.status === 1) {
        this._appService.notify({ msg: data.msg, status: 1 });
      } else {
        shop.status = status;
      }
      this.showSpinner = false;
    });
  }

  viewProfile(association): void {
    this._appService.associationId = association.org_id;
    this._cacheService.donationUserType = this.type;
    this._cacheService.associationsStatus = this.status;
    this._cacheService.adoptMe = this.adoptMe;
    if (this.projectType === PROJECTS.HumansAndWildLife) {
      this._router.navigate(['donation/association/profile'], { queryParams: { project: 'humans-and-wild-life' } });
    } else {
      this._router.navigate(['donation/association/profile']);
    }
  }
}
