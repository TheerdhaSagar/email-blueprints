export interface PriceList {
  currency_code: string;
  list_header_id: number;
  name: string;
}
