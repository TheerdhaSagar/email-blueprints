import { Component, Injector, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { TabletemplateComponent } from '../../globals/tabletemplate/tabletemplate.component';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { HttpService } from '../../globals/http.service';
import { Settings } from '../../globals/tabletemplate/models/settings';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { ProductMappingService } from './product-mapping.service';
import { PriceList } from './price-list';
import { Product } from './product';

@Component({
  selector: 'app-product-mapping',
  templateUrl: './product-mapping.component.html',
  styleUrls: ['./product-mapping.component.scss'],
  providers: [OrderByPipe],
})
export class ProductMappingComponent implements OnInit {
  @ViewChild(TabletemplateComponent) child: TabletemplateComponent;

  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _location: Location = this.injector.get(Location);
  private _orderBy: OrderByPipe;
  private _productMappingService: ProductMappingService = this.injector.get(
    ProductMappingService
  );
  private _router: Router = this.injector.get(Router);
  private _window: any;

  allPetSizeList: any[];
  allProducts: any[];
  allSummary: any[];
  applicationType: string;
  applicationTypeFilter: string;
  applicationTypeList: any[];
  desc: boolean;
  focusApplicationType: boolean;
  focusItemCode: boolean;
  focusMealWeight = true;
  focusNoOfDays = true;
  focusNoOfMeals = true;
  focusPetSize: boolean;
  focusPriceList: boolean;
  focusQtyPerPet: boolean;
  foodType: string;
  headerDetails: any[];
  inventoryItemId: number;
  itemCode: string;
  itemName: string;
  mealWeight: number;
  noOfDays: number;
  noOfMeals: number;
  openDialog: boolean;
  openProductMappingDialog: boolean;
  pageDim: boolean;
  petSize: string;
  petSizeList: any[];
  petType: string;
  predicate: string;
  priceList: number;
  priceLists: PriceList[];
  productMappingSummary: any[];
  productsDetails: any[];
  qtyPerPet: number;
  searchQuery: string;
  showSpinner: boolean;
  status: string;
  statusFilter: string;
  statusList: any[];
  tableSettings: Settings;
  toggleFilter: (e?) => void;
  updateProductDetails: Product;
  updateStatusButtonsList: any[];
  user: any;

  constructor(private injector: Injector, orderBy: OrderByPipe) {
    this._orderBy = orderBy;
    this._window = window;

    this.allPetSizeList = [
      { pet_type: 'CAT', pet_size: 'CAT' },
      { pet_type: 'CAT', pet_size: 'KITTEN' },
      { pet_type: 'DOG', pet_size: 'PUPPY-SMALL' },
      { pet_type: 'DOG', pet_size: 'PUPPY-MEDIUM' },
      { pet_type: 'DOG', pet_size: 'PUPPY-LARGE' },
      { pet_type: 'DOG', pet_size: 'ADULT-SMALL' },
      { pet_type: 'DOG', pet_size: 'ADULT-MEDIUM' },
      { pet_type: 'DOG', pet_size: 'ADULT-LARGE' },
    ];
    this.allProducts = [];
    this.allSummary = [];
    this.applicationType = '';
    this.applicationTypeFilter = 'ALL';
    this.applicationTypeList = [
      { label: 'Donation AdoptMe', value: 'LOVEFOOD' },
      { label: 'Welcome Kit AdoptMe', value: 'ADOPTME' },
      { label: 'Donation LoveFood', value: 'DONATIONLOVEFOOD' },
      { label: 'Donation LoveFood Bank', value: 'DONATIONLOVEFOODBANK' },
      { label: 'Habitat', value: 'HUMANSANDWILDLIFE' },
    ];
    this.desc = false;
    this.focusApplicationType = true;
    this.focusItemCode = true;
    this.focusPetSize = true;
    this.focusPriceList = true;
    this.focusQtyPerPet = true;
    this.headerDetails = [
      { title: 'Application Type', keyName: 'donation_type_label' },
      {
        title: 'Price List',
        keyName: 'price_list_name',
        styles: { 'word-break': 'break-all' },
      },
      { title: 'Item Code', keyName: 'item_code' },
      {
        title: 'Item Name',
        keyName: 'item_description',
        styles: { 'word-break': 'break-all' },
      },
      { title: 'Item Type', keyName: 'wet_dry' },
      { title: 'Pet Type', keyName: 'pet_type' },
      { title: 'Pet Size', keyName: 'pet_size' },
      {
        title: 'Weight Per Meal (in gms)',
        keyName: 'weight_per_meal',
        styles: { format: 'number' },
      },
      {
        title: 'No Of Meals/Day',
        keyName: 'no_of_meals',
        styles: { format: 'number' },
      },
      {
        title: 'No Of Days',
        keyName: 'no_of_days',
        styles: { format: 'number' },
      },
    ];
    this.inventoryItemId = null;
    this.itemCode = '';
    this.itemName = '';
    this.openDialog = false;
    this.openProductMappingDialog = false;
    this.pageDim = false;
    this.petSize = '';
    this.petSizeList = [];
    this.petType = '';
    this.predicate = 'donation_type_label';
    this.productMappingSummary = [];
    this.productsDetails = [];
    this.qtyPerPet = null;
    this.searchQuery = null;
    this.showSpinner = false;
    this.status = '';
    this.statusFilter = 'Y';
    this.statusList = [
      { label: 'ALL', value: 'ALL' },
      { label: 'Active', value: 'Y' },
      { label: 'Not Active', value: 'N' },
    ];
    this.tableSettings = new Settings({ headers: [] });
    this.toggleFilter = this._appService.toggleFilter();
    this.updateProductDetails = {
      item_code: '',
      item_description: '',
      is_active: '',
      created_by: null,
      end_date_active: '',
    };
    this.updateStatusButtonsList = [
      {
        key: 'is_active',
        key_label: 'Is Active',
        value: 'Y',
        className: 'action-btn action-btn--warning',
        label: 'Deactivate',
        isLabel: true,
      },
      {
        key: 'is_active',
        key_label: 'Is Active',
        value: 'N',
        className: 'action-btn action-btn--primary',
        label: 'Activate',
        isLabel: true,
      },
    ];
    this.user = '';
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this._appService.scrollTop();
        this.getTableSettings();
        this.loadPriceLists();
        this.loadProductMappingSummary();
      }
    });
  }

  applyFilter(isToggle?): void {
    if (!isToggle) {
      this.toggleFilter();
    }
    if (this.applicationTypeFilter === 'ALL' && this.statusFilter === 'ALL') {
      this.productMappingSummary = this.allSummary;
    } else if (this.applicationTypeFilter === 'ALL') {
      this.productMappingSummary = this.allSummary.filter(
        (product) => product.is_active === this.statusFilter
      );
    } else if (this.statusFilter === 'ALL') {
      this.productMappingSummary = this.allSummary.filter(
        (product) => product.donation_type === this.applicationTypeFilter
      );
    } else {
      this.productMappingSummary = this.allSummary.filter(
        (product) =>
          product.donation_type === this.applicationTypeFilter &&
          product.is_active === this.statusFilter
      );
    }
    this.productMappingSummary = this._orderBy.transform(
      this.productMappingSummary,
      'item_code',
      false
    );
  }

  clearItemDetails(): void {
    this.itemCode = '';
    this.itemName = '';
    this.petType = '';
    this.petSize = '';
    this.noOfDays = null;
    this.noOfMeals = null;
    this.mealWeight = null;
    this.foodType = null;
  }

  closeProductMappingDialog(): void {
    this.openProductMappingDialog = false;
  }

  createProductMapping(): void {
    this.resetMappingDetails();
    this.openProductMappingDialog = true;
  }

  // export to excel sheet
  exportData(): void {
    this.toggleFilter();
    this.child.exportData('Product Mapping');
  }

  getProductMappingDetails(): void {
    const req = {
      pet_size: this.petSize,
      is_active: 'Y',
      price_list_id: this.priceList,
      item_code: this.itemCode,
      donation_type: this.applicationType,
      pet_type: this.petType,
      inventory_item_id: this.inventoryItemId,
      qty_per_pet: 1,
      weight_per_meal: this.mealWeight,
      no_of_meals: this.noOfMeals,
      no_of_days: this.noOfDays,
      created_by: this.user.user_id,
    };
    this.saveProductMappingDetails('POST', req);
  }

  getTableSettings(): void {
    this.tableSettings = new Settings({
      headers: this.headerDetails,
      sortHeader: true,
      predicate: this.predicate,
      desc: this.desc,
      updateStatusButtonsList: this.updateStatusButtonsList,
    });
  }

  loadPriceLists(): void {
    this._productMappingService
      .loadPriceLists()
      .then((priceLists) => {
        this.priceLists = priceLists;
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  loadPriceListProducts(): void {
    this.productsDetails = [];
    this.clearItemDetails();
    this.setFocus();
    this._productMappingService
      .loadPriceListProducts(this.priceList)
      .then((products) => {
        this.allProducts = products;
        this.parseProductsDetails();
      })
      .catch((error) => {
        this._appService.notify(error);
      });
  }

  loadProductMappingSummary(): void {
    const endPoint = '/donation/products/map/';
    this._appService.scrollTop();
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - loadProductMappingSummary',
        });
      } else if (data.status === 1) {
        this._appService.notify({ status: 1, msg: data.msg });
      } else {
        this.allSummary = this._orderBy.transform(
          data.products_map,
          'item_code',
          false
        );
        this.productMappingSummary = [...this.allSummary];
        this.parseProductMappingSummary();
      }
    });
  }

  openStatusDialog(event): void {
    this.openDialog = true;
    this.status = event.is_active === 'Y' ? 'Deactivate' : 'Activate';
    this.updateProductDetails = { ...event };
  }

  parseProductMappingSummary(): void {
    this.allSummary.forEach((summaryValue) => {
      const value = summaryValue;
      const typeIndex = this.applicationTypeList.findIndex(
        (type) => type.value === value.donation_type
      );
      value.donation_type_label =
        typeIndex !== -1 ? this.applicationTypeList[typeIndex].label : '';
    });
    this.applyFilter(true);
  }

  parseProductsDetails(): void {
    this.allProducts.forEach((productDetails) => {
      const product = productDetails;
      product.display_label = `${product.item_code}, ${product.item_description}`;
    });
    this.allProducts = this._orderBy.transform(
      this.allProducts,
      'item_code',
      false
    );
    this.productsDetails = [...this.allProducts];
  }

  populateItemValues(): void {
    if (!this.itemCode) {
      this.itemName = '';
      this.petType = '';
      this.petSize = '';
      this.foodType = '';
    } else {
      const item = this.allProducts.find(
        (product) => product.item_code === this.itemCode
      );
      this.itemName = item.item_description;
      this.petType = item.pet_type;
      this.inventoryItemId = item.inventory_item_id;
      this.petSizeList = this.allPetSizeList.filter(
        (pet) => pet.pet_type === this.petType
      );
      this.petSizeList.unshift({ pet_type: this.petType, pet_size: 'ALL' });
      this.petSize = 'ALL';
      this.foodType = item.wet_dry;
    }
  }

  reloadSummaryData(): void {
    this.openProductMappingDialog = false;
    this.openDialog = false;
    this.applicationTypeFilter = 'ALL';
    this.statusFilter = 'Y';
    this.loadProductMappingSummary();
  }

  removeFocus(): void {
    this.focusApplicationType = false;
    this.focusItemCode = false;
    this.focusPetSize = false;
    this.focusPriceList = false;
    this.focusQtyPerPet = false;
    this.focusMealWeight = false;
    this.focusNoOfDays = false;
    this.focusNoOfMeals = false;
  }

  resetMappingDetails(): void {
    this.applicationType = '';
    this.priceList = null;
    this.clearItemDetails();
    this.qtyPerPet = null;
    this.setFocus();
  }

  saveProductMappingDetails(method, req): void {
    const endPoint = '/donation/products/map/';
    if (method === 'POST' && this.validateProductMappingDetails()) {
      this.removeFocus();
      return;
    }
    this.pageDim = true;
    this._httpService.httpRequest(method, endPoint, req, (data) => {
      this.pageDim = false;
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error - saveProductMappingDetails()',
        });
      } else {
        this._appService.notify({ status: data.status, msg: data.msg });
        if (data.status === 0) {
          this.reloadSummaryData();
        }
      }
    });
  }

  setFocus(): void {
    this.focusApplicationType = true;
    this.focusItemCode = true;
    this.focusPetSize = true;
    this.focusPriceList = true;
    this.focusQtyPerPet = true;
    this.focusMealWeight = true;
    this.focusNoOfDays = true;
    this.focusNoOfMeals = true;
  }

  updateItemsList(): void {
    this.productsDetails = [...this.allProducts];
    this.productMappingSummary.forEach((mapping) => {
      const isActive =
        mapping.donation_type === this.applicationType &&
        mapping.is_active === 'Y';
      if (isActive) {
        const index = this.productsDetails.findIndex(
          (product) => product.item_code === mapping.item_code
        );
        if (index !== -1) {
          this.productsDetails.splice(index, 1);
        }
      }
    });
    this.clearItemDetails();
  }

  updateStatus(): void {
    const details = { ...this.updateProductDetails };
    const req = { ...this.updateProductDetails };
    req.is_active = details.is_active === 'Y' ? 'N' : 'Y';
    req.created_by = this.user.user_id;
    req.end_date_active =
      details.is_active === 'Y' ? this._appService.today(0) : null;
    this.saveProductMappingDetails('PUT', req);
  }

  validateMealDetails(): boolean {
    return (
      (this.focusMealWeight && !this.mealWeight) ||
      (this.focusNoOfMeals && !this.noOfMeals) ||
      (this.focusNoOfDays && !this.noOfDays)
    );
  }

  validateProductMappingDetails(): boolean {
    this.setFocus();
    return (
      (this.focusApplicationType && !this.applicationType) ||
      (this.focusPriceList && !this.priceList) ||
      (this.focusItemCode && !this.itemCode) ||
      (this.focusPetSize && !this.petSize) ||
      this.validateMealDetails()
    );
  }
}
