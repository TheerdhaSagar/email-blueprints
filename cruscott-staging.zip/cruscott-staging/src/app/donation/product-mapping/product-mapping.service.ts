import { Injectable, Injector } from '@angular/core';
import { HttpService } from '../../globals/http.service';
import { ServerError } from '../../globals/server.error';
import { APIError } from '../../globals/api.error';
import { PriceList } from './price-list';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductMappingService {
  private _httpService = this.injector.get(HttpService);

  private readonly URL_PREFIX;

  constructor(private injector: Injector) {
    this.URL_PREFIX = '/donation';
  }

  loadPriceLists(): Promise<PriceList[]> {
    return new Promise((resolve, reject) => {
      const endPoint = '/pricelists/filenames/';
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('loadPriceLists'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  loadPriceListProducts(priceListId: number): Promise<Product[]> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.URL_PREFIX}/pricelist/products/${priceListId}/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('loadPriceListProducts'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response.products);
        }
      });
    });
  }
}
