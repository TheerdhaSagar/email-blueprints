export interface Product {
  created_by?: number;
  end_date_active?: string;
  inventory_item_id?: string;
  is_active?: string;
  item_code: string;
  item_description?: string;
  pet_type?: string;
}
