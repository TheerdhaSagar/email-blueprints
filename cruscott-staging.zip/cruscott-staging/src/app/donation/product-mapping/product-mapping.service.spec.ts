import { TestBed } from '@angular/core/testing';

import { ProductMappingService } from './product-mapping.service';

describe('ProductMappingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProductMappingService = TestBed.get(ProductMappingService);
    expect(service).toBeTruthy();
  });
});
