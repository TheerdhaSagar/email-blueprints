import { Injectable, Injector } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { HttpService } from '../../globals/http.service';
import { ServerError } from '../../globals/server.error';
import { APIError } from '../../globals/api.error';
import { Application } from '../application';
import { AppService } from '../../globals/app.service';
import { Response } from '../../globals/response';
import { FormatService } from '../../globals/format.service';
import {
  PartnerAssociation,
  PartnerSummary,
} from '../partner-association/partner-association';
import { PetDetailsEntity } from '../partner-association/pet-details';
import { DonationDetailsEntity } from '../partner-association/donation-details';
import { AddressEntity } from '../partner-association/address';
import { Record } from '../partner-association/record';

@Injectable({
  providedIn: 'root',
})
export class DonationService {
  private _appService: AppService = this.injector.get(AppService);
  private _formatService: FormatService = this.injector.get(FormatService);
  private _httpService: HttpService = this.injector.get(HttpService);
  private _sce: DomSanitizer = this.injector.get(DomSanitizer);

  public readonly PARTNER_PREFIX: string;
  public readonly URL_PREFIX: string;

  constructor(private injector: Injector) {
    this.PARTNER_PREFIX = '/hw/partners';
    this.URL_PREFIX = '/donation';
  }

  changeContactPassword(requestData: {
    username: string;
    password: string;
  }): Promise<Response> {
    const endPoint = `/aws/cognito/set/password/${requestData.username}/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        'POST',
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('POST - changeContactPassword'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  createCognitoCredentials(requestData): Promise<Response> {
    const endPoint = '/aws/cognito/register/';
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        'POST',
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('POST - createCognitoCredentials'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response.msg);
          }
        }
      );
    });
  }

  deleteAdoption(adoptionId): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `/donation/adoptions/${adoptionId}/`;
      this._httpService.httpRequest('DELETE', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deleteAdoption'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  deleteDonationOrPetDetails(
    donationId: number,
    partnerType: string
  ): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.PARTNER_PREFIX}/${partnerType}/${donationId}/`;
      this._httpService.httpRequest('DELETE', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deleteDonationOrPetDetails'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  deletePartnerAssocPetDetails(petId: number): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.PARTNER_PREFIX}/pets/${petId}/`;
      this._httpService.httpRequest('DELETE', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('deletePartnerAssocPetDetails'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  findCountry(countryCode: string): string {
    let country;
    switch (countryCode) {
      case 'IT':
        country = 'ITALY';
        break;
      case 'BE':
        country = 'BELGIUM';
        break;
      case 'FR':
        country = 'FRANCE';
        break;
      case 'NL':
        country = 'NETHERLANDS';
        break;
      default:
        country = countryCode;
        break;
    }
    return country;
  }

  formatAddress(data: AddressEntity): SafeHtml {
    let formattedAddress = '';
    if (data) {
      formattedAddress = `${data.address || data.address_line_1}<br/>${
        data.zip
      } ${data.city} `;
      if (data.province) {
        formattedAddress += `${data.province}<br/>`;
      }
      formattedAddress += this.findCountry(data.country);
      if (data.phone) {
        formattedAddress += `<br/>Tel: ${data.phone || '-'}`;
      }
    }
    return this._sce.bypassSecurityTrustHtml(formattedAddress.toUpperCase());
  }

  formatAttachmentName(attachments): void {
    if (attachments) {
      attachments.forEach((attachment) => {
        const attach = attachment;
        attach.file_name = this._formatService.removeEscapeCharacter(
          attach.file_name
        );
      });
    }
  }

  getDetailsHWPartnerAssociation(
    partnerId: number
  ): Promise<PartnerAssociation> {
    const endPoint = `${this.PARTNER_PREFIX}/${partnerId}/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('getDetailsHWPartnerAssociation'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response.partner_details[0]);
        }
      });
    });
  }

  getPartnerAssociationJSONFile(): Promise<Record<Array<string>>> {
    const endPoint = '/cdn/?file_name=partner_association.json';
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('GET - getPartnerAssociationJSONFile'));
        } else if (response.status === 1) {
          reject(new APIError(response));
        } else {
          resolve(response);
        }
      });
    });
  }

  getSummaryHWPartnerAssociation(
    orgId: number
  ): Promise<Array<PartnerSummary>> {
    const endPoint = `${this.PARTNER_PREFIX}/summary/?org_id=${orgId}`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('getSummaryHWPartnerAssociation'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response.partner_details);
        }
      });
    });
  }

  loadApplications(endPoint): Promise<Application[]> {
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('loadApplications'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response.result);
        }
      });
    });
  }

  loadCountries(): Promise<Array<{ country: string; country_code: string }>> {
    const endPoint = '/registration/countries/';
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('loadCountries'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  manageHWPartnerAssociation(
    method: string,
    requestData: PartnerAssociation
  ): Promise<Response & { partner_association_id: number }> {
    const endPoint = `${this.PARTNER_PREFIX}/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        method,
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('manageHWPartnerAssociation'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  manageHWPartnerAssocDonationDetails(
    method: string,
    requestData: DonationDetailsEntity
  ): Promise<Response & { partner_donation_id: number }> {
    const endPoint = `${this.PARTNER_PREFIX}/donations/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        method,
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('manageHWPartnerAssocDonationDetails'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  manageHWPartnerAssocPetDetails(
    method: string,
    requestData: PetDetailsEntity
  ): Promise<Response & { pet_id: number }> {
    const endPoint = `${this.PARTNER_PREFIX}/pets/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        method,
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('manageHWPartnerAssocPetDetails'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  resendContactPasswordLink(requestData): Promise<Response> {
    const endPoint = '/aws/cognito/password/forgot/';
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        'POST',
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('POST - resendContactPasswordLink'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  uploadApplicationOrg(requestData): Promise<Response> {
    const endPoint = `${this.URL_PREFIX}/application/org/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        'POST',
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('POST - uploadApplicationOrg'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }

  validateApplication(applicationName, allApplications, isVerified?): boolean {
    const appName = applicationName.slice(0, -2);
    let isValid = true;
    for (let i = 0; i < allApplications.length; i++) {
      if (this.validateApplicationForCountry(allApplications[i])) {
        isValid = true;
      } else if (
        (allApplications[i].request_status === 'O' &&
          allApplications[i].ricevuta === 'N') ||
        isVerified
      ) {
        this._appService.notify({
          status: 1,
          msg: `Ricevuta document is missing for ${appName}. Can't create / copy a new application`,
        });
        isValid = false;
        break;
      }
    }
    return isValid;
  }

  // 'L' - Donation AdoptMe, 'A' - Welcome Kit AdoptMe
  validateApplicationForCountry(application): boolean {
    let year = application.created_date.split('-');
    year = parseInt(year[2], 10);
    /* For Germany - Any kind of application will not have Receipts.
    For France - Welcome Kit Adopt Me applications will not have Receipts.
    Donation Adopt Me applications ignore the Receipt check for any application before the 2019 year. */
    return (
      application.country === 'DE' ||
      (application.country === 'FR' &&
        (application.request_type === 'A' ||
          (application.request_type === 'L' && year < 2019)))
    );
  }

  validateEmailInCognito(emailAddress: string): Promise<Response> {
    const endPoint = `/aws/cognito/users/validate/${emailAddress}/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('GET - validateEmailInCognito'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  validateUrl(requestData: { url: string }): Promise<Response> {
    const endPoint = `${this.URL_PREFIX}/validate/url/`;
    return new Promise((resolve, reject) => {
      this._httpService.httpRequest(
        'POST',
        endPoint,
        requestData,
        (response) => {
          if (!response) {
            reject(new ServerError('POST - validateUrl'));
          } else if (response.status === 1) {
            reject(new APIError(response.msg));
          } else {
            resolve(response);
          }
        }
      );
    });
  }
}
