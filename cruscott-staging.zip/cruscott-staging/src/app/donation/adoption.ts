export interface Adoption {
  address: string;
  adoption_date: string;
  adoption_id: number;
  city: string;
  comments: string;
  consent: string;
  country: string;
  created_date: string;
  email: string;
  f_pet_parent_name?: string;
  org_id: number;
  org_name: string;
  pet_age: string;
  pet_breed: string;
  pet_name: string;
  pet_parent_name: string;
  pet_size: string;
  pet_type: string;
  phone: string;
  province: string;
  registered: string;
  registration_code: string;
  request_header_id: number;
  zip: string;
}
