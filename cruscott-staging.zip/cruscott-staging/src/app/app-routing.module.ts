import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TemplateComponent } from './template/template.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { RecipesMainComponent } from './productversion/recipe/main/main.component';
import { RegisterComponent } from './onboard/suppliers/register/register.component';
import { OutCanadaMainComponent } from './outcanada/main/main.component';
import { OutCanadaCustomersComponent } from './outcanada/customer/customer.component';
import { OutCanadaItemsComponent } from './outcanada/items/items.component';
import { OutCanadaManagerComponent } from './outcanada/manager/manager.component';
import { OutCanadaMonthComponent } from './outcanada/month/month.component';
import { CanadaRevenueProvinceComponent } from './outcanada/province/province.component';
import { MainOutOfDoorComponent } from './outofdoor/main/main.component';
import { OutOfDoorAgentComponent } from './outofdoor/agent/agent.component';
import { OutCanadaComponent } from './outcanada/outcanada.component';
import { OutOfDoorComponent } from './outofdoor/outofdoor.component';
import { OutOfDoorCustomerComponent } from './outofdoor/customer/customer.component';
import { OutOfDoorDistributorComponent } from './outofdoor/distributor/distributor.component';
import { OutOfDoorItemComponent } from './outofdoor/item/item.component';
import { ItemSummaryComponent } from './outofdoor/itemsummary/itemsummary.component';
import { OutOfDoorMonthComponent } from './outofdoor/month/month.component';
import { NewCustomersComponent } from './outofdoor/newcustomers/newcustomers.component';
import { RevenueManagerComponent } from './outofdoor/revenuemanager/revenuemanager.component';
import { OutofdoorSalesManagersComponent } from './outofdoor/salesmanagers/salesmanagers.component';
import { OutOfDoorStateComponent } from './outofdoor/state/state.component';
import { OutofdoorTMCustomersComponent } from './outofdoor/tmcustomers/tmcustomers.component';
import { PriceListDashboardComponent } from './pricelists/dashboard/dashboard.component';
import { PriceListComponent } from './pricelists/pricelists.component';
import { EditProductRecipeComponent } from './productversion/recipe/edit/edit.component';
import { ViewProductRecipeComponent } from './productversion/recipe/view/view.component';
import { ProfileComponent } from './profile/profile.component';
import { ProductsComponent } from './utilities/products/products.component';
import { ConversionComponent } from './utilities/conversion/conversion.component';
import { PasswordChangeComponent } from './password-change/password-change.component';
import { PreAuthorizationApproveComponent } from './pre-authorization/request/approve/approve.component';
import { ApproveLeaveComponent } from './hcm/leavemanagement/leaves/approve/approve.component';
import { SupplierClaimCreateComponent } from './reclaims/supplierclaim/create/create.component';
import { SupplierClaimSummaryComponent } from './reclaims/supplierclaim/summary/summary.component';
import { ReclaimsDashboardComponent } from './reclaims/dashboard/dashboard.component';
import { CustomerClaimSummaryComponent } from './reclaims/customerclaim/summary/summary.component';
import { CustomerClaimCreateComponent } from './reclaims/customerclaim/create/create.component';
import { ShippingLabelsComponent } from './shipping-labels/shipping-labels.component';
import { ApproveDonationApplicationComponent } from './donation/manage/application/approve/approve-donation-application.component';
import { HumanandWildLifeRegisterComponent } from './humansandwildlife/register/register.component';
import { HumanandWildlifeUserDashboardComponent } from './humansandwildlife/users-dashboard/dashboard.component';
import { HWAssociationsSummaryComponent } from './humansandwildlife/associations/summmary/summmary.component';
import { HWAssociationComponent } from './humansandwildlife/associations/manage/manage.component';
import { HumansAndWildLifeDashboardComponent } from './humansandwildlife/dashboard/dashboard.component';
import { HumansAndWildLifeInvitationsComponent } from './humansandwildlife/invitations/invitations.component';
import { PromotionApproveComponent } from './promotions/approve/approve.component';

const activityPlannerRoutes: Routes = [
  {
    path: 'activity-planner',
    loadChildren:
      './activity-planner/activity-planner.module#ActivityPlannerModule',
  },
];

const agentTargetRoutes: Routes = [
  {
    path: 'agent-targets',
    loadChildren: './agent-targets/agent-targets.module#AgentTargetsModule',
  },
];

const assetMgmtRoutes: Routes = [
  {
    path: 'asset-management',
    loadChildren:
      './assetmanagement/assetmanagement.module#AssetManagementModule',
  },
];

const budgetRoutes: Routes = [
  { path: 'budget', loadChildren: './budget/budget.module#BudgetModule' },
];

const caflRoutes: Routes = [
  { path: 'cafl', loadChildren: './cafl/cafl.module#CaflModule' },
];

const campaignRoutes: Routes = [
  {
    path: 'campaigns',
    loadChildren: './campaigns/campaigns.module#CampaignsModule',
  },
];

const contactsRoutes: Routes = [
  {
    path: 'contacts',
    loadChildren: './contacts/contacts.module#ContactsModule',
  },
];

const contactReasonRoutes: Routes = [
  {
    path: 'reasons',
    loadChildren:
      './contact-reasons/contact-reasons.module#ContactReasonsModule',
  },
];

const couponsRoutes: Routes = [
  { path: 'coupons', loadChildren: './coupons/coupons.module#CouponsModule' },
];

const creditNotesRoutes: Routes = [
  {
    path: 'creditnotes',
    loadChildren: './creditnotes/creditnotes.module#CreditnotesModule',
  },
];

const dashboardRoutes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
];

const donationRoutes: Routes = [
  {
    path: 'donation',
    loadChildren: './donation/donation.module#DonationModule',
  },
];

const dsvRoutes: Routes = [
  { path: 'dsv', loadChildren: './dsv/dsv.module#DsvModule' },
];

const eventsRoutes: Routes = [
  { path: 'events', loadChildren: './events/events.module#EventsModule' },
];

const expensesRoutes: Routes = [
  {
    path: 'expenses',
    loadChildren: './expenses/expenses.module#ExpensesModule',
  },
];

const financeRoutes: Routes = [
  {
    path: 'finance',
    loadChildren: './finance/finance.module#FinanceModule',
  },
];

const forecastRoutes: Routes = [
  {
    path: 'purchasing',
    loadChildren: './forecast/forecast.module#ForecastModule',
  },
];

const gmailRoutes: Routes = [
  {
    path: 'gmail',
    loadChildren:
      './gmail-signature/gmail-signature.module#GmailSignatureModule',
  },
];

const glRoutes: Routes = [
  {
    path: 'gl',
    loadChildren: './gl-journal/gl-journal.module#GlJournalModule',
  },
];

const hcmRoutes: Routes = [
  { path: 'hcm', loadChildren: './hcm/hcm.module#HcmModule' },
];

const humansAndWildLifeRoutes: Routes = [
  {
    path: 'humans-and-wild-life/dashboard',
    component: HumansAndWildLifeDashboardComponent,
  },
  {
    path: 'humans-and-wild-life/invitations',
    component: HumansAndWildLifeInvitationsComponent,
  },
  {
    path: 'humansandwildlife/users-dashboard',
    component: HumanandWildlifeUserDashboardComponent,
  },
  {
    path: 'humanandwildlife/associations/summary',
    component: HWAssociationsSummaryComponent,
  },
  { path: 'humansandwildlife/association', component: HWAssociationComponent },
];

const invoicesRoutes: Routes = [
  {
    path: 'invoices',
    loadChildren: './invoices/invoices.module#InvoicesModule',
  },
];

const loginRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'login/:token', component: LoginComponent },
];

const mailNavigationRoutes: Routes = [
  { path: 'approveleave/:token', component: ApproveLeaveComponent },
  { path: 'supplier/register/:token', component: RegisterComponent },
  {
    path: 'pre-authorization/:token',
    component: PreAuthorizationApproveComponent,
  },
  {
    path: 'application/action/:token',
    component: ApproveDonationApplicationComponent,
  },
  {
    path: 'humanandwildlife/register/:token',
    component: HumanandWildLifeRegisterComponent,
  },
  {
    path: 'promotion/action/:token',
    component: PromotionApproveComponent,
  },
];

const notificationsRoutes: Routes = [
  { path: 'notifications', component: NotificationsComponent },
];

const objectivesRoutes: Routes = [
  {
    path: 'objectives',
    loadChildren: './objectives/objectives.module#ObjectivesModule',
  },
];

const onboardRoutes: Routes = [
  {
    path: 'onboard',
    loadChildren: './onboard/onboard.module#OnboardModule',
  },
];

const outcanadaRoutes: Routes = [
  { path: 'outdoor/canada/dashboard', component: OutCanadaMainComponent },
  {
    path: 'outdoor/canada/reports/revenue',
    component: OutCanadaComponent,
    children: [
      { path: 'customers', component: OutCanadaCustomersComponent },
      { path: 'items', component: OutCanadaItemsComponent },
      { path: 'month', component: OutCanadaMonthComponent },
      { path: 'province', component: CanadaRevenueProvinceComponent },
      { path: 'managers', component: OutCanadaManagerComponent },
      { path: 'customer-chains', component: OutCanadaManagerComponent },
    ],
    runGuardsAndResolvers: 'always',
  },
];

const outdoorRoutes: Routes = [
  { path: 'outdoor/usa/dashboard', component: MainOutOfDoorComponent },
  {
    path: 'outdoor/usa/reports/revenue',
    component: OutOfDoorComponent,
    children: [
      { path: 'reps', component: OutOfDoorAgentComponent },
      { path: 'customers', component: OutOfDoorCustomerComponent },
      { path: 'distributor', component: OutOfDoorDistributorComponent },
      { path: 'items', component: OutOfDoorItemComponent },
      { path: 'items/summary', component: ItemSummaryComponent },
      { path: 'month', component: OutOfDoorMonthComponent },
      { path: 'customers/latest', component: NewCustomersComponent },
      { path: 'managers', component: RevenueManagerComponent },
      { path: 'salesmanagers', component: OutofdoorSalesManagersComponent },
      { path: 'state', component: OutOfDoorStateComponent },
      { path: 'managers/customers', component: OutofdoorTMCustomersComponent },
    ],
  },
];

const passwordRoutes: Routes = [
  { path: 'password/change', component: PasswordChangeComponent },
];

const paymentsRoutes: Routes = [
  {
    path: 'payments',
    loadChildren: './payments/payments.module#PaymentsModule',
  },
];

const poApprovalFlowRoutes: Routes = [
  {
    path: 'poapprovals',
    loadChildren:
      './poapprovalflow/po-approval-flow.module#PoApprovalFlowModule',
  },
  {
    path: 'department-mapping',
    loadChildren:
      './poapprovalflow/department-mapping/department-mapping.module#DepartmentMappingModule',
  },
];

const pobRoutes: Routes = [
  {
    path: 'pob',
    loadChildren: './pob/pob.module#PobModule',
  },
];

const podRoutes: Routes = [
  { path: 'pod', loadChildren: './pod/pod.module#PodModule' },
];

const preAuthRoutes: Routes = [
  {
    path: 'pre-authorization',
    loadChildren:
      './pre-authorization/pre-authorization.module#PreAuthorizationModule',
  },
];

const pricelistsRoutes: Routes = [
  { path: 'pricelists/dashboard', component: PriceListDashboardComponent },
  { path: 'pricelists', component: PriceListComponent },
];

const privacyConsentRoutes: Routes = [
  {
    path: 'privacyconsent',
    loadChildren: './privacyconsent/privacyconsent.module#PrivacyConsentModule',
  },
];

const procurementRoutes: Routes = [
  {
    path: 'procurement',
    loadChildren: './procurement/procurement.module#ProcurementModule',
  },
];

const productsCalendarRoutes: Routes = [
  {
    path: 'products-calendar',
    loadChildren:
      './products-calendar/products-calendar.module#ProductsCalendarModule',
  },
];

const productCatalogueRoutes: Routes = [
  {
    path: 'product-catalogue',
    loadChildren:
      './productcatalogue/product-catalogue.module#ProductCatalogueModule',
  },
];

const productVersionRoutes: Routes = [
  { path: 'products/v1', component: RecipesMainComponent },
  { path: 'products/v1/edit', component: EditProductRecipeComponent },
  { path: 'products/v1/view', component: ViewProductRecipeComponent },
];

const profileRoutes: Routes = [
  { path: 'profile', component: ProfileComponent },
];

const promotionsRoutes: Routes = [
  {
    path: 'promotions',
    loadChildren: './promotions/promotions.module#PromotionsModule',
  },
];

const purchaseOrdersRoutes: Routes = [
  {
    path: 'purchaseorders',
    loadChildren:
      './purchaseorders/purchase-orders.module#PurchaseOrdersModule',
  },
];

const quotesRoutes: Routes = [
  {
    path: 'quotes',
    loadChildren: './quotes/quotes.module#QuotesModule',
  },
];

const reclaimsRoutes: Routes = [
  {
    path: 'reclaims/customer/summary',
    component: CustomerClaimSummaryComponent,
  },
  { path: 'reclaims/customer/create', component: CustomerClaimCreateComponent },
  {
    path: 'reclaims/supplier/summary',
    component: SupplierClaimSummaryComponent,
  },
  { path: 'reclaims/supplier/create', component: SupplierClaimCreateComponent },
  { path: 'reclaims/dashboard', component: ReclaimsDashboardComponent },
];

const reportsRoutes: Routes = [
  {
    path: 'reports',
    loadChildren: './reports/reports.module#ReportsModule',
  },
];

const rvfRoutes: Routes = [
  {
    path: 'rvf',
    loadChildren: './rvf-inventory/rvf-inventory.module#RvfInventoryModule',
  },
];

const salesCalendarRoutes: Routes = [
  {
    path: 'sales-calendar',
    loadChildren: './sales-calendar/sales-calendar.module#SalesCalendarModule',
  },
];

const schedulesRoutes: Routes = [
  {
    path: 'schedules',
    loadChildren: './schedules/schedules.module#SchedulesModule',
  },
];

const shippingRoutes: Routes = [
  { path: 'shipping/labels', component: ShippingLabelsComponent },
];

const storelocatorRoutes: Routes = [
  {
    path: 'storelocator',
    loadChildren: './storelocator/storelocator.module#StorelocatorModule',
  },
];

const supplierRoutes: Routes = [
  {
    path: 'supplier',
    loadChildren: './supplier/supplier.module#SupplierModule',
  },
];

const userAccessControlReportRoutes: Routes = [
  {
    path: 'useraccesscontrol',
    loadChildren:
      './useraccesscontrolreport/useraccesscontrolreport.module#UserAccessControlReportModule',
  },
];

const userManagementRoutes: Routes = [
  {
    path: 'usermanagement',
    loadChildren: './usermanagement/usermanagement.module#UserManagementModule',
  },
];

const utilitiesRoutes: Routes = [
  { path: 'utilities/products', component: ProductsComponent },
  { path: 'utilities/conversion', component: ConversionComponent },
];

const wordpressRoutes: Routes = [
  {
    path: 'website',
    loadChildren: './wordpress/wordpress.module#WordpressModule',
  },
];

const workflowRoutes: Routes = [
  {
    path: 'workflows',
    loadChildren: './workflows/workflows.module#WorkflowsModule',
  },
];

const routes: Routes = [
  ...loginRoutes,
  ...mailNavigationRoutes,
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  {
    path: '',
    component: TemplateComponent,
    children: [
      ...activityPlannerRoutes,
      ...agentTargetRoutes,
      ...assetMgmtRoutes,
      ...budgetRoutes,
      ...caflRoutes,
      ...campaignRoutes,
      ...contactsRoutes,
      ...contactReasonRoutes,
      ...couponsRoutes,
      ...creditNotesRoutes,
      ...dashboardRoutes,
      ...donationRoutes,
      ...dsvRoutes,
      ...eventsRoutes,
      ...expensesRoutes,
      ...financeRoutes,
      ...forecastRoutes,
      ...gmailRoutes,
      ...glRoutes,
      ...hcmRoutes,
      ...humansAndWildLifeRoutes,
      ...invoicesRoutes,
      ...notificationsRoutes,
      ...objectivesRoutes,
      ...onboardRoutes,
      ...outcanadaRoutes,
      ...outdoorRoutes,
      ...passwordRoutes,
      ...paymentsRoutes,
      ...poApprovalFlowRoutes,
      ...pobRoutes,
      ...podRoutes,
      ...preAuthRoutes,
      ...pricelistsRoutes,
      ...privacyConsentRoutes,
      ...procurementRoutes,
      ...productsCalendarRoutes,
      ...productCatalogueRoutes,
      ...productVersionRoutes,
      ...profileRoutes,
      ...promotionsRoutes,
      ...purchaseOrdersRoutes,
      ...quotesRoutes,
      ...reclaimsRoutes,
      ...reportsRoutes,
      ...rvfRoutes,
      ...salesCalendarRoutes,
      ...schedulesRoutes,
      ...shippingRoutes,
      ...storelocatorRoutes,
      ...supplierRoutes,
      ...userAccessControlReportRoutes,
      ...userManagementRoutes,
      ...utilitiesRoutes,
      ...wordpressRoutes,
      ...workflowRoutes,
    ],
    runGuardsAndResolvers: 'always',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload' })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
