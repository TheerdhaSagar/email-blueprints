import { Injectable, Injector } from '@angular/core';
import { HttpService } from '../../globals/http.service';
import { ServerError } from '../../globals/server.error';
import { APIError } from '../../globals/api.error';
import { HubspotContact } from '../hubspotContact';
import { GmailContact } from '../gmailContact';

@Injectable({
  providedIn: 'root'
})
export class GmailContactsMigrationService {
  private readonly URL_PREFIX_CMS: string;
  private readonly URL_PREFIX_GMAIL: string;
  private _httpService: HttpService = this.injector.get(HttpService);

  constructor(private injector: Injector) {
    this.URL_PREFIX_CMS = '/cms';
    this.URL_PREFIX_GMAIL = '/wrapper/gmail';
  }

  createContact(reqObj): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.URL_PREFIX_CMS}/contact/create/list/`;
      this._httpService.httpRequest('POST', endPoint, reqObj, (response) => {
        if (!response) {
          reject(new ServerError('createContact'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  loadContactsList(): Promise<HubspotContact[]> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.URL_PREFIX_CMS}/contactlists/`;
      this._httpService.httpRequest('GET', endPoint, null, (response) => {
        if (!response) {
          reject(new ServerError('loadContactsList'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  loadGmailContactsSummary(reqObj): Promise<GmailContact[]> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.URL_PREFIX_GMAIL}/contacts/list/`;
      this._httpService.httpRequest('POST', endPoint, reqObj, (response) => {
        if (!response) {
          reject(new ServerError('loadGmailContactsSummary'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }

  markAsPersonal(reqObj): Promise<Response> {
    return new Promise((resolve, reject) => {
      const endPoint = `${this.URL_PREFIX_GMAIL}/contact/label/add/`;
      this._httpService.httpRequest('POST', endPoint, reqObj, (response) => {
        if (!response) {
          reject(new ServerError('markAsPersonal'));
        } else if (response.status === 1) {
          reject(new APIError(response.msg));
        } else {
          resolve(response);
        }
      });
    });
  }
}
