import { TestBed } from '@angular/core/testing';

import { GmailContactsMigrationService } from './contacts.service';

describe('GmailContactsMigrationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GmailContactsMigrationService = TestBed.get(GmailContactsMigrationService);
    expect(service).toBeTruthy();
  });
});
