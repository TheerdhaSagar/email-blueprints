import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GmailContactsMigrationComponent } from './contacts.component';

describe('GmailContactsMigrationComponent', () => {
  let component: GmailContactsMigrationComponent;
  let fixture: ComponentFixture<GmailContactsMigrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GmailContactsMigrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GmailContactsMigrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
