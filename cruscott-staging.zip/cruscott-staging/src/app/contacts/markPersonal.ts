export interface MarkPersonal {
  email: string;
  etag: string;
  group_name: string;
  memberships: Array<object>;
  resource_name: string;
}
