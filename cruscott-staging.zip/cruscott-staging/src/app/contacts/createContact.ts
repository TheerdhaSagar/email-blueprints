export interface CreateContact {
  etag?: string;
  list_id: number;
  memberships?: Array<object>;
  owner_email: string;
  props: {
    country: string;
    email: string;
    firstname: string;
    hs_language: string;
    hs_persona: string;
  };
  resource_name?: string;
}
