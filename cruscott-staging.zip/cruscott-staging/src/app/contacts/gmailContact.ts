export interface GmailContact {
  country?: string;
  display_name: string;
  email?: string;
  emails?: Array<string>;
  etag: string;
  isChecked?: boolean;
  language?: string;
  list_id?: number;
  memberships?: Array<object>;
  names: {
    family_name: string;
    display_name: string;
    given_name: string;
  };
  persona?: string;
  photo: string;
  resource_name: string;
}
