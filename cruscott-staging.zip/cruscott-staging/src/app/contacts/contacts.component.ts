import {
  Component, Injector, OnInit
} from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { PrivacyConsentService } from '../privacyconsent/privacyservice/privacyconsent.service';
import { GmailContactsMigrationService } from './services/contacts.service';
import { HubspotContact } from './hubspotContact';
import { Persona } from './persona';
import { DropDownItem } from '../humansandwildlife/dropdownitem';
import { GmailContact } from './gmailContact';
import { CreateContact } from './createContact';
import { MarkPersonal } from './markPersonal';
import { FilterPipe } from '../globals/filter.pipe';
import { OrderByPipe } from '../globals/order-by.pipe';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.scss'],
  providers: [FilterPipe, OrderByPipe]
})
export class GmailContactsMigrationComponent implements OnInit {
  private _appService: AppService = this.injector.get(AppService);
  private _cacheService: CacheService = this.injector.get(CacheService);
  private _filter: FilterPipe = this.injector.get(FilterPipe);
  private _gmailContactsService: GmailContactsMigrationService = this.injector.get(GmailContactsMigrationService);
  private _location: Location = this.injector.get(Location);
  private _orderBy: OrderByPipe = this.injector.get(OrderByPipe);
  private _privacyConsentService: PrivacyConsentService = this.injector.get(PrivacyConsentService);
  private _router: Router = this.injector.get(Router);
  private _window: any;

  allCountriesList: Array<DropDownItem> = [];
  allPaginationNumbers: Array<number> = [];
  completeSummary: Array<GmailContact> = [];
  contactList: Array<HubspotContact> = [];
  contactsFailed: Array<string> = [];
  country: string;
  createContactDialog: boolean;
  displayContactsSummary: Array<{ pageNum: number; contacts: Array<GmailContact> }>;
  displayPaginationNumbers: Array<number> = [];
  focusListId: boolean;
  gmailContactsSummary: Array<GmailContact> = [];
  language: string;
  languagesList: Array<DropDownItem> = [];
  listId: number;
  markAsCMSFailed: Array<string> = [];
  markAsPersonalFailed: Array<string> = [];
  pageDim: boolean;
  pageSummary: Array<GmailContact> = [];
  persona: string;
  personaDetails: Array<Persona> = [];
  personalDialog: boolean;
  searchQuery: string;
  selectAll: boolean;
  selectedContactsCount: number;
  selectedContactsList: Array<GmailContact> = [];
  selectedCreateContact: GmailContact;
  selectedPage: number;
  showSpinner: boolean;
  singleCreateContactDialog: boolean;
  toggleFilter: (e?) => void;
  totalContactsSummary: Array<GmailContact> = [];
  totalPages: number;
  user: { email_address: string };

  constructor(private injector: Injector) {
    this._window = window;

    this.createContactDialog = false;
    this.listId = null;
    this.pageDim = false;
    this.personalDialog = false;
    this.searchQuery = '';
    this.selectAll = false;
    this.selectedContactsCount = 0;
    this.showSpinner = false;
    this.singleCreateContactDialog = false;
    this.toggleFilter = this._appService.toggleFilter();
    this.user = null;
    this.setFocus();
  }

  ngOnInit(): void {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this._appService.scrollTop();
        this.showSpinner = true;
        this.loadDetails();
      }
    });
  }

  createContact(contact, isMultiple?): void {
    const reqObj = this.getCreateContactRequestObj(contact);
    this.pageDim = true;
    this._gmailContactsService.createContact(reqObj)
      .then((response) => {
        this.notifySingleContact(contact, response, isMultiple);
      }).catch((error) => {
        this.notifySingleContact(contact, error, isMultiple);
      }).finally(() => {
        this.singleCreateContactDialog = false;
        this.createContactDialog = false;
        this.pageDim = false;
      });
  }

  createContactForSelected(): void {
    this.contactsFailed = [];
    this.markAsCMSFailed = [];
    if (this.validateCreateContact()) {
      this.removeFocus();
      return;
    }
    this.selectedContactsCount = this.selectedContactsList.length;
    this.selectedContactsList.forEach((selected) => {
      const contact = selected;
      contact.list_id = this.listId;
      contact.persona = this.persona;
      contact.country = this.country;
      contact.language = this.language;
      this.createContact(contact, true);
    });
  }

  filterSearch(): void {
    this.showSpinner = true;
    if (this.searchQuery) {
      this.totalContactsSummary = this._filter.transform(this.completeSummary, this.searchQuery, '');
    } else {
      this.totalContactsSummary = this.completeSummary;
    }
    this.formatSummaryDetails();
  }

  formatSummaryDetails(): void {
    // Display 100 records per page
    let first = 0;
    let last = 100;
    this.getPaginationNumbers();
    for (let i = 1; i <= this.totalPages; i++) {
      this.displayContactsSummary.push({
        pageNum: i,
        contacts: this.totalContactsSummary.slice(first, last)
      });
      first = last;
      last += 100;
    }
    const index = this.displayContactsSummary.findIndex((contact) => contact.pageNum === this.selectedPage);
    if (index !== -1) {
      this.pageSummary = this.displayContactsSummary[index].contacts;
    }
    this.showSpinner = false;
  }

  getCreateContactRequestObj(contact): CreateContact {
    const reqObj = {
      list_id: contact.list_id,
      owner_email: this.user.email_address,
      props: {
        country: contact.country,
        email: contact.email,
        firstname: contact.names.display_name,
        hs_language: contact.language,
        hs_persona: contact.persona
      },
      etag: contact.etag,
      memberships: contact.memberships || [],
      resource_name: contact.resource_name
    };
    return reqObj;
  }

  getCountriesList(): void {
    this.allCountriesList = [
      { key: 'IT', label: 'Italy' },
      { key: 'DE', label: 'Germany' },
      { key: 'FR', label: 'France' },
      { key: 'NL', label: 'Netherlands' },
      { key: 'BE_FR', label: 'Belgium (FR)' },
      { key: 'BE_NL', label: 'Belgium (NL)' },
      { key: 'GB', label: 'United Kingdom' },
      { key: 'VF', label: 'Villa Fortuna' },
      { key: 'FC', label: 'Fondazione Capellino' },
      { key: 'EN', label: 'USA' },
      { key: 'CA', label: 'Canada' },
      { key: 'FI', label: 'Finland' },
      { key: 'ES', label: 'Spain' },
      { key: 'CH', label: 'Swiss' },
      { key: 'SV', label: 'Sweden' }
    ];
  }

  getDisplayContactsSummary(): void {
    // If the selected page is >=6 get previous 6 and next 4 numbers of selected page for pagination display
    const prev = this.allPaginationNumbers.slice(this.selectedPage >= 6 ?
      this.selectedPage - 6 : 0, this.selectedPage);
    const next = this.allPaginationNumbers.slice(this.selectedPage,
      this.selectedPage >= 6 ? this.selectedPage + 4 : 10);
    this.displayPaginationNumbers = [...prev, ...next];
    const index = this.displayContactsSummary.findIndex((contact) => contact.pageNum === this.selectedPage);
    if (index !== -1) {
      this.pageSummary = this.displayContactsSummary[index].contacts;
    }
    this.showSpinner = false;
  }

  getLanguagesList(): void {
    this.languagesList = [
      { key: 'en', label: 'English' },
      { key: 'it', label: 'Italian' },
      { key: 'de', label: 'German' },
      { key: 'fr', label: 'French' },
      { key: 'nl', label: 'Dutch' }
    ];
  }

  getPaginationNumbers(): void {
    this.selectedPage = 1;
    this.displayContactsSummary = [];
    this.pageSummary = [];
    this.totalPages = Math.ceil(this.totalContactsSummary.length / 100);
    this.allPaginationNumbers = [];
    for (let i = 1; i <= this.totalPages; i++) {
      this.allPaginationNumbers.push(i);
    }
    this.displayPaginationNumbers = this.allPaginationNumbers.slice(0, 10);
  }

  getPersonalRequestObj(contact, groupName): MarkPersonal {
    const reqObj = {
      etag: contact.etag,
      email: this.user.email_address,
      resource_name: contact.resource_name,
      group_name: groupName,
      memberships: contact.memberships || []
    };
    return reqObj;
  }

  goToPage(event, direction, num?): void {
    this.showSpinner = true;
    if ((direction === 'prev' && this.selectedPage === 1) ||
      (direction === 'next' && this.selectedPage === this.totalPages)) {
      event.stopPropagation();
      return;
    }
    if (direction === 'prev' && this.selectedPage > 1) {
      this.selectedPage -= 1;
    } else if (direction === 'next' && this.selectedPage < this.totalPages) {
      this.selectedPage += 1;
    } else {
      this.selectedPage = num;
    }
    this.getDisplayContactsSummary();
  }

  loadContactsList(): Promise<void> {
    this.showSpinner = true;
    return new Promise((resolve) => {
      this._gmailContactsService.loadContactsList()
        .then((response) => {
          this.contactList = response;
          this.contactList = this._orderBy.transform(this.contactList, 'name', false);
        }).catch((error) => {
          this._appService.notify(error);
        });
      resolve();
    });
  }

  loadDetails(): void {
    this.getCountriesList();
    this.getLanguagesList();
    this.loadPersonaDetails();
    if (this._cacheService.gmailContactsDetails && this._cacheService.gmailContactsDetails.length) {
      this.loadContactsList();
      this._cacheService.gmailContactsDetails.forEach((contact) => {
        GmailContactsMigrationComponent.resetData(contact);
      });
      this.totalContactsSummary = this._cacheService.gmailContactsDetails;
      this.completeSummary = this._cacheService.gmailContactsDetails;
      this.formatSummaryDetails();
    } else {
      this.loadGmailContactsSummary();
    }
  }

  async loadGmailContactsSummary(): Promise<any> {
    const reqObj = { email: this.user.email_address };
    await this.loadContactsList();
    this._gmailContactsService.loadGmailContactsSummary(reqObj)
      .then((response) => {
        this.gmailContactsSummary = response;
      }).catch((error) => {
        this._appService.notify(error);
      }).finally(() => {
        this.parseGmailContacts();
      });
  }

  loadPersonaDetails(): void {
    this.showSpinner = true;
    this._privacyConsentService.loadPersonaDetails((data) => {
      this.showSpinner = false;
      this.personaDetails = data;
      this.personaDetails = this._orderBy.transform(this.personaDetails, 'label', false);
    });
  }

  markAsCMS(contact, isMultiple?): void {
    const reqObj = this.getPersonalRequestObj(contact, 'CMS');
    this.pageDim = true;
    this._gmailContactsService.markAsPersonal(reqObj)
      .then((response) => {
        this.notifyCMSMsg(contact, response, isMultiple);
      }).catch((error) => {
        this.notifyCMSMsg(contact, error, isMultiple);
      }).finally(() => {
        this.selectedContactsCount -= 1;
        if (this.selectedContactsCount === 0 && isMultiple) {
          this.notifyMsg();
        }
        this.pageDim = false;
      });
  }

  markAsPersonal(): void {
    let count = this.selectedContactsList.length;
    this.selectedContactsList.forEach((contact) => {
      const reqObj = this.getPersonalRequestObj(contact, 'Personal');
      this.pageDim = true;
      this._gmailContactsService.markAsPersonal(reqObj)
        .then((response) => {
          this.removeDataFromCache(contact);
        }).catch((error) => {
          this.markAsPersonalFailed.push(contact.email);
        }).finally(() => {
          count -= 1;
          if (count === 0) {
            this.notifyPersonalMsg();
          }
          this.personalDialog = false;
          this.pageDim = false;
        });
    });
  }

  notifyCMSMsg(contact, response, isMultiple): void {
    if (!isMultiple) {
      this._appService.notify(response);
    }
    if (response.status === 0) {
      this.removeDataFromCache(contact);
    } else {
      this.markAsCMSFailed.push(contact.email);
    }
  }

  notifyMsg(): void {
    let contactGmailList = '';
    this.contactsFailed.forEach((email) => {
      contactGmailList = `${contactGmailList} ,${email}`;
    });
    const contactStatus = !this.contactsFailed.length ? 0 : 1;
    const contactMsg = !this.contactsFailed.length ? 'Contacts created and added to list successfully' :
      `Failed to create contacts for ${contactGmailList.slice(0, -2)}`;
    this._appService.notify({ status: contactStatus, msg: contactMsg });

    let markCMSList = '';
    this.markAsCMSFailed.forEach((email) => {
      markCMSList = `${markCMSList} ,${email}`;
    });
    const cmsStatus = !this.markAsCMSFailed.length ? 0 : 1;
    const cmsMsg = !this.markAsCMSFailed.length ? 'Contact label added successfully' :
      `Failed to add contact label for ${markCMSList.slice(0, -2)}`;
    this._appService.notify({ status: cmsStatus, msg: cmsMsg });
  }

  notifyPersonalMsg(): void {
    this.markAsPersonalFailed = [];
    this.markAsPersonal();
    let gmailList = '';
    this.markAsPersonalFailed.forEach((email) => {
      gmailList = `${gmailList} ,${email}`;
    });
    const status = !this.markAsPersonalFailed.length ? 0 : 1;
    const msg = !this.markAsPersonalFailed.length ? 'Contacts marked as Personal' :
      `Failed to mark these contacts as Personal:  ${gmailList.slice(0, -2)}`;
    this._appService.notify({ status, msg });
  }

  notifySingleContact(contact, response, isMultiple): void {
    if (!isMultiple) {
      this._appService.notify(response);
    }
    if (response.status === 0) {
      this.markAsCMS(contact, isMultiple);
    } else {
      this.contactsFailed.push(contact.email);
    }
  }

  onContactSelection(contact): void {
    if (contact.isChecked) {
      this.selectedContactsList.push(contact);
    } else {
      this.selectedContactsList.splice(contact, 1);
    }
  }

  openMultiCreateContactDialog(): void {
    this.createContactDialog = true;
    this.setFocus();
    this.listId = null;
    this.persona = '';
    this.country = '';
    this.language = '';
  }

  openSingleCreateContactDialog(contact): void {
    if (this.validateSingleCreateContact(contact)) {
      return;
    }
    this.singleCreateContactDialog = true;
    this.selectedCreateContact = contact;
  }

  parseGmailContacts(): void {
    this.gmailContactsSummary.forEach((contact) => {
      contact.emails.forEach((email) => {
        this.totalContactsSummary.push({
          photo: contact.photo,
          etag: contact.etag,
          email,
          resource_name: contact.resource_name,
          display_name: contact.names.display_name,
          names: contact.names,
          list_id: null,
          persona: '',
          country: '',
          language: ''
        });
      });
    });
    this.pushData();
    this.formatSummaryDetails();
  }

  pushData(): void {
    this._cacheService.gmailContactsDetails = [...this.totalContactsSummary];
    this.completeSummary = [...this.totalContactsSummary];
  }

  removeDataFromCache(contact): void {
    const addedContact = contact;
    addedContact.isChecked = false;
    let index = this.selectedContactsList.findIndex((allContact) => allContact.email === addedContact.email);
    if (index !== -1) {
      this.selectedContactsList.splice(index, 1);
    }
    index = this.completeSummary.findIndex((allContact) => allContact.email === addedContact.email);
    if (index !== -1) {
      this.completeSummary.splice(index, 1);
    }
    this._cacheService.gmailContactsDetails = [...this.completeSummary];
    this.totalContactsSummary = [...this.completeSummary];
    this.filterSearch();
  }

  removeFocus(): void {
    this.focusListId = false;
  }

  static resetData(contact): void {
    const details = contact;
    details.isChecked = false;
    details.list_id = null;
    details.persona = '';
    details.country = '';
    details.language = '';
  }

  selectAllContacts(): void {
    this.pageSummary.forEach((contact) => {
      const contactDetails = contact;
      contactDetails.isChecked = this.selectAll;
    });
    this.selectedContactsList = this.pageSummary.filter((contact) => contact.isChecked);
  }

  setFocus(): void {
    this.focusListId = true;
  }

  validateCreateContact(): boolean {
    this.setFocus();
    return this.focusListId && !this.listId;
  }

  validateSingleCreateContact(contact): boolean {
    if (!contact.list_id) {
      const msg = 'Please select contact list to create contact';
      this._appService.notify({ status: 1, msg });
      return true;
    }
    return false;
  }
}
