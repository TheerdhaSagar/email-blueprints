import { NgModule } from '@angular/core';

import { ContactsRoutingModule } from './contacts-routing.module';
import { ShareModule } from '../share/share.module';
import { GmailContactsMigrationComponent } from './contacts.component';

@NgModule({
  declarations: [GmailContactsMigrationComponent],
  imports: [
    ShareModule,
    ContactsRoutingModule
  ]
})
export class ContactsModule { }
