export interface HubspotContact {
  internal_list_id: number;
  list_id: number;
  name: string;
}
