export interface Persona {
  description: string;
  displayOrder: number;
  doubleData: string;
  hidden: boolean;
  label: string;
  readOnly: string;
  value: string;
}
