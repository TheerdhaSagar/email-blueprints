import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { DataService } from '../globals/data.service';
import { HttpService } from '../globals/http.service';
import { APIError } from '../globals/api.error';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  cardRows: any[];
  cards: any[];
  notificationCount: any;
  roles: any;
  user: any;
  windowWidth: any;

  constructor(
    appService: AppService,
    cacheService: CacheService,
    dataService: DataService,
    httpService: HttpService,
    location: Location,
    router: Router
  ) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.cards = [];
    this.roles = dataService.roles;
    this.user = null;
    this.windowWidth = dataService.windowWidth;
  }

  ngOnInit() {
    // google analytics code
    this._window.ga('send', 'pageview', { page: this._location.path() });

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;

        this.loadNotificationCount();
        this.setUpModules();
      }
    });
  }

  goToState(state, params?) {
    if (state) {
      if (state === 'ambassador') {
        if (this.roles.isAgent) {
          state = 'events/ambassador/summary';
        } else if (this.roles.isHostess) {
          state = 'events/hostess/report';
        }
      } else if (state === 'cruscott') {
        if (
          !this.roles.UIReportsLimitAccess &&
          ((this.roles.isOutofdoorManager && !this.roles.UIOutofdoorReports) ||
            this.roles.isCEO ||
            this.roles.isAdmin ||
            (this.roles.isManager && !this.roles.isOutofdoorManager))
        ) {
          state = 'reports/overview';
        } else {
          state = 'reports/dashboard';
        }
      } else if (state === 'useraccesscontrol') {
        if (
          this.roles.UIforLeavesApproval ||
          this.roles.UIAccessControlReportAll
        ) {
          state = 'useraccesscontrol/summary';
        } else {
          this._appService.accessControlReportId = this.user.user_id;
          this._appService.accessControlUserName = `${this.user.user_description.toLowerCase()}(${
            this.user.email_address
          })`;
          state = 'useraccesscontrol/detail';
        }
      }
      if (params) {
        this._router.navigate([state], { queryParams: params });
      } else {
        this._router.navigate([state]);
      }
    } else {
      this._window.open(
        'https://www.almonature.com/wp-content/uploads/2018/01/ALMO-NATURE-PROJECTS-2018-EN.pdf'
      );
    }
  }

  loadNotificationCount() {
    const endPoint = `/users/notifications/count/${this.user.user_id}/`;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({
          status: 1,
          msg: 'Server Error: loadNotificationCount()',
        });
      } else if (data.status === 1) {
        this._appService.notify(new APIError(data.msg));
      } else if (data && data.length > 0) {
        this.notificationCount = data[0].open_count;
      }
    });
  }

  setUpModules() {
    let reclaimsRoute;
    if (
      (!this.roles.isCEO &&
        !this.roles.isSupplier &&
        !this.roles.isHostess &&
        !this.roles.UIOutofdoorReports &&
        !this.roles.isGenericUser) ||
      this.roles.UIQuotes
    ) {
      this.cards.push({
        name: 'Quotes',
        state: 'quotes/summary',
        icon: 'quotes.png',
        key: 'KEY_QUOTES',
        title: 'KEY_QUOTES_TITLE',
      });
    }

    if (
      (((this.roles.isAdmin && !this.roles.isCEO) || this.roles.isManager) &&
        !this.roles.UIOutofdoorReports &&
        !this.roles.isGenericUser) ||
      this.roles.UICreditNotes
    ) {
      this.cards.push({
        name: 'Credit Notes',
        state: 'creditnotes/summary',
        icon: 'creditnotes.png',
        key: 'KEY_CREDITNOTES',
        title: 'KEY_CREDITNOTES_TITLE',
      });
    }

    if (
      !this.roles.isSupplier &&
      !this.roles.isHostess &&
      !this.roles.UIOutofdoorReports &&
      (!this.roles.isGenericUser ||
        (this.roles.isGenericUser && this.roles.UICruscott) ||
        (this.roles.isGenericUser && this.roles.UIWordPress))
    ) {
      this.cards.push({
        name: 'Cruscott',
        state: 'cruscott',
        icon: 'cruscott.png',
        key: 'KEY_CRUSCOTT',
        title: 'KEY_CRUSCOTT_TITLE',
      });
    }

    if (this.roles.isGenericUser && this.roles.UIOutofdoorReports) {
      this.cards.push({
        name: 'Cruscott',
        state: 'cruscott',
        icon: 'cruscott.png',
        key: 'KEY_CRUSCOTT',
        title: 'KEY_CRUSCOTT_TITLE',
      });
    }

    if (
      (!this.roles.isSupplier &&
        !this.roles.isHostess &&
        this.windowWidth <= 1024 &&
        !this.roles.UIOutofdoorReports &&
        (!this.roles.isGenericUser ||
          (this.roles.isGenericUser && this.roles.UICruscott))) ||
      this.roles.UICruscottReports
    ) {
      this.cards.push({
        name: 'Cruscott - Reports',
        state: 'reports/dashboard',
        icon: 'cruscott.png',
        key: 'KEY_CRUSCOTT_REPORTS',
        title: 'KEY_CRUSCOTT_TITLE',
      });
    }

    if (
      (!this.roles.isCEO &&
        !this.roles.isSupplier &&
        !this.roles.isHostess &&
        !this.roles.UIOutofdoorReports &&
        !this.roles.isGenericUser) ||
      this.roles.UIReports
    ) {
      this.cards.push({
        name: 'Sales Reports',
        state: 'reports/other',
        icon: 'sales_reports.png',
        key: 'KEY_SALESREPORTS',
        title: 'KEY_SALESREPORTS_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      (this.roles.hasEvents && !this.roles.isHostess)
    ) {
      this.cards.push({
        name: 'Event Management',
        state: 'events/dashboard',
        icon: 'event_management.png',
        key: 'KEY_EVENTMANAGEMENT',
        title: 'KEY_EVENTMANAGEMENT_TITLE',
      });
    }

    if (this.roles.hasEvents && this.roles.isHostess) {
      this.cards.push({
        name: 'Event Management',
        state: 'events/hostess/report',
        icon: 'event_management.png',
        key: 'KEY_EVENTMANAGEMENT',
        title: 'KEY_EVENTMANAGEMENT_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.isSupplier ||
      this.roles.UISupplier ||
      this.roles.isAgentSupplier
    ) {
      this.cards.push({
        name: 'Supplier',
        state: 'supplier/supplier-dashboard',
        icon: 'supplier.png',
        key: 'KEY_SUPPLIER',
        title: 'KEY_SUPPLIER_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIFinance) {
      this.cards.push({
        name: 'Financials',
        state: 'finance/dashboard',
        icon: 'financials.png',
        key: 'KEY_FINANCIALS',
        title: 'KEY_FINANCIALS_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIUserManagement
    ) {
      this.cards.push({
        name: 'User Management',
        state: 'usermanagement/users',
        icon: 'user_management.png',
        key: 'KEY_USERMANAGEMENT',
        title: 'KEY_USERMANAGEMENT_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIB2BUserManagement
    ) {
      this.cards.push({
        name: 'Agent & B2B User Management',
        state: 'usermanagement/dashboard',
        icon: 'user_management.png',
        key: 'KEY_B2BUSERMANAGEMENT',
        title: 'KEY_B2BUSERMANAGEMENT_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.hasExpenses) {
      const expensesRoute = this.roles.UIExpensesApprovalFlow
        ? 'expenses/dashboard'
        : 'expenses/summary';
      this.cards.push({
        name: 'Expenses',
        state: expensesRoute,
        icon: 'expenses.png',
        key: 'KEY_EXPENSES',
        title: 'KEY_EXPENSES_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.hasProcurement
    ) {
      this.cards.push({
        name: 'Procurement',
        state: 'procurement/dashboard',
        icon: 'procurement.png',
        key: 'KEY_PROCUREMENT',
        title: 'KEY_PROCUREMENT_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.hasOnboard) {
      this.cards.push({
        name: 'On Board',
        state: 'onboard/suppliers/invitations',
        icon: 'onboard.png',
        key: 'KEY_ONBOARD',
        title: 'KEY_ONBOARD_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.hasNotifications
    ) {
      this.cards.push({
        name: 'Notifications',
        state: 'notifications',
        icon: 'notifications.png',
        key: 'KEY_NOTIFICATIONS',
        title: 'KEY_NOTIFICATIONS_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIPayments) {
      this.cards.push({
        name: 'Payments',
        state: 'payments',
        icon: 'financials.png',
        key: 'KEY_PAYMENTS',
        title: 'KEY_PAYMENTS_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIObjectives) {
      this.cards.push({
        name: 'Objectives',
        state: 'objectives',
        icon: 'objectives.png',
        key: 'KEY_OBJECTIVES',
        title: 'KEY_OBJECTIVES_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIPurchasing) {
      this.cards.push({
        name: 'Purchasing',
        state: 'purchasing/dashboard',
        icon: 'purchase.png',
        key: 'KEY_FORECAST',
        title: 'KEY_FORECAST_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UISchedules) {
      this.cards.push({
        name: 'Schedules',
        state: 'schedules/summary',
        icon: 'schedules.png',
        key: 'KEY_SCHEDULES',
        title: 'KEY_SCHEDULES_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIStoreLocator
    ) {
      this.cards.push({
        name: 'Store Locator',
        state: 'storelocator/dashboard',
        icon: 'storelocator.png',
        key: 'KEY_STORELOCATOR',
        title: 'KEY_STORELOCATOR_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIWordPress) {
      this.cards.push({
        name: 'Website',
        state: 'website/dashboard',
        icon: 'website.png',
        key: 'KEY_WEBSITE',
        title: 'KEY_WEBSITE_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIDonationDesk
    ) {
      this.cards.push({
        name: 'Donation Desk',
        state: 'donation/dashboard',
        icon: 'donation.png',
        key: 'KEY_DONATION',
        title: 'KEY_DONATION_TITLE',
      });
    }

    if (this.roles.UIHumansAndWildLife) {
      this.cards.push({
        name: 'Humans & Wild Life',
        state: 'donation/dashboard',
        params: { project: 'humans-and-wild-life' },
        icon: 'hwl.png',
        key: 'KEY_HUMANS_AND_WILDLIFE',
        title: 'KEY_HUMANS_AND_WILDLIFE_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIProductOnboardVersion1
    ) {
      this.cards.push({
        name: 'Product OnBoard V1',
        state: 'products/v1',
        icon: 'document.png',
        key: 'KEY_PRODUCT_ONBOARD_VERSION1',
        title: 'KEY_PRODUCT_ONBOARD_TITLE_VERSION1',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIProductOnboardHubspot
    ) {
      this._cacheService.pobFilters = [];
      this.cards.push({
        name: 'POB',
        state: 'pob/summary',
        icon: 'pob.png',
        key: 'KEY_POB',
        title: 'KEY_POB',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.isManager ||
      this.roles.isAgent
    ) {
      this.cards.push({
        name: 'Product Catalogue',
        state: 'product-catalogue',
        icon: 'product_catalogue.png',
        key: 'KEY_PRODUCT_CATALOGUE',
        title: 'KEY_PRODUCT_CATALOGUE_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.isPMBBudget) {
      this.cards.push({
        name: 'PMB Budget',
        state: 'budget/dashboard',
        icon: 'budget.png',
        key: 'KEY_PMB_BUDGET',
        title: 'KEY_PMB_BUDGET_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIforHCM) {
      this.cards.push({
        name: 'HCM',
        state: 'hcm/dashboard',
        icon: 'event_management.png',
        key: 'HCM',
        title: 'Apply & Manage leaves / holidays',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UICoupons ||
      this.roles.isB2b
    ) {
      this.cards.push({
        name: 'Coupons',
        state: 'coupons/summary',
        icon: 'coupons.png',
        key: 'KEY_COUPONS',
        title: 'KEY_COUPONS_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UITripPlanner) {
      this.cards.push({
        name: 'Activity Planner',
        state: 'activity-planner',
        icon: 'projects.png',
        key: 'KEY_TRIP_PLANNER',
        title: 'KEY_TRIP_PLANNER_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIAssetManagement
    ) {
      this.cards.push({
        name: 'Asset Management',
        state: 'asset-management/summary',
        icon: 'asset_management.png',
        key: 'KEY_ASSET_MANAGEMENT',
        title: 'KEY_ASSET_MANAGEMENT_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIAccessControlReport
    ) {
      this.cards.push({
        name: 'Access Control Report',
        state: 'useraccesscontrol',
        icon: 'access_control_report.png',
        key: 'KEY_USER_CONTROL',
        title: 'KEY_USER_CONTROL_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIPrivacyConsent
    ) {
      this.cards.push({
        name: 'Privacy Consent',
        state: 'privacyconsent/summary',
        icon: 'privacy_consent.png',
        key: 'KEY_PRIVACY_CONSENT',
        title: 'KEY_PRIVACY_CONSENT_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UICustomerClaim ||
      this.roles.UISupplierClaim
    ) {
      // if user has only customer claim role navigate to customer claim summary
      if (
        !this.roles.isAdmin &&
        this.roles.UICustomerClaim &&
        !this.roles.UISupplierClaim
      ) {
        reclaimsRoute = '/reclaims/customer/summary';
      } else if (
        !this.roles.isAdmin &&
        this.roles.UISupplierClaim &&
        !this.roles.UICustomerClaim
      ) {
        // if user has only supplier role navigate to supplier claim summary
        reclaimsRoute = '/reclaims/supplier/summary';
      } else {
        // If user is admin or has both roles show reclaims dashboard
        reclaimsRoute = '/reclaims/dashboard';
      }
      this.cards.push({
        name: 'Reclaims',
        state: reclaimsRoute,
        icon: 'reclaims.png',
        key: 'KEY_RECLAIMS',
        title: 'KEY_RECLAIMS_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIProofOfDelivery
    ) {
      this.cards.push({
        name: 'POD',
        state: 'pod/summary',
        icon: 'pod_icon.png',
        key: 'KEY_POD',
        title: 'KEY_POD_TITLE',
      });
    }

    if (this.roles.UIGmailSignature) {
      this.cards.push({
        name: 'Gmail Signature',
        state: 'gmail/signature',
        icon: 'signature.png',
        key: 'KEY_GMAIL_SIG',
        title: 'KEY_GMAIL_SIG_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIWorkflows) {
      this.cards.push({
        name: 'Workflows',
        state: 'workflows/dashboard',
        icon: 'workflows.png',
        key: 'KEY_WORKFLOWS',
        title: 'KEY_WORKFLOWS_TITLE',
      });

      if (this.roles.UIHumansAndWildLifeNew) {
        this.cards.push({
          name: 'Humans & Wild Life',
          state: 'humans-and-wild-life/dashboard',
          icon: 'hwl.png',
          key: 'KEY_HUMANS_AND_WILDLIFE',
          title: 'KEY_HUMANS_AND_WILDLIFE_TITLE',
        });
      }
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UISalesCalendar
    ) {
      this.cards.push({
        name: 'Communications Calendar',
        state: 'sales-calendar',
        icon: 'sales-calendar.png',
        key: 'KEY_SALES_CALENDAR',
        title: 'KEY_SALES_CALENDAR_TITLE',
      });
    }

    if (this.roles.UIProductCalendar) {
      this.cards.push({
        name: 'Product Calendar',
        state: 'products-calendar',
        icon: 'product-calendar.png',
        key: 'KEY_PRODUCT_CALENDAR',
        title: 'KEY_PRODUCT_CALENDAR_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIGmailContactsMigration
    ) {
      this.cards.push({
        name: 'Contacts Migration',
        state: 'contacts',
        icon: 'contacts-migration.png',
        key: 'KEY_GMAIL_CONTACTS',
        title: 'KEY_GMAIL_CONTACTS_TITLE',
      });
    }

    if (this.roles.UISalesCalendarCommon) {
      this.cards.push({
        name: 'Foundation Calendar',
        state: 'sales-calendar',
        params: { calendarType: 'common' },
        icon: 'sales-calendar.png',
        key: 'KEY_COMMON_SALES_CALENDAR',
        title: 'KEY_COMMON_SALES_CALENDAR_TITLE',
      });
    }

    if (
      (this.roles.isAdmin && !this.roles.isCEO) ||
      this.roles.UIAgentTargets
    ) {
      this.cards.push({
        name: 'Agent Targets',
        state: 'agent-targets',
        icon: 'budget.png',
        key: 'KEY_AGENT_TARGETS',
        title: 'KEY_AGENT_TARGETS_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UICampaigns) {
      this.cards.push({
        name: 'Campaigns',
        state: 'campaigns',
        icon: 'campaign.png',
        key: 'KEY_CAMPAIGNS',
        title: 'KEY_CAMPAIGNS_TITLE',
      });
    }

    if (this.roles.UIDSV) {
      this.cards.push({
        name: 'DSV',
        state: 'dsv/dashboard',
        icon: 'dsv.png',
        key: 'KEY_DSV',
        title: 'KEY_DSV_TITLE',
      });
    }

    if (this.roles.UIRVFInventory) {
      this.cards.push({
        name: 'RVF - Inventory',
        state: 'rvf',
        icon: 'RVF.png',
        key: 'KEY_RVF',
        title: 'KEY_RVF_TITLE',
      });
    }

    if ((this.roles.isAdmin && !this.roles.isCEO) || this.roles.UIPromotions) {
      this.cards.push({
        name: 'Promotions',
        state: 'promotions/summary',
        icon: 'promotions-icon.png',
        key: 'KEY_PROMOTIONS',
        title: 'KEY_PROMOTIONS_TITLE',
      });
    }

    if (this.roles.UIGLJournal) {
      this.cards.push({
        name: 'GL Journal',
        state: 'gl',
        icon: 'general_ledger_1.png',
        key: 'KEY_GL_JOURNAL',
        title: 'KEY_GL_JOURNAL_TITLE',
      });
    }

    if (this.roles.UIContactReasons) {
      this.cards.push({
        name: 'Contact Reasons',
        state: 'reasons',
        icon: 'contact-reasons.png',
        key: 'KEY_CONTACT_REASON',
        title: 'KEY_CONTACT_REASON_TITLE',
      });
    }
    const cardRows = [];
    let row = [];
    for (let i = 0; i < this.cards.length; i++) {
      if (i > 0 && i % 4 === 0) {
        cardRows.push(row);
        row = [];
      }
      row.push(this.cards[i]);
    }
    if (row && row.length > 0) {
      cardRows.push(row);
    }

    this.cardRows = cardRows;
  }
}
