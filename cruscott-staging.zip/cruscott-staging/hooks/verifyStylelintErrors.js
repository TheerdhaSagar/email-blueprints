const { exec } = require('child_process');
const { MAXIMUM_ALLOWED_STYLE_ERRORS_COUNT } = require('./constants');
const { logError, logInfo } = require('./logger');

function verifyStylelintErrors() {
  exec('npm run stylelint-on-commit', { maxBuffer: 1024 * 7024 }, (err, stdout, stderr) => {
    const problems = stdout.trim().match(/(\d+) problems/);
    if (problems) {
      const numberOfProblems = +stdout.trim().match(/(\d+) problems/)[1];
      if (numberOfProblems > MAXIMUM_ALLOWED_STYLE_ERRORS_COUNT) {
        let message = `Number of stylelint errors count exceeds pre-defined limit: ${MAXIMUM_ALLOWED_STYLE_ERRORS_COUNT}`;
        message += `\nNumber of errors reported by stylelint: ${numberOfProblems}.`;
        logError(message);
        process.exit(1);
      }
      const message = `\nNumber of errors reported by stylelint: ${numberOfProblems}.`;
      logInfo(message);
    }
  });
}
exports.verifyStylelintErrors = verifyStylelintErrors;
