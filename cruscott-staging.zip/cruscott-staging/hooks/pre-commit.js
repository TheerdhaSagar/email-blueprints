const { verifyTSLintErrors } = require('./verifyTSLintErrors');
const { verifyESLintErrors } = require('./verifyESLintErrors');
const { verifyStylelintErrors } = require('./verifyStylelintErrors');

verifyStylelintErrors();
verifyTSLintErrors();
verifyESLintErrors();
