const { exec } = require('child_process');
const { MAXIMUM_ALLOWED_ESLINT_ERRORS_COUNT } = require('./constants');
const { logError, logInfo } = require('./logger');

function verifyESLintErrors() {
  exec('npm run lint-on-commit', { maxBuffer: 1024 * 9024 }, (err, stdout, stderr) => {
    const problems = stdout.trim().match(/(\d+) problems/);
    if (problems) {
      const numberOfProblems = +stdout.trim().match(/(\d+) problems/)[1];
      if (numberOfProblems > MAXIMUM_ALLOWED_ESLINT_ERRORS_COUNT) {
        let message = `Number of eslint errors count exceeds pre-defined limit: ${MAXIMUM_ALLOWED_ESLINT_ERRORS_COUNT}`;
        message += `\nNumber of errors reported by eslint: ${numberOfProblems}.`;
        logError(message);
        process.exit(1);
      }
      const message = `\nNumber of errors reported by eslint: ${numberOfProblems}.`;
      logInfo(message);
    }
  });
}
exports.verifyESLintErrors = verifyESLintErrors;
