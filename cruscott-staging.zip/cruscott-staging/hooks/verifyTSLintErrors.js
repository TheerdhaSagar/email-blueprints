const { exec } = require('child_process');
const { logError, logInfo } = require('./logger');
const { MAXIMUM_ALLOWED_TSLINT_ERRORS_COUNT } = require('./constants');

function verifyTSLintErrors() {
  exec('npm run tslint', { maxBuffer: 1024 * 7024 }, (err, stdout, stderr) => {
    const numberOfProblems = (stdout.match(/ERROR:/g) || []).length;
    if (numberOfProblems > MAXIMUM_ALLOWED_TSLINT_ERRORS_COUNT) {
      let message = `Number of tslint errors count exceeds pre-defined limit: ${MAXIMUM_ALLOWED_TSLINT_ERRORS_COUNT}`;
      message += `\nNumber of errors reported by tslint: ${numberOfProblems}.`;
      logError(message);
      process.exit(1);
    }
    const message = `\nNumber of errors reported by tslint: ${numberOfProblems}.`;
    logInfo(message);
  });
}
exports.verifyTSLintErrors = verifyTSLintErrors;
