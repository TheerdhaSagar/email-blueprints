const chalk = require('chalk');

function logError(message) {
  console.log(chalk.red.bold(message));
}

function logInfo(message) {
  console.log(chalk.blue.bold(message));
}

exports.logError = logError;
exports.logInfo = logInfo;
