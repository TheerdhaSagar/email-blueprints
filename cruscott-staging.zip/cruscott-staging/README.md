# Cruscott

### Configuring Project

Clone the project in a new directory don't just switch between branchs that doens't work since the `node_modules` is different for both AngularJS and Angular

You need to have node version `10.16.0 ( tested )` to run the project, since there is a different version requirements for our differrent projects 
you can install nvm (node version manager) to easily manage and switch between different versions of **node** and **npm**

*Installation instructions can be found at the below link*

https://github.com/nvm-sh/nvm#installation-and-update

Once the correct version of node is installed run

`npm install`

to install the dependencies

If everything goes well, you should be able to run the project by typing

`npm start`

### Creating new components/services

Use Angular CLI to generate components or services

**To generate Component**

`ng g c <component-name>`

**To generate Service**

`ng g s <service-name>`

This will automatically add necessary imports and declarations in `app-module.ts`