import os
import yaml


def get_sql(filename):
    path = os.path.dirname(__file__) + '/queries/'
    fn = os.path.join(path, filename + '.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return sql_file

def get_translation_sql(filename):
    path = os.path.dirname(__file__) + '/translations/'
    fn = os.path.join(path, filename.lower() + '.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return sql_file
