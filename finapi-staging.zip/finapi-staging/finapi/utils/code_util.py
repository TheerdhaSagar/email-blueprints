from finapi.utils.logdata import logger
from finapi.models.login.login import Login
from finapi.utils import db_util
import tempfile
import os
import ujson
import base64
import ntpath
import cx_Oracle
from flask import Response


class Code_util:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_usertype(puserid):
        logger.addinfo('@ utils - codeutil - get_usertype(+)')
        login_data = Login.get_user_preferences(puserid)
        login_vals = ujson.dumps(login_data)
        login_dict = ujson.loads(login_vals)
        userdetails = {}
        if login_dict["cust_acc_id"]:
            userdetails['type'] = 'b2b'
            userdetails['refid'] = login_dict["cust_acc_id"]
        elif login_dict["salesrep_id"] and login_dict[
                "salesrep_id"] != "ALL":
            userdetails['type'] = 'salesrep'
            userdetails['refid'] = login_dict["salesrep_id"]
        elif login_dict["user_id"] and not login_dict[
                "salesrep_id"] and not login_dict["cust_acc_id"]:
            userdetails['type'] = 'manager'
            userdetails['refid'] = login_dict["user_id"]
        else:
            userdetails['type'] = 'admin'
            userdetails['refid'] = ""
        logger.addinfo('@ utils - codeutil - get_usertype(-)')
        return userdetails

    @staticmethod
    def get_fieldtype(fieldnames, field_type):
        logger.addinfo('@ utils - codeutil - get_fieldtype(+)')
        fieldtypes = ""
        my_util = {}
        for index, fn in enumerate(fieldnames):
            type_str = str(field_type[index])
            for ch in ['cx_Oracle', '.', '<', '>', '\'', 'type']:
                if ch in type_str:
                    type_str = type_str.replace(ch, "")
            type_str = type_str.strip()
            my_util[fn] = type_str
            fieldtypes = my_util
        logger.addinfo('@ utils - codeutil - get_fieldtype(-)')
        return fieldtypes

    @staticmethod
    def get_saleschanel(p_userid, p_org):
        logger.addinfo('@ utils - codeutil - get_saleschanel(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            saleschannel_list = []
            query = sql_file['saleschannel_userid']
            cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            cur.execute(query, p_org_id=p_org)
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                sales_chanel = {}
                for index, fn in enumerate(field_names):
                    sales_chanel[fn] = row[index]
                saleschannel_list.append(sales_chanel)
        except Exception as error:
            logger.findaylog("""@ 77 EXCEPTION - utils - codeutil -
                 get_saleschanel """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ utils - codeutil - get_saleschanel(-)')
        return saleschannel_list

    @staticmethod
    def tmpfile_creation(pbase64):
        dir_name = '/home/finuser/finapi/dist/cdn'
        filelist = [f for f in os.listdir(dir_name) if f.endswith(".pdf")]
        for f in filelist:
            file = dir_name+'/'+f
            os.remove(file)
        tmpfile = tempfile.NamedTemporaryFile(dir=dir_name,
                                              suffix=".pdf", delete=False)
        fh = open(tmpfile.name, "wb")
        fh.write(base64.b64decode(pbase64))
        fh.close()
        os.chmod(tmpfile.name, 0o644)
        return ntpath.basename(tmpfile.name)

    @staticmethod
    def iterate_data(cursor, convert_data=False, is_json_check=False):
        field_names = [a[0].lower() for a in cursor.description]
        data = []
        for row in cursor:
            obj = {}
            for i in range(len(field_names)):
                if type(row[i]) == cx_Oracle.Cursor:
                    obj[field_names[i]] = Code_util.iterate_data(row[i])
                elif type(row[i]) == cx_Oracle.BLOB or \
                        type(row[i]) == cx_Oracle.LOB:
                    try:
                        obj[field_names[i]] = Code_util.is_base64(row[i].read()).decode('utf-8')
                    except:
                        obj[field_names[i]] = Code_util.is_base64(row[i].read())
                else:
                    obj[field_names[i]] = Code_util.is_json(row[i]) if is_json_check else row[i]
            data.append(obj)
        return Code_util.convert_to_unicode(data) if convert_data else data

    @staticmethod
    def convert_to_unicode(oracle_data):
        for i in range(len(oracle_data)):
            for key, value in oracle_data[i].items():
                if isinstance(value, str):
                    try:
                        oracle_data[i][key] = value
                    except:
                        oracle_data[i][key] = value
                elif isinstance(value, bytes):
                    oracle_data[i][key] = value.decode('utf-8', 'ignore')
                elif isinstance(value, list):
                    oracle_data[i][key] = Code_util.convert_to_unicode(value)
        return oracle_data

    @staticmethod
    def is_base64(data):
        try:
            ujson.dumps(data)
        except:
            return base64.b64encode(data)
        return data

    @staticmethod
    def is_json(json_str):
        try:
            json_object = ujson.loads(json_str)
        except Exception:
            return json_str
        return json_object

    @staticmethod
    def pass_error(e):
        final = dict()
        final['msg'] = e.message
        final['status'] = 1
        return Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
