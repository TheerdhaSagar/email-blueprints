import functools
import os
import types
from . import db_util
import ujson
from mailjet_rest import Client
from flask import g, request
from finapi.utils.logdata import logger


class LogUtil:

    def __init__(self):
        pass

    @staticmethod
    def send_log(err):
        try:
            api_key = os.environ['MJ_APIKEY_PUBLIC']
            api_secret = os.environ['MJ_APIKEY_PRIVATE']
            mailjet = Client(auth=(api_key, api_secret))
            strings = db_util.get_strings()
            try:
                user = g.username.lower()
            except Exception:
                user = 'no_user'
            sub = 'Issue: {0} in module {1} for user {2}'
            sub = sub.format(err.get('source', ''), err.get('module', ''),
                             user)
            data = {
                'FromEmail': strings['sender_email'],
                'FromName': strings['sender_name'],
                'Subject': sub,
                'MJ-TemplateID': 245644,
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': 'saikrishna@finday.com',
                'Vars': {
                    'source': err.get('source', ''),
                    'module': err.get('module', ''),
                    'function': err.get('function', ''),
                    'user': user,
                    'error_msg': err.get('error_msg', ''),
                    'input_data': ujson.dumps(err.get('input_data', ''))
                },
                'To': 'engineers@finday.com'
            }
            mailjet.send.create(data=data)
        except Exception as e:
            logger.findaylog("EXCEPTION while sending log => " + str(e))

    @staticmethod
    def before_request(func):
        @functools.wraps(func)
        def wrapper():
            logger.addinfo('@ [{0}] views - {1}(+)'.format(request.method, request.endpoint))
            func()

        return wrapper

    @staticmethod
    def after_request(func):
        @functools.wraps(func)
        def wrapper(response):
            logger.addinfo('@ [{0}] views - {1}(-)'.format(request.method, request.endpoint))
            return response

        return wrapper

    @staticmethod
    def class_module_logs(module_name):
        def class_decorator(cls):
            for name, member in list(vars(cls).items()):
                # function that are defined with object of a class are verified here
                if isinstance(member, (types.FunctionType, types.BuiltinFunctionType)):
                    setattr(cls, name, LogUtil.func_logs(module_name, member))

                # Static and class methods
                if isinstance(member, (classmethod, staticmethod)):
                    # getting the function details
                    inner_func = member.__func__
                    # check the type of the function static or class method
                    method_type = type(member)
                    # apply the method type before calling the function
                    decorated = method_type(LogUtil.func_logs(module_name, inner_func))
                    setattr(cls, name, decorated)
            return cls
        return class_decorator

    @staticmethod
    def func_logs(module_name, func):
        @functools.wraps(func)
        def wrapper(*args, **kw):
            logger.addinfo('@ models - {0} - {1}(+)'.format(module_name, func.__name__))
            try:
                res = func(*args, **kw)
            except Exception as error:
                message = '@ EXCEPTION models - {0} - {1}, {2}' \
                    .format(module_name, func.__name__, str(error))
                logger.findaylog(message)
                raise error
            finally:
                logger.addinfo('@ models - {0} - {1}(+)'.format(module_name, func.__name__))
            return res
        return wrapper
