from apiclient.discovery import build
from google.oauth2 import service_account
import datetime
import os
from finapi.utils.logdata import logger
from finapi.utils.common_utils import CommonUtils

dateformat = '%d-%b-%Y'


class GoogleUtils:
    def __init__(self):
        self.account_token = os.environ['GOOGLE_CAL_TOKEN']
        self.scopes = ['https://www.googleapis.com/auth/calendar',
                       'https://www.googleapis.com/auth/calendar.events']

    def get_credentials(self):
        return service_account.Credentials.from_service_account_file(
            self.account_token, scopes=self.scopes)

    def delegate_account(self, account):
        credentials = self.get_credentials()
        return credentials.with_subject(account)

    @staticmethod
    def get_api(api, version, credentials):
        service = build(api, version, credentials=credentials)
        return service

    @staticmethod
    def get_calendars_list(service, calendar_name):
        """
            This method will get list of all Calendars for a specific user
            and returns Calendar_id if expected calendar_name exists in the list, else it returns false

            if requirement is to add event to default calendar then use primary keyword
        """
        try:
            logger.addinfo('@ Google Utils - get_calendars_list(+)')
            page_token = None
            while True:
                calendar_list = service.calendarList().list(pageToken=page_token).execute()
                for calendar_list_entry in calendar_list['items']:
                    if calendar_list_entry['summary'] == calendar_name:
                        return calendar_list_entry['id']
                page_token = calendar_list.get('nextPageToken')
                if not page_token:
                    break
        except Exception as e:
            raise e
        logger.addinfo('@ Google Utils - get_calendars_list(-)')
        return False

    @staticmethod
    def insert_new_calendar(service, summary, timezone):
        """
            Inserts new calendar if a specific calendar does not exists.
        """
        try:
            logger.addinfo('@ Google Utils - insert_new_calendar(+)')
            calendar = {
                'summary': summary,
                'timeZone': timezone
            }
            created_calendar = service.calendars().insert(body=calendar).execute()
        except Exception as e:
            raise e
        logger.addinfo('@ Google Utils - insert_new_calendar(-)')
        return created_calendar['id']

    def delete_event_google_cal(self, jsond):
        try:
            # Deleting an event in Google calendar by taking event_id and calendar_id as inputs
            logger.addinfo('@ Google Utils - delete_event_google_cal(+)')
            common_utils_obj = CommonUtils()
            is_valid, result = common_utils_obj.check_params(jsond, 'delete_google_sync_keys')
            if is_valid:
                credentials = self.delegate_account(jsond['account'])
                service = GoogleUtils.get_api("calendar", "v3", credentials=credentials)
                calendar_id = GoogleUtils.get_calendars_list(service, jsond['calendar_name'])
                if not calendar_id:
                    result['status'] = 'ERROR'
                    result['msg'] = 'Failed to sync to Google, Calendar specified is not associated with this account'
                event = service.events().get(calendarId=calendar_id,
                                             eventId=jsond['event_id']).execute()
                if event['status'] != 'cancelled':
                    service.events().delete(calendarId=calendar_id,
                                            eventId=jsond['event_id']).execute()
                result['status'] = 0
                result['msg'] = 'Google sync completed'
        except Exception as e:
            raise e
        logger.addinfo('@ Google Utils - delete_event_google_cal(-)')
        return result

    def get_service_validation(self, param_key, jsond):
        common_utils_obj = CommonUtils()
        is_valid, result = common_utils_obj.check_params(jsond, param_key)
        if is_valid:
            if 'finday.com' in jsond['account'] or 'almonature.com' in jsond['account']:
                credentials = self.delegate_account(jsond['account'])
                service = GoogleUtils.get_api("calendar", "v3", credentials=credentials)
                return {'status': 0, 'service': service}
            else:
                return {
                    'status': 1,
                    'msg': 'Verify your email address, Google sync only works for Almo domain accounts'
                }
        return result

    @staticmethod
    def get_date_time_for_google(event, jsond):
        if 'start_time' in jsond and 'end_time' in jsond:
            start_time = datetime.datetime.strptime(jsond['start_date'] + ' '
                                                    + jsond['start_time'], '%d-%b-%Y %H:%M:%S')

            end_time = datetime.datetime.strptime(jsond['end_date'] + ' '
                                                  + jsond['end_time'], '%d-%b-%Y %H:%M:%S')
            event['start'] = {
                'dateTime': start_time.strftime("%Y-%m-%dT%H:%M:%S"),
                'timeZone': jsond['timezone'],
            }
            event['end'] = {
                'dateTime': end_time.strftime("%Y-%m-%dT%H:%M:%S"),
                'timeZone': jsond['timezone'],
            }
        else:
            start_time = datetime.datetime.strptime(
                jsond['start_date'], dateformat)
            end_time = datetime.datetime.strptime(
                jsond['end_date'], dateformat)
            event['start'] = {
                'date': start_time.strftime("%Y-%m-%dT"),
                'timeZone': jsond['timezone'],
            }
            event['end'] = {
                'date': end_time.strftime("%Y-%m-%dT"),
                'timeZone': jsond['timezone'],
            }
        return event

    def change_google_calendar(self, jsond):
        """
            Insert and update google calendar, if event_id is null then treat as insert
            else it will be updating calendar.
        """
        try:
            logger.addinfo('@ Google Utils - change_google_calendar(+)')
            result = self.get_service_validation('google_sync_keys', jsond)
            if result.get('service'):
                service = result['service']
                event = {
                    'summary': jsond['summary'],
                    'location': jsond['location'],
                    'description': jsond['description'],
                    'reminders': {
                        'useDefault': False,
                        'overrides': [
                            {'method': 'email', 'minutes': 24 * 60},
                            {'method': 'popup', 'minutes': 10},
                        ],
                    },
                }

                event = GoogleUtils.get_date_time_for_google(event, jsond)
                calendar_id = GoogleUtils.get_calendars_list(service, jsond['calendar_name'])
                if not calendar_id:
                    calendar_id = GoogleUtils.insert_new_calendar(
                        service, jsond['calendar_name'], jsond['timezone'])
                if jsond['event_id']:
                    event = service.events().update(calendarId=calendar_id, eventId=jsond['event_id'],
                                                    body=event).execute()
                else:
                    event = service.events().insert(calendarId=calendar_id, body=event).execute()
                if event['status'] == 'confirmed':
                    result['status'] = 'OK'
                    result['msg'] = 'Google sync completed'
                    result['event_id'] = event['id']
                else:
                    result['status'] = 'ERROR'
                    result['msg'] = 'Failed to sync to Google'
                    result['event_id'] = -1
        except Exception as e:
            raise e
        logger.addinfo('@ Google Utils - change_google_calendar(-)')
        return result

    def fetch_google_calendar_events(self, jsond):
        try:
            logger.addinfo('@ Google Utils - fetch_google_calendar_events(+)')
            result = self.get_service_validation('fetch_google_sync_keys', jsond)
            if not result.get('service'):
                return result
            service = result['service']
            calendar_id = GoogleUtils.get_calendars_list(service, jsond['calendar_name'])
            if not calendar_id:
                calendar_id = GoogleUtils.insert_new_calendar(
                    service, jsond['calendar_name'], jsond['timezone'])
            start_time = datetime.datetime.strptime(
                jsond['start_date'], dateformat).isoformat() + 'Z'
            end_time = datetime.datetime.strptime(jsond['end_date'], dateformat).isoformat() + 'Z'
            events_list = service.events().list(
                calendarId=calendar_id,
                timeMin=start_time,
                timeMax=end_time,
                singleEvents=True,
                orderBy='startTime').execute()
            result = [event.get('id') for event in events_list.get('items', [])]
        except Exception as error:
            logger.findaylog("""@ EXCEPTION Google Utils -
              fetch_google_calendar_events """ + str(error))
            raise error
        logger.addinfo('@ Google Utils - fetch_google_calendar_events(-)')
        return result
