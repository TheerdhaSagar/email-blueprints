import base64
import hashlib
import random
import string
import os
import re
import copy
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
import jinja2
import ujson

from flask import Response
from mailjet_rest import Client

from finapi.utils import db_util
from finapi.sql import sql_util
from finapi.utils.code_util import Code_util
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil
from finapi.utils.google_cred_util import GoogleCredUtil

SCOPES = ['https://www.googleapis.com/auth/calendar',
          'https://www.googleapis.com/auth/calendar.events']
SERVICE_CREDENTIALS = 'finapi/utils/service_account.json'


class CommonUtils:
    def __init__(self, **kwargs):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False
        self.logging = True

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def check_params(self, req, param):
        result = {}
        keys = ''
        attributes = self.sql_file[param].split(',')

        for i in range(len(attributes)):
            if attributes[i].strip() not in req:
                keys += attributes[i] + ','

        if keys:
            keys = keys[:-1]
            result['status'] = 'ERROR'
            result['msg'] = 'Missing ' + keys
            result['msg'] += ' parameter(s)'
            return False, result
        return True, result

    def check_role_exists(self, user_id, role):
        try:
            self.acquire()
            query = self.sql_file['check_user_has_role']
            data = self.cursor.execute(query, p_role_name=role, p_user_id=user_id).fetchone()
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return data[0] in 'Y'

    @staticmethod
    def decode_credential(encoded):
        decoded = encoded
        for _ in range(5):
            decoded = base64.b64decode(decoded)[::-1]

        return decoded.decode('utf-8')

    @staticmethod
    def encode_key(key):
        for _ in range(5):
            key = base64.b64encode(key)
        return key

    @staticmethod
    def generate_random_string(length):
        return ''.join([random.choice(string.ascii_letters + string.digits[n])
                        for n in range(length)])

    @staticmethod
    def generate_md5_hash(data):
        md5_hash = hashlib.md5()
        md5_hash.update(data.encode('utf-8'))
        return md5_hash.hexdigest()

    @staticmethod
    def pass_error(module, method, error, is_views=True):
        module_type = 'views' if is_views else 'models'
        message = '@ EXCEPTION {0} - {1} - {2}, {3}' \
            .format(module_type, module, method, str(error))
        logger.findaylog(message)
        return Response(ujson.dumps({
            'status': 1,
            'msg': str(error)
        }), status=200, mimetype='application/json')

    @staticmethod
    def send_response(result):
        return Response(ujson.dumps(result), status=200,
                        mimetype='application/json')

    @staticmethod
    def get_error_message():
        return {
            'status': 'ERROR',
            'msg': 'Unable to process the request!'
        }

    def get_users_with_role(self, role):
        try:
            self.acquire()
            query = self.sql_file['users_with_role_query']
            self.cursor.execute(query, p_role_name=role)
            users = Code_util.iterate_data(self.cursor)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return users

    @staticmethod
    def check_email(email):
        return bool(re.search(r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$", email))

    @staticmethod
    def validate_password(password):
        # validates for 1 number, 1 lower case, 1 upper case,
        # 1 special character and minimum 8 characters
        return bool(re.match(r"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})", password))

    def get_attachment_data(self, column_name, table_name, column_id, file_id):
        """

        :param column_name: the column in which the file content is present
        :param table_name: attachment table
        :param column_id: the column name of the id present
        :param file_id: id of the attachment that you want to get
        :return: base64 content
        """
        try:
            self.acquire()
            query = self.sql_file['get_attachment_details']
            query = query.format(column_name, table_name, column_id)
            self.cursor.execute(query,
                                p_file_id=file_id)
            file_details = self.cursor.fetchone()
            result = None
            if file_details is not None:
                result = file_details[0].read()
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - utils -
                commonutils - get_attachment_data""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def get_user_details_based_on_id(self, user_id):
        try:
            self.acquire()
            query = self.sql_file['get_user_details']
            self.cursor.execute(query,
                                p_user_id=user_id)
            file_details = self.cursor.fetchone()
            fields = [x[0].lower() for x in self.cursor.description]

            result = None
            if file_details is not None:
                result = dict(list(zip(fields, file_details)))
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION - utils -
                    commonutils - get_user_details_based_on_id""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    @staticmethod
    def get_mail_attachments(mail_data):
        attachments = []
        if 'attachments' in mail_data:
            for attachment in mail_data['attachments']:
                attachments.append({
                    'ContentType': attachment['file_type'],
                    'Filename': attachment['file_name'],
                    'Base64Content': attachment['file_data'].decode('utf-8')
                })
        return attachments

    @staticmethod
    def get_mail_params(mail_data):
        params = {}
        if 'params' in mail_data:
            for param in mail_data['params']:
                key, value = param['key'], param['value']
                params[key] = value
        return params

    @staticmethod
    def get_mail_recipients(mail_data):
        mail_to = []
        if 'recipients' in mail_data:
            mail_to = mail_data['recipients']
        else:
            mail_to.append({
                'Email': mail_data['to_email'],
                'Name': mail_data.get('to_name', '')
            })
        return mail_to

    @staticmethod
    def get_mail_sender(mail_data):
        mail_server = os.environ.get('DEFAULT_MAIL_SERVER', '').lower().strip()
        if 'sender' in mail_data and mail_server != 'gmail':
            email = mail_data['sender']['email']
            name = mail_data['sender']['name']
        else:
            if mail_server == 'gmail':
                email = os.environ['GMAIL_FROM_ID']
                name = os.environ['GMAIL_FROM_NAME']
            else:
                email = os.environ['MAILJET_FROM_ID']
                name = os.environ['MAILJET_FROM_NAME']
        return email, name

    @staticmethod
    def send_mail(mail_data):
        status = ''
        try:
            strings = db_util.get_strings()

            attachments = CommonUtils.get_mail_attachments(mail_data)
            params = CommonUtils.get_mail_params(mail_data)
            mail_to = CommonUtils.get_mail_recipients(mail_data)
            from_email, from_name = CommonUtils.get_mail_sender(mail_data)

            data = {
                'Messages': [
                    {
                        'From': {
                            'Email': from_email,
                            'Name': from_name
                        },
                        'Subject': mail_data['subject'],
                        'TemplateID': mail_data['template_id'],
                        'TemplateLanguage': True,
                        'TemplateErrorReporting': {
                            'Email': strings['mj_error_report_mail'],
                            'Name': strings['mj_error_report_name']
                        },
                        'Variables': params,
                        'To': mail_to
                    }
                ]
            }

            if attachments:
                data['Messages'][0]['Attachments'] = attachments
            if mail_data.get('cc'):
                cc_list = mail_data['cc'].split(',')
                data['Messages'][0]['Cc'] = [{'Email': str(email), 'Name': ''} for email in cc_list]
            if mail_data.get('bcc'):
                bcc_list = mail_data['bcc'].split(',')
                data['Messages'][0]['Bcc'] = [
                    {'Email': str(email), 'Name': ''} for email in bcc_list]

            status = CommonUtils.send_mail_helper(data)
            if status != 'SUCCESS' and 'no_log' not in mail_data:
                logger.findaylog('Error sending email - ' + str(status))
        except Exception as error:
            if 'no_log' not in mail_data:
                logger.findaylog("""@ EXCEPTION - utils - commonutils -
                    send_mail """ + str(error))
        return status

    @staticmethod
    def send_mail_helper(data):
        status = 'SUCCESS'
        mail_server = os.environ.get('DEFAULT_MAIL_SERVER', '').lower().strip()
        backup_server = os.environ.get('BACKUP_MAIL_SERVER', '').lower().strip()
        if mail_server == 'gmail':
            # send email with gmail if that fails send with mailjet
            if not CommonUtils.send_email_with_gmail(data['Messages'][0]):
                result = CommonUtils.send_email_with_mailjet(data)
                if not result or result.status_code != 200:
                    status = 'Failed to send email using %s and %s' % (mail_server, backup_server)
        else:
            # send email with mailjet if that fails send with gmail
            result = CommonUtils.send_email_with_mailjet(data)
            if (not result or result.status_code != 200) and\
                    CommonUtils.send_email_with_gmail(data['Messages'][0]):
                status = 'Failed to send email using %s and %s' % (mail_server, backup_server)
        return status

    @staticmethod
    def get_mail_template(template_id, data):
        template = None
        try:
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/finapi/static/mail_templates/'
            file_name = '{}.html'.format(template_id)
            template = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path),
                autoescape=True
            ).get_template(file_name).render(
                params=data
            )
        except Exception as error:
            logger.findaylog('''@ EXCEPTION - utils - commonutils -
                get_mail_template - ''' + str(error))
        return template

    @staticmethod
    def get_formatted_mail_address(data):
        if data.get('Name'):
            return '%s <%s>' % (data['Name'], data['Email'])
        return data['Email']

    @staticmethod
    def send_email_with_mailjet(mail_data):
        data = copy.deepcopy(mail_data)
        result = {}
        mail_jet = Client(auth=(os.environ['MJ_APIKEY_PUBLIC'],
                                os.environ['MJ_APIKEY_PRIVATE']),
                          version='v3.1')
        template = CommonUtils.get_mail_template(
            data['Messages'][0]['TemplateID'], data['Messages'][0]['Variables'])

        if template:
            del data['Messages'][0]['TemplateID']
            del data['Messages'][0]['TemplateLanguage']
            del data['Messages'][0]['TemplateErrorReporting']
            del data['Messages'][0]['Variables']

            data['Messages'][0]['HTMLPart'] = template
            result = mail_jet.send.create(data=data)
        return result

    @staticmethod
    def send_email_with_gmail(data):
        try:
            credentials = GoogleCredUtil(os.environ['GMAIL_SERVICE_ACCOUNT'],
                                         scopes=['https://www.googleapis.com/auth/gmail.send'])
            api = credentials.get_api('gmail', 'v1', data['From']['Email'])

            template = CommonUtils.get_mail_template(
                data['TemplateID'], data['Variables'])

            if template:
                message = MIMEMultipart()
                message['From'] = CommonUtils.get_formatted_mail_address(data['From'])
                message['To'] = CommonUtils.get_formatted_mail_address(data['To'][0])
                if 'Cc' in data:
                    message['Cc'] = CommonUtils.get_formatted_mail_address(data['Cc'][0])
                if 'Bcc' in data:
                    message['Bcc'] = CommonUtils.get_formatted_mail_address(data['Bcc'][0])
                message['Subject'] = data['Subject']
                message.attach(MIMEText(template, 'html', 'utf-8'))

                if 'Attachments' in data:
                    for attachment in data['Attachments']:
                        message.attach(CommonUtils.get_payload(attachment))

                raw_content = {
                    'raw': base64.urlsafe_b64encode(message.as_string())
                }
                response = (api.users().messages().send(userId='me',
                                                        body=raw_content).execute())
                if response.get('id'):
                    return True
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - utils -
                commonutils - send_email_with_gmail """ + str(error))
            return False
        return False

    @staticmethod
    def get_payload(attachment):
        payload = MIMEBase('application', attachment['ContentType'])
        payload.set_payload(attachment['Base64Content'])
        payload.add_header('Content-Decomposition', 'attachment',
                           filename=attachment['Filename'])
        return payload

    @staticmethod
    def get_header_logo(org_id):
        if org_id == 243:
            header_logo = 'https://cdn.almonature.com/hubfs/pdf-footer/Logo_FondazioneCapellino_Reports.png'
        elif org_id == 263:
            header_logo = 'https://cdn.almonature.com/hubfs/pdf-footer/villa-fortunna-logo.png'
        else:
            header_logo = 'https://cdn.almonature.com/hubfs/logo_footer_v2.png'
        return header_logo

    @staticmethod
    def encode_base64(data):
        try:
            return base64.b64encode(data)
        except Exception:
            return data

    @staticmethod
    def decode_base64(data):
        try:
            return base64.b64decode(data)
        except Exception:
            return data

    @staticmethod
    def file_to_bas64(file_path, file_name):
        result = {}
        with open(file_path, 'r') as tmp_file:
            result['file_data'] = base64.b64encode(tmp_file.read()).decode('utf-8')
        result['file_name'] = '%s' % (file_name)
        return result


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'CommonUtils',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
