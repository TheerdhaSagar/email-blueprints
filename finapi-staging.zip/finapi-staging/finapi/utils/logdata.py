import base64
import logging
import os
import os.path
import ujson

from mailjet_rest import Client
from flask import g, request


class logger:

    @staticmethod
    def decode_credential(encoded):
        decoded = encoded
        for _ in range(5):
            decoded = base64.b64decode(decoded)[::-1]

        return decoded

    @staticmethod
    def get_user_name(input_data):
        if 'user_name1' in input_data:
            for _ in range(3):
                user_name = logger.decode_credential(input_data['user_name' + str(_ + 1)])
                if user_name[:3] == '--#' and user_name[-3:] == '#--':
                    final_user_name = user_name[3:-3]
        return final_user_name

    @staticmethod
    # user based log method
    def getLog():
        loglevel = logging.INFO
        l = ""
        tmp_debugflg = ""
        if 'debug' in g:
            tmp_debugflg = g.debug
        if tmp_debugflg == 'Y':
            l = logging.getLogger(g.username)
            file_name = g.username+'.log'
            if not l.handlers:
                l.setLevel(logging.INFO)
                h = logging.FileHandler(os.path.join("/tmp", file_name), "a",
                                        encoding=None, delay="true")
                # h = logging.FileHandler(file_name)
                f = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
                h.setFormatter(f)
                l.addHandler(h)
                l.setLevel(loglevel)
        return l

    @staticmethod
    # verify's each time and add id exsists
    def addinfo(logmsg):
        log = logger.getLog()
        if log:
            log.info(logmsg)

    @staticmethod
    # finday log
    def findaylog(logmsg, send_email=True):
        lg = logging.getLogger('finday')
        if not lg.handlers:
            lg.setLevel(logging.INFO)
            file_name = 'finday.log'
            h = logging.FileHandler(os.path.join("/tmp", file_name), "a",
                                    encoding=None, delay="true")
            f = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
            h.setFormatter(f)
            lg.addHandler(h)
            lg.setLevel(logging.INFO)
        lg.info(logmsg)
        if type(logmsg) == str and logmsg.find('models') != -1 and send_email:
            logger.send_log_email(logmsg)

    @staticmethod
    def send_log_email(error_message):
        try:
            api_key = os.environ['MJ_APIKEY_PUBLIC']
            api_secret = os.environ['MJ_APIKEY_PRIVATE']
            mailjet = Client(auth=(api_key, api_secret))
            try:
                user = g.username.lower()
            except Exception:
                user = 'no_user'

            try:
                path = request.path[1:]
                index = path.index('/')
                module = path[0:index]
            except Exception:
                module = ''

            try:
                input_data = request.data
                if input_data:
                    input_data = ujson.loads(input_data)
                    # To get user_name for Cruscott login page error emails
                    if request.endpoint == 'login.user_verification':
                        input_data['user_name'] = logger.get_user_name(input_data)
                    if 'attachments' in input_data:
                        input_data['attachments'] = []
                    input_data = ujson.dumps(input_data)
            except Exception:
                input_data = 'Error decoding input_data'

            sub = 'Issue: Finapi {0} in module {1} for user {2}'
            sub = sub.format(os.environ.get('FINAPI_SERVER', 'PROD'),
                             module, user)
            data = {
                'FromEmail': 'noreply@almonature.com',
                'FromName': 'Almo Nature',
                'Subject': sub,
                'MJ-TemplateID': 245644,
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': 'saikrishna@finday.com',
                'Vars': {
                    'source': 'Finapi',
                    'module': module,
                    'function': request.endpoint + '  =>  ' + request.full_path,
                    'user': user,
                    'error_msg': error_message,
                    'input_data': input_data
                },
                'To': os.environ['API_ERROR_LOG_MAIL']
            }
            mailjet.send.create(data=data)
        except Exception:
            pass
