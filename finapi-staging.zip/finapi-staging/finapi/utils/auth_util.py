import base64
import hashlib
import os


def encrypt(source):
    salt = os.environ['PWD_SALT']
    pwd_hash = hashlib.pbkdf2_hmac('sha512', source.encode('utf-8'),
                                   salt.encode('utf-8'), 100000)
    return pwd_hash.hex()


def verify(source, target):
    hashed = encrypt(source)
    if hashed == target:
        return True
    return verify_legacy(source, target)


def encrypt_legacy(source):
    salt = os.environ['PWD_SALT']
    d = hashlib.sha256()
    d.update(salt.encode('utf-8'))
    d.update(source.encode('utf-8'))
    hashed = bytes(d.digest())
    for _ in range(0, 1023):
        d = hashlib.sha256()
        d.update(hashed)
        hashed = bytes(d.digest())
    base64hash = base64.b64encode(hashed)
    return base64hash.decode('utf-8').strip()


def verify_legacy(source, target):
    hashed = encrypt_legacy(source)
    if hashed == target:
        return True
    return False
