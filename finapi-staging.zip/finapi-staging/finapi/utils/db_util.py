import functools
import os

import cx_Oracle
import yaml

from finapi.utils.logdata import logger


host = os.environ['CLIENTDBHOST']
user = os.environ['CLIENTDBUSER']
pwd = os.environ['CLIENTDBPASS']
db = os.environ['CLIENTDBNAME']
port = os.environ['CLIENTDBPORT']

dsn = "(DESCRIPTION= (ADDRESS=(PROTOCOL=tcp)(HOST=" + host + ") \
           (PORT=" + port + ")) (CONNECT_DATA= (SERVICE_NAME=" + db + ") \
           (INSTANCE_NAME=" + db + ")))"
db_pool = None
os.environ['NLS_LANG'] = ".AL32UTF8"


def init_pool():
    try:
        return cx_Oracle.SessionPool(user=user, password=pwd, dsn=dsn, min=1,
                                     max=5, increment=1)
    except cx_Oracle.DatabaseError:
        logger.findaylog('Error establishing database connection', send_email=True)
    return None


def get_connection():
    if db_pool:
        return db_pool.acquire(purity=cx_Oracle.ATTR_PURITY_NEW)
    return None


def release_connection(con):
    if db_pool:
        db_pool.release(con)


def langs(plang):
    def decorator(f):
        @functools.wraps(f)
        def wrapped(*args, **kwargs):
            retval = f(*args, **kwargs)
            con = get_connection()
            cur = con.cursor()
            cur.execute("ALTER SESSION SET NLS_LANGUAGE = "+str(plang))
            cur.close()
            release_connection(con)
            return retval
        return wrapped
    return decorator


def getSqlData():
    fn = os.path.join(os.path.dirname(__file__), 'sql.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return sql_file


def getusermngSql():
    fn = os.path.join(os.path.dirname(__file__), 'usermngsql.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return sql_file


def get_reports_sql():
    fn = os.path.join(os.path.dirname(__file__), 'reports.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return sql_file


def get_strings():
    fn = os.path.join(os.path.dirname(__file__), 'strings.yaml')
    with open(fn, 'r') as yaml_file:
        strings_file = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return strings_file


def get_onboard_images():
    fn = os.path.join(os.path.dirname(__file__), 'onboard.yaml')
    with open(fn, 'r') as yaml_file:
        onboard_file = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return onboard_file


def get_sql(filename):
    fn = os.path.join(os.path.dirname(__file__), filename + '.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return sql_file
