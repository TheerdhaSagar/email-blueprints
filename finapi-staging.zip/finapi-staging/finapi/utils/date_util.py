from . import db_util
import datetime
from finapi.utils.logdata import logger


def getdatefomat(formatval, dateval):
    logger.addinfo('@ utils - dateutil - getdatefomat(+)')
    sql_file = db_util.getSqlData()
    formatlist = sql_file['dateformats']
    req_format = ''
    for key, value in formatlist.items():
        if key == formatval:
            req_format = value
            pass
    date_object = datetime.datetime.strptime(str(dateval), '%Y-%m-%d %H:%M:%S')
    formatted_date = date_object.strftime(req_format)
    logger.addinfo('@ utils - dateutil - getdatefomat(-)')
    return formatted_date
