from functools import wraps
from flask import request, abort, Response
from finapi.utils import db_util
import ujson


def validate_api(func):
    @wraps(func)
    def check_api_key(*args, **kwargs):
        api_key = request.headers.get('x-api-key')
        api_secret = request.headers.get('x-api-secret')
        connection = db_util.get_connection()
        cursor = connection.cursor()
        sql_file = db_util.getSqlData()
        api_query = sql_file['api_validate_query']
        cursor.execute(api_query, p_api_key=api_key,
                       p_api_secret=api_secret)
        data = cursor.fetchone()
        if data and len(data) > 0:
            pass
        else:
            resp = {'status': 401,
                    'msg': 'Unauthorized! Please authenticate with API'
                    ' key & API Secret to access this API'}
            abort(Response(ujson.dumps(resp), status=401,
                           mimetype='application/json'))

    return check_api_key
