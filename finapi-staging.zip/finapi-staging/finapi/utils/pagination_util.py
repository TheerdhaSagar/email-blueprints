from finapi.utils.logdata import logger


def getpagination(pagenum, pagesize, plist):
    logger.addinfo('@ utils - paginationutil - getpagination(+)')
    page_num = pagenum
    page_size = pagesize
    start_index = ""
    end_index = ""
    data_len = len(plist)
    total_data = (page_num*page_size)+page_size
    final_data = []
    if page_num == 1:
        start_index = 0
        end_index = page_size*page_num
    elif total_data >= data_len:
        start_index = (page_num*page_size)-(2*page_size)
        end_index = data_len
    else:
        start_index = (page_num*page_size)-(2*page_size)
        end_index = (page_num*page_size)+page_size
    final_data = plist[start_index:end_index]
    logger.addinfo('@ utils - paginationutil - getpagination(-)')
    if final_data:
        return final_data
    else:
        return "Enter a valid page num or size"


def getpg_dtype(pagenum, pagesize, plist):
    logger.addinfo('@ utils - paginationutil - getpg_dtype(+)')
    page_num = pagenum
    page_size = pagesize
    start_index = ""
    end_index = ""
    final_data = []
    data_len = len(plist)
    total_data = (page_num*page_size)+page_size
    if page_num == 1:
        start_index = 1
        end_index = (page_size*page_num)+1
    elif total_data >= data_len:
        start_index = (page_num*page_size)-(2*page_size)+1
        end_index = data_len
    else:
        start_index = (page_num*page_size)-(2*page_size)+1
        end_index = (page_num*page_size)+page_size+1
    final_data = [plist[0]]+final_data
    final_data.extend(plist[start_index:end_index])
    logger.addinfo('@ utils - paginationutil - getpg_dtype(-)')
    if len(final_data) == 1:
        return "Enter a valid page num or size"
    else:
        return final_data
