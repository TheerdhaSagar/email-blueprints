from apiclient.discovery import build
from google.oauth2 import service_account


class GoogleCredUtil(object):
    def __init__(self, credential_path, scopes):
        self.credentials = service_account.Credentials.from_service_account_file(
            credential_path, scopes=scopes)

    def delegate_account(self, account):
        return self.credentials.with_subject(account)

    def get_api(self, api, version, account):
        delegated_credentials = self.delegate_account(account)
        return build(api, version, credentials=delegated_credentials)
