from finapi.utils import db_util


def get_query(report):
    sqlFile = db_util.get_reports_sql()
    return {
        'cruscott': sqlFile['cruscott_query'],
        'sales_avg': sqlFile['sales_avg_query'],
        'revenue_segments': sqlFile['segments_query'],
        'revenue_brand': sqlFile['revenue_brand_query'],
        'revenue_items': sqlFile['revenue_items_query'],
        'revenue_agent': sqlFile['revenue_agent_query'],
        'revenue_class': sqlFile['revenue_class_query'],
        'revenue_network': sqlFile['sales_network_query'],
        'cruscott_sales': sqlFile['cruscott_sales_query'],
        'revenue_segments_agent': sqlFile['segments_agents_query'],
        'revenue_brand_agent': sqlFile['revenue_brand_agent_query'],
        'revenue_items_agent': sqlFile['revenue_items_agents_query'],
        'revenue_brand_customer': sqlFile['revenue_brand_customer_query']
    }[report]


def get_key_list(report):
    return {
        'revenue_network': ['SN', 'sales_channel', 'period'],
        'cruscott': ['C', 'org_name', 'group_name', 'period'],
        'revenue_brand': ['RB', 'sales_channel', 'brand', 'period'],
        'cruscott_sales': ['CS', 'sales_channel', 'segments', 'period'],
        'revenue_items': ['RI', 'sales_channel', 'item_code', 'period'],
        'revenue_agent': ['RA', 'sales_channel', 'agent_name', 'period'],
        'revenue_segments': ['RS', 'sales_channel', 'segments', 'period'],
        'revenue_class': ['RC', 'sales_channel', 'customer_class', 'period'],
        'revenue_brand_agent': ['RBA', 'sales_channel', 'brand',
                                'salesrep_id', 'period'],
        'revenue_items_agent': ['RIA', 'sales_channel', 'salesrep_id',
                                'item_code', 'period'],
        'revenue_segments_agent': ['RSA', 'sales_channel', 'salesrep_id',
                                   'segments', 'period'],
        'revenue_brand_customer': ['RBC', 'sales_channel', 'brand',
                                   'cust_account_id', 'period'],
        'sales_avg': ['SA', 'group_name', 'customer_number',
                      'agent_name', 'segments', 'item_code', 'period']
    }[report]
