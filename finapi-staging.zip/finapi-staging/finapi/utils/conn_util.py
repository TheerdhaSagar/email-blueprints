import functools
import inspect
import cx_Oracle
from finapi.utils import db_util
from finapi.utils.code_util import Code_util
from finapi.utils.logdata import logger


class OracleConnectionManager:
    def __init__(self):
        self.connection = None
        self.cursor = None
        self.is_acquired = False
        self.status_code = None

    def __enter__(self):
        """
        sql connection resources are assigned & managed
        :return:
        """
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        """
        after completion of query execution, the connections to be released
        """
        if self.is_acquired:
            self.connection.commit()
            self.release()

    def __call__(self, f):
        @functools.wraps(f)
        def wrapper(*args, **kw):
            with self:
                return f(self, *args, **kw)

        return wrapper

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def set_output_param(self, variable_type='STRING'):
        if variable_type == 'STRING':
            return self.cursor.var(cx_Oracle.STRING)
        else:
            return self.cursor.var(cx_Oracle.NUMBER)

    def execute(self, query, output_key=None, **kwargs):
        """
        To execute the query with params or without params
        :param query:
        :param output_key: Key that is present for package
        :param kwargs:
        """
        try:
            if kwargs:
                params = {key: value for key, value in list(kwargs.items())}
                if output_key:
                    self.status_code = self.set_output_param('STRING')
                    params[output_key] = self.status_code
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
        except Exception as e:
            raise e

    def get_result(self, convert_data=False, is_json_check=False):
        """
        To get the details from the oracle cursor
        :return:
        """
        return Code_util.iterate_data(self.cursor, convert_data, is_json_check)

    def get_single_result(self, convert_data=False):
        """
        to fetch single result from cursor and convert to unicode
        :return:
        """
        fetch_details = self.cursor.fetchone()
        fields = [x[0].lower() for x in self.cursor.description]
        result = None
        if fetch_details is not None:
            result = dict(list(zip(fields, fetch_details)))
            if convert_data:
                result = Code_util.convert_to_unicode([result])[0]
        return result

    def get_output_param(self, raise_exception=True, send_email=True):
        if self.status_code.getvalue() not in ['SUCCESS', 'S']:
            if raise_exception:
                raise Exception(self.status_code.getvalue())
            else:
                func_name = inspect.stack()[1][3]
                logger.findaylog("""@ models - {0} - {1}""".format(func_name,
                                                                   self.status_code.getvalue()),
                                 send_email)
        return self.status_code.getvalue()


class DummyContextManager:
    def __init__(self):
        pass  # empty parameters are present

    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc_value, traceback):
        return False
