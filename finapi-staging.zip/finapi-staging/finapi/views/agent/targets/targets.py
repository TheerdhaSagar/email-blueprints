import ujson

from flask import Blueprint, request

from finapi.plugins import auth
from finapi.utils.common_utils import CommonUtils
from finapi.utils.log_util import LogUtil
from finapi.models.agent.targets.targets import AgentTargets

agent_targets = Blueprint('agent_targets', __name__, url_prefix='/agent/targets')


@agent_targets.route('/templates/', methods=['GET', 'PUT'])
@agent_targets.route('/templates/<int:template_id>/', methods=['GET', 'DELETE'])
@agent_targets.route('/templates/copy/<int:template_id>/<int:user_id>/', methods=['GET'])
def get_target_templates(template_id=None, user_id=None):
    try:
        if request.method == 'PUT':
            req = ujson.loads(request.data)
            result = AgentTargets.update_template(req)
        elif request.path.find('copy') != -1:
            result = AgentTargets.copy_template(template_id, user_id)
        elif request.method == 'DELETE':
            result = AgentTargets.delete_template(template_id)
        else:
            obj = AgentTargets()
            result = obj.get_target_templates(template_id)
    except Exception as error:
        return CommonUtils.pass_error('agent_targets', 'get_target_templates', error)
    return CommonUtils.send_response(result)


@agent_targets.route('/<int:template_id>/', methods=['GET'])
@agent_targets.route('/<int:template_id>/<int:salesrep_id>/', methods=['DELETE'])
@agent_targets.route('/', methods=['PUT', 'POST'])
def get_agent_targets(template_id=None, salesrep_id=None):
    try:
        if request.method == 'PUT':
            req = ujson.loads(request.data)
            result = AgentTargets.update_agent_target(req)
        elif request.method == 'POST':
            req = ujson.loads(request.data)
            result = AgentTargets.insert_agent_target(req)
        elif request.method == 'DELETE':
            result = AgentTargets.delete_agent_target(template_id, salesrep_id)
        else:
            obj = AgentTargets()
            result = obj.get_agent_targets(template_id)
    except Exception as error:
        return CommonUtils.pass_error('agent_targets', 'get_agent_targets', error)
    return CommonUtils.send_response(result)


@agent_targets.route('/salesreps/', methods=['GET'])
def get_salesreps():
    try:
        obj = AgentTargets()
        result = obj.get_salesreps()
    except Exception as error:
        return CommonUtils.pass_error('agent_targets', 'get_salesreps', error)
    return CommonUtils.send_response(result)


@agent_targets.route('/email/send/', methods=['POST'])
def send_email():
    try:
        req = ujson.loads(request.data)
        obj = AgentTargets()
        result = obj.send_email(req)
    except Exception as error:
        return CommonUtils.pass_error('agent_targets', 'send_email', error)
    return CommonUtils.send_response(result)


@agent_targets.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@agent_targets.after_request
@LogUtil.after_request
def after_request(response):
    return response
