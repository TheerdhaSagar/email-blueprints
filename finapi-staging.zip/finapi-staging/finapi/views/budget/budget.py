import ujson
from flask import Blueprint, Response, request
from finapi.models.budget.budget import Budget
from finapi.utils.logdata import logger
from finapi.plugins import auth
from finapi.utils.constants import Status

budget = Blueprint('budget', __name__, url_prefix='/budget')


@budget.route('/', methods=['GET'])
def get_headers():
    logger.addinfo('views - budget - get_headers(+)')
    try:
        budget_obj = Budget()
        result = budget_obj.get_headers()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views - budget -
                        get_headers """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views - budget - get_headers(-)')
    return response


@budget.route('/read_file/', methods=['POST'])
def read_file():
    logger.addinfo('views - budget - read_file(+)')
    jsond = ujson.loads(request.data)
    try:
        budget_obj = Budget()
        result = budget_obj.read_file(jsond)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views - budget -
                         read_file """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views - budget - read_file(-)')
    return response


@budget.route('/', methods=['POST'])
def insert():
    logger.addinfo('views - budget - insert(+)')
    jsond = ujson.loads(request.data)
    try:
        budget_obj = Budget()
        result = budget_obj.insert(jsond)
        if result == 'SUCCESS':
            final = {
                'status': Status.OK.value,
                'msg': 'Inserted Successfully'
            }
        else:
            final = {
                'status': Status.ERROR.value,
                'msg': result
            }
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views - budget  -
                         insert """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views - budget - insert(-)')
    return response


@budget.route('/<int:budget_id>/', methods=['GET'])
def get_budget_lines(budget_id=None):
    logger.addinfo('views - budget - get_budget_lines(+)')
    try:
        budget_obj = Budget()
        result = budget_obj.get_budget_lines(budget_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views - budget -
                        get_budget_lines """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views -budget -get_budget_lines(-)')
    return response


@budget.route('/header/<int:budget_id>/', methods=['DELETE'])
def delete_header(budget_id=None):
    logger.addinfo('views - budget - delete_header(+)')
    try:
        budget_obj = Budget()
        result = budget_obj.delete_header(budget_id)
        if result == 'SUCCESS':
            final = {
                'status': Status.OK.value,
                'msg': 'Budget deleted successfully'
            }
        else:
            final = {
                'status': Status.ERROR.value,
                'msg': result
            }
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views -budget -
                         delete_header """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views - budget - delete_header(-)')
    return response


@budget.route('/lines/<int:budget_id>/<string:item_code>/', methods=['DELETE'])
def delete_lines(budget_id=None, item_code=None):
    logger.addinfo('views - budget - delete_lines(+)')
    try:
        budget_obj = Budget()
        result = budget_obj.delete_lines(budget_id, item_code)
        if result == 'SUCCESS':
            final = {
                'status': Status.OK.value,
                'msg': 'Item deleted successfully'
            }
        else:
            final = {
                'status': Status.ERROR.value,
                'msg': result
            }
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views - budget -
                         delete_lines """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views - budget - delete_lines(-)')
    return response


@budget.route('/line/', methods=['POST'])
def insert_line():
    logger.addinfo('views - budget - insert_line(+)')
    jsond = ujson.loads(request.data)
    try:
        budget_obj = Budget()
        result = budget_obj.insert_line(jsond)
        if result['status'] == 'SUCCESS':
            final = {
                'status': Status.OK.value,
                'msg': 'Item inserted successfully',
                'item_description': result['item_description']
            }
        else:
            final = {
                'status': Status.ERROR.value,
                'msg': result['status'],
                'item_description': ''
            }
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views - budget -
                         insert_line """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views - budget - insert_line(-)')
    return response


@budget.route('/line/', methods=['PUT'])
def update_line():
    logger.addinfo('views - budget - update_line(+)')
    jsond = ujson.loads(request.data)
    try:
        budget_obj = Budget()
        result = budget_obj.update_line(jsond)
        if result == 'SUCCESS':
            final = {
                'status': Status.OK.value,
                'msg': 'Item updated successfully'
            }
        else:
            final = {
                'status': Status.ERROR.value,
                'msg': result
            }
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views - budget -
                         update_line """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views - budget - update_line(-)')
    return response


@budget.route('/dates/', methods=['POST'])
def get_start_end_dates():
    logger.addinfo('@ views - budget - get_start_end_dates(+)')
    jsond = ujson.loads(request.data)
    try:
        budget_obj = Budget()
        result = budget_obj.get_start_end_dates(jsond)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        logger.findaylog("""@ EXCEPTION - views - budget -
                         get_start_end_dates """ + str(e.message))
        return pass_error(e)
    logger.addinfo('views - budget - get_start_end_dates(-)')
    return response


def pass_error(error):
    response = {
        'status': Status.ERROR.value,
        'msg': error.message
    }
    resp = Response(ujson.dumps(response), status=200,
                    mimetype='application/json')
    return resp


@budget.before_request
@auth.login_required
def before_request():
    pass
