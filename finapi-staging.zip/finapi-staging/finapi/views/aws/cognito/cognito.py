import ujson
from flask import Blueprint, request

from finapi.models.aws.cognito.cognito import Cognito
from finapi.utils.common_utils import CommonUtils
from finapi.utils.constants import Status
from finapi.utils.log_util import LogUtil

cognito = Blueprint('cognito', __name__, url_prefix='/aws/cognito')


@cognito.route('/login/', methods=['POST'])
def login():
    try:
        req = ujson.loads(request.data)
        obj = Cognito()
        result = obj.login(req)
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'login', e)
    return CommonUtils.send_response(result)


@cognito.route('/password/forgot/', methods=['POST'])
def forgot_password():
    try:
        req = ujson.loads(request.data)
        obj = Cognito()
        result = obj.forgot_password(req)
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'forgot_password', e)
    return CommonUtils.send_response(result)


@cognito.route('/password/change/', methods=['POST'])
def change_password():  # not in use in the new flow
    try:
        req = ujson.loads(request.data)
        obj = Cognito()
        result = obj.change_password(req)
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'change_password', e)
    return CommonUtils.send_response(result)


@cognito.route('/password/update/', methods=['POST'])
def update_password():
    try:
        req = ujson.loads(request.data)
        obj = Cognito()
        result = obj.update_password(req)
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'update_password', e)
    return CommonUtils.send_response(result)


@cognito.route('/password/reset/', methods=['POST'])
def reset_password():
    try:
        req = ujson.loads(request.data)
        req['password'] = CommonUtils.decode_credential(req['password'])
        if CommonUtils.validate_password(req['password']):
            obj = Cognito()
            result = obj.reset_password(req)
        else:
            result = {
                'status': 1,
                'msg': 'Password does not conform to policy'
            }
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'reset_password', e)
    return CommonUtils.send_response(result)


@cognito.route('/set/password/<string:email>/', methods=['POST'])
def set_password(email):
    # This method is used from cruscott to set new password
    try:
        req = ujson.loads(request.data)
        req['password'] = CommonUtils.decode_credential(req['password'])
        if CommonUtils.validate_password(req['password']):
            if CommonUtils.check_email(email.lower()):
                req['email'] = email.lower()
                obj = Cognito()
                result = obj.reset_password(req, validate_token=False)
            else:
                result = {
                    'status': 1,
                    'msg': 'Email is not in correct format'
                }
        else:
            result = {
                'status': 1,
                'msg': 'Password does not conform to policy'
            }
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'set_password', e)
    return CommonUtils.send_response(result)


@cognito.route('/user/', methods=['POST'])
def get_user():
    try:
        req = ujson.loads(request.data)
        cognito_obj = Cognito()
        result = cognito_obj.get_user(req)
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'get_user', e)
    return CommonUtils.send_response(result)


@cognito.route('/register/', methods=['POST'])
def register():
    try:
        req = ujson.loads(request.data)
        obj = Cognito()
        result = obj.register(req)
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'register', e)
    return CommonUtils.send_response(result)


@cognito.route('/users/', methods=['POST'])
def get_users_list():
    try:
        req = ujson.loads(request.data)
        obj = Cognito()
        result = obj.get_users_list(req)
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'get_users_list', e)
    return CommonUtils.send_response(result)


@cognito.route('/users/<string:email>/', methods=['DELETE'])
def delete_user(email):
    valid_emails = ['yogasaikrishna@gmail.com', 'ilya@twice-agency.ru',
                    'ksenia.tolkova@twice-agency.ru',
                    'zaharova_aa@icloud.com', 'ablov90@gmail.com', 'jonika_@mail.ru',
                    'awakened666@gmail.com']
    if email.lower() not in valid_emails:
        result = {
            'status': 1,
            'msg': 'Not a valid email'
        }
    else:
        try:
            obj = Cognito()
            result = obj.delete_user(email)
            if result == 'success':
                result = {
                    'status': 0,
                    'msg': 'Account deleted successfully'
                }
        except Exception as e:
            return CommonUtils.pass_error('cognito', 'delete_user', e)
    return CommonUtils.send_response(result)


@cognito.route('/delete/user/<string:email>/', methods=['DELETE'])
def delete_cognito_user(email):
    # This method is used from cruscott to delete user
    try:
        obj = Cognito()
        result = obj.delete_user(email)
        if result == 'success':
            result = {
                'status': 0,
                'msg': 'Account deleted successfully'
            }
        else:
            result = {
                'status': 1,
                'msg': 'Cannot find user with this email! Please try again'
            }
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'delete_cognito_user', e)
    return CommonUtils.send_response(result)


@cognito.route('/users/validate/<string:email>/', methods=['GET'])
def validate_user(email):
    try:
        obj = Cognito()
        req = {
            'email': email
        }
        result = obj.get_users_list(req)
        if len(result) > 0:
            res = {
                'status': 1,
                'msg': 'User account already exists with the email',
                'status_code': 'USER_EXISTS'
            }
        else:
            res = {
                'status': 0,
                'msg': 'No data found with the email',
                'status_code': 'NO_DATA_FOUND'
            }
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'validate_user', e)
    return CommonUtils.send_response(res)


@cognito.route('/password/resend/', methods=['POST'])
def resend_temporary_password():
    try:
        req = ujson.loads(request.data)
        obj = Cognito()
        result = obj.resend_temporary_password(req)
        if result == 'SUCCESS':
            res = {
                'status': Status.OK.value,
                'msg': 'Temporary password sent successfully'
            }
        else:
            res = {
                'status': Status.ERROR.value,
                'msg': 'Failed to send password to user'
            }
    except Exception as e:
        return CommonUtils.pass_error('cognito', 'resend_temporary_password', e)
    return CommonUtils.send_response(res)


@cognito.before_request
@LogUtil.before_request
def before_request():
    pass


@cognito.after_request
@LogUtil.after_request
def after_request(response):
    return response
