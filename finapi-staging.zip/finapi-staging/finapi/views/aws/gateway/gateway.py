import ujson
from flask import Blueprint, request, Response

from finapi.models.gateway.gateway import Gateway
from finapi.models.storelocator.storelocator import StoreLocator
from finapi.utils.common_utils import CommonUtils
from finapi.utils.log_util import LogUtil

gateway = Blueprint('gateway', __name__, url_prefix='/aws/gateway')


@gateway.route('/stores/', methods=['GET'])
def get_stores_by_country():
    try:
        obj = StoreLocator()
        country = request.args.get('country')
        stores = obj.get_stores_by_country(country)
    except Exception as e:
        return CommonUtils.pass_error('gateway', 'get_stores_by_country', e)
    return Response(ujson.dumps(stores), status=200,
                    mimetype='application/json')


@gateway.route('/cache/', methods=['DELETE'])
def delete_cache():
    try:
        obj = Gateway()
        result = obj.delete_cache()
    except Exception as error:
        return CommonUtils.pass_error('gateway', 'delete_cache', error)
    return CommonUtils.send_response(result)


@gateway.before_request
@LogUtil.before_request
def before_request():
    pass


@gateway.after_request
@LogUtil.after_request
def after_request(response):
    return response
