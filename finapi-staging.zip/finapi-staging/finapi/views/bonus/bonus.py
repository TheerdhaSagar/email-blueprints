from flask import Blueprint, request, Response
import json
import ujson
from finapi.utils.logdata import logger
from finapi.plugins import auth
from finapi.models.bonus.bonus import Bonus

bonus = Blueprint('bonus', __name__, url_prefix='/bonus')


@bonus.route('/conversion/', methods=['POST'])
def xml_generate():
    logger.addinfo('@ [POST] views - payments - xml_generate(+)')
    jsond = ujson.loads(request.data)
    final = {}
    try:
        temp = Bonus.writing(jsond['base64'], jsond['sales_channel'],
                             jsond['number_format'])
        resp = Response(ujson.dumps(temp), status=200,
                        mimetype='application/xml')
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - views - payments -
             xml_generate """ + str(error.message))
        final['status'] = 1
        final['msg'] = str(error.message)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/xml')
    return resp


@bonus.route('/', methods=['POST'])
def post_bonus():
    logger.addinfo('@ [POST] views - payments - post_bonus(+)')
    jsond = json.loads(request.data)
    final = {}
    try:
        header_id = Bonus.head_id()
        for i in jsond:
            i['batch_id'] = header_id
        temp = Bonus.post(jsond)
        if temp == 'success':
            pkg_call = Bonus.package_call(header_id)
            if pkg_call == 'SUCCESS':
                final['status'] = 0
                final['msg'] = 'Bonus inserted successfully'
            else:
                final['status'] = 1
                final['msg'] = 'Bonus insertion failed'
        else:
            final['status'] = 1
            final['msg'] = 'Bonus insertion failed'
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/xml')
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - views - payments -
             post_bonus """ + str(error.message))
        final['status'] = 1
        final['msg'] = str(error.message)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
    return resp


@bonus.route('/agents/<string:sales_channel>/', methods=['GET'])
def get_agents(sales_channel=None):
    logger.addinfo('@ [POST] views - payments - get_agents(+)')
    final = {}
    try:
        result = Bonus.get_agent_datails(sales_channel)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - views - payments -
             get_agents """ + str(error.message))
        final['status'] = 1
        final['msg'] = str(error.message)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/xml')
    logger.addinfo('@ [POST] views - payments - get_agents(-)')
    return resp


@bonus.route('/<string:period>/<string:group_name>/', methods=['GET'])
def get_bonus_details(period=None, group_name=None):
    logger.addinfo('@ [POST] views - payments - get_bonus_details(+)')
    final = {}
    try:
        result = Bonus.get_bonus_details(period, group_name)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - views - payments -
             get_bonus_details """ + str(error.message))
        final['status'] = 1
        final['msg'] = str(error.message)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/xml')
    logger.addinfo('@ [POST] views - payments - get_bonus_details(-)')
    return resp


@bonus.route('/po/<string:period>/', methods=['GET'])
def po_creation(period=None):
    logger.addinfo('@ [POST] views - payments - po_creation(+)')
    final = {}
    try:
        result = Bonus.po_creation(period)
        if result == 'S':
            final['status'] = 0
            final['msg'] = 'Purchase order created successfully'
        else:
            final['status'] = 1
            final['msg'] = result
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - views - payments -
             po_creation """ + str(error.message))
        final['status'] = 1
        final['msg'] = str(error.message)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/xml')
        return resp
    resp = Response(ujson.dumps(final), status=200,
                    mimetype='application/json')
    logger.addinfo('@ [POST] views - payments - po_creation(-)')
    return resp


@bonus.route('/mail/<string:period>/', methods=['GET'])
def send_mail(period=None):
    logger.addinfo('@ [POST] views - payments - send_mail(+)')
    final = {}
    try:
        result = Bonus.send_mail(period)
        if result == 'success':
            final['status'] = 0
            final['msg'] = 'Mail sent successfully'
        else:
            final['status'] = 1
            final['msg'] = 'Failed to sent email'
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - views - payments -
             send_mail """ + str(error.message))
        final['status'] = 1
        final['msg'] = str(error.message)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/xml')
        return resp
    resp = Response(ujson.dumps(final), status=200,
                    mimetype='application/json')
    logger.addinfo('@ [POST] views - payments - send_mail(-)')
    return resp


@bonus.route('/exist/<string:period>/<string:sales_channel>/', methods=['GET'])
def check_data_exist(period=None, sales_channel=None):
    logger.addinfo('@ [POST] views - payments - check_data_exist(+)')
    final = {}
    try:
        result = Bonus.check_data_exist(period, sales_channel)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - views - payments -
             check_data_exist """ + str(error.message))
        final['status'] = 1
        final['msg'] = str(error.message)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/xml')
        return resp
    logger.addinfo('@ [POST] views - payments - check_data_exist(-)')
    return resp


@bonus.before_request
@auth.login_required
def before_request():
    pass
