from flask import Blueprint

from finapi.models.address.address import Address
from finapi.plugins import auth
from finapi.utils.common_utils import CommonUtils
from finapi.utils.log_util import LogUtil

address = Blueprint('address', __name__, url_prefix='/address')


@address.route('/shipto/<int:salesrep>/<int:custaccnt>/<int:orgid>/',
               methods=['GET'])
def get_ship_to(salesrep, custaccnt, orgid):
    try:
        addresses = Address.get_allshipto_address(salesrep, custaccnt, orgid)
    except Exception as error:
        return CommonUtils.pass_error('address', 'get_ship_to', error)
    return CommonUtils.send_response(addresses)


@address.route('/billto/<int:custaccnt>/<int:orgid>/',
               methods=['GET'])
def get_bill_to(custaccnt, orgid):
    try:
        addresses = Address.get_allbillto_address(custaccnt, orgid)
    except Exception as error:
        return CommonUtils.pass_error('address', 'get_bill_to', error)
    return CommonUtils.send_response(addresses)


@address.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@address.after_request
@LogUtil.after_request
def after_request(response):
    return response
