from flask import Blueprint, Response, request
from finapi.models.activityplanner.activityplanner import ActivityPlanner
from finapi.plugins import auth
from finapi.utils.common_utils import CommonUtils
import ujson
from finapi.utils.logdata import logger

activityplanner = Blueprint('activityplanner', __name__,
                            url_prefix='/activityplanner')


# Insert a new task
@activityplanner.route('/task/add/', methods=['POST'])
def task_add():
    logger.addinfo('@ [POST] views - activityplanner - task_add(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.task_add(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'task_add', e)
    logger.addinfo('@ [POST] views - activityplanner - task_add(+)')
    return response


# Update a task
@activityplanner.route('/task/update/', methods=['POST'])
def task_update():
    logger.addinfo('@ [POST] views - activityplanner - task_update(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.task_update(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'task_update', e)
    logger.addinfo('@ [POST] views - activityplanner - task_update(+)')
    return response


# Map task & trip
@activityplanner.route('/link/', methods=['POST'])
def trip_task_link():
    logger.addinfo('@ [POST] views - activityplanner - trip_task_link(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.trip_task_link(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'trip_task_link', e)
    logger.addinfo('@ [POST] views - activityplanner - trip_task_link(+)')
    return response


# UnMap task & trip
@activityplanner.route('/unlink/', methods=['POST'])
def trip_task_unlink():
    logger.addinfo('@ [POST] views - activityplanner - trip_task_unlink(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.trip_task_unlink(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'trip_task_unlink', e)
    logger.addinfo('@ [POST] views - activityplanner - trip_task_unlink(+)')
    return response


# Summary of all trips and tasks based on dates
@activityplanner.route('/summary/', methods=['POST'])
@activityplanner.route('/summary/<int:user_id>/', methods=['GET'])
def trip_task_summary(user_id=None):
    logger.addinfo('@ [POST] views - activityplanner - trip_task_summary(-)')
    try:
        activity_obj = ActivityPlanner()
        if request.method == 'POST':
            req_data = ujson.loads(request.data)
            result = activity_obj.trip_task_summary(req_data)
        else:
            status = request.args.get('status')
            result = activity_obj.summary_based_on_user_id(user_id, status)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'trip_task_summary', e)
    logger.addinfo('@ [POST] views - activityplanner - trip_task_summary(+)')
    return response


# get trip/task based on ids
@activityplanner.route('/details/task/<int:task_id>/', methods=['GET'])
@activityplanner.route('/details/trip/<int:trip_id>/', methods=['GET'])
def get_task_trip_details(task_id=None, trip_id=None):
    logger.addinfo('@ [GET] views - activityplanner - get_task_trip_details(-)')
    try:
        activity_obj = ActivityPlanner()
        if task_id:
            result = activity_obj.get_task_details(task_id)
        elif trip_id:
            result = activity_obj.get_trip_details(trip_id)
        else:
            result = {'status': 1, 'msg': 'Not a valid trip/task'}
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner',
                                      'get_task_trip_details', e)
    logger.addinfo('@ [GET] views - activityplanner - get_task_trip_details(+)')
    return response


# Activity planner google sync
@activityplanner.route('/google/sync/<int:user_id>', methods=['GET'])
def google_sync(user_id=None):
    logger.addinfo('@ [GET] views - activityplanner - google_sync(+)')
    try:
        trip_obj = ActivityPlanner()
        result = trip_obj.google_sync(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'google_sync', e)
    logger.addinfo('@ [GET] views - activityplanner - google_sync(+)')
    return response


# lov for managers and populating their employees
@activityplanner.route('/managers/reportees/', methods=['GET'])
@activityplanner.route('/managers/<int:user_id>/', methods=['GET'])
def get_managers_lov(user_id=None):
    logger.addinfo('@ [GET] views - activityplanner - get_managers_lov(-)')
    try:
        obj = ActivityPlanner()
        permission = request.args.get('permission')
        if request.path.find('reportees') != -1:
            result = obj.get_manager_reportees()
        else:
            result = obj.get_managers_lov(user_id, permission)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as error:
        return CommonUtils.pass_error('activityplanner', 'get_managers_lov', error)
    logger.addinfo('@ [GET] views - activityplanner - get_managers_lov(+)')
    return response


# get employee leaves based on dates and org_id
@activityplanner.route('/user/leavedates/', methods=['POST'])
def get_user_leaves():
    logger.addinfo('@ [POST] views - activityplanner - get_user_leaves(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.get_user_leaves(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'get_user_leaves', e)
    logger.addinfo('@ [POST] views - activityplanner - get_user_leaves(+)')
    return response


# submit flow, approval flow and rejection flow -- TODO
@activityplanner.route('/status/', methods=['POST'])
def change_status():
    logger.addinfo('@ [POST] views - activityplanner - change_status(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.change_status(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'change_status', e)
    logger.addinfo('@ [POST] views - activityplanner - change_status(+)')
    return response


# adds google calendars to relevant account
@activityplanner.route('/google/sync/add/', methods=['POST'])
def google_sync_add():
    """
    expects below json as input
    {
        user_id = 1,
        type = 'trip/task'
    }
    """
    logger.addinfo('@ [POST] views - activityplanner - google_sync_add(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.get_list_missing_events(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'google_sync_add', e)
    logger.addinfo('@ [POST] views - activityplanner - google_sync_add(+)')
    return response


# to Add a new trip
@activityplanner.route('/trip/add/', methods=['POST'])
def trip_add():
    logger.addinfo('@ [POST] views - activityplanner - trip_add(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.trip_add(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'trip_add', e)
    logger.addinfo('@ [POST] views - activityplanner - trip_add(+)')
    return response


# to update an existing trip
@activityplanner.route('/trip/update/', methods=['POST'])
def trip_update():
    logger.addinfo('@ [POST] views - activityplanner - trip_update(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.trip_update(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'trip_update', e)
    logger.addinfo('@ [POST] views - activityplanner - trip_update(+)')
    return response


# to get attachment details
@activityplanner.route('/attachment/', methods=['POST'])
@activityplanner.route('/attachment/<int:attachment_id>/', methods=['GET'])
def attachment_details(attachment_id=None):
    logger.addinfo('@ [GET] views - activityplanner - attachment_details(-)')
    try:
        if request.method == 'POST':
            obj = ActivityPlanner()
            req = ujson.loads(request.data)
            result = obj.add_attachment(req)
        else:
            result = ActivityPlanner.get_attachment_details(attachment_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'attachment_details',
                                      e)
    logger.addinfo('@ [GET] views - activityplanner - attachment_details(+)')
    return response


# Insert a comment in activity
@activityplanner.route('/comments/add/', methods=['POST'])
def add_comments():
    logger.addinfo('@ [POST] views - activityplanner - add_comments(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.add_comments(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'add_comments', e)
    logger.addinfo('@ [POST] views - activityplanner - add_comments(+)')
    return response


@activityplanner.route('/comments/<string:activity_type>/<int:activity_id>/', methods=['GET'])
@activityplanner.route('/chat/<int:user_id>/<string:status>/', methods=['GET'])
@activityplanner.route('/chat/', methods=['POST'])
def get_comments(activity_type=None, activity_id=None, user_id=None, status=None):
    """ Method to fetch comments of an activity
    or to fetch and create chat threads of a user """
    logger.addinfo('@ [GET, POST] views - activityplanner - get_comments(-)')
    try:
        activity_obj = ActivityPlanner()
        if request.method == 'POST':
            req_data = ujson.loads(request.data)
            result = ActivityPlanner.create_chat_thread(req_data)
        elif activity_type and activity_id:
            sort_order = request.args.get('sort')
            result = activity_obj.get_comments(activity_type, activity_id, sort_order)
        else:
            result = activity_obj.get_chat_threads(user_id, status)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'get_comments', e)
    logger.addinfo('@ [GET, POST] views - activityplanner - get_comments(+)')
    return response


# to delete comments or replies of an activity
@activityplanner.route('/comments/delete/<int:comment_id>/', methods=['GET'])
def delete_comment(comment_id=None):
    logger.addinfo('@ [GET] views - activityplanner - delete_comment(-)')
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.delete_comment(comment_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'delete_comment', e)
    logger.addinfo('@ [GET] views - activityplanner - delete_comment(+)')
    return response


@activityplanner.route('/delete/<string:activity_type>/<int:activity_id>/', methods=['DELETE'])
def delete_activity(activity_type=None, activity_id=None):
    """ Method to delete an activity and its dependencies """
    logger.addinfo('@ [GET] views - activityplanner - delete_activity(+)')
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.delete_activity(activity_type, activity_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'delete_activity', e)
    logger.addinfo('@ [GET] views - activityplanner - delete_activity(-)')
    return response


@activityplanner.route('/task/status/update/', methods=['POST'])
def update_task_status():
    logger.addinfo('@ [POST] views - activityplanner - update_task_status(+)')
    try:
        req = ujson.loads(request.data)
        obj = ActivityPlanner()
        result = obj.update_task_status(req)
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'update_task_status', e)
    logger.addinfo('@ [POST] views - activityplanner - update_task_status(-)')
    return Response(ujson.dumps(result), status=200,
                    mimetype='application/json')


@activityplanner.route('/task/tags/', methods=['GET'])
def get_task_tags():
    logger.addinfo('@ [GET] views - activityplanner - get_task_tags(+)')
    try:
        obj = ActivityPlanner()
        result = obj.get_task_tags()
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'get_task_tags', e)
    logger.addinfo('@ [GET] views - activityplanner - get_task_tags(-)')
    return Response(ujson.dumps(result), status=200,
                    mimetype='application/json')


@activityplanner.route('/subtask/', methods=['POST', 'PUT'])
@activityplanner.route('/subtask/<int:sub_task_id>/', methods=['DELETE'])
def add_or_update_sub_task(sub_task_id=None):
    logger.addinfo("""@ [POST, PUT, DELETE] views - 
    activityplanner - add_or_update_sub_task(-)""")
    try:
        activity_obj = ActivityPlanner()
        if request.method == 'POST':
            req_data = ujson.loads(request.data)
            result = activity_obj.add_sub_task(req_data)
        elif request.method == 'PUT':
            req_data = ujson.loads(request.data)
            result = activity_obj.update_sub_task(req_data)
        else:
            result = activity_obj.delete_sub_task(sub_task_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'add_or_update_sub_task', e)
    logger.addinfo("""@ [POST, PUT, DELETE] views - 
    activityplanner - add_or_update_sub_task(+)""")
    return response


@activityplanner.route('/collaborators/', methods=['POST'])
def add_or_delete_collaborators():
    """
    Method to add or delete collaborators for a task.

    Expects below json as input :
    {
        add_user_ids: [1, 2007],
        delete_user_ids: [1, 2007],
        task_id: 165,
        created_id: 1
    }
    """
    logger.addinfo('@ [POST] views - activityplanner - add_or_delete_collaborators(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.add_or_delete_collaborators(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'add_or_delete_collaborators', e)
    logger.addinfo('@ [POST] views - activityplanner - add_or_delete_collaborators(+)')
    return response


@activityplanner.route('/subtask/order/', methods=['POST'])
def update_sub_task_order():
    logger.addinfo('@ [POST] views - activityplanner - update_sub_task_order(-)')
    req_data = ujson.loads(request.data)
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.update_sub_task_order(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'update_sub_task_order', e)
    logger.addinfo('@ [POST] views - activityplanner - update_sub_task_order(+)')
    return response


@activityplanner.route('/log/<int:task_id>/', methods=['GET'])
@activityplanner.route('/log/', methods=['POST'])
def add_activity_log(task_id=None):
    logger.addinfo('@ [GET, POST] views - activityplanner - add_activity_log(-)')
    try:
        activity_obj = ActivityPlanner()
        if request.method == 'POST':
            req_data = ujson.loads(request.data)
            result = activity_obj.add_activity_log(req_data)
        else:
            result = activity_obj.get_activity_logs(task_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'add_activity_log', e)
    logger.addinfo('@ [GET, POST] views - activityplanner - add_activity_log(+)')
    return response


@activityplanner.route('/task/order/', methods=['POST'])
def update_task_order():
    logger.addinfo('@ [POST] views - activityplanner - update_task_order(-)')
    try:
        activity_obj = ActivityPlanner()
        req_data = ujson.loads(request.data)
        result = activity_obj.update_task_order(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'update_task_order', e)
    logger.addinfo('@ [POST] views - activityplanner - update_task_order(+)')
    return response


@activityplanner.route('/goal/<int:goal_id>/', methods=['GET', 'DELETE'])
@activityplanner.route('/goal/', methods=['POST', 'PUT'])
def manage_goals(goal_id=None):
    logger.addinfo("""@ [POST, PUT, GET, DELETE] views - 
    activityplanner - manage_goals(-)""")
    try:
        activity_obj = ActivityPlanner()
        if request.method == 'POST':
            req_data = ujson.loads(request.data)
            result = activity_obj.add_goal(req_data)
        elif request.method == 'PUT':
            req_data = ujson.loads(request.data)
            result = activity_obj.update_goal(req_data)
        elif request.method == 'GET':
            result = activity_obj.get_goal_details(goal_id)
        else:
            result = activity_obj.delete_goal(goal_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'manage_goals', e)
    logger.addinfo("""@ [POST, PUT, GET, DELETE] views - 
    activityplanner - manage_goals(+)""")
    return response


@activityplanner.route('/goal/link/', methods=['POST'])
def link_or_unlink_goal():
    logger.addinfo('@ [POST] views - activityplanner - link_or_unlink_goal(-)')
    try:
        activity_obj = ActivityPlanner()
        req_data = ujson.loads(request.data)
        result = activity_obj.link_or_unlink_goal(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'link_or_unlink_goal', e)
    logger.addinfo('@ [POST] views - activityplanner - link_or_unlink_goal(+)')
    return response


@activityplanner.route('/employees/', methods=['GET'])
@activityplanner.route('/map/managers/', methods=['POST'])
@activityplanner.route('/reportee/status/', methods=['POST'])
def map_managers_and_employees():
    logger.addinfo('@ [POST, GET] views - activityplanner - map_managers_and_employees(-)')
    try:
        activity_obj = ActivityPlanner()
        if request.method == 'POST':
            req_data = ujson.loads(request.data)
            if request.path.find('map') != -1:
                result = activity_obj.map_managers_and_employees(req_data)
            else:
                result = activity_obj.update_reportee_status(req_data)
        else:
            result = activity_obj.get_manager_employee_details()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'map_managers_and_employees', e)
    logger.addinfo('@ [POST, GET] views - activityplanner - map_managers_and_employees(+)')
    return response


@activityplanner.route('/tasks/<int:user_id>/', methods=['GET'])
def get_tasks_lov(user_id=None):
    logger.addinfo('@ [GET] views - activityplanner - get_tasks_lov(+)')
    try:
        activity_obj = ActivityPlanner()
        result = activity_obj.get_tasks_lov(user_id)
    except Exception as e:
        return CommonUtils.pass_error('activityplanner', 'get_tasks_lov', e)
    logger.addinfo('@ [GET] views - activityplanner - get_tasks_lov(-)')
    return Response(ujson.dumps(result), status=200,
                    mimetype='application/json')


@activityplanner.before_request
@auth.login_required
def before_request():
    pass
