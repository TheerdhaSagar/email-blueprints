import csv
import ujson

import redis
from flask import Blueprint, Response, request

from finapi.plugins import auth
from finapi.utils.log_util import LogUtil
from finapi.utils.common_utils import CommonUtils

metrics = Blueprint('metrics', __name__, url_prefix='/metrics')


@metrics.route('/cruscott/', methods=['POST'])
def get_ytd_data():
    try:
        req = ujson.loads(request.data)
        r = redis.StrictRedis(host='localhost', port=6379, db=2, decode_responses=True)
        summary = []
        for key in r.keys('C:*:' + req['period']):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_ytd_data', error)
    return Response(ujson.dumps(summary, False), status=200,
                    mimetype='application/json')


@metrics.route('/cruscott/salesChannel/', methods=['POST'])
def get_cruscott_data():
    try:
        req = ujson.loads(request.data)
        r = redis.StrictRedis(host='localhost', port=6379, db=2, decode_responses=True)
        summary = []
        pattern = 'CS:' + req['salesChannel'] + ':*:' + req['period']
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_cruscott_data', error)
    return Response(ujson.dumps(summary, True), status=200,
                    mimetype='application/json')


@metrics.route('/cruscott/channels/', methods=['GET'])
def get_cruscott_sales_channels():
    try:
        r = redis.StrictRedis(host='localhost', port=6379, db=1)
        data = r.zrange('SalesChannels', 0, -1)
        sales_channels = []
        for value in data:
            obj = dict()
            obj['group_name'] = value.decode('utf-8')
            sales_channels.append(obj)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_cruscott_sales_channels',
                                      error)
    return Response(ujson.dumps(sales_channels, True), status=200,
                    mimetype='application/json')


@metrics.route('/agents/revenue/', methods=['POST'])
def get_agent_data():
    try:
        req = ujson.loads(request.data)
        r = redis.StrictRedis(host='localhost', port=6379, db=3, decode_responses=True)
        summary = []
        if not req['agent_name']:
            pattern = 'RA:' + req['salesChannel'] + ':*:' + req['period']
        else:
            pattern = 'RA:' + req['salesChannel'] + ':' + req[
                'agent_name'] + ':' + req['period']
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_agent_data', error)
    return Response(ujson.dumps(summary, True), status=200,
                    mimetype='application/json')


@metrics.route('/periods/', methods=['GET'])
def get_periods():
    try:
        r = redis.StrictRedis(host='localhost', port=6379, db=1)
        data = r.zrange('Periods', 0, -1)
        periods = []
        for value in data:
            obj = dict()
            obj['period'] = value.decode('utf-8')
            periods.append(obj)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_periods', error)
    return Response(ujson.dumps(periods, True), status=200,
                    mimetype='application/json')


@metrics.route('/revenueBySales/', methods=['POST'])
def get_revenue_sales_network():
    try:
        req = ujson.loads(request.data)
        r = redis.StrictRedis(host='localhost', port=6379, db=5, decode_responses=True)
        summary = []
        pattern = 'SN:' + req['salesChannel'] + ':' + req['period']
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_revenue_sales_network',
                                      error)
    return Response(ujson.dumps(summary, True), status=200,
                    mimetype='application/json')


@metrics.route('/revenueByItems/', methods=['POST'])
def get_revenue_items():
    try:
        req = ujson.loads(request.data)
        summary = []
        if req['salesrep_id']:
            r = redis.StrictRedis(host='localhost', port=6379, db=7, decode_responses=True)
            pattern = 'RIA:' + req['salesChannel'] + ':' + req[
                'salesrep_id'] + ':*:'
        else:
            r = redis.StrictRedis(host='localhost', port=6379, db=6)
            pattern = 'RI:' + req['salesChannel'] + ':*:'
        pattern = pattern + req['period']
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_revenue_items', error)
    return Response(ujson.dumps(summary, True), status=200,
                    mimetype='application/json')


@metrics.route('/revenueBySegment/', methods=['POST'])
def get_revenue_segment():
    try:
        req = ujson.loads(request.data)
        summary = []
        if req['salesrep_id']:
            r = redis.StrictRedis(host='localhost', port=6379, db=8, decode_responses=True)
            pattern = 'RSA:' + req['salesChannel'] + ':' + req[
                'salesrep_id'] + ':*:'
        else:
            r = redis.StrictRedis(host='localhost', port=6379, db=4, decode_responses=True)
            pattern = 'RS:' + req['salesChannel'] + ':*:'
        pattern = pattern + req['period']
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_revenue_segment', error)
    return Response(ujson.dumps(summary, True), status=200,
                    mimetype='application/json')


@metrics.route('/revenueByBrand/', methods=['POST'])
def get_revenue_brand():
    try:
        req = ujson.loads(request.data)
        summary = []
        if req['salesrep_id']:
            r = redis.StrictRedis(host='localhost', port=6379, db=11, decode_responses=True)
            pattern = 'RBA:' + req['salesChannel'] + ':*:' + req[
                'salesrep_id'] + ':'
        elif req['cust_account_id']:
            r = redis.StrictRedis(host='localhost', port=6379, db=12, decode_responses=True)
            pattern = 'RBC:' + req['salesChannel'] + ':*:' + req[
                'cust_account_id'] + ':'
        else:
            r = redis.StrictRedis(host='localhost', port=6379, db=10, decode_responses=True)
            pattern = 'RB:' + req['salesChannel'] + ':*:'
        pattern = pattern + req['period']
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_revenue_brand', error)
    return Response(ujson.dumps(summary, True), status=200,
                    mimetype='application/json')


@metrics.route('/revenueByClass/', methods=['POST'])
def get_revenue_class():
    try:
        req = ujson.loads(request.data)
        r = redis.StrictRedis(host='localhost', port=6379, db=13, decode_responses=True)
        summary = []
        pattern = 'RC:' + req['salesChannel'] + ':*:' + req['period']
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_revenue_class', error)
    return Response(ujson.dumps(summary, True), status=200,
                    mimetype='application/json')


@metrics.route('/revenueByRegion/<string:sales_channel>/', methods=['GET'])
def get_revenue_sales_channel(sales_channel=None):
    try:
        r = redis.StrictRedis(host='localhost', port=6379, db=14, decode_responses=True)
        summary = []
        pattern = 'RR:' + sales_channel + ':*'
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_revenue_sales_channel',
                                      error)
    return Response(ujson.dumps(summary, True), status=200,
                    mimetype='application/json')


@metrics.route('/customerlist/', methods=['POST'])
def get_customer_list():
    file_name = 'Customer_List'
    columns = ['customer_number', 'customer_name', 'cust_price_list',
               'cust_terms', 'customer_class', 'credit_limit', 'email',
               'phone', 'billacc_address', 'billacc_city', 'store_locator']
    try:
        jsond = ujson.loads(request.data)
        r = redis.StrictRedis(host='localhost', port=6379, db=15, decode_responses=True)
        customers = []
        pattern = 'CL:'
        if jsond['sales_channel']:
            pattern = pattern + jsond['sales_channel'] + ':*:'
            file_name += '_' + jsond['sales_channel'].replace(' ', '_')
        else:
            pattern += '*:'
        if jsond['salesrep_id']:
            pattern = pattern + str(jsond['salesrep_id']) + ':'
            file_name += '_' + str(jsond['salesrep_id'])
        else:
            pattern += '*:'
        if jsond['org_id']:
            pattern += str(jsond['org_id'])
            file_name += '_' + str(jsond['org_id'])
        else:
            pattern += '*'
        for key in r.keys(pattern):
            data = r.hgetall(key)
            customers.append(data)
        build_excel(file_name, customers, columns)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_customer_list', error)
    return Response(ujson.dumps(customers[0:500], True), status=200,
                    mimetype='application/json')


@metrics.route('/salesAvg/', methods=['POST'])
def get_sales_avg_report():
    file_name = 'Sales_Average_Analysis'
    columns = ['customer_name', 'trx_number', 'trx_date', 'item_code',
               'segments', 'quantity_invoiced', 'line_amount', 'qty_in_pz',
               'pmv_actual', 'pmv_net', 'avg_sales_price_budget']
    try:
        req = ujson.loads(request.data)
        r = redis.StrictRedis(host='localhost', port=6379, db=2, decode_responses=True)
        summary = []
        pattern = 'SA:' + req['sales_channel'] + ':'
        file_name += '_' + req['sales_channel'].replace(' ', '_')
        file_name += '_' + req['period'].replace('/', '_')
        if req['customer_number']:
            pattern = pattern + req['customer_number'] + ':'
        else:
            pattern = pattern + '*:'
        if req['agent_name']:
            pattern = pattern + req['agent_name'] + ':'
            file_name += '_' + req['agent_name'].replace(' ', '_')
        else:
            pattern = pattern + '*:'
        if req['segment']:
            pattern = pattern + req['segment'] + ':'
            file_name += '_' + req['segment'].replace(' ', '_')
        else:
            pattern = pattern + '*:'
        if req['item_code']:
            pattern = pattern + req['item_code'] + ':'
        else:
            pattern = pattern + '*:'
        pattern = pattern + req['period']
        for key in r.keys(pattern):
            data = r.hgetall(key)
            summary.append(data)
        build_excel(file_name, summary, columns)
    except Exception as error:
        return CommonUtils.pass_error('metrics', 'get_sales_avg_report', error)
    return Response(ujson.dumps(summary[0:500], True), status=200,
                    mimetype='application/json')


def build_excel(file_name, data, columns):
    try:
        csv_data = []
        for i in range(len(data)):
            obj = {}
            for j in range(len(columns)):
                obj[columns[j]] = data[i][columns[j]]
            csv_data.append(obj)

        with open('/tmp/' + file_name + '.csv', 'w') as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=columns)
            writer.writeheader()
            for i in range(len(csv_data)):
                writer.writerow(csv_data[i])
    except Exception as error:
        CommonUtils.pass_error('metrics', 'build_excel', error)
        raise error


@metrics.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@metrics.after_request
@LogUtil.after_request
def after_request(response):
    return response
