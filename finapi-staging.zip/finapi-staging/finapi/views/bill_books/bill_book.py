import ujson
from flask import Blueprint, Response, request
from finapi.models.bill_books.bill_book import BillBook
from finapi.utils.logdata import logger
from finapi.plugins import auth
from finapi.utils.code_util import Code_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.log_util import LogUtil

billBook = Blueprint('billBook', __name__, url_prefix='/billBook')


@billBook.route('/accountid/<int:account_id>/<int:org_id>/',
                methods=['GET'])
@billBook.route('/<string:usr_id>/<int:org_id>/',
                methods=['GET'])
def get_All(usr_id=None, org_id=None, account_id=None):
    logger.addinfo('@ [GET] views - billbook - get_All(+)')
    final = {}
    if usr_id or account_id and org_id:
        try:
            bills = BillBook.show_all_bills(usr_id, org_id, account_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - billbook -
                 get_All """ + str(error.message))
            final['status'] = 1
            final['msg'] = str(error.message)
            return ujson.dumps(final)
        response = Response(ujson.dumps(bills), status=200,
                            mimetype='application/json')
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [GET] views - billbook - get_All(-)')
    return response


@billBook.route('/customer/<string:usr_id>/<int:org_id>/',
                methods=['GET'])
def get_bill_customer(usr_id=None, org_id=None, account_id=None):
    logger.addinfo('@ [GET] views - billbook - get_bill_customer(+)')
    final = {}
    if usr_id or account_id and org_id:
        try:
            bills = BillBook.show_bills_customer(usr_id, org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - billbook -
                 get_bill_customer """ + str(error.message))
            final['status'] = 1
            final['msg'] = str(error.message)
            return ujson.dumps(final)
        response = Response(ujson.dumps(bills), status=200,
                            mimetype='application/json')
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [GET] views - billbook - get_bill_customer(-)')
    return response


@billBook.route('/agent/<string:usr_id>/<int:org_id>/',
                methods=['GET'])
def get_bill_agent(usr_id=None, org_id=None, account_id=None):
    logger.addinfo('@ [GET] views - billbook - get_bill_agent(+)')
    final = {}
    if usr_id or account_id and org_id:
        try:
            bills = BillBook.show_bills_agent(usr_id, org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - billbook -
                 get_bill_agent """ + str(error.message))
            final['status'] = 1
            final['msg'] = str(error.message)
            return ujson.dumps(final)
        response = Response(ujson.dumps(bills), status=200,
                            mimetype='application/json')
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [GET] views - billbook - get_bill_agent(-)')
    return response


@billBook.route('/duedate/<string:usr_id>/<int:org_id>/',
                methods=['GET'])
def show_bills_duedate(usr_id=None, org_id=None, account_id=None):
    logger.addinfo('@ [GET] views - billbook - show_bills_duedate(+)')
    final = {}
    if usr_id or account_id and org_id:
        try:
            bills = BillBook.show_bills_duedate(usr_id, org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - billbook -
                 show_bills_duedate """ + str(error.message))
            final['status'] = 1
            final['msg'] = str(error.message)
            return ujson.dumps(final)
        response = Response(ujson.dumps(bills), status=200,
                            mimetype='application/json')
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [GET] views - billbook - show_bills_duedate(-)')
    return response


@billBook.route('/duedate/range/', methods=['POST'])
def show_bills_duedate_range():
    logger.addinfo('@ [POST] views - billbook - show_bills_duedate_range(+)')
    jsond = ujson.loads(request.data)
    final = {}
    if jsond:
        try:
            bills = BillBook.show_bills_duedate_range(jsond)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - billbook -
                 show_bills_duedate_range """ + str(error.message))
            final['status'] = 1
            final['msg'] = str(error.message)
            return ujson.dumps(final)
        response = Response(ujson.dumps(bills), status=200,
                            mimetype='application/json')
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [POST] views - billbook - show_bills_duedate_range(-)')
    return response


@billBook.route('/currency/<string:usr_id>/<int:org_id>/',
                methods=['GET'])
def show_bills_currency(usr_id=None, org_id=None, account_id=None):
    logger.addinfo('@ [GET] views - billbook - show_bills_currency(+)')
    final = {}
    if usr_id or account_id and org_id:
        try:
            bills = BillBook.show_bills_currency(usr_id, org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - billbook -
                 show_bills_currency """ + str(error.message))
            final['status'] = 1
            final['msg'] = str(error.message)
            return ujson.dumps(final)
        response = Response(ujson.dumps(bills), status=200,
                            mimetype='application/json')
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [GET] views - billbook - show_bills_currency(-)')
    return response


@billBook.route('/salesrep/<int:org_id>/<string:salerep_id>/',
                methods=['GET'])
def bills_customer_bySalesRep(org_id=None, salerep_id=None):
    logger.addinfo('@ [GET] views - billbook - bills_customer_bySalesRep(+)')
    final = {}
    if org_id and salerep_id:
        try:
            bills = BillBook.show_bill_customer_bySalesRep(org_id, salerep_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - billbook -
                 bills_customer_bySalesRep """ + str(error.message))
            final['status'] = 1
            final['msg'] = str(error.message)
            return ujson.dumps(final)
        response = Response(ujson.dumps(bills), status=200,
                            mimetype='application/json')
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [GET] views - billbook - bills_customer_bySalesRep(-)')
    return response


@billBook.route('/saleschannel/', methods=['GET'])
@billBook.route('/saleschannel/<string:user_id>/<int:org_id>/',
                methods=['GET'])
def get_saleschanel(user_id=None, org_id=None):
    logger.addinfo('@ [GET] views - billbook - get_saleschanel(+)')
    final = {}
    if user_id and org_id:
        try:
            sales_data = Code_util.get_saleschanel(user_id, org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - billbook -
                 get_saleschanel """ + str(error.message))
            final['status'] = 1
            final['msg'] = str(error.message)
            return ujson.dumps(final)
        response = Response(ujson.dumps(sales_data), status=200,
                            mimetype='application/json')
    else:
        result = BillBook.get_saleschannels()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [GET] views - billbook - get_saleschanel(-)')
    return response


@billBook.route('/saleschannel/', methods=['POST'])
def billbook_saleschannel():
    logger.addinfo('@ [POST] views - billbook - billbook_saleschannel(+)')
    final = {}
    try:
        data = BillBook.billbook_saleschannel(ujson.loads(request.data))
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - views - billbook -
                billbook_saleschannel """ + str(error.message))
        final['status'] = 1
        final['msg'] = str(error.message)
        return ujson.dumps(final)
    response = Response(ujson.dumps(data), status=200,
                        mimetype='application/json')
    logger.addinfo('@ [POST] views - billbook - billbook_saleschannel(-)')
    return response


@billBook.route('/notes/', methods=['POST'])
def update_billbook_notes():
    try:
        billbook_obj = BillBook()
        jsond = ujson.loads(request.data)
        result = billbook_obj.update_billbook_notes(jsond)
    except Exception as error:
        return CommonUtils.pass_error('billbook', 'update_billbook_notes', error)
    return CommonUtils.send_response(result)


@billBook.route('/notes/<int:customer_id>/', methods=['GET'])
def get_customer_notes_history(customer_id=None):
    try:
        result = BillBook().get_customer_notes_history(customer_id)
    except Exception as error:
        return CommonUtils.pass_error('billbook', 'update_billbook_notes', error)
    return CommonUtils.send_response(result)


@billBook.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@billBook.after_request
@LogUtil.after_request
def after_request(response):
    return response
