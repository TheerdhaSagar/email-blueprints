import os

from flask import request, current_app, g, jsonify
from flask_httpauth import HTTPBasicAuth
from itsdangerous import SignatureExpired, BadSignature
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from finapi.utils import db_util
from finapi.sql import sql_util

auth = HTTPBasicAuth()
modules = ['donation', 'recipes', 'professional', 'cms', 'supplier', 'pob']


@auth.verify_password
def verify_password(username_or_token, password):
    if current_app.config['USE_TOKEN_AUTH']:
        s = Serializer(current_app.config['SECRET_KEY'])
        connection = None
        cursor = None
        is_valid = True
        user = None
        try:
            try:
                path = request.path[1:]
                index = path.index('/')
                module = path[0:index]
            except ValueError:
                module = ''

            data = s.loads(username_or_token)

            connection = db_util.get_connection()
            if connection:
                cursor = connection.cursor()
                sql_file = sql_util.get_sql('generic')

            try:
                int(data['id'])
            except ValueError:
                is_valid = False

            if module in modules and not is_valid:
                if connection:
                    api_query = sql_file['api_auth_query']
                    cursor.execute(api_query, p_api_key=data['id'])
                is_valid = True
            else:
                if is_valid:
                    user_query = sql_file['user_auth_by_id_query']
                    cursor.execute(user_query, p_userid=data['id'])

            if is_valid:
                if connection:
                    user = cursor.fetchone()
                    g.username = user[0]
                    g.debug = user[3]
                else:
                    user = [os.environ.get('FIN_X_API_KEY')]
                    g.username = os.environ.get('FIN_X_API_KEY')
                    g.debug = 'N'
        except SignatureExpired:
            return False
        except BadSignature:
            return False
        except Exception as e:
            raise e
        finally:
            if cursor:
                cursor.close()
            if connection:
                db_util.release_connection(connection)
        if user and str(data['id']) == str(password):
            return True
        return False
    else:
        return False


@auth.error_handler
def unauthorized_error():
    response = jsonify({'status': 401, 'error': 'Unauthorized',
                        'msg': 'Please authenticate to access this API'})
    response.status_code = 401
    return response
