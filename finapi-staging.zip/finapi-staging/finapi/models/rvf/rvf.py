from finapi.sql import sql_util
from finapi.utils.log_util import LogUtil
from finapi.utils.constants import Status
from finapi.utils.conn_util import OracleConnectionManager


@LogUtil.class_module_logs('rvf-inventory')
class RVF(object):
    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def get_summary(self, item_type):
        """
        Fetch RVF Item details
        """
        summary = []
        item_filter = ''
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_rvf_summary']
            if item_type == 'FG':
                item_filter = self.sql_file['get_finished_goods']
            elif item_type == 'O':
                item_filter = self.sql_file['get_unfinished_goods']
            query = query.format(item_type_filter=item_filter)
            conn.execute(query)
            summary = conn.get_result()
        return {'status': Status.OK.value, 'summary': summary}

    def get_item_transactions(self, header_id):
        """
        Fetch all transactions or transaction_by_id
        @param: header_id: number
        """
        summary = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_rvf_transactions']
            if header_id:
                query = query.format(transaction_by_id=self.sql_file['get_rvf_transaction_by_id'])
                conn.execute(query, p_inventory_item_id=header_id)
            else:
                query = query.format(transaction_by_id='')
                conn.execute(query)
            summary = conn.get_result()
        return {'status': Status.OK.value, 'transactions': summary}

    @staticmethod
    def manage_transaction_details(jsond):
        """
        update or add a new transaction in temp table for the items
        @param jsond: {"rvf_transaction_id": "", "item_code": "", "inventory_item_id": "",
                        "transaction_date":"", "transaction_qty": "", "reason:": "",
                        "created_id":""}
        @return: { status: "", "msg":""}
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                qpex_rvf_pkg.manage_transaction(
                    :p_rvf_transaction_id,
                    :p_inventory_item_id,
                    :p_item_code,
                    :p_transaction_date,
                    :p_transaction_quantity,
                    :p_reason,
                    :p_created_id,
                    :x_status_code
                );
            END;
            """, output_key='x_status_code',
                         p_rvf_transaction_id=jsond['rvf_transaction_id'],
                         p_inventory_item_id=jsond['inventory_item_id'],
                         p_item_code=jsond['item_code'],
                         p_transaction_date=jsond['transaction_date'],
                         p_transaction_quantity=jsond['transaction_quantity'],
                         p_reason=jsond['reason'],
                         p_created_id=jsond['created_id'])
            conn.get_output_param(raise_exception=True, send_email=True)
        return {'status': Status.OK.value,
                'msg': 'Transaction for item {0} is {1} successfully'
                       .format(jsond['item_code'],
                               'updated'
                               if jsond['rvf_transaction_id'] != -1
                               else 'created')}

    @staticmethod
    def cancel_transaction(transaction_id):
        """
        Delete a transaction from temp file if you dont want to sync them in oracle
        @param transaction_id: number
        @return: { "status": "", "msg":"" }
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                            BEGIN
                                qpex_rvf_pkg.cancel_transaction(
                                    :p_rvf_transaction_id,
                                    :x_status_code
                                );
                            END;
                            """, output_key='x_status_code',
                         p_rvf_transaction_id=transaction_id)
            conn.get_output_param(raise_exception=True, send_email=True)
        return {'status': Status.OK.value, 'msg': 'Transaction details are deleted'}

    def sync_temp_transactions(self):
        """
        fetch all the transactions that are saved in temp transaction table
        """
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_temp_transactions']
            conn.execute(query)
            result = conn.get_result()
        return {'status': Status.OK.value, 'transactions': result}

    @staticmethod
    def sync_with_oracle():
        """
        For syncing the temporary transactions to oracle tables
        """
        status = ''
        err_msg = ''
        with OracleConnectionManager() as conn:
            error_message = conn.set_output_param('STRING')
            conn.execute("""
            BEGIN
                qpex_rvf_pkg.sync_transactions(
                    :x_status_code,
                    :x_status_message
                );
            END;""", output_key='x_status_code', x_status_message=error_message)
            status = conn.get_output_param(raise_exception=False, send_email=True)
            err_msg = error_message.getvalue()
        if status == 'SUCCESS':
            return {'status': Status.OK.value, 'msg': 'Transactions are synced with oracle'}
        return {'status': Status.ERROR.value, 'msg': err_msg}

    def get_rvf_reasons(self):
        """
        Fetch Transaction Types from view table
        """
        result = []
        query = self.sql_file['get_rvf_reasons']
        with OracleConnectionManager() as conn:
            conn.execute(query)
            result = conn.get_result()
        return {'status': Status.OK.value, 'reasons': result}
