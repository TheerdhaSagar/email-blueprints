from finapi.utils import db_util
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil
from finapi.utils.logdata import logger


@LogUtil.class_module_logs('operating_units')
class OperatingUnit:

    def __init__(self):
        self.sqlfile = sql_util.get_sql(self.__class__.__name__.lower())

    #  used in cutomer to get operatingdetails of organization based on orgid
    @db_util.langs("American")
    def get_opr_details(self, porgid):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['operating_units_query']
            conn.execute(query, P_ORG_ID=porgid)
            result = conn.get_result()
        return result

    #  used in cutomer to get operatingdetails of organization
    @db_util.langs("American")
    def get_operating_details(self):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['all_operating_units_query']
            conn.execute(query)
            result = conn.get_result()
        return result

    #  used in cutomer to get saleschannels of organization
    @db_util.langs("American")
    def get_salesrep_list(self, sales_channel, org_id, user_id):
        with OracleConnectionManager() as conn:
            if sales_channel:
                query_name = 'salesrep_query_by_user_id' if user_id else 'salesrep_query'
                query = self.sqlfile[query_name]
                if user_id:
                    # get all salesrep for user and get agent name under the selected
                    # channel for those salesreps
                    sql_file = db_util.getSqlData()
                    query = query.format(salesreps=sql_file['salesrep_ids'])
                    conn.execute(query, p_sales_channel=sales_channel, user_id=user_id)
                else:
                    conn.execute(query, p_sales_channel=sales_channel)
            else:
                query = self.sqlfile['sales_agents_query']
                conn.execute(query, p_org_id=org_id)
            result = conn.get_result()
        return result

    #  used in cutomer to get operatingdetails of organization
    @db_util.langs("American")
    def get_customer_list(self, sales_channel):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['customers_salesrep_query']
            conn.execute(query, P_SALES_CHANNEL=sales_channel)
            result = conn.get_result()
        return result

    #  used in cutomer to get customers in saleschannel
    @db_util.langs("American")
    def get_segment_list(self, sales_channel):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['segments_query']
            conn.execute(query, P_SALES_CHANNEL=sales_channel)
            result = conn.get_result()
        return result

    #  used in cutomer to get items in sales channel
    @db_util.langs("American")
    def get_items_list(self, jsond):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['items_query']
            conn.execute(query, P_SALES_CHANNEL=jsond['sales_channel'],
                         P_SEGMENT=jsond['segment'])
            result = conn.get_result()
        return result

    @db_util.langs("American")
    def get_all_opr(self):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['all_opr_query']
            conn.execute(query)
            result = conn.get_result()
        return result

    @db_util.langs("American")
    def get_customers(self, sales_channel, jsond):
        with OracleConnectionManager() as conn:
            query_temp = self.sqlfile['cust_list_query']
            if len(jsond):
                salesrep_ids = ','.join(["'" + str(jsond[i]) + "'"
                                        for i in range(len(jsond))])
            else:
                logger.findaylog(
                    'models - operatingunutis - get_customers - Salesrep ids are not found')
                return {"status": 1, "msg": "Sales rep ids are not found"}
            query = query_temp % (salesrep_ids, sales_channel)
            conn.execute(query)
            result = conn.get_result()
        return result

    def get_brands_list(self, sales_channel):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['brands_query']
            conn.execute(query, P_SALES_CHANNEL=sales_channel)
            result = conn.get_result()
        return result

    def get_city_details(self, sales_channel):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['city_query']
            conn.execute(query, P_SALES_CHANNEL=sales_channel)
            result = conn.get_result()
        return result

    def get_province_details(self, sales_channel):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['province_query']
            conn.execute(query, P_SALES_CHANNEL=sales_channel)
            result = conn.get_result()
        return result

    def get_codice_centrale(self, sales_channel):
        with OracleConnectionManager() as conn:
            query = self.sqlfile['codice_centrale_query']
            conn.execute(query, P_SALES_CHANNEL=sales_channel)
            result = conn.get_result()
        return result
