from finapi.utils import db_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.constants import Status
from finapi.utils.log_util import LogUtil
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util
from finapi.utils import auth_util
from finapi.sql import sql_util
import cx_Oracle
import os
import random
import string


class Events:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    # create agent report
    def create_ambassador_visit(self, data):
        logger.addinfo('@ models - events - create_ambassador_visit(+)')
        try:
            self.acquire()
            report_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_ambassador_pkg.insert_agent(
                    :p_report_id,
                    :p_salesrep_id,
                    :p_agent_name,
                    :p_clinic_name,
                    :p_contact_person,
                    :p_address,
                    :p_visit_date,
                    :p_prescription,
                    :p_free_samples_qty,
                    :p_kit,
                    :p_comments,
                    :p_creation_date,
                    :p_cat_quantity,
                    :p_dog_quantity,
                    :p_status_code
                );
            end; """, p_report_id=report_id, p_salesrep_id=data['salesrep_id'],
                                p_agent_name=data['agent_name'],
                                p_clinic_name=data['clinic_name'],
                                p_contact_person=data['contact_person'],
                                p_address=data['address'],
                                p_visit_date=data['visit_date'],
                                p_prescription=data['prescription'],
                                p_free_samples_qty=data['free_samples_qty'],
                                p_kit=data['kit'],
                                p_comments=data['comments'],
                                p_creation_date=data['creation_date'],
                                p_cat_quantity=data['cat_samples'],
                                p_dog_quantity=data['dog_samples'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                result['report_id'] = report_id.getvalue()
                rid = report_id.getvalue()
                query = self.sql_file['delete_agent_clients']
                self.cursor.execute(query, P_REPORT_ID=rid)
                if data['clients']:
                    clients = data['clients']
                    for i in range(len(clients)):
                        self.insert_agent_cli(clients[i], rid)
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 60 EXCEPTION - models - events -
                 create_ambassador_visit """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - create_ambassador_visit(-)')
        return result

    # update agent report
    def update_ambassador_visit(self, data):
        logger.addinfo('@ models - events - update_ambassador_visit(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_ambassador_pkg.update_agent(
                    :p_report_id,
                    :p_agent_name,
                    :p_clinic_name,
                    :p_contact_person,
                    :p_address,
                    :p_visit_date,
                    :p_prescription,
                    :p_free_samples_qty,
                    :p_kit,
                    :p_comments,
                    :p_cat_quantity,
                    :p_dog_quantity,
                    :p_status_code
                );
            end; """, p_report_id=data['report_id'],
                                p_agent_name=data['agent_name'],
                                p_clinic_name=data['clinic_name'],
                                p_contact_person=data['contact_person'],
                                p_address=data['address'],
                                p_visit_date=data['visit_date'],
                                p_prescription=data['prescription'],
                                p_free_samples_qty=data['free_samples_qty'],
                                p_kit=data['kit'],
                                p_comments=data['comments'],
                                p_cat_quantity=data['cat_samples'],
                                p_dog_quantity=data['dog_samples'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                rid = data['report_id']
                query = self.sql_file['delete_agent_clients']
                self.cursor.execute(query, P_REPORT_ID=rid)
                if data['clients']:
                    clients = data['clients']
                    for i in range(len(clients)):
                        self.insert_agent_cli(clients[i], rid)
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 114 EXCEPTION - models - events -
                 update_ambassador_visit """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - update_ambassador_visit(-)')
        return result

    # delete agent report
    def delete_ambassador_visit(self, report_id):
        logger.addinfo('@ models - events - delete_ambassador_visit(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_ambassador_pkg.delete_agent(
                    :p_report_id,
                    :p_status_code
                );
            end; """, p_report_id=report_id, p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 145 EXCEPTION - models - events -
                 delete_ambassador_visit """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - delete_ambassador_visit(-)')
        return result

    # ambassador visit summary
    def get_visit_summary(self, salesrep_id, data):
        logger.addinfo('@ models - events - get_visit_summary(+)')
        start_date = None
        end_date = None
        result = []
        try:
            self.acquire()
            query = self.sql_file['ambassador_visit_query']
            if not salesrep_id and data:
                salesrep_id = data['salesrep_id']
                start_date = data['start_date']
                end_date = data['end_date']
            self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                P_START_DATE=start_date,
                                P_END_DATE=end_date)
        except Exception as error:
            logger.findaylog("""@ 169 EXCEPTION - models - events -
                 get_visit_summary """ + str(error))
            raise error
        else:
            result = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - events - get_visit_summary(-)')
        return result

    # insert agent clients
    def insert_agent_cli(self, data, rid):
        logger.addinfo('@ models - events - insert_agent_cli(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
             qpex_ambassador_pkg.insert_agent_cli(
                 :p_report_id,
                 :p_cust_account_id,
                 :p_customer_name,
                 :p_creation_date,
                 :p_status_code
             );
             end; """, p_report_id=rid,
                                p_cust_account_id=data['cust_account_id'],
                                p_customer_name=data['customer_name'],
                                p_creation_date=data['creation_date'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 252 EXCEPTION - models - events -
                 insert_agent_cli """ + str(error))
            raise error
        logger.addinfo('@ models - events - insert_agent_cli(-)')
        return result

    # create event
    def create_event(self, data):
        logger.addinfo('@ models - events - create_event(+)')
        try:
            self.acquire()
            event_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.insert_event(
                    :p_event_id,
                    :p_event_name,
                    :p_event_date,
                    :p_status,
                    :p_cust_account_id,
                    :p_customer_name,
                    :p_party_site_id,
                    :p_address_1,
                    :p_address_2,
                    :p_created_by,
                    :p_last_updated_by,
                    :p_salesrep_id,
                    :p_hostess_id,
                    :p_org_id,
                    :p_customer_email,
                    :p_customer_phone,
                    :p_agency_id,
                    :p_hostess_verified,
                    :p_compenso_hostess,
                    :p_status_code
                );
            end; """, p_event_id=event_id, p_event_name=data['event_name'],
                                p_event_date=data['event_date'],
                                p_status=data['status'],
                                p_cust_account_id=data['cust_account_id'],
                                p_customer_name=data['customer_name'],
                                p_party_site_id=data['party_site_id'],
                                p_address_1=data['address_1'],
                                p_address_2=data['address_2'],
                                p_created_by=data['created_by'],
                                p_last_updated_by=data['last_updated_by'],
                                p_salesrep_id=data['salesrep_id'],
                                p_hostess_id=data['hostess_id'],
                                p_org_id=data['org_id'],
                                p_customer_email=data['customer_email'],
                                p_customer_phone=data['customer_phone'],
                                p_agency_id=data['agency_id'],
                                p_hostess_verified=data['hostess_verified'],
                                p_compenso_hostess=data['compenso_hostess'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                eid = event_id.getvalue()
                result['event_id'] = eid
                if data['objectives']:
                    obj = data['objectives']
                    for i in range(len(obj)):
                        self.create_event_objective(obj[i], eid)
                if data['gifts']:
                    gifts = data['gifts']
                    for i in range(len(gifts)):
                        self.create_event_gift(gifts[i], eid)
                self.connection.commit()
                result['msg'] = 'Event created successfully'
                result['status'] = Status.OK.value
                mail_data = {}
                mail_data['event_id'] = eid
                mail_data['created_by'] = data['created_by']
                mail_data['creation_date'] = data['creation_date']
                mail_data['hostess_name'] = data['hostess_name']
                mail_data['event_status'] = 'created a new event'
                mail_data['mail_status'] = 'created'
                mail_data['customer_name'] = data['customer_name']
                mail_data['event_name'] = data['event_name']
                mail_data['hostess_id'] = ''
                mail_data['event_date'] = data['event_date']
                creation_mail = self.event_creation_mail(mail_data)
                if creation_mail != 'success':
                    result['msg'] += ' and ' + creation_mail
            else:
                result['msg'] = 'Event creation failed'
                result['status'] = Status.ERROR.value
        except Exception as error:
            logger.findaylog("""@ 319 EXCEPTION - models - events -
                 create_event """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - events - create_event(-)')
        return result

    # update event
    def update_event(self, data):
        logger.addinfo('@ models - events - update_event(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.update_event(
                    :p_event_id,
                    :p_event_name,
                    :p_event_date,
                    :p_status,
                    :p_cust_account_id,
                    :p_customer_name,
                    :p_party_site_id,
                    :p_address_1,
                    :p_address_2,
                    :p_last_updated_by,
                    :p_salesrep_id,
                    :p_hostess_id,
                    :p_org_id,
                    :p_customer_email,
                    :p_customer_phone,
                    :p_agency_id,
                    :p_hostess_verified,
                    :p_compenso_hostess,
                    :p_status_code
                );
            end; """, p_event_id=data['event_id'],
                                p_event_name=data['event_name'],
                                p_event_date=data['event_date'],
                                p_status=data['status'],
                                p_cust_account_id=data['cust_account_id'],
                                p_customer_name=data['customer_name'],
                                p_party_site_id=data['party_site_id'],
                                p_address_1=data['address_1'],
                                p_address_2=data['address_2'],
                                p_last_updated_by=data['last_updated_by'],
                                p_salesrep_id=data['salesrep_id'],
                                p_hostess_id=data['hostess_id'],
                                p_org_id=data['org_id'],
                                p_customer_email=data['customer_email'],
                                p_customer_phone=data['customer_phone'],
                                p_agency_id=data['agency_id'],
                                p_hostess_verified=data['hostess_verified'],
                                p_compenso_hostess=data['compenso_hostess'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                eid = data['event_id']
                if data['objectives']:
                    obj = data['objectives']
                    for i in range(len(obj)):
                        code = obj[i]['operation_code']
                        if code == 'UPDATE':
                            self.update_event_objective(obj[i])
                        elif code == 'CREATE':
                            self.create_event_objective(obj[i], eid)
                        elif code == 'DELETE':
                            obj_id = obj[i]['event_objective_id']
                            self.delete_event_objective(eid, obj_id)
                if data['gifts']:
                    gifts = data['gifts']
                    for i in range(len(gifts)):
                        code = gifts[i]['operation_code']
                        if code == 'UPDATE':
                            self.update_event_gift(gifts[i])
                        elif code == 'CREATE':
                            self.create_event_gift(gifts[i], eid)
                        elif code == 'DELETE':
                            self.delete_event_gift(gifts[i]['event_gift_id'])
                self.connection.commit()
                result['msg'] = 'Event updated successfully'
                result['status'] = Status.OK.value
                mail_data = {}
                mail_data['event_id'] = data['event_id']
                mail_data['created_by'] = data['last_updated_by']
                mail_data['creation_date'] = data['last_updated_date']
                mail_data['hostess_name'] = data['hostess_name']
                mail_data['event_status'] = 'updated event'
                mail_data['mail_status'] = 'updated'
                mail_data['customer_name'] = data['customer_name']
                mail_data['event_name'] = data['event_name']
                mail_data['hostess_id'] = ''
                mail_data['event_date'] = data['event_date']
                creation_mail = self.event_creation_mail(mail_data)
                if creation_mail != 'success':
                    result['msg'] += ' and ' + creation_mail
            else:
                result['msg'] = 'Failed to update event'
                result['status'] = Status.ERROR.value
        except Exception as error:
            logger.findaylog("""@ 381 EXCEPTION - models - events -
                 update_event """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - events - update_event(-)')
        return result

    # delete event
    def delete_event(self, jsond):
        logger.addinfo('@ models - events - delete_event(+)')
        try:
            self.acquire()
            event_id = jsond['event_id']
            query = self.sql_file['delete_event_query']
            self.cursor.execute(query, p_event_id=event_id)
            # status_code = cursor.var(cx_Oracle.STRING)
            # cursor.execute("""
            # begin
            #     qpex_event_pkg.delete_event(
            #         :p_event_id,
            #         :p_status_code
            #     );
            # end; """, p_event_id=event_id, p_status_code=status_code)
            # result = {}
            # if status_code.getvalue() == 'SUCCESS':
            #     result['msg'] = 'SUCCESS'
            mail_data = {}
            mail_data['event_id'] = event_id
            mail_data['created_by'] = jsond['deleted_by']
            mail_data['creation_date'] = jsond['date']
            mail_data['hostess_name'] = jsond['hostess_name']
            mail_data['event_status'] = 'deleted event'
            mail_data['mail_status'] = 'deleted'
            mail_data['customer_name'] = jsond['customer_name']
            mail_data['event_name'] = jsond['event_name']
            mail_data['hostess_id'] = jsond['hostess_id']
            mail_data['event_date'] = jsond['event_date']
            self.event_creation_mail(mail_data)
            # else:
            #     result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 398 EXCEPTION - models - events -
                 delete_event """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - delete_event(-)')
        return 'success'

    # create event target
    def create_event_target(self, data, eid, obj_id):
        logger.addinfo('@ models - events - create_event_target(+)')
        try:
            event_target_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.insert_event_target(
                    :p_event_target_id,
                    :p_event_id,
                    :p_objective_id,
                    :p_item_id,
                    :p_target_qty,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_event_target_id=event_target_id,
                                p_event_id=eid,
                                p_objective_id=obj_id,
                                p_item_id=data['item_id'],
                                p_target_qty=data['target_qty'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                result['event_target_id'] = event_target_id.getvalue()
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 450 EXCEPTION - models - events -
                 create_event_target """ + str(error))
            raise error
        logger.addinfo('@ models - events - create_event_target(-)')
        return result

    # update event target
    def update_event_target(self, data):
        logger.addinfo('@ models - events - update_event_target(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.update_event_target(
                    :p_event_target_id,
                    :p_event_id,
                    :p_objective_id,
                    :p_item_id,
                    :p_target_qty,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_event_target_id=data['event_target_id'],
                                p_event_id=data['event_id'],
                                p_objective_id=data['event_objective_id'],
                                p_item_id=data['item_id'],
                                p_target_qty=data['target_qty'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 496 EXCEPTION - models - events -
                 update_event_target """ + str(error))
            raise error
        logger.addinfo('@ models - events - update_event_target(-)')
        return result

    # delete event target
    def delete_event_target(self, event_target_id):
        logger.addinfo('@ models - events - delete_event_target(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.delete_event_target(
                    :p_event_target_id,
                    :p_status_code
                );
            end; """, p_event_target_id=event_target_id,
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 529 EXCEPTION - models - events -
                 delete_event_target """ + str(error))
            raise error
        logger.addinfo('@ models - events - delete_event_target(-)')
        return result

    # create event gift
    def create_event_gift(self, data, eid):
        logger.addinfo('@ models - events - create_event_gift(+)')
        try:
            event_gift_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.insert_event_gift(
                    :p_event_gift_id,
                    :p_event_id,
                    :p_objective_id,
                    :p_value,
                    :p_currency,
                    :p_vouchers,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_event_gift_id=event_gift_id,
                                p_event_id=eid,
                                p_objective_id=data['objective_id'],
                                p_value=data['value'],
                                p_currency=data['currency'],
                                p_vouchers=data['vouchers'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                result['event_gift_id'] = event_gift_id.getvalue()
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 583 EXCEPTION - models - events -
                 create_event_gift """ + str(error))
            raise error
        logger.addinfo('@ models - events - create_event_gift(-)')
        return result

    # update event gift
    def update_event_gift(self, data):
        logger.addinfo('@ models - events - update_event_gift(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.update_event_gift(
                    :p_event_gift_id,
                    :p_event_id,
                    :p_objective_id,
                    :p_value,
                    :p_currency,
                    :p_vouchers,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_event_gift_id=data['event_gift_id'],
                                p_event_id=data['event_id'],
                                p_objective_id=data['objective_id'],
                                p_value=data['value'],
                                p_currency=data['currency'],
                                p_vouchers=data['vouchers'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 631 EXCEPTION - models - events -
                 update_event_gift """ + str(error))
            raise error
        logger.addinfo('@ models - events - update_event_gift(-)')
        return result

    # delete event gift
    def delete_event_gift(self, event_gift_id):
        logger.addinfo('@ models - events - delete_event_gift(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.delete_event_gift(
                    :p_event_gift_id,
                    :p_status_code
                );
            end; """, p_event_gift_id=event_gift_id, p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 664 EXCEPTION - models - events -
                 delete_event_gift """ + str(error))
            raise error
        logger.addinfo('@ models - events - delete_event_gift(-)')
        return result

    # create stand
    def create_stand(self, data):
        logger.addinfo('@ models - events - create_stand(+)')
        try:
            self.acquire()
            stand_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.insert_stand(
                    :p_stand_id,
                    :p_stand_name,
                    :p_current_location,
                    :p_next_available_date,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_stand_id=stand_id,
                                p_stand_name=data['stand_name'],
                                p_current_location=data['current_location'],
                                p_next_available_date=data[
                                                        'next_available_date'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                result['stand_id'] = stand_id.getvalue()
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 715 EXCEPTION - models - events -
                 create_stand """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - create_stand(-)')
        return result

    # update stand
    def update_stand(self, data):
        logger.addinfo('@ models - events - update_stand(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.update_stand(
                    :p_stand_id,
                    :p_stand_name,
                    :p_current_location,
                    :p_next_available_date,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_stand_id=data['stand_id'],
                                p_stand_name=data['stand_name'],
                                p_current_location=data['current_location'],
                                p_next_available_date=data[
                                                        'next_available_date'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 759 EXCEPTION - models - events -
                 update_stand """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - update_stand(-)')
        return result

    # delete stand
    def delete_stand(self, stand_id):
        logger.addinfo('@ models - events - delete_stand(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.delete_stand(
                    :p_stand_id,
                    :p_status_code
                );
            end; """, p_stand_id=stand_id, p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 792 EXCEPTION - models - events -
                 delete_stand """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - delete_stand(-)')
        return result

    # create stand header
    def create_stand_hdr(self, data):
        logger.addinfo('@ models - events - create_stand_hdr(+)')
        try:
            self.acquire()
            reserve_hdr_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.insert_stand_hdr(
                    :p_reserve_hdr_id,
                    :p_stand_id,
                    :p_from_date,
                    :p_till_date,
                    :p_final_location,
                    :p_reserved_by,
                    :p_description,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status,
                    :p_status_code
                );
            end; """, p_reserve_hdr_id=reserve_hdr_id,
                                p_stand_id=data['stand_id'],
                                p_from_date=data['from_date'],
                                p_till_date=data['till_date'],
                                p_final_location=data['final_location'],
                                p_reserved_by=data['reserved_by'],
                                p_description=data['description'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status=data['status'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                rid = reserve_hdr_id.getvalue()
                result['reserve_hdr_id'] = rid
                if data['lines']:
                    lines = data['lines']
                    for i in range(len(lines)):
                        self.create_stand_line(lines[i], rid)
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 848 EXCEPTION - models - events -
                 create_stand_hdr """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - create_stand_hdr(-)')
        return result

    # update stand header
    def update_stand_hdr(self, data):
        logger.addinfo('@ models - events - update_stand_hdr(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.update_stand_hdr(
                    :p_reserve_hdr_id,
                    :p_stand_id,
                    :p_from_date,
                    :p_till_date,
                    :p_final_location,
                    :p_reserved_by,
                    :p_description,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status,
                    :p_status_code
                );
            end; """, p_reserve_hdr_id=data['reserve_hdr_id'],
                                p_stand_id=data['stand_id'],
                                p_from_date=data['from_date'],
                                p_till_date=data['till_date'],
                                p_final_location=data['final_location'],
                                p_reserved_by=data['reserved_by'],
                                p_description=data['description'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status=data['status'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                if data['lines']:
                    lines = data['lines']
                    for i in range(len(lines)):
                        if lines[i]['operation_code'] == 'UPDATE':
                            self.update_stand_line(lines[i])
                        elif lines[i]['operation_code'] == 'CREATE':
                            rid = data['reserve_hdr_id']
                            self.create_stand_line(lines[i], rid)
                        elif lines[i]['operation_code'] == 'DELETE':
                            self.del_stand_line(lines[i]['reserve_line_id'])
                if (data['status'] == 'Closed' and
                        data['approval_status'] == ''):
                    self.connection.commit()
                    status_msg = self.cursor.var(cx_Oracle.STRING)
                    self.cursor.execute("""
                    begin
                        qpex_stand_appr_pkg.start_stand_process(
                            :p_request_id,
                            :x_return_status,
                            :x_return_msg
                        );
                    end; """, p_request_id=data['reserve_hdr_id'],
                                        x_return_status=status_code,
                                        x_return_msg=status_msg)
                    logger.findaylog('return status -- ' + str(status_code), send_email=False)
                    logger.findaylog('return msg -- ' + str(status_msg), send_email=False)
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 899 EXCEPTION - models - events -
                 update_stand_hdr """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - update_stand_hdr(-)')
        return result

    # delete stand hdr
    def delete_stand_hdr(self, reserve_hdr_id):
        logger.addinfo('@ models - events - delete_stand_hdr(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.delete_stand_hdr(
                    :p_reserve_hdr_id,
                    :p_status_code
                );
            end; """, p_reserve_hdr_id=reserve_hdr_id,
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 933 EXCEPTION - models - events -
                 delete_stand_hdr """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - delete_stand_hdr(-)')
        return result

    # create stand line
    def create_stand_line(self, data, rid):
        logger.addinfo('@ models - events - create_stand_line(+)')
        try:
            reserve_line_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.insert_stand_line(
                    :p_reserve_line_id,
                    :p_reserve_hdr_id,
                    :p_from_date,
                    :p_till_date,
                    :p_location,
                    :p_shipping_cost,
                    :p_assemble_cost,
                    :p_rental_cost,
                    :p_people_cost,
                    :p_other_cost,
                    :p_hostess_cost,
                    :p_agent_cost,
                    :p_justification,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_reserve_line_id=reserve_line_id,
                                p_reserve_hdr_id=rid,
                                p_from_date=data['from_date'],
                                p_till_date=data['till_date'],
                                p_location=data['location'],
                                p_shipping_cost=data['shipping_cost'],
                                p_assemble_cost=data['assemble_cost'],
                                p_rental_cost=data['rental_cost'],
                                p_people_cost=data['people_cost'],
                                p_other_cost=data['other_cost'],
                                p_hostess_cost=data['hostess_cost'],
                                p_agent_cost=data['agent_cost'],
                                p_justification=data['justification'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                line_id = reserve_line_id.getvalue()
                result['msg'] = 'SUCCESS'
                result['reserve_line_id'] = line_id
                if data['assemble']:
                    data['assemble']['reserve_hdr_id'] = rid
                    data['assemble']['reserve_line_id'] = line_id
                    self.create_attachment(data['assemble'])
                if data['rent']:
                    data['rent']['reserve_hdr_id'] = rid
                    data['rent']['reserve_line_id'] = line_id
                    self.create_attachment(data['rent'])
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 991 EXCEPTION - models - events -
                 create_stand_line """ + str(error))
            raise error
        logger.addinfo('@ models - events - create_stand_line(-)')
        return result

    # update stand line
    def update_stand_line(self, data):
        logger.addinfo('@ models - events - update_stand_line(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.update_stand_line(
                    :p_reserve_line_id,
                    :p_reserve_hdr_id,
                    :p_from_date,
                    :p_till_date,
                    :p_location,
                    :p_shipping_cost,
                    :p_assemble_cost,
                    :p_rental_cost,
                    :p_people_cost,
                    :p_other_cost,
                    :p_hostess_cost,
                    :p_agent_cost,
                    :p_justification,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_reserve_line_id=data['reserve_line_id'],
                                p_reserve_hdr_id=data['reserve_hdr_id'],
                                p_from_date=data['from_date'],
                                p_till_date=data['till_date'],
                                p_location=data['location'],
                                p_shipping_cost=data['shipping_cost'],
                                p_assemble_cost=data['assemble_cost'],
                                p_rental_cost=data['rental_cost'],
                                p_people_cost=data['people_cost'],
                                p_other_cost=data['other_cost'],
                                p_hostess_cost=data['hostess_cost'],
                                p_agent_cost=data['agent_cost'],
                                p_justification=data['justification'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                rid = data['reserve_hdr_id']
                line_id = data['reserve_line_id']
                if data['assemble']:
                    data['assemble']['reserve_hdr_id'] = rid
                    data['assemble']['reserve_line_id'] = line_id
                    self.create_attachment(data['assemble'])
                if data['rent']:
                    data['rent']['reserve_hdr_id'] = rid
                    data['rent']['reserve_line_id'] = line_id
                    self.create_attachment(data['rent'])
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1043 EXCEPTION - models - events -
                 update_stand_line """ + str(error))
            raise error
        logger.addinfo('@ models - events - update_stand_line(-)')
        return result

    # delete stand hdr
    def del_stand_line(self, reserve_line_id):
        logger.addinfo('@ models - events - del_stand_line(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.delete_stand_line(
                    :p_reserve_line_id,
                    :p_status_code
                );
            end; """, p_reserve_line_id=reserve_line_id,
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1077 EXCEPTION - models - events -
                 del_stand_line """ + str(error))
            raise error
        logger.addinfo('@ models - events - del_stand_line(-)')
        return result

    # stands summary
    def get_stands_details(self):
        logger.addinfo('@ models - events - get_stands_details(+)')
        try:
            self.acquire()
            query = self.sql_file['get_stands_details']
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor)[0]
        except Exception as e:
            logger.findaylog(""" @ 1137 EXCEPTION - models - events -
                             get_stands_details """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - events - get_stands_details(-)')
        return result

    # stands summary
    def get_stands(self):
        logger.addinfo('@ models - events - get_stands(+)')
        result = {}
        data = []
        try:
            self.acquire()
            query = self.sql_file['stands_query']
            self.cursor.execute(query)
            data = Code_util.iterate_data(self.cursor)
            result['stands'] = data
            query = self.sql_file['stand_reserve_dates']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1061 EXCEPTION - models - events -
                 get_stands """ + str(error))
            raise error
        else:
            reservations = Code_util.iterate_data(self.cursor)
            result['reservations'] = reservations
        finally:
            self.release()
        logger.addinfo('@ models - events - get_stands(-)')
        return result

    # stands reservations summary
    def get_stand_reservations(self, stand_id):
        logger.addinfo('@ models - events - get_stand_reservations(+)')
        result = []
        try:
            self.acquire()
            query = self.sql_file['stand_reservations_query']
            self.cursor.execute(query, P_STAND_ID=stand_id)
        except Exception as error:
            logger.findaylog("""@ 1093 EXCEPTION - models - events -
                 get_stand_reservations """ + str(error))
            raise error
        else:
            result = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - events - get_stand_reservations(-)')
        return result

    def get_reservation_details(self, reservation_id):
        logger.addinfo('@ models - events - get_reservation_details(+)')
        try:
            self.acquire()
            query = self.sql_file['get_reservation_details']
            self.cursor.execute(query, P_RESERVE_HDR_ID=reservation_id)
        except Exception as e:
            logger.findaylog(""" @ 1314 EXCEPTION - models - events -
                            get_reservation_details """ + str(e))
            raise e
        else:
            header = Code_util.iterate_data(self.cursor)[0]
        finally:
            self.release()
        logger.addinfo('@ models - events - get_reservation_details(-)')
        return header

    # reservations details
    def get_reservation(self, reservation_id):
        logger.addinfo('@ models - events - get_reservation(+)')
        header = None
        lines = []
        try:
            self.acquire()
            query = self.sql_file['reservation_hdr_query']
            self.cursor.execute(query, P_RESERVE_HDR_ID=reservation_id)
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                header = {}
                for i in range(len(fieldnames)):
                    header[fieldnames[i]] = row[i]
            query = self.sql_file['reservation_lines_query']
            self.cursor.execute(query, P_RESERVE_HDR_ID=reservation_id)
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                line = {}
                for i in range(len(fieldnames)):
                    line[fieldnames[i]] = row[i]
                lines.append(line)
            setattr(header, 'lines', lines)
        except Exception as error:
            logger.findaylog("""@ 1138 EXCEPTION - models - events -
                 get_reservation """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - events - get_reservation(-)')
        return header

    # events details
    def get_events(self, jsond):
        logger.addinfo('@ models - events - get_events(+)')
        result = []
        try:
            self.acquire()
            from_date = jsond['from_date'] if 'from_date' in jsond else None
            to_date = jsond['to_date'] if 'to_date' in jsond else None
            mfrom_date = jsond['mfrom_date'] if 'mfrom_date' in jsond else None
            mto_date = jsond['mto_date'] if 'mto_date' in jsond else None
            user_id = jsond['user_id'] if 'user_id' in jsond else None
            created_by = jsond['created_by'] if 'created_by' in jsond else None
            event_status = jsond[
                        'event_status'] if 'event_status' in jsond else None
            report_status = jsond[
                        'report_status'] if 'report_status' in jsond else None
            ptype = None
            if user_id:
                user_type = Code_util.get_usertype(user_id)
                ptype = user_type['type']
            if ptype and ptype == 'salesrep':
                salesid_qry = self.sql_file['salesrep_ids']
                self.cursor.execute(salesid_qry, user_id=user_id)
                ids = self.cursor.fetchall()
                length = len(ids)
                list_ids = []
                for count in range(length):
                    id = ids[count][0]
                    list_ids.append(id)
                query_temp = self.sql_file['events_summary_agent']
                hdr_query = query_temp % (',' . join(["'" +
                                          str(list_ids[i]) + "'"
                                          for i in range(len(list_ids))]))
                if report_status == 'REPORTED':
                    hdr_query += self.sql_file['events_summary_reported']
                elif report_status == 'NOT_REPORTED':
                    hdr_query += self.sql_file['events_summary_not_reported']
                if event_status == 'ACTIVE':
                    hdr_query += self.sql_file['events_summary_active']
                elif event_status == 'INACTIVE':
                    hdr_query += self.sql_file['events_summary_inactive']
                if from_date and to_date:
                    hdr_query += self.sql_file['events_summary_bydate']
                    if mfrom_date and mto_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_bydate']
                        self.cursor.execute(hdr_query, P_FROM_DATE=from_date,
                                            P_TO_DATE=to_date,
                                            P_MFROM_DATE=mfrom_date,
                                            P_MTO_DATE=mto_date)
                    elif mfrom_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_from']
                        self.cursor.execute(hdr_query, P_FROM_DATE=from_date,
                                            P_TO_DATE=to_date,
                                            P_MFROM_DATE=mfrom_date)
                    elif mto_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_todate']
                        self.cursor.execute(hdr_query, P_FROM_DATE=from_date,
                                            P_TO_DATE=to_date,
                                            P_MTO_DATE=mto_date)
                    else:
                        self.cursor.execute(hdr_query, P_FROM_DATE=from_date,
                                            P_TO_DATE=to_date)
                elif from_date:
                    if mfrom_date and mto_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_bydate']
                        self.cursor.execute(hdr_query, P_FROM_DATE=from_date,
                                            P_MFROM_DATE=mfrom_date,
                                            P_MTO_DATE=mto_date)
                    elif mfrom_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_from']
                        self.cursor.execute(hdr_query, P_FROM_DATE=from_date,
                                            P_MFROM_DATE=mfrom_date)
                    elif mto_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_todate']
                        self.cursor.execute(hdr_query, P_FROM_DATE=from_date,
                                            P_MTO_DATE=mto_date)
                    else:
                        hdr_query += self.sql_file['events_summary_fromdate']
                        self.cursor.execute(hdr_query, P_FROM_DATE=from_date)
                elif to_date:
                    if mfrom_date and mto_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_bydate']
                        self.cursor.execute(hdr_query,
                                            P_TO_DATE=to_date,
                                            P_MFROM_DATE=mfrom_date,
                                            P_MTO_DATE=mto_date)
                    elif mfrom_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_from']
                        self.cursor.execute(hdr_query,
                                            P_TO_DATE=to_date,
                                            P_MFROM_DATE=mfrom_date)
                    elif mto_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_todate']
                        self.cursor.execute(hdr_query,
                                            P_TO_DATE=to_date,
                                            P_MTO_DATE=mto_date)
                    else:
                        hdr_query += self.sql_file['events_summary_todate']
                        self.cursor.execute(hdr_query, P_TO_DATE=to_date)
                else:
                    if mfrom_date and mto_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_bydate']
                        self.cursor.execute(hdr_query,
                                            P_MFROM_DATE=mfrom_date,
                                            P_MTO_DATE=mto_date)
                    elif mfrom_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_from']
                        self.cursor.execute(hdr_query,
                                            P_MFROM_DATE=mfrom_date)
                    elif mto_date:
                        hdr_query += self.sql_file[
                                        'events_summary_modified_todate']
                        self.cursor.execute(hdr_query,
                                            P_MTO_DATE=mto_date)
                    else:
                        self.cursor.execute(hdr_query)
            else:
                query = self.sql_file['events_summary']
                if report_status == 'REPORTED':
                    query += self.sql_file['events_summary_reported']
                elif report_status == 'NOT_REPORTED':
                    query += self.sql_file['events_summary_not_reported']
                if event_status == 'ACTIVE':
                    query += self.sql_file['events_summary_active']
                elif event_status == 'INACTIVE':
                    query += self.sql_file['events_summary_inactive']
                if from_date and to_date:
                    query += self.sql_file['events_summary_bydate']
                    if mfrom_date and mto_date:
                        query += self.sql_file[
                                    'events_summary_modified_bydate']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_FROM_DATE=from_date,
                                            P_TO_DATE=to_date,
                                            P_MFROM_DATE=mfrom_date,
                                            P_MTO_DATE=mto_date)
                    elif mfrom_date:
                        query += self.sql_file['events_summary_modified_from']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_FROM_DATE=from_date,
                                            P_TO_DATE=to_date,
                                            P_MFROM_DATE=mfrom_date)
                    elif mto_date:
                        query += self.sql_file[
                                    'events_summary_modified_todate']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_FROM_DATE=from_date,
                                            P_TO_DATE=to_date,
                                            P_MTO_DATE=mto_date)
                    else:
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_FROM_DATE=from_date,
                                            P_TO_DATE=to_date)
                elif from_date:
                    query += self.sql_file['events_summary_fromdate']
                    if mfrom_date and mto_date:
                        query += self.sql_file[
                                    'events_summary_modified_bydate']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_FROM_DATE=from_date,
                                            P_MFROM_DATE=mfrom_date,
                                            P_MTO_DATE=mto_date)
                    elif mfrom_date:
                        query += self.sql_file['events_summary_modified_from']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_FROM_DATE=from_date,
                                            P_MFROM_DATE=mfrom_date)
                    elif mto_date:
                        query += self.sql_file[
                                    'events_summary_modified_todate']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_FROM_DATE=from_date,
                                            P_MTO_DATE=mto_date)
                    else:
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_FROM_DATE=from_date)
                elif to_date:
                    query += self.sql_file['events_summary_todate']
                    if mfrom_date and mto_date:
                        query += self.sql_file[
                                    'events_summary_modified_bydate']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_TO_DATE=to_date,
                                            P_MFROM_DATE=mfrom_date,
                                            P_MTO_DATE=mto_date)
                    elif mfrom_date:
                        query += self.sql_file['events_summary_modified_from']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_TO_DATE=to_date,
                                            P_MFROM_DATE=mfrom_date)
                    elif mto_date:
                        query += self.sql_file[
                                    'events_summary_modified_todate']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_TO_DATE=to_date,
                                            P_MTO_DATE=mto_date)
                    else:
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_TO_DATE=to_date)
                else:
                    if mfrom_date and mto_date:
                        query += self.sql_file[
                                    'events_summary_modified_bydate']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_MFROM_DATE=mfrom_date,
                                            P_MTO_DATE=mto_date)
                    elif mfrom_date:
                        query += self.sql_file[
                                    'events_summary_modified_from']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_MFROM_DATE=mfrom_date)
                    elif mto_date:
                        query += self.sql_file[
                                    'events_summary_modified_todate']
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by,
                                            P_MTO_DATE=mto_date)
                    else:
                        self.cursor.execute(query, P_HOSTESS_ID=user_id,
                                            P_USER_ID=created_by)
        except Exception as error:
            logger.findaylog("""@ 1138 EXCEPTION - models - events -
                 get_events """ + str(error))
            raise error
        else:
            response = {}
            result = Code_util.iterate_data(self.cursor)
            query = self.sql_file['get_target_quantities']
            self.cursor.execute(query)
            targets = Code_util.iterate_data(self.cursor)
            response['events'] = result
            response['targets'] = targets
        finally:
            self.release()
        logger.addinfo('@ models - events - get_events(-)')
        return response

    # event details
    def get_event_by_id(self, event_id):
        logger.addinfo('@ models - events - get_event_by_id(+)')
        header = None
        cur = None
        targets = []
        gifts = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['event_query']
            cursor.execute(query, P_EVENT_ID=event_id)
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                header = {}
                for index, fn in enumerate(fieldnames):
                    header[fn] = row[index]

            query = sql_file['event_objectives_query']
            cursor.execute(query, P_EVENT_ID=event_id)
            fieldnames = [a[0].lower() for a in cursor.description]
            objectives = []
            obj_ids = []
            for row in cursor:
                objective = {}
                for index, fn in enumerate(fieldnames):
                    if fn == 'event_objective_id':
                        obj_ids.append(row[index])
                    objective[fn] = row[index]
                objectives.append(objective)
            setattr(header, 'objectives', objectives)

            if len(obj_ids):
                query = sql_file['objective_targets_query']
                query = query % (',' . join([str(obj_ids[i])
                                 for i in range(len(obj_ids))]))
                cursor.execute(query)
                fieldnames = [a[0].lower() for a in cursor.description]
                for row in cursor:
                    target = {}
                    for index, fn in enumerate(fieldnames):
                        target[fn] = row[index]
                    targets.append(target)

            setattr(header, 'targets', targets)

            query = sql_file['event_gifts_query']
            cursor.execute(query, P_EVENT_ID=event_id)
            obj_ids = []
            fieldnames = [a[0].lower() for a in cursor.description]
            cur = connection.cursor()
            for row in cursor:
                gift = {}
                targets = []
                for index, fn in enumerate(fieldnames):
                    if fn == 'objective_id':
                        query = sql_file['objective_targets_query']
                        query = query % (row[index])
                        cur.execute(query)
                        fnames = [a[0].lower() for a in cur.description]
                        for t in cur:
                            target = {}
                            for indx, fname in enumerate(fnames):
                                target[fname] = t[indx]
                            targets.append(target)
                        gift['targets'] = targets
                    gift[fn] = row[index]
                gifts.append(gift)
            setattr(header, 'gifts', gifts)
        except Exception as error:
            logger.findaylog("""@ 1227 EXCEPTION - models - events -
                 get_event_by_id """ + str(error))
            raise error
        finally:
            cur.close()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - events - get_event_by_id(-)')
        return header

    def event_by_id(self, event_id):
        logger.addinfo('@ models - events - event_by_id(+)')
        try:
            self.acquire()
            query = self.sql_file['get_event_by_id']
            self.cursor.execute(query, P_EVENT_ID=event_id)
            header = Code_util.iterate_data(self.cursor)[0]
        except Exception as e:
            logger.findaylog(""" @ 1713 EXCEPTION - models - events -
                             event_by_id """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - events - get_event_by_id(-)')
        return header

    # create hostess report
    def create_hostess_report(self, data):
        logger.addinfo('@ models - events - create_hostess_report(+)')
        result = {'msg': 'SUCCESS'}
        try:
            self.acquire()
            report_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.insert_event_report(
                    :p_report_id,
                    :p_event_id,
                    :p_report_date,
                    :p_hostess_name,
                    :p_created_by,
                    :p_last_update_by,
                    :p_status,
                    :p_amount,
                    :p_discount,
                    :p_report_verified,
                    :p_verified_by,
                    :p_rimborso_extra,
                    :p_compenso_variable,
                    :p_total_compenso,
                    :p_note,
                    :p_status_code
                );
            end; """, p_report_id=report_id,
                                p_event_id=data['event_id'],
                                p_report_date=data['report_date'],
                                p_hostess_name=data['hostess_name'],
                                p_created_by=data['created_by'],
                                p_last_update_by=data['last_update_by'],
                                p_status=data['status'],
                                p_amount=data['amount'],
                                p_discount=data['discount'],
                                p_report_verified=data['report_verified'],
                                p_verified_by=data['verified_by'],
                                p_rimborso_extra=data['rimborso_extra'],
                                p_compenso_variable=data['compenso_variable'],
                                p_total_compenso=data['total_compenso'],
                                p_note=data['note'],
                                p_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                result['report_id'] = report_id.getvalue()
                rid = int(result['report_id'])
                if data['objectives']:
                    obj = data['objectives']
                    for i in range(len(obj)):
                        if result['msg'] == 'SUCCESS':
                            objective_result = self.create_hostess_objective(
                                                        obj[i], rid)

                            if objective_result['msg'] != 'SUCCESS':
                                result['msg'] = 'ERROR'

                if data['gifts']:
                    gifts = data['gifts']
                    for i in range(len(gifts)):
                        if result['msg'] == 'SUCCESS':
                            gift_result = self.create_hostess_gift(
                                                    gifts[i], rid)
                            if gift_result['msg'] != 'SUCCESS':
                                result['msg'] = 'ERROR'

                if 'attachments' in data and (
                        len(data['attachments']) > 0) and (
                            result['msg'] == 'SUCCESS'):
                    return_value = self.attachment_save(data['attachments'],
                                                        rid)
                    if return_value.getvalue() == 'E':
                        logger.findaylog(
                            '@ models - events - attachment_save:{}'.format(
                                return_value.getvalue()))
                        result['msg'] = 'ERROR'
                if result['msg'] == 'SUCCESS':
                    self.send_email(data['event_id'], data['status'], rid)
            else:
                logger.findaylog(""" @ pkg - models - events -
                                 insert_event_report:{}
                                 """.format(data))
                result['msg'] = 'ERROR'
        except Exception as error:
            result['msg'] = 'ERROR'
            logger.findaylog("""@ 60 EXCEPTION - models - events -
                 create_hostess_report """ + str(error))
            raise error
        finally:
            if result['msg'] == 'SUCCESS':
                self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - create_hostess_report(-)')
        return result

    # create hostess target report
    def create_hostess_target(self, data, rid, oid):
        logger.addinfo('@ models - events - create_hostess_target(+)')
        try:
            target_report_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.insert_event_target_report(
                    :p_report_id,
                    :p_target_report_id,
                    :p_event_target_id,
                    :p_objective_report_id,
                    :p_event_id,
                    :p_item_id,
                    :p_target_qty,
                    :p_target_achieved,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_update_by,
                    :p_status_code
                );
            end; """, p_report_id=rid,
                                p_target_report_id=target_report_id,
                                p_event_target_id=data['event_target_id'],
                                p_objective_report_id=oid,
                                p_event_id=data['event_id'],
                                p_item_id=data['item_id'],
                                p_target_qty=data['target_qty'],
                                p_target_achieved=data['target_achieved'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_update_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                result['target_report_id'] = target_report_id.getvalue()
            else:
                logger.findaylog(""" @ pkg - models - events -
                                 insert_event_target_report:{}
                                 """.format(data))
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 60 EXCEPTION - models - events -
                 create_hostess_target """ + str(error))
            raise error
        logger.addinfo('@ models - events - create_hostess_target(-)')
        return result

    # create hostess gift report
    def create_hostess_gift(self, data, rid):
        logger.addinfo('@ models - events - create_hostess_gift(+)')
        try:
            gift_report_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.insert_event_gift_report(
                    :p_report_id,
                    :p_gift_report_id,
                    :p_event_gift_id,
                    :p_event_id,
                    :p_objective_id,
                    :p_value,
                    :p_currency,
                    :p_value_spent,
                    :p_vouchers,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_update_by,
                    :p_status_code
                );
            end; """, p_report_id=rid,
                                p_gift_report_id=gift_report_id,
                                p_event_gift_id=data['event_gift_id'],
                                p_event_id=data['event_id'],
                                p_objective_id=data['objective_id'],
                                p_value=data['value'],
                                p_currency=data['currency'],
                                p_value_spent=data['value_spent'],
                                p_vouchers=data['vouchers'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_update_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                eid = gift_report_id.getvalue()
                result['gift_report_id'] = eid
                if data['targets']:
                    targets = data['targets']
                    for i in range(len(targets)):
                        if result['msg'] == 'SUCCESS':
                            gift_result = self.create_gift_target(
                                                  targets[i], rid, eid)
                            if gift_result['msg'] != 'SUCCESS':
                                result['msg'] = 'ERROR'
            else:
                logger.findaylog(""" @ pkg - models - events -
                                 insert_event_gift_report: {}
                                 """.format(data))
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 60 EXCEPTION - models - events -
                 create_hostess_gift """ + str(error))
            raise error
        logger.addinfo('@ models - events - create_hostess_gift(-)')
        return result

    # create hostess gift report
    def create_gift_target(self, data, rid, eid):
        logger.addinfo('@ models - events - create_gift_target(+)')
        try:
            target_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.insert_event_gift_target(
                    :p_report_id,
                    :p_target_id,
                    :p_event_gift_id,
                    :p_event_id,
                    :p_item_id,
                    :p_value,
                    :p_currency,
                    :p_value_spent,
                    :p_vouchers,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_update_by,
                    :p_status_code
                );
            end; """, p_report_id=rid,
                                p_target_id=target_id,
                                p_event_gift_id=eid,
                                p_event_id=data['event_id'],
                                p_item_id=data['item_id'],
                                p_value=data['value'],
                                p_currency=data['currency'],
                                p_value_spent=data['value_spent'],
                                p_vouchers=data['vouchers'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_update_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                result['target_id'] = target_id.getvalue()
            else:
                logger.findaylog(""" @ pkg - models - events -
                                 insert_event_gift_target :{}
                                 """ .format(data))
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1608 EXCEPTION - models - events -
                 create_gift_target """ + str(error))
            raise error
        logger.addinfo('@ models - events - create_gift_target(-)')
        return result

    # ambassador visit summary
    def get_agent_clients(self, report_id):
        logger.addinfo('@ models - events - get_agent_clients(+)')
        result = []
        try:
            self.acquire()
            query = self.sql_file['agent_clients_query']
            self.cursor.execute(query, P_REPORT_ID=report_id)
        except Exception as error:
            logger.findaylog("""@ 169 EXCEPTION - models - events -
                 get_agent_clients """ + str(error))
            raise error
        else:
            result = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - events - get_agent_clients(-)')
        return result

    # hostess summary
    def get_hostess_summary(self, jsond):
        logger.addinfo('@ models - events - get_hostess_summary(+)')
        result = []
        try:
            self.acquire()
            query = self.sql_file['hostess_report_summary']
            try:
                from_date = jsond['from_date']
            except AttributeError:
                from_date = None
            try:
                to_date = jsond['to_date']
            except AttributeError:
                to_date = None

            if from_date and to_date:
                query = query + ' AND e.event_date between :P_FROM_DATE'
                query = query + ' AND :P_TO_DATE'
                self.cursor.execute(query, P_REPORT_ID=None,
                                    P_USER_ID=jsond['user_id'],
                                    P_FROM_DATE=from_date, P_TO_DATE=to_date)
            elif from_date:
                query = query + ' AND e.event_date >= :P_FROM_DATE'
                self.cursor.execute(query, P_REPORT_ID=None,
                                    P_USER_ID=jsond['user_id'],
                                    P_FROM_DATE=from_date)
            elif to_date:
                query = query + ' AND e.event_date <= :P_TO_DATE'
                self.cursor.execute(query, P_REPORT_ID=None,
                                    P_USER_ID=jsond['user_id'],
                                    P_TO_DATE=to_date)
            else:
                self.cursor.execute(query, P_REPORT_ID=None,
                                    P_USER_ID=jsond['user_id'])
            result = Code_util.iterate_data(self.cursor)
        except Exception as error:
            logger.findaylog("""@ 1456 EXCEPTION - models - events -
                 get_hostess_summary """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - events - get_hostess_summary(-)')
        return result

    def get_hostess_report_details(self, report_id):
        logger.addinfo('@ models - events - get_hostess_report_details(+)')
        try:
            self.acquire()
            query = self.sql_file['get_hostess_report_details']
            self.cursor.execute(query, P_REPORT_ID=report_id, P_USER_ID=None)
            report = Code_util.iterate_data(self.cursor)[0]
        except Exception as e:
            logger.findaylog(""" @ 2089 EXCEPTION - models - events -
                             get_hostess_report_details """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - events - get_hostess_report_details(-)')
        return report

    # hostess report
    def get_hostess_report(self, report_id):
        logger.addinfo('@ models - events - get_hostess_report(+)')
        result = None
        targets = []
        objectives = []
        gifts = []
        try:
            self.acquire()
            query = self.sql_file['hostess_report_summary']
            self.cursor.execute(query, P_REPORT_ID=report_id, P_USER_ID=None)
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                result = {}
                for i in range(len(fieldnames)):
                    result[fieldnames[i]] = row[i]

            query = self.sql_file['hostess_objectives_report']
            self.cursor.execute(query, P_REPORT_ID=report_id, P_USER_ID=None)
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                obj = {}
                for i in range(len(fieldnames)):
                    obj[fieldnames[i]] = row[i]
                objectives.append(obj)
            setattr(result, 'objectives', objectives)

            query = self.sql_file['hostess_target_report']
            self.cursor.execute(query, P_REPORT_ID=report_id, P_USER_ID=None)
            targets = Code_util.iterate_data(self.cursor)
            setattr(result, 'targets', targets)

            query = self.sql_file['hostess_gift_summary']
            self.cursor.execute(query, P_REPORT_ID=report_id, P_USER_ID=None)
            ids = []
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                gift = {}
                for i in range(len(fieldnames)):
                    if fieldnames[i] == 'gift_report_id':
                        ids.append(row[i])
                    gift[fieldnames[i]] = row[i]
                gifts.append(gift)
            setattr(result, 'gifts', gifts)

            targets = []
            if len(ids):
                query = self.sql_file['hostess_gift_targets']
                query = query % (',' . join([str(ids[i])
                                 for i in range(len(ids))]))
                self.cursor.execute(query, P_REPORT_ID=report_id)
                targets = Code_util.iterate_data(self.cursor)

            setattr(result, 'gift_targets', targets)
            query = self.sql_file['hostess_attachments']
            self.cursor.execute(query, p_attachseq=str(report_id))
        except Exception as error:
            logger.findaylog("""@ 1509 EXCEPTION - models - events -
                 get_hostess_report """ + str(error))
            raise error
        else:
            attachments = []
            attachmentsFn = [a[0].lower() for a in self.cursor.description]
            for attachment in self.cursor:
                attachment_data = {}
                for i in range(len(attachmentsFn)):
                    if attachmentsFn[i] == 'file_data':
                        attachment_data[
                                attachmentsFn[i]] = attachment[i].read()
                    else:
                        attachment_data[attachmentsFn[i]] = attachment[i]
                attachments.append(attachment_data)
            setattr(result, 'attachments', attachments)
        finally:
            self.release()
        logger.addinfo('@ models - events - get_hostess_report(-)')
        return result

    # update hostess report
    def update_hostess_report(self, data):
        logger.addinfo('@ models - events - update_hostess_report(+)')
        result = {'msg': 'SUCCESS'}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.update_event_report(
                    :p_report_id,
                    :p_event_id,
                    :p_report_date,
                    :p_hostess_name,
                    :p_last_update_by,
                    :p_status,
                    :p_amount,
                    :p_discount,
                    :p_report_verified,
                    :p_verified_by,
                    :p_approver,
                    :p_rimborso_extra,
                    :p_compenso_variable,
                    :p_total_compenso,
                    :p_note,
                    :p_status_code
                );
            end; """, p_report_id=data['report_id'],
                                p_event_id=data['event_id'],
                                p_report_date=data['report_date'],
                                p_hostess_name=data['hostess_name'],
                                p_last_update_by=data['last_update_by'],
                                p_status=data['status'],
                                p_amount=data['amount'],
                                p_discount=data['discount'],
                                p_report_verified=data['report_verified'],
                                p_verified_by=data['verified_by'],
                                p_approver=data['approver'],
                                p_rimborso_extra=data['rimborso_extra'],
                                p_compenso_variable=data['compenso_variable'],
                                p_total_compenso=data['total_compenso'],
                                p_note=data['note'],
                                p_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                if data['objectives']:
                    obj = data['objectives']
                    for i in range(len(obj)):
                        if result['msg'] == 'SUCCESS':
                            objective_result = self.update_hostess_objective(obj[i])
                            if objective_result['msg'] != 'SUCCESS':
                                result['msg'] = 'ERROR'

                if data['gifts']:
                    gifts = data['gifts']
                    for i in range(len(gifts)):
                        if result['msg'] == 'SUCCESS':
                            gifts_result = self.update_hostess_gift(
                                                gifts[i])
                            if gifts_result['msg'] != 'SUCCESS':
                                result['msg'] = 'ERROR'

                if data['deletedAttachments'] and result['msg'] == 'SUCCESS':
                    return_vaue = self.attachment_delete(
                                            data['deletedAttachments'])
                    if return_vaue.getvalue() != 'S':
                        logger.findaylog(
                            '@ models - update_hostess_report - attachment_delete:{}'.format(
                                return_vaue.getvalue()))
                        result['msg'] = 'ERROR'

                if 'attachments' in data and (
                        len(data['attachments']) > 0) and (
                            result['msg'] == 'SUCCESS'):
                    return_vaue = self.attachment_save(
                                        data['attachments'],
                                        data['report_id'])

                    if return_vaue.getvalue() == 'E':
                        logger.findaylog(
                            '@ models - update_hostess_report - attachment_save:{}'.format(
                                return_vaue.getvalue()))
                        result['msg'] = 'ERROR'

                if result['msg'] == 'SUCCESS' and data['send_email']:
                    self.send_email(data['event_id'], data['status'],
                                    data['report_id'])
            else:
                result['msg'] = 'ERROR'
                logger.findaylog(
                    '@ pkg - models - events - update_event_report:{}'.format(data))

        except Exception as error:
            result['msg'] = 'ERROR'
            logger.findaylog("""@ 1561 EXCEPTION - models - events -
                 update_hostess_report """ + str(error))
            raise error
        finally:
            if result['msg'] == 'SUCCESS':
                self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - update_hostess_report(-)')
        return result

    # create hostess target report
    def update_hostess_target(self, data):
        logger.addinfo('@ models - events - update_hostess_target(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.update_event_target_report(
                    :p_report_id,
                    :p_target_report_id,
                    :p_event_target_id,
                    :p_objective_report_id,
                    :p_event_id,
                    :p_item_id,
                    :p_target_qty,
                    :p_target_achieved,
                    :p_last_updated_date,
                    :p_last_update_by,
                    :p_status_code
                );
            end; """, p_report_id=data['report_id'],
                                p_target_report_id=data['target_report_id'],
                                p_event_target_id=data['event_target_id'],
                                p_objective_report_id=data[
                                                        'objective_report_id'],
                                p_event_id=data['event_id'],
                                p_item_id=data['item_id'],
                                p_target_qty=data['target_qty'],
                                p_target_achieved=data['target_achieved'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_update_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                logger.findaylog("""@ pkg - models - events -
                                 update_event_target_report:{} """.format(data))
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1609 EXCEPTION - models - events -
                 update_hostess_target """ + str(error))
            raise error
        logger.addinfo('@ models - events - update_hostess_target(-)')
        return result

    # update hostess gift report
    def update_hostess_gift(self, data):
        logger.addinfo('@ models - events - update_hostess_gift(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.update_event_gift_report(
                    :p_report_id,
                    :p_gift_report_id,
                    :p_event_gift_id,
                    :p_event_id,
                    :p_objective_id,
                    :p_value,
                    :p_currency,
                    :p_value_spent,
                    :p_vouchers,
                    :p_last_updated_date,
                    :p_last_update_by,
                    :p_status_code
                );
            end; """, p_report_id=data['report_id'],
                                p_gift_report_id=data['gift_report_id'],
                                p_event_gift_id=data['event_gift_id'],
                                p_event_id=data['event_id'],
                                p_objective_id=data['objective_id'],
                                p_value=data['value'],
                                p_currency=data['currency'],
                                p_value_spent=data['value_spent'],
                                p_vouchers=data['vouchers'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_update_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                if data['targets']:
                    targets = data['targets']
                    for i in range(len(targets)):
                        if result['msg'] == 'SUCCESS':
                            targets_result = self.update_gift_target(
                                                targets[i])

                            if targets_result['msg'] != 'SUCCESS':
                                result['msg'] = 'ERROR'
            else:
                logger.findaylog(
                    '@ pkg - models - events - update_event_gift_report:{}'.format(data))
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1657 EXCEPTION - models - events -
                 update_hostess_gift """ + str(error))
            raise error
        logger.addinfo('@ models - events - update_hostess_gift(-)')
        return result

    def create_attachment(self, data):
        logger.findaylog('@models - registration - create_attachment(+)', send_email=False)
        try:
            query = self.sql_file['delete_stand_line_docs']
            self.cursor.execute(query, P_RESERVE_ID=data['reserve_hdr_id'],
                                P_RESERVE_LINE_ID=data['reserve_line_id'],
                                P_TYPE=data['type'])
            document_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_filedata=cx_Oracle.BLOB)
            self.cursor.execute("""
            begin
                qpex_stand_pkg.insert_line_attachment (
                    :p_document_id,
                    :p_reserve_line_id,
                    :p_reserve_hdr_id,
                    :p_supplier_id,
                    :p_filetype,
                    :p_filename,
                    :p_filedata,
                    :p_filesize,
                    :p_created_by,
                    :p_last_updated_by,
                    :p_attachment_type,
                    :p_status_code
                );
            end; """, p_document_id=document_id,
                                p_reserve_line_id=data['reserve_line_id'],
                                p_reserve_hdr_id=data['reserve_hdr_id'],
                                p_supplier_id=data['supplier_id'],
                                p_filename=data['filename'],
                                p_filetype=data['filetype'],
                                p_filedata=data['base64'],
                                p_filesize=data['filesize'],
                                p_created_by=data['created_by'],
                                p_last_updated_by=data['last_updated_by'],
                                p_attachment_type=data['type'],
                                p_status_code=status_code)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1043 EXCEPTION - models - registration -
                create_attachment """ + str(error))
            raise error
        logger.findaylog('@models - registration - create_attachment(-)', send_email=False)
        return status_code.getvalue()

    def get_line_docs(self, hdr_id, line_id):
        logger.addinfo('@ models - supplier - get_line_docs(+)')
        try:
            self.acquire()
            query = self.sql_file['reserve_line_docs']
            self.cursor.execute(query, P_RESERVE_HDR_ID=hdr_id,
                                P_RESERVE_LINE_ID=line_id)
        except Exception as error:
            logger.findaylog("""@ 2252 EXCEPTION - models - supplier -
                 get_line_docs """ + str(error))
            raise error
        else:
            data = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                result = {}
                for i in range(len(field_names)):
                    if field_names[i] == 'filedata':
                        result[field_names[i]] = row[i].read()
                    else:
                        result[field_names[i]] = row[i]
                data.append(result)
        finally:
            self.release()
        logger.addinfo('@ models - supplier - get_line_docs(-)')
        return data

    # create event objective
    def create_event_objective(self, data, eid):
        logger.addinfo('@ models - events - create_event_objective(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.insert_event_objective(
                    :p_event_objective_id,
                    :p_event_id,
                    :p_objective_name,
                    :p_target_qty,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_event_objective_id=data['event_objective_id'],
                                p_event_id=eid,
                                p_objective_name=data['objective_name'],
                                p_target_qty=data['target_qty'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 450 EXCEPTION - models - events -
                 create_event_objective """ + str(error))
            raise error
        logger.addinfo('@ models - events - create_event_objective(-)')
        return result

    # update event objective
    def update_event_objective(self, data):
        logger.addinfo('@ models - events - update_event_objective(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.update_event_objective(
                    :p_event_objective_id,
                    :p_event_id,
                    :p_objective_name,
                    :p_target_qty,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status_code
                );
            end; """, p_event_objective_id=data['event_objective_id'],
                                p_event_id=data['event_id'],
                                p_objective_name=data['objective_name'],
                                p_target_qty=data['target_qty'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_updated_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 496 EXCEPTION - models - events -
                 update_event_objective """ + str(error))
            raise error
        logger.addinfo('@ models - events - update_event_objective(-)')
        return result

    # delete event objective
    def delete_event_objective(self, event_id, event_objective_id):
        logger.addinfo('@ models - events - delete_event_objective(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.delete_event_objective(
                    :p_event_id,
                    :p_event_objective_id,
                    :p_status_code
                );
            end; """, p_event_id=event_id,
                                p_event_objective_id=event_objective_id,
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                result['msg'] = 'ERROR'
        except Exception as error:
            logger.findaylog("""@ 529 EXCEPTION - models - events -
                 delete_event_objective """ + str(error))
            raise error
        logger.addinfo('@ models - events - delete_event_objective(-)')
        return result

    # create hostess objective report
    def create_hostess_objective(self, data, rid):
        logger.addinfo('@ models - events - create_hostess_objective(+)')
        try:
            objective_report_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.insert_objective_report(
                    :p_report_id,
                    :p_objective_report_id,
                    :p_event_objective_id,
                    :p_event_id,
                    :p_target_qty,
                    :p_target_achieved,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_update_by,
                    :p_status_code
                );
            end; """, p_report_id=rid,
                                p_objective_report_id=objective_report_id,
                                p_event_objective_id=data[
                                                        'event_objective_id'],
                                p_event_id=data['event_id'],
                                p_target_qty=data['target_qty'],
                                p_target_achieved=data['target_achieved'],
                                p_creation_date=data['creation_date'],
                                p_created_by=data['created_by'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_update_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                oid = objective_report_id.getvalue()
                result['objective_report_id'] = oid
                if data['targets']:
                    targets = data['targets']
                    for i in range(len(targets)):
                        if result['msg'] == 'SUCCESS':
                            targets_result = self.create_hostess_target(
                                                    targets[i], rid, oid)
                            if targets_result['msg'] != 'SUCCESS':
                                result['msg'] = 'ERROR'
            else:
                logger.findaylog(""" @ pkg - models - events -
                                 insert_objective_report:{}
                                 """.format(data))
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 2047 EXCEPTION - models - events -
                 create_hostess_objective """ + str(error))
            raise error
        logger.addinfo('@ models - events - create_hostess_objective(-)')
        return result

    # create hostess objective report
    def update_hostess_objective(self, data):
        logger.addinfo('@ models - events - update_hostess_objective(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.update_objective_report(
                    :p_report_id,
                    :p_objective_report_id,
                    :p_event_objective_id,
                    :p_event_id,
                    :p_target_qty,
                    :p_target_achieved,
                    :p_last_updated_date,
                    :p_last_update_by,
                    :p_status_code
                );
            end; """, p_report_id=data['report_id'],
                                p_objective_report_id=data[
                                    'objective_report_id'],
                                p_event_objective_id=data[
                                    'event_objective_id'],
                                p_event_id=data['event_id'],
                                p_target_qty=data['target_qty'],
                                p_target_achieved=data['target_achieved'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_update_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
                if data['targets']:
                    targets = data['targets']
                    for i in range(len(targets)):
                        if result['msg'] == 'SUCCESS':
                            targets_result = self.update_hostess_target(
                                targets[i])
                            if targets_result['msg'] != 'SUCCESS':
                                result['msg'] = 'ERROR'
            else:
                result['msg'] = 'ERROR'
                logger.findaylog(
                    '@ pkg - models - events - update_objective_report :{}'.format(data))
        except Exception as error:
            self.release()
            logger.findaylog("""@ 2091 EXCEPTION - models - events -
                 update_hostess_objective """ + str(error))
            raise error
        logger.addinfo('@ models - events - update_hostess_objective(-)')
        return result

    def get_objectives_by_id(self, obj_id):
        logger.addinfo('@ models  - events - get_objectives_by_id(+)')
        try:
            self.acquire()
            query = self.sql_file['get_objectives_by_id']
            self.cursor.execute(query, p_objective_id=obj_id)
            objectives = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 2723 EXCEPTION - get_objectives_by_id -
                            models """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - events - get_objectives_by_id(-)')
        return objectives

    def get_objectives(self, obj_id):
        logger.addinfo('@ models - events - get_objectives(+)')
        try:
            self.acquire()
            query = self.sql_file['objectives_summary']
            self.cursor.execute(query, p_objective_id=obj_id)
            objectives = []
            targets = []
            objectives = Code_util.iterate_data(self.cursor)
            if obj_id:
                query = self.sql_file['objective_targets']
                self.cursor.execute(query, p_obj_id=obj_id)
                targets = Code_util.iterate_data(self.cursor)
            if len(objectives):
                objectives[0]['targets'] = targets
        except Exception as error:
            logger.findaylog("""@ 2148 EXCEPTION - models - events-
                get_objectives """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - events - get_objectives(-)')
        return objectives

    def insert_objective(self, jsond):
        logger.addinfo('@ models - events - insert_objective(+)')
        status = ''
        try:
            self.acquire()
            objective_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.insert_objective(
                    :p_objective_id,
                    :p_objective_name,
                    :p_target_qty,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status,
                    :p_type,
                    :p_cust_account_id,
                    :p_cust_site_id,
                    :p_status_code
                );
            end; """, p_objective_id=objective_id,
                                p_objective_name=jsond['objective_name'],
                                p_target_qty=jsond['target_qty'],
                                p_creation_date=jsond['creation_date'],
                                p_created_by=jsond['created_by'],
                                p_last_updated_date=jsond['last_updated_date'],
                                p_last_updated_by=jsond['last_updated_by'],
                                p_status=jsond['status'],
                                p_type=jsond['type'],
                                p_cust_account_id=jsond['cust_account_id'],
                                p_cust_site_id=jsond['cust_site_id'],
                                p_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                status = 0
                if jsond['targets']:
                    targets = jsond['targets']
                    obj_id = objective_id.getvalue()
                    for i in range(len(targets)):
                        self.create_event_target(targets[i],
                                                 None, obj_id)
            else:
                status = 1
        except Exception as error:
            logger.findaylog("""@ 2201 EXCEPTION - models - events-
                insert_objective """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - insert_objective(-)')
        return status

    def update_objective(self, jsond):
        logger.addinfo('@ models - events - update_objective(+)')
        status = ''
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.update_objective(
                    :p_objective_id,
                    :p_objective_name,
                    :p_target_qty,
                    :p_last_updated_date,
                    :p_last_updated_by,
                    :p_status,
                    :p_type,
                    :p_cust_account_id,
                    :p_cust_site_id,
                    :p_status_code
                );
            end; """, p_objective_id=jsond['objective_id'],
                                p_objective_name=jsond['objective_name'],
                                p_target_qty=jsond['target_qty'],
                                p_last_updated_date=jsond['last_updated_date'],
                                p_last_updated_by=jsond['last_updated_by'],
                                p_status=jsond['status'],
                                p_type=jsond['type'],
                                p_cust_account_id=jsond['cust_account_id'],
                                p_cust_site_id=jsond['cust_site_id'],
                                p_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                status = 0
                if jsond['targets']:
                    obj_id = jsond['objective_id']
                    targets = jsond['targets']
                    for i in range(len(targets)):
                        code = targets[i]['operation_code']
                        if code == 'UPDATE':
                            self.update_event_target(targets[i])
                        elif code == 'CREATE':
                            eid = None
                            self.create_event_target(targets[i],
                                                     eid, obj_id)
                        elif code == 'DELETE':
                            eid = targets[i]['event_target_id']
                            self.delete_event_target(eid)
            else:
                status = 1
        except Exception as error:
            logger.findaylog("""@ 2242 EXCEPTION - models - events-
                update_objective """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - update_objective(-)')
        return status

    def delete_objective(self, obj_id):
        logger.addinfo('@ models - events - delete_objective(+)')
        status = ''
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_event_pkg.delete_objective(
                    :p_objective_id,
                    :p_status_code
                );
            end; """, p_objective_id=obj_id,
                                p_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                status = 0
            else:
                status = 1
        except Exception as error:
            logger.findaylog("""@ 2275 EXCEPTION - models - events-
                delete_objective """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - delete_objective(-)')
        return status

    def get_report(self, jsond):
        logger.addinfo('@ models - events - get_report(+)')
        try:
            self.acquire()
            salesrep_id = jsond['agent_id'] if 'agent_id' in jsond else None
            from_date = jsond['from_date'] if 'from_date' in jsond else None
            to_date = jsond['to_date'] if 'to_date' in jsond else None
            cust_id = jsond['cust_id'] if 'cust_id' in jsond else None
            hostess = jsond['hostess'] if 'hostess' in jsond else None
            rfrom_date = jsond['rfrom_date'] if 'rfrom_date' in jsond else None
            rto_date = jsond['rto_date'] if 'rto_date' in jsond else None
            query = self.sql_file['get_report']
            if from_date and to_date:
                query += self.sql_file['hostess_report_details_bydate']
                if rfrom_date and rto_date:
                    query = query + ' AND r.last_updated_date between '
                    query = query + ' :P_RFROMDATE AND :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_TO_DATE=to_date,
                                        P_RFROMDATE=rfrom_date,
                                        P_RTO_DATE=rto_date)
                elif rfrom_date:
                    query = query + ' AND r.last_updated_date >= :P_RFROMDATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_TO_DATE=to_date,
                                        P_RFROMDATE=rfrom_date)
                elif rto_date:
                    query = query + ' AND r.last_updated_date <= :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_TO_DATE=to_date,
                                        P_RTO_DATE=rto_date)
                else:
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_TO_DATE=to_date)
            elif from_date:
                query += self.sql_file['hostess_report_details_fromdate']
                if rfrom_date and rto_date:
                    query = query + ' AND r.last_updated_date between '
                    query = query + ' :P_RFROMDATE AND :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_RFROMDATE=rfrom_date,
                                        P_RTO_DATE=rto_date)
                elif rfrom_date:
                    query = query + ' AND r.last_updated_date >= :P_RFROMDATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_RFROMDATE=rfrom_date)
                elif rto_date:
                    query = query + ' AND r.last_updated_date <= :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_RTO_DATE=rto_date)
                else:
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date)
            elif to_date:
                query += self.sql_file['hostess_report_details_todate']
                if rfrom_date and rto_date:
                    query = query + ' AND r.last_updated_date between '
                    query = query + ' :P_RFROMDATE AND :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_TO_DATE=to_date,
                                        P_RFROMDATE=rfrom_date,
                                        P_RTO_DATE=rto_date)
                elif rfrom_date:
                    query = query + ' AND r.last_updated_date >= :P_RFROMDATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_TO_DATE=to_date,
                                        P_RFROMDATE=rfrom_date)
                elif rto_date:
                    query = query + ' AND r.last_updated_date <= :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_TO_DATE=to_date,
                                        P_RTO_DATE=rto_date)
                else:
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_TO_DATE=to_date)
            else:
                if rfrom_date and rto_date:
                    query = query + ' AND r.last_updated_date between '
                    query = query + ' :P_RFROMDATE AND :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_RFROMDATE=rfrom_date,
                                        P_RTO_DATE=rto_date)
                elif rfrom_date:
                    query = query + ' AND r.last_updated_date >= :P_RFROMDATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_RFROMDATE=rfrom_date)
                elif rto_date:
                    query = query + ' AND r.last_updated_date <= :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_RTO_DATE=rto_date)
                else:
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess)
        except Exception as e:
            raise e
        else:
            report = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@models - events - get_report(-)')
        return report

    def hostess_report(self, jsond):
        logger.addinfo('@ models - events - hostess_report(+)')
        result = []
        try:
            self.acquire()
            salesrep_id = jsond['agent_id'] if 'agent_id' in jsond else None
            from_date = jsond['from_date'] if 'from_date' in jsond else None
            to_date = jsond['to_date'] if 'to_date' in jsond else None
            cust_id = jsond['cust_id'] if 'cust_id' in jsond else None
            hostess = jsond['hostess'] if 'hostess' in jsond else None
            rfrom_date = jsond['rfrom_date'] if 'rfrom_date' in jsond else None
            rto_date = jsond['rto_date'] if 'rto_date' in jsond else None
            query = self.sql_file['hostess_report_details']
            if from_date and to_date:
                query += self.sql_file['hostess_report_details_bydate']
                if rfrom_date and rto_date:
                    query = query + ' AND r.last_updated_date between '
                    query = query + ' :P_RFROMDATE AND :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_TO_DATE=to_date,
                                        P_RFROMDATE=rfrom_date,
                                        P_RTO_DATE=rto_date)
                elif rfrom_date:
                    query = query + ' AND r.last_updated_date >= :P_RFROMDATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_TO_DATE=to_date,
                                        P_RFROMDATE=rfrom_date)
                elif rto_date:
                    query = query + ' AND r.last_updated_date <= :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_TO_DATE=to_date,
                                        P_RTO_DATE=rto_date)
                else:
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_TO_DATE=to_date)
            elif from_date:
                query += self.sql_file['hostess_report_details_fromdate']
                if rfrom_date and rto_date:
                    query = query + ' AND r.last_updated_date between '
                    query = query + ' :P_RFROMDATE AND :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_RFROMDATE=rfrom_date,
                                        P_RTO_DATE=rto_date)
                elif rfrom_date:
                    query = query + ' AND r.last_updated_date >= :P_RFROMDATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_RFROMDATE=rfrom_date)
                elif rto_date:
                    query = query + ' AND r.last_updated_date <= :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date,
                                        P_RTO_DATE=rto_date)
                else:
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_FROM_DATE=from_date)
            elif to_date:
                query += self.sql_file['hostess_report_details_todate']
                if rfrom_date and rto_date:
                    query = query + ' AND r.last_updated_date between '
                    query = query + ' :P_RFROMDATE AND :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_TO_DATE=to_date,
                                        P_RFROMDATE=rfrom_date,
                                        P_RTO_DATE=rto_date)
                elif rfrom_date:
                    query = query + ' AND r.last_updated_date >= :P_RFROMDATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_TO_DATE=to_date,
                                        P_RFROMDATE=rfrom_date)
                elif rto_date:
                    query = query + ' AND r.last_updated_date <= :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_TO_DATE=to_date,
                                        P_RTO_DATE=rto_date)
                else:
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_TO_DATE=to_date)
            else:
                if rfrom_date and rto_date:
                    query = query + ' AND r.last_updated_date between '
                    query = query + ' :P_RFROMDATE AND :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_RFROMDATE=rfrom_date,
                                        P_RTO_DATE=rto_date)
                elif rfrom_date:
                    query = query + ' AND r.last_updated_date >= :P_RFROMDATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_RFROMDATE=rfrom_date)
                elif rto_date:
                    query = query + ' AND r.last_updated_date <= :P_RTO_DATE'
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess,
                                        P_RTO_DATE=rto_date)
                else:
                    self.cursor.execute(query, P_SALESREP_ID=salesrep_id,
                                        P_CUST_ID=cust_id,
                                        P_HOSTESS_NAME=hostess)
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                details = {}
                for index, fn in enumerate(fieldnames):
                    details[fn] = row[index]
                report_id = details['report_id']
                query = self.sql_file['hostess_report_target_objectives']
                targets = self.hostess_report_data(report_id,
                                                   query)
                details['objectives'] = targets
                query = self.sql_file['hostess_report_gift_objectives']
                gifts = self.hostess_report_data(report_id,
                                                 query)
                details['gift_objectives'] = gifts
                result.append(details)
        except Exception as error:
            logger.findaylog("""@ 2402 EXCEPTION - models - events-
                hostess_report """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - events - hostess_report(-)')
        return result

    def hostess_report_data(self, report_id, query):
        logger.addinfo('@ models - events - hostess_report_data(+)')
        try:
            self.cursor.execute(query, P_REPORT_ID=report_id)
            fieldnames = [a[0].lower() for a in self.cursor.description]
            result = []
            for row in self.cursor:
                data = {}
                for index, fn in enumerate(fieldnames):
                    data[fn] = row[index]
                result.append(data)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 2426 EXCEPTION - models - events-
                hostess_report_data """ + str(error))
        logger.addinfo('@ models - events - hostess_report_data(-)')
        return result

    # update hostess gift report
    def update_gift_target(self, data):
        logger.addinfo('@ models - events - update_gift_target(+)')
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.update_event_gift_target(
                    :p_report_id,
                    :p_target_id,
                    :p_event_gift_id,
                    :p_event_id,
                    :p_item_id,
                    :p_value,
                    :p_currency,
                    :p_value_spent,
                    :p_vouchers,
                    :p_last_updated_date,
                    :p_last_update_by,
                    :p_status_code
                );
            end; """, p_report_id=data['report_id'],
                                p_target_id=data['target_id'],
                                p_event_gift_id=data['event_gift_id'],
                                p_event_id=data['event_id'],
                                p_item_id=data['item_id'],
                                p_value=data['value'],
                                p_currency=data['currency'],
                                p_value_spent=data['value_spent'],
                                p_vouchers=data['vouchers'],
                                p_last_updated_date=data['last_updated_date'],
                                p_last_update_by=data['last_updated_by'],
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'SUCCESS'
            else:
                logger.findaylog('@ pkg - models - events - update_event_gift_target:{}'.format(data))
                result['msg'] = 'ERROR'
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1608 EXCEPTION - models - events -
                 update_gift_target """ + str(error))
            raise error
        logger.addinfo('@ models - events - update_gift_target(-)')
        return result

    def create_hostess(self, jsond):
        logger.addinfo('@ models - events - create_hostess(+)')
        result = []
        try:
            user_name = jsond['user_name']
            description = jsond['description']
            password = jsond['password'] if 'password' in jsond else None
            if password is None:
                hashval = ''.join(random.choice
                                  (string.ascii_uppercase +
                                   string.ascii_lowercase +
                                   string.digits) for i in range(10))
                password = hashval
            encrypted_password = self.hashPassword(password)
            email_address = jsond['email_address']
            phone_no = jsond['phone_no'] if 'phone_no' in jsond else None
            external_id = jsond['external_identification']
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                QPEX_HOSTESS_PKG.create_hostess(
                    :p_user_name,
                    :p_description,
                    :p_email_address,
                    :p_password,
                    :p_encrypted_password,
                    :p_phone_no,
                    :p_external_identification,
                    :p_status_code
                );
            end; """, p_user_name=user_name, p_description=description,
                                p_email_address=email_address,
                                p_password=password,
                                p_encrypted_password=encrypted_password,
                                p_phone_no=phone_no,
                                p_external_identification=external_id,
                                p_status_code=status_code)
            result = {}
            if status_code.getvalue() == 'S':
                result['status'] = 0
                result['msg'] = 'User created successfully'
            else:
                result['status'] = 1
                result['msg'] = status_code.getvalue()

            if status_code.getvalue() == 'S' and jsond['send_mail'] == 'Y':
                self.send_hostess_email(user_name, password, email_address)
                result['msg'] = 'User created and mail sent successfully'
        except Exception as error:
            logger.findaylog("""@ 2621 EXCEPTION - models - events-
                create_hostess """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - create_hostess(-)')
        return result

    def get_categories(self):
        logger.addinfo('@ models - events - get_categories(+)')
        try:
            self.acquire()
            query = self.sql_file['event_categories']
            self.cursor.execute("alter session set nls_language='American'")
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - events - pforecast -
                 get_categories """ + str(error))
            raise error
        else:
            categories = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - events - get_categories(-)')
        return categories

    def get_attachment_categories(self):
        logger.addinfo('@ models - events - get_attachment_categories(+)')
        try:
            self.acquire()
            query = self.sql_file['get_attachment_categories']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 2756 EXCEPTION - events - pforecast -
                 get_attachment_categories """ + str(error))
            raise error
        else:
            categories = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - events - get_attachment_categories(-)')
        return categories

    def get_hostess_users(self):
        logger.addinfo("@ models - events - get_hostess_users(+)")
        try:
            self.acquire()
            query = self.sql_file['get_hostess']
            self.cursor.execute(query)
        except Exception as error:
            logger.addinfo(""" @ 2851 EXCEPTION - events -
                           get_hostess_users """ + str(error))
            raise error
        else:
            users = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - events - get_hostess_users(-)')
        return users

    def update_hostess(self, jsond):
        logger.addinfo('@ models - events - update_hostess(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            encrypted_password = self.hashPassword(jsond['password'])
            self.cursor.execute("""
            begin
                QPEX_HOSTESS_PKG.update_hostess(
                    :p_user_id,
                    :p_description,
                    :p_email_address,
                    :p_password,
                    :p_encrypted_password,
                    :p_phone_no,
                    :p_external_identification,
                    :p_status_code
                );
            end; """, p_user_id=jsond['user_id'],
                                p_description=jsond['user_description'],
                                p_email_address=jsond['email_address'],
                                p_password=jsond['password'],
                                p_encrypted_password=encrypted_password,
                                p_phone_no=jsond['phone_no'],
                                p_external_identification=jsond['external_id'],
                                p_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = 'success'
            else:
                result = status_code.getvalue()
        except Exception as e:
            logger.addinfo(""" @ 2898 EXCEPTION - events -
                            update_hostess """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - events - update_hostess(-)')
        return result

    def get_hostess_details(self, user_id):
        logger.addinfo('@ models - events - get_hostess_details(+)')
        try:
            self.acquire()
            query = self.sql_file['hostess_details_query']
            self.cursor.execute(query, p_user_id=user_id)
        except Exception as e:
            logger.addinfo(""" @ 2926 models - events -
                            get_hostess_details """ + str(e))
            raise e
        else:
            attrs = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - events - get_hostess_details(-)')
        return attrs

    def validate_booking(self, jsond):
        logger.addinfo('@ models - events - validate_booking(+)')
        result = None
        try:
            self.acquire()
            query = self.sql_file['stand_reservation_query']
            self.cursor.execute(query, p_from_date=jsond['from_date'],
                                p_to_date=jsond['to_date'],
                                p_stand_id=jsond['stand_id'],
                                p_reserve_hdr_id=jsond['reserve_hdr_id'])
            result = int(self.cursor.fetchone()[0])
        except Exception as error:
            logger.findaylog(""" @ 3223 EXCEPTION - models - events -
                validate_booking """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - events - validate_booking(-)')
        return result

    def send_email(self, event_id, report_status, report_id):
        logger.addinfo('@ models - events - send_email(+)')
        try:
            query = self.sql_file['event_email_query']
            self.cursor.execute(query, P_EVENT_ID=event_id)
            data = self.cursor.fetchone()
            if data:
                strings = db_util.get_strings()
                mail_data = ''
                if report_status == 'PENDING_APPROVAL':
                    mail_data = {
                        'subject': strings['event_report_submitted'],
                        'template_id': 107417,
                        'params': [{
                            'key': 'event_creator',
                            'value': data[2]
                        }, {
                            'key': 'event_name',
                            'value': data[1]
                        }, {
                            'key': 'user_name',
                            'value': data[6]
                        }, {
                            'key': 'report_id',
                            'value': report_id
                        }],
                        'recipients': [
                            {
                                'Email': data[3]
                            }
                        ]
                    }
                elif report_status == 'APPROVED' or (
                        report_status == 'REJECTED'):
                    subject = ''
                    status = ''
                    if report_status == 'APPROVED':
                        subject = strings['event_report_approved']
                        status = 'Approved'
                    else:
                        subject = strings['event_report_rejected']
                        status = 'Rejected'
                    mail_data = {
                        'subject': subject,
                        'template_id': 107416,
                        'params': [{
                            'key': 'user_name',
                            'value': data[6]
                        }, {
                            'key': 'report_id',
                            'value': report_id
                        }, {
                            'key': 'report_status',
                            'value': status
                        }],
                        'recipients': [
                            {
                                'Email': data[7]
                            }
                        ]
                    }
            result = CommonUtils.send_mail(mail_data)
            if result != 'SUCCESS':
                logger.findaylog("""@ models - events -
                                 send_email -{} """.format(mail_data))
        except Exception as error:
            logger.findaylog("""@ 2202 EXCEPTION - models - events -
                             send_email """ + str(error))
        logger.addinfo('@ models - events - send_email(-)')

    # generate encrypted password
    def hashPassword(self, new_password):
        return auth_util.encrypt(new_password)

    def send_hostess_email(self, user_name, password, email_address):
        logger.addinfo('@ models - events - send_hostess_email(+)')
        try:
            strings = db_util.get_strings()
            mail_data = {
                'subject': strings['hostess_creation'],
                'template_id': 107422,
                'params': [{
                    'key': 'user_name',
                    'value': user_name
                }, {
                    'key': 'password',
                    'value': password
                }],
                'recipients': [
                    {
                        'Email': email_address
                    }
                ]
            }
            result = CommonUtils.send_mail(mail_data)
            if result != 'SUCCESS':
                logger.findaylog("""@ models - events -
                                send_hostess_email - {} """.format(mail_data))

        except Exception as error:
            self.release()
            logger.findaylog("""@ 2778 EXCEPTION - models - events -
                             send_hostess_email """ + str(error))
        logger.addinfo('@ models - events - send_hostess_email(-)')

    def event_creation_mail(self, data):
        logger.findaylog('@models - events - event_creation_mail(+)', send_email=False)
        status = ''
        try:
            strings = db_util.get_strings()
            query = self.sql_file['user_data_query']
            query_data = self.cursor.execute(query,
                                             p_user_id=data[
                                                'created_by']).fetchone()
            user_name = query_data[0]
            email_receipients = []
            email_receipients.append({'Email': strings['recipient_mail']})
            mail_status = 'event_' + data['mail_status']
            subject = strings[mail_status]
            subject += ' for customer ' + data['customer_name']
            if data['mail_status'] == 'deleted':
                hostess_details = self.cursor.execute(query,
                                                      p_user_id=data[
                                                        'hostess_id']
                                                      ).fetchone()
                hostess_email = hostess_details[1]
                email_receipients.append({'Email': hostess_email})
            mail_data = {
                'subject': subject,
                'template_id': 107411,
                'params': [{
                    'key': 'user_name',
                    'value': user_name
                },{
                    'key': "status",
                    'value': data['event_status']
                },{
                    'key': "hostess_name",
                    'value': data['hostess_name']
                },{
                    'key': "event_id",
                    'value': data['event_id']
                },{
                    'key': "creation_date",
                    'value': data['creation_date']
                },{
                    'key': "customer_name",
                    'value': data['customer_name']
                },{
                    'key': "event_name",
                    'value': data['event_name']
                },{
                    'key': "event_date",
                    'value': data['event_date']
                }],
                'recipients': email_receipients
            }
            result = CommonUtils.send_mail(mail_data)
            if result == 'SUCCESS':
                status = 'success'
            else:
                status = 'Failure - Failed to send email'
                logger.findaylog("""@ models - events -
                                event_creation_mail - {}""".format(mail_data))
        except Exception as error:
            logger.findaylog("""@ 2878 EXCEPTION - models - events -
                             event_creation_mail """ + str(error))
            raise error
        logger.findaylog('@models - events - event_creation_mail(-)', send_email=False)
        return status

    def attachment_save(self, jsond, report_id):
        logger.addinfo('@ models - events - attachment_save(+)')
        try:
            if not self.is_acquired:
                self.acquire()
            return_value = ''
            for i in range(len(jsond)):
                p_ref_id = report_id
                p_title = jsond[i]['title']
                p_desc = jsond[i]['description']
                p_file_name = jsond[i]['file_name']
                p_content = (jsond[i]['file_blob'])
                p_content_type = jsond[i]['content_type']
                p_entity_name = jsond[i]['entity_name']
                p_category_name = jsond[i]['category_name']
                self.cursor.setinputsizes(p_blob=cx_Oracle.BLOB)
                return_value = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute(""" declare
                begin
                :retval := qpex_attachments.add_attachment(:pref,
                :ptitle, :pfilename,:pdesc, :p_blob, :pcontent_type,
                :pentity, :pcategory);end;""", pref=p_ref_id, ptitle=p_title,
                                    pfilename=p_file_name, pdesc=p_desc,
                                    p_blob=p_content,
                                    pcontent_type=p_content_type,
                                    pentity=p_entity_name,
                                    pcategory=p_category_name,
                                    retval=return_value)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1371 EXCEPTION - models - events -
                             attachment_save """ + str(error))
            raise error
        logger.addinfo('@ models - events - attachment_save(-)')
        return return_value

    def attachment_delete(self, jsond):
        logger.addinfo('@ models - events - attachment_delete(+)')
        try:
            return_value = ''
            for i in range(len(jsond)):
                return_value = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute(""" declare
                begin
                :retval := qpex_attachments.delete_attachment(
                            :p_file_id);end;""", p_file_id=jsond[i]['file_id'],
                                    retval=return_value)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 2967 EXCEPTION - models - events -
                             attachment_delete """ + str(error))
            raise error
        logger.addinfo('@ models - events - attachment_delete(-)')
        return return_value

    def get_attachment_data(self, jsond):
        logger.addinfo('@ models - events - get_attachment_data(+)')
        try:
            self.acquire()
            query = self.sql_file['get_attachment_data']
            self.cursor.execute(query, p_report_id=jsond['pk1_value'],
                                p_file_name=jsond['file_name'])
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                data = {}
                for i in range(len(field_names)):
                    if field_names[i] == 'file_data':
                        data[field_names[i]] = (row[i].read()).decode('utf-8')
                    else:
                        data[field_names[i]] = row[i]
        except Exception as e:
            logger.findaylog(""" @ 3539 EXCEPTION - models - events -
                             get_attachment_data """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - events - get_attachment_data(-)')
        return data

    def delete_error_report(self, event_id):
        logger.addinfo('@ models - events - delete_error_report(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_hostess_pkg.delete_error_report(
                    :p_event_id,
                    :p_status_code
                );
            end; """, p_event_id=event_id,
                                p_status_code=status_code)
        except Exception as e:
            logger.findaylog("""@ 3463 EXCEPTION - models - events -
                             delete_error_report """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - events - delete_error_report(-)')
        return 'success'


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'events',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
