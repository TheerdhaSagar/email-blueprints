import os
import random
import string
import base64

import boto3
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer

from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.logdata import logger
from finapi.models.admin.user import User


class Cognito:
    assoc_id = 'custom:assoc_id'

    def __init__(self):
        self.strings = db_util.get_strings()
        self.region = os.environ['COGNITO_REGION']
        self.client_id = os.environ['COGNITO_CLIENT_ID']
        self.pool_id = os.environ['COGNITO_POOL_ID']
        self.account_id = os.environ['COGNITO_ACCOUNT_ID']
        self.identity_pool_id = os.environ['COGNITO_IDENTITY_POOL_ID']
        self.token_secret_key = os.environ['SECRET_KEY']

    def get_client(self):
        try:
            client = boto3.client('cognito-identity', self.region)
            response = client.get_id(AccountId=self.account_id,
                                     IdentityPoolId=self.identity_pool_id)
            response = client.get_open_id_token(IdentityId=response['IdentityId'])
            response = client.get_credentials_for_identity(
                IdentityId=response['IdentityId'])
            secret_key = response['Credentials']['SecretKey']
            access_key = response['Credentials']['AccessKeyId']
            session_token = response['Credentials']['SessionToken']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - cognito -
                            get_client""" + str(e))
            raise e
        return boto3.client('cognito-idp', self.region,
                            aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            aws_session_token=session_token)

    def forgot_password(self, req, call_stack=0):
        logger.addinfo('@ models - cognito - forgot_password(+)')
        result = {}
        try:
            if 'reset_link' in req:
                return self.send_reset_password_link(req)
            client = self.get_client()
            try:
                response = client.forgot_password(ClientId=self.client_id,
                                                  Username=req['username'].lower())
                if 'CodeDeliveryDetails' in response:  # not in use 14-05-2020
                    result['status'] = 'OK'
                    result['msg'] = 'Verification code sent to email'
                else:
                    result['status'] = 'ERROR'
                    result['msg'] = 'Unknown Error! Please try again'
            except Exception as e:
                if 'NotAuthorizedException' in str(e):
                    user_req = {
                        'email': req['username'].lower()
                    }
                    user_response = self.get_users_list(user_req)
                    if len(user_response) > 0:
                        user = user_response[0]
                        enabled = user['Enabled']
                        if enabled:
                            language = req['language'] if 'language' in req else 'GB'
                            user_req['name'] = Cognito.get_user_attribute(user, 'name')
                            user_req['language'] = language
                            self.resend_temporary_password(user_req)
                            result['status'] = 'OK'
                            result[
                                'msg'] = 'Your account is not activated, temporary password has ' \
                                         'been sent again.'
                        else:
                            result['status'] = 'ERROR'
                            result[
                                'msg'] = 'Your account is not enabled, please contact ' \
                                         'administrator.'
                elif 'InvalidParameterException' in str(e):
                    # this happens when the user click on forgot password and if
                    # the email_verified flag is either false or null, so to avoid this
                    # we update email_verified flag to true and then call forgot_password
                    if str(e).find('verified email') != -1 and call_stack == 0:
                        result = self.update_user_attributes({
                            'user_name': req['username'].lower(),
                            'attributes_to_change': [
                                {
                                    'Name': 'email_verified',
                                    'Value': 'true'
                                }
                            ]
                        })
                        # we don't want to keep calling this method recursively forever
                        # if there is an exception with updating attribute, so we maintain
                        # a variable to track the call
                        call_stack += 1
                        if result['status'] == 'OK':
                            result = self.forgot_password(req, call_stack)
                    else:
                        result['status'] = 'ERROR'
                        result['msg'] = str(e)
                else:
                    result['status'] = 'ERROR'
                    result['msg'] = str(e)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                forgot_password """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - forgot_password(-)')
        return result

    def send_reset_password_link(self, req):
        logger.addinfo('@ models - cognito - send_reset_password_link(+)')
        result = {}
        try:
            # prepare request link with base64 data
            code = base64.b64encode(req['username'].lower().encode()).decode('utf-8')

            # attach unique token
            token = Cognito.prepare_token(req['username'].lower())

            reset_link = req['reset_link'] + '?code=' + code + '&token=' + token

            # get username from cognito
            user_req = {
                'email': req['username'].lower()
            }

            user_response = self.get_users_list(user_req)
            if len(user_response) > 0:
                user = user_response[0]
                name = Cognito.get_user_attribute(user, 'name')

                # send email to user with reset password link
                # based on language parameter
                language = 'en' if 'language' not in req else req['language'].lower()

                template_id = self.strings['reset_password_mail_template_id'].get(language, 'en')
                subject = self.strings['reset_password_email_subject'].get(language, 'en')

                mail_data = {
                    'template_id': template_id,
                    'subject': subject,
                    'params': [
                        {
                            'key': 'user_email',
                            'value': req['username'].lower()
                        },
                        {
                            'key': 'reset_link',
                            'value': reset_link
                        }
                    ],
                    'to_email': req['username'].lower(),
                    'to_name': name
                }

                mail_status = CommonUtils.send_mail(mail_data)

                if mail_status == 'SUCCESS':
                    result['status'] = 0
                    result['msg'] = 'Sent reset password link'
                else:
                    result['status'] = 1
                    result['msg'] = 'Error in sending email! Please try again'
                    logger.findaylog("""@ models - cognito - send_reset_password_link -
                                    failed to reset -{}""".format(result['msg']))
            else:
                result['status'] = 1
                result['msg'] = 'User does not exists'
                logger.findaylog("""@ models - cognito - send_reset_password_link -
                    {}""".format(result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                    send_reset_password_link """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - send_reset_password_link(-)')
        return result

    @staticmethod
    def prepare_token(email, expires_in=86400):
        logger.addinfo('@ models - cognito - prepare_token(+)')
        try:
            # prepares token using internal auth token method
            user_obj = User()
            user_obj.user_id = email.lower()
            token = user_obj.generate_auth_token(expires_in)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                    prepare_jwt_token """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - prepare_token(-)')
        return token

    def decode_token(self, token):
        logger.addinfo('@ models - cognito - decode_token(+)')
        result = {}
        try:
            s = Serializer(self.token_secret_key)
            data = s.loads(token)
            if 'id' in data:
                result['status'] = 0
                result['msg'] = 'Token is valid'
                result['email'] = data.get('id')
            else:
                result['status'] = 1
                result['msg'] = 'Token is invalid or expired'
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                           decode_jwt_token """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - decode_token(-)')
        return result

    def reset_password(self, req, validate_token=True):
        logger.addinfo('@ models - cognito - reset_password(+)')
        result = {}
        try:
            email = req['email'].lower()
            password = req['password']

            # validate token before moving forward
            if validate_token:
                decode_token = self.decode_token(req['token'])
                if decode_token.get('status') == 1:
                    # is status is 1, then there is error in decoding token
                    return decode_token
                elif decode_token.get('email') != email:
                    result['status'] = 1
                    result['msg'] = 'Email does not match with token'
                    logger.findaylog("""@ models - cognito - reset_password - {}""".format(
                        result['msg']))
                    return result

            client = self.get_client()
            users = self.get_users_list({'email': email})
            if len(users) > 0:
                username = None
                for user in users:
                    username = user['Username']
                    break
                if username:
                    response = client.admin_set_user_password(
                        UserPoolId=self.pool_id,
                        Username=username,
                        Password=password,
                        Permanent=True
                    )

                if 'ResponseMetadata' in response:
                    result['status'] = 0
                    result['msg'] = 'Password reset successful'
                else:
                    result['status'] = 1
                    result['msg'] = 'Unknown Error! Please try again'
                    logger.findaylog("""@ models - cognito - reset_password -
                                    {}""".format(response))
            else:
                result['status'] = 1
                result['msg'] = 'Cannot find user with this email! Please try again'
                logger.findaylog("""@ models - cognito - reset_password 
                                {}""".format(result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                    reset_password """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - reset_password(-)')
        return result

    def login(self, req):
        """
        To login using cognito
        :param req: {"username":<email_address>, "password":<password>}
        :return:
        """
        logger.addinfo('@ models - cognito - login(+)')
        result = {}
        client = self.get_client()
        try:
            password = CommonUtils.decode_credential(req['password'])
            response = client.admin_initiate_auth(
                UserPoolId=self.pool_id,
                ClientId=self.client_id,
                AuthFlow='ADMIN_NO_SRP_AUTH',
                AuthParameters={
                    'USERNAME': req['username'].lower(),
                    'PASSWORD': password
                }
            )
            if 'AuthenticationResult' in response:
                result['status'] = 'OK'
                result['token'] = response['AuthenticationResult']['AccessToken']
                response = self.get_user({'token': result['token']}, client)
                if response.get(Cognito.assoc_id):
                    response['org_type'] = Cognito.get_organization_type(
                        int(response.get(Cognito.assoc_id)))
                result['data'] = response
            elif 'ChallengeName' in response:
                result['status'] = 'ERROR'
                result['session'] = response['Session']
                result['msg'] = 'New password required. ' \
                                'Change password before proceeding'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Unknown Error! Please try again'
                logger.findaylog("""@ models - cognito - login -
                                {}""".format(response))
        except client.exceptions.UserNotFoundException as error:
            logger.findaylog("""@ Exception models - cognito -
                login """ + str(error.message))
            result['status'] = 'ERROR'
            result['msg'] = 'User does not exist'
        except client.exceptions.NotAuthorizedException as error:
            logger.findaylog("""@ Exception models - cognito -
                login """ + str(error.message))
            result['status'] = 'ERROR'
            result['msg'] = error.message
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                login """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - login(-)')
        return result

    @staticmethod
    def get_organization_type(org_id):
        org_type = None
        with OracleConnectionManager() as conn:
            sql_file = sql_util.get_sql('donation')
            query = sql_file['fetch_org_type']
            conn.execute(query, p_org_id=org_id)
            org_details = conn.get_single_result()
            if org_details:
                org_type = org_details['org_type']
        return org_type

    def get_user(self, req, client=None):
        logger.addinfo('@ models - cognito - get_user(+)')
        result = {}
        attributes = ['sub', 'name', 'email', 'email_verified', Cognito.assoc_id,
                      'custom:unique_id', 'custom:role']
        try:
            if not client:
                client = self.get_client()
            response = client.get_user(AccessToken=req['token'])

            if 'UserAttributes' in response:
                for obj in response['UserAttributes']:
                    if obj['Name'] in attributes:
                        result[obj['Name']] = obj['Value']

            if 'provider' in req:
                users = self.get_users_list(result)
                if len(users) > 0:
                    for obj in users:
                        for attribute in obj['Attributes']:
                            if attribute['Name'] in attributes:
                                result[attribute['Name']] = attribute['Value']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                get_user """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - get_user(-)')
        return result

    def change_password(self, req):  # not in use 14-05-2020
        logger.addinfo('@ models - cognito - change_password(+)')
        result = {}
        try:
            client = self.get_client()
            # on success empty object {} returned from server so no need to
            # store the response in variable, on error it goes into except block
            client.confirm_forgot_password(
                ClientId=self.client_id,
                Username=req['username'].lower(),
                ConfirmationCode=req['confirmation_code'],
                Password=req['password']
            )
            result['status'] = 'OK'
            result['msg'] = 'Password changed successfully'
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                change_password """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - change_password(-)')
        return result

    def register(self, req):
        """
        Notes:
            https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/cognito
            -idp.html#CognitoIdentityProvider.Client.admin_create_user
        """
        logger.addinfo('@ models - cognito - register(+)')
        result = {}
        attributes = None
        response = {}
        try:
            client = self.get_client()
            password = Cognito.generate_password()
            if 'role' in req:
                if 'donation-desk' in req['role']:
                    attributes = Cognito.get_donation_desk_attributes(req)
                elif 'pet-parent' in req['role']:
                    attributes = Cognito.get_pet_parent_attributes(req)
                elif 'professional' in req['role']:
                    attributes = [{
                        'Name': 'custom:role',
                        'Value': 'professional'
                    }]
            else:
                attributes = {
                    'Name': Cognito.assoc_id,
                    'Value': str(req['assoc_id'])
                }

            # required attributes for cognito registration
            user_attributes = [
                {
                    'Name': 'name',
                    'Value': req['name']
                },
                {
                    'Name': 'email',
                    'Value': req['username'].lower()
                },
                {
                    'Name': 'email_verified',
                    'Value': 'true'
                }
            ]

            if attributes:
                user_attributes += attributes

            cognito_user = []
            if 'provider' in req:
                req['email'] = req['username'].lower()
                cognito_user = self.get_users_list(req)

            if len(cognito_user) <= 1:
                # create user using admin API
                response = client.admin_create_user(
                    UserPoolId=self.pool_id,
                    Username=req['username'].lower(),
                    TemporaryPassword=password,
                    UserAttributes=user_attributes,
                    DesiredDeliveryMediums=['EMAIL'],
                    MessageAction='SUPPRESS'
                )
                # If notify = 'N' then don't sent any email to user with temporary password
                if 'notify' in req and req['notify'] == 'Y':
                    language = req['language'] if 'language' in req else 'GB'
                    self.resend_temporary_password({
                        'email': req['username'].lower(),
                        'name': req['name'],
                        'language': language,
                        'password': password
                    })

                # If password is available in the request, then reset password
                if 'password' in req and CommonUtils.validate_password(req['password']):
                    self.reset_password({
                        'email': req['username'].lower(),
                        'password': req['password']
                    }, validate_token=False)

                cognito_user = self.get_users_list(req)

            if 'provider' in req:
                if len(cognito_user) > 1:
                    cognito_user_id = ''
                    provider_user_id = ''
                    for user in cognito_user:
                        if user['UserStatus'] == 'EXTERNAL_PROVIDER':
                            provider_user_id = user['Username']
                        else:
                            cognito_user_id = user['Username']
                    req = {
                        'cognito_user_id': cognito_user_id,
                        'provider_user_id': provider_user_id,
                        'provider': req['provider']
                    }
                    self.link_provider(req)

            if 'User' in response:
                result['status'] = 'OK'
                result['msg'] = 'Account created successfully'
                result['data'] = {
                    'username': response['User']['Username'],
                    'attributes': response['User']['Attributes'],
                    'status': response['User']['UserStatus']
                }
            else:
                result['status'] = 'ERROR',
                result['msg'] = 'Unknown Error! Please try again'
                logger.findaylog("""@ models - cognito -
                                 register - {} """.format(response))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                register """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - register(-)')
        return result

    def update_password(self, req):
        logger.addinfo('@ models - cognito - update_password(+)')
        result = {}
        try:
            password = CommonUtils.decode_credential(req['password'])
            client = self.get_client()
            response = client.admin_respond_to_auth_challenge(
                UserPoolId=self.pool_id,
                ClientId=self.client_id,
                ChallengeName='NEW_PASSWORD_REQUIRED',
                ChallengeResponses={
                    'USERNAME': req['username'].lower(),
                    'NEW_PASSWORD': password
                },
                Session=req['session']
            )
            if 'AuthenticationResult' in response:
                result['status'] = 'OK'
                result['token'] = response['AuthenticationResult']['AccessToken']
                response = self.get_user({'token': result['token']}, client)
                result['data'] = response
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Unknown Error! Please try again'
                logger.findaylog("""@ models - cognito -
                                update_password - {}""".format(response))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                update_password """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - update_password(-)')
        return result

    def get_users_list(self, req):
        logger.addinfo('@ models - cognito - get_users_list(+)')
        email = None
        try:
            client = self.get_client()
            if 'email' in req:
                email = req['email']

            if email:
                response = client.list_users(
                    UserPoolId=self.pool_id,
                    Filter='email="' + str(email) + '"'
                )
            else:
                response = client.list_users(
                    UserPoolId=self.pool_id
                )

            if 'Users' not in response:
                result = {
                    'status': 'ERROR',
                    'msg': 'Unexpected Error! Please try again!'
                }
                logger.findaylog("""@ models - cognito -
                                get_users_list - {} """.format(response))
            else:
                if 'provider' in req:
                    result = []
                    for user in response['Users']:
                        if user['Username'].find(req['provider']) != -1:
                            result.append(user)
                        if user['UserStatus'] != 'EXTERNAL_PROVIDER':
                            result.append(user)
                else:
                    result = response['Users']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                get_users_list """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - get_users_list(+)')
        return result

    def link_provider(self, req):
        logger.addinfo('@ models - cognito - link_provider(+)')
        try:
            client = self.get_client()
            client.admin_link_provider_for_user(
                UserPoolId=self.pool_id,
                DestinationUser={
                    'ProviderName': 'Cognito',
                    'ProviderAttributeName': 'Username',
                    'ProviderAttributeValue': req['cognito_user_id']
                },
                SourceUser={
                    'ProviderName': req['provider'],
                    'ProviderAttributeName': 'Cognito_Subject',
                    'ProviderAttributeValue': req['provider_user_id']
                }
            )
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                link_provider """ + str(e))
        logger.addinfo('@ models - cognito - link_provider(+)')

    def update_user_attributes(self, req):
        logger.addinfo('@ models - cognito - update_user(+)')
        client = self.get_client()
        try:
            client.admin_update_user_attributes(
                UserPoolId=self.pool_id,
                Username=req['user_name'],
                UserAttributes=req['attributes_to_change']
            )
            result = {
                'status': 'OK',
                'msg': 'Contact updated successfully'
            }
        except client.exceptions.UserNotFoundException as error:
            logger.findaylog("""@ Exception models - cognito -
                            update_user_attributes """ + str(error.message))
            result = {
                'status': 'ERROR',
                'msg': 'User does not exist'
            }
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                        update_user """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - update_user(+)')
        return result

    def change_user_password(self, req):
        """
        Notes:
            https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/cognito
            -idp.html#CognitoIdentityProvider.Client.admin_set_user_password
        """
        logger.addinfo('@ models - cognito - change_user_password(+)')
        try:
            password = Cognito.generate_password()
            client = self.get_client()
            users = self.get_users_list({'email': req['username'].lower()})
            if len(users) > 0:
                username = None
                for user in users:
                    if user['UserStatus'] == 'FORCE_CHANGE_PASSWORD':
                        username = user['Username']
                        break
                if username:
                    client.admin_set_user_password(
                        UserPoolId=self.pool_id,
                        Username=username,
                        Password=password,
                        Permanent=False
                    )
            else:
                logger.findaylog("""@ models - cognito -
                                change_user_password - No user found """)

        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                change_user_password """ + str(e))
            raise e
        logger.addinfo('@ models - cognito - change_user_password(+)')
        return password

    @staticmethod
    def get_donation_desk_attributes(req):
        return [{
            'Name': Cognito.assoc_id,
            'Value': str(req['assoc_id'])
        }, {
            'Name': 'custom:role',
            'Value': ','.join(req['role'])
        }]

    @staticmethod
    def get_pet_parent_attributes(req):
        return [{
            'Name': 'custom:unique_id',
            'Value': str(req['adoption_id'])
        }, {
            'Name': 'custom:role',
            'Value': ','.join(req['role'])
        }]

    @staticmethod
    def get_user_attribute(user, attribute):
        if 'Attributes' not in user:
            return ''
        for attr in user['Attributes']:
            if attr['Name'] == attribute:
                return attr['Value']
        return ''

    @staticmethod
    def generate_password():
        return ''.join([random.choice(string.ascii_uppercase) for _ in range(3)]) + \
               ''.join([random.choice(string.ascii_lowercase) for _ in range(4)]) + \
               ''.join([random.choice(string.digits) for _ in range(2)]) + \
               ''.join([random.choice('!@#$%&*') for _ in range(2)])

    def delete_user(self, email):
        result = ''
        try:
            client = self.get_client()
            users = self.get_users_list({'email': email})
            if len(users) > 0:
                for user in users:
                    if 'Username' in user:
                        client.admin_delete_user(
                            UserPoolId=self.pool_id,
                            Username=user['Username']
                        )
                result = 'success'
            else:
                result = 'failed'
                logger.findaylog("""@ models - cognito -
                                delete_user - cannot find user """)
        except Exception as e:
            logger.findaylog("""@ models - cognito -
                             delete_user - {} """.format(e))
            raise e
        return result

    def resend_temporary_password(self, req):
        try:
            language = req['language'] if 'language' in req else 'GB'
            template_id = 823913
            if language == 'IT':
                template_id = 838617
            elif language == 'DE':
                template_id = 838622
            elif language == 'NL':
                template_id = 838625
            elif language == 'FR':
                template_id = 838626

            if 'password' not in req:
                password = self.change_user_password({'username': req['email']})
            else:
                password = req['password']
            if 'link' in req:
                link = req['link']
            else:
                link = 'https://www.almonature.com'

            mail_data = {
                'template_id': template_id,
                'subject': 'Almo Nature: Temporary Password',
                'params': [
                    {
                        'key': 'username',
                        'value': req['email']
                    },
                    {
                        'key': 'password',
                        'value': password
                    },
                    {
                        'key': 'login_link',
                        'value': link
                    }
                ],
                'to_email': req['email'],
                'to_name': req['name']
            }
            status = CommonUtils.send_mail(mail_data)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - cognito -
                resend_temporary_password """ + str(e))
            raise e
        return status
