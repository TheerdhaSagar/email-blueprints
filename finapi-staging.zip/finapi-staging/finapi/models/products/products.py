import datetime
import os
import base64
import shutil
import zipfile
import barcode
from barcode.writer import ImageWriter
import jinja2
import pdfkit
from PyPDF2 import PdfFileWriter, PdfFileReader
import ujson
import xlrd

from pdf417gen import encode, render_image

from finapi.models.creditNotes.creditNote import CreditNote
from finapi.sql import sql_util
from finapi.utils.log_util import LogUtil
from finapi.utils.logdata import logger
from finapi.utils.common_utils import CommonUtils
from finapi.utils.conn_util import OracleConnectionManager


@LogUtil.class_module_logs('products')
class Products:

    DELIMITERS = [";", ":", ",", "\t"]
    EMPTY_STRING_LITERAL = ' - {}'
    TMP_FILE_PATH = '/tmp/'

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def get_products(self, org_id, price_list_id, lang, copia, on_hand):
        if on_hand == 'on_hand':
            query = self.sql_file['products_with_onhand_query']
        else:
            query = self.sql_file['products_query']
        copia_id = copia or self.get_copia_id(org_id, price_list_id)
        if lang == 'IT':
            lang = 'I'
        elif lang == 'DE':
            lang = 'D'
        elif lang == 'FR':
            lang = 'F'
        else:
            lang = 'US'
        with OracleConnectionManager() as conn:
            conn.execute(query, p_list_header_id=price_list_id,
                         p_org_id=org_id, p_comm_id=copia_id, p_lang=lang)
            products = conn.get_result()
        return products

    def get_copia_id(self, org_id, price_list_id):
        copia_id = None
        if org_id == 141 or org_id == 202:
            org_id = 202
        else:
            org_id = 82

        with OracleConnectionManager() as conn:
            query = self.sql_file['copia_query']
            conn.execute(query, p_org_id=org_id,
                         p_list_header_id=price_list_id)
            data = conn.get_result()
            if len(data) == 0:
                # when there is no data for list_header_id and org_id then
                # get the data for the org and list_header_id from a different query.
                # we always have an issue with pricelist table with data not gettting
                # updated when the something related to that table is changed, this
                # should fix that issue
                query = self.sql_file['org_copia_query']
                conn.execute(query, p_org_id=org_id, p_list_header_id=price_list_id)
                data = conn.get_result()
                if len(data) == 0:
                    # as a fail safe if the above query doesn't return any data then
                    # get data related to the org
                    conn.execute(query, p_org_id=org_id, p_list_header_id=None)
                    data = conn.get_result()

        if len(data) > 0:
            copia_id = data[0].get('code')
        return copia_id

    def get_catalog_data(self, org_id):
        if org_id == 141 or org_id == 202:
            org_id = 202
        else:
            org_id = 82
        query = self.sql_file['org_copia_query']
        with OracleConnectionManager() as conn:
            conn.execute(query, p_org_id=org_id, p_list_header_id=None)
            result = conn.get_result()
        return result

    def products_reading(self, encoded_data, price_list_id, org_id, lang):
        lines = []
        file_data = base64.b64decode(encoded_data).decode('utf-8')
        delimiter = None
        line = file_data.splitlines()[0]
        for d in Products.DELIMITERS:
            index = line.find(d)
            if index != -1:
                delimiter = d
                break

        if not delimiter:
            result = dict()
            result['status'] = 1
            result['msg'] = 'Invalid file format. Use either  , or ; or : or \
                             TAB as delimiter'
            logger.findaylog(('models - products - products_reading - ' + result['msg'] + Products.EMPTY_STRING_LITERAL).format(
                {'price_list_id': price_list_id, 'org_id': org_id,
                 'lang': lang, 'encoded_data': encoded_data}))
            return result

        for value in file_data.splitlines():
            data = value.split(delimiter)
            if len(data) == 3 and data[0] != '' and data[1] != '' and data[2] != '':
                line = dict()
                line['concatenated_segments'] = data[0].strip()
                line['primary_uom_code'] = data[1].strip()
                line['qty'] = data[2].strip()
                lines.append(line)

        if len(lines) == 0:
            result = dict()
            result['status'] = 1
            result['msg'] = 'File format looks not correct. \
                             Download a sample file'
            logger.findaylog(('models - products - products_reading' + result['msg'] + Products.EMPTY_STRING_LITERAL).format(
                {'price_list_id': price_list_id, 'org_id': org_id,
                 'lang': lang, 'encoded_data': encoded_data}))
            return result

        products = self.get_products(org_id, price_list_id, lang, None,
                                     None)
        product_data = ujson.dumps(products)
        product_list = ujson.loads(product_data)
        all_products = []
        for index, value in enumerate(product_list):
            all_products.append(str(value['concatenated_segments']))
        final_list = dict()
        invalid_list = []
        for x in lines:
            if x['concatenated_segments'] not in all_products or \
                    int(x['qty']) <= 0:
                invalid_list.append(x)

        final_list['invalid'] = invalid_list
        final_list['valid'] = [x for x in lines if
                               x['concatenated_segments'] in
                               all_products and int(x['qty']) > 0]
        return final_list

    @staticmethod
    def cm_items_csv(encoded, org_id, separator):
        lines = []
        decoded = base64.b64decode(encoded).decode('utf-8')
        delimiter = None
        line = decoded.splitlines()[0]
        error_method_name = 'models - products - cm_items_csv'
        for d in Products.DELIMITERS:
            index = line.find(d)
            if separator == ',' and line.count(d) == 1:
                delimiter = '\t'
                break
            elif index != -1:
                delimiter = d
                break
        if not delimiter:
            result = dict()
            result['status'] = 1
            result['msg'] = 'Invalid file format. Use either  , or ; or : or \
                             TAB as delimiter'
            logger.findaylog((error_method_name + result['msg'] + Products.EMPTY_STRING_LITERAL).format(
                {'encoded': encoded, 'org_id': org_id,
                 'separator': separator}))
            return result
        for value in decoded.splitlines():
            data = value.split(delimiter)
            if data[0] != '' and data[1] != '' and data[2] != '':
                if len(data) > 3:
                    line = dict(item_code=data[0].strip(),
                                primary_uom_code=data[1].strip().title(), quantity=data[2].strip())
                else:
                    line = dict(item_code=data[0].strip(),
                                quantity=data[1].strip(), primary_uom_code='Ct')
                if delimiter == ',' and separator == ',' and (len(data) > len(data) + 1):
                    line['price'] = data[-2].strip() + ',' + data[-1].strip()
                elif delimiter == ',' and separator == ',' and \
                        not len(data) > len(data) - 1:
                    result = dict()
                    result['status'] = 1
                    result['msg'] = 'Please check your number format'
                    logger.findaylog((error_method_name + result['msg'] + Products.EMPTY_STRING_LITERAL).format(
                        {'encoded': encoded, 'org_id': org_id,
                         'separator': separator}))
                    return result
                else:
                    if data[-1].strip().find(',') != -1 and separator == '.':
                        result = dict()
                        result['status'] = 1
                        result['msg'] = 'Please check your number format'
                        logger.findaylog((error_method_name + result['msg'] + '- {}').format(
                            {'encoded': encoded, 'org_id': org_id,
                             'separator': separator}))
                        return result
                    else:
                        line['price'] = data[-1].strip()
                lines.append(line)
        if len(lines) == 0:
            result = dict()
            result['status'] = 1
            result['msg'] = 'File format looks not correct. \
                             Download a sample file'
            logger.findaylog((error_method_name + result['msg'] + Products.EMPTY_STRING_LITERAL).format(
                {'encoded': encoded, 'org_id': org_id,
                 'separator': separator}))
            return result
        items = CreditNote.getItems(org_id)
        items_data = ujson.dumps(items)
        items_list = ujson.loads(items_data)
        all_products = []
        descriptions = []
        for index, value in enumerate(items_list):
            descriptions.append(str(value['description']))
            all_products.append(str(value['item_code']))
        final_list = {}
        invalid_list = []
        for x in lines:
            if x['item_code'] not in all_products:
                invalid_list.append(x)
                lines.remove(x)
        for line in lines:
            ind = all_products.index(line['item_code'])
            line['description'] = descriptions[ind]
        final_list['invalid'] = invalid_list
        final_list['valid'] = [x for x in lines if
                               x['item_code'] in all_products]
        return final_list

    def get_product_mapping(self, donation_type):
        query = self.sql_file['donation_product_map_query']
        with OracleConnectionManager() as conn:
            conn.execute(query, p_donation_type=donation_type)
            result = conn.get_result()
        return result

    def upload_shipping_labels(self, req):
        result = {}
        labels = self.sql_file['shipping_label_excel_columns']
        # decode base64 data and save as excel file
        file_name = '{}.xlsx'.format(CommonUtils.generate_random_string(10))
        with open(Products.TMP_FILE_PATH + file_name, 'wb') as excel_file:
            excel_file.write(base64.b64decode(req['file_data']))

        # read data from excel file
        sheet = xlrd.open_workbook(Products.TMP_FILE_PATH + file_name)
        worksheet = sheet.sheet_by_index(0)
        columns = worksheet.row_slice(0)
        result['labels'] = [c.value for c in columns]
        columns = [c.value.lower().strip().replace(' ', '_').replace('#', '') for c in columns]

        # check if all mandatory columns are present in uploaded excel file
        missing_columns = [labels[key] for key in labels if key not in columns]

        if missing_columns:
            result['status'] = 1
            result['msg'] = 'Missing columns {} from the uploaded excel file'\
                            .format(', '.join([c for c in missing_columns]))
            return result

        result['data'] = []
        for row in range(worksheet.nrows):
            if row > 0:
                obj = {}
                for index, column in enumerate(columns):
                    row_value = worksheet.cell_value(row, index)
                    cell_type = worksheet.cell_type(row, index)
                    value = Products.validate_data(column, row, row_value, cell_type, sheet)
                    if isinstance(value, dict):
                        return value
                    obj[column] = value
                result['data'].append(obj)
        return result

    @staticmethod
    def validate_data(column, row, row_value, cell_type, worksheet):
        if not row_value:
            return Products.data_error('Missing data for column {} in Row {}'
                                       .format(column, row))
        # check if the date columns in the excel sheet
        # are in MM/DD/YYYY format, if not return an error
        # if the format is correct then send parsed date
        # in YY/MM/DD format in the response
        if column == 'expected_date' or column == 'bbd':
            return Products.parse_date(row_value, '%m/%d/%Y', cell_type, worksheet, row, column)
        elif column == 'ship_to':
            try:
                # Remove white spaces around string
                if row_value and isinstance(row_value, str):
                    row_value = row_value.strip()
                ['FTW1', 'MDW2', 'MEM1', 'CVG3', 'XEW2', 'PGA1', 'PIL1', 'IND9'].index(row_value)
            except ValueError:
                return Products.data_error('{} has invalid value {} in Row {}. \
                        The valid values are FTW1, MEM1, CVG3, XEW2, PGA1, PIL1'.format(column.upper(), row_value, row))
        elif column == 'accepted_quantity':
            try:
                row_value = int(row_value)
            except ValueError:
                return Products.data_error('Row {} has invalid value {} for {}'
                                           .format(row, row_value, column.upper()))
        elif isinstance(row_value, (float, int)):
            row_value = str(int(row_value))
        return row_value

    @staticmethod
    def data_error(msg):
        logger.findaylog('models - products - ' + msg)
        return {
            'status': 1,
            'msg': msg
        }

    @staticmethod
    def parse_date(date_str, date_format, cell_type, worksheet, row, column):
        format_date = '%y/%m/%d'
        # 3 denotes date in float data type
        if cell_type == 3:
            date = datetime.datetime(*xlrd.xldate_as_tuple(date_str, worksheet.datemode))
            return date.strftime(format_date)
        else:
            try:
                date = datetime.datetime.strptime(date_str, date_format)
            except ValueError:
                return Products.data_error('Row {} contains invalid date format \
                        for {}. Expected format is MM/DD/YYYY'.format(row, column))
            return datetime.datetime.strftime(date, format_date)

    @staticmethod
    def download_shipping_labels(req):
        result = {}
        try:
            date = datetime.datetime.now().strftime('%Y%m%d')
            folder_name = 'LABELS_{}_{}'.format(str(req[0]['po']), date)
            if not os.path.exists('/tmp/%s' % (folder_name)):
                os.mkdir('/tmp/%s' % (folder_name))
            for row in req:
                pdf_writer = PdfFileWriter()
                row['po'] = str(row['po'])
                for _ in range(row['quantity']):
                    random_str = CommonUtils.generate_random_string(10)
                    # generating Code39 barcode
                    code = barcode.codex.Code39(row['po'], writer=ImageWriter(), add_checksum=False)
                    barcode_file_name = 'bar_{}'.format(random_str)
                    code.save(Products.TMP_FILE_PATH + barcode_file_name, options={
                        'quiet_zone': 0,
                        'module_height': 6.0,
                        'module_width': 0.1,
                        'write_text': False
                    })

                    # generating PDF417 barcode
                    code = encode(row['pdf417'].replace(' ', ''), columns=5, security_level=0)
                    file_name = 'code_{}.png'.format(random_str)
                    image = render_image(code, scale=3, ratio=5, padding=0)
                    image.save(Products.TMP_FILE_PATH + file_name)

                    # generate HTML file from template
                    path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
                    path += '/static/'
                    template = jinja2.Environment(
                        loader=jinja2.FileSystemLoader(path),
                        autoescape=True
                    ).get_template('shipping_label.html').render(
                        po_bar_code=Products.TMP_FILE_PATH + barcode_file_name + '.png',
                        barcode=Products.TMP_FILE_PATH + file_name,
                        po=row['po'],
                        asin=row['asin'],
                        product=row['model_number'],
                        ship_to=row['ship_to']
                    )
                    html_file_name = 'label_{}.html'.format(random_str)
                    with open(Products.TMP_FILE_PATH + html_file_name, 'w') as html_file:
                        html_file.write(template)

                    margin = '0.05in'
                    # generate PDF file
                    options = {
                        'page-width': '10.2cm',
                        'page-height': '15.2cm',
                        'margin-top': margin,
                        'margin-bottom': margin,
                        'margin-left': margin,
                        'margin-right': margin,
                        'encoding': 'UTF-8',
                        'quiet': ''
                    }
                    pdf_file_name = 'label_{}.pdf'.format(random_str)
                    pdfkit.from_file(Products.TMP_FILE_PATH + html_file_name, Products.TMP_FILE_PATH + pdf_file_name,
                                     options=options)
                    pdf_file = PdfFileReader(open(Products.TMP_FILE_PATH + pdf_file_name, 'rb'))
                    pdf_writer.addPage(pdf_file.getPage(0))
                pdf_file_name = '{}_{}_{}_{}.pdf'.format(row['po'], row['model_number'], row['asin'],
                                                         date)
                pdf_writer.write(open(Products.TMP_FILE_PATH +
                                 folder_name + '/' + pdf_file_name, 'wb'))
            # create zip file if there are more than 1 labels PDF file
            if len(req) > 1:
                Products.zip_folder('/tmp/%s' % (folder_name), folder_name)
                file_name = '%s.zip' % (folder_name)
                file_path = '/tmp/%s' % (file_name)
            else:
                file_name = pdf_file_name
                file_path = '/tmp/%s/%s' % (folder_name, file_name)
            with open(file_path, 'rb') as tmp_file:
                result['file_data'] = base64.b64encode(tmp_file.read()).decode('utf-8')
            result['file_name'] = '%s' % (file_name)
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - products -
                download_shipping_labels ''' + str(error))
            raise error
        finally:
            # delete the labels folder and zip file if exists
            if os.path.exists(folder_name):
                shutil.rmtree('/tmp/%s' % (folder_name))
            if os.path.exists('/tmp/%s.zip' % (folder_name)):
                os.remove('/tmp/%s.zip' % (folder_name))
        return result

    @staticmethod
    def zip_folder(src_dir, zip_file_name):
        zip_file = zipfile.ZipFile('/tmp/%s.zip' % (zip_file_name), 'w', zipfile.ZIP_DEFLATED)
        for dirname, _, files in os.walk(src_dir):
            for filename in files:
                absname = os.path.abspath(os.path.join(dirname, filename))
                zip_file.write(absname, filename)
        zip_file.close()

    @staticmethod
    def get_cell_format(workbook, worksheet, row, col):
        """
        Return cell format and font information
        """
        cell_format = worksheet.cell_xf_index(row, col)
        format_list = workbook.xf_list[cell_format]
        font = workbook.font_list[format_list.font_index]
        return format_list, font

    @staticmethod
    def get_cell_alignment(format_list):
        """
        Return cell alignment information
        """
        if format_list.alignment.hor_align == 2:
            return 'center'
        elif format_list.alignment.hor_align > 2:
            return 'right'
        return 'left'

    @staticmethod
    def get_font_color(workbook, font):
        """
        Return font color as rgb color
        """
        color = workbook.colour_map.get(font.colour_index)
        if color:
            return 'rgb(%s)' % ','.join([str(c) for c in color])
        return None

    @staticmethod
    def get_cell_background(workbook, format_list):
        """
        Return cell background as rgb color
        """
        color_index = format_list.background.pattern_colour_index
        background = workbook.colour_map.get(color_index)
        if background:
            return 'rgb(%s)' % ','.join([str(c) for c in background])
        return None

    @staticmethod
    def parse_products_data(req):
        file_path = '/tmp/%s.xls' % CommonUtils.generate_random_string(10)
        with open(file_path, 'wb') as tmp_file:
            tmp_file.write(base64.b64decode(req['data']))
        workbook = xlrd.open_workbook(file_path, formatting_info=True)
        worksheet = workbook.sheet_by_index(0)
        data = []
        for row in range(worksheet.nrows):
            row_data = []
            for col in range(0, worksheet.ncols):
                format_list, font = Products.get_cell_format(workbook, worksheet, row, col)
                align = Products.get_cell_alignment(format_list)
                background = Products.get_cell_background(workbook, format_list)
                color = Products.get_font_color(workbook, font)
                bold = font.weight
                row_data.append({
                    'value': worksheet.cell_value(row, col),
                    'type': worksheet.cell_type(row, col),
                    'background': background,
                    'color': color,
                    'fontWeight': bold,
                    'alignment': align
                })
            data.append({'rowData': row_data})
        return data

    def get_all_products(self):
        with OracleConnectionManager() as conn:
            query = self.sql_file['products_master_data_query']
            conn.execute(query)
            result = conn.get_result()
        return result
