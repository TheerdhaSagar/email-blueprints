from datetime import datetime
import cx_Oracle
from finapi.utils.constants import Status
from finapi.sql import sql_util
from finapi.utils.log_util import LogUtil
from finapi.utils.conn_util import OracleConnectionManager
from finapi.models.outofdoor.uploadfile import UploadOutofDoorFiles


@LogUtil.class_module_logs('gl_journal')
class GlJournal(object):

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def import_journal_excel(self, jsond):
        """
        import journal excel files
        jsond: {
            "base64":"",
            "created_id":"",
            "filename":"",
            "period":"",
            "header_description":""
            }"""
        upload_obj = UploadOutofDoorFiles(jsond)
        sheets_list = upload_obj.get_sheets_list()
        journal_dict = GlJournal.gl_journal_header(jsond)
        combination_error = []
        for sheet in sheets_list:
            upload_obj.sheet = upload_obj.get_workbook(sheet)
            if upload_obj.sheet.visibility == 0 and upload_obj.sheet.nrows:
                upload_obj.row_index, columns = upload_obj.get_column_names()
                new_columns = self.column_mapping_with_excel_keys(columns)
                upload_obj.columns = new_columns
                lines, combination_error = self.fetch_combination_id(
                    jsond['org_value'],
                    upload_obj.get_rows_data(upload_obj.row_index, 2), combination_error)
                journal_dict['lines'].extend(lines)
        if combination_error:
            return {'status': 1, 'msg': 'Code Combination Id\'s not found:{}'.format(
                '\n'.join(set(combination_error))),
                'lines': combination_error}
        return GlJournal.insert_journals(journal_dict)

    def fetch_period_from_excel(self, jsond):
        """
        import journal excel files
        jsond: {
            "base64":"",
            "created_id":"",
            "filename":"",
            }"""
        upload_obj = UploadOutofDoorFiles(jsond)
        sheets_list = upload_obj.get_sheets_list()
        line_periods = []
        for sheet in sheets_list:
            upload_obj.sheet = upload_obj.get_workbook(sheet)
            if upload_obj.sheet.visibility == 0 and upload_obj.sheet.nrows:
                upload_obj.row_index, columns = upload_obj.get_column_names()
                new_columns = self.column_mapping_with_excel_keys(columns)
                upload_obj.columns = new_columns
                lines = upload_obj.get_rows_data(upload_obj.row_index, 2)
                for line in lines:
                    date = datetime.strptime(line['accounting_date'], '%d/%m/%Y')
                    line_periods.append(date.strftime('%m-%y'))
        month_list = list(set(line_periods))
        if len(month_list) > 1:
            return {'status': 1, 'msg': 'More than 1 period is found'}
        return {'status': 0, 'period': month_list[0]}

    def fetch_combination_id(self, org, lines, combination_error):
        query = self.sql_file['find_combination_id']
        with OracleConnectionManager() as conn:
            for line in lines:
                kwargs = {
                    'p_code_1': '01{}'.format(org),
                    'p_code_2': str(int(line['segment_2'])),
                    'p_code_3': line['segment_3'] or '0000',
                    'p_code_4': line['segment_4'] or '0000',
                    'p_code_5': line['segment_5'] or '0000',
                    'p_code_6': line['segment_6'] or '000000',
                    'p_code_7': line['segment_7'] or '000000'
                }
                conn.execute(query, **kwargs)
                result = conn.get_single_result()
                if result:
                    line['combination_id'] = result['code_combination_id']
                else:
                    line['combination_id'] = ''
                    combination_error.append('.'.join(kwargs.values()))
        return lines, combination_error

    @staticmethod
    def gl_journal_header(jsond):
        return {
            'period': jsond['period'],
            'period_month': jsond['periodMonth'],
            'header_description': jsond['header_description'],
            'file_name': jsond['file_name'],
            'created_id': jsond['created_id'],
            'lines': [],
            'ledger_id': jsond['ledger_id'],
            'org_id': jsond['org_id'],
            'org_value': jsond['org_value'],
            'currency_code': jsond['currency_code'],
            'user_category': jsond['category_name']
        }

    def column_mapping_with_excel_keys(self, columns):
        # column names mapping keys
        line_keys = self.sql_file['journal_line_columns']
        new_clumns = []
        for key, values in line_keys.items():
            flag = False
            new_col = {}
            if values:
                for column in columns:
                    if any(GlJournal.replace_string_text(
                            column['column_name'], ' ', '', True).rstrip()
                            in GlJournal.replace_string_text(val, ' ', '', True)
                            for val in values):
                        new_col = {'column_index': column['column_index'],
                                   'column_name': column['column_name'],
                                   'column_type': column['column_type'],
                                   'oracle_name': key}
                        flag = True
                        new_clumns.append(new_col)
            if not flag:
                new_clumns.append({'oracle_name': key, 'column_name': 'NA'})
        return new_clumns

    @staticmethod
    def replace_string_text(value, replace_char, replace_with, lowercase=False, uppercase=False):
        new_value = value.replace(replace_char, replace_with)
        if lowercase:
            return new_value.lower()
        elif uppercase:
            return new_value.upper()
        return new_value

    @staticmethod
    def insert_journals(journal_details):
        """
        To insert the journal from excel sheet to db
        """
        status = {
            'status': 1,
            'msg': 'Unable to load the file'
        }
        line_date = []
        line_description = []
        line_dare = []
        line_avere = []
        line_conto = []
        line_month = []
        with OracleConnectionManager() as conn:
            for items in journal_details['lines']:
                date = datetime.strptime(items['accounting_date'], '%d/%m/%Y')
                line_month.append(date.strftime('%m-%y'))
                line_date.append(date.strftime('%d-%b-%Y'))
                line_description.append(items['description'])
                line_dare.append(items['credit_amt'] if items['credit_amt'] else None)
                line_avere.append(items['debit_amt'] if items['debit_amt'] else None)
                line_conto.append(items['combination_id'] if items['combination_id'] else None)
            month_count = list(set(line_month))
            if len(month_count) > 1:
                status = {
                    'status': 1,
                    'msg': 'Period in the file is more than one'
                }
            elif len(month_count) == 1 and month_count[0] != journal_details['period_month']:
                status = {
                    'status': 1,
                    'msg': 'Period selected is not same as the file dates'
                }
            elif line_date:
                conn.execute('''
                        BEGIN
                            QPEX_JOURNAL_PKG.manage_journal_details(
                            :p_line_date,
                            :p_line_description,
                            :p_line_dare,
                            :p_line_avere,
                            :p_line_conto,
                            :p_period,
                            :p_header_description,
                            :p_ledger_id,
                            :p_org_id,
                            :p_currency_code,
                            :p_user_category,
                            :p_file_name,
                            :p_created_id,
                            :x_status_code
                            );
                        END;''',
                             output_key='x_status_code',
                             p_line_date=conn.cursor.arrayvar(cx_Oracle.STRING, line_date),
                             p_line_description=conn.cursor.arrayvar(
                                 cx_Oracle.STRING, line_description),
                             p_line_dare=conn.cursor.arrayvar(cx_Oracle.NUMBER, line_dare),
                             p_line_avere=conn.cursor.arrayvar(
                                 cx_Oracle.NUMBER, line_avere),
                             p_line_conto=conn.cursor.arrayvar(
                                 cx_Oracle.NUMBER, line_conto),
                             p_period=journal_details['period'],
                             p_header_description=journal_details['header_description'],
                             p_file_name=journal_details['file_name'],
                             p_ledger_id=journal_details['ledger_id'],
                             p_org_id=journal_details['org_id'],
                             p_user_category=journal_details['user_category'],
                             p_currency_code=journal_details['currency_code'],
                             p_created_id=journal_details.get('created_id', -1))
                conn.get_output_param(raise_exception=True)
                status = {
                    'status': Status.OK.value,
                    'msg': 'Successfully uploaded'
                }
            return status

    def get_journal_details(self, journal_id, org_id, status):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['journal_summary']
            conn.execute(query, p_journal_id=journal_id, p_org_id=org_id,
                         p_status=status)
            if journal_id:
                result = conn.get_single_result()
                query = self.sql_file['journal_line_details']
                conn.execute(query, p_journal_id=journal_id)
                result['lines'] = conn.get_result()
            else:
                result = conn.get_result()
        return {'status': 0, 'journal': result}

    def get_user_category_names(self, language):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_user_category']
            conn.execute(query, p_lang=language)
            result = conn.get_result()
        return {'status': 0, 'user_categories': result}

    @staticmethod
    def cancel_invoice(invoice_id):
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                QPEX_JOURNAL_PKG.cancel_invoice(
                    :p_header_id,
                    :x_status_code
                );
            END;
            """, output_key='x_status_code', p_header_id=invoice_id)
            conn.get_output_param(raise_exception=True)
            return {'status': 0, 'msg': 'Cancelled Journal Details'}

    def call_plsql(self, jsond):
        response = ''
        with OracleConnectionManager() as conn:
            status_msg = conn.set_output_param('STRING')
            conn.execute("""
            BEGIN
             QPEX_JOURNAL_PKG.call_plsql(
                 :p_header_id,
                 :p_created_id,
                 :x_status_code,
                 :x_status_msg);
            END;
            """, output_key='x_status_code', p_header_id=jsond['header_id'],
                         p_created_id=jsond['created_id'],
                         x_status_msg=status_msg)
            status = conn.get_output_param(raise_exception=False)
            response = status_msg.getvalue()
        return {'status': 0, 'msg': 'Submitted successfully for further procedures',
                'response_msg': response, 'response_status': status}
