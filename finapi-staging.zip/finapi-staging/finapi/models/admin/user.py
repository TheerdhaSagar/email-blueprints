from flask import current_app
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer

from finapi.utils import auth_util


class User:

    def __init__(self):
        self.user_id = None
        self.user_name = None
        self.debug_flag = None
        self.encrypted_password = None

    # to verify the password given in authentication
    def verify_password(self, password):
        if self.encrypted_password:
            return auth_util.verify(password, self.encrypted_password)
        else:
            return False

    # token generation with expiry time 1 day
    def generate_auth_token(self, expires_in=86400):
        serializer = Serializer(current_app.config['SECRET_KEY'], expires_in=expires_in)
        # id dumped in token for further validation
        token = serializer.dumps({'id': self.user_id}).decode('utf-8')
        return token

    def clear(self):
        self.user_id = None
        self.user_name = None
        self.debug_flag = None
        self.encrypted_password = None

    def as_dict(self):
        return {"user_id": self.user_id,
                "username": self.user_name,
                "debug_flag": self.debug_flag,
                "encrypted_password": self.encrypted_password}
