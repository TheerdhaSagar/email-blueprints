from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.sql import sql_util
import datetime
from finapi.utils.code_util import Code_util
from finapi.utils.common_utils import CommonUtils
import cx_Oracle
import os


class Pforecast:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    # to get categories list
    def get_categories(self):
        logger.addinfo('@ models - pforecast - get_categories(+)')
        try:
            self.acquire()
            query = self.sql_file['pforecast_categories_query']
            self.cursor.execute("alter session set nls_language='American'")
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 38 EXCEPTION - models - pforecast -
                 get_categories """ + str(error))
            raise error
        else:
            category_list = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - get_categories(-)')
        return category_list

    # To get category products or items
    def get_items(self, category_id):
        logger.addinfo('@ models - pforecast - get_items(+)')
        try:
            self.acquire()
            query = self.sql_file['pforecast_items_query']
            self.cursor.execute("alter session set nls_language='American'")
            self.cursor.execute(query, P_CATEGORY_ID=category_id)
            forecast_data = Code_util.iterate_data(self.cursor)
            avg_query = self.sql_file['pforecast_avg_query']
            self.cursor.execute(avg_query, p_category_id=category_id)
            avg_qty = Code_util.iterate_data(self.cursor)
        except Exception as error:
            logger.findaylog("""@ 57 EXCEPTION - models - pforecast -
                 get_items """ + str(error))
            raise error
        else:
            for i in forecast_data:
                for j in avg_qty:
                    if i["segment1"] == j["item_code"]:
                        i["four_months_avg"] = j["four_months_avg"]
                        i["three_months_avg"] = j["three_months_avg"]
                        i["one_month_avg"] = j["one_month_avg"]
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - get_items(-)')
        return forecast_data

    # To get period details
    def get_periods(self):
        logger.addinfo('@ models - pforecast - get_periods(+)')
        try:
            self.acquire()
            query = self.sql_file['pforecast_periods_query']
            self.cursor.execute("alter session set nls_language='American'")
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 76 EXCEPTION - models - pforecast -
                 get_periods """ + str(error))
            raise error
        else:
            forecast_data = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - get_periods(-)')
        return forecast_data

    # to get items based on group_name
    def get_focus_items(self, group_name):
        logger.addinfo('@ models - pforecast - get_focus_items(+)')
        try:
            self.acquire()
            query = self.sql_file['get_focus_items_query']
            self.cursor.execute("alter session set nls_language='American'")
            self.cursor.execute(query, p_group_name=group_name)
        except Exception as error:
            logger.findaylog("""@ 103 EXCEPTION - models - pforecast -
                 get_focus_items """ + str(error))
            raise error
        else:
            forecast_data = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - get_focus_items(-)')
        return forecast_data

    # to change the promotion status
    def focus_status(self, jsond):
        logger.addinfo('@ models - pforecast - focus_status(+)')
        jsond = self.encode_data(jsond)
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            query = self.sql_file['get_promo_start_date']
            p_data = self.cursor.execute(query,
                                         p_promo_id=jsond[
                                                  "promo_id"])
            p_data_1 = Code_util.iterate_data(p_data)
            week = datetime.datetime.strptime(
                                             p_data_1[0][
                                                 "start_date"],
                                             "%d-%b-%Y")\
                                    .isocalendar()[1]
            week_label = "Week " + str(week)
            self.cursor.execute("""
                                begin
                                    QPEX_SALESFORECAST_PKG.approve_promo(
                                    :p_promo_id,
                                    :p_promo_name,
                                    :p_status,
                                    :p_week,
                                    :p_week_label,
                                    :x_status_code
                                    );
                                end;
                                """,
                                p_promo_id=jsond["promo_id"],
                                p_promo_name=p_data_1[0][
                                                  "promo_name"],
                                p_status=jsond["status"],
                                p_week=week,
                                p_week_label=week_label,
                                x_status_code=status_code)
            result_val = {}
            if status_code.getvalue() == "SUCCESS":
                result_val["status"] = 0
                if jsond["status"] == "APPROVED":
                    result_val["msg"] = "Promotion is Approved"
                elif jsond["status"] == "REJECTED":
                    result_val["msg"] = "Promotion is Rejected"
                else:
                    result_val["msg"] = "Promotion is Updated"

            else:
                result_val["status"] = 1
                result_val["msg"] = status_code.getvalue()
        except Exception as error:
            logger.findaylog("""@ 164 EXCEPTION - models - pforecast -
                 focus_status """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - focus_status(-)')
        return result_val

    # to delete promotion
    def delete_promo_details(self, promo_id):
        logger.addinfo('@ models - pforecast - delete_promo(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                    begin
                                        QPEX_SALESFORECAST_PKG.delete_promo
                                        (:p_promo_id,
                                         :x_status_code
                                        );
                                    end;
                                """, p_promo_id=promo_id,
                                x_status_code=status_code)
            return_val = {}
            if status_code.getvalue() == "SUCCESS":
                return_val['status'] = 0
                return_val['msg'] = "Promotion deleted successfully"
            else:
                return_val['status'] = 1
                return_val['msg'] = status_code.getvalue()
        except Exception as error:
            logger.findaylog("""@ 195 EXCEPTION - models - pforecast -
                 delete_promo """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - pforecast - delete_promo(-)')
        return return_val

    def encode_data(self, data):
        if isinstance(data, dict):
            for i in data:
                if isinstance(data[i], str):
                    data[i] = data[i].encode("UTF-8")
        return data

    def send_email(self, jsond):
        logger.addinfo('@ models - pforecast - send_email(+)')
        try:
            query = self.sql_file['sales_forecast_users']
            self.cursor.execute(query)
            emails = Code_util.iterate_data(self.cursor)
            strings = db_util.get_strings()
            if jsond['is_update']:
                subject = strings['promo_updated']
                template_id = 409121
            else:
                subject = strings['promo_created']
                template_id = 409120
            mail_data = {
                'template_id': template_id,
                'subject': subject,
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                },
                'params': [
                    {
                        'key': 'promo_name',
                        'value': jsond['promo_name']
                    },
                    {
                        'key': 'promo_id',
                        'value': jsond['promo_id']
                    },
                    {
                        'key': 'start_date',
                        'value': jsond['start_date']
                    },
                    {
                        'key': 'end_date',
                        'value': jsond['end_date']
                    },
                    {
                        'key': 'sales_channel',
                        'value': jsond['sales_channel']
                    }
                ],
                'recipients': emails
            }
            result = CommonUtils.send_mail(mail_data)
            if result != 'SUCCESS':
                logger.findaylog("""@ models - pforecast - send_email
                                    - Failed to send email - {}""".format(mail_data))
        except Exception as e:
            logger.findaylog(""" @ 246 EXCEPTION - models - pforecast -
                             send_email """ + str(e))
            raise e
        logger.addinfo('@ models - pforecast - send_email(-)')
        return 'success'

    def insert_line_details(self, jsond):
        logger.addinfo('@ models - pforecast - insert_lines(+)'
                       )
        week = datetime.datetime.strptime(jsond["start_date"], "%d-%b-%Y")\
                                .isocalendar()[1]
        week_label = "Week " + str(week)
        jsond = self.encode_data(jsond)
        lines_inventory_items = []
        lines_avg_qty_arr = []
        lines_estimated_qty_arr = []
        lines_actual_qty_arr = []
        lines_onhand_qty_arr = []
        lines_quantity_arr = []
        lines_category_id = []

        for lines in jsond["category"]:
            lines_inventory_items.append(lines["inventory_item_id"])
            if "avg_qty" not in lines or lines["avg_qty"] is None:
                lines_avg_qty_arr.append(999999)
            else:
                lines_avg_qty_arr.append(lines["avg_qty"])
            if "onhand_qty" not in lines or lines["onhand_qty"] is None:
                lines_onhand_qty_arr.append(999999)
            else:
                lines_onhand_qty_arr.append(lines["onhand_qty"])
            if "actual_qty" not in lines or lines["actual_qty"] is None:
                lines_actual_qty_arr.append(999999)
            else:
                lines_actual_qty_arr.append(lines["actual_qty"])
            lines_estimated_qty_arr.append(lines["estimated_qty"])
            lines_quantity_arr.append(-lines["estimated_qty"])
            lines_category_id.append(lines["category_id"])
        try:
            self.acquire()
            promo_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            DECLARE
                focus_lines QPEX_SALESFORECAST_PKG.focus_line_Tbl_Type_Cover;
                type number_table_t is table of number
                    index by binary_integer;

                d_lines_inventory_items number_table_t :=
                    :p_lines_inventory_items;
                d_lines_avg_qty_arr number_table_t := :p_lines_avg_qty_arr;
                d_lines_estimated_qty_arr number_table_t :=
                    :p_estimated_qty_arr;
                d_lines_actual_qty_arr number_table_t :=
                                                        :p_lines_actual_qty_arr;
                d_lines_onhand_qty_arr number_table_t :=
                                                        :p_lines_onhand_qty_arr;
                d_lines_quantity_arr number_table_t := :p_lines_quantity_arr;
                d_lines_category_id number_table_t := :p_lines_category_id;
            BEGIN
                    for j in 1..d_lines_inventory_items.count LOOP
                        focus_lines(j).inventory_item_id :=
                            d_lines_inventory_items(j);
                        focus_lines(j).avg_qty := d_lines_avg_qty_arr(j);
                        focus_lines(j).estimated_qty :=
                            d_lines_estimated_qty_arr(j);
                        focus_lines(j).quantity := d_lines_quantity_arr(j);
                        focus_lines(j).actual_qty := d_lines_actual_qty_arr(j);
                        focus_lines(j).onhand_qty := d_lines_onhand_qty_arr(j);
                        focus_lines(j).category_id := d_lines_category_id(j);
                    END LOOP;
                QPEX_SALESFORECAST_PKG. insert_lines (
                                    :p_promo_name,
                                    :p_start_date,
                                    :p_end_date,
                                    :p_sales_channel,
                                    :p_created_by,
                                    :p_last_updated_by,
                                    :p_status,
                                    focus_lines,
                                    :p_week,
                                    :p_week_label,
                                    :x_promo_id,
                                    :x_status_code
                                );
            END;

                                """,
                                p_promo_name=jsond["promo_name"],
                                p_start_date=jsond["start_date"],
                                p_end_date=jsond["end_date"],
                                p_sales_channel=jsond["sales_channel"],
                                p_created_by=jsond["created_by"],
                                p_last_updated_by=jsond["last_updated_by"],
                                p_status="PENDING",
                                p_week=week,
                                p_week_label=week_label,
                                x_promo_id=promo_id,
                                x_status_code=status_code,
                                p_lines_inventory_items=lines_inventory_items,
                                p_lines_avg_qty_arr=lines_avg_qty_arr,
                                p_estimated_qty_arr=lines_estimated_qty_arr,
                                p_lines_actual_qty_arr=lines_actual_qty_arr,
                                p_lines_onhand_qty_arr=lines_onhand_qty_arr,
                                p_lines_quantity_arr=lines_quantity_arr,
                                p_lines_category_id=lines_category_id
                                )

            result = {}
            result_id = promo_id.getvalue()
            if status_code.getvalue() == 'SUCCESS':
                result["status"] = 0
                result["message"] = "Promotion Added Successfully"
                mail_obj = {}
                mail_obj['promo_name'] = jsond['promo_name']
                mail_obj['promo_id'] = result_id
                mail_obj['start_date'] = jsond['start_date']
                mail_obj['end_date'] = jsond['end_date']
                mail_obj['sales_channel'] = jsond['sales_channel']
                mail_obj['is_update'] = False
                self.send_email(mail_obj)
            else:
                result["status"] = 1
                result["message"] = status_code.getvalue()
        except Exception as e:
            logger.findaylog("""@ 371 EXCEPTION - models - pforecast -
                 insert_lines """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - insert_lines(-)')
        return result

    def update_line_details(self, jsond):
        logger.addinfo('@ models - pforecast - update_lines(+)'
                       )
        week = datetime.datetime.strptime(jsond["start_date"], "%d-%b-%Y")\
                                .isocalendar()[1]
        week_label = "Week " + str(week)
        jsond = self.encode_data(jsond)
        lines_inventory_items = []
        lines_avg_qty_arr = []
        lines_estimated_qty_arr = []
        lines_actual_qty_arr = []
        lines_onhand_qty_arr = []
        lines_quantity_arr = []
        lines_category_id = []
        lines_id = []
        promo_id = jsond["promo_id"]
        promo_name = jsond["promo_name"]
        sales_channel = jsond["sales_channel"]
        start_date = jsond["start_date"]
        end_date = jsond["end_date"]
        status = jsond["status"]
        delete_lineid = jsond["clear_lines"]
        for lines in jsond["category"]:
            lines_inventory_items.append(lines["inventory_item_id"])
            if "avg_qty" not in lines or lines["avg_qty"] is None:
                lines_avg_qty_arr.append(999999)
            else:
                lines_avg_qty_arr.append(lines["avg_qty"])
            if "onhand_qty" not in lines or lines["onhand_qty"] is None:
                lines_onhand_qty_arr.append(999999)
            else:
                lines_onhand_qty_arr.append(lines["onhand_qty"])
            if "actual_qty" not in lines or lines["actual_qty"] is None:
                lines_actual_qty_arr.append(999999)
            else:
                lines_actual_qty_arr.append(lines["actual_qty"])
            lines_estimated_qty_arr.append(lines["estimated_qty"])
            lines_quantity_arr.append(-lines["estimated_qty"])
            lines_category_id.append(lines["category_id"])
            if "lines_id" not in lines or lines["lines_id"] is None:
                lines_id.append(-1)
            else:
                lines_id.append(lines["lines_id"])

        try:

            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            DECLARE
                focus_lines QPEX_SALESFORECAST_PKG.focus_line_Tbl_Type_Cover;
                type number_table_t is table of number
                    index by binary_integer;
                d_lines_inventory_items number_table_t :=
                    :p_lines_inventory_items;
                d_lines_avg_qty_arr number_table_t := :p_lines_avg_qty_arr;
                d_lines_estimated_qty_arr number_table_t :=
                    :p_estimated_qty_arr;
                d_lines_actual_qty_arr number_table_t :=
                                                        :p_lines_actual_qty_arr;
                d_lines_onhand_qty_arr number_table_t :=
                                                        :p_lines_onhand_qty_arr;
                d_lines_quantity_arr number_table_t := :p_lines_quantity_arr;
                d_lines_category_id number_table_t := :p_lines_category_id;
                d_line_id number_table_t := :p_line_ids;

            BEGIN
                    for j in 1..d_lines_inventory_items.count LOOP
                        focus_lines(j).inventory_item_id :=
                            d_lines_inventory_items(j);
                        focus_lines(j).avg_qty := d_lines_avg_qty_arr(j);
                        focus_lines(j).estimated_qty :=
                            d_lines_estimated_qty_arr(j);
                        focus_lines(j).quantity := d_lines_quantity_arr(j);
                        focus_lines(j).actual_qty := d_lines_actual_qty_arr(j);
                        focus_lines(j).onhand_qty := d_lines_onhand_qty_arr(j);
                        focus_lines(j).category_id := d_lines_category_id(j);
                        focus_lines(j).lines_id := d_line_id(j);
                    END LOOP;
                QPEX_SALESFORECAST_PKG.update_lines(
                                    :p_promo_id,
                                    :p_promo_name,
                                    :p_start_date,
                                    :p_end_date,
                                    :p_sales_channel,
                                    :p_last_updated_by,
                                    :p_status,
                                    focus_lines,
                                    :p_week,
                                    :p_week_label,
                                    :x_status_code
                                );
            END;

                                """,
                                p_promo_id=promo_id,
                                p_promo_name=promo_name,
                                p_start_date=start_date,
                                p_end_date=end_date,
                                p_sales_channel=sales_channel,
                                p_last_updated_by=jsond["last_updated_by"],
                                p_status=status,
                                p_week=week,
                                p_week_label=week_label,
                                x_status_code=status_code,
                                p_lines_inventory_items=lines_inventory_items,
                                p_lines_avg_qty_arr=lines_avg_qty_arr,
                                p_estimated_qty_arr=lines_estimated_qty_arr,
                                p_lines_actual_qty_arr=lines_actual_qty_arr,
                                p_lines_onhand_qty_arr=lines_onhand_qty_arr,
                                p_lines_quantity_arr=lines_quantity_arr,
                                p_lines_category_id=lines_category_id,
                                p_line_ids=lines_id
                                )

            if len(delete_lineid) > 0:
                delete_status_code = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute("""
                DECLARE
                    type number_table_t is table of number
                        index by binary_integer;
                    d_delete_lines QPEX_SALESFORECAST_PKG.line_Tbl_Type_Cover;
                    d_delete_line_ids number_table_t := :p_delete_line_ids;

                BEGIN
                        for k in 1..d_delete_line_ids.count LOOP
                            d_delete_lines(k) := d_delete_line_ids(k);
                        END LOOP;
                    QPEX_SALESFORECAST_PKG.delete_lines(
                                        :p_promo_id,
                                        d_delete_lines,
                                        :x_status_code
                                    );
                END;

                                    """,
                                    p_promo_id=promo_id,
                                    x_status_code=delete_status_code,
                                    p_delete_line_ids=delete_lineid
                                    )

            if status == "APPROVED":
                update_status_code = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute("""
                                    begin
                                        QPEX_SALESFORECAST_PKG.approve_promo(
                                        :p_promo_id,
                                        :p_promo_name,
                                        :p_status,
                                        :p_week,
                                        :p_week_label,
                                        :x_status_code
                                        );
                                    end;
                                    """,
                                    p_promo_id=promo_id,
                                    p_promo_name=start_date,
                                    p_status=status,
                                    p_week=week,
                                    p_week_label=week_label,
                                    x_status_code=update_status_code)

            result = {}
            if status_code.getvalue() == 'SUCCESS':
                result["status"] = 0
                result["message"] = "Promotion Updated Successfully"
                mail_obj = {}
                mail_obj['promo_name'] = jsond['promo_name']
                mail_obj['promo_id'] = jsond['promo_id']
                mail_obj['start_date'] = jsond['start_date']
                mail_obj['end_date'] = jsond['end_date']
                mail_obj['sales_channel'] = jsond['sales_channel']
                mail_obj['is_update'] = True
                self.send_email(mail_obj)
            else:
                result["status"] = 1
                result["message"] = status_code.getvalue()
        except Exception as e:
            logger.findaylog("""@ 557 EXCEPTION - models - pforecast -
                 update_lines """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - update_lines(-)')
        return result

    # to get all promotions
    def get_all_promotions(self, jsond):
        logger.addinfo('@ models - pforecast - get_all_promotions(+)')
        try:
            jsond = self.encode_data(jsond)
            self.acquire()
            query = self.sql_file['get_all_promotions']
            header_list = self.cursor.execute(query,
                                              p_group_name=jsond[
                                                            "sales_channel"],
                                              p_status=jsond["status"],
                                              p_start_date=jsond["start_date"],
                                              p_end_date=jsond["end_date"]
                                              )
        except Exception as error:
            logger.findaylog("""@ 580 EXCEPTION - models - pforecast -
                 get_all_promotions """ + str(error))
            raise error
        else:
            forecast_data = Code_util.iterate_data(header_list)
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - get_all_promotions(-)')
        return forecast_data

    def get_sales_id_details(self, promo_id):
        logger.addinfo('@ models - pforecast - get_sales_id_details(+)')
        try:
            self.acquire()
            query = self.sql_file['get_promotion_edit']
            header_list = self.cursor.execute(query, p_promo_id=promo_id)
        except Exception as error:
            logger.findaylog("""@ 597 EXCEPTION - models - pforecast -
                 get_sales_id_details """ + str(error))
            raise error
        else:
            promotion_details = Code_util.iterate_data(header_list)
            for promo in promotion_details:
                headers = []
                for i in promo["focus_header"]:
                    lines = []
                    for j in promo["focus_lines"]:
                        if i["category_id"] == j["category_id"]:
                            j["quantity"] = j["estimated_qty"]
                            lines.append(j)
                    i["items"] = lines
                    headers.append(i)
                promo["focus_header"] = headers
                del promo["focus_lines"]
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - get_sales_id_details(-)')
        return promotion_details

    def delete_promo_line(self, jsond):
        logger.addinfo('@ models - pforecast - delete_promo_line(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                    begin
                                        QPEX_SALESFORECAST_PKG.delete_focus
                                        (:p_promo_id,
                                         :p_category_id,
                                         :x_status_code
                                        );
                                    end;
                                """, p_promo_id=jsond["promo_id"],
                                p_category_id=jsond["category_id"],
                                x_status_code=status_code)
            return_val = {}
            if status_code.getvalue() == "SUCCESS":
                return_val['status'] = 0
                return_val['msg'] = "Focus deleted successfully"
            else:
                return_val['status'] = 1
                return_val['msg'] = status_code.getvalue()
        except Exception as error:
            logger.findaylog("""@ 643 EXCEPTION - models - pforecast -
                 delete_promo_line """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - pforecast - delete_promo_line(-)')
        return return_val
