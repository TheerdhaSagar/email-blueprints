import io
import cx_Oracle
import jinja2
import base64
import ujson
import os
import pdfkit
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.conn_util import OracleConnectionManager
from PyPDF2 import PdfFileReader, PdfFileWriter
from finapi.utils.constants import Status


@LogUtil.class_module_logs('Procurement')
class Procurement:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    def get_categories(self, lang, person_id=None):
        logger.addinfo('@ models - procurement - get_categories(+)')
        try:
            self.acquire()
            self.cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            if not lang:
                lang = 'I'
            if person_id:
                query = self.sql_file['procurement_categories_person_query']
                self.cursor.execute(query, p_language=lang,
                                    p_person_id=person_id)
            else:
                query = self.sql_file['procurement_categories']
                self.cursor.execute(query, p_language=lang)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - procurement -
                 get_categories """ + str(error))
            raise error
        else:
            categories_list = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_categories(-)')
        return categories_list

    # generate HeaderId
    def get_header_id(self):
        logger.addinfo("@ models - procurement - get_header_id(+)")
        try:
            self.acquire()
            query = self.sql_file['procurement_seq']
            data = self.cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 55 EXCEPTION - models - procurement -
             get_header_id """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo("@ models - procurement - get_header_id(-)")
        return header_id

    def insert_data(self, p_supplierlines, header_id):
        logger.addinfo('@ models - supplier - insert_data(+)')
        try:
            self.acquire()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            line_numseq = self.sql_file['procurement_line_seq']
            for line in p_supplierlines:
                data = self.cursor.execute(line_numseq).fetchone()
                line['line_id'] = data[0]
                if line['created_by'] or line['created_by'] == '':
                    del line['created_by']
                line['requisition_id'] = header_id
                values = []
                for key, val in line.items():
                    values.append(val)
                row_list.append(tuple(values))
            if p_supplierlines:
                dict_val = p_supplierlines[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            self.cursor.prepare("""insert into
            qpex_po_requisitions """ + fieldname_strng+"""
            values""" + paramater_strng)
            self.cursor.executemany(None, row_list)
        except Exception as error:
            logger.findaylog("""@ 103 EXCEPTION - models - procurement -
                 insert_data """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - procurement - insert_data(-)')
        return "success"

    def package_save(self, header_id, preparer_id):
        logger.addinfo('@ models - procurement - package_save(+)')
        returnval = {}
        try:
            self.acquire()
            return_value = self.cursor.var(cx_Oracle.STRING)
            status = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
             QPEX_PROCUREMENT_PKG.insert_order(:p_report_id, :p_requisition_id,
             :p_status);
            end;""", p_report_id=header_id, p_requisition_id=return_value,
                                p_status=status)
        except Exception as error:
            logger.findaylog("""@ 131 EXCEPTION - models - procurement -
                package_save """ + str(error))
            raise error
        else:
            if status.getvalue() == 'SUCCESS':
                returnval['status'] = 0
                returnval['msg'] = "Order created successfully"
                returnval['requisition_id'] = return_value.getvalue()
                # delete_lines_query = self.sql_file[
                #                         'procurement_attac_delete_query']
                # self.cursor.execute(delete_lines_query,
                #                     p_preparer_id=preparer_id)
                delete_lines_query = self.sql_file[
                    'procurement_del_lin_query']
                self.cursor.execute(delete_lines_query,
                                    p_preparer_id=preparer_id)
            else:
                returnval['status'] = 1
                returnval['msg'] = status.getvalue()
                returnval['requisition_id'] = ""
                logger.findaylog("""@ models - procurement - package_save - """
                                 + returnval['msg'])
        finally:
            if returnval['status'] == 0:
                self.connection.commit()
            self.release()
        logger.addinfo('@ models - procurement - package_save(-)')
        return returnval

    def attachment_save(self, jsond, requisition_id):
        logger.addinfo('@ models - procurement - attachment_save(+)')
        try:
            p_ref_id = requisition_id
            p_title = jsond['title']
            p_desc = jsond['description']
            p_file_name = jsond['file_name']
            if 'file_id' in jsond:
                p_content = self.get_attachment_data(jsond['file_id'])
                p_content = (p_content)
            else:
                p_content = (jsond['file_blob'])
            p_content_type = jsond['file_content_type']
            p_entity_name = jsond['entity_name']
            p_category_name = jsond['category_name']
            self.acquire()
            self.cursor.setinputsizes(p_blob=cx_Oracle.BLOB)
            return_value = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute(""" declare
            begin
            :retval := qpex_attachments.add_attachment(:pref,
            :ptitle, :pfilename,:pdesc, :p_blob, :pcontent_type,
            :pentity, :pcategory);end;""", pref=p_ref_id, ptitle=p_title,
                                pfilename=p_file_name, pdesc=p_desc,
                                p_blob=base64.b64decode(p_content),
                                pcontent_type=p_content_type,
                                pentity=p_entity_name,
                                pcategory=p_category_name, retval=return_value)
        except Exception as error:
            logger.findaylog("""@ 179 EXCEPTION - procurement - expense -
                 attachment_save """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - procurement - attachment_save(-)')
        return return_value

    def get_uoms(self):
        logger.addinfo('@ models - procurement - get_uoms(+)')
        try:
            self.acquire()
            self.cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = self.sql_file['procurement_uom_query']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 201 EXCEPTION - models - procurement -
                 get_uoms """ + str(error))
            raise error
        else:
            categories_list = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_uoms(-)')
        return categories_list

    def get_salechannels(self, org_id):
        logger.addinfo('@ models - procurement - get_salechannels(+)')
        try:
            self.acquire()
            self.cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = self.sql_file['procurement_saleschannel_quert']
            self.cursor.execute(query, p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ 231 EXCEPTION - models - procurement -
                 get_salechannels """ + str(error))
            raise error
        else:
            categories_list = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_salechannels(-)')
        return categories_list

    def get_orders(self, jsond):
        logger.addinfo('@ models - procurement - get_orders(+)')
        try:
            self.acquire()
            # cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            # cur.execute("""begin
            #             qpex_quotes_pub_pkg.set_org_context(:p_org);
            #             end;""", p_org=org_id)
            query = self.sql_file['procurement_summary']
            if jsond['vendor_id']:
                query = query + self.sql_file['procurement_summary_supplier']
            if jsond['start_date'] and jsond['end_date']:
                query += self.sql_file['procurement_summary_by_date']
                query = query % ("'" + jsond['start_date'] + "'", "'" + jsond['end_date'] + "'")
            elif jsond['start_date']:
                query += self.sql_file['procurement_summary_fromdate']
                query = query % ("'" + jsond['start_date'] + "'")
            elif jsond['end_date']:
                query += self.sql_file['procurement_summary_todate']
                query = query % ("'" + jsond['end_date'] + "'")
            else:
                query += self.sql_file['procurement_summary_nodate']
            query = query + ' ORDER BY creation_date DESC'
            if jsond['vendor_id']:
                self.cursor.execute(query, p_preparer_id=jsond['preparer_id'],
                                    p_status=jsond['status'],
                                    p_org_id=jsond['org_id'],
                                    p_vendor_id=jsond['vendor_id'])
            else:
                self.cursor.execute(query, p_preparer_id=jsond['preparer_id'],
                                    p_status=jsond['status'],
                                    p_org_id=jsond['org_id'])
        except Exception as error:
            logger.findaylog("""@ 274 EXCEPTION - models - procurement -
                get_orders """ + str(error))
            raise error
        else:
            orders_list = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_orders(-)')
        return orders_list

    def get_procurement_details(self, header_id, org_id):
        logger.addinfo('@ models - procurement - get_procurement_details(+)')
        has_org_id = True
        try:
            self.acquire()
            if org_id is None:
                query = self.sql_file['requisition_org_query']
                data = self.cursor.execute(
                    query, p_header_id=header_id).fetchone()
                if data is not None:
                    org_id = data[0]
                    if not org_id:
                        org_id = 82
                else:
                    headers = {}
                    headers['status'] = 1
                    msg = 'Requisition # ' + str(header_id)
                    msg = msg + ' not found'
                    headers['msg'] = msg
                    has_org_id = False
            if has_org_id:
                query = self.sql_file['get_procurement_details']
                self.cursor.execute(query, p_header_id=header_id)
                headers = Code_util.iterate_data(self.cursor)
        except Exception as error:
            logger.findaylog("""@ 263 EXCEPTION - models - procurement -
                             get_procurement_details """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_procurement_details(-)')
        return headers

    def get_header(self, header_id, org_id):
        logger.addinfo('@ models - procurement - get_header(+)')
        get_data = 1
        attachments = []
        try:
            self.acquire()
            if org_id is None:
                # get_data = 0
                query = self.sql_file['requisition_org_query']
                data = self.cursor.execute(query,
                                           P_HEADER_ID=header_id).fetchone()
                if data is not None:
                    org_id = data[0]
                    if not org_id:
                        org_id = 82
                else:
                    final = {}
                    final['status'] = 1
                    msg = 'Requisition # ' + str(header_id)
                    msg = msg + ' not found'
                    final['msg'] = msg
                    return final
            # cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            # cur.execute("""begin
            #             qpex_quotes_pub_pkg.set_org_context(:p_org);
            #             end;""", p_org=org_id)
            query = self.sql_file['procurement_header_query']
            self.cursor.execute(query, p_header_id=header_id)
            history_list = self.get_history(header_id)
        except Exception as error:
            logger.findaylog("""@ 292 EXCEPTION - models - procurement -
                get_header """ + str(error))
            raise error
        else:
            order = {}
            orders_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                for index, fn in enumerate(field_names):
                    order[fn] = row[index]

            lines = self.get_lines(header_id)
            try:
                attachments = self.get_att(str(order['requisition_header_id']),
                                           get_data)
            except AttributeError:
                attachments = []
            order['lines'] = lines
            order['history'] = history_list
            order['attachments'] = attachments
            orders_list.append(order)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_header(-)')
        return orders_list

    def get_lines(self, header_id):
        logger.addinfo('@ models - procurement - get_lines(+)')
        try:
            self.acquire()
            # cur.execute("""begin
            #             qpex_quotes_pub_pkg.set_org_context(:p_org);
            #             end;""", p_org=org_id)
            query = self.sql_file['procurement_lines_query']
            self.cursor.execute(query, p_header_id=header_id)
        except Exception as error:
            logger.findaylog("""@ 293 EXCEPTION - models - procurement -
                get_lines """ + str(error))
            raise error
        else:
            orders_list = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_lines(-)')
        return orders_list

    def delete_order(self, header_id):
        logger.addinfo('@ models - procurement - delete_order(+)')
        returnval = {}
        try:
            self.acquire()
            status = self.cursor().var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
             QPEX_PROCUREMENT_PKG.remove_order(:p_report_id, :p_status);
            end;""", p_report_id=header_id, p_status=status)
        except Exception as error:
            logger.findaylog("""@ 367 EXCEPTION - models - procurement -
                delete_order """ + str(error))
            raise error
        else:
            if status.getvalue() == 'SUCCESS':
                returnval['status'] = 0
                returnval['msg'] = "Order deleted successfully"
            else:
                returnval['status'] = 1
                returnval['msg'] = status.getvalue()
                logger.findaylog("""@ models - procurement - delete_order - """
                                 + returnval['msg'])
        finally:
            self.release()
        logger.addinfo('@ models - procurement - delete_order(-)')
        return returnval

    def get_history(self, header_id):
        logger.addinfo('@ models - procurement - get_history(+)')
        try:
            self.acquire()
            # cur.execute("""begin
            #             qpex_quotes_pub_pkg.set_org_context(:p_org);
            #             end;""", p_org=org_id)
            query = self.sql_file['procurement_history_query']
            self.cursor.execute(query, p_header_id=header_id)
        except Exception as error:
            logger.findaylog("""@ 404 EXCEPTION - models - procurement -
                get_history """ + str(error))
            raise error
        else:
            orders_list = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_history(-)')
        return orders_list

    def insert_lines_data(self, p_supplierlines):
        logger.addinfo('@ models - supplier - insert_lines_data(+)')
        temp_line_id = ''
        ids = []
        try:
            self.acquire()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            line_numseq = self.sql_file['procurement_line_seq']
            for line in p_supplierlines:
                data = self.cursor.execute(line_numseq).fetchone()
                line['LINE_ID'] = data[0]
                temp_line_id = data[0]
                values = []
                for key, value in line.items():
                    values.append(value)
                row_list.append(tuple(values))
                ids.append(temp_line_id)
            if p_supplierlines:
                dict_val = p_supplierlines[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            self.cursor.prepare("""insert into
             qpex_po_requisitions """ + fieldname_strng+"""
             values""" + paramater_strng)
            self.cursor.executemany(None, row_list)
        except Exception as error:
            logger.findaylog("""@ 459 EXCEPTION - models - procurement -
                 insert_lines_data """ + str(error))
            raise error
        finally:
            final = {}
            final['status'] = 'success'
            final['ids'] = ids
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - procurement - insert_lines_data(-)')
        return final

    def line_update(self, val_list):
        logger.addinfo('@ models - expenses - line_update(+)')
        line_id = ''
        try:
            self.acquire()
            sql_data = 'update qpex_po_requisitions set '
            for key, value in val_list.items():
                if key == 'LINE_ID':
                    line_id = value
                sql_data += str(key) + '=' + "'"
                if value is not None:
                    if "'" in str(value):
                        value = value.replace("'", "''")
                    sql_data += str(value)
                sql_data += "'"+','
            sql_data = sql_data[:-1]
            sql_data += " where LINE_ID ='" + str(line_id) + "'"
            self.cursor.execute(sql_data)
        except Exception as error:
            logger.findaylog("""@ 488 EXCEPTION - models - expenses -
                 line_update """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - line_update(-)')
        return "success"

    def insert_attachment(self, p_supplierlines, justi, req_desc):
        logger.addinfo('@ models - supplier - insert_attachment(+)')
        try:
            self.acquire()
            update_qury = self.sql_file['procurement_update_query']
            self.cursor.execute(update_qury, p_req_desc=req_desc,
                                p_justification=justi)
            count = 0
            ids = []
            preparer_id = ''
            if len(p_supplierlines) > 0:
                for data in p_supplierlines:
                    preparer_id = data['preparer_id']
                    FILE_ID = self.cursor.var(cx_Oracle.NUMBER)
                    status_code = self.cursor.var(cx_Oracle.STRING)
                    self.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
                    blob = data['file_content']
                    self.cursor.execute("""
                        begin
                        QPEX_PROCUREMENT_PKG.insert_attachment (
                        :p_file_id,
                        :p_file_name,
                        :p_file_type,
                        :p_file_content,
                        :p_preparer_id,
                        :p_supplier_id,
                        :p_supplier_site_id,
                        :x_status_code
                        );
                        end; """, p_file_id=FILE_ID,
                                        p_file_name=data['file_name'],
                                        p_file_type=data['file_type'],
                                        p_file_content=base64.b64decode(blob),
                                        p_preparer_id=data['preparer_id'],
                                        p_supplier_id=data['supplier_id'],
                                        p_supplier_site_id=data[
                                            'supplier_site_id'],
                                        x_status_code=status_code)
                    if status_code.getvalue() == 'SUCCESS':
                        count = count + 1
                        ids.append(int(FILE_ID.getvalue()))
        except Exception as error:
            logger.findaylog("""@ 532 EXCEPTION - models - procurement -
                 insert_attachment """ + str(error))
            raise error
        finally:
            final = {}
            if len(p_supplierlines) > 0:
                if len(ids) == len(p_supplierlines):
                    final['status'] = 0
                    final['msg'] = 'Attachments inserted successfully'
                    final['ids'] = ids
                else:
                    delete_query = self.sql_file[
                        'procurement_attac_delete_query']
                    self.cursor.execute(delete_query,
                                        p_preparer_id=preparer_id)
                    final['status'] = 1
                    final['msg'] = 'Failed to add attachments'
                    logger.findaylog("""@ models - procurement - insert_attachment 
                    - """ + final['msg'])
            else:
                final['status'] = 0
                final['msg'] = 'Attachments inserted successfully'
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - procurement - insert_attachment(-)')
        return final

    def get_procurement_lines(self, preparer_id, vendor_id, site_id):
        logger.addinfo('@ models - procurement - get_procurement_lines(+)')
        try:
            self.acquire()
            query = self.sql_file['get_procurement_lines']
            self.cursor.execute(query, p_preparer_id=preparer_id,
                                p_supplier_id=vendor_id,
                                p_supplier_site_id=site_id)
        except Exception as e:
            logger.findaylog(""" EXCEPTION @ 553 models - procurement -
                             get_procurement_lines """ + str(e))
            raise e
        else:
            lines = Code_util.iterate_data(self.cursor)
            line = lines[0]
        logger.addinfo('@ models - procurement - get_procurement_lines(-)')
        return line

    def get_line_details(self, preparer_id, vendor_id, site_id):
        logger.addinfo('@ models - procurement - get_line_details(+)')
        try:
            self.acquire()
            query = self.sql_file['procurement_line_details_query']
            self.cursor.execute(query, p_preparer_id=preparer_id,
                                p_supplier_id=vendor_id,
                                p_supplier_site_id=site_id)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 553 EXCEPTION - models - procurement -
                get_line_details """ + str(error))
            raise error
        else:
            orders_list = Code_util.iterate_data(self.cursor)
            final = {}
            final['lines'] = orders_list
            attachments_list = self.get_attachment_details(preparer_id,
                                                           vendor_id,
                                                           site_id)
            final['attachments'] = attachments_list
        logger.addinfo('@ models - procurement - get_line_details(-)')
        return final

    def delete_line(self, id):
        logger.addinfo('@ models - procurement - delete_line(+)')
        try:
            self.acquire()
            query = self.sql_file['procurement_line_delete_query']
            self.cursor.execute(query, p_line_id=id)
        except Exception as error:
            logger.findaylog("""@ 582 EXCEPTION - models - procurement -
                delete_line """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - procurement - delete_line(-)')
        return 'success'

    def get_attachment_details(self, preparer_id, vendor_id, site_id):
        logger.addinfo('@ models - procurement - get_attachment_details(+)')
        try:
            self.acquire()
            query = self.sql_file['procurement_attachment_query']
            self.cursor.execute(query, p_preparer_id=preparer_id,
                                p_supplier_id=vendor_id,
                                p_supplier_site_id=site_id)
        except Exception as error:
            logger.findaylog("""@ 683 EXCEPTION - models - procurement -
                get_attachment_details """ + str(error))
            raise error
        else:
            orders_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                order = {}
                for index, fn in enumerate(field_names):
                    if fn == 'file_content':
                        encoded_string = ''
                        if row[index]:
                            encoded_string = self.is_base64(row[index].read())
                        order[fn] = encoded_string.decode('utf-8')
                    else:
                        order[fn] = row[index]
                orders_list.append(order)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_attachment_details(-)')
        return orders_list

    def delete_attachment(self, id):
        logger.addinfo('@ models - procurement - delete_attachment(+)')
        try:
            self.acquire()
            query = self.sql_file['procurement_attachment_delete_query']
            self.cursor.execute(query, p_file_id=id)
        except Exception as error:
            logger.findaylog("""@ 665 EXCEPTION - models - procurement -
                delete_attachment """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - procurement - delete_attachment(-)')
        return 'success'

    def get_att(self, header_id, get_data):
        logger.addinfo('@ models - procurement - get_att(+)')
        try:
            self.acquire()
            query = self.sql_file['procurement_attachments_query']
            self.cursor.execute(query, p_attachment_seq=header_id)
        except Exception as error:
            logger.findaylog("""@ 705 EXCEPTION - models - procurement -
                get_att """ + str(error))
            raise error
        else:
            attachments_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                order = {}
                for index, fn in enumerate(field_names):
                    if fn == 'file_data' and get_data != 0 and row[index]:
                        order[fn] = self.is_base64(row[index].read()).decode('utf-8')
                    else:
                        order[fn] = row[index]
                attachments_list.append(order)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_att(-)')
        return attachments_list

    def get_account_details(self):
        logger.addinfo('@ models - procurement - get_account_details(+)')
        try:
            self.acquire()
            query = self.sql_file['procurement_accounts_query']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 739 EXCEPTION - models - procurement -
                get_account_details """ + str(error))
            raise error
        else:
            accounts = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_account_details(-)')
        return accounts

    def edit_line(self, json):
        logger.addinfo('@ models - procurement - edit_line(+)')
        try:
            self.acquire()
            header_id = json['header_id']
            line_id = json['line_id']
            category_id = json['category_id']
            gl_account = json['gl_account']
            item_description = json['item_description']
            quantity = json['quantity']
            price = json['price']
            currency = json['currency']
            description = json['description']
            status = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
             QPEX_PROCUREMENT_PKG.update_requisition_line(:p_header_id,
                                                          :p_line_id,
                                                          :p_category_id,
                                                          :p_gl_account,
                                                          :p_item_description,
                                                          :p_quantity,
                                                          :p_price,
                                                          :p_currency,
                                                          :p_description,
                                                          :p_status);
            end;""", p_header_id=header_id, p_line_id=line_id,
                                p_category_id=category_id,
                                p_gl_account=gl_account,
                                p_item_description=item_description,
                                p_quantity=quantity, p_price=price,
                                p_currency=currency, p_description=description,
                                p_status=status)
        except Exception as error:
            logger.findaylog("""@ 131 EXCEPTION - models - procurement -
                edit_line """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - procurement - edit_line(-)')
        return status.getvalue()

    def get_attachments(self, header_id, file_id):
        logger.addinfo('@ models - procurement - get_attachments(+)')
        try:
            self.acquire()
            query = self.sql_file['procurement_attachement_data_query']
            self.cursor.execute(query, p_header_id=header_id,
                                p_file_id=file_id)
        except Exception as error:
            logger.findaylog("""@ 811 EXCEPTION - models - procurement -
                get_attachments """ + str(error))
            raise error
        else:
            orders_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                order = {}
                for index, fn in enumerate(field_names):
                    if fn == 'file_data' and row[index] is not None:
                        order[fn] = self.is_base64(row[index].read()).decode('utf-8')
                    else:
                        order[fn] = row[index]
            orders_list.append(order)
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_attachments(-)')
        return orders_list

    def get_invoice(self, invoice_num):
        logger.addinfo('@ models - procurement - get_invoice(+)')
        invoice = None
        invoice_lines = []
        try:
            self.acquire()
            query = self.sql_file['po_invoice_header_query']
            self.cursor.execute(query, P_INVOICE_NUM=invoice_num)
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                invoice = {}
                for index, fn in enumerate(fieldnames):
                    invoice[fn] = row[index]
            query = self.sql_file['po_invoice_lines_query']
            self.cursor.execute(query, P_INVOICE_ID=invoice['invoice_id'])
            invoice_lines = Code_util.iterate_data(self.cursor)
            invoice['lines'] = invoice_lines
        except Exception as error:
            logger.findaylog("""@ 860 EXCEPTION - models - procurement -
                get_invoice """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_invoice(-)')
        return invoice

    def send_invoice_notification(self, invoice_num, created_by):
        logger.addinfo('@ models - procurement - send_invoice_notification(+)')
        try:
            self.acquire()
            user_name = None
            email_address = None
            query = self.sql_file['user_data_query']
            self.cursor.execute(query, p_user_id=created_by)
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                for index, fn in enumerate(fieldnames):
                    if fn == 'user_description':
                        user_name = row[index]
                    else:
                        email_address = row[index]

            if user_name and email_address:
                strings = db_util.get_strings()
                mail_data = {
                    'template_id': 107420,
                    'subject': strings['invoice_notification_mail'],
                    'sender': {
                        'email': strings['sender_email'],
                        'name': strings['sender_name']
                    },
                    'params': [
                        {
                            'key': 'user_name',
                            'value': user_name
                        },
                        {
                            'key': 'invoice_num',
                            'value': invoice_num
                        }
                    ],
                    'recipients': [
                        {
                            'Email': email_address
                        }
                    ]
                }
                res = CommonUtils.send_mail(mail_data)
                if res != 'SUCCESS':
                    logger.findaylog("""@ models - procurement - get_invoice 
                    - Failed to send notification email - {}""".format(mail_data))
        except Exception as error:
            logger.findaylog("""@ 860 EXCEPTION - models - procurement -
                get_invoice """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - procurement - send_invoice_notification(-)')
        return 'SUCCESS'

    def is_base64(self, data):
        try:
            ujson.dumps(data)
        except:
            return base64.b64encode(data)
        return data

    def get_attachment_data(self, file_id):
        logger.addinfo('@ models - procurement - get_attachment_data(+)')
        try:
            self.acquire()
            query = self.sql_file['get_attachment_data']
            self.cursor.execute(query, p_file_id=file_id)
            file_data = self.cursor.fetchone()
            if file_data is not None:
                file_data = self.is_base64(file_data[0].read()).decode('utf-8')
        except Exception as e:
            logger.findaylog(""" EXCEPTION @ 890 - models - procurement -
                             get_attachment_data """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_attachment_data(-)')
        return file_data

    def delete_custom_attachment(self, preparer_id):
        logger.addinfo('@ models - procurement - delete_custom_attachment(+)')
        try:
            self.acquire()
            delete_attachment_query = self.sql_file[
                'procurement_attac_delete_query']
            self.cursor.execute(delete_attachment_query,
                                p_preparer_id=preparer_id)
        except Exception as e:
            logger.findaylog(""" EXCEPTION @ 896 models - procurement -
                             delete_custom_attachment """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - procurement - delete_custom_attachment(-)')

    def get_procurement_flow(self, org_id, person_id):
        logger.addinfo('@ models - procurement - get_procurement_flow(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['procurement_approval_flow_query']
            self.cursor.execute(query, p_org_id=org_id, p_person_id=person_id)
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - procurement -
                get_procurement_flow """ + str(e))
        logger.addinfo('@ models - procurement - get_procurement_flow(-)')
        return result

    def get_procurement_pdf(self, jsond):
        logger.addinfo('@ models - procurement - get_procurement_pdf(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['procurement_pdf_lines_query']
            self.cursor.execute(query, p_header_id=jsond['header_id'])
            lines = Code_util.iterate_data(self.cursor, convert_data=False)
            query = self.sql_file['procurement_pdf_header_query']
            self.cursor.execute(query, p_po_num=jsond['po_num'])
            header = Code_util.iterate_data(self.cursor, convert_data=False)
            query = self.sql_file['po_total']
            self.cursor.execute(query, p_header_id=jsond['header_id'])
            total = Code_util.iterate_data(self.cursor)
            footer_address = self.get_footer_address(header[0]['p_org_id'])
            render_template, footer_template = Procurement.get_po_template(
                header[0], lines, total, footer_address)
            obj = {'page_content': render_template,
                   'file_name': 'PO_' + jsond['header_id'],
                   'footer_content': footer_template,
                   'footer_file_name': 'PO_footer_' + jsond['header_id']}
            pdf_path = '/tmp/' + obj['file_name'] + '.pdf'
            result_pdf_generation = Procurement.write_to_file(obj)
            if result_pdf_generation == "SUCCESS":
                with open(pdf_path, "rb") as pdf_file:
                    result = base64.b64encode(pdf_file.read()).decode('utf-8')
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - procurement -
                get_procurement_pdf """ + str(e))
        finally:
            self.release()
        logger.addinfo('@ models - procurement - get_procurement_pdf(-)')
        return result

    def get_po_status(self, jsond):
        logger.addinfo('@ models - procurement - get_po_status(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['check_po_number']
            self.cursor.execute(query, p_po_num=jsond['po_num'])
            count = self.cursor.fetchone()[0]
            if count == 0:
                result = {'po_status': False}
            else:
                result = {'po_status': True}

        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - procurement -
                        get_po_status """ + str(e))
        logger.addinfo('@ models - procurement - get_po_status(-)')
        return result

    def get_approval_flows(self, org_id):
        logger.addinfo('models - procurement - get_approval_flows(+)')
        try:
            query = self.sql_file['get_approval_flows']
            with OracleConnectionManager() as conn:
                conn.execute(query, p_org_id=org_id)
                approvals = conn.get_result()
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models - procurement -
                            get_approval_flows """ + str(e))
            raise e
        logger.addinfo('models - procurement - get_approval_flows(-)')
        return approvals

    def insert_approvals(self, req):
        logger.addinfo('models - procurement - insert_approvals(+)')
        try:
            with OracleConnectionManager() as conn:
                status = conn.cursor.var(cx_Oracle.STRING)
                flow_id = conn.cursor.var(cx_Oracle.NUMBER)
                conn.execute("""
                begin
                    qpex_procurement_pkg.insert_approvals(
                        :x_flow_id,
                        :p_approval_flow,
                        :p_manager_id,
                        :p_dept_id,
                        :p_org_id,
                        :p_dept_mgr_id,
                        :p_approver_id_3,
                        :p_approver_id_4,
                        :p_approver_id_5,
                        :p_approver_id_6,
                        :x_status_code
                    );
                end; """, x_flow_id=flow_id,
                             p_approval_flow=req['approval_flow'],
                             p_manager_id=req['manager_id'],
                             p_dept_id=req['dept_id'],
                             p_org_id=req['org_id'],
                             p_dept_mgr_id=req['dept_manager_id'],
                             p_approver_id_3=req['approver_id_3'],
                             p_approver_id_4=req['approver_id_4'],
                             p_approver_id_5=req['approver_id_5'],
                             p_approver_id_6=req['approver_id_6'],
                             x_status_code=status
                             )
                if status.getvalue() == 'SUCCESS':
                    result = {
                        'msg': 'Approval Flow inserted successfully',
                        'status': 0,
                        'flow_id': int(flow_id.getvalue())
                    }
                else:
                    result = {
                        'msg': 'Failed to insert approval flow',
                        'status': 1
                    }
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models- procurement -
                             insert_approvals """ + str(e))
            raise e
        logger.addinfo('models - procurement - insert_approvals(-)')
        return result

    def update_approvals(self, req):
        logger.addinfo('models - procurement - update_approvals(+)')
        try:
            with OracleConnectionManager() as conn:
                status = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_procurement_pkg.update_approvals(
                        :p_flow_id,
                        :p_approval_flow,
                        :p_manager_id,
                        :p_dept_mgr_id,
                        :p_dept_id,
                        :p_approver_id_3,
                        :p_approver_id_4,
                        :p_approver_id_5,
                        :p_approver_id_6,
                        :x_status_code
                    );
                end; """, p_flow_id=req['flow_id'],
                             p_approval_flow=req['approval_flow'],
                             p_manager_id=req['manager_id'],
                             p_dept_mgr_id=req['dept_manager_id'],
                             p_dept_id=req['dept_id'],
                             p_approver_id_3=req['approver_id_3'],
                             p_approver_id_4=req['approver_id_4'],
                             p_approver_id_5=req['approver_id_5'],
                             p_approver_id_6=req['approver_id_6'],
                             x_status_code=status
                             )
                if status.getvalue() == 'SUCCESS':
                    result = {
                        'msg': 'Approval Flow updated successfully',
                        'status': 0,
                        'flow_id': req['flow_id']
                    }
                else:
                    result = {
                        'msg': 'Failed to update approval flow',
                        'status': 1
                    }
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models- procurement -
                             update_approvals """ + str(e))
            raise e
        logger.addinfo('models - procurement - update_approvals(-)')
        return result

    def delete_approvals(self, org_id, flow_id):
        logger.addinfo('models - procurement - delete_approvals(+)')
        try:
            with OracleConnectionManager() as conn:
                status = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_procurement_pkg.delete_approvals(
                        :p_flow_id,
                        :p_org_id,
                        :x_status_code
                    );
                end; """, p_flow_id=flow_id,
                             p_org_id=org_id,
                             x_status_code=status
                             )
                if status.getvalue() == 'SUCCESS':
                    result = {
                        'msg': 'Approval Flow deleted successfully',
                        'status': 0,
                        'flow_id': flow_id
                    }
                else:
                    result = {
                        'msg': 'Failed to delete approval flow',
                        'status': 1
                    }
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models- procurement -
                             delete_approvals """ + str(e))
            raise e
        logger.addinfo('models - procurement - delete_approvals(-)')
        return result

    @staticmethod
    def write_to_file(obj):
        logger.addinfo("@ models - procurement - write_to_file(+)")
        try:
            tmp_path = '/tmp/'
            page_content = obj['page_content']
            with io.open(tmp_path + obj['footer_file_name'] + '.html', "w", encoding="utf-8") as footer_file:
                footer_file.write(obj['footer_content'])
                footer_file.close()
            options = {
                "page-size": "A4",
                "quiet": "",
                "encoding": "utf-8",
                "dpi": 700,
                "margin-bottom": "45mm",
                "footer-html": tmp_path + obj['footer_file_name'] + '.html'
            }
            file_path = tmp_path
            html_file_name = obj['file_name'] + ".html"
            pdf_name = obj['file_name'] + ".pdf"
            with io.open(file_path + html_file_name, "w", encoding="utf-8") as changed:
                changed.write(page_content)
                changed.close()
                pdfkit.from_file(file_path + html_file_name, file_path + pdf_name, options=options)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - procurement - models -
                                 write_to_file """ + str(e))
            raise e
        logger.addinfo("@ models - procurement - write_to_file(-)")
        return "SUCCESS"

    @staticmethod
    def get_po_template(header, lines, total, footer_address):
        logger.addinfo('@ models - procurement - get_po_template(+)')
        try:
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__))) + '/static/'
            environment = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path),
                autoescape=True
            )
            template = environment.get_template('po_pdf.html').render(
                po_num=header['po_number'],
                order_date=header['order_date'],
                term_name=header['terms_name'],
                ship_to_loc_code=header['ship_to_loc_code'],
                ship_to_location=header['ship_to_location'],
                ship_to_address1=header['ship_to_address1'],
                ship_to_country=header['ship_to_country'],
                supplier_name=header['supplier_name'],
                vendor_address1=header['vendor_address1'],
                vendor_zip=header['vendor_zip'],
                vendor_city=header['vendor_city'],
                vendor_country=header['vendor_country'],
                lines=lines,
                total=total[0]['total'],
                header_logo=CommonUtils.get_header_logo(header['p_org_id'])
            )
            footer_template = environment.get_template('footer.html').render(
                footer_address=footer_address
            )
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - procurement -
                get_po_template """ + str(error))
            raise error
        logger.addinfo('@ models - procurement - get_po_template(-)')
        return template, footer_template

    def get_department_summary(self, org_id):
        """
        For getting all the departments that are present for the procurement purchase orders
        """
        logger.addinfo('@ models - procurement - get_department_summary(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_department_summary']
                conn.execute(query, p_org_id=org_id)
                department_details = conn.get_result()
            result = {
                'status': Status.OK.value,
                'departments': department_details
            }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION -  models - procurement -
                get_department_summary """ + str(error))
            raise error
        logger.addinfo('@ models - procurement - get_department_summary(+)')
        return result

    def get_department_details(self, department_id, language_id):
        """
            Get all accounts and persons mapped to a single department
            @:param department_id: integer
            @:param language_id: string
            @:return: json object {'status':'', 'details':[]}
        """
        logger.addinfo('@ models - procurement - get_department_details(-)')
        try:
            if not language_id:
                return {'status': Status.ERROR.value, 'msg': 'Language is not found'}
            if not department_id:
                return {'status': Status.ERROR.value, 'msg': 'Department Id is not found'}
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_department_details']
                conn.cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
                conn.execute(query, p_dept_id=department_id, p_language=str(language_id))
                department_id_details = conn.get_result()
            result = {
                'status': Status.OK.value,
                'details': department_id_details
            }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION -  models - procurement -
                get_department_details """ + str(error))
            raise error
        logger.addinfo('@ models - procurement - get_department_details(+)')
        return result

    def get_accounts_lov(self, language_id):
        """
            Get all accounts that are available
            @:param language_id: get account category_name based on language
            @:return jsonobject: {'status':'','accounts':[]}
        """
        logger.addinfo('@ models - procurement - get_accounts_lov(-)')
        try:
            if not language_id:
                return {'status': Status.ERROR.value, 'msg': 'Language is not found'}
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_account_ids_lov']
                conn.cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
                conn.execute(query, p_language=language_id)
                accounts_details = conn.get_result()
            result = {
                'status': Status.OK.value,
                'accounts': accounts_details
            }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION -  models - procurement -
                get_accounts_lov """ + str(error))
            raise error
        logger.addinfo('@ models - procurement - get_accounts_lov(+)')
        return result

    @staticmethod
    def manage_dept_accounts_and_users(method, request_data):
        """
        Add accounts, users to the department id and if department_id is
        empty insert the department
        Delete accounts, users linked to department id
        @:param request_data: {
                        "insert_employees":[635],
                        "insert_accounts":[4070105],
                        "delete_accounts":[],
                        "delete_employees":[],
                        "department_id": "",
                        "department_name":"",
                        "manager_id": "",
                        "org_id": ""}
        @:return jsonObject: {'status':'','msg':''}
        """
        logger.addinfo('@ models - procurement - manage_dept_accounts_and_users(-)')
        try:
            if request_data['department_id'] is None:
                return {'status': 1, 'msg': 'Department Id is required'}
            with OracleConnectionManager() as conn:
                x_status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute('''
                    BEGIN
                        QPEX_PROCUREMENT_PKG.manage_dept_accounts_and_users(
                        :p_insert_account,
                        :p_delete_account,
                        :p_insert_users,
                        :p_delete_users,
                        :p_department_id,
                        :p_department_name,
                        :p_manager_id,
                        :p_org_id,
                        :p_map_type,
                        :x_status_code
                        );
                    END;''', p_insert_account=conn.cursor.arrayvar(cx_Oracle.NUMBER,
                                                                   request_data['insert_accounts']),
                             p_delete_account=conn.cursor.arrayvar(cx_Oracle.NUMBER,
                                                                   request_data['delete_accounts']),
                             p_insert_users=conn.cursor.arrayvar(cx_Oracle.NUMBER,
                                                                 request_data['insert_employees']),
                             p_delete_users=conn.cursor.arrayvar(cx_Oracle.NUMBER,
                                                                 request_data['delete_employees']),
                             p_department_id=request_data['department_id'],
                             p_department_name=request_data['department_name'],
                             p_manager_id=request_data['manager_id'],
                             p_org_id=request_data['org_id'],
                             p_map_type='new' if method == 'POST' else 'exist',
                             x_status_code=x_status_code)
                if x_status_code.getvalue() == 'SUCCESS':
                    result = {
                        'status': Status.OK.value,
                        'msg': 'Mapping details are {} successfully'.format(
                            'added' if method == 'POST' else 'updated'
                        )
                    }
                else:
                    result = {
                        'status': Status.ERROR.value,
                        'accounts': 'Failed to {0} the map details - {1}'.format(
                            'add' if method == 'POST' else 'update',
                            x_status_code.getvalue()
                        )
                    }

        except Exception as error:
            logger.findaylog("""@ EXCEPTION -  models - procurement -
                manage_dept_accounts_and_users """ + str(error))
            raise error
        logger.addinfo('@ models - procurement - manage_dept_accounts_and_users(+)')
        return result

    @staticmethod
    def delete_department_details(department_id, org_id):
        """
        To delete the department details from DB
        @:param department_id: number
        @:param org_id: number,
        :return:{'status':'','msg':''}
        """
        logger.addinfo('@ models - procurement - delete_department_details(-)')
        try:
            if not department_id:
                return {'status': Status.ERROR.value, 'msg': 'Department Id is required'}
            if not org_id:
                return {'status': Status.ERROR.value, 'msg': 'Org Id is required'}
            with OracleConnectionManager() as conn:
                x_status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                             BEGIN
                                QPEX_PROCUREMENT_PKG.delete_department_details(
                                :p_department_id,
                                :p_org_id,
                                :x_status_code
                                );
                             END;
                             """, p_department_id=department_id,
                             p_org_id=org_id,
                             x_status_code=x_status_code)
            if x_status_code.getvalue() == 'SUCCESS':
                result = {
                    'status': Status.OK.value,
                    'msg': 'Department and related mappings are deleted successfully'
                }
            else:
                result = {
                    'status': Status.ERROR.value,
                    'accounts': 'Failed to delete the department details - {0}'.format(
                        x_status_code.getvalue()
                    )
                }

        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - procurement -
                delete_department_details """ + str(error))
            raise error
        logger.addinfo('@ models - procurement - delete_department_details(+)')
        return result

    def validate_department_details(self, department_id, department_name):
        """
        To validate department id and department name
        :param department_id: number
        :param department_name: string
        :return: {'status':'', 'name':''}
        """
        logger.addinfo('@ models - procurement - validate_department_details(-)')
        try:
            with OracleConnectionManager() as conn:
                if department_id:
                    query = self.sql_file['validate_department_id']
                    conn.execute(query,
                                 p_validate=department_id)
                else:
                    query = self.sql_file['validate_department_name']
                    conn.execute(query,
                                 p_validate=department_name)

                response = conn.get_single_result()
            if response['total_count'] > 0:
                result = {'status': Status.ERROR.value,
                          'msg': '{} already exists'.format(
                              'Department ID' if department_id else
                              'Department Name'
                          )
                          }
            else:
                result = {'status': Status.OK.value,
                          'msg': '{} does not exist'.format(
                              'Department ID' if department_id else
                              'Department Name'
                          )
                          }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - procurement -
                validate_department_details """ + str(error))
            raise error
        logger.addinfo('@ models - procurement - validate_department_details(+)')
        return result

    def get_footer_address(self, org_id):
        try:
            footer_address = ''
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_footer_address']
                conn.execute(query, p_org_id=org_id)
                result = conn.get_result(convert_data=True)
                if result:
                    footer_address = result[0]['footer_note']
        except Exception as error:
            logger.findaylog("""@ EXCEPTION -  models - procurement -
                            get_footer_address """ + str(error))
            raise error
        return footer_address

    def get_next_department_id(self):
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_new_department_id']
            conn.execute(query)
            result = conn.get_single_result(convert_data=True)
        return result['department_id']
