from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('agent_targets')
class AgentTargets(object):
    def __init__(self):
        self.sql_file = sql_util.get_sql('agent_targets')

    def get_target_templates(self, template_id):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['agent_targets_templates_query']
            conn.execute(query, p_template_id=template_id)
            result = conn.get_result()
            if template_id:
                query = self.sql_file['template_lines_query']
                conn.execute(query, p_template_id=template_id)
                lines = conn.get_result()
                result = {
                    'header': result[0],
                    'lines': lines
                }
        return result

    def get_agent_targets(self, template_id):
        result = {}
        with OracleConnectionManager() as conn:
            query = self.sql_file['agent_targets_query']
            conn.execute(query, p_template_id=template_id)
            targets = conn.get_result()
            query = self.sql_file['template_lines_query']
            conn.execute(query, p_template_id=template_id)
            lines = conn.get_result()
            result = {
                'lines': lines,
                'targets': targets
            }
        return result

    def send_email(self, req):
        result = {'status': 0, 'msg': 'Email sent successfully'}
        with OracleConnectionManager() as conn:
            query = self.sql_file['template_dates_query']
            conn.execute(query, p_template_id=req['temp_id'])
            data = conn.get_single_result()
            if data:
                errcod = conn.set_output_param()
                errmsg = conn.set_output_param()
                conn.execute("""
                begin
                    almo_send_target_email(
                        :errcod,
                        :errmsg,
                        :p_date_from,
                        :p_date_to,
                        :p_send_email_flag,
                        :p_subject
                    );
                end; """, errcod=errcod,
                             errmsg=errmsg,
                             p_date_from=data['start_date'],
                             p_date_to=data['end_date'],
                             p_send_email_flag='Y',
                             p_subject=req['subject'])
                if errcod.getvalue() or errmsg.getvalue():
                    result['status'] = 1
                    result['msg'] += ' errcod %s' % (errcod.getvalue())
                    result['msg'] += ' errmsg %s' % (errmsg.getvalue())
        return result

    def get_salesreps(self):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['salesreps_query']
            conn.execute(query)
            result = conn.get_result()
        return result

    @staticmethod
    def update_template(req):
        result = AgentTargets.update_template_header(req['header'])
        if result['status'] == 0:
            result = AgentTargets.update_template_lines(req['lines'], req['header']['user_id'])
        return result

    @staticmethod
    def update_template_header(header):
        result = {'status': 0, 'msg': 'Template header updated successfully'}
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                qpex_agent_targets_pkg.update_template_header(
                    :p_temp_hdr_id,
                    :p_temp_name,
                    :p_period_name,
                    :p_period_month,
                    :p_period_year,
                    :p_start_date,
                    :p_end_date,
                    :p_user_id,
                    :x_status_code
                );
            end; """, p_temp_hdr_id=header['temp_hdr_id'],
                         p_temp_name=header['temp_name'],
                         p_period_name=header['period_name'],
                         p_period_month=header['period_month'],
                         p_period_year=header['period_year'],
                         p_start_date=header['start_date'],
                         p_end_date=header['end_date'],
                         p_user_id=header['user_id'],
                         output_key='x_status_code')
            status = conn.get_output_param(raise_exception=False)
            if status == 'SUCCESS':
                return result
            return status

    @staticmethod
    def update_template_lines(lines, user_id):
        result = {'status': 0, 'msg': 'Template updated successfully'}
        with OracleConnectionManager() as conn:
            for line in lines:
                conn.execute("""
                begin
                    qpex_agent_targets_pkg.update_template_line(
                        :p_temp_hdr_id,
                        :p_line_num,
                        :p_line_name,
                        :p_bonus_percentage,
                        :p_user_id,
                        :x_status_code
                    );
                end; """, p_temp_hdr_id=line['temp_hdr_id'],
                             p_line_num=line['line_num'],
                             p_line_name=line['line_name'],
                             p_bonus_percentage=line['bonus_percentage'],
                             p_user_id=user_id,
                             output_key='x_status_code')
                status = conn.get_output_param(raise_exception=False)
                if status != 'SUCCESS':
                    result['status'] = 1
                    result['msg'] += 'Failed to update line %s. ' % (line['line_num'])
            return result

    @staticmethod
    def copy_template(template_id, user_id):
        result = {'status': 0, 'msg': 'Template copied successfully'}
        with OracleConnectionManager() as conn:
            temp_hdr_id = conn.set_output_param('NUMBER')
            conn.execute("""
            begin
                qpex_agent_targets_pkg.copy_template(
                    :p_temp_hdr_id,
                    :p_user_id,
                    :x_temp_hdr_id,
                    :x_status_code
                );
            end; """, p_temp_hdr_id=template_id,
                         p_user_id=user_id,
                         x_temp_hdr_id=temp_hdr_id,
                         output_key='x_status_code')
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result = {'status': 1, 'msg': status}
            else:
                result['template_id'] = int(temp_hdr_id.getvalue())
        return result

    @staticmethod
    def insert_agent_target(req):
        result = {'status': 0, 'msg': 'Agent target inserted successfully'}
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                qpex_agent_targets_pkg.insert_agent_target(
                    :p_temp_id,
                    :p_salesrep_id,
                    :p_level_1_description,
                    :p_level_2_description,
                    :p_level_3_description,
                    :p_level_4_description,
                    :p_level_5_description,
                    :p_user_id,
                    :x_status_code
                );
            end; """, p_temp_id=req['temp_id'],
                         p_salesrep_id=req['salesrep_id'],
                         p_level_1_description=req['level_1_description'],
                         p_level_2_description=req['level_2_description'],
                         p_level_3_description=req['level_3_description'],
                         p_level_4_description=req['level_4_description'],
                         p_level_5_description=req['level_5_description'],
                         p_user_id=req['user_id'],
                         output_key='x_status_code')
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result = {'status': 1, 'msg': status}
        return result

    @staticmethod
    def update_agent_target(req):
        result = {'status': 0, 'msg': 'Agent target updated successfully'}
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                qpex_agent_targets_pkg.update_agent_target(
                    :p_temp_id,
                    :p_salesrep_id,
                    :p_level_1_target_amount,
                    :p_level_2_target_amount,
                    :p_level_3_target_amount,
                    :p_level_4_target_amount,
                    :p_level_5_target_amount,
                    :p_user_id,
                    :x_status_code
                );
            end; """, p_temp_id=req['temp_id'],
                         p_salesrep_id=req['salesrep_id'],
                         p_level_1_target_amount=req['level_1_target_amount'],
                         p_level_2_target_amount=req['level_2_target_amount'],
                         p_level_3_target_amount=req['level_3_target_amount'],
                         p_level_4_target_amount=req['level_4_target_amount'],
                         p_level_5_target_amount=req['level_5_target_amount'],
                         p_user_id=req['user_id'],
                         output_key='x_status_code')
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result = {'status': 1, 'msg': status}
        return result

    @staticmethod
    def delete_agent_target(template_id, salesrep_id):
        result = {'status': 0, 'msg': 'Agent target deleted successfully'}
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                qpex_agent_targets_pkg.delete_agent_target(
                    :p_temp_id,
                    :p_salesrep_id,
                    :x_status_code
                );
            end; """, p_temp_id=template_id,
                         p_salesrep_id=salesrep_id,
                         output_key='x_status_code')
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result = {'status': 1, 'msg': status}
        return result

    @staticmethod
    def delete_template(template_id):
        result = {'status': 0, 'msg': 'Template deleted successfully'}
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                qpex_agent_targets_pkg.delete_template(
                    :p_temp_hdr_id,
                    :x_status_code
                );
            end; """, p_temp_hdr_id=template_id, output_key='x_status_code')
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result = {'status': 1, 'msg': status}
        return result
