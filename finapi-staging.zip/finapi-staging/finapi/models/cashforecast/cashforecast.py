import os
import xlsxwriter
import uuid
from xlsxwriter.utility import xl_rowcol_to_cell
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.conn_util import OracleConnectionManager
from finapi.sql import sql_util
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('Cashforecast')
class Cashforecast:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def intercmpny_gl(p_period, p_ledgerid):
        logger.addinfo('@ models - cashforecast - intercmpny_gl(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['inercmpny_glqry']
            cur.execute("alter session set nls_language='American'")
            cur.execute(query, p_ledger_id=p_ledgerid, P_PERIOD=p_period)
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - models - cashforecast -
                 intercmpny_gl """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            intercmpny_gldatalst = []
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                intercmpny_gldatalst.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - cashforecast - intercmpny_gl(-)')
        return intercmpny_gldatalst

    @staticmethod
    def GetCustomer_aging(org_id):
        logger.addinfo('@ models - cashforecast - GetCustomer_aging(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['customer_aging_qry']
            cur.execute("alter session set nls_language='American'")
            cur.execute(query, P_ORG_ID=org_id)
        except Exception as error:
            logger.findaylog("""@ 55 EXCEPTION - models - cashforecast -
                 GetCustomer_aging """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            customer_agingdatalst = []
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                customer_agingdatalst.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - cashforecast - GetCustomer_aging(-)')
        return customer_agingdatalst

    @staticmethod
    def GetSupplier_aging_v(org_id):
        logger.addinfo('@ models - cashforecast - GetSupplier_aging_v(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_aging_v_qry']
            cur.execute("alter session set nls_language='American'")
            cur.execute(query, P_ORG_ID=org_id)
        except Exception as error:
            logger.findaylog("""@ 85 EXCEPTION - models - cashforecast -
                 GetSupplier_aging_v """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            supplier_agingdatalst = []
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                supplier_agingdatalst.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - cashforecast - GetSupplier_aging_v(-)')
        return supplier_agingdatalst

    @staticmethod
    def GetArinterface_v(p_org_id):
        logger.addinfo('@ models - cashforecast - GetArinterface_v(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['ar_interface_v_qry']
            cur.execute("alter session set nls_language='American'")
            cur.execute(query, p_org_id=p_org_id)
        except Exception as error:
            logger.findaylog("""@ 115 EXCEPTION - models - cashforecast -
                 GetArinterface_v """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            supplier_arinterdatalst = []
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                supplier_arinterdatalst.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - cashforecast - GetArinterface_v(-)')
        return supplier_arinterdatalst

    @staticmethod
    def get_forecast_data(req):
        with OracleConnectionManager() as conn:
            if req.get('is_balance'):
                sql_file = sql_util.get_sql('cashforecast')
                query = sql_file['forecast_balance_query']
                conn.execute(query, p_org_id=req.get('org_id'),
                             p_due_date=req.get('due_date'))
            else:
                sql_file = db_util.getSqlData()
                query = sql_file['forecast_data_summary']
                condition_one = ''
                condition_two = ''
                if req.get('bank_id'):
                    condition_one = sql_file['forecast_bank_condition_1']
                    condition_two = sql_file['forecast_bank_condition_2']
                query = query.format(cond1=condition_one, cond2=condition_two)
                if req.get('bank_id'):
                    conn.execute(query, p_org_id=req.get('org_id'),
                                 p_bank_id=req.get('bank_id'))
                else:
                    conn.execute(query, p_org_id=req.get('org_id'))
            result = conn.get_result()
        return result

    @staticmethod
    def get_cash_receipt():
        logger.addinfo('@ models - cashforecast - get_cash_receipt(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['cash_receipt_query']
            cur.execute("alter session set nls_language='American'")
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 176 EXCEPTION - models - cashforecast -
                    get_cash_receipt """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            forecast_data = []
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                forecast_data.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - cashforecast - get_cash_receipt(-)')
        return forecast_data

    @staticmethod
    def get_receipt_lines(org_id):
        logger.addinfo('@ models - cashforecast - get_receipt_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            cur.execute("""begin
                        mo_global.set_policy_context('S', :p_org);
                        end;""", p_org=org_id)
            query = sql_file['receipt_details_query']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 208 EXCEPTION - models - cashforecast -
                    get_receipt_lines """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            forecast_data = []
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                forecast_data.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - cashforecast - get_receipt_lines(-)')
        return forecast_data

    @staticmethod
    def get_weeks():
        logger.addinfo('@ models - cashforecast - get_weeks(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['weeks_query']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 237 EXCEPTION - models - cashforecast -
                 get_weeks """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            weeks_data = []
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                weeks_data.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - cashforecast - get_weeks(-)')
        return weeks_data

    @staticmethod
    def get_po_forecast(org_id):
        logger.addinfo('@ models - cashforecast - get_po_forecast(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['cashforecast_pos_query']
            cur.execute(query, p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ 266 EXCEPTION - models - cashforecast -
                    get_po_forecast """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            forecast_data = []
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                forecast_data.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - cashforecast - get_po_forecast(-)')
        return forecast_data

    @staticmethod
    def export_forecast_data(org_id):
        result = {}
        cashforecast = Cashforecast()
        forecast_data = cashforecast.get_forecast_data(org_id)
        if forecast_data:
            excel_data = {
                'Forecast': forecast_data
            }
            forecast_data = sorted(forecast_data, key=lambda k: k['description'])
            for i in range(len(forecast_data)):
                if forecast_data[i]['show_drill_down']:
                    excel_data[forecast_data[i]['description']] = cashforecast.get_forecast_drilldown(
                        forecast_data[i]['description'], org_id)
            f_name = generate_forecast_excel("cash_forecast", excel_data)
            result["filename"] = f_name
        else:
            result = {
                'status': 1,
                'msg': 'No data found'
            }
        return result

    @staticmethod
    def supplier_setup(req):
        result = {'status': 0}
        with OracleConnectionManager() as connection:
            sql_file = sql_util.get_sql('cashforecast')
            if req['method'] == 'GET':
                query = sql_file['supplier_cashflow_setup_query']
                connection.execute(query, p_org_id=req['org_id'])
                result = connection.get_result()
            elif req['method'] == 'DELETE':
                query = sql_file['supplier_cashflow_delete']
                connection.execute(query, p_vendor_id=req['vendor_id'],
                                   p_org_id=req['org_id'])
                result['msg'] = 'Data deleted successfully'
            elif req['method'] == 'POST':
                query = sql_file['supplier_cashflow_insert']
                connection.execute(query, p_vendor_id=req['vendor_id'],
                                   p_days=req['days'],
                                   p_user_id=req['user_id'],
                                   p_org_id=req['org_id'])
                result['msg'] = 'Data added successfully'
            else:
                query = sql_file['supplier_cashflow_update']
                connection.execute(query, p_vendor_id=req['vendor_id'],
                                   p_days=req['days'],
                                   p_user_id=req['user_id'],
                                   p_org_id=req['org_id'])
                result['msg'] = 'Data updated successfully'
        return result

    @staticmethod
    def manage_bank_accounts(req):
        result = {'status': 0}
        with OracleConnectionManager() as connection:
            sql_file = sql_util.get_sql('cashforecast')
            if req['method'] == 'GET':
                query = sql_file['bank_accounts_query']
                connection.execute(query, p_org_id=req['org_id'])
                result = connection.get_result()
            elif req['method'] == 'DELETE':
                query = sql_file['delete_bank_query']
                connection.execute(query, p_bank_id=req['bank_id'])
                result['msg'] = 'Bank account deleted successfully'
            elif req['method'] == 'POST':
                query = sql_file['bank_account_insert']
                connection.execute(query, p_bank_account_identifier=str(uuid.uuid4()),
                                   p_bank_name=req.get('bank_name', ''),
                                   p_account_number=req.get('account_number', ''),
                                   p_account_name=req.get('account_name', ''),
                                   p_currency_code=req.get('currency_code', ''),
                                   p_current_balance=req.get('current_balance', 0),
                                   p_exchange_rate=req.get('exchange_rate', 0),
                                   p_organization_id=req['organization_id'],
                                   p_statement_date=req.get('statement_date', ''),
                                   p_statement_identifier=req.get('statement_identifier', ''))
                result['msg'] = 'Bank account added successfully'
            else:
                query = sql_file['bank_account_update']
                connection.execute(query, p_bank_account_identifier=req['bank_account_identifier'],
                                   p_current_balance=req.get('current_balance', 0),
                                   p_bank_name=req.get('bank_name', ''),
                                   p_account_number=req.get('account_number', ''),
                                   p_account_name=req.get('account_name', ''),
                                   p_currency_code=req.get('currency_code', ''),
                                   p_exchange_rate=req.get('exchange_rate', 0),
                                   p_statement_date=req.get('statement_date', ''),
                                   p_statement_identifier=req.get('statement_identifier', ''))
                result['msg'] = 'Bank account updated successfully'
        return result

    @staticmethod
    def budget_setup(req):
        result = {'status': 0}
        with OracleConnectionManager() as connection:
            sql_file = sql_util.get_sql('cashforecast')
            if req['method'] == 'GET':
                query = sql_file['budget_details_query']
                connection.execute(query, p_org_id=req['org_id'])
                result = connection.get_result()
            elif req['method'] == 'PUT':
                query = sql_file['budget_update_query']
                connection.execute(query, p_budget_name=req.get('budget_name', ''),
                                   p_frequency=req.get('frequency', ''),
                                   p_amount=req.get('amount', 0),
                                   p_due_date=req.get('due_date'),
                                   p_bank_id=req.get('bank_account_identifier'),
                                   p_org_id=req['org_id'],
                                   p_budget_id=req['budget_id'])
                result['msg'] = 'Budget updated successfully'
            elif req['method'] == 'POST':
                query = sql_file['budget_insert_query']
                connection.execute(query, p_budget_name=req.get('budget_name', ''),
                                   p_org_id=req['org_id'],
                                   p_frequency=req.get('frequency', ''),
                                   p_amount=req.get('amount', 0),
                                   p_due_date=req.get('due_date'))
                result['msg'] = 'Budget added successfully'
            else:
                query = sql_file['budget_delete_query']
                connection.execute(query, p_budget_id=req['budget_id'],
                                   p_org_id=req['org_id'])
                result['msg'] = 'Budget deleted successfully'
        return result

    @staticmethod
    def exclude_invoices(req):
        result = {'status': 0, 'msg': 'Invoices excluded successfully'}
        with OracleConnectionManager() as conn:
            for row in req:
                conn.execute("""
                begin
                    almo_ce_pkg.exclude_invoices(
                        :p_cashflow_id,
                        :x_status_code
                    );
                end; """, output_key='x_status_code',
                             p_cashflow_id=row['cashflow_id'])
                status = conn.get_output_param()
                if status != 'SUCCESS':
                    result['msg'] = 'Failed to exclude invoice %s' % (req['cf_txn_num'])
                    break
        return result

    @staticmethod
    def update_cashflow_bank(req):
        result = {'status': 0, 'msg': 'Bank updated successfully'}
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                almo_ce_pkg.update_cashflow_bank(
                    :p_cashflow_id,
                    :p_account_name,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         p_cashflow_id=req['cashflow_id'],
                         p_account_name=req['gl_account'])
            status = conn.get_output_param()
            if status != 'SUCCESS':
                result['msg'] = 'Failed to update bank %s' % (status)
        return result

    @staticmethod
    def get_excluded_invoices(org_id):
        result = []
        with OracleConnectionManager() as conn:
            sql_file = sql_util.get_sql('cashforecast')
            query = sql_file['excluded_invoices_query']
            conn.execute(query, p_org_id=org_id)
            result = conn.get_result()
        return result

    @staticmethod
    def remove_excluded_invoices(req):
        result = {'status': 0, 'msg': 'Invoices removed from exclusion successfully!'}
        with OracleConnectionManager() as conn:
            for row in req:
                conn.execute("""
                begin
                    almo_ce_pkg.delete_invoice_from_exclusion(
                        :p_exclusion_id,
                        :x_status_code
                    );
                end; """, p_exclusion_id=row['exclusion_id'],
                             output_key='x_status_code')
                status = conn.get_output_param()
                if status != 'SUCCESS':
                    result['msg'] = 'Failed to remove invoice %s' % (req['reference_num'])
                    break
        return result

    @staticmethod
    def get_forecast_drilldown(budget_type, org_id):
        with OracleConnectionManager() as conn:
            sql_file = db_util.getSqlData()
            query = sql_file['forecast_drilldown_data']
            conn.execute(query, p_org_id=org_id,
                         p_cf_type=budget_type)
            result = conn.get_result()
        return result


def get_column_names(budget_type):
    budget_type = ' '.join(budget_type.split('_')).lower()
    column_names = []
    payment_method_obj = {
        'excel_name': 'Payment Method',
        'column_name': 'payment_method'
    }
    due_date_obj = {
        'excel_name': 'Due Date',
        'column_name': 'due_date'
    }
    if budget_type == 'customer invoices':
        column_names = [
            {
                'excel_name': 'Party Name',
                'column_name': 'supplier_name'
            },
            {
                'excel_name': 'Account',
                'column_name': 'gl_account'
            },
            due_date_obj,
            payment_method_obj,
            {
                'excel_name': 'Term Name',
                'column_name': 'payment_term'
            },
            {
                'excel_name': 'Trx #',
                'column_name': 'invoice_number'
            },
            {
                'excel_name': 'Currency',
                'column_name': 'currency_code'
            },
            {
                'excel_name': 'Amount',
                'column_name': 'base_amount'
            },
            {
                'excel_name': 'Over Due',
                'column_name': 'w0'
            },
            {
                'excel_name': 'W1',
                'column_name': 'w1'
            },
            {
                'excel_name': 'W2',
                'column_name': 'w2'
            },
            {
                'excel_name': 'W3',
                'column_name': 'w3'
            },
            {
                'excel_name': 'W4',
                'column_name': 'w4'
            },
            {
                'excel_name': 'W5',
                'column_name': 'w5'
            },
            {
                'excel_name': 'W6',
                'column_name': 'w6'
            },
            {
                'excel_name': 'W7',
                'column_name': 'w7'
            },
            {
                'excel_name': 'W8',
                'column_name': 'w8'
            }
        ]
    elif budget_type == 'to be invoiced':
        column_names = [
            {
                'excel_name': 'Party Name',
                'column_name': 'supplier_name'
            },
            {
                'excel_name': 'Account',
                'column_name': 'gl_account'
            },
            due_date_obj,
            {
                'excel_name': 'Trx #',
                'column_name': 'invoice_date'
            },
            payment_method_obj,
            {
                'excel_name': 'Term Name',
                'column_name': 'payment_term'
            },
            {
                'excel_name': 'Account #',
                'column_name': 'account'
            },
            {
                'excel_name': 'Sales Order',
                'column_name': 'invoice_number'
            },
            {
                'excel_name': 'Currency',
                'column_name': 'currency_code'
            },
            {
                'excel_name': 'Base Amount',
                'column_name': 'base_amount'
            },
            {
                'excel_name': 'W1',
                'column_name': 'w1'
            },
            {
                'excel_name': 'W2',
                'column_name': 'w2'
            },
            {
                'excel_name': 'W3',
                'column_name': 'w3'
            },
            {
                'excel_name': 'W4',
                'column_name': 'w4'
            },
            {
                'excel_name': 'W5',
                'column_name': 'w5'
            },
            {
                'excel_name': 'W6',
                'column_name': 'w6'
            },
            {
                'excel_name': 'W7',
                'column_name': 'w7'
            },
            {
                'excel_name': 'W8',
                'column_name': 'w8'
            },
            {
                'excel_name': 'W9',
                'column_name': 'w9'
            },
            {
                'excel_name': 'W10',
                'column_name': 'w10'
            },
            {
                'excel_name': 'W11',
                'column_name': 'w11'
            },
            {
                'excel_name': 'W12',
                'column_name': 'w12'
            }
        ]
    elif budget_type == 'supplier invoices':
        column_names = [
            {
                'excel_name': 'Supplier',
                'column_name': 'supplier_name'
            },
            {
                'excel_name': 'GL Account',
                'column_name': 'gl_account'
            },
            {
                'excel_name': 'Invoice Date',
                'column_name': 'invoice_date'
            },
            due_date_obj,
            {
                'excel_name': 'Invoice Number',
                'column_name': 'invoice_number'
            },
            {
                'excel_name': 'Currency',
                'column_name': 'currency_code'
            },
            {
                'excel_name': 'Due',
                'column_name': 'due_amount'
            },
            {
                'excel_name': 'Base Amount',
                'column_name': 'base_amount'
            },
            {
                'excel_name': 'W1',
                'column_name': 'w1'
            },
            {
                'excel_name': 'W2',
                'column_name': 'w2'
            },
            {
                'excel_name': 'W3',
                'column_name': 'w3'
            },
            {
                'excel_name': 'W4',
                'column_name': 'w4'
            },
            {
                'excel_name': 'W5',
                'column_name': 'w5'
            },
            {
                'excel_name': 'W6',
                'column_name': 'w6'
            },
            {
                'excel_name': 'W7',
                'column_name': 'w7'
            },
            {
                'excel_name': 'W8',
                'column_name': 'w8'
            },
            {
                'excel_name': 'W9',
                'column_name': 'w9'
            },
            {
                'excel_name': 'W10',
                'column_name': 'w10'
            },
            {
                'excel_name': 'W11',
                'column_name': 'w11'
            },
            {
                'excel_name': 'W12',
                'column_name': 'w12'
            }
        ]
    elif budget_type == 'purchase orders':
        column_names = [
            {
                'excel_name': 'Vendor Name',
                'column_name': 'supplier_name'
            },
            {
                'excel_name': 'Segment',
                'column_name': 'segment'
            },
            {
                'excel_name': 'Currency',
                'column_name': 'currency_code'
            },
            {
                'excel_name': 'PO',
                'column_name': 'invoice_number'
            },
            {
                'excel_name': 'Amount',
                'column_name': 'base_amount'
            },
            {
                'excel_name': 'Due Amount',
                'column_name': 'w0'
            },
            {
                'excel_name': 'B1',
                'column_name': 'w1'
            },
            {
                'excel_name': 'B2',
                'column_name': 'w2'
            },
            {
                'excel_name': 'B3',
                'column_name': 'w3'
            },
            {
                'excel_name': 'B4',
                'column_name': 'w4'
            },
            {
                'excel_name': 'B5',
                'column_name': 'w5'
            },
            {
                'excel_name': 'B6',
                'column_name': 'w6'
            },
            {
                'excel_name': 'B7',
                'column_name': 'w7'
            },
            {
                'excel_name': 'B8',
                'column_name': 'w8'
            },
            {
                'excel_name': 'B9',
                'column_name': 'w9'
            },
            {
                'excel_name': 'B10',
                'column_name': 'w10'
            },
            {
                'excel_name': 'B11',
                'column_name': 'w11'
            },
            {
                'excel_name': 'B12',
                'column_name': 'w12'
            }
        ]
    elif budget_type == 'customer receipts':
        column_names = [
            {
                'excel_name': 'Party',
                'column_name': 'supplier_name'
            },
            payment_method_obj,
            {
                'excel_name': 'Amount',
                'column_name': 'base_amount'
            },
            {
                'excel_name': 'B0',
                'column_name': 'w0'
            },
            {
                'excel_name': 'B1',
                'column_name': 'w1'
            },
            {
                'excel_name': 'B2',
                'column_name': 'w2'
            },
            {
                'excel_name': 'B3',
                'column_name': 'w3'
            },
            {
                'excel_name': 'B4',
                'column_name': 'w4'
            },
            {
                'excel_name': 'B5',
                'column_name': 'w5'
            },
            {
                'excel_name': 'B6',
                'column_name': 'w6'
            },
            {
                'excel_name': 'B7',
                'column_name': 'w7'
            },
            {
                'excel_name': 'B8',
                'column_name': 'w8'
            },
            {
                'excel_name': 'B9',
                'column_name': 'w9'
            },
            {
                'excel_name': 'B10',
                'column_name': 'w10'
            },
            {
                'excel_name': 'B11',
                'column_name': 'w11'
            },
            {
                'excel_name': 'B12',
                'column_name': 'w12'
            }
        ]
    return column_names


def generate_forecast_excel(file_name, file_details):
    static_path = os.path.dirname(os.path.dirname(
                                       os.path.dirname(__file__)
                                       )) + '/static/'
    file_path = os.path.join(static_path, (file_name + ".xlsx"))
    try:
        # to remove existing file with the file_name
        if os.path.exists(file_path):
            os.remove(file_path)
        amount_array = ['base_amount', 'w0',
                        'w1', 'w2', 'w3', 'w4', 'w5', 'w6', 'w7', 'w8', 'w9',
                        'w10', 'w11', 'w12', 'due_amount']

        # to create a new excel file
        workbook = xlsxwriter.Workbook(file_path, {'constant_memory': True})
        # to have a format for a row
        bold = workbook.add_format({'bold': True})
        if file_details is not None and isinstance(file_details, dict):
            for key, value in file_details.items():
                # to create a sheet in the excel
                worksheet = workbook.add_worksheet(' '.join(key.split('_')))
                column_names = get_column_names(key)
                if not column_names:
                    column_names = [{
                        'excel_name': ' '.join(header.upper().split('-')),
                        'column_name': header
                    } for header in list(value[0].keys())]
                # to create header names in excel sheet
                for i in range(len(column_names)):
                    worksheet.write(0, i, column_names[i]['excel_name'], bold)
                # to insert data w.r.t to the header values
                for v_index, excel_value in enumerate(value):
                    for h_index in range(len(column_names)):
                        column_name = column_names[h_index]['column_name']
                        if excel_value[column_name] is None:
                            excel_value[column_name] = 0
                        if isinstance(excel_value[column_name], (int, float)):
                            worksheet.write_number(v_index + 1, h_index,
                                                   excel_value[column_name])
                        else:
                            worksheet.write(v_index + 1, h_index,
                                            excel_value[column_name].decode('utf-8', 'ignore'))
                #  Sum the column values
                worksheet.write(len(value)+1, 0, "TOTALS", bold)
                for h_index in range(len(column_names)):
                    if column_names[h_index]['column_name'] in amount_array:
                        first = xl_rowcol_to_cell(1, h_index)
                        second = xl_rowcol_to_cell(len(value), h_index)
                        worksheet.write_formula(len(value)+1, h_index,
                                                '{=ROUND(SUM(%s:%s), 3)}' %
                                                (first, second),
                                                bold)
        workbook.close()
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - models - cashforecast -
                 generate_forecast_excel """ + str(error))
        raise error
    finally:
        workbook.close()
    return file_name + ".xlsx"
