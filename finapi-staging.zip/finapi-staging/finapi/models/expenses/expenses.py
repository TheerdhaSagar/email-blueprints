from finapi.utils import db_util
from collections import OrderedDict
from finapi.utils.common_utils import CommonUtils
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
import cx_Oracle
import base64
import datetime
import xlrd
import string
import os
import ujson
import csv
import random


class Expenses:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    # generate HeaderId
    def head_id(self):
        logger.addinfo("@ models - expenses - header_id(+)")
        try:
            self.acquire()
            query = self.sql_file['expense_header_sequence']
            data = self.cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 29 EXCEPTION - models - expenses -
                 header_id """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo("@ models - quote - header_id(-)")
        return header_id

    def delete_expense(self, header_id):
        logger.addinfo("@ models - expenses - delete_expense(+)")
        try:
            self.acquire()
            query = self.sql_file['delete_header_expense_query']
            self.cursor.execute(query, p_header_id=header_id)
            query1 = self.sql_file['delete_lines_expense_query']
            self.cursor.execute(query1, p_header_id=header_id)
        except Exception as error:
            logger.findaylog("""@ 54 EXCEPTION - models - expenses -
                 header_id """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo("@ models - expenses - header_id(-)")
        return "Success"

    def expenseList(self, pExpenses):
        logger.addinfo("@ models - expenses - expenseList(+)")
        try:
            mail_details = []
            for i in range(len(pExpenses)):
                header_id = self.head_id()
                email_address = pExpenses[i]['email_address']
                user_name = pExpenses[i]['user_name']
                total = pExpenses[i]['total']
                history = pExpenses[i]['history']
                created_by_name = history['user']
                currency_code = pExpenses[i]['default_currency_code']
                del pExpenses[i]['email_address']
                del pExpenses[i]['user_name']
                expense_flag = 0
                result = self.insertExpense(pExpenses[i], header_id)
                if result == "success":
                    if email_address and user_name:
                        mail = {}
                        mail['email_address'] = email_address
                        mail['user_name'] = user_name
                        mail['created_by_name'] = created_by_name
                        mail['header_id'] = header_id
                        mail['total'] = total
                        mail['currency_code'] = currency_code
                        mail_details.append(mail)
                else:
                    expense_flag = 1
                    break
            result_status = {}
            if expense_flag:
                result_status['result'] = "error"
                result_status['status'] = 1
                result_status['header_id'] = -1
            else:
                for i in range(len(mail_details)):
                    self.send_mail(
                        mail_details[i]['email_address'],
                        mail_details[i]['user_name'],
                        mail_details[i]['created_by_name'],
                        mail_details[i]['header_id'],
                        mail_details[i]['total'],
                        mail_details[i]['currency_code']
                    )
                result_status['result'] = "success"
                result_status['status'] = 0
                result_status['header_id'] = header_id
        except Exception as error:
            logger.findaylog("""@ 112 EXCEPTION - models - expenses -
                 expenseList """ + str(error))
            raise error
        logger.addinfo("@ models - expenses - expenseList(-)")
        return result_status

    def insertExpense(self, pExpense, header_id):
        logger.addinfo('@ models - expenses - insertExpense(+)')
        if 'history' in pExpense:
            history = pExpense['history']
            del pExpense['history']
            self.save_history(history, header_id)
        lines = pExpense['lines']
        del pExpense['lines']
        result = self.insert_lines(lines, header_id)
        return_data = ''
        try:
            self.acquire()
            if result == "success":
                row_data = []
                query = self.sql_file['expense_insert_query1']
                my_data = []
                for key, value in pExpense.items():
                    my_data.append(value)
                    my_new_tuple = tuple(my_data)
                row_data.append(my_new_tuple)
                for key, value in pExpense.items():
                    query += str(key)
                    query += ','
                query += self.sql_file["expense_insert_query2"]
                query += str(header_id) + ","
                sql_args = ""
                for idx, key in enumerate(pExpense.items()):
                    sql_args += ":" + str(idx) + ","
                query += sql_args + " 'DRAFT')"
                self.cursor.executemany(query, row_data)
                return_data = "success"
            else:
                return_data = "error"
        except Exception as error:
            logger.findaylog("""@ 164 EXCEPTION - models - expenses -
                    insertExpense """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - insertExpense(-)')
        return return_data

    def submitExpense(self, pExpenses, header_id):
        logger.addinfo('@ models - expenses - submitExpense(+)')
        pExpense = pExpenses[0]
        if 'history' in pExpense:
            history = pExpense['history']
            del pExpense['history']
            self.save_history(history, header_id)
        lines = pExpense['lines']
        del pExpense['lines']
        result = self.insert_lines(lines, header_id)
        if result == "success":
            try:
                self.acquire()
                return_data = {}
                row_data = []
                query = self.sql_file['expense_insert_query1']
                my_data = []
                for key, value in pExpense.items():
                    my_data.append(value)
                    my_new_tuple = tuple(my_data)
                row_data.append(my_new_tuple)
                for key, value in pExpense.items():
                    query += str(key)
                    query += ','
                query += self.sql_file["expense_insert_query2"]
                query += str(header_id) + ","
                sql_args = ""
                for idx, key in enumerate(pExpense.items()):
                    sql_args += ":" + str(idx) + ","
                query += sql_args + " 'DRAFT')"
                self.cursor.executemany(query, row_data)
                self.connection.commit()
                self.release()
                package_result = self.call_package(header_id)
                if package_result['status'] == 0:
                    return_data['req_id'] = header_id
                    return_data['status'] = 0
                    return_data['result'] = "success"
                    return_data['msg'] = "Expense created suceesfully"
                else:
                    return_data['status'] = 1
                    return_data['msg'] = package_result['msg']
            except Exception as error:
                self.release()
                logger.findaylog("""@ 211 EXCEPTION - models - expenses -
                        submitExpense """ + str(error))
                raise error
            logger.addinfo('@ models - expenses - submitExpense(-)')
            return return_data
        else:
            return_data = {}
            return_data['result'] = "fails"
            return_data['status'] = 1
            return_data['msg'] = "Error in creating Expense lines"

    def get_line_sequence(self):
        logger.addinfo('@ models - expenses - get_line_sequence(+)')
        try:
            self.acquire()
            query = self.sql_file['expense_line_sequence']
            data = self.cursor.execute(query).fetchone()[0]
        except Exception as e:
            logger.findaylog(""" @ 232 EXCEPTION - models - expenses -
                             get_line_sequence """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - expenses - get_line_sequence(-)')
        return data

    def insert_lines(self, expense_lines_list, req_id):
        logger.addinfo('@ models - expenses - insert_lines(+)')
        result = 'error'
        try:
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            for cn_line in expense_lines_list:
                if 'REPORT_LINE_ID' not in cn_line:
                    line_sequence = self.get_line_sequence()
                    cn_line['REPORT_LINE_ID'] = line_sequence
                    if 'attachments' in cn_line:
                        for i in cn_line['attachments']:
                            i['ref_id'] = line_sequence
                            self.attachment_save(i)
                        del cn_line['attachments']
                cn_line['REPORT_HEADER_ID'] = req_id
            if expense_lines_list:
                self.acquire()
                for cn_line in expense_lines_list:
                    expense_data = []
                    for key, value in cn_line.items():
                        expense_data.append(value)
                    row_list.append(tuple(expense_data))
                dict_val = expense_lines_list[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    if key == 'trip_id':
                        key = 'additional_info_1'
                    fieldname_strng += str(key) + ','
                    paramater_strng += ":" + str(indx_value) + ','
                    indx_value = indx_value + 1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            self.cursor.prepare("""insert into
            qpex_expense_lines_all """ + fieldname_strng + """
            values""" + paramater_strng)
            self.cursor.executemany(None, row_list)
            if self.cursor.rowcount == len(expense_lines_list):
                result = 'success'
            else:
                result = 'error'
        except Exception as error:
            logger.findaylog("""@ 284 EXCEPTION - models - expenses -
                 insert_lines """ + str(error))
            raise error
        finally:
            if result == 'success':
                self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - insert_lines(-)')
        return result

    def attachment_save(self, jsond):
        logger.addinfo('@ models - expense - attachment_save(+)')
        try:
            self.acquire()
            p_ref_id = jsond['ref_id']
            p_title = jsond['title']
            p_desc = jsond['description']
            p_file_name = jsond['file_name']
            p_content = (jsond['file_blob'])
            p_content_type = jsond['file_content_type']
            p_entity_name = jsond['entity_name']
            p_category_name = jsond['category_name']
            self.cursor.setinputsizes(p_blob=cx_Oracle.BLOB)
            return_value = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute(""" declare
            begin
            :retval := qpex_attachments.add_attachment(:pref,
            :ptitle, :pfilename,:pdesc, :p_blob, :pcontent_type,
            :pentity, :pcategory);end;""", pref=p_ref_id, ptitle=p_title,
                                pfilename=p_file_name, pdesc=p_desc,
                                p_blob=base64.b64decode(p_content),
                                pcontent_type=p_content_type,
                                pentity=p_entity_name,
                                pcategory=p_category_name, retval=return_value)
        except Exception as error:
            logger.findaylog("""@ 318 EXCEPTION - models - expense -
                 attachment_save """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expense - attachment_save(-)')
        return return_value

    def get_expenses(self, core_flag, wfa_flag, jsond):
        logger.addinfo('@ models - expenses - get_expenses(+)')
        try:
            self.acquire()
            if jsond['status'] != 'ALL':
                query = self.sql_file['expenses_query']
            else:
                query = self.sql_file['expense_query_all']
            # fetch only the expenses which have projects linked to them
            if 'linked_expenses_only' in jsond and jsond['linked_expenses_only']:
                query += self.sql_file['expenses_linked_to_projects']
            if jsond['from_date'] and jsond['to_date']:
                query = query + ' ' + self.sql_file['expenses_bydate']
                self.cursor.execute(query, p_cwf_flag=core_flag,
                                    p_wfa_flag=wfa_flag,
                                    p_org_id=jsond['org_id'],
                                    p_person=jsond['person_id'],
                                    P_FROM_DATE=jsond['from_date'],
                                    P_TO_DATE=jsond['to_date'],
                                    p_created_by=jsond['created_by'])
            elif jsond['from_date']:
                query = query + ' ' + self.sql_file['expenses_fromdate']
                self.cursor.execute(query, p_cwf_flag=core_flag,
                                    p_wfa_flag=wfa_flag,
                                    p_org_id=jsond['org_id'],
                                    p_person=jsond['person_id'],
                                    P_FROM_DATE=jsond['from_date'],
                                    p_created_by=jsond['created_by'])
            elif jsond['to_date']:
                query = query + ' ' + self.sql_file['expenses_todate']
                self.cursor.execute(query, p_cwf_flag=core_flag,
                                    p_wfa_flag=wfa_flag,
                                    p_org_id=jsond['org_id'],
                                    p_person=jsond['person_id'],
                                    P_TO_DATE=jsond['to_date'],
                                    p_created_by=jsond['created_by'])
            else:
                self.cursor.execute(query, p_cwf_flag=core_flag,
                                    p_wfa_flag=wfa_flag,
                                    p_org_id=jsond['org_id'],
                                    p_person=jsond['person_id'],
                                    p_created_by=jsond['created_by'])
        except Exception as error:
            logger.findaylog("""@ 363 EXCEPTION - models - expenses -
                 get_expenses """ + str(error))
            raise error
        else:
            expenses = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - expenses - get_expenses(-)')
        return expenses

    def expense_details(self, header_id):
        logger.addinfo('@ models - expense - expense_details(+)')
        try:
            self.acquire()
            query = self.sql_file['get_expense_details']
            self.cursor.execute(query, p_header_id=header_id)
        except Exception as e:
            logger.findaylog(""" EXCEPTION @ 415 models - expenses -
                            expense_details """ + str(e))
            raise e
        else:
            expense_header = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - expenses - expense_details(-)')
        return expense_header

    def get_expense_details(self, header_id):
        logger.addinfo('@ models - expense - get_expense_details(+)')
        header_details = []
        exp_header = []
        lines_list = []
        try:
            self.acquire()
            query = self.sql_file['expense_header_query']
            self.cursor.execute(query, P_HEADER_ID=header_id)
            lines_list = self.show_lines(header_id)
            history = self.show_history(header_id)
            # attachments_list = self.show_attachments(header_id, 'header')
        except Exception as error:
            logger.findaylog("""@ 403 EXCEPTION - models - expenses -
                 get_expense_details """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                header = {}
                for index, fn in enumerate(fieldnames):
                    header[fn] = row[index]
                header_details.append(header)
            setattr(header, "lines", lines_list)
            setattr(header, "history", history)
            # setattr(header, "attachments", attachments_list)
            exp_header.append(header)
        finally:
            self.release()
        logger.addinfo('@ models - expenses - get_expense_details(-)')
        return exp_header

    def show_lines(self, header_id):
        logger.addinfo('@ models - expenses - show_lines(+)')
        try:
            self.acquire()
            query = self.sql_file['expense_lines_query']
            self.cursor.execute(query, p_header_id=header_id)
            lines = []
            fieldnames = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                line = {}
                for index, fn in enumerate(fieldnames):
                    if fn == 'report_line_id':
                        attachment = row[index]
                        st = self.show_attachments(str(attachment), 'line')
                        attachment_data = st
                        line['attachments'] = attachment_data
                    line[fn] = row[index]
                lines.append(line)
        except Exception as error:
            logger.findaylog("""@ 441 EXCEPTION - models - expenses -
                 show_lines """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - expenses - show_lines(-)')
        return lines

    def show_attachments(self, ref_id, desc):
        logger.addinfo('@ models - expenses - show_attachments(+)')
        try:
            self.acquire()
            if desc == 'line':
                query = self.sql_file['expense_attachments_query']
            else:
                query = self.sql_file['expense_header_attachments_query']
            self.cursor.execute(query, p_attachment_seq=ref_id)
            attachments = Code_util.iterate_data(self.cursor)
        except Exception as error:
            logger.findaylog("""@ 460 EXCEPTION - models - expenses -
                 show_attachments """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - expenses - show_attachments(-)')
        return attachments

    def get_currency_details(self):
        logger.addinfo('@ models - expenses - get_currency_details(+)')
        try:
            self.acquire()
            query = self.sql_file['expense_currencies_query']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 475 EXCEPTION - models - expenses -
                 get_currency_details """ + str(error))
            raise error
        else:
            currecncies = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - expenses - get_currency_details(-)')
        return currecncies

    def get_prompt_details(self, org_id):
        logger.addinfo('@ models - expenses - get_prompt_details(+)')
        try:
            self.acquire()
            query = self.sql_file['prompts_lov_query']
            self.cursor.execute(query, p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ 492 EXCEPTION - models - expenses -
                 get_prompt_details """ + str(error))
            raise error
        else:
            prompts = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - expenses - get_prompt_details(-)')
        return prompts

    def header_update(self, val_list, header_id):
        logger.addinfo('@ models - expenses - header_update(+)')
        try:
            self.acquire()
            sql_data = 'update qpex_expense_headers_all set '
            for key, value in val_list.items():
                sql_data += str(key)+'='
                if value is not None:
                    if isinstance(value, str):
                        value = value.replace("'", "''")
                        sql_data += "'" + str(value) + "'"
                    else:
                        sql_data += str(value)
                else:
                    sql_data += ''
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += "where REPORT_HEADER_ID =" + "'" + str(header_id) + "'"
            self.cursor.execute(sql_data)
        except Exception as error:
            logger.findaylog("""@ 520 EXCEPTION - expenses - expenses -
                 header_update """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - header_update(-)')
        return 'success'

    def line_update(self, val_list, line_id):
        logger.addinfo('@ models - expenses - line_update(+)')
        try:
            self.acquire()
            sql_data = 'update qpex_expense_lines_all set '
            for key, value in val_list.items():
                if key == 'trip_id':
                    key = 'additional_info_1'
                sql_data += str(key)+'='
                if value is not None:
                    if isinstance(value, str):
                        value = value.replace("'", "''")
                        sql_data += "'" + str(value) + "'"
                    else:
                        sql_data += str(value)
                else:
                    sql_data += ''
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += " where REPORT_LINE_ID ='" + str(line_id) + "'"
            self.cursor.execute(sql_data)
        except Exception as error:
            logger.findaylog("""@ 549 EXCEPTION - models - expenses -
                 line_update """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - line_update(-)')
        return "success"

    def update_attachment(self, attachment):
        logger.addinfo('@ models - expenses - update_attachment(+)')
        try:
            self.acquire()
            file_data = attachment['file_data']
            file_id = attachment['file_id']
            file_name = attachment['file_name']
            content = attachment['file_content_type']
            qry = self.sql_file['attachement_update_query']
            self.cursor.setinputsizes(p_file_data=cx_Oracle.BLOB)
            self.cursor.execute(qry, p_file_name=file_name, p_file_id=file_id,
                                p_file_data=base64.b64decode(file_data),
                                p_content_type=content)
        except Exception as error:
            logger.findaylog("""@ 571 EXCEPTION - models - expenses -
                 update_attachment """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - update_attachment(-)')
        return "succcess"

    def line_delete(self, p_linenum):
        logger.addinfo('@ models - expenses - line_delete(+)')
        try:
            self.acquire()
            query = self.sql_file['expense_lineonlydelete']
            self.cursor.execute(query, p_line_id=p_linenum)
        except Exception as error:
            logger.findaylog("""@ 587 EXCEPTION - models - expenses -
                 line_delete """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - line_delete(-)')
        return "success"

    def delete_attachments(self, file_id, attached_doc_id):
        logger.addinfo('@ models - expenses - delete_attachments(+)')
        try:
            self.acquire()
            query = self.sql_file['fnd_lobs_delete_query']
            self.cursor.execute(query, p_file_id=file_id)
            query1 = self.sql_file['attached_doc_del_query']
            self.cursor.execute(query1, p_attached_document_id=attached_doc_id)
        except Exception as error:
            logger.findaylog("""@ 605 EXCEPTION - models - expenses -
                 delete_attachments """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - delete_attachments(-)')
        return "success"

    def save_history(self, history, header_id):
        logger.addinfo('@ models - expenses - save_history(+)')
        try:
            self.acquire()
            query = self.sql_file['expense_history_insert_query']
            if history['status'] == 'D':
                create = ' Created Expense'
                resp = history['user'] + create
            elif history['status'] == 'S':
                submit = ' Submitted Expense'
                resp = history['user'] + submit
            elif history['status'] == 'U':
                update = ' Updated Expense'
                resp = history['user'] + update
            elif history['status'] == 'APPROVED':
                approve = ' Approved Expense'
                resp = history['user'] + approve
            elif history['status'] == 'REJECTED':
                reject = ' Rejected Expense'
                resp = history['user'] + reject
            else:
                oth = ' Other Expense'
                resp = history['user'] + oth
            self.cursor.execute(query, p_seq=header_id,
                                p_response=resp,
                                p_comments=history['comments'],
                                p_approver=history['name'])
        except Exception as error:
            logger.findaylog(""" @ 642 EXCEPTION - models - expenses -
                             save_history """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - save_history(-)')
        return True

    def call_package(self, header_id):
        logger.addinfo('@ models - expenses - call_package(+)')
        return_data = {}
        try:
            self.acquire()
            return_status = self.cursor.var(cx_Oracle.STRING)
            return_msg = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
              qpex_iexp_appr_pkg.START_IEXP_PROCESS(
              P_REPORT_HEADER_ID => :p_report_header_id,
              X_RETURN_STATUS => :p_return_status,
              X_RETURN_MSG => :p_return_msg);
            end;""", p_report_header_id=header_id,
                                p_return_status=return_status,
                                p_return_msg=return_msg)
            if return_status.getvalue() == 'S':
                return_data['status'] = 0
                return_data['msg'] = "Expense created suceesfully"
            else:
                return_data['status'] = 1
                return_data['msg'] = return_msg.getvalue()
        except Exception as error:
            logger.findaylog("""@ 674 EXCEPTION - models - expenses -
                 call_package """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - expenses - call_package(-)')
        return return_data

    def show_history(self, header_id):
        logger.addinfo('@ models - expenses - show_history(+)')
        try:
            self.acquire()
            query = self.sql_file['expense_history_query']
            self.cursor.execute(query, p_history_id=header_id)
        except Exception as error:
            logger.findaylog("""@ 690 EXCEPTION - models - expenses -
                 show_history """ + str(error))
            raise error
        else:
            datas = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo('@ models - expenses - show_history(-)')
        return datas

    # get the detailed information of products
    def csv_writing(self, pencoded):
        logger.addinfo("@ models - expenses - csv_writing(+)")
        try:
            decoded = base64.b64decode(pencoded)
            file_name = self.id_generator()
            tmp_f_name = file_name
            text_file = open(tmp_f_name, 'w')
            text_file.write(decoded)
            text_file.close()
            tmp_file = open(file_name, 'r')
            sample = tmp_file.readline()[0]
            if sample == 'D' or sample == 'T':
                tmp_data = self.csv_reading(tmp_f_name)
            else:
                tmp_str = 'application/vnd.ms-excel'
                tmp_data = self.reading(tmp_f_name, tmp_str)
            if tmp_data == 'error':
                logger.addinfo("@ models - expenses - csv_writing(-)")
                return 'error'
            expense_data = []
            for t in tmp_data:
                if t != {}:
                    expense_data.append(t)
        except Exception as error:
            logger.findaylog("""@ 725 EXCEPTION - models - expenses -
                 csv_writing """ + str(error))
            raise error
        logger.addinfo("@ models - expenses - csv_writing(-)")
        return expense_data

    # get the detailed information of products
    def reading(self, file_name, file_type):
        logger.addinfo("@ models - expenses - reading(+)")
        z = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        try:
            b = xlrd.open_workbook(file_name)
            sheet = b.sheet_by_index(0)
            # for row in range(0, sheet.ncols):
            cols = []
            col_types = []
            for col in range(0, sheet.ncols):
                cols.append(sheet.cell_value(0, col))
                col_types.append(sheet.cell_type(sheet.nrows/2, col))
            data_list = []
            for rownum in range(1, sheet.nrows):
                data = OrderedDict()
                r = sheet.row_values(rownum)
                for i in range(0, len(cols)):
                    formatkey = "_".join(cols[i].lower().strip(' ').split(' '))
                    if col_types[i] == 3 and r[i] != '':
                        zc = b.datemode
                        tmp_vak = datetime.datetime(*xlrd.xldate_as_tuple(r[i],
                                                                          zc))
                        tmp_val = tmp_vak.strftime("%d/%m/%Y")
                        data[formatkey] = tmp_val
                    else:
                        data[formatkey] = r[i]
                data_list.append(data)

            if file_type == 'application/vnd.ms-excel' or z:
                var = 'xls'
            else:
                var = 'csv'
            if var == 'xls' and sheet.ncols == 1:
                id_list = []
                keys = list(data_list[0].keys())
                words = keys[0].split(',')
                for j in range(0, len(data_list)):
                    line_data = list(data_list[j].values())[0].split(',')
                    lines_data = OrderedDict()
                    for k in range(0, len(words)):
                        lines_data[words[k]] = line_data[k]
                    id_list.append(lines_data)
            os.remove(file_name)
        except Exception as error:
            logger.findaylog("""@ 776 EXCEPTION - models - expenses -
                 reading """ + str(error))
            raise error
        logger.addinfo("@ models - expenses - reading(-)")
        if var == 'xls' and sheet.ncols == 1:
            return id_list
        else:
            return data_list

    def id_generator(self):
        size = 8
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))

    def csv_reading(self, file_name):
        logger.addinfo("@ models - expenses - csv_reading(+)")
        array = []
        tmp = ''
        try:
            with open(file_name, 'rb') as csvfile:
                spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
                for row in spamreader:
                    array.append(row)
                tmp_array = []
                for i in range(len(array[0])):
                    format_key = array[0][i].strip(' ').lower().split(' ')
                    array[0][i] = "_".join(format_key)
                for j in range(1, len(array)):
                    tmp = [0] * len(array[j])
                    for i in range(len(array[j])):
                        tmp[i] = array[j][i].strip('"').strip(' ')
                    tmp_array.append(tmp)
            final_data = []
            for i in range(len(tmp_array)):
                combo = list(zip(array[0], tmp_array[i]))
                who = dict(combo)
                final_data.append(who)
            os.remove(file_name)
        except Exception as error:
            logger.findaylog("""@ 815 EXCEPTION - models - expenses -
                 csv_reading """ + str(error))
            raise error
        logger.addinfo("@ models - expenses - csv_reading(-)")
        return final_data

    def send_mail(
            self, email_address, user_name, created_by_name,
            header_id, total, currency_code):
        logger.addinfo('@ models - expenses - send_mail(+)')
        status = ''
        try:
            strings = db_util.get_strings()
            data = {
                'subject': strings['expense_created'],
                'template_id': 107414,
                'params': [{
                    'key': 'user_name',
                    'value': user_name,
                }, {
                    'key': 'created_by',
                    'value': created_by_name
                }, {
                    'key': 'header_id',
                    'value': header_id
                }, {
                    'key': 'total',
                    'value': total
                }, {
                    'key': 'currency_code',
                    'value': currency_code
                }],
                'recipients': [
                    {
                        'Email': email_address
                    }
                ]
            }
            result = CommonUtils.send_mail(data)
            if result == 'SUCCESS':
                status = 'success'
            else:
                status = 'Failure - Failed to send email'
                logger.findaylog("""@ models - expenses - send_email - {}""".format(data))
        except Exception as error:
            logger.findaylog("""@ 857 EXCEPTION - models - expenses -
                send_mail """ + str(error))
            raise error
        logger.addinfo('@ models - expenses - send_mail(-)')
        return status

    def send_submission_mail(self, created_by, last_updated_name,
                             report_header_id):
        logger.addinfo('@ models - expenses - send_submission_mail(+)')
        try:
            self.acquire()
            query = self.sql_file['user_data_query']
            data = self.cursor.execute(query, p_user_id=created_by).fetchone()
            user_name = data[0]
            email_address = data[1]
            strings = db_util.get_strings()
            data = {
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                },
                'subject': strings['expense_submitted'],
                'template_id': 107413,
                'params': [{
                    'key': 'user_name',
                    'value': user_name
                }, {
                    'key': 'submitted_by',
                    'value': last_updated_name
                }, {
                    'key': "report_id",
                    'value': report_header_id
                }],
                'recipients': [
                    {
                        'Email': email_address
                    }
                ]
            }
            result = CommonUtils.send_mail(data)
            if result != 'SUCCESS':
                logger.findaylog("""@ models - expenses - send_submission_mail - {}""".format(data))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - expenses -
                send_submission_mail """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - procurement - send_submission_mail(-)')
        return result

    def attachment_data(self, attachment):
        logger.addinfo("@ models - expenses - attachment_data(+)")
        try:
            self.acquire()
            query = self.sql_file['expense_attachment_data_query']
            # if attachment['notification_type'] == 'procurement':
            #     description = 'Procurement lines'
            # else:
            #     description = 'expense lines'
            self.cursor.execute(query,
                                p_attachment_seq=attachment['pk1_value'],
                                p_file_name=attachment['file_name'])
        except Exception as e:
            logger.findaylog(""" @ 918 EXCEPTION - models -
            expenses - attachment_data""" + str(e))
            raise e
        else:
            field_data = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                data = {}
                for index, field in enumerate(field_names):
                    encoded_string = ''
                    if field == 'file_data':
                        encoded_string = ''
                        if row[index]:
                            encoded_string = self.is_base64(row[index].read())
                        data[field] = encoded_string.decode('utf-8')
                    else:
                        data[field] = row[index]
                field_data.append(data)
        finally:
            self.release()
        logger.addinfo("@ models - expenses - attachment_data(-)")
        return field_data

    def is_base64(self, data):
        if not (base64.b64encode(base64.b64decode(data)) == data):
            encoded_string = (base64.b64encode(data))
        else:
            encoded_string = (data)

        return encoded_string

    def card_limit(self):
        logger.addinfo('models - expenses - card_limit(+)')
        result = []
        try:
            self.acquire()
            query = self.sql_file['credit_expense_limit']
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 963 EXCEPTION - models - expenses -
                             card_limit """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - expenses - card_limit(-)')
        return result

    def get_expense_role_users(self):
        logger.addinfo('models - expenses - get_expense_role_users(+)')
        try:
            query = db_util.getusermngSql()['check_role_responsibility']
            with OracleConnectionManager() as conn:
                # 998 is UI-EXPENSES role_id
                conn.execute(query, p_role_id=998)
                users = conn.get_result()
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models - expenses -
                                get_expense_role_users""" + str(e))
            raise e
        logger.addinfo('models - expenses - get_expense_role_users(-)')
        return users

    def get_expense_approvals(self, org_id):
        logger.addinfo('models - expenses - get_expense_approvals(+)')
        try:
            query = self.sql_file['get_expense_approvals']
            with OracleConnectionManager() as conn:
                conn.execute(query, p_org_id=org_id)
                result = conn.get_result()
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models - expenses -
                                get_expense_approvals """ + str(e))
        logger.addinfo('models - expenses - get_expense_approvals(-)')
        return result

    def insert_expense_approvals(self, json):
        logger.addinfo('models - expenses - insert_expense_approvals(+)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_iexp_appr_pkg.insert_expense_approvals(
                        :p_emp_id,
                        :p_mgr_id,
                        :p_org_id,
                        :x_status_code
                    );
                end;""", p_emp_id=json['emp_id'],
                             p_mgr_id=json['mgr_id'],
                             p_org_id=json['org_id'],
                             x_status_code=status_code)
                status = status_code.getvalue()
            if status == 'SUCCESS':
                result = {
                    'msg': 'Approval inserted successfully',
                    'status': 0
                }
            else:
                result = {
                    'msg': 'Failed to insert approval - {}'.format(status),
                    'status': 1
                }
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models - expenses -
                                insert_expense_approvals """ + str(e))
            raise e
        logger.addinfo('models - expenses - insert_expense_approvals(-)')
        return result

    def update_expense_approvals(self, json):
        logger.addinfo('models - expenses - update_expense_approvals(+)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_iexp_appr_pkg.update_expense_approvals(
                        :p_emp_id,
                        :p_mgr_id,
                        :p_org_id,
                        :x_status_code
                    );
                end;""", p_emp_id=json['emp_id'],
                             p_mgr_id=json['mgr_id'],
                             p_org_id=json['org_id'],
                             x_status_code=status_code)
                status = status_code.getvalue()
            if status == 'SUCCESS':
                result = {
                    'msg': 'Approval updated successfully',
                    'status': 0
                }
            else:
                result = {
                    'msg': 'Failed to update approval - {}'.format(status),
                    'status': 1
                }
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models - expenses -
                                update_expense_approvals """ + str(e))
            raise e
        logger.addinfo('models - expenses - update_expense_approvals(-)')
        return result

    def delete_expense_approval(self, org_id, emp_id):
        logger.addinfo('models - expenses - delete_expense_approval(+)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_iexp_appr_pkg.delete_expense_approval(
                        :p_org_id,
                        :p_emp_id,
                        :x_status_code
                    );
                end;""", p_org_id=org_id,
                             p_emp_id=emp_id,
                             x_status_code=status_code)
                status = status_code.getvalue()
            if status == 'SUCCESS':
                result = {
                    'msg': 'Approval deleted successfully',
                    'status': 0
                }
            else:
                result = {
                    'msg': 'Failed to delete approval - {}'.format(status),
                    'status': 1
                }
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models - expenses -
                                delete_expense_approval """ + str(e))
            raise e
        logger.addinfo('models - expenses - delete_expense_approval(-)')
        return result
