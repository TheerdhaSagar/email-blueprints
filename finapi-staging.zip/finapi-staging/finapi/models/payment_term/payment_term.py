import ujson
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil


class PaymentTerm:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    #  used in Address to get payment terms of billto address
    @staticmethod
    @db_util.langs("American")
    def get_payments(psiteid_list, porg_id, plang, cust_id):
        logger.addinfo('@ models - paymentterm - get_payments(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            if cust_id:
                plang = "'" + plang + "'"
                query_template = sql_file['paymentTermsCTl']
                query = query_template % (',' . join([":" + str(i)
                                          for i in range(len(
                                                         psiteid_list
                                                         ))]), porg_id, plang,
                                          plang, cust_id)
            elif plang:
                plang = "'" + plang + "'"
                query_template = sql_file['paymentTermsTl']
                query = query_template % (',' . join([":" + str(i)
                                          for i in range(len(
                                                         psiteid_list
                                                         ))]), porg_id, plang,
                                          plang)
            else:
                query_template = sql_file['paymentSelect']
                query = query_template % (',' . join([":" + str(i)
                                          for i in range(len(
                                                         psiteid_list
                                                         ))]), porg_id)

            cur.execute(query, psiteid_list)
        except Exception as error:
            logger.findaylog("""@ 32 EXCEPTION - models - paymentterm -
                 get_payments """ + str(error))
            raise error
        else:
            payment_dict = {}
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                payterm = {}
                for index, fn in enumerate(field_names):
                    payterm[fn] = row[index]
                    if fn == 'site_use_id':
                        keyval = row[index]
                if keyval in list(payment_dict.keys()):
                    payment_dict.get(keyval).append(payterm)
                else:
                    pay_list = []
                    pay_list.append(payterm)
                    payment_dict[keyval] = pay_list
            data = ujson.dumps(payment_dict)
            payment_data = ujson.loads(data)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - paymentterm - get_payments(-)')
        return payment_data


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'paymentterm',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
