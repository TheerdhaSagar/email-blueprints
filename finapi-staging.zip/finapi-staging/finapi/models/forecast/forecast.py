import cx_Oracle
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.constants import Status
from finapi.utils.logdata import logger
from finapi.utils.conn_util import OracleConnectionManager


class Forecast:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    def get_data(self):
        result = {}
        field_names = [a[0].lower() for a in self.cursor.description]
        data = []
        for row in self.cursor:
            obj = {}
            for index, field in enumerate(field_names):
                obj[field] = row[index]
            data.append(obj)
        result['status'] = Status.OK.value
        result['record_count'] = len(data)
        result['records'] = data
        return result

    def no_data(self):
        result = {
            'status': Status.OK.value,
            'record_count': 0,
            'records': []
        }
        return result

    def get_vendor_segments(self, vendor_id):
        logger.addinfo('@ models - forecast - get_vendor_segments(+)')
        try:
            self.acquire()
            query = self.sql_file['vendor_segments_query']
            self.cursor.execute(query, p_vendor_id=vendor_id)
            result = self.get_data()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                get_vendor_segments """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - forecast - get_vendor_segments(-)')
        return result

    def get_segment_items(self, segment_id, vendor_id, item_ids):
        logger.addinfo('@ models - forecast - get_segment_items(+)')
        result = {}
        items_list = None
        try:
            if item_ids and len(item_ids) > 0:
                items_list = ',' . join([str(item_ids[i])
                                        for i in range(len(item_ids))])

            self.acquire()

            query = self.sql_file['segment_items_query']
            if item_ids:
                query += ' AND i.inventory_item_id IN (%s)'
                query %= items_list
                query += ' ORDER BY to_number(item_display_seq) ASC'
            self.cursor.execute(query, p_segment_id=segment_id,
                                p_vendor_id=vendor_id)
            result['items'] = self.get_data()

            vendor_items = self.sql_file['inventory_items_vendor_query']
            segment_items = self.sql_file['inventory_items_segment_query']

            query = self.sql_file['items_week_history_query']
            if item_ids is None:
                query %= segment_items
                self.cursor.execute(query, p_segment_id=segment_id)
            else:
                if vendor_id is None:
                    query %= items_list
                    self.cursor.execute(query)
            if item_ids is None or vendor_id is None:
                result['history'] = self.get_data()
            else:
                result['history'] = self.no_data()

            query = self.sql_file['items_yearly_avg_query']
            if item_ids is None:
                query %= segment_items
                self.cursor.execute(query, p_segment_id=segment_id)
            else:
                query %= items_list
                self.cursor.execute(query)
            result['yearly'] = self.get_data()

            query = self.sql_file['items_supply_forecast_query']
            if item_ids is None:
                query %= vendor_items
                self.cursor.execute(query, p_segment_id=segment_id,
                                    p_vendor_id=vendor_id)
            else:
                query %= items_list
                self.cursor.execute(query)
            result['supply'] = self.get_data()

            query = self.sql_file['items_demand_forecast_query']
            if item_ids is None:
                query %= segment_items
                self.cursor.execute(query, p_segment_id=segment_id)
            else:
                query %= items_list
                self.cursor.execute(query)
            result['demand'] = self.get_data()

            query = self.sql_file['forecast_quantity_query']
            if segment_id is None:
                query += ' AND inventory_item_id IN (%s)'
                query %= items_list
            self.cursor.execute(query, p_segment_id=segment_id,
                                p_vendor_id=vendor_id)
            result['forecast'] = self.get_data()

            query = self.sql_file['forecast_history_query']
            if segment_id is None:
                query += ' AND inventory_item_id IN (%s)'
                query %= items_list
            if segment_id or (item_ids and vendor_id is None):
                self.cursor.execute(query, p_segment_id=segment_id,
                                    p_vendor_id=vendor_id)
                result['forecast_history'] = self.get_data()
            else:
                result['forecast_history'] = self.no_data()

            query = self.sql_file['sales_by_vendor']
            self.cursor.execute(query, p_vendor_id=vendor_id)
            result['sales_by_vendor'] = self.get_data()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                get_segment_items """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - forecast - get_segment_items(-)')
        return result

    def get_suppliers(self):
        logger.addinfo('@ models - forecast - get_suppliers(+)')
        try:
            self.acquire()
            query = self.sql_file['vendors_query']
            self.cursor.execute(query)
            result = self.get_data()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                get_suppliers """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - forecast - get_suppliers(-)')
        return result

    def save_order(self, req):
        logger.addinfo('@ models - forecast - save_order(+)')
        status = None
        try:
            self.acquire()
            cursor = self.cursor
            po_interface_id = cursor.var(cx_Oracle.NUMBER)
            status_code = cursor.var(cx_Oracle.STRING)
            for line in req:
                cursor.execute("""
                begin
                    qpex_forecast_pkg.insert_order(
                        :x_qpex_po_interface_id,
                        :p_checkout_status,
                        :p_checkout_group_id,
                        :p_vendor_id,
                        :p_vendor_site_id,
                        :p_currency_code,
                        :p_unit_price,
                        :p_quantity,
                        :p_uom_code,
                        :p_item_id,
                        :p_need_by_date,
                        :p_promise_date,
                        :p_created_by,
                        :x_status_code
                    );
                end; """, x_qpex_po_interface_id=po_interface_id,
                               p_checkout_status=line['checkout_status'],
                               p_checkout_group_id=line['checkout_group_id'],
                               p_vendor_id=line['vendor_id'],
                               p_vendor_site_id=line['vendor_site_id'],
                               p_currency_code=line['currency_code'],
                               p_unit_price=line['unit_price'],
                               p_quantity=line['quantity'],
                               p_uom_code=line['uom_code'],
                               p_item_id=line['item_id'],
                               p_need_by_date=line['need_by_date'],
                               p_promise_date=line['promise_date'],
                               p_created_by=line['created_by'],
                               x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    status = Status.OK.value
                else:
                    status = status_code.getvalue()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                save_order """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - forecast - save_order(-)')
        return status

    def order_summary(self, po_header_id, vendor_id):
        logger.addinfo('@ models - forecast - order_summary(+)')
        item_ids = []
        try:
            self.acquire()
            if po_header_id is None and vendor_id is None:
                query = self.sql_file['order_summary_query']
                self.cursor.execute(query)
            elif vendor_id is None:
                query = self.sql_file['po_items_query']
                self.cursor.execute(query, p_po_header_id=po_header_id)
            else:
                query = self.sql_file['vendor_items_query']
                self.cursor.execute(query, p_vendor_id=vendor_id)
            result = self.get_data()
            for line in result['records']:
                item_ids.append(line['item_id'])
            if len(item_ids) > 0:
                data = self.get_segment_items(None, vendor_id, item_ids)
                result['items_forecast'] = data
            else:
                self.release()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                order_summary """ + str(error))
            raise
        logger.addinfo('@ models - forecast - order_summary(-)')
        return result

    def create_order(self, req):
        logger.addinfo('@ models - forecast - create_order(+)')
        status = None
        checkout_group_id = None
        try:
            self.acquire()
            cursor = self.cursor
            if req['operation_code'] == 'ORDER':
                query = self.sql_file['checkout_group_query']
                data = cursor.execute(query).fetchone()
                checkout_group_id = data[0]
            status_code = cursor.var(cx_Oracle.STRING)
            for line in req['lines']:
                if checkout_group_id is None:
                    checkout_group_id = line['checkout_group_id']
                cursor.execute("""
                begin
                    qpex_forecast_pkg.update_order(
                        :p_qpex_po_interface_id,
                        :p_checkout_status,
                        :p_checkout_group_id,
                        :p_vendor_id,
                        :p_vendor_site_id,
                        :p_currency_code,
                        :p_unit_price,
                        :p_quantity,
                        :p_uom_code,
                        :p_item_id,
                        :p_need_by_date,
                        :p_promise_date,
                        :p_created_by,
                        :x_status_code
                    );
                end; """, p_qpex_po_interface_id=line['qpex_po_interface_id'],
                               p_checkout_status=line['checkout_status'],
                               p_checkout_group_id=checkout_group_id,
                               p_vendor_id=line['vendor_id'],
                               p_vendor_site_id=line['vendor_site_id'],
                               p_currency_code=line['currency_code'],
                               p_unit_price=line['unit_price'],
                               p_quantity=line['quantity'],
                               p_uom_code=line['uom_code'],
                               p_item_id=line['item_id'],
                               p_need_by_date=line['need_by_date'],
                               p_promise_date=line['promise_date'],
                               p_created_by=line['created_by'],
                               x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    status = Status.OK.value
                else:
                    status = status_code.getvalue()

            if status == Status.OK.value:
                if checkout_group_id and req['operation_code'] == 'ORDER':
                    status = self.create_po(checkout_group_id)
            else:
                status = status_code.getvalue()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                create_order """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - forecast - create_order(-)')
        return status

    def order_count(self):
        logger.addinfo('@ models - forecast - order_count(+)')
        try:
            self.acquire()
            query = self.sql_file['order_summary_count_query']
            self.cursor.execute(query)
            result = self.get_data()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                order_count """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - forecast - order_count(-)')
        return result

    def supplier_orders(self, vendor_id):
        logger.addinfo('@ models - forecast - supplier_orders(+)')
        try:
            self.acquire()
            query = self.sql_file['supplier_orders_query']
            self.cursor.execute(query, p_vendor_id=vendor_id)
            result = self.get_data()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                supplier_orders """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - forecast - supplier_orders(-)')
        return result

    def update_promised_date(self, req):
        logger.addinfo('@ models - forecast - update_promised_date(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            for line in req:
                self.cursor.execute("""
                    begin
                        qpex_forecast_pkg.update_promised_date(
                            :p_po_header_id,
                            :p_promised_date,
                            :x_status_code);
                    end; """, p_po_header_id=line['po_header_id'],
                                    p_promised_date=line['promised_date'],
                                    x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                status = Status.OK.value
            else:
                status = Status.ERROR.value
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                update_promised_date """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - forecast - update_promised_date(-)')
        return status

    def delete_order(self, header_id):
        logger.addinfo('@ models - forecast - delete_order(+)')
        try:
            self.acquire()
            query = self.sql_file['delete_interface_order_query']
            self.cursor.execute(query, p_header_id=header_id)
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                delete_order """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - forecast - delete_order(-)')
        return Status.OK.value

    def save_forecast_qty(self, req):
        logger.addinfo('@ models - forecast - save_forecast_qty(+)')
        try:
            self.acquire()
            cursor = self.cursor
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_forecast_pkg.save_forecast_quantity(
                    :p_segment_id,
                    :p_inventory_item_id,
                    :p_vendor_id,
                    :p_quantity,
                    :p_week,
                    :p_week_label,
                    :p_comments,
                    :x_status_code
                );
            end; """, p_segment_id=req['segment_id'],
                           p_inventory_item_id=req['inventory_item_id'],
                           p_vendor_id=req['vendor_id'],
                           p_quantity=req['quantity'],
                           p_week=req['week'],
                           p_week_label=req['week_label'],
                           p_comments=req['comments'],
                           x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                result = Status.OK.value
            else:
                result = status_code.getvalue()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                save_forecast_qty """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - forecast - save_forecast_qty(-)')
        return result

    def save_history_qty(self, req):
        logger.addinfo('@ models - forecast - save_history_qty(+)')
        try:
            self.acquire()
            cursor = self.cursor
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_forecast_pkg.save_history_quantity(
                    :p_segment_id,
                    :p_inventory_item_id,
                    :p_vendor_id,
                    :p_quantity,
                    :p_settimana,
                    :p_week,
                    :p_week_label,
                    :p_comments,
                    :x_status_code
                );
            end; """, p_segment_id=req['segment_id'],
                           p_inventory_item_id=req['inventory_item_id'],
                           p_vendor_id=req['vendor_id'],
                           p_quantity=req['quantity'],
                           p_settimana=req['settimana'],
                           p_week=req['week'],
                           p_week_label=req['week_label'],
                           p_comments=req['comments'],
                           x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                result = Status.OK.value
            else:
                result = status_code.getvalue()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                save_history_qty """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - forecast - save_history_qty(-)')
        return result

    def create_po(self, group_id):
        logger.addinfo('@ models - forecast - create_po(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                begin
                    qpex_forecast_pkg.create_order(
                        :p_checkout_group_id,
                        :x_status_code
                    );
                end; """, p_checkout_group_id=group_id,
                                x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                status = Status.OK.value
            else:
                status = status_code.getvalue()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                create_po """ + str(error))
            raise error
        finally:
            self.connection.commit()
        logger.addinfo('@ models - forecast - create_po(-)')
        return status

    def update_po_qty(self, req):
        logger.addinfo('@ models - forecast - update_po_qty(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                begin
                    qpex_forecast_pkg.update_po_quantity(
                        :p_po_header_id,
                        :p_item_id,
                        :p_quantity,
                        :p_updated_by,
                        :x_status_code
                    );
                end; """, p_po_header_id=req['po_header_id'],
                                p_item_id=req['item_id'],
                                p_quantity=req['quantity'],
                                p_updated_by=req['updated_by'],
                                x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                result = Status.OK.value
            else:
                result = status_code.getvalue()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                update_po_qty """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - forecast - update_po_qty(-)')
        return result

    def get_supplier_po_details(self, request_data):
        """
            For getting supplier po details while generating a po order
            @:param request_data: {"year": "", "org":""}
            @:return :array of objects
        """
        logger.addinfo('@ models - forecast - get_supplier_po_details(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_supplier_po_details']
                conn.execute(query, p_year=request_data['year'],
                             p_org_id=request_data['org'],
                             p_supplier_id='')
                supplier_po_details = conn.get_result()
            result = {'status': Status.OK.value, 'suppliers': supplier_po_details}
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                get_supplier_po_details """ + str(error))
            raise error
        logger.addinfo('@ models - forecast - get_supplier_po_details(+)')
        return result

    def get_supplier_po_updates(self, method, request_data):
        """
        to insert and update the supplier po details
        @:param method: POST/PUT
        @:param request_data:
            {
            "supplier_id": "", "start_date": "", "end_date": "", "po_number": "", "org_id": "",
            "prefix": "", "year": ""
            }
        @:return {"status": "", "msg": ""}
        """
        logger.addinfo('@ models - forecast - get_supplier_po_updates(-)')
        try:
            with OracleConnectionManager() as conn:
                if method == 'POST':
                    query = self.sql_file['get_supplier_po_details']
                    conn.execute(query, p_year=request_data['year'],
                                 p_org_id=request_data['org_id'],
                                 p_supplier_id=request_data['supplier_id'])
                    supplier_po_details = conn.get_result()
                    if len(supplier_po_details) > 0:
                        return {'status': 1, 'msg': 'Supplier already exists!!'}
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                    BEGIN
                        QPEX_FORECAST_PKG.manage_supplier_po_details(
                        :p_supplier_id,
                        :p_start_date,
                        :p_end_date,
                        :p_prefix,
                        :p_year,
                        :p_po_number,
                        :p_org_id,
                        :x_status_code);
                    END;

                    """, p_supplier_id=request_data['supplier_id'],
                             p_start_date=request_data['start_date'],
                             p_end_date=request_data.get('end_date'),
                             p_prefix=request_data['prefix'],
                             p_year=request_data.get('year'),
                             p_po_number=request_data.get('po_number', 1),
                             p_org_id=request_data['org_id'],
                             x_status_code=status_code
                             )
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value, 'msg': '{} PO Formats Successfully'.format(
                    'Added' if method == 'POST' else 'Updated')}
            else:
                result = {'status': Status.ERROR.value, 'msg': 'Failed to {} PO Formats'.format(
                    'add' if method == 'POST' else 'update')}

        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                get_supplier_po_updates """ + str(error))
            raise error
        logger.addinfo('@ models - forecast - get_supplier_po_updates(+)')
        return result

    @staticmethod
    def copy_existing_po_formats(request_data):
        """
        to copy existing PO Details to the given year
        @:param request_data:
            { "data":[{
            "supplier_id": "", "start_date": "", "end_date": "", "po_number": "", "org_id": "",
            "prefix": "", "year": ""
            }], "action": "COPY/DISABLE"
        @:return {"status": "", "msg": ""}
        """
        logger.addinfo('@ models - forecast - copy_existing_po_formats(-)')
        try:
            supplier_ids = []
            prefix = []
            start_date = []
            end_date = []
            org_ids = []
            year = []
            po_number = []

            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                for i in request_data['data']:
                    supplier_ids.append(i['supplier_id'])
                    prefix.append(i['prefix'])
                    start_date.append(i['start_date'])
                    end_date.append(i['end_date'])
                    org_ids.append(i['org_id'])
                    year.append(i['year'])
                    po_number.append(i['po_number'])

                conn.execute("""
                    DECLARE\
                        supplier_obj QPEX_FORECAST_PKG.po_format_type_cover;

                        type number_table_t is table of number
                        index by binary_integer;\

                    type string_table_t is table of nvarchar2(1000)
                        index by binary_integer;\

                        d_supplier_id number_table_t := :p_supplier_id;\
                        d_prefix  string_table_t := :p_prefix;\
                        d_start_date string_table_t := :p_start_date;\
                        d_end_date string_table_t := :p_end_date;\
                        d_year  number_table_t := :p_year;\
                        d_org_id number_table_t := :p_org_id;\
                        d_po_number number_table_t := :p_po_number;\

                    BEGIN\
                        for i in 1..d_supplier_id.count
                        LOOP
                            supplier_obj(i).supplier_id := d_supplier_id(i);\
                            supplier_obj(i).prefix := d_prefix(i);\
                            supplier_obj(i).start_date := d_start_date(i);\
                            supplier_obj(i).end_date := d_end_date(i);\
                            supplier_obj(i).year:= d_year(i);\
                            supplier_obj(i).org_id := d_org_id(i);\
                            supplier_obj(i).po_number := d_po_number(i);\

                        END LOOP;

                        QPEX_FORECAST_PKG.copy_supplier_po_formats(
                        supplier_obj,
                        :p_action,
                        :x_status_code);
                    END;

                    """, p_supplier_id=supplier_ids,
                             p_prefix=prefix,
                             p_start_date=start_date,
                             p_end_date=end_date,
                             p_org_id=org_ids,
                             p_year=year,
                             p_po_number=po_number,
                             p_action=request_data['action'],
                             x_status_code=status_code
                             )
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value, 'msg': '{} PO Formats Successfully'.format(
                    'Copied' if request_data['action'] == 'copy' else 'Updated')}
            else:
                result = {'status': Status.ERROR.value, 'msg': 'Failed to {} PO Formats'.format(
                    'Copied' if request_data['action'] == 'copy' else 'Updated')}

        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - forecast -
                copy_existing_po_formats """ + str(error))
            raise error
        logger.addinfo('@ models - forecast - get_supplier_po_updates(+)')
        return result
