import os
import xlsxwriter
import tempfile
from finapi.sql import sql_util
from finapi.utils.constants import Status
from finapi.utils.log_util import LogUtil
from finapi.models.outofdoor.uploadfile import UploadOutofDoorFiles
from finapi.utils.conn_util import OracleConnectionManager
from finapi.models.products.products import Products


@LogUtil.class_module_logs('safety_stocks')
class SafetyStock:

    def __init__(self):
        folder_name = os.path.basename(os.path.dirname(os.path.realpath(__file__)))
        self.sql_file = sql_util.get_sql(folder_name.lower())

    def upload_excel_to_db(self, jsond):
        """
            upload excel into db
            jsond: { base64: '', 'created_by': ''}
        """
        upload_obj = UploadOutofDoorFiles(jsond)
        sheet_name = upload_obj.get_sheets_list()
        upload_obj.sheet = upload_obj.get_workbook(sheet_name=sheet_name[0])
        row_index, columns = upload_obj.get_column_names()
        for column in columns:
            column['oracle_name'] = '_'.join(column['column_name'].lower().split(' '))

        upload_obj.columns = columns
        data = upload_obj.get_rows_data(row_index, 0)
        status_codes = []
        for stock in data:
            stock['created_by'] = jsond['created_by']
            if isinstance(stock['item_code'], float):
                stock['item_code'] = int(stock['item_code'])
            stock['item_code'] = str(stock['item_code'])
            status = self.insert_or_update_safety_stock(stock, send_email=False)
            if status['status'] != 0:
                stock['msg'] = status['msg']
                status_codes.append(stock)
        if len(status_codes) == len(data):
            result = {'status': Status.ERROR.value,
                      'msg': 'Failed to upload excel sheet'}
        else:
            result = {'status': Status.OK.value,
                      'msg': 'Excel uploaded successfully',
                      'status_errors': status_codes}
        return result

    def insert_or_update_safety_stock(self, stock, send_email=True):
        created_by = stock['created_by']
        with OracleConnectionManager() as conn:
            query = self.sql_file['item_code_safety_stock']
            conn.execute(query, p_item_code=str(stock['item_code']))
            output = conn.get_single_result()
            safety_stock_id = conn.set_output_param('NUMBER')
            flag = False
            if output:
                safety_stock_id.setvalue(0, output['safety_stock_id'])
                flag = True
            if not stock['safety_quantity']:
                stock['safety_quantity'] = 0
            else:
                stock['safety_quantity'] = int(round(stock['safety_quantity']))
            conn.execute("""
                BEGIN
                    qpex_forecast_pkg.insert_or_update_safety_stock(
                        :p_safety_stock_id,
                        :p_item_code,
                        :p_safety_quantity,
                        :p_created_by,
                        :x_status_code
                    );
                END;""", output_key='x_status_code',
                         p_safety_stock_id=safety_stock_id,
                         p_item_code=stock['item_code'],
                         p_safety_quantity=stock['safety_quantity'],
                         p_created_by=created_by)
            status_code = conn.get_output_param(raise_exception=False,
                                                send_email=send_email)
            if status_code == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Item details {} successfully'.format(
                              'updated' if flag else 'added'),
                          'safety_stock_id': int(safety_stock_id.getvalue())}
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Failed to {} item details - {}.'.format(
                              'update' if flag else 'add',
                              status_code)}
        return result

    @staticmethod
    def delete_safety_stock(stock_id):
        """
        For Deleting the stock details of item
        stock_id:  number
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                BEGIN
                    qpex_forecast_pkg.delete_safety_stock(
                        :p_safety_stock,
                        :x_status_code
                    );
                END;
                """, output_key='x_status_code',
                         p_safety_stock=stock_id)
            conn.get_output_param()
            result = {'status': Status.OK.value,
                      'msg': 'Deleted item successfully'}
        return result

    def get_safety_stock(self, org_id, lang='IT'):
        """
        Getting safety stock details from table
        org_id: number
        lang: language in string
        """
        product_obj = Products()
        if lang == 'IT':
            lang = 'I'
        elif lang == 'DE':
            lang = 'D'
        elif lang == 'FR':
            lang = 'F'
        else:
            lang = 'US'
        copia_id = product_obj.get_copia_id(org_id, None)
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_safety_stock_details']
            query = query.format(copia_id)
            conn.execute(query, p_org_id=org_id, p_lang=lang)
            result = conn.get_result()
        return {'status': Status.OK.value, 'safety_stocks': result}

    def parse_safety_stock(self, jsond):
        """
        fetch the get details and calculate the percentages
        """
        file_details = self.get_safety_stock(jsond['org_id'], jsond['lang'])['safety_stocks']
        for item in file_details:
            percentage = None
            item['onhand_quantity'] = item['onhand_quantity'] or 0
            if item['safety_quantity']:
                percentage = (float(item['onhand_quantity'] - item['safety_quantity']) /
                              float(item['safety_quantity'])) * 100
                percentage = round(percentage, 2)
            item['percentage'] = percentage
        file_details = sorted(file_details,
                              key=lambda k: (k['seq_number'] is None, k['seq_number']))
        return file_details

    def generate_safety_stock(self, jsond):
        # for creating temporary file with .xlsx as extension and file not to be deleted
        temp_folder = tempfile.NamedTemporaryFile(dir='/tmp/', suffix='.xlsx', delete=False)
        # for file path
        file_path = os.path.join(temp_folder.name)
        # file name is taken from the temporary folder path
        file_name = temp_folder.name.split('/')[-1]
        number_format = '#,###.00'
        # to remove existing file with the file_name
        if os.path.exists(file_path):
            os.remove(file_path)
        file_details = self.parse_safety_stock(jsond)

        # to create a new excel file
        workbook = xlsxwriter.Workbook(file_path, {'constant_memory': True})
        # to have a format for a row
        bold = workbook.add_format({'bold': True})
        num_format = workbook.add_format({'num_format': number_format})
        empty_format = workbook.add_format()

        if len(file_details) > 0:
            # to create a sheet in the excel
            worksheet = workbook.add_worksheet()
            # to get header details
            headers = [header for header in list(file_details[0].keys())]
            headers.remove('safety_stock_id')
            headers.remove('inventory_item_id')
            # to create header names in excel sheet
            list(map(lambda h_index_header:
                worksheet.write(0, h_index_header[0], h_index_header[1].replace('_', ' ').upper(), bold),
                enumerate(headers)))

            for v_index, item in enumerate(file_details):
                # to insert data w.r.t to the header values
                for h_index, header in enumerate(headers):
                    worksheet.write(v_index + 1, h_index, item[header],
                                    num_format if header == 'percentage' else empty_format)

        workbook.close()
        return {'status': 0, 'file_name': file_name}
