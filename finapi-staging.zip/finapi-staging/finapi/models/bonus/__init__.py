class db_configuration():
    cfg = None

    def getCfg(cfg):
        return cfg
