from finapi.utils.logdata import logger
from finapi.utils import db_util
from collections import OrderedDict
import base64
import string
import random
import xlrd
import os
import cx_Oracle


class Bonus:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def id_generator():
        size = 9
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))

    @staticmethod
    def writing(pencoded, sales_channel, number_format):
        logger.addinfo("@ models - bonus - writing(+)")
        try:
            if not number_format:
                number_format = '999,999.99'
            decoded = base64.b64decode(pencoded)
            file_name = Bonus.id_generator()
            tmp_f_name = '/tmp/' + file_name + '.xls'
            text_file = open(tmp_f_name, 'wb')
            text_file.write(decoded)
            text_file.close()
            tmp_data = Bonus.reading(tmp_f_name, number_format)
            os.remove(tmp_f_name)
        except Exception as error:
            logger.findaylog("""@ 37 EXCEPTION - models - bonus -
                 writing """ + str(error))
            raise error
        logger.addinfo("@ models - bonus - writing(-)")
        if isinstance(tmp_data, list):
            final_data = Bonus.remove_duplicates(tmp_data, sales_channel)
            return final_data
        else:
            return tmp_data

    @staticmethod
    def reading(file_name, number_format):
        logger.addinfo("@ models - bonus - reading(+)")
        try:
            b = xlrd.open_workbook(file_name)
            sheet = b.sheet_by_index(0)
            count = ''
            for rownum in range(1, sheet.nrows):
                r = sheet.row_values(rownum)
                if r[0] == 'TOTALE':
                    count = rownum
                    break
            data_list = []
            dup_array = ['col1', 'col2', 'col3', 'col4', 'col5', 'col6',
                         'col7', 'col8', 'col9', 'col10', 'col11', 'col12',
                         'col13', 'col14', 'col15', 'col16', 'col17', 'col18',
                         'col19', 'col20', 'col21', 'col22', 'col23', 'col24',
                         'col25', 'col26', 'col27', 'col28']
            for rownum in range(1, count-2):
                data = OrderedDict()
                r = sheet.row_values(rownum)
                temp = str(r[1])
                for i in range(0, len(dup_array)):
                    if isinstance(r[i], float):
                        data[dup_array[i]] = "%.2f" % r[i]
                    else:
                        data[dup_array[i]] = r[i]
                data_list.append(data)
        except Exception as error:
            logger.findaylog("""@ 340 EXCEPTION - bonus - outofdoor -
                 just_reading """ + str(error))
            raise error
        logger.addinfo("@ models - bonus - reading(-)")
        if temp[-3] == number_format[-3] or temp[-2] == number_format[-3]:
            return data_list
        else:
            final = {}
            msg = 'User number format and file number format are not same'
            final['status'] = 0
            final['msg'] = msg
            return final

    @staticmethod
    def remove_duplicates(tmp_data, sales_channel):
        logger.addinfo("@ models - bonus - remove_duplicates(+)")
        try:
            final_array = []
            for i in range(0, len(tmp_data)):
                tmp = list(tmp_data[i].items())[0]
                tmp_arr = [x for x in tmp]
                final_array.append(tmp_arr[1])
            final_array = final_array[:-3]
            agents = Bonus.get_agent_datails(sales_channel)
            final_list = list(set(final_array) - set(agents))
            indexes = []
            if len(final_list) > 0:
                for i in final_list:
                    index = final_array.index(i)
                    indexes.append(index)
            if len(indexes) > 0:
                for i in range(0, len(tmp_data)):
                    if i in indexes:
                        tmp_data[i]['new'] = 'Y'
                    else:
                        tmp_data[i]['new'] = 'N'
        except Exception as error:
            logger.findaylog("""@ 100 EXCEPTION - models - bonus -
                 remove_duplicates """ + str(error))
            raise error
        logger.addinfo("@ models - bonus - remove_duplicates(-)")
        return tmp_data

    # generate HeaderId
    @staticmethod
    def head_id():
        logger.addinfo("@ models - bonus - header_id(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['file_sequence_query']
            data = cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 121 EXCEPTION - models - bonus -
                 header_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - bonus - header_id(-)")
        return header_id

    @staticmethod
    def get_agent_datails(sales_channel):
        logger.addinfo('@ models - payments - get_agent_datails(+)')
        sql_file = db_util.getSqlData()
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['distinct_salesreps_query']
            cursor.execute(query, p_sales_channel=sales_channel)
        except Exception as error:
            logger.findaylog("""@ 120 EXCEPTION - models - bonus -
                 get_agent_datails """ + str(error))
            raise error
        else:
            agents = []
            for row in cursor:
                agents.append(row[0])
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - bonus - get_agent_datails(-)')
        return agents

    @staticmethod
    def post(jsond):
        logger.addinfo('@ models - expenses - post(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            data = []
            sql_data = 'insert into xx_file ('
            for quote_line in jsond:
                my_data = []
                for key, value in quote_line.items():
                    my_data.append(value)
                    new_record = tuple(my_data)
                data.append(new_record)
            for key, value in quote_line.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(quote_line.items()):
                sql_args += ":"+str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            cursor.executemany(sql_data, data)
            connection.commit()
        except Exception as error:
            logger.findaylog("""@ 176 EXCEPTION - models - bonus -
                 post """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - bonus - post(-)')
        return "success"

    @staticmethod
    def package_call(header_id):
        logger.addinfo('@ models - bonus - package_call(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
             QPEX_AGENTS_PKG.insert_bonus(:p_batch_id, :p_status);
            end;""", p_batch_id=header_id, p_status=status)
        except Exception as error:
            logger.findaylog("""@ 131 EXCEPTION - models - procurement -
                package_save """ + str(error))
            raise error
        finally:
            cur.close()
            con.commit()
            db_util.release_connection(con)
        logger.addinfo('@ models - procurement - package_save(-)')
        return status.getvalue()

    @staticmethod
    def get_bonus_details(period, group_name):
        logger.addinfo('@ models - payments - get_bonus_details(+)')
        sql_file = db_util.getSqlData()
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['bonus_details_query']
            cursor.execute(query, p_period=period, p_group_name=group_name)
        except Exception as error:
            logger.findaylog("""@ 120 EXCEPTION - models - bonus -
                 get_bonus_details """ + str(error))
            raise error
        else:
            bonuses = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                bonus = {}
                for index, fn in enumerate(fieldnames):
                    bonus[fn] = row[index]
                bonuses.append(bonus)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - bonus - get_bonus_details(-)')
        return bonuses

    @staticmethod
    def po_creation(period):
        logger.addinfo('@ models - bonus - package_call(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status = cur.var(cx_Oracle.STRING)
            msg = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
             APPS.XXALMO_PO_AUTOCREATE.IMPORT_REQ_IT00(:p_period, :p_status,
                                                       :p_msg);
            end;""", p_period=period, p_status=status, p_msg=msg)
        except Exception as error:
            logger.findaylog("""@ 277 EXCEPTION - models - procurement -
                package_save """ + str(error))
            raise error
        finally:
            cur.close()
            con.commit()
            db_util.release_connection(con)
        logger.addinfo('@ models - procurement - package_save(-)')
        return status.getvalue()

    @staticmethod
    def send_mail(period):
        logger.addinfo('@ models - bonus - package_call(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute("""
            begin
                APPS.XXALMO_PO_AUTOCREATE.SEND_BONUS_EMAIL_IT00(:p_period);
            end;""", p_period=period)
        except Exception as error:
            logger.findaylog("""@ 131 EXCEPTION - models - procurement -
                package_save """ + str(error))
            raise error
        finally:
            cur.close()
            con.commit()
            db_util.release_connection(con)
        logger.addinfo('@ models - procurement - package_save(-)')
        return 'success'

    @staticmethod
    def check_data_exist(period, sales_channel):
        logger.addinfo('@ models - payments - check_data_exist(+)')
        sql_file = db_util.getSqlData()
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['bonus_data_exist_query']
            cursor.execute(query, p_period=str(period),
                           p_sales_channel=str(sales_channel))
        except Exception as error:
            logger.findaylog("""@ 323 EXCEPTION - models - bonus -
                 check_data_exist """ + str(error))
            raise error
        else:
            bonuses = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                bonus = {}
                for index, fn in enumerate(fieldnames):
                    bonus[fn] = row[index]
                bonuses.append(bonus)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - bonus - check_data_exist(-)')
        return bonuses
