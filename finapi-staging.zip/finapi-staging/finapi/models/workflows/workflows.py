import cx_Oracle

from finapi.sql import sql_util
from finapi.utils.logdata import logger
from finapi.utils.constants import Status
from finapi.utils.conn_util import OracleConnectionManager


class Workflows(object):
    def __init__(self):
        self.sql_file = sql_util.get_sql('workflows')

    @staticmethod
    def add_approvers(req):
        logger.addinfo('@ models - workflows - add_approvers(+)')
        try:
            errors = []
            with OracleConnectionManager() as connection:
                status = connection.cursor.var(cx_Oracle.STRING)
                for approver in req['approvers']:
                    connection.execute('''
                    begin
                        qpex_workflow_pkg.add_approver(
                            :p_workflow_id,
                            :p_approver_id,
                            :p_approver_seq,
                            :p_comments,
                            :p_active,
                            :p_user_id,
                            :x_status_code
                        );
                    end; ''', p_workflow_id=req['workflow_id'],
                                       p_approver_id=approver['approver_id'],
                                       p_approver_seq=approver['approver_seq'],
                                       p_comments=approver.get('comments'),
                                       p_active=approver.get('active', 'Y'),
                                       p_user_id=req['user_id'],
                                       x_status_code=status)
                    if status.getvalue() != 'S':
                        errors.append({'approver_id': approver['approver_id'],
                                       'error': str(status.getvalue())})
                if errors:
                    result = {
                        'status': Status.ERROR.value,
                        'msg': 'Error adding approvers to the workflow',
                        'errors': errors
                    }
                else:
                    result = {
                        'status': Status.OK.value,
                        'msg': 'Approvers added successfully to the workflow'
                    }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                add_approvers ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - add_approvers(-)')
        return result

    @staticmethod
    def add_workflow(req):
        logger.addinfo('@ models - workflows - add_workflow(+)')
        try:
            with OracleConnectionManager() as connection:
                workflow_id = connection.cursor.var(cx_Oracle.NUMBER)
                status = connection.cursor.var(cx_Oracle.STRING)
                connection.execute('''
                begin
                    qpex_workflow_pkg.add_workflow(
                        :x_workflow_id,
                        :p_workflow_name,
                        :p_module,
                        :p_no_of_approvers,
                        :p_comments,
                        :p_active,
                        :p_user_id,
                        :x_status_code
                    );
                end; ''', x_workflow_id=workflow_id,
                                   p_workflow_name=req['workflow_name'],
                                   p_module=req['module'],
                                   p_no_of_approvers=req['no_of_approvers'],
                                   p_comments=req.get('description'),
                                   p_active=req.get('active', 'Y'),
                                   p_user_id=req['user_id'],
                                   x_status_code=status)
                if status.getvalue() == 'S':
                    if 'approvers' in req:
                        req['workflow_id'] = int(workflow_id.getvalue())
                        result = Workflows.add_approvers(req)
                    else:
                        result = {
                            'status': Status.OK.value,
                            'msg': 'Workflow created successfully',
                            'workflow_id': int(workflow_id.getvalue())
                        }
                else:
                    result = {
                        'status': Status.ERROR.value,
                        'msg': 'Error creating workflow - {}'.format(
                            status.getvalue())
                    }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                add_workflow ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - add_workflow(-)')
        return result

    @staticmethod
    def delete_approver(workflow_id, approver_id):
        logger.addinfo('@ models - workflows - delete_approver(+)')
        try:
            with OracleConnectionManager() as connection:
                status = connection.cursor.var(cx_Oracle.STRING)
                connection.execute('''
                begin
                    qpex_workflow_pkg.delete_approver(
                        :p_workflow_id,
                        :p_approver_id,
                        :x_status_code
                    );
                end; ''', p_workflow_id=workflow_id,
                                   p_approver_id=approver_id,
                                   x_status_code=status)
                if status.getvalue() == 'S':
                    result = {
                        'status': Status.OK.value,
                        'msg': 'Approver deleted successfully'
                    }
                else:
                    result = {
                        'status': Status.ERROR.value,
                        'msg': 'Error deleting approver - {}'.format(
                            str(status.getvalue()))
                    }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                delete_approver ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - delete_approver(-)')
        return result

    @staticmethod
    def delete_workflow_notification(notification_id):
        logger.addinfo('@ models - workflows - delete_workflow_notification(+)')
        try:
            with OracleConnectionManager() as connection:
                status = connection.cursor.var(cx_Oracle.STRING)
                connection.execute('''
                begin
                    qpex_workflow_pkg.delete_notification(
                        :p_notification_id,
                        :x_status_code
                    );
                end; ''', p_notification_id=notification_id,
                                   x_status_code=status)
                if status.getvalue() == 'S':
                    result = {
                        'status': Status.OK.value,
                        'msg': 'Notification delete successfully'
                    }
                else:
                    result = {
                        'status': Status.ERROR.value,
                        'msg': 'Failed to delete notification - {}'.format(
                            status.getvalue())
                    }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                delete_workflow_notification ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - delete_workflow_notification(-)')
        return result

    @staticmethod
    def update_approvers(req):
        logger.addinfo('@ models - workflows - update_approvers(+)')
        try:
            errors = []
            with OracleConnectionManager() as connection:
                status = connection.cursor.var(cx_Oracle.STRING)
                for approver in req['approvers']:
                    connection.execute('''
                    begin
                        qpex_workflow_pkg.update_approver(
                            :p_workflow_id,
                            :p_old_approver_id,
                            :p_approver_id,
                            :p_approver_seq,
                            :p_comments,
                            :p_active,
                            :p_user_id,
                            :x_status_code
                        );
                    end; ''', p_workflow_id=req['workflow_id'],
                                       p_old_approver_id=approver.get('old_approver_id', -1),
                                       p_approver_id=approver['approver_id'],
                                       p_approver_seq=approver['approver_seq'],
                                       p_comments=approver.get('comments'),
                                       p_active=approver.get('active', 'Y'),
                                       p_user_id=req['user_id'],
                                       x_status_code=status)
                    if status.getvalue() != 'S':
                        errors.append({'approver_id': approver['approver_id'],
                                       'error': str(status.getvalue())})
            if errors:
                result = {
                    'status': Status.ERROR.value,
                    'msg': 'Error updating approvers for the workflow',
                    'errors': errors
                }
            else:
                result = {
                    'status': Status.OK.value,
                    'msg': 'Approvers updated successfully for the workflow'
                }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                update_approvers ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - update_approvers(-)')
        return result

    @staticmethod
    def update_workflow(req):
        logger.addinfo('@ models - workflows - update_workflow(+)')
        try:
            with OracleConnectionManager() as connection:
                status = connection.cursor.var(cx_Oracle.STRING)
                connection.execute('''
                begin
                    qpex_workflow_pkg.update_workflow(
                        :p_workflow_id,
                        :p_workflow_name,
                        :p_module,
                        :p_no_of_approvers,
                        :p_comments,
                        :p_active,
                        :p_user_id,
                        :x_status_code
                    );
                end; ''', p_workflow_id=req['workflow_id'],
                                   p_workflow_name=req['workflow_name'],
                                   p_module=req['module'],
                                   p_no_of_approvers=req['no_of_approvers'],
                                   p_comments=req.get('description'),
                                   p_active=req.get('active', 'Y'),
                                   p_user_id=req['user_id'],
                                   x_status_code=status)
                if status.getvalue() == 'S':
                    if 'approvers' in req:
                        result = Workflows.update_approvers(req)
                    else:
                        result = {
                            'status': Status.OK.value,
                            'msg': 'Workflow updated successfully'
                        }
                else:
                    result = {
                        'status': Status.ERROR.value,
                        'msg': 'Error updating workflow - {}'.format(
                            str(status.getvalue()))
                    }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                update_workflow ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - update_workflow(-)')
        return result

    @staticmethod
    def update_workflow_notification(req):
        logger.addinfo('@ models - workflows - update_workflow_notification(+)')
        try:
            with OracleConnectionManager() as connection:
                status = connection.cursor.var(cx_Oracle.STRING)
                connection.execute('''
                begin
                    qpex_workflow_pkg.update_notification(
                        :p_notification_id,
                        :p_approver_id,
                        :p_approval_status,
                        :x_status_code
                    );
                end; ''', p_notification_id=req['notification_id'],
                                   p_approver_id=req['approver_id'],
                                   p_approval_status=req['approval_status'],
                                   x_status_code=status)
                if status.getvalue() == 'S':
                    result = {
                        'status': Status.OK.value,
                        'msg': 'Notification updated successfully'
                    }
                else:
                    result = {
                        'status': Status.ERROR.value,
                        'msg': 'Failed to update notification - {}'.format(
                            str(status.getvalue()))
                    }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                update_workflow_notification ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - update_workflow_notification(-)')
        return result

    def get_workflows(self, workflow_id, module, workflow_name=None):
        logger.addinfo('@ models - workflows - get_workflows(+)')
        result = []
        try:
            with OracleConnectionManager() as connection:
                query = self.sql_file['workflows_query']
                connection.execute(query, p_workflow_id=workflow_id,
                                   p_module=module,
                                   p_workflow_name=workflow_name)
                result = connection.get_result()
                if result and workflow_name:
                    workflow_id = result[0]['workflow_id']
                if workflow_id and result:
                    result[0]['approvers'] = self.get_workflow_approvers(
                        workflow_id)
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                get_workflows ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - get_workflows(-)')
        return result

    def get_workflow_approvers(self, workflow_id):
        logger.addinfo('@ models - workflows - get_workflow_approvers(+)')
        result = []
        try:
            with OracleConnectionManager() as connection:
                query = self.sql_file['workflow_approvers_query']
                connection.execute(query, p_workflow_id=workflow_id)
                result = connection.get_result()
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                get_workflow_approvers ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - get_workflow_approvers(-)')
        return result

    def get_workflow_notifications(self, req):
        logger.addinfo('@ models - workflows - get_workflow_notifications(+)')
        try:
            with OracleConnectionManager() as connection:
                query = self.sql_file['workflow_notifications_query']
                connection.execute(query, p_workflow_id=req['workflow_id'],
                                   p_wf_key=req['wf_key'],
                                   p_status=req['status'])
                result = connection.get_result()
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                get_workflow_notifications ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - get_workflow_notifications(-)')
        return result

    def get_workflow_users(self):
        logger.addinfo('@ models - workflows - get_workflow_users(+)')
        try:
            with OracleConnectionManager() as connection:
                query = self.sql_file['workflow_users_query']
                connection.execute(query)
                result = connection.get_result()
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                get_workflow_users ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - get_workflow_users(-)')
        return result

    @staticmethod
    def delete_workflow_with_wf_key(wf_key):
        logger.addinfo('@ models - workflows - delete_workflow_with_wf_key(+)')
        try:
            with OracleConnectionManager() as conn:
                conn.execute("""
               BEGIN
                    qpex_workflow_pkg.delete_workflow(
                        :p_wf_key,
                        :x_status_code
                    );
                END;
               """, output_key='x_status_code', p_wf_key=wf_key)
                status = conn.get_output_param(raise_exception=False, send_email=True)
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                delete_workflow_with_wf_key ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - delete_workflow_with_wf_key(-)')
        return status

    @staticmethod
    def update_wf_notify_based_on_approver_id(req):
        logger.addinfo('@ models - workflows - update_wf_notify_based_on_approver_id(+)')
        try:
            with OracleConnectionManager() as connection:
                status = connection.cursor.var(cx_Oracle.STRING)
                connection.execute('''
                begin
                    qpex_workflow_pkg.update_last_notifications(
                        :p_wf_key,
                        :p_prev_approver_id,
                        :p_approver_id,
                        :x_status_code
                    );
                end; ''', p_wf_key=req['wf_key'],
                                   p_prev_approver_id=req['old_approver_id'],
                                   p_approver_id=req['new_approver_id'],
                                   x_status_code=status)
                if status.getvalue() == 'S':
                    result = {
                        'status': Status.OK.value,
                        'msg': 'Notification updated successfully'
                    }
                else:
                    result = {
                        'status': Status.ERROR.value,
                        'msg': 'Failed to update notification - {}'.format(
                            str(status.getvalue()))
                    }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - workflows -
                update_wf_notify_based_on_approver_id ''' + str(error))
            raise error
        logger.addinfo('@ models - workflows - update_wf_notify_based_on_approver_id(-)')
        return result
