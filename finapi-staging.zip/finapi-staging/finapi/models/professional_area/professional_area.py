import os

from mailjet_rest import Client

from finapi.models.wordpress.wordpress import Wordpress
from finapi.utils import db_util
from finapi.utils.constants import Status
from finapi.utils.log_util import LogUtil
from finapi.utils.logdata import logger


class ProfessionalArea:

    def __init__(self):
        self.sql_file = db_util.getSqlData()
        self.strings = db_util.get_strings()
        self.api_key = os.environ['MJ_APIKEY_PUBLIC']
        self.api_secret = os.environ['MJ_APIKEY_PRIVATE']
        self.connection = None
        self.cursor = None

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    def customer_registration(self, req):
        logger.addinfo('@ models - professional_area - customer_registration(+)')
        res = {}
        try:
            send_almonature_mail = self.send_almonature_mail(req)
            if send_almonature_mail == 'SUCCESS':
                customer_mail = self.customer_registration_mail(
                    req['first_name'],
                    req['email_address'],
                    req['almo_contact_person'])
                if customer_mail == 'SUCCESS':
                    ProfessionalArea.mail_list_subscribe(req)
                else:
                    res['status'] = Status.ERROR.value
                    res['msg'] = 'Failed to send Email to user :' + \
                                 req['email_address']
            else:
                res['status'] = Status.ERROR.value,
                res['msg'] = 'Failed to send Email to almo person :' + \
                             req['almo_contact_person']
            res['status'] = Status.OK.value
            res['msg'] = 'User Registration Successful'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - professional_area -
                send_mail """ + str(error))
            raise error
        logger.addinfo('@ models - professional_area - send_mail(-)')
        return res

    def send_almonature_mail(self, req):
        logger.addinfo('@ models - professional_area - send_almonature_mail(+)')
        try:
            self.acquire()
            mailjet_obj = Client(auth=(self.api_key, self.api_secret))
            query = self.sql_file['reference_email_check']
            self.cursor.execute(query, p_reference_email=str(req['almo_contact_person']))
            user = self.cursor.fetchone()
            if user and user[0] > 0:
                ref_email = req['almo_contact_person']
            else:
                ref_email = self.strings['wp_alternate_ref_email']
            data = {
                'FromEmail': self.strings['sender_email'],
                'FromName': self.strings['sender_name'],
                'Subject': 'Professional Area - Registration - ' + \
                           req['business_name'] + ' | ' + req['first_name'],
                'MJ-TemplateID': 612946,
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': self.strings[
                    'mj_error_report_mail'],
                'Vars': {
                    'business_name': req['business_name'],
                    'sur_name': req['sur_name'],
                    'first_name': req['first_name'],
                    'email_address': req['email_address'],
                    'contact_number': req['contact_number'],
                    'country': req['country'],
                    'subject': req['subject'],
                    'almo_contact_person': ref_email,
                    'language': req['language'],
                    'req_link': req['req_link']
                },
                'Recipients': [
                    {
                        'Email': ref_email
                    }
                ]
            }
            res = mailjet_obj.send.create(data=data)
            if res.status_code != 200:
                mail_status = 'FAIL'
            else:
                mail_status = 'SUCCESS'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - professional_area -
                        send_almonature_mail -  """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - professional_area - send_mail(-)')
        return mail_status

    def customer_registration_mail(self, first_name, email_address,
                                   almo_contact=None):
        logger.addinfo('@ models - professional_area - customer_registration_mail(+)')
        try:
            mailjet_obj = Client(auth=(self.api_key, self.api_secret))
            if almo_contact:
                internal_contact = almo_contact + ' or web@almo.eu'
            else:
                internal_contact = 'web@almo.eu'
            data = {
                'FromEmail': self.strings['sender_email'],
                'FromName': self.strings['sender_name'],
                'Subject': self.strings['customer_register_subject_us'],
                'MJ-TemplateID': 575991,
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': self.strings[
                    'mj_error_report_mail'],
                'Vars': {
                    'almo_contact_person': internal_contact,
                    'first_name': first_name
                },
                'Recipients': [
                    {
                        'Email': email_address
                    }
                ]
            }
            res = mailjet_obj.send.create(data=data)
            if res.status_code != 200:
                mail_status = 'FAIL'
            else:
                mail_status = 'SUCCESS'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - professional_area -
                customer_registration_mail """ + str(error))
            raise error
        logger.addinfo('@ models - professional_area - customer_registration_mail(-)')
        return mail_status

    @staticmethod
    def mail_list_subscribe(jsond):
        logger.addinfo('@ models - professional_area - mail_list_subscribe(+)')
        try:
            privacy = jsond['privacy'][0]
            obj = {
                'name': jsond['first_name'],
                'email': jsond['email_address'],
                'pet_type': '',
                'country': jsond['country'],
                'zip_code': jsond['postal_code'] if 'postal_code' in jsond
                else '',
                'project': 'N',
                'consent_projects': privacy['consent_projects'],
                'consent_profiling': privacy['consent_profiling'],
                'consent_foundation': privacy['consent_foundation'],
                'source': jsond['source'],
                'unsubscribe': False,
                'confirm': False
            }
            if obj['consent_projects'] == 'Y' or \
                    obj['consent_profiling'] == 'Y' or \
                    obj['consent_foundation'] == 'Y':
                # Wordpress.add_subscriber(obj)
                Wordpress.add_contact_hubspot(obj)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - professional_area -
                mail_list_subscribe """ + str(error))
            raise error
        logger.addinfo('@ models - professional_area - mail_list_subscribe(-)')
        return 'SUCCESS'

    def send_approved_mail(self, jsond):
        logger.addinfo('@ models - professional_area - send_approved_mail(+)')
        try:
            mailjet_obj = Client(auth=(self.api_key, self.api_secret))
            data = {
                'FromEmail': self.strings['sender_email'],
                'FromName': self.strings['sender_name'],
                'Subject': self.strings['customer_confirm_subject_us'],
                'MJ-TemplateID': 575996,
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': self.strings[
                    'mj_error_report_mail'],
                'Vars': {
                    'first_name': jsond['first_name'],
                    'user_email': jsond['user_email'],
                    'user_password': jsond['user_password'],
                    'login_link': jsond['login_link']
                },
                'Recipients': [
                    {
                        'Email': jsond['user_email']
                    }
                ]
            }
            mailjet_obj.send.create(data=data)
            final = {'status': 0, 'msg': 'User approved successfully'}
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - professional_area -
                send_approved_mail """ + str(error))
            raise error
        logger.addinfo('@ models - professional_area - send_approved_mail(-)')
        return final

    def business_enquiry(self, jsond):
        logger.addinfo('@ models - professional_area - business_enquiry(+)')
        try:
            final = {'status': '', 'msg': ''}
            email_cc = ''
            if jsond['almo_contact_person'] and jsond['mail_to_cc']:
                email_cc = jsond['almo_contact_person'] + ',' + jsond['mail_to_cc']
            elif jsond['almo_contact_person']:
                email_cc = jsond['almo_contact_person']
            elif jsond['mail_to_cc']:
                email_cc = jsond['mail_to_cc']
            mailjet_obj = Client(auth=(self.api_key, self.api_secret))
            data = {
                'FromEmail': self.strings['sender_email'],
                'FromName': self.strings['sender_name'],
                'Subject': 'Professional Area - Business Inquiry - ' + \
                           jsond['business_name'] + ' | ' + jsond['first_name'],
                'MJ-TemplateID': 612944,
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': self.strings[
                    'mj_error_report_mail'],
                'Vars': {
                    'support_person_name': jsond['support_person_name'],
                    'business_name': jsond['business_name'],
                    'sur_name': jsond['sur_name'],
                    'first_name': jsond['first_name'],
                    'email_address': jsond['email_address'],
                    'country': jsond['country'],
                    'postal_code': jsond['postal_code'],
                    'contact_number': jsond['contact_number'],
                    'subject': jsond['subject']
                },
                'To': jsond['support_person_email']
            }
            if email_cc:
                data['Cc'] = email_cc
            res = mailjet_obj.send.create(data=data)
            if res.status_code != 200:
                final['status'] = Status.ERROR.value
                final['msg'] = 'Failed to send Business enquiry details:' + \
                               jsond['email_address']
            else:
                ProfessionalArea.mail_list_subscribe(jsond)
            final['status'] = 0
            final['msg'] = 'Business Enquiry Details sent successfully'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - professional_area -
                business_enquiry """ + str(error))
            raise error
        logger.addinfo('@ models - professional_area - business_enquiry(-)')
        return final

    @staticmethod
    def send_log(func, err, inp):
        LogUtil.send_log({
            'source': 'Finapi',
            'module': 'professional_area',
            'function': func,
            'error_msg': err,
            'input_data': inp
        })
