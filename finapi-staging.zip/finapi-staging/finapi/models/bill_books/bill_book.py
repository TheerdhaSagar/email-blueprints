from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util
from finapi.utils.log_util import LogUtil
from finapi.utils.conn_util import OracleConnectionManager
from finapi.sql import sql_util


@LogUtil.class_module_logs('BillBook')
class BillBook:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def update_billbook_notes(self, jsond):
        logger.addinfo('@ models - billbook - update_billbook_notes(+)')
        try:
            with OracleConnectionManager() as conn:
                conn.execute("""
                    begin
                        qpex_reports_pkg.update_billbook_notes(
                            :p_customer_trx_id,
                            :p_notes,
                            :p_user_id,
                            :x_status_code
                        );
                    end;
                """, output_key='x_status_code',
                             p_customer_trx_id=jsond['customer_trx_id'],
                             p_notes=jsond['notes'],
                             p_user_id=jsond['user_id'])
                status = conn.get_output_param()
                if status == 'SUCCESS':
                    result = {
                        'msg': 'Notes updated successfully',
                        'status': 0
                    }
        except Exception as error:
            logger.findaylog("""@EXCEPTION - models - billbook -
                                update_billbook_notes - """ + str(error))
            raise error
        logger.addinfo('@ models - billbook - update_billbook_notes(-)')
        return result

    # shows all bills
    @staticmethod
    @db_util.langs("American")
    def show_all_bills(puserid, org_id, account_id):
        logger.addinfo('@ models - billbook - show_all_bills(+)')
        query = 'bill_book_all'
        if not account_id:
            sales_rep = 'bill_book_salesRep'
            manager_query = 'bill_book_all_manager'
            bills = genericBillcall(puserid, org_id, sales_rep, query,
                                    manager_query)
        else:
            bills = account_bill_call(account_id, org_id, query)
        logger.addinfo('@ models - billbook - show_all_bills(-)')
        return bills

    # shows bills based on customer
    @staticmethod
    @db_util.langs("American")
    def show_bills_customer(puserid, org_id):
        logger.addinfo('@ models - billbook - show_bills_customer(+)')
        query = 'bill_book_cust'
        sales_rep = 'bill_book_cust_SalesRep'
        manager_query = 'bill_book_cust_manager'
        bills = genericBillcall(puserid, org_id, sales_rep, query,
                                manager_query)
        logger.addinfo('@ models - billbook - show_bills_customer(-)')
        return bills

    # shows bills based on customer
    @staticmethod
    @db_util.langs("American")
    def show_bills_agent(puserid, org_id):
        logger.addinfo('@ models - billbook - show_bills_agent(+)')
        query = 'bill_book_agnt'
        sales_rep = 'bill_book_agnt_salesRep'
        manager_query = 'bill_book_agnt_manager'
        bills = genericBillcall(puserid, org_id, sales_rep, query,
                                manager_query)
        logger.addinfo('@ models - billbook - show_bills_agent(-)')
        return bills

    # shows bills based on duedate
    @staticmethod
    @db_util.langs("American")
    def show_bills_duedate(puserid, org_id):
        logger.addinfo('@ models - billbook - show_bills_duedate(+)')
        query = 'bill_book_due'
        sales_rep = 'bill_book_due_salesRep'
        manager_query = 'bill_book_due_manager'
        bills = genericBillcall(puserid, org_id, sales_rep, query,
                                manager_query)
        logger.addinfo('@ models - billbook - show_bills_duedate(-)')
        return bills

    # shows bills based on due date range
    @staticmethod
    @db_util.langs("American")
    def show_bills_duedate_range(jsond):
        logger.addinfo('@ models - billbook - show_bills_duedate_range(+)')
        from_date = jsond['from_days']
        to_date = jsond['to_days']
        userid = jsond['user_id']
        orgid = jsond['org_id']
        connection = None
        cursor = None
        refid = ""
        ptype = ""
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query_all = sql_file['bill_book_dudate_range']
            user_type = Code_util.get_usertype(userid)
            ptype = user_type['type']
            refid = user_type['refid']
            if ptype == 'b2b':
                cursor.execute(query_all, p_cust_account_id=refid,
                               p_org_id=orgid, p_from_date=from_date,
                               p_to_date=to_date)
            elif ptype == 'salesrep':
                salesid_qry = sql_file['salesrep_ids']
                cur = connection.cursor()
                cur.execute(salesid_qry, user_id=userid)
                ids = cur.fetchall()
                cur.close()
                length = len(ids)
                idList = []
                for count in range(length):
                    id = ids[count][0]
                    idList.append(id)
                query_temp = sql_file['bill_dudate_range_salesrep']
                bil_query = query_temp % (',' . join([":" + str(i)
                                                      for i in range(len(idList))]),
                                          orgid, from_date, to_date)
                cursor.execute(bil_query, idList)
            elif ptype == 'manager':
                group_id_query = sql_file['group-ids-query']
                cur = connection.cursor()
                cur.execute(group_id_query, p_user_id=refid)
                ids = cur.fetchall()
                cur.close()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                query_temp = sql_file['bill_dudate_range_manager']
                manager_query = query_temp % (orgid, ',' . join([":" + str(i)
                                                                 for i in range(len(listk))]),
                                              from_date, to_date)
                cursor.execute(manager_query, listk)
            else:
                cursor.execute(query_all, p_cust_account_id=None,
                               p_org_id=orgid, p_from_date=from_date,
                               p_to_date=to_date)
        except Exception as error:
            logger.findaylog("""@ 130 EXCEPTION - models - billbook -
                 show_bills_duedate_range """ + str(error))
            raise error
        else:
            bills = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                bills.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - billbook - show_bills_duedate_range(-)')
        return bills

    # shows bills based on currency
    @staticmethod
    @db_util.langs("American")
    def show_bills_currency(puserid, org_id):
        logger.addinfo('@ models - billbook - show_bills_currency(+)')
        query = 'bill_book_currency'
        sales_rep = 'bill_book_currency_salesRep'
        manager_query = 'bill_book_currency_manager'
        bills = genericBillcall(puserid, org_id, sales_rep, query,
                                manager_query)
        logger.addinfo('@ models - billbook - show_bills_currency(-)')
        return bills

    # get customer bills based on salesrep
    @staticmethod
    @db_util.langs("American")
    def show_bill_customer_bySalesRep(org_id, sales_rep_id):
        logger.addinfo("""@ models - billbook -
             show_bill_customer_bySalesRep(+)""")
        connection = None
        cursor = None
        try:
            if sales_rep_id == 'null':
                sales_rep_id = None
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            salesrep_query = sql_file['bill_book_by_salesrep']
            cursor.execute(salesrep_query, p_sales_rep=sales_rep_id,
                           p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ 176 EXCEPTION - models - billbook -
                 show_bill_customer_bySalesRep """ + str(error))
            raise error
        else:
            bills = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                bills.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("""@ models - billbook -
             show_bill_customer_bySalesRep(-)""")
        return bills

    # get due invoices by sales channel
    @staticmethod
    @db_util.langs("American")
    def billbook_saleschannel(jsond):
        logger.addinfo("""@ models - billbook - billbook_saleschannel(+)""")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['billbook_saleschannel']
            cursor.execute(query, p_group_name=jsond['group_name'],
                           p_org_id=jsond['org_id'])
        except Exception as error:
            logger.findaylog("""@ 176 EXCEPTION - models - billbook -
                 billbook_saleschannel """ + str(error))
            raise error
        else:
            bills = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                bills.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("""@ models - billbook - billbook_saleschannel(-)""")
        return bills

    @staticmethod
    def get_saleschannels():
        logger.addinfo('@ models - billbook - get_saleschannels(+)')
        connection = None
        cursor = None
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['billbook_saleschannels_query']
            cursor.execute(query)
            data = Code_util.iterate_data(cursor)
        except Exception as e:
            logger.findaylog('''@ EXCEPTION models - billbook -
                get_saleschannels ''' + str(e))
            raise e
        finally:
            if cursor:
                cursor.close()
                db_util.release_connection(connection)
        logger.addinfo('@ models - billbook - get_saleschannels(-)')
        return data

    @db_util.langs("American")
    def get_customer_notes_history(self, customer_id):
        with OracleConnectionManager() as conn:
            query = self.sql_file['comments_history']
            conn.execute(query, p_customer_trx_id=customer_id)
            result = conn.get_result()
        return {'status': 0, 'comments': result}


def account_bill_call(account_id, org_id, query):
    logger.addinfo('@ models - billbook - account_bill_call(+)')
    connection = None
    cursor = None
    try:
        connection = db_util.get_connection()
        cursor = connection.cursor()
        sql_file = db_util.getSqlData()
        query_all = sql_file[query]
        cursor.execute(query_all, p_cust_account_id=account_id,
                       p_org_id=org_id)
    except Exception as error:
        logger.findaylog("""@ 207 EXCEPTION - models - billbook -
             account_bill_call """ + str(error))
        raise error
    else:
        bills = []
        fieldnames = [a[0].lower() for a in cursor.description]
        for row in cursor:
            result = {}
            for index, field in enumerate(fieldnames):
                result[field] = row[index]
            bills.append(result)
    finally:
        cursor.close()
        db_util.release_connection(connection)
    logger.addinfo('@ models - billbook - account_bill_call(-)')
    return bills


def genericBillcall(puserid, org_id, sales_rep_query, all_query,
                    manager_query):
    logger.addinfo('@ models - billbook - genericBillcall(+)')
    connection = None
    cursor = None
    refid = ""
    ptype = ""
    try:
        connection = db_util.get_connection()
        cursor = connection.cursor()
        sql_file = db_util.getSqlData()
        query_all = sql_file[all_query]
        user_type = Code_util.get_usertype(puserid)
        ptype = user_type['type']
        refid = user_type['refid']
        if ptype == 'b2b':
            cursor.execute(query_all, p_cust_account_id=refid, p_org_id=org_id)
        elif ptype == 'salesrep':
            salesid_qry = sql_file['salesrep_ids']
            cur = connection.cursor()
            cur.execute(salesid_qry, user_id=puserid)
            ids = cur.fetchall()
            cur.close()
            length = len(ids)
            idList = []
            for count in range(length):
                id = ids[count][0]
                idList.append(id)
            query_temp = sql_file[sales_rep_query]
            bil_query = query_temp % (',' . join([":" + str(i)
                                                  for i in range(len(idList))]),
                                      org_id)
            cursor.execute(bil_query, idList)
        elif ptype == 'manager':
            group_id_query = sql_file['group-ids-query']
            cur = connection.cursor()
            cur.execute(group_id_query, p_user_id=refid)
            ids = cur.fetchall()
            cur.close()
            length = len(ids)
            listk = []
            for count in range(length):
                id = ids[count][0]
                listk.append(id)
            query_temp = sql_file[manager_query]
            manager_query = query_temp % (org_id, ',' . join([":" + str(i)
                                                              for i in range(len(listk))]))
            cursor.execute(manager_query, listk)
        else:
            cursor.execute(query_all, p_cust_account_id=None, p_org_id=org_id)
    except Exception as error:
        logger.findaylog("""@ 276 EXCEPTION - models - billbook -
             genericBillcall """ + str(error))
        raise error
    else:
        bills = []
        fieldnames = [a[0].lower() for a in cursor.description]
        for row in cursor:
            result = {}
            for index, field in enumerate(fieldnames):
                result[field] = row[index]
            bills.append(result)
    finally:
        cursor.close()
        db_util.release_connection(connection)
    logger.addinfo('@ model - billbook - genericBillcall(-)')
    return bills


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'billbook',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
