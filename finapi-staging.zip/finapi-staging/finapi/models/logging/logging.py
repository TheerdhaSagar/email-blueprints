from finapi.sql import sql_util
from finapi.utils.log_util import LogUtil
from finapi.utils.conn_util import OracleConnectionManager


@LogUtil.class_module_logs('logging')
class Logging(object):
    def __init__(self):
        self.sql_file = sql_util.get_sql('logging')

    def get_log(self, reference_id):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_log_query']
            conn.execute(query, p_reference_id=reference_id)
            result = conn.get_result()
        return result
