from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.constants import Status
from finapi.models.creditNotes.creditNote import CreditNote
from finapi.utils.common_utils import CommonUtils
from finapi.utils.conn_util import OracleConnectionManager
import cx_Oracle


class Reclaim:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def get_trx_numbers(self, customer_number, item_code):
        logger.addinfo('@ models - reclaim - get_trx_numbers(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_trx_number']
                conn.cursor.execute(query, p_account_number=customer_number, p_item_code=item_code)
                result = Code_util.iterate_data(conn.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - reclaim -
              get_trx_numbers""" + str(e))
            raise e
        logger.addinfo('@ models - reclaim - get_trx_numbers(+)')
        return result

    def get_item_codes(self, org_id):
        logger.addinfo('@ models - reclaim - get_item_codes(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_item_codes']
                conn.cursor.execute(query, p_org_id=org_id)
                result = Code_util.iterate_data(conn.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - reclaim -
              get_item_codes""" + str(e))
            raise e
        logger.addinfo('@ models - reclaim - get_item_codes(+)')
        return result

    def get_reclaim_agent_summary(self, data):
        logger.addinfo('@ models - reclaim - get_reclaim_agent_summary(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_customer_claim_sales_rep_summary']
                query %= (','.join([str(data['sales_rep_ids'][i])
                                    for i in range(len(data['sales_rep_ids']))]))
                conn.cursor.execute(query, p_status=data['status'])
                result = Code_util.iterate_data(conn.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - reclaim -
              get_reclaim_agent_summary""" + str(e))
            raise e
        logger.addinfo('@ models - reclaim - get_reclaim_agent_summary(+)')
        return result

    def get_customer_reclaim_details(self, reclaim_id, org_id, item_code, status):
        logger.addinfo('@ models - reclaim - get_customer_reclaim_details(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_customer_claim_details']
                conn.cursor.execute(query, p_reclaim_id=reclaim_id, p_org_id=org_id,
                                    p_item_code=item_code, p_status=status)
                result = Code_util.iterate_data(conn.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - reclaim -
              get_customer_reclaim_details""" + str(e))
            raise e
        logger.addinfo('@ models - reclaim - get_customer_reclaim_details(+)')
        return result

    def get_supplier_reclaim_details(self, reclaim_id, org_id, item_code, status):
        logger.addinfo('@ models - reclaim - get_supplier_reclaim_details(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_supplier_claim_details']
                conn.cursor.execute(query, p_reclaim_vendor_id=reclaim_id, p_org_id=org_id,
                                    p_item_code=item_code, p_status=status)
                result = Code_util.iterate_data(conn.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - reclaim -
              get_supplier_reclaim_details""" + str(e))
            raise e
        logger.addinfo('@ models - reclaim - get_supplier_reclaim_details(+)')
        return result

    def add_reclaim(self, data):
        """inserting a new reclaim raised for damaged/expired product by Agent/back office people"""
        logger.addinfo('@ models - reclaim - add_reclaim(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                reclaim_id = conn.cursor.var(cx_Oracle.NUMBER)
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                begin
                    qpex_reclaim_pkg.insert_reclaim_customer(
                    :x_reclaim_id,
                    :p_cust_account_id,
                    :p_party_site_id,
                    :p_reference_person,
                    :p_telephone_number,
                    :p_sales_rep_id,
                    :p_item_code,
                    :p_problem_description,
                    :p_qty,
                    :p_claim_amount,
                    :p_batch_number,
                    :p_is_reported,
                    :p_invoice_number,
                    :p_customer_trx_line_id,
                    :p_internal_comments,
                    :p_linked_supplier_claim_id,
                    :p_org_id,
                    :p_created_id,
                    :p_claim_status,
                    :x_status_code
                    );
                end; """, x_reclaim_id=reclaim_id,
                                    p_cust_account_id=data['cust_account_id'],
                                    p_party_site_id=data['party_site_id'],
                                    p_reference_person=data['reference_person'],
                                    p_telephone_number=data['telephone_number'],
                                    p_sales_rep_id=data['sales_rep_id'],
                                    p_item_code=data['item_code'],
                                    p_problem_description=data['problem_description'],
                                    p_qty=data['qty'],
                                    p_claim_amount=data['claim_amount'],
                                    p_batch_number=data['batch_number'],
                                    p_is_reported=data['is_reported'],
                                    p_invoice_number=data['invoice_number'],
                                    p_customer_trx_line_id=data['customer_trx_line_id'],
                                    p_internal_comments=data['internal_comments'],
                                    p_linked_supplier_claim_id=data['linked_supplier_claim_id'],
                                    p_org_id=data['org_id'],
                                    p_created_id=data['created_id'],
                                    p_claim_status=data['status'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    attachment_status = 'SUCCESS'
                    if len(data['attachments']) > 0:
                        status = self.add_attachment(attachments=data['attachments'],
                                                     reference_id=int(reclaim_id.getvalue()),
                                                     reference_type='customer',
                                                     created_id=data['created_id'])
                        if status['status'] != 0:
                            attachment_status = 'Failed'
                    query = self.sql_file['get_role_users']
                    # Send notification to all users who has the below role
                    conn.cursor.execute(query,
                                        p_role_name='UI-RECLAIM-RECEIVE-NOTIFICATIONS')
                    users = Code_util.iterate_data(conn.cursor)
                    recipients = []
                    receive_notification_names = []
                    for i in range(len(users)):
                        if users[i]['employee_number'] != data['created_id']:
                            recipients.append({
                                'Email': users[i]['email_address'],
                                'Name': ''
                            })
                            receive_notification_names.append(users[i]['full_name'])
                    req_data = {
                        'template_id': 1054264,
                        'subject': 'New Reclaim Request has been raised - #' +
                                   str(int(reclaim_id.getvalue())),
                        'params': [
                            {
                                'key': 'item_code',
                                'value': data['item_code']
                            },
                            {
                                'key': 'qty',
                                'value': data['qty']
                            },
                            {
                                'key': 'problem_description',
                                'value': data['problem_description']
                            },
                            {
                               'key': 'batch_number',
                               'value': data['batch_number']
                            },
                            {
                                'key': 'reclaim_id',
                                'value': str(int(reclaim_id.getvalue()))
                            },
                            {
                                'key': 'customer_name',
                                'value': data['customer_name']
                            },
                            {
                                'key': 'org_id',
                                'value': data['org_id']
                            }]
                    }
                    if data['requested_by'] == 'Agent':
                        query = self.sql_file['get_mail_id']
                        conn.cursor.execute(query, p_user_id=data['created_id'])
                        back_office_email = ''
                        back_office_user_name = ''
                        user_data = Code_util.iterate_data(conn.cursor)
                        if user_data:
                            back_office_email = user_data[0]['email_address']
                            back_office_user_name = user_data[0]['user_description']
                        if back_office_email:
                            recipients.append({
                                'Email': back_office_email
                            })
                            receive_notification_names.append(back_office_user_name)
                    else:
                        query = self.sql_file['get_agent_details']
                        conn.cursor.execute(query, p_reference_value=data['sales_rep_id'])
                        agent_data = Code_util.iterate_data(conn.cursor)
                        if agent_data:
                            agent_name = agent_data[0]['user_description']
                            agent_email = agent_data[0]['email_address']
                            recipients.append({
                                'Email': agent_email
                            })
                            receive_notification_names.append(agent_name)
                    req_data['params'].append({
                        'key': 'notification_users',
                        'value': ', '.join(receive_notification_names)
                    })
                    req_data['recipients'] = recipients
                    mail_status = CommonUtils.send_mail(req_data)
                    if mail_status == 'SUCCESS':
                        if attachment_status == 'SUCCESS':
                            result['status'] = Status.OK.value
                            result['msg'] = 'Reclaim request accepted'
                            result['reclaim_id'] = int(reclaim_id.getvalue())
                        else:
                            result['status'] = Status.ERROR.value
                            result['msg'] = 'Reclaim request created, but attachments failed'
                            result['reclaim_id'] = int(reclaim_id.getvalue())
                    else:
                        result['status'] = Status.ERROR.value
                        result['msg'] = 'Reclaim request created, but failed to send email'
                        result['reclaim_id'] = int(reclaim_id.getvalue())
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to created Reclaim request'
                    result['reclaim_id'] = -1
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
              add_reclaim """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - add_reclaim(+)')
        return result

    @staticmethod
    def link_customer_supplier(data):
        logger.addinfo('@ models - reclaim - link_customer_supplier(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                begin
                    qpex_reclaim_pkg.link_customer_supplier(
                    :p_customer_reclaim_id,
                    :p_supplier_claim_id,
                    :p_recent_updated_id,
                    :p_type,
                    :x_status_code
                    );
                end; """, p_customer_reclaim_id=data['customer_reclaim_id'],
                                    p_supplier_claim_id=data['supplier_claim_id'],
                                    p_recent_updated_id=data['recent_updated_id'],
                                    p_type=data.get('type', ''),
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    result['status'] = Status.OK.value
                    result['msg'] = 'Reclaim link updated successfully'
                    result['customer_reclaim_id'] = data['customer_reclaim_id']
                    result['supplier_claim_id'] = data['supplier_claim_id']
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to update Reclaim link'
                    result['customer_reclaim_id'] = data['customer_reclaim_id']
                    result['supplier_claim_id'] = data['supplier_claim_id']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
              link_customer_supplier """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - link_customer_supplier(+)')
        return result

    @staticmethod
    def update_reclaim(data):
        """updating an existing reclaim raised"""
        logger.addinfo('@ models - reclaim - update_reclaim(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                begin
                    qpex_reclaim_pkg.update_reclaim_customer(
                    :p_reclaim_id,
                    :p_party_site_id,
                    :p_reference_person,
                    :p_telephone_number,
                    :p_sales_rep_id,
                    :p_item_code,
                    :p_problem_description,
                    :p_qty,
                    :p_claim_amount,
                    :p_batch_number,
                    :p_is_reported,
                    :p_invoice_number,
                    :p_customer_trx_line_id,
                    :p_internal_comments,
                    :p_status,
                    :p_recent_updated_id,
                    :x_status_code
                    );
                end; """, p_reclaim_id=data['reclaim_id'],
                                    p_party_site_id=data['party_site_id'],
                                    p_reference_person=data['reference_person'],
                                    p_telephone_number=data['telephone_number'],
                                    p_sales_rep_id=data['sales_rep_id'],
                                    p_item_code=data['item_code'],
                                    p_problem_description=data['problem_description'],
                                    p_qty=data['qty'],
                                    p_claim_amount=data['claim_amount'],
                                    p_batch_number=data['batch_number'],
                                    p_is_reported=data['is_reported'],
                                    p_invoice_number=data['invoice_number'],
                                    p_customer_trx_line_id=data['customer_trx_line_id'],
                                    p_internal_comments=data['internal_comments'],
                                    p_status=data['status'],
                                    p_recent_updated_id=data['recent_updated_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    result['status'] = Status.OK.value
                    result['msg'] = 'Reclaim request updated successfully'
                    result['reclaim_id'] = data['reclaim_id']
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to update reclaim request'
                    result['reclaim_id'] = data['reclaim_id']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
              update_reclaim """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - update_reclaim(+)')
        return result

    @staticmethod
    def delete_request(reclaim_id):
        logger.addinfo('@ models - reclaim - delete_request(+)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                result = {}
                conn.cursor.execute("""
                begin
                    qpex_reclaim_pkg.delete_reclaim_customer(:p_reclaimi_id,
                    :x_status_code
                    );
                end; """, p_reclaimi_id=reclaim_id,
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    result['status'] = 0
                    result['msg'] = 'Request deleted Successfully'
                    result['reclaim_id'] = reclaim_id
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to delete Request'
                    result['reclaim_id'] = reclaim_id
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - reclaim -
                             delete_request """ + str(e))
            raise e
        logger.addinfo('models - reclaim - delete_request(-)')
        return result

    def create_credit_note(self, req):
        logger.addinfo('@ models - reclaim - create_credit_note(+)')
        cn_lines = []
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['cn_customer_details_query']
                conn.cursor.execute(query, p_cust_account_id=req['cust_account_id'],
                                    p_party_site_id=req['party_site_id'])
                customer = Code_util.iterate_data(conn.cursor)
                total = 0
                customer_reclaim_ids = []
                claim_ids = ''
                for line in req['lines']:
                    total += line['amount']
                    customer_reclaim_ids.append(line['reclaim_id'])
                    claim_ids += str(line['reclaim_id']) + ', '
                    cn_lines.append({
                        'quantity': line['quantity'],
                        'price': line['price'],
                        'extended_amount': line['amount'],
                        'customer_trx_line_id': line['customer_trx_line_id'],
                        'org_id': req['org_id'],
                        'last_update_date': req['date'],
                        'last_updated_by': req['user_id'],
                        'creation_date': req['date'],
                        'created_by': req['user_id'],
                        'ATTRIBUTE1': line['item_code'],
                        'ATTRIBUTE2': '',
                        'ATTRIBUTE3': line['item_description'],
                        'ATTRIBUTE4': '',
                        'ATTRIBUTE5': ''
                    })
                # attribute_1 is cust_trx_type_id, attribute_6 is reason_code
                cn_header = {
                    'customer_trx_id': req['customer_trx_id'],
                    'org_id': req['org_id'],
                    'last_update_date': req['date'],
                    'last_updated_by': req['user_id'],
                    'creation_date': req['date'],
                    'status': 'DRAFT',
                    'created_by': req['user_id'],
                    'ATTRIBUTE1': 1005,
                    'ATTRIBUTE2': req['cust_account_id'],
                    'ATTRIBUTE3': customer[0]['billto_site_use_id'],
                    'ATTRIBUTE4': customer[0]['shipto_site_use_id'],
                    'ATTRIBUTE5': req['currency_code'],
                    'ATTRIBUTE6': req['reason_code'],
                    'ATTRIBUTE8': 'N/A',
                    'ATTRIBUTE9': 'N',
                    'ATTRIBUTE10': 1072,
                    'ATTRIBUTE11': 'N',
                    'ATTRIBUTE12': 'N',
                    'ATTRIBUTE13': '',
                    'COMMENTS': 'Created from Reclaim (' + claim_ids[:-2] + ')',
                    'internal_comment': 'Created from Reclaim (' + claim_ids[:-2] + ')',
                    'total_amount': total,
                    'files': []
                }
                result = CreditNote.insertCreditNote(cn_header, cn_lines)
                if result['status'] == 0:
                    status = conn.cursor.var(cx_Oracle.STRING)
                    for reclaim_id in customer_reclaim_ids:
                        conn.cursor.execute("""
                        begin
                            qpex_reclaim_pkg.update_cm_customer_claim (
                                :p_reclaim_id,
                                :p_cm_header_id,
                                :p_recent_updated_id,
                                :x_status_code
                            );
                        end; """, p_reclaim_id=reclaim_id,
                                            p_cm_header_id=result['header_id'],
                                            p_recent_updated_id=req['user_id'],
                                            x_status_code=status)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
                create_credit_note """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - create_credit_note(-)')
        return result

    def add_supplier_reclaim(self, data):
        """Reclaim to supplier by R&D team"""
        logger.addinfo('@ models - reclaim - add_supplier_reclaim(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                vendor_reclaim_id = conn.cursor.var(cx_Oracle.NUMBER)
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                begin
                    qpex_reclaim_pkg.insert_reclaim_supplier(
                    :x_reclaim_vendor_id,
                    :p_reclaim_id,
                    :p_vendor_id,
                    :p_internal_comments,
                    :p_supplier_comments,
                    :p_item_code,
                    :p_qty,
                    :p_batch_number,
                    :p_is_reported,
                    :p_status,
                    :p_org_id,
                    :p_created_id,
                    :x_status_code
                    );
                end; """, x_reclaim_vendor_id=vendor_reclaim_id,
                                    p_reclaim_id=data['linked_customer_claim_id'],
                                    p_vendor_id=data['vendor_id'],
                                    p_internal_comments=data['internal_comments'],
                                    p_supplier_comments=data['supplier_comments'],
                                    p_item_code=data['item_code'],
                                    p_qty=data['qty'],
                                    p_batch_number=data['batch_number'],
                                    p_is_reported=data['is_reported'],
                                    p_status=data['status'],
                                    p_org_id=data['org_id'],
                                    p_created_id=data['created_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    attachment_status = 'SUCCESS'
                    if len(data['attachments']) > 0:
                        status = self.add_attachment(data['attachments'],
                                                     int(vendor_reclaim_id.getvalue()),
                                                     'supplier', data['created_id'])
                        if status['status'] != 0:
                            attachment_status = 'Failed'
                    if attachment_status == 'SUCCESS':
                        result['status'] = Status.OK.value
                        result['msg'] = 'Reclaim request accepted'
                        result['reclaim_vendor_id'] = int(vendor_reclaim_id.getvalue())
                    else:
                        result['status'] = Status.ERROR.value
                        result['msg'] = 'Reclaim request created, but failed to add attachments'
                        result['reclaim_vendor_id'] = int(vendor_reclaim_id.getvalue())
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to created Reclaim request'
                    result['reclaim_vendor_id'] = -1
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
              add_supplier_reclaim """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - add_supplier_reclaim(+)')
        return result

    @staticmethod
    def update_supplier_reclaim(data):
        """updating an existing supplier reclaim raised"""
        logger.addinfo('@ models - reclaim - update_supplier_reclaim(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                begin
                    qpex_reclaim_pkg.update_reclaim_supplier(
                    :p_reclaim_vendor_id,
                    :p_vendor_id,
                    :p_internal_comments,
                    :p_supplier_comments,
                    :p_item_code,
                    :p_qty,
                    :p_batch_number,
                    :p_is_reported,
                    :p_status,
                    :p_recent_updated_id,
                    :x_status_code
                    );
                end; """, p_reclaim_vendor_id=data['reclaim_vendor_id'],
                                    p_vendor_id=data['vendor_id'],
                                    p_internal_comments=data['internal_comments'],
                                    p_supplier_comments=data['supplier_comments'],
                                    p_item_code=data['item_code'],
                                    p_qty=data['qty'],
                                    p_batch_number=data['batch_number'],
                                    p_is_reported=data['is_reported'],
                                    p_status=data['status'],
                                    p_recent_updated_id=data['recent_updated_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    result['status'] = Status.OK.value
                    result['msg'] = 'Reclaim request updated successfully'
                    result['reclaim_vendor_id'] = data['reclaim_vendor_id']
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to update reclaim request'
                    result['reclaim_vendor_id'] = -1
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
              update_supplier_reclaim """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - update_supplier_reclaim(+)')
        return result

    @staticmethod
    def delete_supplier_request(reclaim_id):
        logger.addinfo('@ models - reclaim - delete_supplier_request(+)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                result = {}
                conn.cursor.execute("""
                begin
                    qpex_reclaim_pkg.delete_reclaim_supplier(:p_reclaim_vendor_id,
                    :x_status_code
                    );
                end; """, p_reclaim_vendor_id=reclaim_id,
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    result['status'] = 0
                    result['msg'] = 'Request deleted Successfully'
                    result['reclaim_vendor_id'] = reclaim_id
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to delete Request'
                    result['reclaim_vendor_id'] = reclaim_id
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - reclaim -
                             delete_supplier_request """ + str(e))
            raise e
        logger.addinfo('models - reclaim - delete_supplier_request(-)')
        return result

    @staticmethod
    def add_attachment(attachments, reference_id, reference_type,
                       created_id):
        logger.addinfo('@ models - reclaim - add_attachment(-)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
                file_id = conn.cursor.var(cx_Oracle.NUMBER)
                status_codes = []
                result = {}
                for attachment in attachments:
                    conn.cursor.execute("""
                                        begin
                                            qpex_reclaim_pkg.add_attachment(
                                        :x_file_id,
                                        :p_reference_id,
                                        :p_reference_type,
                                        :p_file_name,
                                        :p_file_type,
                                        :p_file_content,
                                        :p_created_id,
                                        :x_status_code
                                            );
                                        end; """, x_file_id=file_id,
                                        p_reference_id=reference_id,
                                        p_reference_type=reference_type,
                                        p_file_name=attachment['file_name'],
                                        p_file_type=attachment['file_type'],
                                        p_file_content=attachment['file_content'],
                                        p_created_id=created_id,
                                        x_status_code=status_code)
                    status = status_code.getvalue()
                    if status != 'SUCCESS':
                        status_codes.append({'file_name': attachment['file_name'],
                                             'error': status})
                if len(status_codes) > 0:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to add attachment'
                else:
                    result['status'] = Status.OK.value
                    result['file_id'] = int(file_id.getvalue())
                    result['msg'] = 'Attachment added successfully'
                result['failed_attachments'] = status_codes
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
              add_attachment """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - add_attachment(+)')
        return result

    @staticmethod
    def delete_attachments(attachment_id):
        logger.addinfo('@ models - reclaim - delete_attachments(-)')
        try:
            with OracleConnectionManager() as conn:
                result = {}
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                                    begin
                                        qpex_reclaim_pkg.delete_attachment(
                                    :p_file_id,
                                    :x_status_code
                                        );
                                    end; """, p_file_id=attachment_id,
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    result['status'] = Status.ERROR.value
                    result['failed_attachments'] = attachment_id
                else:
                    result['status'] = Status.OK.value
                    result['failed_attachments'] = -1
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
              delete_attachments """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - delete_attachments(+)')
        return result

    @staticmethod
    def get_attachment_details(attachment_id):
        """to get attachment file content based on id"""
        logger.addinfo('@ models - reclaim - get_attachment_details(-)')
        try:
            common_utils_obj = CommonUtils()
            result = common_utils_obj.get_attachment_data('file_content',
                                                          'qpex_reclaimi_attachments',
                                                          'file_id',
                                                          attachment_id)
            final = {'file_content': result}
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - reclaim -
              get_attachment_details """ + str(e))
            raise e
        logger.addinfo('@ models - reclaim - get_attachment_details(+)')
        return final
