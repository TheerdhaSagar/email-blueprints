from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util


class Dashboard:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    #  used in  to get revenue details in given period
    def get_dashboard_data(p_org, p_userid, accnt_id):
        logger.addinfo('@ models - dashboard - get_dashboard_data(+)')
        sql_file = db_util.getSqlData()
        dashboard_data = {}
        if not accnt_id:
            user_details = Code_util.get_usertype(p_userid)
            ptype = user_details['type']
            ref_id = user_details['refid']
            revqry = ""
            oordrqry = ""
            sordrqry = ""
            pquoteqry = ""
            if ptype == 'salesrep':
                revqry = sql_file['sreprevtotal']
                oordrqry = sql_file['srepoordrstotal']
                sordrqry = sql_file['srepsordertotal']
                pquoteqry = sql_file['sreppquotetotal']
            elif ptype == 'manager':
                revqry = sql_file['mrevtotal']
                oordrqry = sql_file['moordrstotal']
                sordrqry = sql_file['msordertotal']
                pquoteqry = sql_file['mpquotetotal']
            else:
                revqry = sql_file['revenuetotal']
                oordrqry = sql_file['openorderstotal']
                sordrqry = sql_file['shippedorderstotal']
                pquoteqry = sql_file['pendingquotestotal']
        else:
            ptype = ''
            ref_id = ''
            revqry = sql_file['revenuetotal']
            oordrqry = sql_file['openorderstotal']
            sordrqry = sql_file['shippedorderstotal']
            pquoteqry = sql_file['pendingquotestotal']
        dashboard_data["revenue"] = Dashboard.get_val(revqry, "revenue",
                                                      p_org, ptype,
                                                      p_userid, ref_id,
                                                      accnt_id)
        dashboard_data["open_order"] = Dashboard.get_val(oordrqry, "open",
                                                         p_org, ptype,
                                                         p_userid, ref_id,
                                                         accnt_id)
        dashboard_data["shipped_order"] = Dashboard.get_val(sordrqry,
                                                            "shipped",
                                                            p_org, ptype,
                                                            p_userid, ref_id,
                                                            accnt_id)
        dashboard_data["pending_quotes"] = Dashboard.get_val(pquoteqry,
                                                             "quotes",
                                                             p_org, ptype,
                                                             p_userid, ref_id,
                                                             accnt_id)
        logger.addinfo('@ models - dashboard - get_dashboard_data(-)')
        return dashboard_data

    @staticmethod
    @db_util.langs("American")
    def get_val(qry, dtype, p_org, ptype, user_id, refid, accnt_id):
        logger.addinfo('@ models - dashboard - get_val(+)')
        con = None
        cur = None
        sql_file = db_util.getSqlData()
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            if ptype == 'b2b':
                cur.execute(qry, pcustaccnt_id=refid,
                            P_SALESREP_ID='', P_ORG_ID=p_org)
            elif ptype == 'salesrep':
                # cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
                salesid_qry = sql_file['salesrep_ids']
                cur.execute(salesid_qry, user_id=user_id)
                ids = cur.fetchall()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                query_temp = qry
                srep_query = query_temp % (',' . join([":" + str(i)
                                           for i in range(len(listk))]),
                                           p_org)
                cur.execute(srep_query, listk)
            elif ptype == 'manager':
                listk = []
                if dtype == 'quotes':
                    group_id_query = sql_file['group-ids-query']
                    cur.execute(group_id_query, p_user_id=refid)
                    ids = cur.fetchall()
                    logger.addinfo("group-ids-query qry in dashboard ends")
                    length = len(ids)
                    listk = []
                    for count in range(length):
                        id = ids[count][0]
                        listk.append(id)
                else:
                    group_name_query = sql_file['cust_manager_grpname']
                    cur.execute(group_name_query, p_user_id=refid,
                                p_org_id=p_org)
                    ids = cur.fetchall()
                    length = len(ids)
                    for count in range(length):
                        id = ids[count][0]
                        listk.append(id)
                query_temp = qry
                manager_query = query_temp % (',' . join([":" + str(i)
                                              for i in range(len(listk))]),
                                              p_org)
                cur.execute(manager_query, listk)
            else:
                cur.execute(qry, P_ORG_ID=p_org,
                            P_SALESREP_ID='', pcustaccnt_id=accnt_id)
        except Exception as error:
            logger.findaylog("""@ 129 EXCEPTION - models - dashboard -
                 get_val """ + str(error))
            raise error
        else:
            dashboard_data = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in cur:
                mydashboard = {}
                for index, fn in enumerate(fieldnames):
                    mydashboard[fn] = row[index]
                dashboard_data.append(mydashboard)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - dashboard - get_val(-)')
        return dashboard_data

    #  used in  to get shippedorder details in given period
    @staticmethod
    def get_shippedorder(p_org, p_userid, p_accntid):
        logger.addinfo('@ models - dashboard - get_shippedorder(+)')
        sql_file = db_util.getSqlData()
        dashboard_data = []
        if not p_accntid:
            user_details = Code_util.get_usertype(p_userid)
            ptype = user_details['type']
            ref_id = user_details['refid']
            qry = ""
            if ptype == 'salesrep':
                qry = sql_file['shipped_sales_orders']
            elif ptype == 'manager':
                qry = sql_file['mshipped_orders']
            else:
                qry = sql_file['shipped_orders']
            dashboard_data = Dashboard.get_val(qry, "shipped", p_org, ptype,
                                               p_userid, ref_id, p_accntid)
        else:
            dashboard_data = Dashboard.get_val(sql_file['shipped_orders'],
                                               "shipped",
                                               p_org, '', '', '', p_accntid)
        logger.addinfo('@ models - dashboard - get_shippedorder(-)')
        return dashboard_data

    @staticmethod
    #  used in  to get openorder details in given period
    def get_openorder(p_org, p_userid, p_accntid):
        logger.addinfo('@ models - dashboard - get_openorder(+)')
        sql_file = db_util.getSqlData()
        dashboard_data = []
        if not p_accntid:
            user_details = Code_util.get_usertype(p_userid)
            ptype = user_details['type']
            ref_id = user_details['refid']
            qry = ""
            if ptype == 'salesrep':
                qry = sql_file['open_sales_orders']
            elif ptype == 'manager':
                qry = sql_file['mopen_orders']
            else:
                qry = sql_file['open_orders']
            dashboard_data = Dashboard.get_val(qry, "open", p_org, ptype,
                                               p_userid, ref_id, p_accntid)
        else:
            dashboard_data = Dashboard.get_val(sql_file['open_orders'],
                                               "open",
                                               p_org, '', '', '', p_accntid)

        logger.addinfo('@ models - dashboard - get_openorder(-)')
        return dashboard_data
