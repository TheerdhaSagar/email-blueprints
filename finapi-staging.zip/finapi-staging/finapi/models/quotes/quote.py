import cx_Oracle
import ujson
import os
import requests
import base64
from datetime import datetime
from finapi.utils import db_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.constants import Status
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util
from finapi.utils.log_util import LogUtil
from finapi.models.products.products import Products


@LogUtil.class_module_logs('quotes')
class Quotes:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    # get quoteDetails based on user_id
    @staticmethod
    def show_headerandlines(puserid):
        try:
            if puserid:
                header_list = Quotes.show_header(puserid, None, None)
                headers_jdata = ujson.dumps(header_list)
                header_data = ujson.loads(headers_jdata)
                for index, value in enumerate(header_data):
                    if not index == 0:
                        lines_list = Quotes.show_lines(value['quote_header_id'])
                        value['lines'] = lines_list
            else:
                header_data = {'status': Status.ERROR.value, 'msg': 'Please enter valid data'}
                logger.findaylog('models - quotes - show_headerandlines' + header_data['msg'])
        except Exception as error:
            logger.findaylog("""@ Exception - models - quotes -
                                show_headerandlines""" + str(error))
            raise error
        return header_data

    # get quote_details by passing quote_header_id and language
    @staticmethod
    @db_util.langs("American")
    def quoteby_id(pheaderid, plang, org_id):
        connection = None
        cursor = None
        header_vals = []
        lines_list = []
        sql_file = db_util.getSqlData()
        try:
            if not pheaderid:
                return {'status': Status.ERROR.value, 'msg': "Please enter valid data"}
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['quote_submmitted_query']
            query = query.format(salesrep_user_id=Quotes.get_salesrep_user_id_query())
            cursor.execute(query, pheader_id=pheaderid, pstatus_id=None,
                           p_org_id=None, sales_rep_id=None, cust_acc_id=None)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 quoteby_id """ + str(error))
            raise error
        else:
            # set print language based on the database
            # get line details of a particular quote
            lines_list = Quotes.show_lines(pheaderid, plang, org_id)
            # iterate through filed names and collects the data
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            myquoted = Code_util.get_fieldtype(fieldnames, field_type)
            header_vals.append(myquoted)
            for row in cursor:
                quote_header = {}
                for index, fn in enumerate(fieldnames):
                    quote_header[fn] = row[index]
                # adding lines details here
                quote_header['lines'] = lines_list
                header_vals.append(quote_header)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return header_vals

    # get only header details based on quote header id
    @staticmethod
    @db_util.langs("American")
    def quoteheaderby_id(pheaderid):
        connection = None
        cursor = None
        header_vals = []
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['quote_header_id_query']
            query = query.format(salesrep_user_id=Quotes.get_salesrep_user_id_query())
            cursor.execute(query, pheader_id=pheaderid, pstatus_id=None,
                           sales_rep_id=None, cust_acc_id=None, p_org_id=None)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 quoteheaderby_id """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            myquoted = Code_util.get_fieldtype(fieldnames, field_type)
            header_vals.append(myquoted)
            for row in cursor:
                quote_header = {}
                for index, fn in enumerate(fieldnames):
                    quote_header[fn] = row[index]
                header_vals.append(quote_header)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return header_vals

    # get the quote details based on status
    @staticmethod
    @db_util.langs("American")
    def show_header(puserid, status_id, org_id):
        connection = None
        cursor = None
        refid = ""
        ptype = ""
        try:
            if not puserid:
                return {'status': Status.ERROR.value, 'msg': 'Please enter valid data'}
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = ''
            if status_id == str(29):
                query = sql_file['quote_submmitted_query']
            else:
                query = sql_file['quote_headers_query']
            salesrep_user_id_query = Quotes.get_salesrep_user_id_query()
            query = query.format(salesrep_user_id=salesrep_user_id_query)

            user_type = Code_util.get_usertype(puserid)
            ptype = user_type['type']
            # p_type means user_type
            refid = user_type['refid']
            # If status value is null the we need to give only draft quotes
            if not status_id:
                status_id = 4
            if ptype == 'b2b':
                # If logged in user is b2b
                cursor.execute(query, cust_acc_id=refid,
                               sales_rep_id='', pheader_id='',
                               pstatus_id=status_id, p_org_id=org_id)
            elif ptype == 'salesrep':
                # If logged in user is salesrep
                # cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
                salesid_qry = sql_file['salesrep_ids']
                cursor.execute(salesid_qry, user_id=puserid)
                ids = cursor.fetchall()
                length = len(ids)
                listk = []
                # generate dynamic query for large data --- "in"
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                query_temp = ''
                if status_id == str(29):
                    query_temp = sql_file['quotes_submitted_srep_qry']
                else:
                    query_temp = sql_file['quotes_srep_qry']
                query_temp = query_temp.format(salesrep_user_id=salesrep_user_id_query)
                hdr_query = query_temp % (',' . join([":" + str(i)
                                          for i in range(len(listk))]),
                                          status_id, org_id)
                cursor.execute(hdr_query, listk)
            elif ptype == 'manager':
                # If logged in user is manager
                group_id_query = sql_file['group-ids-query']
                cursor.execute(group_id_query, p_user_id=refid)
                ids = cursor.fetchall()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                query_temp = ''
                if status_id == str(29):
                    query_temp = sql_file['manager-submitted-quote-query']
                else:
                    query_temp = sql_file['manager-quote-headers-query']
                query_temp = query_temp.format(salesrep_user_id=salesrep_user_id_query)
                manager_query = query_temp % (',' . join([":" + str(i)
                                              for i in range(len(listk))]),
                                              status_id, org_id)
                cursor.execute(manager_query, listk)
            else:
                # If logged in user is admin or super user
                cursor.execute(query, sales_rep_id=None, cust_acc_id=None,
                               pheader_id='', pstatus_id=status_id,
                               p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 show_header """ + str(error))
            raise error
        else:
            quote_headers = []
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            myquoted = Code_util.get_fieldtype(fieldnames, field_type)
            quote_headers.append(myquoted)
            for row in cursor:
                quote_header = {}
                for index, fn in enumerate(fieldnames):
                    quote_header[fn] = row[index]
                quote_headers.append(quote_header)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return quote_headers

    # getLine Details of a quote
    @staticmethod
    def show_lines(refid, plang, porg):
        if plang == "IT":
            plang = "I"
        elif plang == "DE":
            plang = "D"
        elif plang == "FR":
            plang = "F"
        else:
            plang = "US"
        # ref_id is nothing but quote_header_id
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['quote_lines_query']
            org = None
            if porg:
                org = porg
            cursor.execute(query, quote_header_id=refid, p_lang=plang,
                           p_org=org)
            # get all lines information by passing quote_header_id
            # and langugae
            quote_lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            myquoted = Code_util.get_fieldtype(fieldnames, field_type)
            quote_lines.append(myquoted)
            for row in cursor:
                quote_line = {}
                for index, fn in enumerate(fieldnames):
                    quote_line[fn] = row[index]
                quote_lines.append(quote_line)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 show_lines """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return quote_lines

    # insert quoteHeader
    @staticmethod
    def save_header(connection, p_quote_headers, header_id):
        # insert header in to staging table and then call
        # create quote package
        cursor = None
        try:
            cursor = connection.cursor()
            row_data = []
            sql_data = '''insert into QPEX_QUOTE_HDR_STAGING (
                QUOTE_HEADER_ID,QUOTE_NUMBER,'''
            for quote_header in p_quote_headers:
                my_data = []
                for key, value in quote_header.items():
                    my_data.append(value)
                    my_new_tuple = tuple(my_data)
                row_data.append(my_new_tuple)
            for key, value in quote_header.items():
                sql_data += str(key)
                sql_data += ','
            sql_data += " QUOTE_STATUS_ID,QUOTE_VERSION)\
                    VALUES ( " + header_id + "," + header_id + ","
            sql_args = ""
            for idx, key in enumerate(quote_header.items()):
                sql_args += ":"+str(idx) + ","
            sql_data += sql_args + " 4,1)"
            # while creating quote quote_status_id=4 and quote_version=1 always
            cursor.executemany(sql_data, row_data)
            connection.commit()
            return_value = cursor.var(cx_Oracle.STRING)
            error_msg = cursor.var(cx_Oracle.STRING)
            # calling create quote package by passing quote_header_id
            cursor.execute("""
            begin
              :retval := qpex_quotes_pub_pkg.create_quote(:p_quote_header_id,
              :p_error_msg);
            end;""", p_quote_header_id=header_id, p_error_msg=error_msg,
                           retval=return_value)
            returnval = {}
            # if get reference value as 'S' then error message will
            # quote_header_id
            if return_value.getvalue() == 'S':
                returnval['msg'] = "Success"
                returnval['header_id'] = error_msg.getvalue()
                Quotes.send_dtc_approval_mail(int(error_msg.getvalue()), approver_id=None,
                                              is_first_mail=True)
            else:
                returnval['msg'] = error_msg.getvalue()
                returnval['header_id'] = ""
                logger.findaylog(('models - Package error create_quote - ' + str(returnval['msg']) + ' - {}').format({
                    'p_quote_headers': p_quote_headers,
                    'header_id': header_id}))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 save_header """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
        return returnval

    # add lines to a specific quote
    @staticmethod
    def add_lines(p_quote_lines, header_id):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['quote_line_sequence']
            # get the quote_lines sequence
            data = cursor.execute(query).fetchone()
            line_id = str(data[0])
            data = []
            # insert quote_lines data
            sql_data = 'insert into QPEX_QUOTE_LINES_STAGING (QUOTE_LINE_ID, '
            for quote_line in p_quote_lines:
                my_data = []
                for key, value in quote_line.__dict__.items():
                    my_data.append(value)
                    new_record = tuple(my_data)
                data.append(new_record)
            for key, value in quote_line.__dict__.items():
                sql_data += str(key)
                sql_data += ','
            sql_data += " STATUS)\
                    VALUES ( " + line_id + ","
            sql_args = ""
            for idx, key in enumerate(quote_line.__dict__.items()):
                sql_args += ":"+str(idx) + ","
            sql_data += sql_args + " ' ')"
            cursor.executemany(sql_data, data)
            connection.commit()
            error_msg = cursor.var(cx_Oracle.STRING)
            # calling add lines to the requested quote_header_id
            cursor.execute("""
            declare
            l_status VARCHAR2(30);
            begin
             l_status := qpex_quotes_pub_pkg.add_quote_lines(
             :p_quote_header_id,:p_error_msg);
             IF (l_status = 'S') THEN
                 commit;
             ELSE
                 rollback;
             END IF;
            end;""", p_quote_header_id=header_id, p_error_msg=error_msg)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 add_lines """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        if error_msg.getvalue():
            logger.findaylog(('models - Package Error add_quote_lines - ' + str(error_msg.getvalue()) + '- {}').format({
                'p_quote_lines': p_quote_lines, 'header_id': header_id}))
            return error_msg.getvalue()
        return "success"

    # insert quoteLines
    @staticmethod
    def save_lines(p_quote_lineslist, p_quote_headers, header_id):
        # here save lines is same as add_lines but here
        # we add lines at the creating quote it self
        connection = None
        cursor = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            for index, quote_line in enumerate(p_quote_lineslist):
                quote_line['QUOTE_LINE_ID'] = index + 1
                quote_line['QUOTE_HEADER_ID'] = int(header_id)
                values = ""
                values = tuple(val for key, val in quote_line.items())
                row_list.append(values)
            if p_quote_lineslist:
                dict_val = p_quote_lineslist[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            sql = 'insert into qpex_quote_lines_staging %s values %s' % (
                fieldname_strng, paramater_strng)
            cursor.executemany(sql, row_list)
            result = Quotes.save_header(connection, p_quote_headers, header_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 save_lines """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return result

    # generate HeaderId
    @staticmethod
    def header_id():
        # get quote_header_id from squence
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['quote_hdr_sequence']
            data = cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 header_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return header_id

    # create duplicateQuote by passing quoteHeaderId
    @staticmethod
    def duplicate_quote(refid):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            error_msg = cursor.var(cx_Oracle.STRING)
            # calling duplicate quote package by passing quote_header_id
            cursor.execute("""
            declare
            l_status VARCHAR2(30);
            begin
              l_status := apps.qpex_quotes_pub_pkg.copy_quote(
              :p_quote_header_id,
              :p_error_msg);
              IF (l_status = 'S') THEN
                  commit;
              ELSE
                  rollback;
              END IF;
            end; """, p_quote_header_id=refid, p_error_msg=error_msg)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 duplicate_quote """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        # If error occurs then copy quote failed
        if error_msg.getvalue():
            logger.findaylog(('models - duplicate_quote - ' +
                             error_msg.getvalue() + ' - {}').format({'refid': refid}))
            logger.findaylog('models - Package Error copy_quote - ' + str(error_msg.getvalue()))
            return error_msg.getvalue()
        return 'success'

    # delete lines from a quote
    @staticmethod
    def delete_lines(line_ids):
        # line_ids are nothing but quote_line_ids
        connection = None
        cursor = None
        try:
            if not len(line_ids):
                logger.findaylog('models - quotes - delete_lines - Please enter valid data')
                return 'Please enter valid data'
            connection = db_util.get_connection()
            cursor = connection.cursor()
            error_msg = cursor.var(cx_Oracle.STRING)
            lines_var = cursor.arrayvar(cx_Oracle.NUMBER, line_ids)
            # convert line_ids to arrayvar and call delete lines
            # package
            cursor.execute("""
            declare\
            l_status VARCHAR2(30);\
            type dummy_jtf_number_table_t is table of number \
            index by binary_integer;\
            l_dummy_jtf dummy_jtf_number_table_t:= :p_lines;\
            l_jtf jtf_number_table:=jtf_number_table(null);\
            l_msg varchar2(1000);\
            begin\
            l_jtf.extend(l_dummy_jtf.count);\
            FOR i in 1.. l_dummy_jtf.count LOOP\
              l_jtf(i) := l_dummy_jtf(i);\
             END LOOP;\
            l_status := qpex_quotes_pub_pkg.delete_quote_lines(l_jtf,
            :p_error_msg);\
            IF (l_status = 'S') THEN\
               commit;\
            ELSE\
               rollback;\
            END IF;\
            end;""", p_lines=lines_var, p_error_msg=error_msg)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 delete_lines """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        # If error occurs then delete lines failed
        if error_msg.getvalue():
            logger.findaylog('models - Package Error delete_quote_lines - ' +
                             str(error_msg.getvalue()))
            return 'Failed to delete lines'
        else:
            return "success"

    # delete quote by passing header_id
    @staticmethod
    def delete(header_id):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            msg = cursor.var(cx_Oracle.STRING)
            # calling delete quotes package
            cursor.execute("""
            declare\
            l_status VARCHAR2(30);\
            begin\
            l_status :=qpex_quotes_pub_pkg.delete_quote(:p_quote_header_id,
            :p_error_msg);
            end;""", p_quote_header_id=header_id, p_error_msg=msg)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 delete """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        # If error occurs then delete quote failed
        if msg.getvalue():
            logger.findaylog('Package Error delete_quote - ' + str(msg.getvalue()))
            return msg.getvalue()
        return "success"

    # validate Quote
    @staticmethod
    def validate(quote_header_id, org_id):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            # get the credit check sequence
            query = sql_file['almo_credit_check_sequence']
            data = cursor.execute(query).fetchone()
            line_id = str(data[0])
            id_line = int(data[0])
            validate = ["Validation", "PriceCheck", "CommrOutstandingHdr",
                        "CreditCheck", "Risk", "CommrOutstanding"]
            details = []
            retvalvar = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
                begin
                   qpex_quotes_pub_pkg.set_org_context(:p_org_id);
                end;""", p_org_id=org_id)
            # call validating quote package from sequnce
            cursor.execute("""
            begin
              :retval := almo_validate_order_pks.almo_qot_validation(
              :p_sequence, :p_quote_header_id);
              exception
              when others then
              :retval := 'Error: ' || substrb(sqlerrm,1,180);
            end;""", p_sequence=id_line, p_quote_header_id=quote_header_id,
                           retval=retvalvar)
            check_atp_details = Quotes.check_atp(quote_header_id, org_id)
            status_var = 'T'
            for i in check_atp_details:
                if i["atp_quantity_ordered"] > i["atp_request_date_quantity"]:
                    status_var = 'F'
                    break
            validation = sql_file['Validation_details_query']
            cursor.execute(validation, p_id=id_line)
            v_data = cursor.fetchall()
            # validation details
            validation_details = []
            v_fieldnames = [a[0].lower() for a in cursor.description]
            # credit check
            check = "NC"
            for v_row in v_data:
                validation_details_line = {}
                for v_index, v_fn in enumerate(v_fieldnames):
                    if v_fn == "status" and check == "NC":
                        validation_details_line[v_fn] = status_var
                        check = "C"
                    else:
                        validation_details_line[v_fn] = v_row[v_index]
                validation_details.append(validation_details_line)
            details.append(validation_details)
            price_check = sql_file['PriceCheck_details_query']
            cursor.execute(price_check, p_id=line_id)
            p_data = cursor.fetchall()
            # price check details
            price_check_details = []
            p_fieldnames = [a[0].lower() for a in cursor.description]
            for p_row in p_data:
                price_check_deatils_line = {}
                for p_index, p_fn in enumerate(p_fieldnames):
                    price_check_deatils_line[p_fn] = p_row[p_index]
                price_check_details.append(price_check_deatils_line)
            details.append(price_check_details)
            # credit check details
            credit_check = sql_file['CreditCheck_details_query']
            cursor.execute(credit_check, p_id=line_id)
            cc_data = cursor.fetchall()
            credit_check_deatils = []
            cc_fieldnames = [a[0].lower() for a in cursor.description]
            for cc_row in cc_data:
                credit_check_line = {}
                for cc_index, cc_fn in enumerate(cc_fieldnames):
                    credit_check_line[cc_fn] = cc_row[cc_index]
                credit_check_deatils.append(credit_check_line)
            details.append(credit_check_deatils)
            query = """SELECT
            nvl2(aspa.tax_currency_code,aspa.tax_currency_code, null)
            tax_currency_code,
            apps.almo_validate_order_pks.get_fido(aqha.cust_account_id) | |
             ' ' | |
            nvl2(aspa.tax_currency_code,aspa.tax_currency_code,null)
            credit_line_fido,
            apps.almo_validate_order_pks.get_tot_esposizione( % d) | | ' ' | |
            nvl2(aspa.tax_currency_code, aspa.tax_currency_code, null)
            total_exposure,
            nvl2(rc.attribute6, rc.attribute6, null) insurance_code,
            nvl2(rc.attribute2, rc.attribute6, null) visura_code
            FROM apps.ar_system_parameters_all aspa,
            apps.aso_quote_headers_all aqha,
            apps.hz_cust_accounts rc WHERE aspa.org_id = aqha.org_id AND
            aqha.cust_account_id = rc.cust_account_id
            AND aqha.QUOTE_HEADER_ID = %s""" % (id_line, quote_header_id)
            cursor.execute(query)
            # commr_outstanding_hdr_deatils
            cosh_data = cursor.fetchall()
            commr_outstanding_hdr_deatils = []
            cosh_fieldnames = [a[0].lower() for a in cursor.description]
            for cosh_row in cosh_data:
                commr_outstanding_hdr_line = {}
                for cosh_index, cosh_fn in enumerate(cosh_fieldnames):
                    commr_outstanding_hdr_line[cosh_fn] = cosh_row[cosh_index]
                commr_outstanding_hdr_deatils.append(commr_outstanding_hdr_line)
            details.append(commr_outstanding_hdr_deatils)
            # risk details
            risk = sql_file['Risk_details_query']
            cursor.execute(risk, p_id=line_id)
            r_data = cursor.fetchall()
            risk_deatils = []
            r_fieldnames = [a[0].lower() for a in cursor.description]
            for r_row in r_data:
                risk_line = {}
                for r_index, r_fn in enumerate(r_fieldnames):
                    risk_line[r_fn] = r_row[r_index]
                risk_deatils.append(risk_line)
            details.append(risk_deatils)
            # CommrOutstanding_details
            commr_out_standing = sql_file['CommrOutstanding_details_query']
            cursor.execute(commr_out_standing, p_id=line_id)
            cos_data = cursor.fetchall()
            commr_out_standing_details = []
            cos_fieldnames = [a[0].lower() for a in cursor.description]
            # combine all data
            for cos_row in cos_data:
                commr_out_standing_line = {}
                for cos_index, cos_fn in enumerate(cos_fieldnames):
                    commr_out_standing_line[cos_fn] = cos_row[cos_index]
                commr_out_standing_details.append(commr_out_standing_line)
            details.append(commr_out_standing_details)
            my_list = []
            rangeof = len(validate)
            for i in range(rangeof):
                dicti = {}
                dicti['name'] = validate[i]
                dicti['details'] = details[i]
                my_list.append(dicti)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 validate """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        # return validates list
        return my_list

    # checkATP by providing quoteHeaderId and organizationId
    @staticmethod
    def check_atp(quote_header_id, org_id):
        connection = db_util.get_connection()
        cursor = connection.cursor()
        data = []
        call_id = cursor.var(cx_Oracle.NUMBER)
        status = cursor.var(cx_Oracle.STRING)
        try:
            cursor.execute("""
            begin
              qpex_quotes_pub_pkg.checkAtp(
              :p_quote_header_id, :p_org_id, :p_call_id, :p_status);
            end;""", p_quote_header_id=quote_header_id, p_org_id=org_id,
                           p_call_id=call_id, p_status=status)
            sql_file = db_util.getSqlData()
            query = sql_file['check_query']
            cursor.execute(query, p_call_id=call_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 check_atp """ + str(error))
            raise error
        fieldnames = [a[0].lower() for a in cursor.description]
        for row in cursor:
            result = {}
            for index, field in enumerate(fieldnames):
                result[field] = row[index]
            data.append(result)
        try:
            atp_delete = sql_file['atp_delete']
            cursor.execute(atp_delete, p_call_id=call_id)
        except Exception as error:
            logger.findaylog('''Exception in while executing atp_delete
                           in models''' + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return data

    # submit quote by passing quote_header_id and org_id
    @staticmethod
    def submit_quote(quote_header_id, org_id):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            result = Quotes.validate(quote_header_id, org_id)
            validate_quote = ujson.dumps(result[0])
            data = ujson.loads(validate_quote)
            listw = data['details']
            listk = []
            status = ""
            k = 0
            for x in listw:
                listk.append(x["status"])
            for i in range(5):
                if listk[i] == 'T':
                    k = k + 1
            # if validated then k = 5
            if k == 5:
                retvalvar = cursor.var(cx_Oracle.STRING)
                error_msg = cursor.var(cx_Oracle.STRING)
                # convert status and then calling package
                validate_update = sql_file['validata_update']
                cursor.execute(validate_update,
                               p_quote_header_id=quote_header_id)
                cursor.execute("""
                declare
                begin
                :retval := qpex_quotes_pub_pkg.submit_quote(
                :p_quote_header_id,
                :p_error_msg);
                end;""", p_quote_header_id=quote_header_id,
                               p_error_msg=error_msg,
                               retval=retvalvar)
                if retvalvar.getvalue() == 'S':
                    status = error_msg.getvalue()
                else:
                    # if quote submisssion failed again convet status
                    draft_update = sql_file['draft_update']
                    cursor.execute(draft_update,
                                   p_quote_header_id=quote_header_id)
                    status = "fails"
            else:
                status = "fails"
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 submit_quote """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return status

    # update quoteHeader
    @staticmethod
    def update_header(connection, p_quote_headers, header_id):
        cursor = None
        status = ""
        try:
            cursor = connection.cursor()
            row_data = []
            # insert data in to staging table and then call package
            sql_data = '''insert into QPEX_QUOTE_HDR_STAGING ('''
            for quote_header in p_quote_headers:
                my_data = []
                for key, value in quote_header.__dict__.items():
                    my_data.append(value)
                    my_new_tuple = tuple(my_data)
                row_data.append(my_new_tuple)
            for key, value in quote_header.__dict__.items():
                sql_data += str(key)
                sql_data += ','
            sql_data += " STATUS) VALUES ( "
            sql_args = ""
            for idx, key in enumerate(quote_header.__dict__.items()):
                sql_args += ":"+str(idx) + ","
            sql_data += sql_args + " '')"
            cursor.executemany(sql_data, row_data)
            connection.commit()
            return_value = cursor.var(cx_Oracle.STRING)
            error_msg = cursor.var(cx_Oracle.STRING)
            # calling package starts here
            cursor.execute("""
            begin
              :retval := qpex_quotes_pub_pkg.update_quote(:p_quote_header_id,
              :p_error_msg);
            end;""", p_quote_header_id=header_id, p_error_msg=error_msg,
                           retval=return_value)
            # if error message have value the update quote failed
            if error_msg.getvalue():
                status = error_msg.getvalue()
                logger.findaylog('models - Package Error update_quote - ' +
                                 str(error_msg.getvalue()))
            else:
                status = 'success'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 update_header """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
        return status

    # update quoteLines
    @staticmethod
    def update_lines(p_quote_lineslist, p_quote_headers, header_id):
        # same as saving lines but here we have both new lines
        # and old lines major difference is quote_header_id
        connection = None
        cursor = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            row_list = []
            fieldname_strng = ""
            paramater_strng = ""
            inventory_id = []
            # store data in a staging table and then call package
            for index, quote_line in enumerate(p_quote_lineslist):
                if 'quote_line_id' not in quote_line \
                        or not quote_line['quote_line_id']:
                    quote_line['quote_line_id'] = str(index + 1)
                values = tuple(str(val) for key, val in quote_line.items())
                ucons = str(quote_line['quote_header_id']) + ',' + str(
                    quote_line['inventory_item_id']) + ',' + str(
                    quote_line['uom_code'])
                if ucons not in inventory_id:
                    row_list.append(values)
                inventory_id.append(ucons)
            if p_quote_lineslist:
                dict_val = p_quote_lineslist[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key) + ','
                    paramater_strng += ":" + str(indx_value) + ','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            cursor.prepare("""insert into
            QPEX_QUOTE_LINES_STAGING """ + fieldname_strng+"""
            values """ + paramater_strng)
            cursor.executemany(None, row_list)
            result = Quotes.update_header(connection, p_quote_headers, header_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 update_lines """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        return result

    # apply discount
    @staticmethod
    def applydiscount(discount, segment_ids_list, line_ids_list, org_id):
        retvalue = applydisc(discount, segment_ids_list, line_ids_list, org_id)
        return retvalue

    # apply extra discount
    @staticmethod
    def extradiscount(discount, line_ids_list):
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            msg = ""
            rmsg = cur.var(cx_Oracle.STRING)
            lines_var = cur.arrayvar(cx_Oracle.NUMBER,
                                     line_ids_list)
            cur.execute("""
                          declare\
                          l_status VARCHAR2(1000);\
                          type dummy_jtf_number_table_t is table of
                          number index by\
                          binary_integer;l_dummy_jtf
                          dummy_jtf_number_table_t:= :p_lines;\
                          l_jtf jtf_number_table:=jtf_number_table(
                          null);\
                          l_msg varchar2(1000);\
                          begin\
                          l_jtf.extend(l_dummy_jtf.count);\
                          FOR i in 1.. l_dummy_jtf.count LOOP
                          l_jtf(i) := l_dummy_jtf(i);\
                          END LOOP;\
                          l_status := qpex_quotes_pub_pkg
                          .apply_discount_for_lines2\
                          (l_jtf,:p_discount,:p_error_msg);\
                          IF (l_status = 'S') THEN\
                          commit;
                          ELSE\
                          rollback;\
                          END IF;\
                          end;""", p_lines=lines_var,
                        p_discount=discount, p_error_msg=rmsg)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 extradiscount """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        if not msg:
            final_msg = rmsg.getvalue()
            if rmsg.getvalue():
                logger.findaylog('models - quotes - extradiscount')
        else:
            final_msg = msg
        return final_msg

    # force submit quotes
    @staticmethod
    def force_submit(ids, user=None, user_id=None):
        # we can submit the quote without validate it
        connection = None
        cursor = None
        try:
            k = 0
            sql_file = db_util.getSqlData()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            error_msg = cursor.var(cx_Oracle.STRING)
            retvalvar = cursor.var(cx_Oracle.STRING)
            result = []
            order_ids = []
            for i in range(0, len(ids)):
                # iterate through ids and submit each quote
                validate_update = sql_file['validata_update']
                cursor.execute(validate_update, p_quote_header_id=ids[i])
                cursor.execute("""
                    declare
                    begin
                    :retval := qpex_quotes_pub_pkg.submit_quote(
                    :p_quote_header_id,
                    :p_error_msg);
                    end;""", p_quote_header_id=ids[i], p_error_msg=error_msg,
                               retval=retvalvar)
                value = retvalvar.getvalue()
                if value == 'S':
                    if user:
                        description = 'Quote force submitted by %s' % user
                        cursor.execute('''
                        begin
                            qpex_cruscott_logging_pkg.add_log(
                                :p_log_level,
                                :p_module,
                                :p_reference_id,
                                :p_action,
                                :p_description,
                                :p_user_id
                            );
                        end; ''', p_log_level='INFO',
                                       p_module='Quotes',
                                       p_reference_id=ids[i],
                                       p_action='Force Submit',
                                       p_description=description,
                                       p_user_id=user_id)
                    order_ids.append(error_msg.getvalue())
                    result.append(value)
                else:
                    draft_update = sql_file['draft_update']
                    cursor.execute(draft_update, p_quote_header_id=ids[i])
            if len(result) == len(ids):
                for i in range(0, len(ids)):
                    if result[i] == 'S':
                        k = k + 1
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 force_submit """ + str(error))
            raise error
        finally:
            cursor.close()
            if k == len(ids):
                connection.commit()
            db_util.release_connection(connection)
        if k == len(ids):
            return order_ids
        else:
            return "fails"

    @staticmethod
    def print_api(pheaderid, lang, org_id):
        if lang == "IT":
            lang = "I"
        elif lang == "DE":
            lang = "D"
        elif lang == "FR":
            lang = "F"
        else:
            lang = "US"
        quote_data = []
        connection = None
        cursor = None
        try:
            sql_file = db_util.getSqlData()
            quote_data.append(Quotes.qry_data(
                              sql_file['printquote1'], pheaderid))
            connection = db_util.get_connection()
            cursor = connection.cursor()
            lines_data = []
            query = sql_file['printquote2']
            cursor.execute(query, p_header_id=pheaderid, p_lang=lang)
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                quote_header = {}
                for index, fn in enumerate(fieldnames):
                    quote_header[fn] = row[index]
                lines_data.append(quote_header)
            quote_data.append(lines_data)
            quote_data.append(Quotes.qry_data(
                              sql_file['printquote3'], pheaderid))
            header_logo, footer_logo = Quotes.get_header_footer_logos(org_id)
            quote_data.append([{
                'header_logo': header_logo.decode('utf-8'),
                'footer_logo': footer_logo.decode('utf-8')
            }])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 print_api """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return quote_data

    @staticmethod
    def get_header_footer_logos(org_id):
        header_image = requests.get(CommonUtils.get_header_logo(org_id)).content
        image_base64 = base64.b64encode(header_image)
        header_base64 = b'data:image/png;base64,' + image_base64

        # get footer image base64
        footer_image = requests.get(
            'https://cdn.almonature.com/hubfs/pdf-footer/reports-footer.jpg').content
        footer_base64 = base64.b64encode(footer_image)
        footer_base64 = b'data:image/png;base64,' + footer_base64
        return header_base64, footer_base64

    # get the details of quote by passing query and header_id
    @staticmethod
    @db_util.langs("American")
    def qry_data(pquery, pheaderid):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            quote_data = []
            cursor.execute(pquery, p_header_id=pheaderid,)
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                quote_header = {}
                for index, fn in enumerate(fieldnames):
                    quote_header[fn] = row[index]
                quote_data.append(quote_header)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 qry_data """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return quote_data

    # managed discounts
    @staticmethod
    def managediscount(plineids_list, plistline_nolist,
                       pdiscount_list, preason_codelist, p_commentlist):
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            p_comment = ""
            p_comment = cur.var(cx_Oracle.STRING)
            # iterate through line_ids list and call package
            for key, value in enumerate(plineids_list):
                plineid_list = []
                plineid_list.append(value)
                plistline_no = plistline_nolist[key]
                pdiscount = pdiscount_list[key]
                p_comment = p_commentlist[key]
                preason_code = preason_codelist[key]
                emsg = cur.var(cx_Oracle.STRING)
                rmsg = cur.var(cx_Oracle.STRING)
                cur.execute("""
                  declare\
                  l_status VARCHAR2(1000);\
                  type dummy_jtf_number_table_t is table of
                  number index by\
                  binary_integer;l_dummy_jtf
                  dummy_jtf_number_table_t:= :lineids_var;\
                  l_jtf jtf_number_table:=jtf_number_table(
                  null);\
                  begin\
                  l_jtf.extend(l_dummy_jtf.count);\
                  FOR i in 1.. l_dummy_jtf.count LOOP
                  l_jtf(i) := l_dummy_jtf(i);\
                  END LOOP;\
                  :l_status := qpex_quotes_pub_pkg.modify_discount(l_jtf,
                  :p_list_line_no,
                  :p_discount,
                  :p_reason_code,
                  :p_comment,
                  :p_error_msg);
                  end;""", lineids_var=plineid_list,
                            p_list_line_no=plistline_no,
                            p_discount=pdiscount,
                            p_reason_code=preason_code,
                            p_comment=p_comment,
                            p_error_msg=emsg, l_status=rmsg)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 managediscount """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        if not emsg.getvalue():
            return {'status': Status.OK.value, 'msg': "Applied discount successfully"}
        logger.findaylog('models - Package Error modify_discount')
        return {'status': Status.ERROR.value, 'msg': emsg.getvalue()}

    # line_adjustment
    @staticmethod
    @db_util.langs("American")
    def line_adjmnt(pheaderid, plineid):
        connection = None
        cursor = None
        adj_vals = []
        sql_file = db_util.getSqlData()
        try:
            if pheaderid and plineid:
                connection = db_util.get_connection()
                cursor = connection.cursor()
                query = sql_file['line_adjmnts']
                cursor.execute(query, p_header_id=pheaderid, p_line_id=plineid)
                fieldnames = [a[0].lower() for a in cursor.description]
                for row in cursor:
                    adj_data = {}
                    for index, fn in enumerate(fieldnames):
                        if fn == 'last_update_date':
                            if row[index]:
                                adj_data[fn] = row[index].strftime('%d-%b-%Y')
                        else:
                            adj_data[fn] = row[index]
                    adj_vals.append(adj_data)
            else:
                adj_vals = {'status': Status.ERROR.value, 'msg': 'Please neter valid data'}
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 line_adjmnt """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return adj_vals

    # look up Data
    @staticmethod
    @db_util.langs("American")
    def lookup_data(p_ltype):
        connection = None
        cursor = None
        lookup_vals = []
        sql_file = db_util.getSqlData()
        try:
            if p_ltype:
                connection = db_util.get_connection()
                cursor = connection.cursor()
                query = sql_file['lookup_qry']
                cursor.execute(query, p_type=p_ltype)
                fieldnames = [a[0].lower() for a in cursor.description]
                for row in cursor:
                    lookupval = {}
                    for index, fn in enumerate(fieldnames):
                        lookupval[fn] = row[index]
                    lookup_vals.append(lookupval)
            else:
                lookup_vals = {'msg': 'Please enter valid data', 'status': Status.ERROR.value}
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 lookup_data """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return lookup_vals

    # pallets information
    @staticmethod
    @db_util.langs("American")
    def pallet_data(p_headerid):
        connection = None
        cursor = None
        pallet_val = ""
        sql_file = db_util.getSqlData()
        try:
            if not p_headerid:
                pallet_val = {'msg': 'Please enter valid data', 'status': Status.ERROR.value}
                logger.findaylog('models - pallet_data - quotes - please enter valid data')
            else:
                connection = db_util.get_connection()
                cursor = connection.cursor()
                query = sql_file['quote_pallets']
                cursor.execute(query, p_quote_header_id=p_headerid)
                fieldnames = [a[0].lower() for a in cursor.description]
                for row in cursor:
                    pallet_val = {}
                    for index, fn in enumerate(fieldnames):
                        pallet_val[fn] = row[index]
                if not pallet_val:
                    pallet_val = "data not found"
                    logger.findaylog(('models - pallet_data - ' + pallet_val + ' - {}').format({
                        'p_headerid': p_headerid}))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 pallet_data """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return pallet_val

    # get resoruce data for saleerep_id
    @staticmethod
    @db_util.langs("American")
    def getresource_data(psalesrepid):
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        resource_data = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['resource_id']
            cursor.execute(query, psales_rep=psalesrepid)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 getresource_data """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                resource_data = {}
                for index, fn in enumerate(fieldnames):
                    resource_data[fn] = row[index]
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return resource_data

    # quote_search based on the user type by passing condition_list
    @staticmethod
    @db_util.langs("American")
    def quotes_search(conditiondict):
        connection = None
        cursor = None
        ptype = ""
        sql_file = db_util.getSqlData()
        quote_datalst = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['quote_headers_search_query']
            puserid = conditiondict['user_id']
            user_type = Code_util.get_usertype(puserid)
            ptype = user_type['type']
            refid = user_type['refid']
            if ptype == 'b2b':
                # if B2b
                querye = Quotes.getqry(query, conditiondict)
                cursor.execute(querye, cust_acc_id=refid,
                               sales_rep_id='', pheader_id='')
            elif ptype == 'salesrep':
                # if Salesrep
                # cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
                salesid_qry = sql_file['salesrep_ids']
                cursor.execute(salesid_qry, user_id=puserid)
                ids = cursor.fetchall()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                tqry = sql_file['quotes_srep_search_qry']
                query_temp = tqry % (',' . join([":" + str(i)
                                     for i in range(len(listk))]))
                hdr_query = Quotes.getqry(query_temp, conditiondict)
                cursor.execute(hdr_query, listk)
            elif ptype == 'manager':
                # if Manager
                group_id_query = sql_file['group-ids-query']
                cursor.execute(group_id_query, p_user_id=refid)
                ids = cursor.fetchall()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                tqry = sql_file['manager-quote-headers-search-query']
                query_temp = tqry % (',' . join([":" + str(i)
                                     for i in range(len(listk))]))
                manager_query = Quotes.getqry(query_temp, conditiondict)
                cursor.execute(manager_query, listk)
            else:
                query_temp = Quotes.getqry(query, conditiondict)
                cursor.execute(query_temp, sales_rep_id=None, cust_acc_id=None,
                               pheader_id='')
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 quotes_search """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                quote_data = {}
                for index, fn in enumerate(fieldnames):
                    quote_data[fn] = row[index]
                quote_datalst.append(quote_data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return quote_datalst

    # build conditions
    @staticmethod
    def getqry(qry, conditiondict):
        del conditiondict['user_id']
        for key, value in conditiondict.items():
            if "party_name" == key:
                qry += " and "
                qry += " lower(BILL_CUSTOMER."
                qry += str(key)+")"+" like "+"lower('"+"%"+str(value)+"%"+"')"
            elif "quote_name" == key:
                qry += " and "
                qry += " lower(QuoteHeaderEO."
                qry += str(key)+")"+" like "+"lower('"+"%"+str(value)+"%"+"')"
            elif "quote_number" == key:
                qry += " and "
                qry += " QuoteHeaderEO."
                qry += str(key)+"="+"'"+str(value)+"'"
            elif "quote_status_id" == key:
                if value != -1:
                    qry += " and "
                    qry += " QuoteHeaderEO."
                    qry += str(key)+"="+"'"+str(value)+"'"
            elif "start_date" == key:
                qry += " and "
                st_date = "'"+conditiondict['start_date']+"'"
                en_date = "'"+conditiondict['end_date']+"'"
                qry += """trunc(QuoteHeaderEO.creation_date, 'dd'
                ) between to_date("""+st_date+""",'dd-MON-yyyy')
                and to_date("""+en_date+", 'dd-MON-yyyy')"
        qry += str(" ORDER BY QuoteHeaderEO.quote_header_id desc")
        return qry

    # get recent 5 quote details baesd on the user
    @staticmethod
    @db_util.langs("American")
    def show_recentheader(puserid, org_id, condition):
        connection = None
        cursor = None
        refid = ""
        ptype = ""
        try:
            if not puserid or not org_id:
                logger.findaylog('models - quotes - show_recentheader - Please enter valid data')
                return {'msg': 'Please enter valid data', 'status': Status.ERROR.value}
            connection = db_util.get_connection()
            cursor = connection.cursor()
            # cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            sql_file = db_util.getSqlData()
            query = sql_file['recent_quotes']               # query
            salesrep_user_id_query = Quotes.get_salesrep_user_id_query()
            query = query.format(salesrep_user_id=salesrep_user_id_query)
            query += condition
            user_type = Code_util.get_usertype(puserid)
            ptype = user_type['type']
            refid = user_type['refid']
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            if ptype == 'b2b':
                cursor.execute(query, cust_acc_id=refid,
                               sales_rep_id='', pheader_id='',
                               pstatus_id='', p_org_id=org_id)
            elif ptype == 'salesrep':
                salesid_qry = sql_file['salesrep_ids']
                cursor.execute(salesid_qry, user_id=puserid)
                ids = cursor.fetchall()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                query_temp = sql_file['recentquotes_srep_qry']
                query_temp = query_temp.format(salesrep_user_id=salesrep_user_id_query)
                query_temp += condition
                hdr_query = query_temp % (',' . join([":" + str(i)
                                          for i in range(len(listk))]),
                                          org_id)
                cursor.execute(hdr_query, listk)
            elif ptype == 'manager':
                group_id_query = sql_file['group-ids-query']
                cursor.execute(group_id_query, p_user_id=refid)
                ids = cursor.fetchall()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                query_temp = sql_file['manager_recentsalerep']
                query_temp = query_temp.format(salesrep_user_id=salesrep_user_id_query)
                query_temp += condition
                manager_query = query_temp % (',' . join([":" + str(i)
                                              for i in range(len(listk))]),
                                              org_id)
                cursor.execute(manager_query, listk)
            else:
                cursor.execute(query, sales_rep_id=None, cust_acc_id=None,
                               pheader_id='', pstatus_id='',
                               p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 show_recentheader """ + str(error))
            raise error
        else:
            quote_headers = []
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            myquoted = Code_util.get_fieldtype(fieldnames, field_type)
            quote_headers.append(myquoted)
            for row in cursor:
                quote_header = {}
                for index, fn in enumerate(fieldnames):
                    quote_header[fn] = row[index]
                quote_headers.append(quote_header)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return quote_headers

    @staticmethod
    def status_change(header_id, status_id):
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            if header_id and status_id:
                connection = db_util.get_connection()
                cursor = connection.cursor()
                query = sql_file['status_update']
                cursor.execute(query, p_status=status_id, p_header=header_id)
                result = {'status': Status.OK.value, 'msg': 'Quote re-opened successfully'}
            else:
                logger.findaylog('models - quotes - status_change - no header_id and status_id')
                result = {'status': Status.ERROR.value, 'msg': 'Please enter valid data'}
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 status_change """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        return result

    # apply extra discount
    @staticmethod
    def applyextradiscount(pdiscount, segment_ids_list, line_ids_list, req):
        rmsg = ''
        con = None
        cur = None
        try:
            discount_flow = req.get('discount_flow', 'N')
            apply_discount = False
            if discount_flow == 'Y':
                req['line_ids'] = line_ids_list
                result = Quotes.process_discount_flow(req)
                status = result.get('status', '')
                if status == 0:
                    lines = Quotes.show_lines(req['header_id'], None, str(req['org_id']))
                    lines = lines[1:]
                    for line in lines:
                        if line['quote_line_id'] in line_ids_list and line['discount_status'] == 'A':
                            apply_discount = True
                            break

            if discount_flow == 'Y' and not apply_discount:
                return result

            con = db_util.get_connection()
            cur = con.cursor()
            discount = []
            if len(pdiscount) == len(segment_ids_list):
                discount = pdiscount
            else:
                for i in range(len(segment_ids_list)):
                    discount.append(pdiscount[0])
            rmsg = cur.var(cx_Oracle.STRING)
            lines_var = cur.arrayvar(cx_Oracle.NUMBER, line_ids_list)
            discount_var = cur.arrayvar(cx_Oracle.NUMBER, discount)
            cur.execute("""
                       DECLARE
                       l_status VARCHAR2(1000);
                       type dummy_jtf_number_table_t
                       IS
                       TABLE OF NUMBER INDEX BY binary_integer;
                       l_dummy_jtf dummy_jtf_number_table_t:= :p_lines;
                       l_jtf jtf_number_table:=jtf_number_table( NULL);
                       l_msg VARCHAR2(1000);
                       type dummy_jtf_number_table_tdisc
                       IS
                       TABLE OF NUMBER INDEX BY binary_integer;
                       l_dummy_jtf_disc dummy_jtf_number_table_tdisc:= :p_disc;
                       l_jtf_disc jtf_number_table:=jtf_number_table( NULL);
                       l_msg VARCHAR2(1000);
                       BEGIN
                       l_jtf.extend(l_dummy_jtf.count);
                       FOR i IN 1.. l_dummy_jtf.count
                       LOOP
                       l_jtf(i) := l_dummy_jtf(i);
                       END LOOP;
                       l_jtf_disc.extend(l_dummy_jtf_disc.count);
                       FOR i IN 1.. l_dummy_jtf_disc.count
                       LOOP
                       l_jtf_disc(i) := l_dummy_jtf_disc(i);
                       END LOOP;
                       l_status := qpex_quotes_pub_pkg
                       .apply_discount_for_lines\
                       (l_jtf,l_jtf_disc,:p_error_msg);\
                       IF (l_status = 'S') THEN\
                       commit;\
                       ELSE\
                       rollback;\
                       END IF;\
                       end;""", p_lines=lines_var,
                        p_disc=discount_var, p_error_msg=rmsg)

            if discount_flow == 'Y':
                req['mail_type'] = 'S'
                req['approval_status'] = 'A'
                Quotes.send_discount_approval(req)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 applyextradiscount """ + str(error))
            raise error
        finally:
            if cur:
                cur.close()
                db_util.release_connection(con)
        if rmsg.getvalue():
            logger.findaylog('models - quotes - applyextradiscount')
        return rmsg.getvalue()

    # get order_details by passing header_id and language
    @staticmethod
    @db_util.langs("American")
    def order_details(pheaderid, plang):
        connection = None
        cursor = None
        header_vals = []
        lines_list = []
        try:
            sql_file = db_util.getSqlData()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['orders_header_query']
            cursor.execute(query, P_HEADER_ID=pheaderid)
        except Exception as error:
            logger.findaylog(('models - order_details - ' + str(error) + ' - {}').format({
                'pheaderid': pheaderid, 'plang': plang}))
            raise error
        else:
            # set language based on the database
            if plang == "IT":
                plang = "I"
            elif plang == "DE":
                plang = "D"
            elif plang == "FR":
                plang = "F"
            else:
                plang = "US"
            # get line details of a particular order
            lines_list = Quotes.order_lines(pheaderid, plang)
            # iterate through filed names and collects the data
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                quote_header = {}
                for index, fn in enumerate(fieldnames):
                    quote_header[fn] = row[index]
                # adding lines details here
                quote_header['lines'] = lines_list
                header_vals.append(quote_header)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return header_vals

    # getLine Details of a order
    @staticmethod
    def order_lines(refid, lang):
        # ref_id is nothing but header_id
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['order_lines_query']
            cursor.execute(query, P_HEADER_ID=refid, p_lang=lang)
            # get all lines information by passing header_id
            # and langugae
            quote_lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                quote_line = {}
                for index, fn in enumerate(fieldnames):
                    quote_line[fn] = row[index]
                quote_lines.append(quote_line)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 order_lines """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return quote_lines

    @staticmethod
    def get_all_pricelists(org_id):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['price_lists_query']
            cursor.execute(query, P_ORG_ID=org_id)
            pricelists = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                pl = {}
                for index, fn in enumerate(fieldnames):
                    pl[fn] = row[index]
                pricelists.append(pl)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                 get_all_pricelists """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return pricelists

    @staticmethod
    def send_approval(jsond):
        connection = None
        cursor = None
        status = ''
        email = jsond['email_address']
        message = jsond['message']
        temp_id = 152319
        is_distributor_quote = jsond['is_distributor_quote']
        approver_id = jsond['user_id']
        try:
            strings = db_util.get_strings()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            if is_distributor_quote == 'N':
                query = db_util.getusermngSql()['accounting_team_query']
                param = 'QUOTE-APPROVER-' + str(jsond['org_id'])
                user = cursor.execute(query, p_param=param).fetchall()
                if not user:
                    status = 'No Approver found for Quotes'
                    logger.findaylog('models - send_approval - no user - ' + status)
                    return status
                email = user[0][3]
                temp_id = 292177
                approver_id = user[0][0]
            if is_distributor_quote == 'N':
                query = db_util.getSqlData()['update_quote_approver_all']
            else:
                query = db_util.getSqlData()['update_quote_approver']
            cursor.execute(query, p_approver_id=approver_id,
                           p_quote_id=jsond['quote_id'])

            data = {
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                },
                'subject': jsond['subject'],
                'template_id': temp_id,
                'to_email': email
            }

            if is_distributor_quote == 'N':
                data['params'] = [
                    {
                        'key': 'quote_number',
                        'value': jsond['quote_number']
                    },
                    {
                        'key': 'user_name',
                        'value': user[0][2]
                    },
                    {
                        'key': 'agent_name',
                        'value': jsond['user_name']
                    },
                    {
                        'key': 'customer',
                        'value': jsond['customer_name']
                    }

                ]
            else:
                data['params'] = [
                    {
                        'key': 'message',
                        'value': message
                    }
                ]
            result = CommonUtils.send_mail(data)
            if result != 'SUCCESS':
                status = 'Failure - Failed to send email'
                logger.findaylog(
                    'models - quotes - send_approval - failed to send email - ' + status)
            else:
                status = 'SUCCESS'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                send_approval """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return status

    @staticmethod
    def process_discount_flow(req):
        connection = None
        cursor = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            quote_line_ids = cursor.arrayvar(cx_Oracle.NUMBER, req['line_ids'])
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_quotes_pub_pkg.process_discount_flow(
                    :p_quote_header_id,
                    :p_quote_line_ids,
                    :p_user_id,
                    :x_status_code
                );
            end; """, p_quote_header_id=req['header_id'],
                           p_quote_line_ids=quote_line_ids,
                           p_user_id=req['user_id'],
                           x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {
                    'status': Status.OK.value,
                    'msg': 'Discount flow processed successfully'
                }
                Quotes.send_discount_approval(req)
            else:
                result = {
                    'status': Status.ERROR.value,
                    'msg': 'Failed to process discount flow - ' + str(status_code.getvalue())
                }
                logger.findaylog('models - quotes - process_discount_flow - ' + result['msg'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - quote -
                process_discount_flow """ + str(error))
            raise error
        finally:
            if cursor:
                connection.commit()
                cursor.close()
                db_util.release_connection(connection)
        return result

    @staticmethod
    def send_discount_approval(jsond):
        connection = None
        cursor = None
        status = ''
        try:
            # mail type 'A' indicates mail to approver that is by default
            # if mail type is 'S' we send email to Sales agent
            # when the discount is rejected or approved
            mail_type = jsond.get('mail_type', 'A')
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['quote_customer_name_query']
            quote_data = cursor.execute(query, p_header_id=jsond['header_id'],
                                        p_user_id=jsond['user_id']).fetchone()
            if quote_data:
                if mail_type == 'A':
                    lines_data = Quotes.show_lines(jsond['header_id'], None,
                                                   str(jsond['org_id']))
                    lines_data = lines_data[1:]
                    approvers = {}
                    for line in lines_data:
                        # send for approval only if it is pending approval
                        if line['discount_status'] and line['discount_status'] == 'P':
                            approver = line['discount_approver']
                            if approver not in approvers:
                                approvers[approver] = []

                            approvers[approver].append({
                                'description': line['description'],
                                'inventory_item_id': line['inventory_item_id'],
                                'discount_asked': line['discount_asked'],
                                'converted_discount': line['converted_discount'],
                                'quantity': line['quantity'],
                                'actual_price': line['line_list_price'],
                                'discount_price': line['line_quote_price'],
                                'discount_approver': line['discount_approver']
                            })
                    if approvers:
                        subject = '[APPROVAL] Quote #{0} for {1} for discounts'
                        subject = subject.format(quote_data[0], quote_data[3])
                        for approver_id, lines in list(approvers.items()):
                            approver_id = int(approver_id)
                            # if quote line has approver details send email to approver
                            # otherwise get the 1 approver for the user
                            if approver_id:
                                query = sql_file['quotes_approver_details']
                                managers = cursor.execute(query,
                                                          p_approver_id=approver_id).fetchall()
                            else:
                                query = sql_file['quotes_approver_query']
                                managers = cursor.execute(query, p_user_id=jsond['user_id'],
                                                          p_approver_seq=1).fetchall()

                            if not managers:
                                status = 'No Approver found for Quotes'
                                logger.findaylog(
                                    'models - quotes - send_approval - no managers - ' + status)
                                return status
                            else:
                                for user in managers:
                                    if user[1]:
                                        data = {
                                            'subject': subject,
                                            'template_id': 776762,
                                            'to_email': user[1],
                                            'to_name': user[0],
                                            'params': [
                                                {'key': 'manager', 'value': user[0]},
                                                {'key': 'user', 'value': quote_data[4]},
                                                {'key': 'cust_name', 'value': quote_data[3]},
                                                {'key': 'lines', 'value': lines},
                                                {'key': 'prods', 'value': len(lines)},
                                                {'key': 'quote_num', 'value': quote_data[0]},
                                                {'key': 'total', 'value': quote_data[1]},
                                                {'key': 'currency_code', 'value': quote_data[2]},
                                                {'key': 'header_id', 'value': jsond['header_id']}
                                            ]
                                        }
                                        result = CommonUtils.send_mail(data)
                                        if result != 'SUCCESS':
                                            status = 'Failure - Failed to send email. '
                                        else:
                                            status = 'SUCCESS'
                else:
                    query = sql_file['quote_user_details_query']
                    user = cursor.execute(query, p_resource_id=quote_data[5]).fetchone()
                    if user:
                        if jsond.get('approval_status') == 'A':
                            approval_status = 'Approved'
                        else:
                            approval_status = 'Rejected'
                        subject = '[{0}] Quote #{1} for {2} for discounts'
                        subject = subject.format(approval_status, quote_data[0], quote_data[3])
                        data = {
                            'subject': subject,
                            'template_id': 1071344,
                            'to_email': user[1],
                            'to_name': user[2],
                            'params': [
                                {'key': 'agent_name', 'value': user[2]},
                                {'key': 'approval_status', 'value': approval_status},
                                {'key': 'quote_num', 'value': quote_data[0]},
                                {'key': 'cust_name', 'value': quote_data[3]},
                                {'key': 'header_id', 'value': jsond['header_id']}
                            ]
                        }
                        result = CommonUtils.send_mail(data)
                        if result != 'SUCCESS':
                            status += 'Failed to send email to agent'
                        else:
                            status = 'SUCCESS'
        except Exception as error:
            logger.findaylog("""EXCEPTION - models - quote -
                    send_discount_approval """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return status

    @staticmethod
    def send_final_approval(jsond):
        connection = None
        cursor = None
        status = ''
        try:
            strings = db_util.get_strings()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = db_util.getSqlData()['quote_final_approver_query']
            cursor.execute(query)
            user = cursor.fetchall()
            if user:
                data = {
                    'sender': {
                        'email': strings['sender_email'],
                        'name': strings['sender_name']
                    },
                    'subject': strings['quote_approval_subject'] + str(jsond['quote_number']),
                    'template_id': 164586,
                    'params': [{
                        'key': 'quote_number',
                        'value': jsond['quote_number']
                    }],
                    'to_email': user[0][2]
                }
                result = CommonUtils.send_mail(data)
                if result != 'SUCCESS':
                    status = 'Failure - Failed to send email'
                    logger.findaylog('models - send_final_approval - ' + status)
                else:
                    status = 'SUCCESS'
            else:
                status = 'Failure - Failed to send email'
                logger.findaylog('models - send_final_approval - ' + status)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                send_final_approval """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return status

    @staticmethod
    def validate_products(jsond):
        org_id = jsond['org_id']
        list_id = jsond['price_list_id']
        lang = jsond['lang']
        invalid = []
        items = jsond['items']
        try:
            products_obj = Products()
            products = products_obj.get_products(org_id, list_id, lang, None,
                                                 None)
            products = ujson.loads(ujson.dumps(products))
            if products and len(products) > 0:
                # Check if item codes are there in products list
                for item in items:
                    product_flag = True
                    for i in range(len(products)):
                        if products[i]['concatenated_segments'] == item:
                            product_flag = True
                            break
                        else:
                            product_flag = False
                    if not product_flag:
                        invalid.append(item)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                validate_products """ + str(error))
            raise error
        return invalid

    @staticmethod
    def send_notification(jsond):
        connection = None
        cursor = None
        status = ''
        try:
            strings = db_util.get_strings()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = db_util.getSqlData()['user_data_query']
            cursor.execute(query, p_user_id=jsond['created_user'])
            user = cursor.fetchall()
            if user:
                data = {
                    'sender': {
                        'email': strings['sender_email'],
                        'name': strings['sender_name']
                    },
                    'subject': strings['quote_approval_subject'] + str(jsond['quote_number']),
                    'template_id': 289630,
                    'params': [
                        {
                            'key': 'quote_number',
                            'value': jsond['quote_number']
                        },
                        {
                            'key': 'customer',
                            'value': jsond['bill_to_party_name']
                        },
                        {
                            'key': 'username',
                            'value': user[0][0]
                        }
                    ],
                    'to_email': user[0][1]
                }
                result = CommonUtils.send_mail(data)
                if result != 'SUCCESS':
                    status = 'Failure - Failed to send email'
                    logger.findaylog('models - send_notification - ' + status)
                else:
                    status = 'SUCCESS'
            else:
                status = 'Failure - Failed to send email'
                logger.findaylog('models - send_notification - ' + status)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                send_notification """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return status

    @classmethod
    def get_sales_reps(cls, org_id):
        connection = None
        cursor = None
        result = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['salesreps_query']
            cursor.execute(query, p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                get_sales_reps """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                data = dict()
                for index, fn in enumerate(fieldnames):
                    data[fn] = row[index]
                result.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return result

    @staticmethod
    def create_po(req):
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            if req.get('is_update', False):
                cursor.execute('''
                begin
                    qpex_quotes_pub_pkg.update_po(
                        :p_quote_header_id,
                        :p_po_header_id,
                        :p_user_id,
                        :x_status_code
                    );
                end; ''', p_quote_header_id=req['quote_header_id'],
                               p_po_header_id=req['po_header_id'],
                               p_user_id=req['user_id'],
                               x_status_code=status_code)
            else:
                cursor.execute('''
                begin
                    qpex_quotes_pub_pkg.create_po(
                        :p_vendor_id,
                        :p_vendor_site_id,
                        :p_quote_header_id,
                        :p_user_id,
                        :x_status_code
                    );
                end; ''', p_vendor_id=req['vendor_id'],
                               p_vendor_site_id=req['vendor_site_id'],
                               p_quote_header_id=req['quote_header_id'],
                               p_user_id=req['user_id'],
                               x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value}
                if req.get('is_update', False):
                    result['msg'] = 'Purchase order updated successfully'
                else:
                    result['msg'] = 'Purchase order created successfully'
            else:
                result = {
                    'status': Status.ERROR.value,
                    'msg': 'Failed to create purchase order - ' + str(status_code.getvalue())
                }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - quote -
                create_po ''' + str(error))
            raise error
        finally:
            if cursor:
                connection.commit()
                cursor.close()
                db_util.release_connection(connection)
        return result

    @staticmethod
    def get_discount_approvals():
        """
        Get the discount approval list from the db
        :return:{'status': '', 'result' : array of json values}
        """
        try:
            result = {}
            sql_file = db_util.getSqlData()
            with OracleConnectionManager() as conn:
                query = sql_file['get_discount_approver_details']
                conn.execute(query)
                result['result'] = conn.get_result()
                result['status'] = Status.OK.value
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote - get_discount_approvals
            """ + str(error))
            raise error
        return result

    @staticmethod
    def insert_discount_approval(method, request_data):
        """
        Insert the discount approver details w.r.t user id
        :param request_data: {"user_id":"", "approver_id": "", "approver_seq":""}
        :return: {"status":"", "msg":"" }
        """
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                BEGIN
                    qpex_quotes_pub_pkg.insert_discount_approver(
                    :p_user_id,
                    :p_approver_id,
                    :p_approver_seq,
                    :x_status_code
                    );
                END;""", p_user_id=request_data['user_id'],
                             p_approver_id=request_data['approver_id'],
                             p_approver_seq=request_data['approver_seq'],
                             x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': '{} discount approver mapping details'.format(
                              'Added' if method == 'POST' else 'Updated')
                          }
            else:
                result = {'status': Status.OK.value,
                          'msg': 'Failed to {0} mapping details - {1}'.format(
                              'add' if method == 'POST' else 'update',
                              status_code.getvalue())}
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                        insert_discount_approver""" + str(error))
            raise error
        return result

    @staticmethod
    def delete_discount_approval(request_data):
        """
        Delete the approver details w.r.t. user
        :param request_data: {"user_id":"", "approver_id": "", "approver_seq":""}
        :return: {"status":"", "msg":"" }
        """
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                    BEGIN
                        qpex_quotes_pub_pkg.delete_discount_approver(
                        :p_user_id,
                        :p_approver_id,
                        :p_approver_seq,
                        :x_status_code
                        );
                    END;""", p_user_id=request_data['user_id'],
                             p_approver_id=request_data['approver_id'],
                             p_approver_seq=request_data['approver_seq'],
                             x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Deleted discount approver mapping details'}
            else:
                result = {'status': Status.OK.value,
                          'msg': 'Failed to delete mapping details - {}'.format(
                              status_code.getvalue())}
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - quote -
                            delete_discount_approval""" + str(error))
            raise error
        return result

    @staticmethod
    def approve_dtc_quote(header_id, user_id):
        """ Approve DTC quote with <header_id> """
        result = {'status': 0}
        with OracleConnectionManager() as conn:
            approver_id = conn.cursor.var(cx_Oracle.NUMBER)
            conn.execute('''
            begin
                qpex_quotes_pub_pkg.approve_dtc_quote(
                    :p_user_id,
                    :p_quote_header_id,
                    :x_next_approver,
                    :x_status_code
                );
            end; ''', output_key='x_status_code',
                         p_user_id=user_id,
                         p_quote_header_id=header_id,
                         x_next_approver=approver_id)
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result['status'] = 1
                result['msg'] = 'Failed to approve quote %s' % status
                return result
            result['approver_id'] = approver_id.getvalue()
            status = Quotes.send_dtc_approval_mail(header_id, result['approver_id'])
            if status != 'SUCCESS':
                result['msg'] = 'Quote approved but failed to send email'
                return result
            result['msg'] = 'Quote approved successfully'
        return result

    @staticmethod
    def send_dtc_approval_mail(header_id, approver_id, is_first_mail=False):
        with OracleConnectionManager() as conn:
            sql_file = db_util.getSqlData()
            if approver_id:
                approver_id = int(approver_id)
            else:
                query = sql_file['get_quote_approver_query']
                conn.execute(query, p_header_id=header_id)
                data = conn.get_single_result()
                if not data:
                    approver_id = None
                else:
                    approver_id = data['approver_id']
            if is_first_mail and approver_id is None:
                return
            query = sql_file['dtc_mail_query']
            conn.execute(query,
                         p_header_id=header_id,
                         p_user_id=approver_id)
            data = conn.get_single_result()
            if data:
                template_id = 3144871 if approver_id is not None else 3144873
                if approver_id is not None:
                    user_name = data['user_name']
                    subject = '[Approval] Quote # %s is waiting for your approval'
                else:
                    user_name = data['created_by']
                    subject = '[Approved] Quote # %s is ready to submit'
                mail_data = {
                    'subject': subject % data['quote_number'],
                    'template_id': template_id,
                    'params': [
                        {
                            'key': 'quote_number',
                            'value': data['quote_number']
                        },
                        {
                            'key': 'user_name',
                            'value': user_name
                        },
                        {
                            'key': 'header_id',
                            'value': header_id
                        },
                        {
                            'key': 'org_id',
                            'value': data['org_id']
                        }
                    ],
                    'to_email': data['email_address']
                }
                result = CommonUtils.send_mail(mail_data)
                if result != 'SUCCESS':
                    return 'ERROR'
        return 'SUCCESS'

    @staticmethod
    def get_salesrep_user_id_query():
        sql_file = db_util.getSqlData()
        salesrep_user_id_query = '(' + sql_file['quote_salesrep_user_id']
        salesrep_user_id_query += ') salesrep_user_id'
        return salesrep_user_id_query

    @staticmethod
    def get_typecheck_lov():
        result = []
        with OracleConnectionManager() as conn:
            sql_file = db_util.getSqlData()
            query = sql_file['quote_typecheck_lov_query']
            conn.execute(query)
            result = conn.get_result()
        return result


def applydisc(pdiscount, segment_ids_list, line_ids_list, porg):
    discount = []
    con = None
    cur = None
    rmsg = ''
    try:
        for i in range(0, len(segment_ids_list)):
            segment_ids_list[i] = str(segment_ids_list[i])
            if len(pdiscount) < len(segment_ids_list):
                discount.append(pdiscount[0])
        if len(pdiscount) == len(segment_ids_list):
            discount = pdiscount
        con = db_util.get_connection()
        cur = con.cursor()
        sql_file = db_util.getSqlData()
        query = sql_file['item_discounts']
        cur.execute(query, p_org=porg)
        item_data = cur.fetchall()
        item_dict = {}
        item_codes = []
        field_names = [a[0].lower() for a in cur.description]
        key_value = ""
        msg = ""
        invalid_items = []
        for row in item_data:
            item = {}
            for index, fn in enumerate(field_names):
                if fn == "item_code":
                    key_value = str(row[index])
                    item_dict[key_value] = item
                    item_codes.append(row[index])
                item[fn] = row[index]
        # check with item_dict
        for index, value in enumerate(segment_ids_list):
            if value not in item_codes:
                msg += "Discount cannot be applied to " + str(value) + "<br/>"
                invalid_items.append(str(value))
            else:
                dictval = item_dict[str(value)]
                # discount = float(discount)
                # if any error occurs then display message
                if discount[index] > dictval['max_discount_pct']:
                    msg += "Discount should not more than" + "  "
                    msg += str(dictval['max_discount_pct']) + " for item"
                    msg += "  " + str(value) + "<br/>"
                    invalid_items.append(str(value))
                else:
                    dictval = item_dict[str(value)]
                    sd = dictval['start_date']
                    # sd = datetime.fromtimestamp(sd).strftime('%Y-%m-%d')
                    now = datetime.now()
                    # curr_date = now.strftime("%Y-%m-%d")
                    ed = dictval['end_date']
                    # ed = datetime.fromtimestamp(ed).strftime('%Y-%m-%d')
                    if sd > now or ed < now:
                        msg += "Item " + str(value)
                        msg += " has expired discounts!" + "<br/>"
                        invalid_items.append(str(value))
        if len(invalid_items) == 0:
            # if discount is correct then call package
            rmsg = cur.var(cx_Oracle.STRING)
            lines_var = cur.arrayvar(cx_Oracle.NUMBER,
                                     line_ids_list)
            discount_var = cur.arrayvar(cx_Oracle.NUMBER,
                                        discount)
            cur.execute("""
                     DECLARE
                     l_status VARCHAR2(1000);
                     type dummy_jtf_number_table_t
                     IS
                     TABLE OF NUMBER INDEX BY binary_integer;
                     l_dummy_jtf dummy_jtf_number_table_t:= :p_lines;
                     l_jtf jtf_number_table:=jtf_number_table( NULL);
                     l_msg VARCHAR2(1000);
                     type dummy_jtf_number_table_tdisc
                     IS
                     TABLE OF NUMBER INDEX BY binary_integer;
                     l_dummy_jtf_disc dummy_jtf_number_table_tdisc:= :p_disc;
                     l_jtf_disc jtf_number_table:=jtf_number_table( NULL);
                     l_msg VARCHAR2(1000);
                     BEGIN
                     l_jtf.extend(l_dummy_jtf.count);
                     FOR i IN 1.. l_dummy_jtf.count
                     LOOP
                     l_jtf(i) := l_dummy_jtf(i);
                     END LOOP;
                     l_jtf_disc.extend(l_dummy_jtf_disc.count);
                     FOR i IN 1.. l_dummy_jtf_disc.count
                     LOOP
                     l_jtf_disc(i) := l_dummy_jtf_disc(i);
                     END LOOP;
                    l_status := qpex_quotes_pub_pkg
                .apply_discount_for_lines\
                (l_jtf,l_jtf_disc,:p_error_msg);\
                IF (l_status = 'S') THEN\
                commit;\
                ELSE\
                rollback;\
                END IF;\
                end;""", p_lines=lines_var,
                        p_disc=discount_var, p_error_msg=rmsg)
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - models - quote -
             applydisc """ + str(error))
        raise error
    finally:
        cur.close()
        db_util.release_connection(con)
    final_msg = ""
    if not msg:
        final_msg = rmsg.getvalue()
    else:
        final_msg = msg
    if final_msg:
        logger.findaylog('quotes - models - discount - ' + str(final_msg))
    return final_msg, invalid_items
