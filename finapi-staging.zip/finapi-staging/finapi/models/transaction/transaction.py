from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util


class Transaction:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    #  used in  to get revenue details in given period
    def get_cust_revenue(p_userid, p_org, rev_type, accnt_id):
        logger.addinfo('@ models - transaction - get_cust_revenue(+)')
        sql_file = db_util.getSqlData()
        totalrevenue = []
        ptype = ""
        ref_id = ""
        qryname = ""
        if not accnt_id:
            user_details = Code_util.get_usertype(p_userid)
            ptype = user_details['type']
            ref_id = user_details['refid']
        if rev_type == 'all':
            if ptype == 'salesrep':
                qry = sql_file['sallrevquery']
                qryname = 'sallrevquery'
            else:
                qry = sql_file['allrevquery']
                qryname = 'sallrevquery'
        if rev_type == 'open':
            if ptype == 'salesrep':
                qry = sql_file['sopenrevquery']
                qryname = 'sallrevquery'
            else:
                qry = sql_file['openrevquery']
                qryname = 'sallrevquery'
        if rev_type == 'due':
            if ptype == 'salesrep':
                qry = sql_file['sduerevquery']
                qryname = 'sallrevquery'
            else:
                qry = sql_file['duerevquery']
                qryname = 'sallrevquery'
        if rev_type == 'ytd':
            if ptype == 'salesrep':
                qry = sql_file['sytdrevquery']
                qryname = 'sallrevquery'
            else:
                qry = sql_file['ytdrevquery']
                qryname = 'sallrevquery'
        totalrevenue = Transaction.get_value(qry, p_org, ptype,
                                             p_userid, ref_id,
                                             accnt_id, qryname)
        logger.addinfo('@ models - transaction - get_cust_revenue(-)')
        return totalrevenue

    @staticmethod
    @db_util.langs("American")
    def get_value(qry, p_org, ptype, user_id, refid, accnt_id, qryname):
        logger.addinfo('@ models - transaction - get_value(+)')
        con = None
        cur = None
        sql_file = db_util.getSqlData()
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            if ptype == 'b2b':
                cur.execute(qry, pcustaccnt_id=refid,
                            P_SALESREP_ID='', P_ORG_ID=p_org)
            elif ptype == 'salesrep':
                salesid_qry = sql_file['salesrep_ids']
                cur.execute(salesid_qry, user_id=user_id)
                ids = cur.fetchall()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                query_temp = qry
                srep_query = query_temp % (',' . join([":" + str(i)
                                           for i in range(len(listk))]),
                                           p_org)
                cur.execute(srep_query, listk)
            else:
                cur.execute(qry, P_ORG_ID=p_org,
                            P_SALESREP_ID='', pcustaccnt_id=accnt_id)
        except Exception as error:
            logger.findaylog("""@ 91 EXCEPTION - models - transaction -
                 get_value """ + str(error))
            raise error
        else:
            rev_data = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in cur:
                myrev = {}
                for index, fn in enumerate(fieldnames):
                    myrev[fn] = row[index]
                rev_data.append(myrev)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('get_val  in transaction in model ends')
        return rev_data

    @staticmethod
    def get_val(pquery, p_org, psalesrep):
        logger.addinfo('@ models - transaction - get_val(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute(pquery, p_orgid=p_org, p_salesrep=psalesrep)
        except Exception as error:
            logger.findaylog("""@ 118 EXCEPTION - models - transaction -
                 get_val """ + str(error))
            raise error
        else:
            cust_revenue_data = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in cur:
                mytransaction = {}
                for index, fn in enumerate(fieldnames):
                    mytransaction[fn] = row[index]
                cust_revenue_data.append(mytransaction)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - transaction - get_val(-)')
        return cust_revenue_data

    @staticmethod
    def get_Trans_Dtl(transactionId, p_org):
        logger.addinfo("@ models - transaction - get_Trans_Dtl(+)")
        con = None
        cur = None
        transactionDetails = []
        sql_file = db_util.getSqlData()
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            transactionquery = sql_file["transactionById"]
            cur.execute(transactionquery, p_customerTrxId=transactionId,
                        p_orgid=p_org)
            transactionDetails = cur.fetchall()
        except Exception as error:
            logger.findaylog("""@ 150 EXCEPTION - models - transaction -
                 get_Trans_Dtl """ + str(error))
            raise error
        else:
            cust_transaction_data = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in transactionDetails:
                mytransaction = {}
                for index, fn in enumerate(fieldnames):
                    mytransaction[fn] = row[index]
                transactionLinesquery = sql_file['transactionLinesQuery']
                cur.execute(transactionLinesquery,
                            p_customerTrxId=transactionId,
                            p_orgid=p_org)
                transactionLineDetails = cur.fetchall()
                cust_transactionLine_data = []
                lineFieldnames = [a[0].lower() for a in cur.description]
                for row in transactionLineDetails:
                    mytransactionLine = {}
                    for index, fn in enumerate(lineFieldnames):
                        mytransactionLine[fn] = row[index]
                    cust_transactionLine_data.append(mytransactionLine)
                mytransaction['lines'] = cust_transactionLine_data
                cust_transaction_data.append(mytransaction)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - transaction - get_Trans_Dtl(-)')
        return cust_transaction_data

    @staticmethod
    def sales_avg_price(jsond):
        logger.addinfo('@ models - transaction - sales_avg_price(+)')
        connection = None
        cursor = None
        sales_channel = jsond['sales_channel']
        agent_name = jsond['agent_name']
        customer_number = jsond['customer_number']
        segment = jsond['segment']
        item_code = jsond['item_code']
        period_from = jsond['period_from']
        period_to = jsond['period_to']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['sales_avg_price_analysis']
            cursor.execute(qry, P_SALES_CHANNEL=sales_channel,
                           P_AGENT_NAME=agent_name,
                           P_CUSTOMER_NUMBER=customer_number,
                           P_SEGMENT=segment,
                           P_ITEM_CODE=item_code,
                           P_PERIOD_FROM=period_from,
                           P_PERIOD_TO=period_to)
        except Exception as error:
            logger.findaylog("""@ 205 EXCEPTION - models - transaction -
                 sales_avg_price """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - transaction - sales_avg_price(-)')
        return reports
