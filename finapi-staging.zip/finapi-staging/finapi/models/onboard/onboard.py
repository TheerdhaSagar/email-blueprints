from finapi.utils.logdata import logger
from finapi.utils import db_util
from copy import deepcopy
from jinja2 import Template
from PyPDF2 import PdfFileReader, PdfFileWriter
from barcode.writer import ImageWriter
from finapi.sql import sql_util
from finapi.utils.code_util import Code_util
from finapi.utils.log_util import LogUtil
import ujson
import cx_Oracle
import urllib.request
import urllib.error
import urllib.parse
import requests
import os
import paramiko
import pdfkit
import io
import datetime
import barcode
import re
import base64
import xlsxwriter


class Onboard:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    def get_brands(self, language, status):
        logger.addinfo('@ models - onboard - get_brands(+)')
        try:
            self.acquire()
            if status:
                query = self.sql_file['get_brands']
            else:
                query = self.sql_file['brands_query']
            self.cursor.execute(query, p_language=language)
        except Exception as error:
            logger.findaylog("""@ 50 EXCEPTION - models - onboard -
                 get_brands """ + str(error))
            raise error
        else:
            brands_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                brand = {}
                for index, field in enumerate(field_names):
                    brand[field] = self.decode_value(row[index])
                brands_list.append(brand)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_brands(-)')
        return brands_list

    def get_segments(self, brand, language):
        logger.addinfo('@ models - onboard - get_segments(+)')
        try:
            self.acquire()
            query = self.sql_file['segements_brand_query']
            self.cursor.execute(query, p_brand=brand, p_language=language)
        except Exception as error:
            logger.findaylog("""@ 75 EXCEPTION - models - onboard -
                 get_segments """ + str(error))
            raise error
        else:
            segments_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            data = self.cursor.fetchall()
            for row in data:
                segment = {}
                for index, field in enumerate(field_names):
                    segment[field] = self.decode_value(row[index])
                    if index == 1:
                        c_query = self.sql_file['get_item_count_query']
                        data = self.cursor.execute(c_query,
                                                   p_segement=row[index],
                                                   p_language=language,
                                                   p_brand=brand).fetchone()
                        segment['count'] = data[0]
                segments_list.append(segment)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_segments(-)')
        return segments_list

    def get_items(self, segment, language, brand):
        logger.addinfo('@ models - onboard - get_items(+)')
        try:
            self.acquire()
            query = self.sql_file['items_segment_query']
            self.cursor.execute(query, p_segement=segment,
                                p_language=language,
                                p_brand=brand)
        except Exception as error:
            logger.findaylog("""@ 110 EXCEPTION - models - onboard -
                 get_items """ + str(error))
            raise error
        else:
            items_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                item = {}
                for index, field in enumerate(field_names):
                    # item[field] = row[index]
                    item[field] = self.decode_value(row[index])
                items_list.append(item)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_items(-)')
        return items_list

    def post(self, jsond):
        logger.addinfo('@ models - onboard - post(+)')
        bg_color = jsond['bgColor']
        language = jsond['language']
        sections = jsond['sections']
        del jsond['sections']
        if 'new_language' in jsond:
            del jsond['bgColor']
        try:
            self.acquire()
            fieldname_strng = ""
            parameter_strng = ""
            row_list = []
            query = self.sql_file['onboard_section_sequence']
            data = self.cursor.execute(query).fetchone()
            for cn_line in sections:
                field_query = self.sql_file['onboard_field_block_sequence']
                field_data = self.cursor.execute(field_query).fetchone()
                style_query = self.sql_file['onboard_style_block_sequence']
                style_data = self.cursor.execute(style_query).fetchone()
                self.insert_fields(cn_line['fields'], field_data[0],
                                   data[0], language)
                self.insert_styles(cn_line['styles'], style_data[0],
                                   data[0])
                del cn_line['fields']
                del cn_line['styles']
                cn_line['section_id'] = data[0]
                cn_line['bg_color'] = bg_color
                cn_line['style_block_id'] = style_data[0]
                cn_line['field_block_id'] = field_data[0]
                cn_line['language'] = language
                temp_line = cn_line
                values = ""
                values = tuple(str(val) for key, val in cn_line.items())
                row_list.append(values)
            if sections:
                dict_val = temp_line
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"
            else:
                return 'fails'
            self.acquire()
            self.cursor.prepare("""insert into
            qpex_onboard_sections """ + fieldname_strng+"""
            values""" + parameter_strng)
            self.cursor.executemany(None, row_list)
        except Exception as error:
            logger.findaylog("""@ 186 EXCEPTION - models - onboard -
                 post """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - post(-)')
        return "success"

    def insert_fields(self, fields_list, block_id, section_id,
                      language):
        logger.addinfo('@ models - onboard - insert_fields(+)')
        try:
            self.acquire()
            fieldname_strng = ""
            parameter_strng = ""
            row_list = []
            for cn_line in fields_list:
                if 'field_id' not in cn_line:
                    query = self.sql_file['onboard_field_sequence']
                    data = self.cursor.execute(query).fetchone()
                    cn_line['field_id'] = data[0]
                if 'value' in cn_line:
                    del cn_line['value']
                cn_line['block_id'] = block_id
                cn_line['section_id'] = section_id
                cn_line['language'] = language
                temp_line = cn_line
                my_data = []
                for key, value in cn_line.items():
                    my_data.append(self.encode_value(value, True))
                    values = tuple(my_data)
                row_list.append(values)
            if fields_list:
                dict_val = temp_line
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"
            self.cursor.prepare("""insert into
            qpex_onboard_fields """ + fieldname_strng+"""
            values""" + parameter_strng)
            self.cursor.executemany(None, row_list)
        except Exception as error:
            logger.findaylog("""@ 238 EXCEPTION - models - onboard -
                 insert_fields """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - onboard - insert_fields(-)')
        return "success"

    def insert_styles(self, styles, block_id, section_id):
        logger.addinfo('@ models - onboard - insert_styles(+)')
        try:
            self.acquire()
            fieldname_strng = ""
            parameter_strng = ""
            row_list = []
            for cn_line in styles:
                if 'style_id' not in cn_line:
                    query = self.sql_file['onboard_style_sequence']
                    data = self.cursor.execute(query).fetchone()
                    cn_line['style_id'] = data[0]
                cn_line['block_id'] = block_id
                cn_line['section_id'] = section_id
                temp_line = cn_line
                values = ""
                values = tuple(str(val) for key, val in cn_line.items())
                row_list.append(values)
            if styles:
                dict_val = temp_line
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"
            self.cursor.prepare("""insert into
            qpex_onboard_styles """ + fieldname_strng+"""
            values""" + parameter_strng)
            self.cursor.executemany(None, row_list)
        except Exception as error:
            logger.findaylog("""@ 288 EXCEPTION - models - onboard -
                 insert_styles """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - onboard - insert_styles(-)')
        return "success"

    def get_fields(self, id, field_type, language):
        logger.addinfo('@ models - onboard - get_fields(+)')
        fields = []
        try:
            self.acquire()
            query = self.sql_file['onboard_field_query']
            self.cursor.execute(query, p_section_id=id,
                                p_language=language)
            data = self.cursor.fetchall()
            if len(data) == 0:
                query = self.sql_file['onboard_field_exception_query']
                self.cursor.execute(query, p_section_id=id,
                                    p_language=language)
                data = self.cursor.fetchall()
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in data:
                field = {}
                for i in range(len(field_names)):
                    field[field_names[i]] = self.decode_value(row[i])
                fields.append(field)
        except Exception as e:
            logger.findaylog(""" 321 EXCEPTION - models - onboard -
                             get_fields """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_fields(-)')
        return fields

    def get_styles(self, id):
        logger.addinfo('@ models - onboard - get_styles(+)')
        styles = []
        try:
            self.acquire()
            query = self.sql_file['onboard_styles_query']
            self.cursor.execute(query, p_section_id=id)
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                style = {}
                for i in range(len(field_names)):
                    style[field_names[i]] = self.decode_value(row[i])
                styles.append(style)
        except Exception as e:
            logger.findaylog(""" 346 EXCEPTION - onboard - models -
                             get_styles """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_styles(-)')
        return styles

    def get_data(self, id, field_type, language):
        logger.addinfo('@ models - onboard - get_data(+)')
        flag = 0
        try:
            fields = self.get_fields(id, field_type, language)
            styles = self.get_styles(id)
            self.acquire()
            query = self.sql_file['onboard_section_query']
            self.cursor.execute(query, p_section_id=id,
                                p_language=language,
                                p_type=field_type)
            data = self.cursor.fetchall()
            if len(data) == 0:
                flag = 1
                temp_query = self.sql_file['onboard_section_exception_query']
                self.cursor.execute(temp_query, p_section_id=id,
                                    p_type=field_type,
                                    p_language=language)
                data = self.cursor.fetchall()
            field_names = [a[0].lower() for a in self.cursor.description]
            blocks = []
            for row in data:
                block = {}
                for i in range(len(field_names)):
                    block[field_names[i]] = self.decode_value(row[i])
                    if field_names[i] == 'bg_color':
                        bg_color = row[i]
                blocks.append(block)
            for i in range(len(blocks)):
                blocks[i]['fields'] = []
                blocks[i]['styles'] = []
                for j in range(len(fields)):
                    if blocks[i]['field_block_id'] == fields[j]['block_id']:
                        blocks[i]['fields'].append(fields[j])
                for j in range(len(styles)):
                    if blocks[i]['field_block_id'] == styles[j]['block_id']:
                        blocks[i]['styles'].append(styles[j])
            final = {}
            final['bgColor'] = bg_color
            final['sections'] = blocks
            if flag == 0:
                final['new_language'] = False
            else:
                final['new_language'] = True
        except Exception as error:
            logger.findaylog("""@ 400 EXCEPTION - models - onboard -
                 get_data """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_data(-)')
        return final

    def delete_fields(self, fields, language):
        logger.addinfo('@ models - onboard - delete_fields(+)')
        try:
            self.acquire()
            for i in range(0, len(fields)):
                query = self.sql_file['delete_onboard_fields']
                self.cursor.execute(query,
                                    p_field_id=fields[i],
                                    p_language=language)
        except Exception as error:
            logger.findaylog("""@ 421 EXCEPTION - models - onboard -
                 delete_fields """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - delete_fields(-)')
        return 'success'

    def put(self, jsond):
        logger.addinfo('@ models - onboard - put(+)')
        insert_result = []
        field_ids = []
        try:
            del_fields = jsond['deletedFields']
            result = 'success'
            data = jsond['data']
            language = data['language']
            if len(del_fields) > 0:
                result = self.delete_fields(del_fields, language)
            if result == 'success':
                del jsond['deletedFields']
                bg_color = data['bgColor']
                if data['new_language'] == 'true':
                    tmp_result = self.post_language(data, bg_color)
                    return tmp_result
                else:
                    section_id = data['section_id']
                    sections = data['sections']
                    self.acquire()
                    query = self.sql_file['update_section_color']
                    self.cursor.execute(query, p_bg_color=bg_color,
                                        p_section_id=section_id)
                    for cn_line in sections:
                        fields = cn_line['fields']
                        styles = cn_line['styles']
                        final_list = []
                        update_list = []
                        for i in fields:
                            if i['field_id'] == '':
                                final_list.append(i)
                            else:
                                update_list.append(i)
                        if len(final_list) > 0:
                            insert_result = self.insert_field(
                                final_list)
                            for i in range(len(insert_result)):
                                field_ids.append(insert_result[i])
                        self.fields_update(update_list)
                        self.styles_update(styles)
                        del cn_line['fields']
                        del cn_line['styles']
                        if '$$hashKey' in cn_line:
                            del cn_line['$$hashKey']
                        cn_line['bg_color'] = bg_color
                        sql_data = "update qpex_onboard_sections set "
                        for key, value in cn_line.items():
                            if key == 'field_block_id':
                                field_block_id = str(value)
                            if key == 'style_block_id':
                                style_block_id = str(value)
                            if key == 'language':
                                language = str(value)
                            sql_data += str(key)+"="
                            sql_data += self.encode_value(value, True)
                            sql_data += ","
                        sql_data += "last_update_date=sysdate"
                        sql_data += " where field_block_id ="
                        sql_data += field_block_id
                        sql_data += " and style_block_id ="
                        sql_data += style_block_id
                        sql_data += " and language ="
                        sql_data += "'" + language + "'"
                        self.cursor.execute(sql_data)
                        sql_data = ""
        except Exception as error:
            logger.findaylog("""@ 841 EXCEPTION - models - onboard -
                 put """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - put(-)')
        return {'status': 'success', 'field_ids': field_ids}

    def fields_update(self, val_list):
        logger.addinfo('@ models - onboard - fields_update(+)')
        field_id = ''
        try:
            for line in val_list:
                if '$$hashKey' in line:
                    del line['$$hashKey']
                if line['value'] or line['value'] == '':
                    del line['value']
                sql_data = "update qpex_onboard_fields set "
                for key, value in line.items():
                    if key == 'field_id':
                        field_id = str(value)
                    if key == 'block_id':
                        block_id = str(value)
                    if key == 'language':
                        language = str(value)
                    if key != 'field_count':
                        sql_data += str(key)+"="
                        sql_data += self.encode_value(value, True)
                        sql_data += ","
                sql_data += "last_update_date=sysdate"
                sql_data += " where field_id ="
                sql_data += field_id
                sql_data += " and block_id ="
                sql_data += block_id
                sql_data += " and language ="
                sql_data += "'" + language + "'"
                self.cursor.execute(sql_data)
                sql_data = ""
        except Exception as error:
            self.release()
            logger.findaylog("""@ 543 EXCEPTION - models - onboard -
                 fields_update """ + str(error))
            raise error
        logger.addinfo('@ models - onboard - fields_update(-)')
        return 'success'

    def styles_update(self, val_list):
        logger.addinfo('@ models - onboard - styles_update(+)')
        style_id = ''
        try:
            for line in val_list:
                if '$$hashKey' in line:
                    del line['$$hashKey']
                sql_data = "update qpex_onboard_styles set "
                for key, value in line.items():
                    if key == 'style_id':
                        style_id = str(value)
                    if key == 'block_id':
                        block_id = str(value)
                    sql_data += str(key)+"="
                    if isinstance(value, str):
                        sql_data += "'"
                    if value is not None:
                        tmp = str(value)
                        if "'" in tmp:
                            t_value = tmp.replace("'", "''")
                            sql_data += t_value
                        else:
                            sql_data += tmp
                    if isinstance(value, str):
                        sql_data += "'"
                    sql_data += ","
                sql_data += "last_update_date=sysdate"
                # sql_data = sql_data[:-1]
                sql_data += " where style_id ="
                sql_data += style_id
                sql_data += " and block_id ="
                sql_data += block_id
                self.cursor.execute(sql_data)
                sql_data = ""
        except Exception as error:
            self.release()
            logger.findaylog("""@ 587 EXCEPTION - models - onboard -
                 styles_update """ + str(error))
            raise error
        logger.addinfo('@ models - onboard - styles_update(-)')
        return 'success'

    def insert_field(self, fields_list):
        logger.addinfo('@ models - onboard - insert_field(+)')
        line_details = []
        try:
            fieldname_strng = ""
            parameter_strng = ""
            row_list = []
            for cn_line in fields_list:
                if cn_line['field_id'] == '':
                    query = self.sql_file['onboard_field_sequence']
                    data = self.cursor.execute(query).fetchone()
                    cn_line['field_id'] = data[0]
                    obj = {}
                    obj['field_id'] = data[0]
                    obj['block_id'] = cn_line['block_id']
                    obj['name'] = cn_line['name']
                    line_details.append(obj)
                if cn_line['value'] == '':
                    del cn_line['value']
                if '$$hashKey' in cn_line:
                    del cn_line['$$hashKey']
                if 'field_count' in cn_line:
                    del cn_line['field_count']
                temp_line = cn_line
                my_data = []
                for key, value in cn_line.items():
                    my_data.append(self.encode_value(value, False))
                    values = tuple(my_data)
                row_list.append(values)
            if fields_list:
                dict_val = temp_line
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"
            self.cursor.prepare("""insert into
            qpex_onboard_fields """ + fieldname_strng+"""
            values""" + parameter_strng)
            self.cursor.executemany(None, row_list)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 644 EXCEPTION - models - onboard -
                 insert_field """ + str(error))
            raise error
        logger.addinfo('@ models - onboard - insert_field(-)')
        return line_details

    def get_labels(self, language):
        logger.addinfo('@ models - onboard - get_labels(+)')
        try:
            self.acquire()
            query = self.sql_file['labels_query']
            self.cursor.execute(query, p_language=language)
        except Exception as error:
            logger.findaylog("""@ 660 EXCEPTION - models - onboard -
                 get_labels """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    if field == 'field_block_id':
                        sub_list = self.get_field_labels(row[index],
                                                         language)

                        label['field_labels'] = sub_list
                    label[field] = self.decode_value(row[index])
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_labels(-)')
        return labels_list

    def get_field_labels(self, block_id, language):
        logger.addinfo('@ models - onboard - get_field_labels(+)')
        try:
            self.acquire()
            query = self.sql_file['field_labels_query']
            self.cursor.execute(query,
                                p_block_id=block_id,
                                p_language=language)
        except Exception as error:
            logger.findaylog("""@ 693 EXCEPTION - models - onboard -
                 get_field_labels """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = self.decode_value(row[index])
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_field_labels(-)')
        return labels_list

    def section_labels_update(self, val_list):
        logger.addinfo('@ models - onboard - section_labels_update(+)')
        flag = 0
        try:
            self.acquire()
            for line in val_list:
                if '$$hashKey' in line:
                    del line['$$hashKey']
                if line['field_labels']:
                    self.field_labels_update(line['field_labels'])
                    del line['field_labels']
                sql_data = "update qpex_onboard_sections_labels set "
                for key, value in line.items():
                    if key == 'field_block_id':
                        field_block_id = str(value)
                    sql_data += str(key)+"="
                    sql_data += self.encode_value(value, True)
                    sql_data += ","
                sql_data = sql_data[:-1]
                sql_data += " where field_block_id ="
                sql_data += field_block_id
                self.cursor.execute(sql_data)
                sql_data = ""
        except Exception as error:
            flag = 1
            logger.findaylog("""@ 737 EXCEPTION - models - onboard -
                 section_labels_update """ + str(error))
            raise error
        finally:
            if flag == 0:
                self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - fields_update(-)')
        return 'success'

    def field_labels_update(self, val_list):
        logger.addinfo('@ models - onboard - field_labels_update(+)')
        field_id = ''
        try:
            for line in val_list:
                if '$$hashKey' in line:
                    del line['$$hashKey']
                sql_data = "update qpex_onboard_field_labels set "
                for key, value in line.items():
                    if key == 'field_id':
                        field_id = str(value)
                    if key == 'block_id':
                        block_id = str(value)
                    sql_data += str(key)+"="
                    sql_data += self.encode_value(value, True)
                    sql_data += ","
                sql_data = sql_data[:-1]
                sql_data += " where field_id ="
                sql_data += field_id
                sql_data += " and block_id ="
                sql_data += block_id
                self.cursor.execute(sql_data)
                sql_data = ""
        except Exception as error:
            self.release()
            logger.findaylog("""@ 775 EXCEPTION - models - onboard -
                 field_labels_update """ + str(error))
            raise error
        logger.addinfo('@ models - onboard - field_labels_update(-)')
        return 'success'

    def search(self, jsond):
        logger.addinfo('@ models - onboard - search(+)')
        try:
            self.acquire()
            query = self.sql_file['products_search_query']
            key = '%' + jsond['key'] + '%'
            self.cursor.execute(query, p_key=key, p_animal=jsond['animal'],
                                p_WET_OR_DRY=jsond['wet_or_dry'],
                                p_language=jsond['language'])
        except Exception as error:
            logger.findaylog("""@ 794 EXCEPTION - models - onboard -
                search """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = self.decode_value(row[index])
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - search(-)')
        return labels_list

    # def insert_section_labels(self, fields_list, language, connection):
    #     logger.addinfo('@ models - onboard - insert_section_labels(+)')
    #     cursor = None
    #     try:
    #         cursor = connection.cursor()
    #         fieldname_strng = ""
    #         parameter_strng = ""
    #         row_list = []
    #         for cn_line in fields_list:
    #             if 'label' in cn_line:
    #                 cn_line['language'] = language
    #             if '$$hashKey' in cn_line:
    #                 del cn_line['$$hashKey']
    #             temp_line = cn_line
    #             my_data = []
    #             for key, value in cn_line.iteritems():
    #                 my_data.append(value)
    #                 values = tuple(my_data)
    #             row_list.append(values)
    #         if fields_list:
    #             dict_val = temp_line
    #             fieldname_strng += "("
    #             indx_value = 1
    #             parameter_strng += "("
    #             for key, value in dict_val.iteritems():
    #                 fieldname_strng += str(key)+','
    #                 parameter_strng += ":"+str(indx_value)+','
    #                 indx_value = indx_value+1
    #             fieldname_strng = fieldname_strng[:-1]
    #             parameter_strng = parameter_strng[:-1]
    #             fieldname_strng += ")"
    #             parameter_strng += ")"
    #         cursor.prepare("""insert into
    #         qpex_onboard_sections_labels """ + fieldname_strng+"""
    #         values""" + parameter_strng)
    #         cursor.executemany(None, row_list)
    #     except Exception as error:
    #         db_util.release_connection(connection)
    #         logger.findaylog("""@ 1271 EXCEPTION - models - onboard -
    #              insert_section_labels """ + str(error.message))
    #         raise error
    #         return "false"
    #     finally:
    #         if cursor is not None:
    #             cursor.close()
    #     logger.addinfo('@ models - onboard - insert_section_labels(-)')
    #     return "success"

    # def insert_field_labels(self, fields_list, language, connection):
    #     logger.addinfo('@ models - onboard - insert_field_labels(+)')
    #     cursor = None
    #     try:
    #         cursor = connection.cursor()
    #         fieldname_strng = ""
    #         parameter_strng = ""
    #         row_list = []
    #         for cn_line in fields_list:
    #             cn_line['language'] = language
    #             if '$$hashKey' in cn_line:
    #                 del cn_line['$$hashKey']
    #             temp_line = cn_line
    #             my_data = []
    #             for key, value in cn_line.iteritems():
    #                 my_data.append(value)
    #                 values = tuple(my_data)
    #             row_list.append(values)
    #         if fields_list:
    #             dict_val = temp_line
    #             fieldname_strng += "("
    #             indx_value = 1
    #             parameter_strng += "("
    #             for key, value in dict_val.iteritems():
    #                 fieldname_strng += str(key)+','
    #                 parameter_strng += ":"+str(indx_value)+','
    #                 indx_value = indx_value+1
    #             fieldname_strng = fieldname_strng[:-1]
    #             parameter_strng = parameter_strng[:-1]
    #             fieldname_strng += ")"
    #             parameter_strng += ")"
    #         cursor.prepare("""insert into
    #         qpex_onboard_field_labels """ + fieldname_strng+"""
    #         values""" + parameter_strng)
    #         cursor.executemany(None, row_list)
    #     except Exception as error:
    #         db_util.release_connection(connection)
    #         logger.findaylog("""@ 1325 EXCEPTION - models - onboard -
    #              insert_field_labels """ + str(error.message))
    #         raise error
    #         return "false"
    #     finally:
    #         if cursor is not None:
    #             cursor.close()
    #     logger.addinfo('@ models - onboard - insert_field_labels(-)')
    #     return "success"

    def get_section_id(self):
        logger.addinfo('@ models - onboard - get_section_id(+)')
        try:
            self.acquire()
            query = self.sql_file['get_section_query']
            id = self.cursor.execute(query).fetchone()
        except Exception as error:
            logger.findaylog("""@ 919 EXCEPTION - models - onboard -
                 get_section_id """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_section_id(-)')
        if id is not None:
            return id[0]
        else:
            id = []
            return id

    def post_language(self, jsond, bg_color):
        logger.addinfo('@ models - onboard - post_language(+)')
        flag = 0
        sections = jsond['sections']
        del jsond['sections']
        if 'language' in jsond:
            del jsond['language']
        if 'new_language' in jsond:
            del jsond['new_language']
        try:
            fieldname_strng = ""
            parameter_strng = ""
            row_list = []
            self.acquire()
            for cn_line in sections:
                self.insert_fields_language(cn_line['fields'])
                del cn_line['fields']
                del cn_line['styles']
                cn_line['bg_color'] = bg_color
                temp_line = cn_line
                values = []
                for key, value in cn_line.items():
                    values.append(self.encode_value(value, True))
                row_list.append(tuple(values))
            if sections:
                dict_val = temp_line
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"
            else:
                return 'fails'
            self.cursor.prepare("""insert into
            qpex_onboard_sections """ + fieldname_strng+"""
            values""" + parameter_strng)
            self.cursor.executemany(None, row_list)
        except Exception as error:
            flag = 1
            logger.findaylog("""@ 977 EXCEPTION - models - onboard -
                 post_language """ + str(error))
            raise error
        finally:
            if flag == 0:
                self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - post_language(-)')
        return "language_success"

    def insert_fields_language(self, fields_list):
        logger.addinfo('@ models - onboard - insert_fields(+)')
        try:
            fieldname_strng = ""
            parameter_strng = ""
            row_list = []
            for cn_line in fields_list:
                if 'field_id' not in cn_line:
                    query = self.sql_file['onboard_field_sequence']
                    data = self.cursor.execute(query).fetchone()
                    cn_line['field_id'] = data[0]
                if 'value' in cn_line:
                    del cn_line['value']
                temp_line = cn_line
                my_data = []
                for key, value in cn_line.items():
                    my_data.append(self.decode_value(value))
                    values = tuple(my_data)
                row_list.append(values)
            if fields_list:
                dict_val = temp_line
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"
            self.cursor.prepare("""insert into
            qpex_onboard_fields """ + fieldname_strng+"""
            values""" + parameter_strng)
            self.cursor.executemany(None, row_list)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1029 EXCEPTION - models - onboard -
                 insert_fields_language """ + str(error))
            raise error
        logger.addinfo('@ models - onboard - insert_fields(-)')
        return "success"

    def get_product_details(self, jsond):
        logger.addinfo('@ models - onboard - get_product_details(+)')
        labels_list = []
        try:
            self.acquire()
            query = self.sql_file['get_segment_details_query']
            ptype = jsond['type']
            self.cursor.execute(query, p_type=jsond['type'],
                                p_segment_id=jsond['segment_id'],
                                p_language=jsond['language'],
                                p_product_id=jsond['product_id'])
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    if ptype == 'segment' and field == 'brand_logo':
                        if row[index] is not None:
                            label[field] = row[index].read()
                    else:
                        label[field] = row[index]
                labels_list.append(label)
            if len(labels_list) <= 0:
                list = self.get_sections(jsond['type'], jsond['language'])
                labels_list = {}
                labels_list['segment_id'] = jsond['segment_id']
                labels_list['sections'] = list
                labels_list['language'] = jsond['language']
                labels_list['type'] = jsond['type']
                labels_list['new'] = 'Y'
        except Exception as error:
            logger.findaylog("""@ 1068 EXCEPTION - models - onboard -
                 get_product_details """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_product_details(-)')
        return labels_list

    def get_sections(self, pet_type, language):
        logger.addinfo('@ models - onboard - get_sections(+)')
        try:
            query = self.sql_file['get_segments_data_query']
            self.cursor.execute(query, p_type=pet_type, p_language=language)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1084 EXCEPTION - models - onboard -
                 get_sections """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            data = self.cursor.fetchall()
            for row in data:
                label = {}
                for index, field in enumerate(field_names):
                    if field == 'field_block_id':
                        result = self.get_field_details(row[index],
                                                        language)
                        label['fields'] = result
                        label['field_block_id'] = row[index]
                    label[field] = self.decode_value(row[index])
                labels_list.append(label)
        logger.addinfo('@ models - onboard - get_sections(-)')
        return labels_list

    def get_field_details(self, block_id, language):
        logger.addinfo('@ models - onboard - get_field_details(+)')
        try:
            query = self.sql_file['get_fields_data_query']
            self.cursor.execute(query,
                                p_block_id=block_id,
                                p_language=language)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1117 EXCEPTION - models - onboard -
                 get_field_details """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = self.decode_value(row[index])
                labels_list.append(label)
        logger.addinfo('@ models - onboard - get_field_details(-)')
        return labels_list

    def post_segments(self, jsond):
        logger.addinfo('@ models - outofdoor - post_segements(+)')
        fieldname_strng = ""
        parameter_strng = ""
        flag = True
        try:
            block_type = jsond['type']
            sections = jsond['sections']
            language = jsond['language']
            brand_id = jsond['brand_id']
            brand_name = jsond['brand_name']
            segment_id = jsond['segment_id']
            segment_name = jsond['segment_name']
            image_url = jsond['image_url']
            description = jsond['description']
            newrecipe = jsond['newrecipe']
            product_id = jsond['product_id']
            product_name = jsond['product_name']
            brand_logo = jsond['brand_logo']
            segment_image_url = jsond['segment_image_url']
            file_name = jsond['file_name']
            is_active = jsond['is_active']
            temp_list = []
            if block_type == 'product' and 'product_image' in jsond:
                self.insert_product_image(jsond['product_image'])
            for i in sections:
                if 'fields' in i:
                    for j in i['fields']:
                        temp_list.append(j)
            for p_line in temp_list:
                p_line['language'] = language
                p_line['brand_id'] = brand_id
                p_line['brand_name'] = brand_name
                p_line['segment_id'] = segment_id
                p_line['segment_name'] = segment_name
                p_line['image_url'] = image_url
                p_line['description'] = description
                p_line['newrecipe'] = newrecipe
                p_line['type'] = block_type
                p_line['product_id'] = product_id
                p_line['product_name'] = product_name
                p_line['segment_image_url'] = segment_image_url
                p_line['file_name'] = file_name
                p_line['is_active'] = is_active
            if len(temp_list) > 0:
                dict_val = temp_list[0]
                fieldname_strng += "("
                parameter_strng += "("
                for key, value in dict_val.items():
                    if key == 'field_id':
                        field_id = str(value)
                    fieldname_strng += str(key) + ','
                    parameter_strng += ":" + str(key) + ','
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"

            self.acquire()
            self.cursor.setinputsizes(value=cx_Oracle.NCHAR,
                                      description=cx_Oracle.NCHAR)
            self.cursor.prepare("""insert into
            qpex_onboard_segments  """ + fieldname_strng+"""
            values""" + parameter_strng)
            self.cursor.executemany(None, temp_list)
            if brand_logo is not None and brand_logo != '':
                self.cursor.setinputsizes(p_base64=cx_Oracle.BLOB)
            query = self.sql_file['update_brand_logo']
            self.cursor.execute(query, p_base64=brand_logo,
                                p_segment_id=segment_id,
                                p_field_id=field_id,
                                p_language=language)

        except Exception as error:
            flag = False
            logger.findaylog("""@ 1210 EXCEPTION - models - outofdoor -
                 post_segements """ + str(error))
            raise error
        finally:
            if flag:
                self.connection.commit()
            self.release()
        logger.addinfo('@ models - outofdoor - post_segements(-)')
        if block_type == 'segment':
            return "success"
        else:
            return "success-product"

    # def get_agents(self):
    #     logger.addinfo('@ models - onboard - get_agents(+)')
    #     con = None
    #     cur = None
    #     try:
    #         con = db_util.get_connection()
    #         cur = con.cursor()
    #         query = self.sql_file['get_agents_query']
    #         cur.execute(query)
    #     except Exception as error:
    #         logger.findaylog("""@ 1676 EXCEPTION - models - onboard -
    #              get_agents """ + str(error.message))
    #         raise error
    #     else:
    #         items_list = []
    #         field_names = [a[0].lower() for a in cur.description]
    #         for row in cur:
    #             item = Onboard()
    #             for index, field in enumerate(field_names):
    #                 setattr(item, field, row[index])
    #             items_list.append(item)
    #     finally:
    #         cur.close()
    #         db_util.release_connection(con)
    #     logger.addinfo('@ models - onboard - get_agents(-)')
    #     return items_list

    # def get_agent_revenue(self, agent_name):
    #     logger.addinfo('@ models - onboard - get_agents(+)')
    #     con = None
    #     cur = None
    #     try:
    #         con = db_util.get_connection()
    #         cur = con.cursor()
    #         query = self.sql_file['onboard_agent_revenue']
    #         cur.execute(query, p_agent_name=agent_name)
    #     except Exception as error:
    #         logger.findaylog("""@ 1705 EXCEPTION - models - onboard -
    #              get_agents """ + str(error.message))
    #         raise error
    #     else:
    #         items_list = []
    #         field_names = [a[0].lower() for a in cur.description]
    #         for row in cur:
    #             item = Onboard()
    #             for index, field in enumerate(field_names):
    #                 setattr(item, field, row[index])
    #             items_list.append(item)
    #     finally:
    #         cur.close()
    #         db_util.release_connection(con)
    #     logger.addinfo('@ models - onboard - get_agents(-)')
    #     return items_list

    def onboard_language(self, jsond):
        logger.addinfo('@ models - onboard - onboard_language(+)')
        try:
            if jsond:
                self.acquire()
                language = jsond['language']
                language_id = jsond['language_id']
                query = self.sql_file['onboard_save_language']
                self.cursor.execute(query, p_language=language,
                                    p_language_id=language_id)
                self.connection.commit()
            else:
                return 'Fails'
        except Exception as error:
            logger.findaylog("""@ 1292 EXCEPTION - models - onboard -
                 onboard_language """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo("@ models - onboard - onboard_language(-)")
        return 'success'

    def get_language(self):
        logger.addinfo('@ models - onboard - get_language(+)')
        try:
            self.acquire()
            query = self.sql_file['language_query']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1308 EXCEPTION - models - onboard -
                 get_language """ + str(error))
            raise error
        else:
            language_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                brand = {}
                for index, field in enumerate(field_names):
                    brand[field] = self.decode_value(row[index])
                language_list.append(brand)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_language(-)')
        return language_list

    def put_product_details(self, val_list):
        logger.addinfo('@ models - onboard - put_product_details(+)')
        field_id = ''
        language = ''
        language = val_list['language']
        sections = val_list['sections']
        image_url = val_list['image_url']
        description = val_list['description']
        product_id = val_list['product_id']
        segment_id = val_list['segment_id']
        newrecipe = val_list['newrecipe']
        product_type = val_list['type']
        brand_id = val_list['brand_id']
        brand_name = val_list['brand_name']
        segment_name = val_list['segment_name']
        product_name = val_list['product_name']
        is_active = val_list['is_active']
        tmp_list = []
        flag = 0
        new_fields = []
        try:
            self.acquire()
            file_name = val_list['file_name']
            brand_logo = ''
            if val_list['type'] == 'product' and 'product_image' in val_list:
                self.insert_product_image(val_list['product_image'])
            if val_list['brand_logo']:
                brand_logo = val_list['brand_logo']
            segment_image_url = val_list['segment_image_url']
            for line in sections:
                for i in line['fields']:
                    i['image_url'] = image_url
                    i['description'] = description
                    i['newrecipe'] = newrecipe
                    i['segment_image_url'] = segment_image_url
                    i['file_name'] = file_name
                    i['is_active'] = is_active
                    tmp_list.append(i)
            for k in tmp_list:
                sql_data = 'update qpex_onboard_segments set '
                for key, val in k.items():
                    if key != 'value' and key != 'description':
                        if key == 'field_id':
                            field_id = str(val)
                        sql_data += str(key)+"="
                        sql_data += self.encode_value(val, True)
                        sql_data += ","
                    elif key == 'value':
                        field_value = val
                        sql_data += 'value = :p_value'
                        sql_data += ','
                    else:
                        product_description = val
                        sql_data += 'description = :p_description'
                        sql_data += ','
                sql_data += 'brand_logo = :p_base64'
                sql_data += ","
                sql_data += 'last_update_date=sysdate'
                self.cursor.setinputsizes(p_value=cx_Oracle.NCHAR)
                self.cursor.setinputsizes(p_description=cx_Oracle.NCHAR)
                if brand_logo:
                    self.cursor.setinputsizes(p_base64=cx_Oracle.BLOB)
                # else:
                #     sql_data = sql_data[:-1]
                sql_data += " where field_id = '"
                sql_data += field_id + "'"
                product_id = str(product_id)
                if product_id:
                    sql_data += " and product_id = '"
                    sql_data += product_id + "'"
                sql_data += " and segment_id = '"
                sql_data += str(segment_id) + "'"
                sql_data += " and language ="
                sql_data += "'" + str(language) + "'"
                self.cursor.execute(sql_data,
                                    p_base64=brand_logo,
                                    p_value=field_value,
                                    p_description=product_description)
                self.connection.commit()
                if self.cursor.rowcount == 0:
                    fields = {"value": k['value'],
                              "field_id": k['field_id'],
                              "field_block_id": k['field_block_id']
                              }
                    new_fields.append(fields)

            if len(new_fields) > 0:
                field_query = self.sql_file['field_query']
                p_product_id = ''
                if product_id:
                    p_product_id = product_id
                field_query = field_query % (',' .join([str(
                                             new_fields[i]['field_id'])
                    for i in range(len(new_fields))]))

                # check if field_ids exists for the product
                self.cursor.execute(field_query,
                                    p_segment_id=str(segment_id),
                                    p_product_id=p_product_id,
                                    p_language=str(language))
                field_ids = self.cursor.fetchall()
                temp_fields = []

                # insert if field_ids not in database
                for i in range(len(new_fields)):
                    if new_fields[i]['field_id'] not in field_ids:
                        temp_fields.append({'fields': [new_fields[i]]})
                if len(temp_fields) > 0:
                    flag = 1
                    jsond = {}
                    jsond['sections'] = temp_fields
                    jsond['type'] = product_type
                    jsond['language'] = language
                    jsond['brand_id'] = brand_id
                    jsond['brand_name'] = brand_name
                    jsond['segment_name'] = segment_name
                    jsond['segment_id'] = segment_id
                    jsond['image_url'] = image_url
                    jsond['description'] = description
                    jsond['newrecipe'] = newrecipe
                    jsond['product_id'] = product_id
                    jsond['product_name'] = product_name
                    jsond['segment_image_url'] = segment_image_url
                    jsond['brand_logo'] = brand_logo
                    jsond['file_name'] = file_name
                    jsond['is_active'] = is_active
                    self.post_segments(jsond)
        except Exception as error:
            flag = 0
            logger.findaylog("""@ 1454 EXCEPTION - models - onboard -
                 put_product_details """ + str(error))
            raise error
        finally:
            if flag == 0:
                self.release()
        logger.addinfo('@ models - onboard - put_product_details(-)')
        return 'success'

    def get_product_pdf_details(self, jsond):
        logger.addinfo('@ models - onboard - get_product_details(+)')
        data = jsond['data']
        language = jsond['language']
        is_active = jsond['is_active']
        prod_str = ''
        seg_str = ''
        try:
            self.acquire()
            for i in data:
                seg_str += str(i['segment_id']) + ','
                prod_str += "'" + str(i['item_code']) + "',"
            prod_str = prod_str[:-1]
            seg_str = seg_str[:-1]
            query = self.sql_file['get_product_details_query']
            query = query % (seg_str, prod_str)
            self.cursor.execute(query, p_language=language,
                                p_active=is_active)
            field_names = [a[0].lower() for a in self.cursor.description]
            data = self.cursor.fetchall()
            segment_details = self.get_segment_details(seg_str, language)
            style_details = self.get_style_details()
        except Exception as error:
            logger.findaylog("""@ 1489 EXCEPTION - models - onboard -
                 get_product_pdf_details """ + str(error))
            raise error
        else:
            labels_list = []
            for row in data:
                label = {}
                for i in range(len(field_names)):
                    if field_names[i] == 'brand_logo' and row[i] is not None:
                        label[field_names[i]] = row[i].read()
                    else:
                        label[field_names[i]] = self.decode_value(row[i])
                labels_list.append(label)
            final = {}
            final['products'] = labels_list
            final['segments'] = segment_details
            final['styles'] = style_details
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_product_details(-)')
        return final

    def get_segment_details(self, seg_str, language):
        logger.addinfo('@ models - onboard - get_segment_details(+)')
        try:
            query = self.sql_file['get_segment_lines']
            query = query % (seg_str)
            self.cursor.execute(query, p_language=language)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1520 EXCEPTION - models - onboard -
                 get_segement_details """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            brand_logos = []
            for row in self.cursor:
                label = {}
                segment_id = ''
                segment_index = -1
                f_brand_logo = ''
                for i in range(len(field_names)):
                    if field_names[i] == 'brand_logo' and row[i] is not None:
                        if segment_index != -1 and brand_logos[
                                segment_index]['brand_logo']:
                            label[field_names[i]] = brand_logos[
                                segment_index][
                                'brand_logo']
                        else:
                            f_brand_logo = row[i].read()
                            label[field_names[i]] = f_brand_logo
                            if segment_index != -1 and not brand_logos[
                                    segment_index]['brand_logo']:
                                brand_logos[segment_index][
                                    'brand_logo'] = f_brand_logo
                    else:
                        if field_names[i] == 'segment_id':
                            segment_id = row[i]
                            segment_index = self.get_segment_index(
                                brand_logos,
                                segment_id)
                            if segment_index == -1:
                                brand_logos.append(
                                    {'segment_id': row[i],
                                     'brand_logo': ''})
                        label[field_names[i]] = self.decode_value(row[i])
                labels_list.append(label)
        logger.addinfo('@ models - onboard - get_segment_details(-)')
        return labels_list

    def get_segment_index(self, brand_logos, segment_id):
        logger.addinfo('@ modesl -onboard - get_segment_index(+)')
        try:
            try:
                index = [str(logo['segment_id'])
                         for logo in brand_logos].index(str(segment_id))
            except Exception:
                index = -1
        except Exception as e:
            logger.findaylog(""" @ 1574 EXCEPTION - onboard - models -
                            get_segment_index """ + str(e))
            raise e
        return index

    def get_style_details(self):
        logger.addinfo('@ models - onboard - get_styles(+)')
        try:
            query = self.sql_file['styles_query']
            self.cursor.execute(query)
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for i in range(len(field_names)):
                    label[field_names[i]] = self.decode_value(row[i])
                labels_list.append(label)
        except Exception as error:
            self.release()
            logger.findaylog("""@ 1597 EXCEPTION - models - onboard -
                 get_styles """ + str(error))
            raise error
        logger.addinfo('@ models - onboard - get_styles(-)')
        return labels_list

    def copia_search(self, jsond):
        logger.addinfo('@ models - onboard - search(+)')
        try:
            self.acquire()
            query_temp = self.sql_file['products_search_query2']
            ids = jsond['ids']
            string = ''
            for i in ids:
                string = string + i + ','
            string = string[:-1]
            salesrep_query = query_temp % (',' . join([str("'"+ids[i]+"'") for
                                           i in range(len(ids))]))
            self.cursor.execute(salesrep_query, p_language=jsond['language'])
        except Exception as error:
            logger.findaylog("""@ 1618 EXCEPTION - models - onboard -
                copia_search """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = self.decode_value(row[index])
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - search(-)')
        return labels_list

    def search_multiple(self, jsond):
        logger.addinfo('@ models - onboard - search_multiple(+)')
        try:
            self.acquire()
            query = self.sql_file['products_search_query']
            ids = jsond['ids']
            labels_list = []
            for i in ids:
                key = '%' + i + '%'
                self.cursor.execute(query, p_key=key, p_animal='',
                                    p_WET_OR_DRY='',
                                    p_language=jsond['language'])
                field_names = [a[0].lower() for a in self.cursor.description]
                for row in self.cursor:
                    label = {}
                    for index, field in enumerate(field_names):
                        label[field] = self.decode_value(row[index])
                    labels_list.append(label)
            uniq = []
            if len(labels_list) > 0:
                data = ujson.loads(ujson.dumps(labels_list))
                uniq = [dict(t) for t in set([tuple(d.items()) for d in data])]
        except Exception as error:
            logger.findaylog("""@ 1658 EXCEPTION - models - onboard -
                search_multiple """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - onboard - search_multiple(-)')
        return uniq

    def put_language(self, jsond):
        logger.addinfo('@ models - onboard - put_language(+)')
        status = None
        try:
            self.acquire()
            if jsond['language_id']:
                query = self.sql_file['onboard_update_language']
                query = query.format(jsond['language_id'],
                                     jsond['new_language'],
                                     jsond['language'])
                self.cursor.execute(query)
                status = 'success'
            else:
                status = 'Fails'
        except Exception as error:
            logger.findaylog("""@ 1682 EXCEPTION - models - onboard -
                 put_language """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo("@ models - onboard - put_language(-)")
        return status

    def delete_language(self, language_id):
        logger.addinfo('@ models - onboard - delete_language(+)')
        try:
            if language_id:
                self.acquire()
                query = self.sql_file['onboard_delete_language']
                self.cursor.execute(query, p_language_id=language_id)
                status = 'success'
            else:
                status = 'Fails'
        except Exception as error:
            logger.findaylog("""@ 1703 EXCEPTION - models - onboard -
                 delete_language """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo("@ models - onboard - delete_language(-)")
        return status

    def get_details(self, language):
        logger.addinfo('@ models - onboard - get_details(+)')
        try:
            self.acquire()
            query = self.sql_file['product_onboard_get_details']
            if language:
                query += " where language = '" + language + "'"
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1724 EXCEPTION - models - onboard -
                 get_details """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = self.decode_value(row[index])
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_details(-)')
        return labels_list

    def post_details(self, jsond):
        logger.addinfo('@ models - onboard - post_details(+)')
        details_data = jsond['data']
        try:
            self.acquire()
            fieldname_strng = ''
            parameter_strng = ''
            cus_data = []
            for c_line in details_data:
                values = tuple(val for key, val in c_line.items())
                temp_line = c_line
                cus_data.append(values)
            dict_val = temp_line
            fieldname_strng += "("
            indx_value = 1
            parameter_strng += "("
            for key, value in dict_val.items():
                fieldname_strng += str(key)+','
                parameter_strng += ":"+str(indx_value)+','
                indx_value = indx_value+1
            fieldname_strng = fieldname_strng[:-1]
            parameter_strng = parameter_strng[:-1]
            fieldname_strng += ")"
            parameter_strng += ")"
            self.cursor.prepare("""insert into
            QPEX_ONBOARD_DETAILS """ + fieldname_strng+"""
            values""" + parameter_strng)
            self.cursor.executemany(None, cus_data)
        except Exception as error:
            logger.findaylog("""@ 1772 EXCEPTION - models - onboard -
                 post_details """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - post_details(-)')
        return "success"

    def put_details(self, jsond):
        logger.addinfo('@ models - onboard - put_details(+)')
        details_data = jsond['data']
        try:
            self.acquire()
            for line in details_data:
                sql_data = "update QPEX_ONBOARD_DETAILS set "
                for key, value in line.items():
                    if key == 'language':
                        language = str(value)
                    sql_data += str(key)+"="
                    sql_data += "'"
                    sql_data += str(value)
                    sql_data += "'"
                    sql_data += ","
                sql_data = sql_data[:-1]
                sql_data += " where language ="
                sql_data += "'" + language + "'"
                self.cursor.execute(sql_data)
                sql_data = ""
        except Exception as error:
            logger.findaylog("""@ 1803 EXCEPTION - models - outofdoor -
                 put_details """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - outofdoor - update(-)')
        return 'success'

    def get_report(self):
        logger.addinfo('@ models - onboard - get_report(+)')
        try:
            self.acquire()
            query = self.sql_file['product_onboard_report']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1820 EXCEPTION - models - onboard -
                 get_report """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = row[index]
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_report(-)')
        return labels_list

    def get_report_purchasesegments(self):
        logger.addinfo('@ models - onboard - get_report_purchasesegments(+)')
        try:
            self.acquire()
            query = self.sql_file['onboard_purchase_segments']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1844 EXCEPTION - models - onboard -
                 get_report_purchasesegments """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = row[index]
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_report_purchasesegments(-)')
        return labels_list

    def get_report_salessegments(self):
        logger.addinfo('@ models - onboard - get_report_salessegments(+)')
        try:
            self.acquire()
            query = self.sql_file['onboard_sales_segments']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1868 EXCEPTION - models - onboard -
                 get_report_salessegments """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = row[index]
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_report_salessegments(-)')
        return labels_list

    def get_report_promozioni(self):
        logger.addinfo('@ models - onboard - get_report_promozioni(+)')
        try:
            self.acquire()
            query = self.sql_file['onboard_promozioni']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1892 EXCEPTION - models - onboard -
                 get_report_promozioni """ + str(error))
            raise error
        else:
            labels_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                label = {}
                for index, field in enumerate(field_names):
                    label[field] = row[index]
                labels_list.append(label)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_report_promozioni(-)')
        return labels_list

    def update_itemcategories(self, jsond):
        logger.addinfo('@ models - onboard - update_itemcategories(+)')
        try:
            self.acquire()
            item_ids = []
            status_code = ''
            for j in range(len(jsond)):
                status_code = self.cursor.var(cx_Oracle.STRING)
                if 'old_category_id' in jsond[j]:
                    self.cursor.execute("""
                        begin
                            qpex_category_pkg.update_category(
                                :p_category_set_id,
                                :p_category_id,
                                :p_old_category_id,
                                :p_inventory_item_id,
                                :x_return_status
                            );
                        end; """, p_category_set_id=jsond[j][
                        'category_set_id'],
                        p_category_id=jsond[j]['category_id'],
                        p_old_category_id=jsond[j][
                        'old_category_id'],
                        p_inventory_item_id=jsond[j][
                        'inventory_item_id'],
                        x_return_status=status_code)
                else:
                    self.cursor.execute("""
                        begin
                            qpex_category_pkg.create_category(
                                :p_category_set_id,
                                :p_category_id,
                                :p_inventory_item_id,
                                :x_return_status
                            );
                            end; """, p_category_set_id=jsond[j][
                        'category_set_id'],
                        p_category_id=jsond[j]['category_id'],
                        p_inventory_item_id=jsond[j][
                        'inventory_item_id'],
                        x_return_status=status_code)
                if status_code.getvalue() != 'S':
                    item_ids.append(jsond[j]['item_code'])

        except Exception as error:
            logger.findaylog("""@ 2015 EXCEPTION - models - onboard -
                update_itemcategories """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - onboard - update_itemcategories(-)')
        return item_ids

    def pdf_html_template(self, jsond, pet_type, wet_or_dry,
                          brand_name, content):
        logger.addinfo('@ models - onboard - pdf_html_template(+)')
        try:
            obj = {}
            obj['language'] = jsond[0]['language']
            obj['brand_name'] = brand_name
            obj['pet_type'] = pet_type
            obj['wet_or_dry'] = wet_or_dry
            obj['path'] = self.sql_file['pdf_path']
            file_path = self.get_file_path(obj)

            options = {
                'page-size': 'A4',
                'quiet': '',
                'encoding': 'utf-8',
                'margin-bottom': '0mm',
                'margin-top': '3mm',
                'margin-left': '3mm',
                'margin-right': '3mm'
            }

            products = []
            url_heading = self.get_download_text(jsond[0]['language'])
            link_img = self.sql_file['link_img']
            new_product_image = self.sql_file['new_product_image']
            logo = self.sql_file['new_logo']

            for s in range(len(jsond)):
                product = {}
                product_image = self.get_product_image(jsond[s]['product_id'])
                sections = jsond[s]['sections']
                fields = sections[0]['fields']
                product_name = fields[0]['value']
                product_name += ' ' + fields[1]['value']
                column_one_blocks = []
                column_two_blocks = []
                column_three_blocks = []
                for i in range(len(sections)):
                    if i < 4:
                        # sections in first column
                        column_one_blocks.append(sections[i])
                    elif i >= 4 and i < 7:
                        # sections in second column
                        column_two_blocks.append(sections[i])
                    else:
                        # sections in third column
                        column_three_blocks.append(sections[i])
                blocks = [column_one_blocks, column_two_blocks,
                          column_three_blocks]
                description = ''
                if jsond[s]['description']:
                    description = jsond[s]['description']

                image_url = ''
                if jsond[s]['image_url']:
                    image_url = jsond[s]['image_url']

                product['url_heading'] = url_heading
                product['image_url'] = image_url
                product['description'] = description
                product['link_img'] = link_img
                if product_image:
                    product['base64'] = product_image[
                        'img_product'].encode('base64')
                else:
                    product['base64'] = ''
                product['logo'] = logo
                product['new_image'] = new_product_image
                product['product_name'] = product_name
                product['blocks'] = blocks
                product['newrecipe'] = jsond[s]['newrecipe']
                products.append(product)

            products_array = []
            for i in range(len(products)):
                composition_length = 0
                daily_serving_length = 0
                sections = products[i]['blocks'][1]
                for k in range(len(sections)):
                    fields = sections[k]['fields']
                    for f in range(len(fields)):
                        if fields[f]['value'] is not None:
                            value_length = len(fields[f]['value'])

                            # Composition fields length
                            if k == 0:
                                composition_length += value_length

                            # suggested daily serving fields length
                            elif k == 2:
                                daily_serving_length += value_length

                    if k == 0:
                        # set font size for compost field value
                        if composition_length > 700:
                            sections[k]['font_size'] = '15px'
                        elif composition_length > 500:
                            sections[k]['font_size'] = '16px'
                        else:
                            sections[k]['font_size'] = '17px'
                    if k == 2:
                        # set font size for suggested daily serving field value
                        if daily_serving_length > 400:
                            sections[k]['font_size'] = '15px'
                        else:
                            sections[k]['font_size'] = '16px'

                # composition_length - no.of characters in Composition fields
                # daily_serving_length - no.of characters in suggested serving
                if (composition_length > 750 and (
                        daily_serving_length > 400)) or (
                            composition_length > 2400) or (
                                daily_serving_length > 650) or (
                                    composition_length > 1250 and (
                                        daily_serving_length > 180)):
                    temp_products = deepcopy(products[i])
                    if composition_length > 2000:
                        compostion_blocks = products[i]['blocks'][1].pop(0)
                        # pop first section of second column and append
                        # first section to first page and last two sections to
                        # duplicate page
                        temp_products['blocks'][1] = products[i]['blocks'][1]
                        products[i]['blocks'][1] = [compostion_blocks]
                    else:
                        # pop the last section from the second column of pdf
                        daily_serving_block = products[i][
                            'blocks'][1].pop(2)

                        # duplicate the product & append only this last section
                        #  and generate as new product page
                        temp_products['blocks'][1] = [daily_serving_block]

                    products_array.append(products[i])
                    products_array.append(temp_products)
                else:
                    products_array.append(products[i])
            content = content.render(products=products_array)
            temp_file_name = '/tmp/detailpdf' + brand_name + pet_type
            temp_file_name += wet_or_dry + '.html'
            with io.open(temp_file_name, 'w',
                         encoding='utf-8') as changed:
                changed.write(content)
                changed.close()

            pdfkit.from_file(temp_file_name, file_path, options=options)
            if os.path.exists(temp_file_name):
                os.remove(temp_file_name)
        except Exception as e:
            logger.findaylog(""" @ 2112 EXCEPTION - models - onboard -
                             pdf_html_template """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - pdf_html_template(-)')
        return 'success'

    def get_block_data(self, ids, products, styles, block_type):
        logger.addinfo('@ models - onboard - get_block_data(+)')
        try:
            if block_type == 'product':
                field_label = 'product_id'
            else:
                field_label = 'segment_id'
            brand_segments = []
            for i in range(len(ids)):
                segments = []
                for j in range(len(products)):
                    if str(ids[i]) == str(products[j][field_label]):
                        block_id = str(products[j]['field_block_id'])
                        product_styles = []
                        for k in range(len(styles)):
                            if block_id == str(styles[k]['block_id']):
                                style = {'value': styles[k]['value'],
                                         'label': styles[k]['label']}
                                product_styles.append(style)
                        obj = {}
                        if products[j]['value'] is None:
                            obj['value'] = ''
                        else:
                            obj['value'] = products[j]['value']
                        if products[j]['label'] is None:
                            obj['label'] = ''
                        else:
                            obj['label'] = products[j]['label']
                        if len(segments) > 0:
                            try:
                                index = [str(segment['block_id'])
                                         for segment in segments].index(
                                    str(products[j]['field_block_id']))
                            except Exception:
                                index = -1
                            if index != -1:
                                segments[index]['fields'].append(obj)
                            else:
                                segments.append(
                                    {'block_id': products[j]['field_block_id'],
                                     'label': products[j]['segment_label'],
                                     'fields': [obj],
                                     'styles': product_styles})
                        else:
                            segments.append(
                                {
                                    'block_id': products[j]['field_block_id'],
                                    'label': products[j]['segment_label'],
                                    'fields': [obj],
                                    'styles': product_styles
                                }
                            )
                brand_segments.append(
                    {
                        field_label: ids[i],
                        'fields': segments
                    }
                )
        except Exception as e:
            logger.findaylog("""2184 EXCEPTION - models - onboard -
                get_block_data """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - get_block_data(-)')
        return brand_segments

    def get_segment_value(self, products, segments, label):
        logger.addinfo('@ models - onboard - get_segment_value(+)')
        try:
            segValue = ''
            temp_fields = []

            # label for suggested daily serving in italian and german
            I_label = 'Razione Giornaliera Indicativa'
            D_label = 'Tagesration'

            for i in range(len(products)):
                fields = products[i]['fields']
                temp_fields = []
                if len(fields) > 0:
                    for j in range(len(fields)):
                        if fields[j][
                                'label'] == I_label or fields[
                                j]['label'] == D_label:
                            if len(segments) > 0:
                                segValue = fields[j]['value']
                        else:
                            temp_fields.append(fields[j])
                    if len(temp_fields) == 0:
                        temp_fields.append({'label': '', 'value': ''})
                    products[i]['fields'] = temp_fields
                else:
                    fields.append({'label': '', 'value': ''})
                    products[i]['fields'] = fields
            if len(segments) > 0:
                for i in range(len(segments)):
                    if segments[i]['label'] == label:
                        fields = segments[i]['fields']
                        if segValue != '':
                            fields[0]['value'] = segValue
                            segments[i]['fields'] = fields
        except Exception as e:
            logger.findaylog(""" @ 2232 EXCEPTION - models - onboard -
                get_segment_value""" + str(e))
            raise e
        logger.addinfo('@ models - onboard - get_segment_value(-)')
        if label != '':
            return segments
        else:
            return products

    def get_brands_segments(self, brand, html_content):
        logger.addinfo('@ models - onboard - get_brands_segments(+)')
        all_products = []
        try:
            pdf_brand_name = brand['brand']
            language = brand['language']
            pet_type = brand['pet_type']
            wet_or_dry = brand['wet_or_dry']
            pdf_type = brand['pdf_type']
            blocks = brand['blocks']
            data = brand['active_segments']
            # To get segment_ids and product_ids in brand
            # data = self.get_segment_product_ids(
            #                             pdf_brand_name, pet_type,
            #                             language, wet_or_dry)

            if len(data) > 0:
                all_products = self.get_product_pdf_details(
                    {'data': data,
                     'language': language,
                     'is_active': 'Y'})
                all_products['segments'] = sorted(all_products['segments'],
                                                  key=lambda product: product[
                    'field_id'])
                all_products['products'] = sorted(all_products['products'],
                                                  key=lambda product: product[
                    'field_id'])

                if pdf_type == 'old_pdf':
                    result = self.format_old_pdf_data(pdf_brand_name,
                                                      language,
                                                      pet_type, wet_or_dry,
                                                      all_products,
                                                      blocks,
                                                      html_content)
                else:
                    result = self.format_new_pdf_data(pdf_brand_name,
                                                      language,
                                                      pet_type,
                                                      wet_or_dry,
                                                      all_products,
                                                      html_content)
            else:
                result = 'success'
        except Exception as e:
            logger.findaylog(""" @ 2291 EXCEPTION - models - onboard -
                           get_brands_segments """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - get_brands_segments(-)')
        return result

    def get_missing_blocks(self, templateList, styles, blocks):
        logger.addinfo('@ models - onboard - get_missing_blocks(+)')
        try:
            for i in range(len(blocks)):
                try:
                    block_index = [str(template['block_id'])
                                   for template in templateList].index(
                        str(blocks[i]['field_block_id']))
                except Exception:
                    block_index = -1
                if block_index == -1:
                    templateObj = {}
                    templateObj['styles'] = []
                    for j in range(len(styles)):
                        if str(styles[j]['block_id']) == str(
                                blocks[i]['field_block_id']):
                            style = {
                                'value': styles[j]['value'],
                                'label': styles[j]['label']
                            }
                            templateObj['styles'].append(style)
                    templateObj['fields'] = [{'label': '', 'value': ''}]
                    templateObj['block_id'] = blocks[i]['field_block_id']
                    templateObj['label'] = blocks[i]['label']
                    templateList.append(templateObj)
            templateList = sorted(templateList,
                                  key=lambda block: int(block['block_id']))
        except Exception as e:
            logger.findaylog(""" @ 2329 EXCEPTION - models - onboard -
                             get_missing_blocks """ + str(e))
            raise e
        logger.addinfo('@ models - onbaord - get_missing_blocks(-)')
        return templateList

    def format_old_pdf_data(self, pdf_brand_name, language, pet_type,
                            wet_or_dry, all_products, blocks, html_content):
        logger.addinfo('@ models - onboard - format_old_pdf_data(+)')
        segment_details = []
        templateList = []
        brand_products = []
        brand_segments = []
        segment_ids = []
        try:
            if language == 'D':
                segLabel = self.sql_file['d_segment_label']
            elif language == 'F':
                segLabel = self.sql_file['f_segment_label']
            elif language == 'US':
                segLabel = self.sql_file['us_segment_label']
            else:
                segLabel = self.sql_file['I_segment_label']
        except Exception as e:
            logger.findaylog(""" 2358 EXCEPTION - models - onboard -
            format_old_pdf_data """ + str(e))
            raise e
        else:
            segment_details = []

            segment_ids = []
            for i in range(len(all_products['segments'])):
                if str(all_products['segments'][i][
                        'segment_id']) not in segment_ids:
                    segment_ids.append(str(
                        all_products['segments'][i]['segment_id']))

            # To differentiate each segment products
            for i in range(len(segment_ids)):
                segment_detail = {
                    'segment_id': segment_ids[i],
                    'product_ids': []}
                for j in range(len(all_products['products'])):
                    if str(all_products['products'][j][
                            'segment_id']) == segment_ids[i]:
                        if all_products['products'][j][
                                'product_id'] is not None and all_products[
                                    'products'][j][
                                        'product_id'] not in segment_detail[
                                            'product_ids']:
                            segment_detail['product_ids'].append(
                                all_products[
                                    'products'][j]['product_id'])
                segment_details.append(segment_detail)

            styles = all_products['styles']
            brand_segments = []
            brand_products = []

            # To get segment details
            brand_segments = self.get_block_data(segment_ids,
                                                 all_products['segments'],
                                                 styles,
                                                 'segment')
            brand_products = []
            for i in range(len(segment_details)):
                product_ids = []
                product_ids = segment_details[i]['product_ids']
                if len(product_ids) > 0:

                    # To get all product details of each segment
                    products = self.get_block_data(product_ids,
                                                   all_products['products'],
                                                   styles,
                                                   'product')
                    for j in range(len(products)):
                        products[j]['segment_id'] = segment_details[
                            i]['segment_id']
                        brand_products.append(products[j])

            templateList = []
            if len(brand_products) > 0:
                for i in range(len(brand_products)):
                    template = []
                    product_fields = brand_products[i]['fields']
                    tmp_product_fields = deepcopy(product_fields)
                    product_fields = self.get_segment_value(
                        product_fields, [], '')
                    if len(product_fields) > 0:
                        for p in range(len(product_fields)):
                            template.append(product_fields[p])
                    for j in range(len(brand_segments)):
                        segment_fields = deepcopy(brand_segments[j]['fields'])
                        if brand_segments[j][
                                'segment_id'] == brand_products[i][
                                'segment_id']:

                            segment_fields = self.get_segment_value(
                                tmp_product_fields,
                                segment_fields, segLabel)
                            if len(segment_fields) > 0:
                                for s in range(len(segment_fields)):
                                    template.append(segment_fields[s])
                            else:
                                template.append({'label': '', 'value': ''})

                            # add missing blocks to pdf
                            template = self.get_missing_blocks(template,
                                                               styles,
                                                               blocks)
                            for k in range(len(all_products['products'])):
                                if brand_products[i][
                                    'product_id'] == all_products[
                                        'products'][k]['product_id']:
                                    if all_products['products'][k][
                                            'description'] is not None:
                                        description = all_products['products'][
                                            k]['description']
                                    else:
                                        description = ''
                                    if all_products['products'][k][
                                            'image_url'] is not None:
                                        image_url = all_products[
                                            'products'][k]['image_url']
                                    else:
                                        image_url = ''
                                    brand_name = all_products['products'][k][
                                        'brand_name']
                                    product_name = all_products['products'][k][
                                        'product_name']
                                    newrecipe = all_products['products'][k][
                                        'newrecipe']
                                    item_seq = all_products['products'][k][
                                        'item_display_number']
                            if not item_seq:
                                item_seq = 99999999
                            templateList.append({
                                'description': description,
                                'product_id': brand_products[i][
                                                'product_id'],
                                'image_url': image_url,
                                'brand_name': brand_name,
                                'product_name': product_name,
                                'newrecipe': newrecipe,
                                'sections': template,
                                'language': language,
                                'item_display_number': item_seq
                            })
            if len(templateList) > 0:
                templateList = sorted(templateList,
                                      key=lambda
                                      product: product[
                                          'item_display_number'])
                result = self.pdf_html_template(templateList, pet_type,
                                                wet_or_dry, pdf_brand_name,
                                                html_content)
            else:
                self.send_log('format_old_pdf_data', 'no product data', {
                    'brand_name': pdf_brand_name,
                    'language': language,
                    'pet_type': pet_type,
                    'wet_or_dry': wet_or_dry
                })
                result = 'error'
        logger.addinfo('@ models - onboard - format_old_pdf_data(-)')
        return result

    # To get field names and ids
    def get_fields_data(self, language):
        logger.addinfo('@ models - onboard - get_fields_data(+)')
        try:
            self.acquire()
            query = self.sql_file['get_fields']
            self.cursor.execute(query, p_language=language)
        except Exception as e:
            logger.findaylog(""" @ 2512 EXCEPTION - models - onboard -
            get_fields_data """ + str(e))
            raise e
        else:
            field_names = [a[0].lower() for a in self.cursor.description]
            fields = []
            for row in self.cursor:
                field_data = {}
                for index, field in enumerate(field_names):
                    field_data[field] = self.decode_value(row[index])
                fields.append(field_data)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_fields_data(-)')
        return fields

    # To get block names and ids
    def get_blocks(self, language):
        logger.addinfo('@ models - onboard - get_blocks(+)')
        try:
            self.acquire()
            query = self.sql_file['get_block_data']
            self.cursor.execute(query, p_language=language)
        except Exception as e:
            logger.findaylog(""" @ 2539 EXCEPTION - models - onboard -
            get_blocks """ + str(e))
            raise e
        else:
            field_names = [a[0].lower() for a in self.cursor.description]
            blocks = []
            for row in self.cursor:
                block = {}
                for index, field in enumerate(field_names):
                    block[field] = self.decode_value(row[index])
                blocks.append(block)
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_blocks(-)')
        return blocks

    # To get row having brand_logo
    def get_logo_details(self, segment_ids):
        logger.addinfo('@ models - onboard - get_logo_details(+)')
        segments = []
        try:
            self.acquire()
            query = self.sql_file['get_brand_logo']
            query = query % (',' . join([str(segment_ids[i])
                                         for i in range(len(segment_ids))]))
            self.cursor.execute(query)
            field_names = [a[0].lower() for a in self.cursor.description]
            rows = self.cursor.fetchall()
            if len(rows) > 0:
                for row in rows:
                    segment = {}
                    for index, field in enumerate(field_names):
                        if field == 'brand_logo' and row[index]:
                            segment[field] = row[index].read()
                        else:
                            segment[field] = self.decode_value(row[index])
                    segments.append(segment)
        except Exception as e:
            logger.findaylog(""" @ 2580 EXCEPTION - models - onboard -
                           get_logo_details """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_logo_details(-)')
        return segments

    def get_brand_logo(self, jsond):
        logger.addinfo('@ models - onboard - get_brand_logo(+)')
        try:
            self.acquire()

            # To check segment data is available or not
            query = self.sql_file['get_segment_rows']
            self.cursor.execute(query,
                                p_segment_id=jsond['segment_id'],
                                p_language=jsond['language'])
        except Exception as e:
            logger.findaylog(""" @ 2602 EXCEPTION - models - onboard -
            get_brand_logo """ + str(e))
            raise e
        else:
            segment_data = self.cursor.fetchall()
            if len(segment_data) > 0:
                segments = self.get_logo_details([jsond['segment_id']])
            else:
                segments = {}
                segments['msg'] = 'No segment Data found'
                segments['status'] = 1
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_brand_logo(-)')
        return segments

    # To insert brand logo
    def upload_brand_logo(self, jsond):
        logger.addinfo('@ models - onboard - upload_brand_logo(+)')
        try:
            self.acquire()
            query = self.sql_file['get_segment_rows']
            self.cursor.execute(query, p_segment_id=jsond['segment_id'],
                                p_language='')
        except Exception as e:
            logger.findaylog(""" @ 2628 EXCEPTION - models - onboard -
            upload_brand_logo """ + str(e))
            raise e
        else:
            result = {}
            field_names = [a[0].lower() for a in self.cursor.description]
            row_data = self.cursor.fetchall()
            if len(row_data) == 0:
                result['status'] = 1
                result['msg'] = 'No data for selected segment'
            else:
                seg_details = []
                for row in row_data:
                    seg_detail = {}
                    for index, field in enumerate(field_names):
                        seg_detail[field] = self.decode_value(row[index])
                    seg_details.append(seg_detail)
                self.cursor.setinputsizes(p_base64=cx_Oracle.BLOB)
                query = self.sql_file['update_image']
                self.cursor.execute(query, p_base64=jsond['base64'],
                                    p_segment_id=seg_details[0]['segment_id'],
                                    p_brand=seg_details[0]['brand_name'],
                                    p_field_id=seg_details[0]['field_id'],
                                    p_language=seg_details[0]['language'],
                                    p_file_name=jsond['filename'])
                if self.cursor.rowcount == 1:
                    result['status'] = 0
                    result['msg'] = 'Image inserted successfully'
                else:
                    result['status'] = 1
                    result['msg'] = "Failed to insert image"
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - upload_brand_logo(-)')
        return result

    # To update brand logo
    def update_brand_logo(self, jsond):
        logger.addinfo('@ models - onboard - update_brand_logo(+)')
        try:
            self.acquire()
            self.cursor.setinputsizes(p_base64=cx_Oracle.BLOB)
            query = self.sql_file['update_image']
            self.cursor.execute(query, p_base64=jsond['base64'],
                                p_file_name=jsond['filename'],
                                p_segment_id=jsond['segment_id'],
                                p_brand=jsond['brand_name'],
                                p_field_id=jsond['field_id'],
                                p_language=jsond['language'])
        except Exception as e:
            logger.findaylog(""" @ 2680 EXCEPTION - models - onboard -
            update_brand_logo """ + str(e))
            raise e
        else:
            result = {}
            if self.cursor.rowcount == 1:
                result['status'] = 0
                result['msg'] = 'Image updated successfully'
            else:
                result['status'] = 1
                result['msg'] = "Failed to update image"
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - update_brand_logo(-)')
        return result

    def get_file_path(self, jsond):
        logger.addinfo(' @ models - onboard - get_file_path(+)')
        try:
            if jsond['language'] == 'I':
                language = 'IT'
            elif jsond['language'] == 'F':
                language = 'FR'
            else:
                language = jsond['language']
            filename = jsond['brand_name'].split(' ')
            filename = '_'.join(filename)
            filename += '_' + jsond['pet_type']
            filename += '_' + jsond['wet_or_dry']
            filename += '_' + language
            if not os.path.exists(jsond['path']):
                os.mkdir(jsond['path'])
            file_path = jsond['path'] + filename + '.pdf'
        except Exception as e:
            logger.findaylog(""" @ 2716 EXCEPTION models - onboard -
                            get_file_path """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - get_file_path(-)')
        return file_path

    # To get translation for download high resolution
    def get_download_text(self, language):
        logger.addinfo('@ models - onboard - get_download_text(+)')
        try:
            if language == 'D':
                urlHeading = self.sql_file['d_url_heading']
            elif language == 'US':
                urlHeading = self.sql_file['us_url_heading']
            elif language == 'F':
                urlHeading = self.sql_file['f_url_heading']
            else:
                urlHeading = self.sql_file['I_url_heading']
        except Exception as e:
            logger.findaylog(""" @ 2736 EXCEPTION - models - onboard
                           get_download_text - """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - get_download_text(-)')
        return urlHeading

    def get_header(self, product, base64, brand_logo):
        logger.addinfo('@ models - onboard - get_header(+)')
        header_details = {}
        try:
            header_details['product_image'] = base64
            header_details['brand_image'] = brand_logo
            header_details['product_description'] = ''
            if product[0]['description']:
                description = product[0]['description']
                header_details['product_description'] = description
        except Exception as e:
            logger.findaylog(""" @ 2756 EXCEPTION - models - onboard -
                           get_header """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - get_header(-)')
        return header_details

    def build_segments(self, products, segments):
        logger.addinfo('@ models - onboard - build_segments(+)')
        segment_tables = []
        try:
            # Field_block_ids for segments
            # [Indication of storage and shelf life,
            # Languages on Single Pack, Suggested Daily serving,
            # Technical Data Single Pack,Technical Data packaging,
            # Made In, Manufacturer Data]
            segment_ids = [15, 16, 20, 21, 22, 39, 23]
            for i in range(len(segment_ids)):
                segment_table = {}
                segment_table['segment_label'] = ''
                segment_table['segment_index'] = i
                if segment_ids[i] == 22:
                    # Build table with 4 rows with fields in
                    # Technical data packaging segment
                    packaging_data = []
                if segment_ids[i] != 39:
                    segment_table['segment_value'] = ''

                    for j in range(len(segments)):
                        if str(segments[j][
                                'field_block_id']) == str(segment_ids[i]):
                            segment_table[
                                'segment_label'] = segments[
                                j]['segment_label']
                            if segment_ids[i] == 22:
                                # Append field label and value to rows if
                                # segment is Technical data packaging
                                # index refers row number in table
                                if segments[j]['label'] is not None:
                                    label = '<b>'
                                    label += segments[j]['label']
                                    label += '</b>'
                                else:
                                    label = ''
                                if segments[j]['value'] is not None:
                                    value = segments[j]['value']
                                else:
                                    value = ''
                                packaging_data.append(label)
                                packaging_data.append(value)
                                segment_table[
                                    'segment_value'] = packaging_data
                            else:
                                if segment_ids[i] == 21:
                                    # Add field label if segment is
                                    # Technical data single pack
                                    if segments[j]['label'] is not None:
                                        segment_table[
                                            'segment_value'] = segments[
                                            j]['label']
                                    else:
                                        segment_table[
                                            'segment_value'] += ''
                                    segment_table['segment_value'] += ': '
                                if segments[j]['value'] is not None:
                                    segment_table[
                                        'segment_value'] += segments[
                                        j]['value']
                                segment_table['segment_value'] += '    '
                if segment_ids[i] == 22:
                    segment_tables.append(segment_table)
                elif segment_ids[i] == 39:
                    try:
                        index = -1
                        index = [str(product['field_id'])
                                 for product in products].index(
                            str(segment_ids[i]))
                    except Exception:
                        index = -1
                    if index != -1:
                        segment_table['segment_value'] = ''
                        segment_table[
                            'segment_label'] = products[
                            index]['label']
                        if products[index]['value']:
                            segment_table[
                                'segment_value'] = products[
                                index]['value']
                        segment_tables.append(segment_table)
                else:
                    if segment_table[
                            'segment_label'] != '' and segment_table[
                            'segment_value'] != '':
                        segment_tables.append(segment_table)
        except Exception as e:
            logger.findaylog(""" @ 2855 EXCEPTION - models - onboard -
                           build_segments""" + str(e))
            raise e
        logger.addinfo('@ models - onboard - build_segments(-)')
        return segment_tables

    def get_product_image(self, product_id):
        logger.addinfo('@ models - onboard - get_product_image(+)')
        has_image = False
        product_image_details = {}
        base64 = ''
        try:
            product_url = os.environ['IMAGE_URL']
            product_url += product_id + '.png'
            r = requests.get(product_url)
            if r.status_code == 200:
                has_image = True
                product_image = urllib.request.urlopen(product_url)
                base64 = product_image.read()
            product_image_details['img_product'] = base64
            product_image_details['has_image'] = has_image
        except Exception as e:
            logger.findaylog(""" @ 2882 EXCEPTION - models - onboard -
                           get_product_image""" + str(e))
            raise e
        logger.addinfo('@ models - onboard - get_product_image(-)')
        return product_image_details

    def new_pdf_html_template(self, segment_details, brand_name, pet_type,
                              wet_or_dry, language, content):
        logger.addinfo('@ models - onboard - new_pdf_html_template(+)')
        try:
            file_obj = {}
            file_obj['language'] = language
            file_obj['pet_type'] = pet_type
            file_obj['brand_name'] = brand_name
            file_obj['path'] = self.sql_file['new_pdf_path']
            file_obj['wet_or_dry'] = wet_or_dry
            file_path = self.get_file_path(file_obj)

            modified_time = ''
            if os.path.exists(file_path):
                modified_time = datetime.datetime.fromtimestamp(
                    os.path.getmtime(file_path))
                modified_time = modified_time.strftime('%Y-%m-%d')

            products_page_content = content['products_content']
            footer_content = content['footer_content']
            header_name = content['header_name']

            segments = []

            segment_update_date = ''
            product_update_date = ''
            for k in range(len(segment_details)):
                if not segment_update_date or segment_details[k][
                        'segment_update_date'
                ] > segment_update_date:
                    segment_update_date = segment_details[k][
                        'segment_update_date']
                if not product_update_date or segment_details[k][
                        'product_update_date'
                ] > product_update_date:
                    product_update_date = segment_details[k][
                        'product_update_date']

            if modified_time and (
                    modified_time > segment_update_date) and (
                        modified_time > product_update_date):
                return 'success'
            for k in range(len(segment_details)):
                segment = {}
                segment['image_link'] = ''
                segment['brand_logo'] = ''
                if len(segment_details[k]['products']) > 0:
                    products = segment_details[k]['products']
                    if len(segment_details[k]['segments']):
                        segment['brand_logo'] = segment_details[k][
                            'segments'][0]['brand_logo']
                        if segment['image_link'] == '' or segment[
                                'image_link'] is None:
                            segment['image_link'] = segment_details[k][
                                'segments'][0][
                                'segment_image_url']

                    if segment[
                        'brand_logo'] is not None and segment[
                            'brand_logo'] != '':
                        segment['brand_logo'] = segment['brand_logo']
                    else:
                        segment['brand_logo'] = self.sql_file[
                            'almo_nature_logo']

                    # build products tables
                    products_page = self.build_products(products,
                                                        brand_name,
                                                        segment['brand_logo'],
                                                        segment_details[k][
                                                            'segments'])

                    # has brand logo and product description
                    segment['header_details'] = products_page['header_details']

                    segment['product_tables'] = products_page['product_tables']

                    # build segment tables
                    segment_tables = self.build_segments(products[0],
                                                         segment_details[k][
                        'segments'])
                    segment['segment_tables'] = segment_tables
                    segment['download_text'] = self.get_download_text(language)

                    # append each product and segment page to segments
                    segments.append(segment)

            obj = {}
            obj['segments'] = segments
            obj['page_content'] = products_page_content
            temp_file_name = '/tmp/summarypdf' + brand_name
            temp_file_name += wet_or_dry + pet_type
            obj['file_name'] = temp_file_name
            footer_file_name = '/tmp/pdffooter' + brand_name
            footer_file_name += wet_or_dry + pet_type
            obj['footer_file_name'] = footer_file_name
            obj['footer_content'] = footer_content
            obj['header_name'] = header_name
            obj['file_path'] = file_path
            self.write_to_file(obj)
        except Exception as e:
            logger.findaylog(""" @ 2998 EXCEPTION - models - onboard -
                             new_pdf_html_template """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - new_pdf_html_template(-)')
        return 'success'

    def write_to_file(self, obj):
        logger.addinfo('@ models - onboard - write_to_file(+)')
        try:
            segments = obj['segments']
            products_page_content = obj['page_content']
            output_file = PdfFileWriter()
            options = {
                'page-size': 'A4',
                'margin-top': '10mm',
                'margin-bottom': '24mm',
                'margin-left': '0mm',
                'margin-right': '0mm',
                'quiet': '',
                'encoding': 'utf-8',
                'header-html': obj['header_name'],
                'header-spacing': '2',
                'footer-spacing': '8'
            }

            for i in range(len(segments)):
                content = products_page_content.render(
                    segment=segments[i])
                html_file_name = obj['file_name'] + str(i) + '.html'
                pdf_name = obj['file_name'] + str(i) + '.pdf'
                footer_file_name = obj['footer_file_name'] + str(i) + '.html'

                footer_content = obj['footer_content'].render(
                    download_text=segments[i][
                        'download_text'],
                    image_link=segments[i]['image_link'])

                # write footer html file
                with io.open(
                        footer_file_name, 'w', encoding='utf-8') as footer:
                    footer.write(footer_content)
                    footer.close()

                options['footer-html'] = footer_file_name

                with io.open(html_file_name, 'w', encoding='utf-8') as changed:
                    changed.write(content)
                    changed.close()

                pdfkit.from_file(html_file_name, pdf_name, options=options)
                file = PdfFileReader(open(pdf_name, 'rb'))
                no_of_pages = file.getNumPages()
                for i in range(0, no_of_pages):
                    output_file.addPage(file.getPage(i))

                if os.path.exists(html_file_name):
                    os.remove(html_file_name)
                if os.path.exists(pdf_name):
                    os.remove(pdf_name)
                if os.path.exists(footer_file_name):
                    os.remove(footer_file_name)
            output_file.write(open(obj['file_path'], 'w'))
        except Exception as e:
            logger.findaylog(""" @ 3063 EXCEPTION - onboard - models -
                             write_to_file """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - write_to_file(-)')
        return 'success'

    def generate_barcode(self, value, barcodes_path):
        logger.addinfo('@ models - onboard - generate_barcode(+)')
        try:
            value = value.replace(" ", "")
            check_digits = re.search(r'[^0-9]', value)
            if check_digits is not None or len(value) != 13:
                return ''
            if not os.path.exists(barcodes_path):
                os.mkdir(barcodes_path)
            file_name = barcodes_path + 'barcode_' + str(value)
            png_filename = file_name + '.png'
            if not os.path.exists(png_filename):
                EAN = barcode.get_barcode_class('ean13')
                ean = EAN(value, writer=ImageWriter())
                ean.default_writer_options['font_size'] = 23
                ean.default_writer_options['center_text'] = True
                ean.default_writer_options['quiet_zone'] = 1.0
                ean.default_writer_options['text_distance'] = 2.0
                ean.default_writer_options['module_height'] = 10.0
                png_filename = ean.save(file_name)
        except Exception as e:
            logger.findaylog(""" @ 3093 EXCEPTION - onboard - models -
                             generate_barcode """ + str(e))
            raise e
        logger.addinfo('@ models - onboard- generate_barcode(-)')
        return png_filename

    # To build table with product details
    def build_products(self, products, brand_name, brand_logo, segments):
        logger.addinfo('@ models - onboard - build_products(+)')
        product_page = {'product_tables': [], 'header_details': ''}
        set_header_description = False
        try:
            barcodes_path = self.sql_file['barcodes_path']
            # field_ids [Product code, EAN, Barcode, Weight, Pieces per carton]
            field_ids = [34, 35, 36, 37, 58]
            product_html_tables = []

            # field_id for product name
            product_name_id = 33

            for j in range(len(products)):
                bar_code = ''
                product_html_table = {}
                product_image_details = self.get_product_image(
                    products[j][0]['product_id'])
                if product_image_details:
                    base64 = product_image_details[
                        'img_product'].encode('base64')
                else:
                    base64 = ''
                product_html_table[
                    'img_product'] = base64
                if product_image_details[
                        'has_image'] and products[j][0][
                            'description'] and not set_header_description:
                    product_page['header_details'] = self.get_header(
                        products[j], base64,
                        brand_logo)
                    set_header_description = True
                if j == len(products) - 1 and not set_header_description:
                    product_page['header_details'] = self.get_header(
                        products[j],
                        base64, brand_logo)
                header_row = []
                value_row = []

                # build products table
                product_range_name = brand_name + ' - '
                product_name_index = [product['field_id']
                                      for product in products[j]].index(
                    product_name_id)
                if product_name_index != -1 and products[j][
                        product_name_index]['value'] is not None:
                    product_range_name += products[j][product_name_index][
                        'value']
                product_html_table['product_range_name'] = product_range_name
                for i in range(len(field_ids)):
                    field_value = ''
                    field_index = -1
                    block = ''
                    # Check for field_id in products
                    if field_ids[i] != 58:
                        try:
                            field_index = [str(product['field_id'])
                                           for product in products[j]].index(
                                str(field_ids[i]))
                        except Exception:
                            field_index = -1
                        if field_index != -1:
                            block = products[j]
                    else:
                        # Check for field_id in segment details
                        try:
                            field_index = [str(segment['field_id'])
                                           for segment in segments].index(
                                str(field_ids[i]))
                        except Exception:
                            field_index = -1
                        if field_index != -1:
                            block = segments

                    if block:
                        field_label = block[field_index]['label']
                        if block[field_index]['value'] is not None:
                            field_value = block[field_index]['value']

                            # generate barcode with EAN field value
                            if field_ids[i] == 35 and field_value != '-':
                                bar_code = self.generate_barcode(field_value,
                                                                 barcodes_path)
                        else:
                            field_value = ''
                        header_row.append(field_label)
                        value_row.append(field_value)
                product_html_table['header_row'] = header_row
                product_html_table['value_row'] = value_row
                if bar_code:
                    product_html_table['bar_code'] = bar_code
                else:
                    product_html_table['bar_code'] = ''
                composition_value = ''
                # Block_ids for blocks
                # [Composition, Analytical constituents, Energy value]
                composition_ids = [18, 19, 17]
                for i in range(len(composition_ids)):
                    if composition_ids[i] != 17:
                        try:
                            index = -1
                            index = [str(product['field_block_id'])
                                     for product in products[j]].index(
                                str(composition_ids[i]))
                        except Exception:
                            index = -1
                        if index != -1:
                            composition_value += "<b>"
                            segment_label = ''
                            if products[j][index]['segment_label'] is not None:
                                segment_label = products[j][
                                    index]['segment_label']
                            composition_value += segment_label
                            composition_value += ': ' + "</b>"
                    for k in range(len(products[j])):
                        if products[j][k][
                                'field_block_id'] == composition_ids[i]:
                            if composition_ids[i] == 19:
                                label = ''
                                if products[j][k]['label'] is not None:
                                    label = products[j][k]['label']
                                composition_value += label
                                composition_value += ' '
                            if products[j][k]['value']:
                                value = ''
                                if products[j][k]['value'] is not None:
                                    value = products[j][k]['value']
                                if composition_ids[i] == 17:

                                    # label for suggested daily serving in
                                    # italian and german
                                    I_label = 'Razione Giornaliera Indicativa'
                                    D_label = 'Tagesration'
                                    if products[j][k][
                                        'label'] != I_label and products[
                                            j][k]['label'] != D_label:
                                        composition_value += "<b>"
                                        composition_value += value
                                        composition_value += "</b>"
                                else:
                                    composition_value += value
                                composition_value += ', '
                product_html_table['composition_value'] = composition_value
                product_html_tables.append(product_html_table)
            product_page['product_tables'] = product_html_tables
        except Exception as e:
            logger.findaylog(""" @ 3250 EXCEPTION - models - onboard -
                             build_products """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - build_products(-)')
        return product_page

    def get_segment_product_ids(self, brand_name, pet_type, language,
                                wet_or_dry):
        logger.addinfo('@ models - onboard- get_product_segment_ids(+)')
        ids = []
        try:
            self.acquire()
            query = self.sql_file['get_pet_type_segments']
            self.cursor.execute(query, p_brand=brand_name,
                                p_pet_type=pet_type,
                                p_language=language,
                                p_wet_or_dry=wet_or_dry)
            field_names = [a[0].lower() for a in self.cursor.description]
            data = self.cursor.fetchall()
            if len(data) > 0:
                for row in data:
                    id = {}
                    for i in range(len(field_names)):
                        if field_names[i] == 'item_code':
                            id['item_code'] = row[i]
                        elif field_names[i] == 'segments_category_id':
                            id['segment_id'] = row[i]
                    ids.append(id)
        except Exception as e:
            logger.findaylog(""" 3285 EXCEPTION - models - onboard -
                           get_segment_product_ids """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_segment_product_ids(-)')
        return ids

    def format_new_pdf_data(self, pdf_brand_name, language, pet_type,
                            wet_or_dry, all_products, html_content):
        logger.addinfo('@ models - onboard - format_new_pdf_data(+)')
        try:
            # Get segment ids
            segment_ids = []
            for i in range(len(all_products['segments'])):
                if all_products['segments'][i]['segment_id'] and str(
                        all_products['segments'][i][
                            'segment_id']) not in segment_ids:
                    segment_ids.append(str(
                        all_products['segments'][i]['segment_id']))

            # Get product ids
            product_ids = []
            for i in range(len(all_products['products'])):
                if all_products['products'][i]['product_id'] and str(
                    all_products['products'][i][
                        'product_id']) not in product_ids:
                    product_ids.append(
                        str(all_products['products'][i]['product_id']))

            # Group segment details
            segment_details = []
            segment_update_date = ''
            product_update_date = ''
            for i in range(len(all_products['segments'])):
                if not segment_update_date or all_products[
                        'segments'][i][
                            'last_update_date'] > segment_update_date:
                    segment_update_date = all_products['segments'][
                        i]['last_update_date']

                if all_products['segments'][i]['segment_id'] != '':
                    try:
                        segment_index = -1
                        segment_index = [str(segment['segments'][0][
                            'segment_id'])
                            for segment in segment_details].index(
                            str(all_products[
                                'segments'][i]['segment_id']))
                    except Exception:
                        segment_index = -1
                    if all_products['segments'][i]['type'] == 'segment':
                        if segment_index != -1:
                            segment_details[segment_index]['segments'].append(
                                all_products['segments'][i])
                        else:
                            segment_details.append(
                                {
                                    'segments': [all_products['segments'][i]],
                                    'products': [],
                                    'segment_update_date': segment_update_date,
                                    'product_update_date': ''
                                })

            # Group product details for each segment
            for i in range(len(segment_details)):
                product_update_date = ''
                for j in range(len(all_products['products'])):
                    if str(all_products['products'][j][
                        'segment_id']) == str(segment_details[i][
                            'segments'][0]['segment_id']):
                        try:
                            if not product_update_date or all_products[
                                    'products'][j]['last_update_date']:
                                product_update_date = all_products[
                                    'products'][j][
                                    'last_update_date']
                            product_index = -1
                            segment_products = segment_details[i]['products']
                            product_index = [str(segment_product[0][
                                'product_id'])
                                for segment_product in
                                segment_products].index(
                                str(all_products[
                                    'products'][j][
                                    'product_id']))
                        except Exception:
                            product_index = -1
                        segment_details[i][
                            'product_update_date'
                        ] = product_update_date
                        if product_index != -1:
                            segment_details[i]['products'][
                                product_index].append(
                                all_products['products'][j])
                        else:
                            segment_details[i]['products'].append(
                                [all_products['products'][j]])

            if len(segment_details) > 0:
                result = self.new_pdf_html_template(segment_details,
                                                    pdf_brand_name,
                                                    pet_type,
                                                    wet_or_dry,
                                                    language,
                                                    html_content)
            else:
                result = 'error'
        except Exception as e:
            logger.findaylog(""" @ 3400 EXCEPTION - models - onboard -
                           format_new_pdf_data """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - format_new_pdf_data(-)')
        return result

    def generate_pdf(self, jsond):
        logger.addinfo('@ models - onboard - generate_pdf(+)')
        blocks = []
        html_content = ''
        try:
            if jsond['type'] == 'old_pdf':
                file_name = os.path.join(
                    os.path.dirname(__file__) + '/detailpdf.html')
                with io.open(file_name, 'r', encoding='utf-8') as original:
                    html_content = Template(original.read())
                    original.close()
            else:
                html_content = {}
                products_file_name = os.path.join(
                    os.path.dirname(__file__) + '/summarypdfproducts.html')

                with io.open(products_file_name,
                             'r', encoding='utf-8') as original:
                    html_content[
                        'products_content'] = Template(original.read())
                    original.close()

                html_content[
                    'header_name'] = os.path.join(os.path.dirname(
                        __file__) + '/pdfheader.html')
                footer_name = os.path.join(
                    os.path.dirname(__file__) + '/pdffooter.html')

                with io.open(footer_name,
                             'r', encoding='utf-8') as footer_original:
                    html_content[
                        'footer_content'] = Template(footer_original.read())
                    footer_original.close()

            response = []
            languages = self.get_language()
            for i in range(len(languages)):
                if jsond['type'] == 'old_pdf':
                    blocks = self.get_blocks(languages[i]['language_id'])
                brands = jsond['brands']
                for j in range(len(brands)):
                    result = 'success'
                    if len(brands[j]['segments']) > 0:
                        brands[j]['active_segments'] = []

                        brands[j][
                            'active_segments'] = self.get_active_products(
                            brands[j]['segments'],
                            languages[i]['language_id'])
                        if len(brands[j]['active_segments']) > 0:
                            brands[j]['pdf_type'] = jsond['type']
                            brands[j]['language'] = languages[i]['language_id']
                            brands[j]['blocks'] = blocks
                            result = self.get_brands_segments(
                                brands[j], html_content)
                        else:
                            result = 'error'
                            self.send_log('generate_pdf', 'no segment data',
                                          {
                                              'segments': brands[j]['segments'],
                                              'brand': brands[j]['brand']
                                          })
                    else:
                        self.send_log('generate_pdf', 'no segment data',
                                      brands[j]['brand'])
                    response.append({
                        'brand': brands[j]['brand'],
                        'language': languages[i]['language'],
                        'pet_type': brands[j]['pet_type'],
                        'wet_or_dry': brands[j]['wet_or_dry'],
                        'result': result
                    })
        except Exception as e:
            logger.findaylog(""" 3478 EXCEPTION - models - onboard -
                             generate_pdf """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - generate_pdf(-)')
        return response

    # to upload image in local
    def insert_product_image(self, product_image):
        logger.addinfo('@ models - onboard - insert_product_image(+)')
        try:
            image = product_image['base64']
            product_id = product_image['product_id']
            path = os.environ['IMAGE_SFTP_PATH']
            file = open(path + product_id + '.png', 'w')
            file.write(image.decode('base64'))
            file.close()
            self.upload_product_image(product_id)
        except Exception as e:
            logger.findaylog(""" @ 3497 EXCEPTION - modesl - onboard -
                             insert_product_image """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - insert_product_image(-)')

    # to upload images to server
    def upload_product_image(self, product_id):
        logger.addinfo('@ models - onboard - upload_product_image(+)')
        client = None
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            host = os.environ['IMAGE_SFTP_HOST']
            username = os.environ['IMAGE_SFTP_USER']
            key_file_path = os.environ['IMAGE_SFTP_KEY']
            key = paramiko.RSAKey.from_private_key_file(key_file_path)
            path = os.environ['IMAGE_SFTP_PATH']
            port = os.environ['IMAGE_SFTP_PORT']
            client.connect(host, int(port), username=username, pkey=key)
            sftp = client.open_sftp()
            local_path = path + product_id + '.png'
            remote_path = path + product_id + '.png'
            sftp.put(local_path, remote_path)
            sftp.close()
        except Exception as e:
            logger.findaylog(""" @ 3525 EXCEPTION - models - onboard -
                             upload_product_image """ + str(e))
            raise e
        finally:
            if client:
                client.close()
        logger.addinfo('@ models - onboard - upload_product_image(-)')

    def upload_pdf(self, jsond):
        logger.addinfo('@ models - onboard - upload_pdf(+)')
        try:
            base64 = jsond['base64']
            pdf_name = jsond['pdf_name']
            path = self.sql_file['pdf_path']
            file = open(path + pdf_name + '.pdf', 'w')
            file.write(base64.decode('base64'))
            file.close()
        except Exception as e:
            logger.findaylog(""" @ 3546 EXCEPTION - models - onboard -
                             upload_pdf """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - upload_pdf(-)')
        return 'success'

    def encode_value(self, value, convert_to_string):
        logger.addinfo('@ models - onboard - encode_value(+)')
        try:
            if value is not None and type(value) == str:
                if "'" in value:
                    value = value.replace("'", "''")
                value = str(value, "utf-8")
                if convert_to_string:
                    value = "'" + value + "'"
            else:
                value = str(value)
        except Exception as e:
            logger.findaylog(""" @ 3566 EXCEPTION - models - onboard -
                             encode_value """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - encode_value(-)')
        return value

    def decode_value(self, value):
        logger.addinfo('@ models - onboard - decode_value(+)')
        try:
            if value and type(value) == str:
                value = value.decode('utf-8')
        except Exception as e:
            logger.findaylog(""" @ 3582 EXCEPTION - models - onboard -
                             decode_value """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - decode_value(-)')
        return value

    def get_barcode(self, jsond):
        logger.addinfo('@ models - onboard - get_barcode(+)')
        try:
            barcodes_path = self.sql_file['barcodes_path']
            images = []
            for i in range(len(jsond)):
                image_name = ''
                obj = {}
                value = jsond[i]['barcode_value']
                obj['barcode_value'] = value
                obj['product_id'] = jsond[i]['product_id']
                obj['base64'] = ''
                f_value = value.replace(" ", "")
                image_name = 'barcode_' + f_value + '.png'
                barcode_url = barcodes_path + image_name
                if not os.path.exists(barcode_url):
                    image_name = self.generate_barcode(value, barcodes_path)
                if image_name:
                    obj['base64'] = base64.b64encode(open(
                        barcode_url, 'rb').read())
                images.append(obj)
        except Exception as e:
            logger.findaylog(""" @ 3613 EXCEPTION - models - onboard -
                             get_barcode""" + str(e))
            raise e
        logger.addinfo('@ models - onboard - get_barcode(-)')
        return images

    def trade_sheet_data(self, jsond):
        logger.addinfo('@ models - onboard - trade_sheet_data(+)')
        data = []
        translations = []
        languages = []
        try:
            self.acquire()
            query = self.sql_file['get_trade_sheet_data']
            self.cursor.execute(query, p_animal=jsond['animal'],
                                p_wet_or_dry=jsond['wet_or_dry'])
            data = Code_util.iterate_data(self.cursor)
            if jsond['upload'] or jsond['generate']:
                if jsond['upload'] or jsond['language']:
                    query = self.sql_file['get_trade_sheet_translation']
                    self.cursor.execute(query, p_animal='',
                                        p_wet_or_dry='',
                                        p_language=jsond['language'])
                    translations = Code_util.iterate_data(self.cursor)
                if jsond['upload']:
                    query = self.sql_file['language_query']
                    self.cursor.execute(query)
                    languages = Code_util.iterate_data(self.cursor)
                self.generate_excel(data, translations, languages, jsond)
        except Exception as e:
            logger.findaylog(""" @ 3644 EXCEPTION - models - onboard -
                             trade_sheet_data """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - onboard - trade_sheet_data(-)')
        if jsond['upload'] or jsond['generate']:
            return 'success'
        else:
            return data

    def build_excel(self, data, file_path, jsond, language):
        logger.addinfo('@ models - onboard - build_excel(+)')
        try:
            sheet_name = 'Trade Sheet'
            if language:
                sheet_name = language
            workbook = xlsxwriter.Workbook(file_path)
            worksheet = workbook.add_worksheet(sheet_name)
            # To make header fixed
            worksheet.freeze_panes(1, 0)
            string_format = workbook.add_format(jsond['string_format'])
            number_format = workbook.add_format(jsond['number_format'])
            header_format = workbook.add_format(jsond['header_format'])
            no_data_format = workbook.add_format(jsond['merge_format'])
            cat_merge_format = workbook.add_format(jsond['merge_format'])
            cat_merge_format.set_fg_color(jsond['cat_color'])
            cat_merge_format.set_align('center')
            dog_merge_format = workbook.add_format(jsond['merge_format'])
            dog_merge_format.set_fg_color(jsond['dog_color'])
            dog_merge_format.set_align('center')
            animal_type = ['CAT', 'DOG']
            wet_or_dry = ['WET', 'DRY', 'SNACK', 'LITTER']
            row = 0
            col = 0
            # To set row height
            worksheet.set_row(0, 40)

            # To set column width
            worksheet.set_column('A1:E1', 16)
            worksheet.set_column('F1:F1', 30)
            worksheet.set_column('G1:G1', 40)
            worksheet.set_column('H1:Z1', 16)
            column_names = jsond['column_names']
            formatted_column_names = jsond['formatted_column_names']
            for i in range(len(column_names)):
                worksheet.write(row, col, column_names[i], header_format)
                col = col + 1
            sheet_header = ''
            row = row + 1
            if len(data) == 0:
                row = row + 1
                worksheet.set_row(row - 1, 30)
                """Merge columns for type of animal
                   and categorty title"""
                worksheet.merge_range(
                    'A' + str(row) + ':V' + str(row),
                    'No data found for selected parameters',
                    no_data_format)
            for i in range(len(animal_type)):
                has_product = False
                col = 0
                if animal_type[i] == 'CAT':
                    merge_format = cat_merge_format
                else:
                    merge_format = dog_merge_format
                for j in range(len(wet_or_dry)):
                    has_product = False
                    sheet_header = animal_type[i] + ' FOOD | '
                    sheet_header += wet_or_dry[j] + ' PRODUCTS'
                    for k in range(len(data)):
                        if data[k]['wet_or_dry'] == wet_or_dry[j] and (
                                data[k]['animal'] == animal_type[i]):
                            if not has_product:
                                has_product = True
                                row = row + 1
                                worksheet.set_row(row - 1, 30)
                                """Merge columns for type of animal
                                   and categorty title"""
                                worksheet.merge_range(
                                    'A' + str(row) + ':V' + str(row),
                                    sheet_header,
                                    merge_format)

                            col = 0
                            for x in range(len(formatted_column_names)):
                                if type(
                                    data[k][formatted_column_names[x]]
                                ) == int or type(
                                    data[k][formatted_column_names[x]]
                                ) == float:
                                    value_format = number_format
                                else:
                                    value_format = string_format
                                worksheet.write(
                                    row, col,
                                    data[k][formatted_column_names[x]],
                                    value_format)
                                col = col + 1
                            row = row + 1
            workbook.close()
        except Exception as e:
            logger.findaylog(""" @ 3747 EXCEPTION - models - onboard -
                             build_excel """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - build_excel(-)')

    def generate_excel(self, trade_sheet_data, translations, languages, jsond):
        logger.addinfo('@ models - onboard - generate_excel(+)')
        try:
            # Add missing columns from oracle
            for i in range(len(trade_sheet_data)):
                for key, value in trade_sheet_data[i].items():
                    if value is not None:
                        trade_sheet_data[i][key] = str(value).strip()
                    if type(value) == int:
                        trade_sheet_data[i][key] = int(
                            trade_sheet_data[i][key])
                    if type(value) == float:
                        trade_sheet_data[i][key] = float(
                            trade_sheet_data[i][key])
                trade_sheet_data[i]['producer'] = 'Almo Nature'
                trade_sheet_data[i]['height'] = ''
                trade_sheet_data[i]['plt'] = ''
                trade_sheet_data[i]['shelf_life_month'] = ''
                trade_sheet_data[i]['notes'] = ''

            style_obj = {}
            # Cat cell header color
            style_obj['cat_color'] = '#ffcc00'

            # Dog cell header color
            style_obj['dog_color'] = '#00abea'
            style_obj['string_format'] = {
                'font_size': 9,
                'align': 'center',
                'valign': 'vcenter'
            }
            style_obj['header_format'] = {
                'bold': True,
                'font_size': 11,
                'fg_color': '#1fb714',
                'border': 1,
                'border_color': 'black',
                'valign': 'vcenter',
                'align': 'center'
            }
            style_obj['number_format'] = {
                'align': 'right',
                'font_size': 9,
                'num_format': '#,##0.00',
                'valign': 'vcenter'
            }
            style_obj['merge_format'] = {
                'bold': True,
                'border': 1,
                'valign': 'vcenter'
            }
            style_obj['column_names'] = [
                'Item Code', 'Item EAN Code',
                'EAN Code', 'Bar Code', 'Producer',
                'Family Product', 'Recipe', 'Weight',
                'Notes', 'Pieces', 'Pack',
                'Weight Ct(kg)', 'Carton Per Pallet',
                'Pallet: Cartons per layer (Horizontal)',
                'Pallet: Layer (Vertical)',
                'Carton Long Side (cm)',
                'Carton Short Side (cm)',
                'Carton Height', 'Plt',
                'Plt: Height (cm)', 'Plts per truck',
                'Shelf life (month)']
            style_obj['formatted_column_names'] = [
                'item_code', 'item_ean_code',
                'cluster_ean_code', 'bar_code',
                'producer', 'sales_segment',
                'recipe', 'weight', 'notes',
                'pieces', 'pack',
                'unit_weight_ct',
                'cartons_per_pallet',
                'cartons_per_layer',
                'layers_per_pallet',
                'carton_long_side',
                'carton_short_side',
                'height', 'plt', 'height_pallet',
                'pallets_per_truck',
                'shelf_life_month']
            if not jsond['upload']:
                # Path to download file from cruscott
                file_path = '/tmp/trade_sheet.xlsx'
                if jsond['language']:
                    for i in range(len(trade_sheet_data)):
                        trade_sheet_data[i]['recipe'] = ''
                        trade_sheet_data[i]['pack'] = ''
                        for j in range(len(translations)):
                            if trade_sheet_data[i][
                                'inventory_item_id'] == translations[j][
                                    'inventory_item_id']:
                                trade_sheet_data[i][
                                    'recipe'] = translations[j]['recipe']
                                trade_sheet_data[i][
                                    'pack'] = translations[j]['pack']
                self.build_excel(trade_sheet_data, file_path, style_obj,
                                 jsond['languageDescription'])
            else:
                # Path to upload trade sheet
                file_path = self.sql_file['tradesheet_path']
                if not os.path.exists(file_path):
                    os.mkdir(file_path)

                # Generate excel sheet for each language
                for i in range(len(languages)):
                    file_name = file_path
                    file_name += 'TRADE_SHEET_' + languages[i]['language_id']
                    file_name += '.xlsx'
                    data = deepcopy(trade_sheet_data)
                    for j in range(len(data)):
                        data[j]['recipe'] = ''
                        data[j]['pack'] = ''
                        for k in range(len(translations)):
                            if (data[j]['inventory_item_id'
                                        ] == translations[k][
                                'inventory_item_id'] and translations[k][
                                    'language'] == languages[i]['language_id']):
                                data[j]['recipe'] = translations[k]['recipe']
                                data[j]['pack'] = translations[k]['pack']
                                break
                    self.build_excel(data, file_name, style_obj,
                                     languages[i]['language'])
        except Exception as e:
            logger.findaylog(""" @ 3877 EXCEPTION - models - onboard -
                             generate_excel(-) """ + str(e))
            raise e
        logger.addinfo('@ models - onboard - generate_excel(-)')
        return 'success'

    def get_trade_sheet_translation(self, jsond):
        logger.addinfo('@ models - onboard - get_trade_sheet_translation(+)')
        try:
            self.acquire()
            query = self.sql_file['get_trade_sheet_translation']
            self.cursor.execute(query, p_animal=jsond['animal'],
                                p_wet_or_dry=jsond['wet_or_dry'],
                                p_language='')
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 3899 EXCEPTION - models - onboard -
                             get_trade_sheet_translation """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - onboard - get_trade_sheet_translation(-)')
        return result

    def update_translation(self, jsond):
        logger.addinfo('@ models - onboard - update_translation(+)')
        result = 'success'
        try:
            self.acquire()
            query = self.sql_file['update_translation']
            self.cursor.execute(query, p_pack=jsond['pack'],
                                p_inventory_item_id=jsond['inventory_item_id'],
                                p_recipe=jsond['recipe'],
                                p_language=jsond['language'])
        except Exception as e:
            logger.findaylog(""" @ 3919 EXCEPTION - models - onboard -
                             update_translation """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - update_translation(-)')
        return result

    def sync(self):
        logger.addinfo('@ models - onboard - sync(+)')
        try:
            self.acquire()
            query = self.sql_file['update_segment_name']
            self.cursor.execute(query)
            query = self.sql_file['update_product_details']
            self.cursor.execute(query)
            # query = self.sql_file['delete_duplciates_product_lines']
            # self.cursor.execute(query)
            # query = self.sql_file['delete_duplicate_segment_lines']
            # self.cursor.execute(query)
            query = self.sql_file['update_product_brand_ids']
            self.cursor.execute(query)
        except Exception as e:
            logger.findaylog(""" @ 3944 EXCEPTION - models - onboard -
                             sync """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - onboard - sync(-)')
        return 'success'

    def get_active_products(self, segments, language_id):
        logger.addinfo('@ models - onboard - get_active_products(+)')
        try:
            self.acquire()
            query = self.sql_file['get_active_products']
            products_str = ''
            products_str = ',' . join(["'" + str(i['item_code']) + "'"
                                       for i in segments])
            query = query % products_str
            self.cursor.execute(query, p_language_id=language_id)
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 3966 EXCEPTION - models - onboard -
                             get_active_products """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - onboard - get_active_products(-)')
        return result

    def send_log(self, func, err, inp):
        LogUtil.send_log({
            'source': 'Finapi',
            'module': 'Product Onboard',
            'function': func,
            'error_msg': err,
            'input_data': inp
        })
