from finapi.utils import db_util
from finapi.utils.logdata import logger


class Schedules:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def head_id():
        logger.addinfo('@models - schedules - head_id(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedule_header_sequence']
            data = cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - models - schedules -
                 header_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - header_id(-)")
        return header_id

    @staticmethod
    def insertSchedule(jsonData, header_id):
        logger.addinfo('@models - schedules - insertSchedule(+)')
        lines = jsonData['lines']
        del jsonData['lines']
        result = Schedules.insert_lines(lines, header_id)
        if result == "success":
            con = None
            cur = None
            try:
                return_data = {}
                con = db_util.get_connection()
                sql_file = db_util.getSqlData()
                cur = con.cursor()
                row_data = []
                query = sql_file['schedule_insert_query1']
                my_data = []
                for key, value in jsonData.items():
                    my_data.append(value)
                    my_new_tuple = tuple(my_data)
                row_data.append(my_new_tuple)
                for key, value in jsonData.items():
                    query += str(key)
                    query += ','
                query = query[:-1] + sql_file["schedule_insert_query2"]
                query += str(header_id) + ","
                sql_args = ""
                for idx, key in enumerate(jsonData.items()):
                    sql_args += ":" + str(idx) + ","
                query = query + sql_args[:-1] + ")"
                cur.executemany(query, row_data)
                con.commit()
                return_data['req_id'] = header_id
                return_data['status'] = 0
                return_data['result'] = "success"
                return_data['msg'] = "Schedule created suceesfully"
            except Exception as error:
                logger.findaylog("""@ 124 EXCEPTION - models - schedules -
                        insertSchedule """ + str(error))
                raise error
            finally:
                cur.close()
                db_util.release_connection(con)
            logger.addinfo('@ models - schedules - insertSchedule(-)')
            return return_data
        else:
            return_data = {}
            return_data['result'] = "fails"
            return_data['status'] = 1
            return_data['msg'] = "Error in creating schedule lines"

    @staticmethod
    def insert_lines(list, header_id):
        logger.addinfo('@ models - schedules - insert_lines(+)')
        sql_file = db_util.getSqlData()
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            for cn_line in list:
                if 'schedule_line_id' not in cn_line:
                    query = sql_file['schedule_line_sequence']
                    cur = connection.cursor()
                    data = cur.execute(query).fetchone()
                    cur.close()
                    cn_line['schedule_line_id'] = data[0]
                cn_line['schedule_header_id'] = header_id
                values = ""
                values = tuple(str(val) for key, val in cn_line.items())
                row_list.append(values)
            if list:
                dict_val = list[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            cursor.prepare("""insert into
            qpex_schedule_lines """ + fieldname_strng+"""
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
            connection.commit()
        except Exception as error:
            logger.findaylog("""@ 323 EXCEPTION - models - schedules -
                 insert_lines """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - schedules - insert_lines(-)')
        return "success"

    @staticmethod
    def get_schedules():
        logger.addinfo('@models - schedules - get_schedules(+)')
        connection = None
        cur = None
        try:
            connection = db_util.get_connection()
            cur = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedules_query']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 154 EXCEPTION - models - schedules -
                 get_schedules """ + str(error))
            raise error
        else:
            schedule_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                schedule_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - get_schedules(-)")
        return schedule_list

    @staticmethod
    def delete_schedule(schedule_id):
        logger.addinfo("@ models - schedules - delete_schedule(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedule_delete_query1']
            cursor.execute(query, p_schedule_id=schedule_id)
            query1 = sql_file['schedule_delete_query2']
            cursor.execute(query1, p_schedule_id=schedule_id)
        except Exception as error:
            logger.findaylog("""@ 185 EXCEPTION - models - schedules -
                 delete_schedule """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - delete_schedule(-)")
        final = {}
        final['status'] = 0
        msg = 'Schedule # ' + str(schedule_id) + ' deleted successfully'
        final['msg'] = msg
        return final

    @staticmethod
    def delete_line(line_id):
        logger.addinfo("@ models - schedules - delete_line(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedule_line_delete_query']
            cursor.execute(query, p_line_id=line_id)
        except Exception as error:
            logger.findaylog("""@ 209 EXCEPTION - models - schedules -
                 delete_line """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - delete_line(-)")
        return 'success'

    @staticmethod
    def show_header(schedule_id):
        logger.addinfo('@ models - schedules - show_header(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['schedule_header_query']
            cursor.execute(query, p_header_id=schedule_id)
            line_details = Schedules.show_lines(schedule_id)
        except Exception as error:
            logger.findaylog("""@ 235 EXCEPTION - models - schedules -
                 show_header """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                header = {}
                for index, fn in enumerate(fieldnames):
                    header[fn] = row[index]
                header['lines'] = line_details
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - schedules - show_header(-)')
        return header

    @staticmethod
    def show_lines(schedule_id):
        logger.addinfo('@models - schedules - show_lines(+)')
        connection = None
        cur = None
        try:
            connection = db_util.get_connection()
            cur = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedule_lines_query']
            cur.execute(query, p_header_id=schedule_id)
        except Exception as error:
            logger.findaylog("""@ 263 EXCEPTION - models - schedules -
                 show_lines """ + str(error))
            raise error
        else:
            lines_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                lines_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - show_lines(-)")
        return lines_list

    @staticmethod
    def line_update(val_list):
        logger.addinfo('@ models - schedules - line_update(+)')
        con = None
        cur = None
        line_id = ''
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            for line in val_list:
                sql_data = 'update qpex_schedule_lines set '
                for key, value in line.items():
                    if key == 'SCHEDULE_LINE_ID':
                        line_id = str(value)
                    sql_data += str(key)+'='
                    if isinstance(value, str):
                        sql_data += "'"
                    if value is not None:
                        sql_data += str(value)
                    if isinstance(value, str):
                        sql_data += "'"
                    sql_data += ','
                sql_data = sql_data[:-1]
                sql_data += " where SCHEDULE_LINE_ID =" + line_id
                cur.execute(sql_data)
                sql_data = ''
        except Exception as error:
            logger.findaylog("""@ 422 EXCEPTION - models - schedules -
                 line_update """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - schedules - line_update(-)')
        return 'success'

    @staticmethod
    def update_schedule(final_dict, survey_id):
        logger.addinfo('@ models - schedules - update_schedule(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_data = 'update qpex_schedule_headers set '
            for key, value in final_dict.items():
                sql_data += str(key)+'='
                if isinstance(value, str):
                    sql_data += "'"
                if value is not None:
                    sql_data += str(value)
                if isinstance(value, str):
                    sql_data += "'"
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += " where SCHEDULE_HEADER_ID =" + str(survey_id)
            cur.execute(sql_data)
        except Exception as error:
            logger.findaylog("""@ 421 EXCEPTION - models - schedules -
                 update_schedule """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - schedules - update_schedule(-)')
        return 'success'
