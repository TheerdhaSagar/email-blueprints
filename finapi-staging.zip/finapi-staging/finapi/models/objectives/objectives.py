import cx_Oracle
from finapi.utils.logdata import logger
from finapi.utils import db_util
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.constants import Status
from finapi.utils.common_utils import CommonUtils
from finapi.utils.log_util import LogUtil
from finapi.models.donation.donation import Donation
from finapi.models.workflows.workflows import Workflows


@LogUtil.class_module_logs('objectives')
class Objectives:

    def __init__(self, **kwargs):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    def get_adhoc_objective(self, jsond):
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_adhoc_objectives']
                if jsond.get('from_date'):
                    query += self.sql_file['from_date_condition']
                    query = query % ("'" + jsond['from_date'] + "'")
                if jsond.get('to_date'):
                    query += self.sql_file['to_date_condition']
                    query = query % ("'" + jsond['to_date'] + "'")
                conn.execute(query, p_org_id=jsond.get('org_id', ''))
                result = conn.get_result()
        except Exception as error:
            logger.findaylog("""EXCEPTION - models - adhoc_objectives -
                                get_adhoc_objectives """ + str(error))
            raise error
        return result

    def insert_adhoc_objective(self, jsond):
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                objective_id = conn.cursor.var(cx_Oracle.NUMBER)
                conn.cursor.execute("""
                    begin
                        qpex_cust_objectives_pkg.insert_adhoc_objective(
                            :x_objective_id,
                            :p_party_name,
                            :p_budget_amount,
                            :p_from_date,
                            :p_to_date,
                            :p_org_id,
                            :p_created_by,
                            :p_sales_channel,
                            :x_status_code
                        );
                    end;""", x_objective_id=objective_id,
                                    p_party_name=jsond['party_name'],
                                    p_budget_amount=jsond['budget_amount'],
                                    p_from_date=jsond['from_date'],
                                    p_to_date=jsond['to_date'],
                                    p_org_id=jsond['org_id'],
                                    p_created_by=jsond['user_id'],
                                    p_sales_channel=jsond['sales_channel'],
                                    x_status_code=status_code
                                    )
            if status_code.getvalue() == 'SUCCESS':
                response = {
                    'msg': 'Objective created successfully',
                    'status': Status.OK.value,
                    'objective_id': int(objective_id.getvalue())
                }
            else:
                response = {
                    'msg': status_code.getvalue(),
                    'status': Status.ERROR.value
                }
        except Exception as error:
            logger.findaylog("""EXCEPTION - models - adhoc_objectives -
                                insert_adhoc_objectives""" + str(error))
            raise error
        return response

    def update_adhoc_objective(self, jsond):
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                    begin
                        qpex_cust_objectives_pkg.update_adhoc_objective(
                            :p_objective_id,
                            :p_party_name,
                            :p_budget_amount,
                            :p_from_date,
                            :p_to_date,
                            :p_last_updated_by,
                            :p_sales_channel,
                            :x_status_code
                        );
                    end;
                """, p_objective_id=jsond['objective_id'],
                             p_party_name=jsond['party_name'],
                             p_budget_amount=jsond['budget_amount'],
                             p_from_date=jsond['from_date'],
                             p_to_date=jsond['to_date'],
                             p_last_updated_by=jsond['user_id'],
                             p_sales_channel=jsond['sales_channel'],
                             x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                response = {
                    'msg': 'Objective updated successfully',
                    'status': Status.OK.value,
                    'objective_id': jsond['objective_id']
                }
            else:
                response = {
                    'msg': status_code.getvalue(),
                    'status': Status.ERROR.value
                }
        except Exception as error:
            logger.findaylog("""EXCEPTION - models- adhoc_objectives -
                                update_adhoc_objective""" + str(error))
            raise error
        return response

    def delete_adhoc_objective(self, objective_id):
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                    begin
                        qpex_cust_objectives_pkg.delete_adhoc_objective(
                            :p_objective_id,
                            :x_status_code
                        );
                    end;
                """, p_objective_id=objective_id,
                             x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                response = {
                    'msg': 'Objective deleted successfully',
                    'status': Status.OK.value
                }
            else:
                response = {
                    'msg': status_code.getvalue(),
                    'status': Status.ERROR.value
                }
        except Exception as error:
            logger.findaylog("""EXCEPTION - models - adhoc_objectives -
                                delete_adhoc_objectives """ + str(error))
            raise error
        return response

    @staticmethod
    def get_budget_categories():
        logger.addinfo('@ models - objectives - get_budget_categories(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['budget_categories_lov']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 26 EXCEPTION - models - objectives -
                 get_budget_categories """ + str(error))
            raise error
        else:
            budget_categories = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                budget = {}
                for index, field in enumerate(field_names):
                    budget[field] = row[index]
                budget_categories.append(budget)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_budget_categories(-)')
        return budget_categories

    @staticmethod
    def get_budget_description():
        logger.addinfo('@ models - objectives - get_budget_description(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['budget_description_lov']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 55 EXCEPTION - models - objectives -
                 get_budget_description """ + str(error))
            raise error
        else:
            budget_descrption = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                budget = {}
                for index, field in enumerate(field_names):
                    budget[field] = row[index]
                budget_descrption.append(budget)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_budget_description(-)')
        return budget_descrption

    @staticmethod
    def get_invoice_frequency():
        logger.addinfo('@ models - objectives - get_invoice_frequency(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_frequency_lov']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 84 EXCEPTION - models - objectives -
                 get_invoice_frequency """ + str(error))
            raise error
        else:
            invoice_frequency = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                frequency = {}
                for index, field in enumerate(field_names):
                    frequency[field] = row[index]
                invoice_frequency.append(frequency)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_invoice_frequency(-)')
        return invoice_frequency

    @staticmethod
    def get_targets():
        logger.addinfo('@ models - objectives - get_targets(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['target_base_lov']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 113 EXCEPTION - models - objectives -
                 get_targets """ + str(error))
            raise error
        else:
            targets = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                target = {}
                for index, field in enumerate(field_names):
                    target[field] = row[index]
                targets.append(target)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_targets(-)')
        return targets

    def get_customer_objectives(self, jsond):
        cust_objectives = []
        with OracleConnectionManager() as conn:
            kwargs = {'p_org_id': jsond['org_id']}
            query = self.sql_file['customer_objectives']

            # Get data from previous year to sysdate if date filters are not selected
            if not jsond['start_date'] and not jsond['end_date']:
                query += self.sql_file['customer_objectives_date_filter']

            if jsond['start_date']:
                query += self.sql_file['customer_objectives_start_date_filter']
                kwargs['p_start_date'] = jsond['start_date']
            if jsond['end_date']:
                query += self.sql_file['customer_objectives_end_date_filter']
                kwargs['p_end_date'] = jsond['end_date']
            if jsond['customer_number']:
                query += self.sql_file['customer_objectives_customer_filter']
                kwargs['p_customer_number'] = jsond['customer_number']
            conn.execute(query, **kwargs)
            cust_objectives = conn.get_result()
        return cust_objectives

    @staticmethod
    def delete_objective(objective_id):
        logger.addinfo('@ models - objectives - delete_objective(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status_code = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
            qpex_cust_objectives_pkg.delete_objective(
            :p_cust_objective_id,
            :x_status_code);
            end;""", p_cust_objective_id=objective_id,
                        x_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ 142 EXCEPTION - models - objectives -
                 delete_objective """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_objective(-)')
        return status_code.getvalue()

    @staticmethod
    def save_objective(jsond):
        logger.addinfo('@ models - objectives - save_objective(+)')
        con = None
        cur = None
        try:
            if 'status' not in jsond:
                jsond['status'] = None
            if 'approver_id' not in jsond:
                jsond['approver_id'] = None
            con = db_util.get_connection()
            cur = con.cursor()
            cust_objective_id = cur.var(cx_Oracle.NUMBER)
            tmp_budget = jsond['budget']
            customers = jsond['related_customers']
            vendors = jsond['related_vendors']
            attachments = jsond['attachments']
            status_code = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
            qpex_cust_objectives_pkg.insert_objective(
             :x_cust_objective_id,
             :p_customer_id,
             :p_customer_reference,
             :p_start_date,
             :p_end_date,
             :p_target_amount,
             :p_target_base_id,
             :p_target_description,
             :p_bonus_percentage,
             :p_calc_bonus_amount,
             :p_final_bonus_amount,
             :p_bonus_return_type,
             :p_created_by,
             :p_creation_date,
             :p_org_id,
             :p_last_updated_by,
             :p_last_update_date,
             :p_customer_name,
             :p_customer_number,
             :p_fixed_bonus,
             :p_target_group,
             :p_status,
             :p_party_type,
             :p_approver_id,
             :x_status_code);
             end;""", x_cust_objective_id=cust_objective_id,
                        p_customer_id=jsond['customer_id'],
                        p_customer_reference=jsond['customer_reference'],
                        p_start_date=jsond['start_date'],
                        p_end_date=jsond['end_date'],
                        p_target_amount=None,
                        p_target_base_id=None,
                        p_target_description=None,
                        p_bonus_percentage=None,
                        p_calc_bonus_amount=None,
                        p_final_bonus_amount=None,
                        p_bonus_return_type=None,
                        p_created_by=jsond['created_by'],
                        p_creation_date=jsond['creation_date'],
                        p_org_id=jsond['org_id'],
                        p_last_updated_by=jsond['last_updated_by'],
                        p_last_update_date=jsond['last_updated_date'],
                        p_customer_name=jsond['customer_name'],
                        p_customer_number=jsond['customer_number'],
                        p_fixed_bonus=None,
                        p_target_group=None,
                        p_status=jsond['status'],
                        p_party_type=jsond['party_type'],
                        p_approver_id=jsond['approver_id'],
                        x_status_code=status_code)
            customer_sequence = int(cust_objective_id.getvalue())
            objective_status = []
            if status_code.getvalue() == 'S':
                if len(attachments) > 0:
                    result = Objectives.save_attachments(
                        attachments, customer_sequence)
                    if result != 'success':
                        objective_status.append('attachments')
                result = Objectives.save_objective_lines(
                    tmp_budget, customer_sequence)
                if result != 'success':
                    objective_status.append('lines')
                if len(customers) > 0:
                    result = Objectives.save_related_customer(
                        customers, customer_sequence)
                    if result != 'success':
                        objective_status.append('customers')
                if len(vendors) > 0:
                    result = Objectives.save_related_vendors(
                        vendors, customer_sequence)
                    if result != 'success':
                        objective_status.append('vendors')
                if jsond['send_for_approval'] == 'Y' and not objective_status:
                    strings = db_util.get_strings()
                    subject = strings['objective_approval_request']
                    subject += '#' + str(customer_sequence) + ' for '
                    subject += 'customer ' if jsond['party_type'] == 'CUS' else 'vendor '
                    subject += jsond['customer_name']
                    email_obj = {
                        'created_by': jsond['created_user_name'],
                        'approver_name': jsond['approver_name'],
                        'from_date': jsond['start_date'],
                        'to_date': jsond['end_date'],
                        'contract_for': 'customer' if jsond['party_type'] == 'CUS' else 'vendor',
                        'contract_for_name': jsond['customer_name'],
                        'old_approver': jsond['old_approver'],
                        'new_approver': jsond['approver_name'],
                        'objective_id': customer_sequence,
                        'target_status': '',
                        'attachment_count': jsond['attachment_count'],
                        'recipient_id': jsond['approver_id'],
                        'template_id': 693146,
                        'budgets': [],
                        'subject': subject,
                        'org_id': jsond['org_id']
                    }
                    for budget in tmp_budget:
                        email_obj['budgets'].append({
                            'budget_category': budget['budget_category'],
                            'budget': budget['budget'],
                            'target_base': budget['target_base'],
                            'description': budget['target_description'],
                            'target_amount': budget['target_amount'],
                            'start_date': budget['start_date'],
                            'end_date': budget['end_date'],
                            'target_group': 'Yes' if budget['target_group'] == 1 else 'No',
                            'fixed_bonus': budget['fixed_bonus'],
                            'bonus_percentage': budget['bonus_percentage'],
                            'last_updated': budget['last_updated_date']
                        })
                    result = Objectives.send_email(email_obj)
                    if result != 'success':
                        objective_status.append('email')
                if len(objective_status) == 0:
                    objective_status.append('success')
            else:
                objective_status.append('error')
        except Exception as error:
            logger.findaylog("""@ 297 EXCEPTION - models - objectives -
                 save_objective """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - save_objective(-)')
        return objective_status

    @staticmethod
    def save_objective_lines(budgets, line_id):
        logger.addinfo('@ models - objectives - save_objective_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            lines_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for line in budgets:
                cur.execute("""
                begin
                    qpex_cust_objectives_pkg.insert_objective_line (
                    :p_cust_objective_id,
                    :p_line_number,
                    :p_target_amount,
                    :p_target_base_id,
                    :p_target_description,
                    :p_bonus_percentage,
                    :p_calc_bonus_amount,
                    :p_final_bonus_amount,
                    :p_bonus_return_type,
                    :p_fixed_bonus,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_by,
                    :p_last_update_date,
                    :p_budget_category,
                    :p_budge_name,
                    :p_document_created_flag,
                    :p_start_date,
                    :p_end_date,
                    :p_invoice_frequency,
                    :p_target_group,
                    :x_status_code);
                    end;""", p_cust_objective_id=line_id,
                            p_line_number=line['line_number'],
                            p_target_amount=line['target_amount'],
                            p_target_base_id=line['target_base_id'],
                            p_target_description=line['target_description'],
                            p_bonus_percentage=line['bonus_percentage'],
                            p_calc_bonus_amount=line['calc_bonus_amount'],
                            p_final_bonus_amount=line['final_bonus_amount'],
                            p_bonus_return_type=line['bonus_return_type'],
                            p_fixed_bonus=line['fixed_bonus'],
                            p_creation_date=line['creation_date'],
                            p_created_by=line['created_by'],
                            p_last_updated_by=line['last_updated_by'],
                            p_last_update_date=line['last_updated_date'],
                            p_budget_category=line['budget_category'],
                            p_budge_name=line['budget_name'],
                            p_document_created_flag=line[
                                'document_created_flag'],
                            p_start_date=line['start_date'],
                            p_end_date=line['end_date'],
                            p_invoice_frequency=line['invoice_frequency'],
                            p_target_group=line['target_group'],
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    lines_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 364 EXCEPTION - models - objectives -
                 save_objective_lines """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - save_objective_lines(-)')
        return lines_status

    @staticmethod
    def save_related_customer(customers, line_id):
        logger.addinfo('@ models - objectives - save_related_customer(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            customer_status = 'success'
            customer_seq = cur.var(cx_Oracle.NUMBER)
            status_code = cur.var(cx_Oracle.STRING)
            for line in customers:
                cur.execute("""
                begin
                    qpex_cust_objectives_pkg.insert_related_customer(
                    :p_customer_id,
                    :p_customer_name,
                    :p_customer_number,
                    :p_rel_customer_name,
                    :p_rel_customer_id,
                    :p_rel_cust_number,
                    :p_cust_objective_id,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_cust_rel_obj_line_id,
                    :x_status_code
                    );
                    end;""", p_customer_id=line['customer_id'],
                            p_customer_name=line['customer_name'],
                            p_customer_number=line['customer_number'],
                            p_rel_customer_name=line['rel_customer_name'],
                            p_rel_customer_id=line['rel_customer_id'],
                            p_rel_cust_number=line['rel_cust_number'],
                            p_cust_objective_id=line_id,
                            p_creation_date=line['creation_date'],
                            p_created_by=line['created_by'],
                            p_last_update_date=line['last_updated_date'],
                            p_last_updated_by=line['last_updated_by'],
                            x_cust_rel_obj_line_id=customer_seq,
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    customer_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 414 EXCEPTION - models - objectives -
                 save_related_customer """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - save_related_customer(-)')
        return customer_status

    @staticmethod
    def save_related_vendors(vendors, line_id):
        logger.addinfo('@ models - objectives - save_related_vendors(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            vendor_status = 'success'
            vendor_seq = cur.var(cx_Oracle.NUMBER)
            status_code = cur.var(cx_Oracle.STRING)
            for line in vendors:
                cur.execute("""
                begin
                    qpex_cust_objectives_pkg.insert_related_vendor(
                    :p_customer_id,
                    :p_customer_name,
                    :p_customer_number,
                    :p_rel_customer_name,
                    :p_rel_vendor_id,
                    :p_rel_vendor_number,
                    :p_cust_objective_id,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_cust_rel_obj_line_id,
                    :x_status_code
                    );
                    end;""", p_customer_id=line['customer_id'],
                            p_customer_name=line['customer_name'],
                            p_customer_number=line['customer_number'],
                            p_rel_customer_name=line['rel_customer_name'],
                            p_rel_vendor_id=line['rel_vendor_id'],
                            p_rel_vendor_number=line['rel_vendor_number'],
                            p_cust_objective_id=line_id,
                            p_creation_date=line['creation_date'],
                            p_created_by=line['created_by'],
                            p_last_update_date=line['last_updated_date'],
                            p_last_updated_by=line['last_updated_by'],
                            x_cust_rel_obj_line_id=vendor_seq,
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    vendor_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 464 EXCEPTION - models - objectives -
                 save_related_vendors """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - save_related_vendors(-)')
        return vendor_status

    @staticmethod
    def get_objective_details(objective_id):
        logger.addinfo('@ models - objectives - get_objective_details(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_objective_header']
            cur.execute(query, p_objective_id=objective_id)
            details = []
            field_names = [a[0].lower()for a in cur.description]
            for row in cur:
                detail = {}
                for index, field in enumerate(field_names):
                    detail[field] = row[index]
                details.append(detail)
            lines = Objectives.get_objective_lines(objective_id)
            customers = Objectives.get_related_customers(objective_id)
            vendors = Objectives.get_related_vendors(objective_id)
            attachments = Objectives.get_attachments(objective_id)
            result = {}
            result['header'] = details
            result['budget_lines'] = lines
            result['related_customers'] = customers
            result['related_vendors'] = vendors
            result['attachments'] = attachments
        except Exception as error:
            logger.findaylog("""@ 142 EXCEPTION - models - objectives -
                 get_objective_details """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_objective_details(-)')
        return result

    @staticmethod
    def get_objective_lines(objective_id):
        logger.addinfo('@ models - objectives - get_objective_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_objective_lines']
            cur.execute(query, p_objective_id=objective_id)
            lines = []
            lines = Code_util.iterate_data(cur)
            for i in range(len(lines)):
                for j in range(len(lines[i]['attachments'])):
                    if lines[i]['attachments'][j]['file_blob'] and type(lines[i]['attachments'][j]['file_blob']) == cx_Oracle.LOB:
                        lines[i]['attachments'][j]['file_blob'] = lines[i]['attachments'][j]['file_blob'].read()
        except Exception as error:
            logger.findaylog("""@ 497 EXCEPTION - models - objectives -
                 get_objective_lines """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_objective_details(-)')
        return lines

    @staticmethod
    def get_related_customers(objective_id):
        logger.addinfo('@ models - objectives - get_related_customers(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_related_customers']
            cur.execute(query, p_objective_id=objective_id)
            related_customers = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                customer = {}
                for index, field in enumerate(field_names):
                    customer[field] = row[index]
                related_customers.append(customer)
        except Exception as error:
            logger.findaylog("""@ 545 EXCEPTION - models - objectives -
                 get_related_customers """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_related_customers(-)')
        return related_customers

    @staticmethod
    def get_related_vendors(objective_id):
        logger.addinfo('@ models - objectives - get_related_vendors(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_related_vendors']
            cur.execute(query, p_objective_id=objective_id)
            related_vendors = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                vendor = {}
                for index, field in enumerate(field_names):
                    vendor[field] = row[index]
                related_vendors.append(vendor)
        except Exception as error:
            logger.findaylog("""@ 497 EXCEPTION - models - objectives -
                 get_related_vendors """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_related_vendors(-)')
        return related_vendors

    def update_objective(self, jsond):
        logger.addinfo('@ models - objectives - update_objective(+)')
        try:
            status_code = ''
            error_status = 'SUCCESS'
            with OracleConnectionManager() as conn:
                if 'status' not in jsond:
                    jsond['status'] = None
                if 'approver_id' not in jsond:
                    jsond['approver_id'] = None
                if jsond['status'] == 'A':
                    jsond, error_status = self.approve_jsond_details(conn, jsond)
                if error_status == 'SUCCESS':
                    conn.execute("""
                    begin
                    qpex_cust_objectives_pkg.update_objective(
                    :p_cust_objective_id,
                    :p_customer_id,
                    :p_customer_reference,
                    :p_start_date,
                    :p_end_date,
                    :p_target_amount,
                    :p_target_base_id,
                    :p_target_description,
                    :p_bonus_percentage,
                    :p_calc_bonus_amount,
                    :p_final_bonus_amount,
                    :p_bonus_return_type,
                    :p_org_id,
                    :p_last_updated_by,
                    :p_last_update_date,
                    :p_customer_name,
                    :p_customer_number,
                    :p_fixed_bonus,
                    :p_target_group,
                    :p_status,
                    :p_party_type,
                    :p_approver_id,
                    :x_status_code);
                    end;""", output_key='x_status_code',
                                 p_cust_objective_id=jsond['cust_objective_id'],
                                 p_customer_id=jsond['customer_id'],
                                 p_customer_reference=jsond['customer_reference'],
                                 p_start_date=jsond['start_date'],
                                 p_end_date=jsond['end_date'],
                                 p_target_amount=None,
                                 p_target_base_id=None,
                                 p_target_description=None,
                                 p_bonus_percentage=None,
                                 p_calc_bonus_amount=None,
                                 p_final_bonus_amount=None,
                                 p_bonus_return_type=None,
                                 p_org_id=jsond['org_id'],
                                 p_last_updated_by=jsond['last_updated_by'],
                                 p_last_update_date=jsond['last_updated_date'],
                                 p_customer_name=jsond['customer_name'],
                                 p_customer_number=jsond['customer_number'],
                                 p_fixed_bonus=None,
                                 p_target_group=None,
                                 p_status=jsond['status'],
                                 p_party_type=jsond['party_type'],
                                 p_approver_id=jsond['approver_id'])
                    objective_status = []
                    status_code = conn.get_output_param(raise_exception=False, send_email=False)
                    if status_code == 'S':
                        objective_status = self.update_objective_send_email(
                            jsond, objective_status)
                        if len(objective_status) == 0:
                            objective_status.append('success')
                    else:
                        objective_status.append('error')
                else:
                    objective_status.append('error')
        except Exception as error:
            logger.findaylog("""@ 675 EXCEPTION - models - objectives -
                 update_objective """ + str(error))
            raise error
        logger.addinfo('@ models - objectives - update_objective(-)')
        return objective_status

    def approve_jsond_details(self, conn, jsond):
        error_status = 'SUCCESS'
        # fetch workflow id and name
        query = self.sql_file['workflow_details']
        conn.execute(query, p_workflow='QPEX_OBJECTIVES')
        workflow_details = conn.get_single_result()
        jsond['workflow_id'] = workflow_details['workflow_id']
        jsond['wf_name'] = 'QPEX_OBJECTIVES'
        # fetch notification approvers of the workflow
        wf_users_details = Workflows().get_workflow_approvers(
            workflow_details['workflow_id'])
        # start the workflow if notifications
        approver_id = Donation().start_lovefood_flow(
            jsond['cust_objective_id'], jsond)
        # check if the approver_id is an existing workflow user
        existing_approver = next(
            (item for item in wf_users_details if item['approver_id'] == jsond['approver_id']),
            None)
        if existing_approver:
            jsond['wf_key'] = jsond['cust_objective_id']
            # find the next approver id
            jsond['new_approver_id'] = next(
                (item['approver_id'] for item in wf_users_details if item['approver_seq'] ==
                    existing_approver['approver_seq'] + 1), None)
            # check if the approver_id from start flow the same as the next approver,
            # if not update it with the next approver_id
            if jsond['new_approver_id'] != approver_id:
                update_notify = Workflows.update_wf_notify_based_on_approver_id(jsond)
                if update_notify['status'] != 0:
                    error_status = 'Failed to update'
                approver_id = jsond['new_approver_id']
        if approver_id:
            name, email = Donation().get_approver_details(approver_id)
            jsond['status'] = 'I'
            jsond['approver_id'] = approver_id
            jsond['old_approver_id'] = approver_id
            jsond['approver_name'] = name
            jsond['approver_email'] = email
        return jsond, error_status

    def update_objective_send_email(self, jsond, objective_status):
        tmp_budget = jsond['budget']
        strings = db_util.get_strings()
        objective_status = Objectives.update_objective_details(jsond, objective_status)
        party_type = 'customer' if jsond['party_type'] == 'CUS' else 'vendor '
        if jsond['send_for_approval'] == 'Y' and not objective_status:
            contract_for = '#' + str(jsond['cust_objective_id']) + ' for '
            contract_for += party_type + ' '
            contract_for += jsond['customer_name']
            if jsond['status'] == 'I':
                subject = strings['objective_approval_request'] + contract_for
                template_id = 693146
                recipient_id = jsond['approver_id']
            else:
                subject = strings['objective_approved'] + contract_for
                subject += ' is approved by ' + jsond['approver_name']
                template_id = 693141
                recipient_id = jsond['created_by']
            email_obj = {
                'created_by': jsond['created_user_name'],
                'approver_name': jsond['approver_name'],
                'from_date': jsond['start_date'],
                'to_date': jsond['end_date'],
                'contract_for': party_type,
                'contract_for_name': jsond['customer_name'],
                'old_approver': jsond['old_approver'],
                'new_approver': jsond['approver_name'],
                'objective_id': jsond['cust_objective_id'],
                'target_status': 'approved',
                'attachment_count': jsond['attachment_count'],
                'recipient_id': recipient_id,
                'template_id': template_id,
                'budgets': [],
                'subject': subject,
                'org_id': jsond['org_id']
            }
            for budget in tmp_budget:
                email_obj['budgets'].append({
                    'budget_category': budget['budget_category'],
                    'budget': budget['budget'],
                    'target_base': budget['target_base'],
                    'description': budget['target_description'],
                    'target_amount': budget['target_amount'],
                    'start_date': budget['start_date'],
                    'end_date': budget['end_date'],
                    'target_group': 'Yes' if budget['target_group'] == 1 else 'No',
                    'fixed_bonus': budget['fixed_bonus'],
                    'bonus_percentage': budget['bonus_percentage'],
                    'last_updated': budget['last_updated_date']
                })
            result = Objectives.send_email(email_obj)
            if result != 'success':
                objective_status.append('email')
            objective_status = Objectives.change_in_approver(strings, jsond,
                                                             email_obj, objective_status)
        else:
            objective_status.append('email')
        return objective_status

    @staticmethod
    def change_in_approver(strings, jsond, email_obj, objective_status):
        # Send notification to old approver about change in approver
        if jsond['old_approver_id'] and jsond['old_approver_id'] != jsond['approver_id']:
            if jsond.get('cust_objective_id'):
                # Delete Workflow if the approver is changed
                del_workflow_status = Workflows.delete_workflow_with_wf_key(
                    jsond['cust_objective_id'])
                if del_workflow_status != 'S':
                    objective_status.append('workflow-delete')
            subject = strings['objective_update_manager']
            subject += '#' + str(jsond['cust_objective_id']) + \
                ' is transferred to '
            subject += jsond['approver_name']
            email_obj['recipient_id'] = jsond['old_approver_id']
            email_obj['template_id'] = 693149
            email_obj['subject'] = subject
            result = Objectives.send_email(email_obj)
            if result != 'success':
                objective_status.append('email_updated')
        return objective_status

    @staticmethod
    def update_objective_details(jsond, objective_status):
        objective_id = jsond['cust_objective_id']
        tmp_budget = jsond['budget']
        customers = jsond['related_customers']
        vendors = jsond['related_vendors']
        attachments = jsond['attachments']
        deleted_attachments = jsond['deleted_attachments']

        result = Objectives.save_attachments(attachments, objective_id)
        if result != 'success':
            objective_status.append('attachments')
        result = Objectives.update_objective_lines(tmp_budget, objective_id)
        if result != 'success':
            objective_status.append('lines')
        result = Objectives.delete_objective_lines(jsond['deleted_lines'])
        if result != 'success':
            objective_status.append('deleted_lines')
        result = Objectives.delete_related_customer(jsond['deleted_customers'])
        if result != 'success':
            objective_status.append('deleted_customers')
        result = Objectives.delete_related_vendor(jsond['deleted_vendors'])
        if result != 'success':
            objective_status.append('deleted_vendors')
        if customers:
            result = Objectives.save_related_customer(
                customers, objective_id)
            if result != 'success':
                objective_status.append('customers')
        if vendors:
            result = Objectives.save_related_vendors(
                vendors, objective_id)
            if result != 'success':
                objective_status.append('vendors')
        if deleted_attachments:
            result = Objectives.delete_attachment(deleted_attachments)
            if result != 'success':
                objective_status.append('delete_attachments')
        return objective_status

    @staticmethod
    def update_objective_lines(budgets, objective_id):
        logger.addinfo('@ models - objectives - update_objective_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status_code = cur.var(cx_Oracle.STRING)
            line_status = 'success'
            for line in budgets:
                if 'cust_objective_id' in line:
                    cur.execute("""
                    begin
                        qpex_cust_objectives_pkg.update_objective_line (
                        :p_cust_objective_id,
                        :p_line_number,
                        :p_target_amount,
                        :p_target_base_id,
                        :p_target_description,
                        :p_bonus_percentage,
                        :p_calc_bonus_amount,
                        :p_final_bonus_amount,
                        :p_bonus_return_type,
                        :p_fixed_bonus,
                        :p_last_updated_by,
                        :p_last_update_date,
                        :p_budget_category,
                        :p_budge_name,
                        :p_document_created_flag,
                        :p_start_date,
                        :p_end_date,
                        :p_invoice_frequency,
                        :p_target_group,
                        :x_status_code);
                        end;""", p_cust_objective_id=line['cust_objective_id'],
                                p_line_number=line['line_number'],
                                p_target_amount=line['target_amount'],
                                p_target_base_id=line['target_base_id'],
                                p_target_description=line[
                                    'target_description'],
                                p_bonus_percentage=line['bonus_percentage'],
                                p_calc_bonus_amount=line['calc_bonus_amount'],
                                p_final_bonus_amount=line[
                                    'final_bonus_amount'],
                                p_bonus_return_type=line['bonus_return_type'],
                                p_fixed_bonus=line['fixed_bonus'],
                                p_last_updated_by=line['last_updated_by'],
                                p_last_update_date=line['last_updated_date'],
                                p_budget_category=line['budget_category'],
                                p_budge_name=line['budget_name'],
                                p_document_created_flag=line[
                                    'document_created_flag'],
                                p_start_date=line['start_date'],
                                p_end_date=line['end_date'],
                                p_invoice_frequency=line['invoice_frequency'],
                                p_target_group=line['target_group'],
                                x_status_code=status_code)
                    if status_code.getvalue() != 'S':
                        line_status = 'error'
                else:
                    new_line = []
                    new_line.append(line)
                    status = Objectives.save_objective_lines(
                        new_line, objective_id)
                    if status != 'success':
                        line_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 297 EXCEPTION - models - objectives -
                 update_objective_lines """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - update_objective_lines(-)')
        return line_status

    @staticmethod
    def delete_objective_lines(deleted_lines):
        logger.addinfo('@ models - objectives - delete_objective_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            delete_line_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for line in deleted_lines:
                cur.execute("""
                begin
                qpex_cust_objectives_pkg.delete_objective_line(
                :p_cust_objective_id,
                :p_line_number,
                :x_status_code);
                end;""", p_cust_objective_id=line['cust_objective_id'],
                            p_line_number=line['line_number'],
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    delete_line_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 297 EXCEPTION - models - objectives -
                 delete_objective_lines """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_objective_lines(-)')
        return delete_line_status

    @staticmethod
    def delete_related_customer(deleted_customers):
        logger.addinfo('@ models - objectives - delete_related_customer(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            delete_customer_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for line in deleted_customers:
                cur.execute("""
                begin
                qpex_cust_objectives_pkg.delete_related_customer(
                :p_cust_objective_id,
                :p_cust_rel_obj_line_id,
                :x_status_code);
                end;""", p_cust_objective_id=line['cust_objective_id'],
                            p_cust_rel_obj_line_id=line[
                    'cust_rel_obj_line_id'],
                    x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    delete_customer_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 297 EXCEPTION - models - objectives -
                 delete_related_customer """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_related_customer(-)')
        return delete_customer_status

    @staticmethod
    def delete_related_vendor(deleted_vendors):
        logger.addinfo('@ models - objectives - delete_related_vendor(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            delete_vendor_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for line in deleted_vendors:
                cur.execute("""
                begin
                qpex_cust_objectives_pkg.delete_related_vendor(
                :p_cust_objective_id,
                :p_cust_rel_obj_line_id,
                :x_status_code);
                end;""", p_cust_objective_id=line['cust_objective_id'],
                            p_cust_rel_obj_line_id=line[
                    'cust_rel_obj_line_id'],
                    x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    delete_vendor_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 297 EXCEPTION - models - objectives -
                 delete_related_vendor """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_related_vendor(-)')
        return delete_vendor_status

    @staticmethod
    def save_attachments(attachments, objective_id):
        logger.addinfo('@ models - objectives - delete_related_vendor(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            attachment_status = 'success'
            cur.setinputsizes(p_blob=cx_Oracle.BLOB)
            status_code = cur.var(cx_Oracle.STRING)
            for a in attachments:
                if 'line_number' in a:
                    ref_id = str(int(objective_id)) + '-' + str(a['line_number'])
                else:
                    ref_id = objective_id
                cur.execute(""" declare
                begin
                :retval := qpex_attachments.add_attachment(
                :pref,
                :ptitle,
                :pfilename,
                :pdesc,
                :p_blob,
                :pcontent_type,
                :pentity,
                :pcategory);
                end;""", pref=ref_id,
                            ptitle=a['title'],
                            pfilename=a['file_name'],
                            pdesc=a['description'],
                            p_blob=a['file_blob'],
                            pcontent_type=a['content_type'],
                            pentity=a['entity_name'],
                            pcategory=a['category_name'],
                            retval=status_code)
                if status_code.getvalue() == 'S':
                    attachment_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 297 EXCEPTION - models - objectives -
                 delete_related_vendor """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_related_vendor(-)')
        return attachment_status

    @staticmethod
    def get_attachments(objective_id):
        logger.addinfo('@ models - objectives - get_attachments(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_objective_attachments']
            cur.execute(query, p_attachseq=str(objective_id))
            attachments = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                attachment = {}
                for index, field in enumerate(field_names):
                    if field == 'file_data':
                        attachment[field] = row[index].read().decode('utf-8')
                    else:
                        attachment[field] = row[index]
                attachments.append(attachment)
        except Exception as error:
            logger.findaylog("""@ 297 EXCEPTION - models - objectives -
                 get_attachments """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_attachments(-)')
        return attachments

    @staticmethod
    def delete_attachment(attachments):
        logger.addinfo('@ models - objectives - delete_attachment(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            attachment_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for a in attachments:
                cur.execute(""" declare
                    begin
                        :retval := qpex_attachments.delete_attachment(
                        :p_file_id);
                        end;""", p_file_id=a['file_id'],
                            retval=status_code)
                if status_code.getvalue() != 'S':
                    attachment_status = 'error'
        except Exception as error:
            logger.findaylog("""@ 297 EXCEPTION - models - objectives -
                 delete_attachment """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_attachment(-)')
        return attachment_status

    @staticmethod
    def update_status(jsond):
        logger.addinfo('@ models - objectives - update_status(+)')
        con = None
        cur = None
        response = ''
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status = cur.var(cx_Oracle.STRING)
            cur.execute("""
                begin
                qpex_cust_objectives_pkg.update_status(
                    :p_cust_objective_id,
                    :p_status,
                    :p_updated_by,
                    :x_status_code);
                end;""", p_cust_objective_id=jsond['cust_objective_id'],
                        p_status=jsond['status'],
                        p_updated_by=jsond['last_updated_by'],
                        x_status_code=status)

            if status.getvalue() == 'SUCCESS':
                response = 'success'
                strings = db_util.get_strings()
                subject = strings['objective_approved']
                subject += '#' + str(jsond['cust_objective_id']) + ' is rejected by '
                subject += jsond['approver_name']
                email_obj = {
                    'created_by': jsond['created_user_name'],
                    'approver_name': jsond['approver_name'],
                    'from_date': jsond['start_date'],
                    'to_date': jsond['end_date'],
                    'contract_for': '',
                    'contract_for_name': '',
                    'old_approver': '',
                    'new_approver': '',
                    'objective_id': jsond['cust_objective_id'],
                    'target_status': 'rejected',
                    'attachment_count': '',
                    'recipient_id': jsond['created_by'],
                    'template_id': 693141,
                    'budgets': [],
                    'subject': subject,
                    'org_id': jsond['org_id']
                }
                result = Objectives.send_email(email_obj)
                if result != 'success':
                    response = 'failed'
            else:
                response = status.getvalue()
        except Exception as error:
            logger.findaylog("""@ 1018 EXCEPTION - models - objectives -
                             update_status """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - update_status(-)')
        return response

    @staticmethod
    def send_email(jsond):
        logger.addinfo('models - objectives - send_email(+)')
        try:
            sql_file = db_util.getSqlData()
            with OracleConnectionManager() as conn:
                query = sql_file['user_data_query']
                conn.execute(query, p_user_id=jsond['recipient_id'])
                data = conn.get_single_result()
                email_address = data['email_address']

            strings = db_util.get_strings()
            mail_data = {
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                },
                'subject': jsond['subject'],
                'template_id': jsond['template_id'],
                'params': [
                    {
                        'key': 'created_by',
                        'value': jsond['created_by']
                    },
                    {
                        'key': 'approver_name',
                        'value': jsond['approver_name']
                    },
                    {
                        'key': 'target_status',
                        'value': jsond['target_status']
                    },
                    {
                        'key': 'from_date',
                        'value': jsond['from_date']
                    },
                    {
                        'key': 'to_date',
                        'value': jsond['to_date']
                    },
                    {
                        'key': 'objective_id',
                        'value': jsond['objective_id']
                    },
                    {
                        'key': 'contract_for',
                        'value': jsond['contract_for']
                    },
                    {
                        'key': 'contract_for_name',
                        'value': jsond['contract_for_name']
                    },
                    {
                        'key': 'attachment_count',
                        'value': jsond['attachment_count']
                    },
                    {
                        'key': 'old_approver',
                        'value': jsond['old_approver']
                    },
                    {
                        'key': 'new_approver',
                        'value': jsond['new_approver']
                    },
                    {
                        'key': 'budgets',
                        'value': jsond['budgets']
                    },
                    {
                        'key': 'org_id',
                        'value': jsond['org_id']
                    }
                ],
                'to_email': email_address
            }
            result = CommonUtils.send_mail(mail_data)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - objectives -
                              send_email """ + str(e))
            raise e
        logger.addinfo('@ models - objectives - send_email(+)')
        return 'success' if result == 'SUCCESS' else 'failed'
