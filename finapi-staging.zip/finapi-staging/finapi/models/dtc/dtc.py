import os
import base64

from datetime import datetime
from collections import OrderedDict

import cx_Oracle
import xlsxwriter

from finapi.sql import sql_util
from finapi.utils.log_util import LogUtil
from finapi.models.quotes.quote import Quotes
from finapi.utils.common_utils import CommonUtils
from finapi.utils.conn_util import OracleConnectionManager


@LogUtil.class_module_logs('dtc')
class DTC(object):
    @staticmethod
    def create_quote(req):
        result = {'status': 0}
        with OracleConnectionManager() as conn:
            _shipments = req.get('shipments', [{}])
            shipments = {}
            for key in list(_shipments[0].keys()):
                shipments.update({key: [shipment[key] for shipment in _shipments]})
            batch_id = conn.cursor.var(cx_Oracle.NUMBER)
            conn.execute('''
            declare
                p_shipments     qpex_dtc_pkg.shipments;

                type t_number_table is table of number index by binary_integer;
                type t_string_table is table of varchar2(300) index by binary_integer;

                l_dtc_customer_identifiers   t_string_table := :p_dtc_customer_identifiers;
                l_dtc_order_numbers          t_number_table := :p_dtc_order_numbers;
                l_business_names             t_string_table := :p_business_names;
                l_receiver_first_names       t_string_table := :p_receiver_first_names;
                l_receiver_last_names        t_string_table := :p_receiver_last_names;
                l_receiver_email_addresses   t_string_table := :p_receiver_email_addresses;
                l_receiver_phone_nos         t_string_table := :p_receiver_phone_nos;
                l_street_names               t_string_table := :p_street_names;
                l_door_numbers               t_string_table := :p_door_numbers;
                l_zip_codes                  t_string_table := :p_zip_codes;
                l_cities                     t_string_table := :p_cities;
                l_provinces                  t_string_table := :p_provinces;
                l_states                     t_string_table := :p_states;
                l_countries                  t_string_table := :p_countries;
                l_delivery_instructions      t_string_table := :p_delivery_instructions;
                l_campaign_identifiers       t_string_table := :p_campaign_identifiers;
                l_product_codes              t_string_table := :p_product_codes;
                l_sh_quantities              t_number_table := :p_sh_quantities;
                l_line_nums                  t_number_table := :p_line_nums;
            begin
                for i in 1..l_dtc_customer_identifiers.count loop
                    p_shipments(i).dtc_customer_identifier  := l_dtc_customer_identifiers(i);
                    p_shipments(i).dtc_order_number         := l_dtc_order_numbers(i);
                    p_shipments(i).business_name            := l_business_names(i);
                    p_shipments(i).receiver_first_name      := l_receiver_first_names(i);
                    p_shipments(i).receiver_last_name       := l_receiver_last_names(i);
                    p_shipments(i).receiver_email_address   := l_receiver_email_addresses(i);
                    p_shipments(i).receiver_phone_no        := l_receiver_phone_nos(i);
                    p_shipments(i).street_name              := l_street_names(i);
                    p_shipments(i).door_number              := l_door_numbers(i);
                    p_shipments(i).zip_code                 := l_zip_codes(i);
                    p_shipments(i).city                     := l_cities(i);
                    p_shipments(i).province                 := l_provinces(i);
                    p_shipments(i).state                    := l_states(i);
                    p_shipments(i).country                  := l_countries(i);
                    p_shipments(i).delivery_instructions    := l_delivery_instructions(i);
                    p_shipments(i).campaign_identifier      := l_campaign_identifiers(i);
                    p_shipments(i).product_code             := l_product_codes(i);
                    p_shipments(i).quantity                 := l_sh_quantities(i);
                    p_shipments(i).line_num                 := l_line_nums(i);
                end loop;

                qpex_dtc_pkg.create_quote(
                    :x_batch_id,
                    :p_created_user_id,
                    :p_organization_id,
                    p_shipments,
                    :x_status_code
                );
            end; ''', output_key='x_status_code',
                         x_batch_id=batch_id,
                         p_created_user_id=req['user_id'],
                         p_organization_id=req['org_id'],
                         p_dtc_customer_identifiers=shipments['dtc_customer_identifier'],
                         p_dtc_order_numbers=shipments['dtc_order_number'],
                         p_business_names=shipments['business_name'],
                         p_receiver_first_names=shipments['receiver_first_name'],
                         p_receiver_last_names=shipments['receiver_last_name'],
                         p_receiver_email_addresses=shipments['receiver_email_address'],
                         p_receiver_phone_nos=shipments['receiver_phone_no'],
                         p_street_names=shipments['street_name'],
                         p_door_numbers=shipments['door_number'],
                         p_zip_codes=shipments['zip_code'],
                         p_cities=shipments['city'],
                         p_provinces=shipments['province'],
                         p_states=shipments['state'],
                         p_countries=shipments['country'],
                         p_delivery_instructions=shipments['delivery_instructions'],
                         p_campaign_identifiers=shipments['campaign_identifier'],
                         p_product_codes=shipments['product_code'],
                         p_sh_quantities=shipments['quantity'],
                         p_line_nums=shipments['line_num'])
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result['status'] = 1
                result['msg'] = 'Failed to generate shipping files %s' % status
                return result
            batch_num = int(batch_id.getvalue())
            status = DTC.generate_shipping_file(batch_num, req['org_id'], req['user_id'])
            if status != 'SUCCESS':
                result['status'] = 1
                if req['org_id'] == 82:
                    result['msg'] = 'DSV files generated. ' \
                        'Failed to generate shipping excel %s' % status
                    result['batch_id'] = batch_num
                else:
                    result['msg'] = 'Failed to generate shipping files %s' % status
            else:
                result['msg'] = 'Shipping files generated successfully'
                result['batch_id'] = batch_num
        return result

    @staticmethod
    def generate_shipping_file(batch_id, org_id, user_id):
        keys_order = OrderedDict([
            ('WebshopOrderId', 'waybill'),
            ('ShippingFirstName', 'receiver_first_name'),
            ('ShippingMiddleName', 'receiver_middle_name'),
            ('ShippingLastName', 'receiver_last_name'),
            ('ShippingStreet', 'street_name'),
            ('ShippingHouseNo', 'door_number'),
            ('ShippingHouseNoAddition', 'door_number_addition'),
            ('Postcode', 'zip_code'),
            ('City', 'city'),
            ('ShippingState', 'state'),
            ('ShippingCountry', 'country'),
            ('ShippingEmail', 'receiver_email_address'),
            ('ShippingPhone', 'receiver_phone_no'),
            ('ShippingComment', 'delivery_instructions'),
            ('B2B', 'b2b'),
            ('ArticleSKU', 'product_code'),
            ('OrderedQty', 'quantity'),
            ('Reference', 'description')
        ])
        try:
            file_name = 'Ordersheet_%s.xlsx' % (
                datetime.now().strftime('%d%m%Y%H%M%S'))
            file_path = os.path.join('/tmp/', file_name)

            keys = list(keys_order.values())
            user, shipments, shipment_count = DTC.get_db_data(batch_id, user_id)
            excel_data = DTC.get_sheet_data(shipments, keys)

            # write data to excel file
            DTC.write_to_excel(file_path, excel_data, keys_order, keys)

            adopt_me = True if shipments[0].get('campaign_identifier') == 'ADOPTME' else False

            # send email to distributor
            DTC.send_email({
                'org_id': org_id,
                'file_path': file_path,
                'file_name': file_name,
                'user': user,
                'shipment_count': shipment_count,
                'adopt_me': adopt_me
            })
        except Exception as error:
            return 'ERROR - %s' % str(error)
        return 'SUCCESS'

    @staticmethod
    def get_db_data(batch_id, user_id):
        user = None
        shipments = []
        sql_file = sql_util.get_sql('dtc')
        shipment_count = 0
        with OracleConnectionManager() as conn:
            query = sql_file['shipments_query']
            conn.execute(query, p_batch_id=batch_id)
            shipments = conn.get_result()

            query = sql_file['user_details_query']
            conn.execute(query, p_user_id=user_id)
            user = conn.get_single_result()

            query = sql_file['shipment_count_query']
            conn.execute(query, p_batch_id=batch_id)
            shipment_count = conn.get_single_result().get('shipment_count')
        return user, shipments, shipment_count

    @staticmethod
    def get_sheet_data(shipments, keys):
        excel_data = []
        for shipment in shipments:
            ordered = OrderedDict()
            for key in keys:
                ordered[key] = shipment.get(key, '')
            excel_data.append(ordered)
        return excel_data

    @staticmethod
    def write_to_excel(file_path, excel_data, keys_order, keys):
        workbook = xlsxwriter.Workbook(file_path, {'constant_memory': True})
        bold = workbook.add_format({'bold': True})
        worksheet = workbook.add_worksheet('Shipments')

        for index, header in enumerate(keys_order.keys()):
            worksheet.write(0, index, header, bold)

        for index, row in enumerate(excel_data):
            for col_index, header in enumerate(keys):
                if isinstance(row.get(header), (int, float)):
                    worksheet.write_number(
                        index + 1, col_index, row.get(header))
                elif row.get(header):
                    worksheet.write(index + 1, col_index, row[header])
        workbook.close()

    @staticmethod
    def send_email(data):
        shipment_file = open(data['file_path'], 'rb')
        sql_file = sql_util.get_sql('dtc')
        subject = '(%s) %s Shipments - %s' % (
            sql_file['shipping_org'].get(data['org_id']),
            'AdoptMe' if data['adopt_me'] else 'DTC',
            datetime.now().strftime('%d/%m/%Y')
        )
        mail_data = {
            'template_id': 2617975,
            'params': [
                {
                    'key': 'shipment_count',
                    'value': data['shipment_count']
                }
            ],
            'to_name': '',
            'to_email': sql_file['shipping_email'].get(data['org_id']),
            'subject': subject,
            'attachments': [{
                'file_type': 'application/vnd.ms-excel',
                'file_name': data['file_name'],
                'file_data': base64.b64encode(shipment_file.read())
            }]
        }
        if data['user']:
            mail_data['cc'] = data['user'].get('email_address')
        CommonUtils.send_mail(mail_data)

    @staticmethod
    def get_dtc_report(salesrep_id, country):
        result = []
        with OracleConnectionManager() as conn:
            sql_file = sql_util.get_sql('dtc')
            if country:
                query = sql_file['dtc_products_shipped_report_query']
                conn.execute(query, p_salesrep_id=salesrep_id,
                             p_country=country)
            else:
                query = sql_file['dtc_products_report_query']
                conn.execute(query, p_salesrep_id=salesrep_id)
            result = conn.get_result()
        return result

    @staticmethod
    def create_order(req):
        result = {'status': 0}
        with OracleConnectionManager() as conn:
            _lines = req.get('lines', [{}])
            lines = {}
            for key in _lines[0].keys():
                lines.update({key: [line[key] for line in _lines]})
            quote_number = conn.cursor.var(cx_Oracle.NUMBER)
            header_id = conn.cursor.var(cx_Oracle.NUMBER)
            conn.execute('''
            declare
                p_quote_lines   qpex_dtc_pkg.quote_lines;

                type t_number_table is table of number index by binary_integer;
                type t_string_table is table of varchar2(300) index by binary_integer;

                l_item_codes    t_string_table := :p_item_codes;
                l_quantities    t_number_table := :p_quantities;
            begin
                for i in 1..l_item_codes.count loop
                    p_quote_lines(i).product_code := l_item_codes(i);
                    p_quote_lines(i).quantity := l_quantities(i);
                end loop;

                qpex_dtc_pkg.create_order(
                    :p_created_user_id,
                    :p_organization_id,
                    :p_adoptme,
                    p_quote_lines,
                    :x_quote_number,
                    :x_quote_header_id,
                    :x_status_code
                );
            end; ''', output_key='x_status_code',
                         p_created_user_id=req['user_id'],
                         p_organization_id=req['org_id'],
                         p_adoptme=req.get('is_adoptme', 'N'),
                         x_quote_number=quote_number,
                         x_quote_header_id=header_id,
                         p_item_codes=lines['item_code'],
                         p_quantities=lines['quantity'])
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result['status'] = 1
                result['msg'] = 'Failed to create quote %s' % status
                return result
            if header_id.getvalue():
                Quotes.send_dtc_approval_mail(int(header_id.getvalue()), 2)
            result['quote_number'] = int(quote_number.getvalue())
            result['msg'] = 'Quote #%s created successfully' % result['quote_number']
        return result
