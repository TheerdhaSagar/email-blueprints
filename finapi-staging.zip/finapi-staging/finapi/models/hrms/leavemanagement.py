import base64
import cx_Oracle
import ujson
import datetime
import math
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.logdata import logger
from finapi.utils.common_utils import CommonUtils
from finapi.utils.constants import Status


class LeaveManagement:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def holiday_insert(self, data):
        logger.addinfo('@ models - leavemanagement - holiday_insert(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            holiday_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            holiday_dates = self.cursor.var(cx_Oracle.STRING)
            holiday_ids = self.cursor.var(cx_Oracle.STRING)
            dates = []
            for i in range(len(data['dates'])):
                dates.append(data['dates'][i])
            self.cursor.execute("""
                declare\
                    l_holiday_dates qpex_leavemanagement_pkg.lm_date_record_type_cover;\

                    type t_dates_table is table of varchar2(100)
                          index by binary_integer;\
                    p_dates t_dates_table := :p_holidays_dates;\
                begin\

                    for i in 1..p_dates.count
                    LOOP
                        l_holiday_dates(i).holiday_date := p_dates(i);\
                    END LOOP;\
                    qpex_leavemanagement_pkg.insert_holidays(
                        :x_holiday_id,
                        :p_user_id,
                        :p_holiday_name,
                        :p_description,
                        :p_org_id,
                        :p_year,
                        l_holiday_dates,
                        :p_delete_existing,
                        :x_status_code,
                        :x_holiday_dates,
                        :x_holiday_ids
                    );
                end; """, x_holiday_id=holiday_id,
                                p_user_id=1,
                                p_holiday_name=data['holiday_name'],
                                p_description=data['description'],
                                p_org_id=data['org_id'],
                                p_year=data['year'],
                                p_holidays_dates=dates,
                                p_delete_existing=data.get('delete_holiday_leave', 'N'),
                                x_status_code=status_code,
                                x_holiday_dates=holiday_dates,
                                x_holiday_ids=holiday_ids)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Holiday added to the List'
                result['holiday_ids'] = holiday_ids.getvalue()
                result['holiday_dates'] = holiday_dates.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add to holiday list - ' + str(status)
                result['holiday_id'] = -1
                result['holiday_ids'] = ''
                result['holiday_dates'] = ''
        except Exception as e:
            logger.findaylog("""@ 70 EXCEPTION models - leavemanagement -
                holiday_insert """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - holiday_insert(-)')
        return result

    def holiday_update(self, data):
        logger.addinfo('@ models - leavemanagement - holiday_update(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_leavemanagement_pkg.update_holidays(
                    :p_holiday_id,
                    :p_user_id,
                    :p_holiday_name,
                    :p_description,
                    :p_holiday_date,
                    :p_holiday_to_date,
                    :p_year,
                    :p_delete_existing,
                    :x_status_code
                );
            end; """, p_holiday_id=data['holiday_id'],
                                p_user_id=data['user_id'],
                                p_holiday_name=data['holiday_name'],
                                p_description=data['description'],
                                p_holiday_date=data['holiday_date'],
                                p_holiday_to_date=data['holiday_to_date'],
                                p_year=data['year'],
                                p_delete_existing=data.get('delete_holiday_leave', 'N'),
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Holiday updated successfully'
                result['holiday_id'] = data['holiday_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update holiday calendar - ' + str(status)
                result['holiday_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 115 EXCEPTION models - leavemanagement -
                holiday_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - holiday_update(-)')
        return result

    def get_holidays(self, jsond):
        logger.addinfo('@ models - leavemanagement - get_holidays(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['holiday_calender_query']
            query += self.sql_file['holiday_calender_with_year']
            self.cursor.execute(query, p_org_id=jsond['org_id'],
                                p_holiday_id=jsond['holiday_id'],
                                p_year=jsond['year'])
            holidays = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = holidays
        except Exception as e:
            logger.findaylog(""" @ 143 EXCEPTION - models - leavemanagement -
                get_holidays """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - get_holidays(-)')
        return result

    def delete_holidays(self, org_id, holiday_id):
        logger.addinfo('@ models - leavemanagement - delete_holidays(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_leavemanagement_pkg.delete_holidays(
                    :p_holiday_id,
                    :p_org_id,
                    :x_status_code
                );
            end; """, p_holiday_id=holiday_id,
                                p_org_id=org_id,
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Holiday(s) deleted successfully'
                result['org_id'] = org_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete holiday calendar - ' + str(status)
                result['holiday_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 170 EXCEPTION models - leavemanagement -
                delete_holidays """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - delete_holidays(-)')
        return result

    def leave_type_insert(self, data):
        logger.addinfo('@ models - leavemanagement - leave_type_insert(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            leave_type_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_leavemanagement_pkg.insert_leave_type(
                    :x_leave_type_id,
                    :p_user_id,
                    :p_leave_type,
                    :p_description,
                    :p_org_id,
                    :p_leave_count,
                    :p_year,
                    :p_allow_hourly,
                    :p_contract_leaves_count,
                    :x_status_code
                );
            end; """, x_leave_type_id=leave_type_id,
                                p_user_id=data['user_id'],
                                p_leave_type=data['leave_type'],
                                p_description=data['description'],
                                p_org_id=data['org_id'],
                                p_leave_count=data['leave_count'],
                                p_year=data['year'],
                                p_allow_hourly=data['allow_hourly'],
                                p_contract_leaves_count=data['contract_leaves_count'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Leave type added to the List'
                result['leave_type_id'] = leave_type_id.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add to leave type - ' + str(status)
                result['leave_type_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 235 EXCEPTION models - leavemanagement -
                leave_type_insert """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - leave_type_insert(-)')
        return result

    def leave_type_update(self, data):
        logger.addinfo('@ models - leavemanagement - leave_type_update(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_leavemanagement_pkg.leave_type_update(
                    :p_leave_type_id,
                    :p_user_id,
                    :p_leave_type,
                    :p_description,
                    :p_leave_count,
                    :p_year,
                    :p_allow_hourly,
                    :p_contract_leaves_count,
                    :x_status_code
                );
            end; """, p_leave_type_id=data['leave_type_id'],
                                p_user_id=data['user_id'],
                                p_leave_type=data['leave_type'],
                                p_description=data['description'],
                                p_leave_count=data['leave_count'],
                                p_year=data['year'],
                                p_allow_hourly=data['allow_hourly'],
                                p_contract_leaves_count=data['contract_leaves_count'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Leave type updated successfully'
                result['leave_type_id'] = data['leave_type_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update Leave type - ' + str(status)
                result['leave_type_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 281 EXCEPTION models - leavemanagement -
                leave_type_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - leave_type_update(-)')
        return result

    def get_leave_types(self, org_id, leave_type_id):
        logger.addinfo('@ models - leavemanagement - get_leave_type(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['leave_type_query']
            self.cursor.execute(query, p_org_id=org_id,
                                p_leave_type_id=leave_type_id)
            leave_types = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = leave_types
        except Exception as e:
            logger.findaylog(""" @ 307 EXCEPTION - models - leavemanagement -
                get_leave_type """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - get_leave_type(-)')
        return result

    def leave_insert(self, data):
        logger.addinfo('@ models - leavemanagement - leave_insert(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            dates = data['dates']
            if not data['manager_user_id']:
                return {'msg': 'Manager name not found', 'status': Status.ERROR.value}
            duplicated_dates = self.get_duplicate_dates(data)
            if len(duplicated_dates) == 0:
                leave_id = self.cursor.var(cx_Oracle.NUMBER)
                status_code = self.cursor.var(cx_Oracle.STRING)
                leave_dates = []
                full_day = []
                leave_from_time = []
                leave_hours = []

                for i in range(len(dates)):
                    hhmm = ''
                    if dates[i]['full_day'] != 'Y':
                        hhmm = str(dates[i]['hours']) + ':' + str(dates[i]['minutes'])
                    leave_dates.append(dates[i]['leave_date'])
                    full_day.append(dates[i]['full_day'])
                    leave_from_time.append(
                        dates[i]['leave_from_time'])
                    leave_hours.append(hhmm)
                self.cursor.execute("""
                    declare\
                        p_leave_details qpex_leavemanagement_pkg.details_record_type_cover;

                        type t_dates_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_full_day_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_leave_from_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_leave_hours_table is table of varchar2(100)
                              index by binary_integer;\

                        leave_dates t_dates_table := :p_leave_dates;\
                        full_day t_full_day_table := :p_full_day;\
                        leave_from t_leave_from_table := :p_leave_from;\
                        leave_hours t_leave_hours_table := :p_leave_hours;\
                    begin
                        for i in 1..leave_dates.count
                        LOOP
                            p_leave_details(i).leave_date := leave_dates(i);\
                            p_leave_details(i).full_day := full_day(i);\
                            p_leave_details(i).leave_from_time := leave_from(i);\
                            p_leave_details(i).leave_hours := leave_hours(i);\
                            p_leave_details(i).leave_detail_id := -1;\
                        END LOOP;\

                        qpex_leavemanagement_pkg.insert_apply_leave(
                        :x_leave_id,
                        :p_user_id,
                        :p_manager_user_id,
                        :p_leave_type_id,
                        :p_reason,
                        :p_from_date,
                        :p_upto_date,
                        p_leave_details,
                        :p_action,
                        :p_comments,
                        :p_org_id,
                        :x_status_code
                        );
                    end; """, x_leave_id=leave_id,
                                    p_user_id=int(data['user_id']),
                                    p_leave_type_id=data['leave_type_id'],
                                    p_manager_user_id=data['manager_user_id'],
                                    p_reason=data['reason'],
                                    p_from_date=data['from_date'],
                                    p_upto_date=data['upto_date'],
                                    p_leave_dates=leave_dates,
                                    p_full_day=full_day,
                                    p_leave_from=leave_from_time,
                                    p_leave_hours=leave_hours,
                                    p_action=data['action'],
                                    p_comments=data['comments'],
                                    p_org_id=data['org_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    with OracleConnectionManager() as conn:
                        # Insert attachments
                        self.add_attachment(data['attachments'],
                                            leave_id.getvalue(), conn)
                        data['leave_id'] = int(leave_id.getvalue())
                    self.resend_approval_email(data)
                    result['status'] = 0
                    result['msg'] = 'Leave applied Successfully'
                    result['holiday_id'] = int(leave_id.getvalue())
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to apply leave - ' + str(status)
                    result['holiday_id'] = -1
            else:
                result = {
                    'status': 1,
                    'duplicated_dates': duplicated_dates
                }
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - leavemanagement -
                leave_insert """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - leave_insert(-)')
        return result

    @staticmethod
    def send_email(jsond):
        logger.addinfo('models - leavemanagement - send_email(+)')
        try:
            recipients = []
            for i in range(len(jsond['recipients'])):
                recipients.append({
                    'Email': jsond['recipients'][i]
                })
            strings = db_util.get_strings()
            no_of_hours, no_of_days = LeaveManagement.get_days_and_hours(jsond['no_of_days'])
            no_of_leave_days = ''
            if no_of_days:
                no_of_leave_days += '{} day(s) '.format(no_of_days)
            if no_of_hours:
                no_of_leave_days += '{} hrs'.format(no_of_hours)
            template_data = {
                'template_id': jsond['template_id'],
                'params': [
                    {'key': 'manager_name', 'value': jsond['manager_name']},
                    {'key': 'user_name', 'value': jsond['user_name']},
                    {'key': 'leave_type', 'value': jsond['leave_type']},
                    {'key': 'no_of_days', 'value': no_of_leave_days},
                    {'key': 'from_date', 'value': jsond['from_date']},
                    {'key': 'to_date', 'value': jsond['upto_date']},
                    {'key': 'total', 'value': jsond['total_leaves']},
                    {'key': 'leaves_used', 'value': jsond['leaves_used']},
                    {'key': 'leaves_available', 'value': jsond['leaves_remaining']},
                    {'key': 'leaves_remaining', 'value': jsond['leaves_remaining']},
                    {'key': 'leave_status', 'value': jsond['leave_status']},
                    {'key': 'deleted_user_name', 'value': jsond['deleted_user_name']},
                    {'key': 'dates', 'value': jsond['dates']},
                    {'key': 'comments', 'value': jsond['comments'] if jsond['comments'] else '-'},
                    {'key': 'created_date', 'value': jsond['created_date']},
                    {'key': 'reason', 'value': jsond['reason']},
                    {'key': 'recipient_name', 'value': jsond['recipient_name']},
                    {'key': 'leave_id', 'value': jsond['leave_id']},
                    {'key': 'org_id', 'value': jsond['org_id']},
                    {'key': 'org_flag', 'value': LeaveManagement.check_included_org(jsond[
                        'org_id'])},
                    {'key': 'applied_by', 'value': jsond['applied_by']},
                    {'key': 'approve_link', 'value': jsond['approve_link']},
                    {'key': 'reject_link', 'value': jsond['reject_link']},
                    {'key': 'applied_year',
                     'value': max([datetime.datetime.strptime(jsond['from_date'], '%d-%b-%Y').year,
                                   datetime.datetime.strptime(jsond['upto_date'],
                                                              '%d-%b-%Y').year])
                     }
                ],
                'subject': jsond['subject'],
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                }, 'attachments': [],
                'recipients': recipients}
            common_obj = CommonUtils()
            mail_status_manager = common_obj.send_mail(template_data)
            result = {}
            if mail_status_manager == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Request sent to user'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to send email'
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - leavemanagement -
                            send_email """ + str(e))
            raise e
        return result

    def get_duplicate_dates(self, data, check='add'):
        """
        if user already applied leave for selected dates
        :param data: list of dates
        :param check: whether the duplicate_dates check is from add leave or update leave
        :return:
        """
        try:
            selected_dates = data['dates']
            with OracleConnectionManager() as conn:
                # Get if user already applied leave for selected dates
                query = self.sql_file['get_duplicate_leaves']
                query = query % (','.join(["'" + selected_dates[i]['leave_date'].upper() + "'"
                                           for i in range(len(selected_dates))]))
                conn.execute(query, p_applied_by=data['applied_by'],
                             p_org_id=data['org_id'])
                duplicates = conn.get_result()
            duplicated_dates = []
            for input_date in selected_dates:
                for dup_date in duplicates:
                    if (input_date['leave_date'].upper() == dup_date['leave_date'].upper()) and (
                            (check == 'update' and data['leave_id'] != dup_date['leave_id']) or
                            check == 'add'):
                        check_flag = LeaveManagement.check_duplicate_date(input_date, dup_date)
                        if check_flag:
                            duplicated_dates.append({
                                'date': input_date['leave_date'],
                                'leave_type': dup_date['leave_type'],
                                'full_day': dup_date['full_day'],
                            })
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - leavemanagement -
                get_duplicate_dates """ + str(error))
            raise error
        return duplicated_dates

    @staticmethod
    def check_duplicate_date(input_date, dup_date):
        """
        check if the input date and duplicate date is not a full day and compare them
        """
        # check if the input date is full day or if it is hourly and duplicate date is full day then
        # it is a duplicate date
        check_flag = (input_date['full_day'] == 'Y' or
                      input_date['full_day'] != 'Y' and dup_date['full_day'] == 'Y')
        # if both input date and duplicate date are hourly,
        if input_date['full_day'] != 'Y' and dup_date['full_day'] != 'Y':
            selected_date = input_date['leave_date'] + \
                ' ' + input_date['leave_from_time']
            # input date start time with date
            leave_date_time = datetime.datetime.strptime(
                selected_date, '%d-%b-%Y %H:%M')
            # duplicate date leave from time with date
            duplicate_date = dup_date['leave_date'].upper(
            ) + ' ' + dup_date['leave_from_time']
            start_time = datetime.datetime.strptime(
                duplicate_date, '%d-%b-%Y %H:%M')
            hours = dup_date['leave_hours'].split(':')
            # end date time for duplicate date
            end_time = start_time + \
                datetime.timedelta(minutes=int(hours[1]), hours=int(hours[0]))
            # If the input date is inbetween the duplicate date hourly hours
            # True -> duplicate date  False -> not a duplicate date
            check_flag = start_time <= leave_date_time < end_time
        return check_flag

    def leave_update(self, data):
        logger.addinfo('@ models - leavemanagement - leave_update(+)')
        result = dict()
        try:
            dates = data['dates']
            if not data['manager_user_id']:
                return {'msg': 'Manager name not found', 'status': 1}
            duplicated_dates = self.get_duplicate_dates(data, 'update')
            if len(duplicated_dates) == 0:
                leave_dates = []
                full_day = []
                leave_from_time = []
                leave_hours = []
                leave_detail_ids = []
                deleted_dates = [deleteId['leave_date'] for deleteId in data['deleteIds']]
                delete_ids = [deleteId.get('leave_detail_id', -1)
                              for deleteId in (data['deleteIds'] or [{'leave_detail_id': -1}])]
                with OracleConnectionManager() as conn:
                    status_code = conn.cursor.var(cx_Oracle.STRING)
                    for i in range(len(dates)):
                        hhmm = ''
                        from_time = ''
                        if dates[i]['full_day'] != 'Y':
                            hhmm = str(dates[i]['hours']) + ':' + str(dates[i]['minutes'])
                            from_time = dates[i]['leave_from_time']
                        leave_from_time.append(from_time)
                        leave_hours.append(hhmm)
                        leave_dates.append(dates[i]['leave_date'])
                        full_day.append(dates[i]['full_day'])
                        leave_detail_ids.append(dates[i]['leave_detail_id'])
                    conn.execute("""
                        declare\
                            p_leave_details qpex_leavemanagement_pkg.details_record_type_cover;
                            p_delete_ids qpex_leavemanagement_pkg.delete_leave_detail_type_cover;


                            type t_dates_table is table of varchar2(100)
                                  index by binary_integer;\

                            type t_full_day_table is table of varchar2(100)
                                  index by binary_integer;\

                            type t_leave_from_table is table of varchar2(100)
                                  index by binary_integer;\

                            type t_leave_hours_table is table of varchar2(100)
                                  index by binary_integer;\

                            type t_leave_detail_ids_table is table of NUMBER
                                index by binary_integer;\

                            leave_dates t_dates_table := :p_leave_dates;\
                            full_day t_full_day_table := :p_full_day;\
                            leave_from t_leave_from_table := :p_leave_from;\
                            leave_hours t_leave_hours_table := :p_leave_hours;\
                            leave_detail_ids t_leave_detail_ids_table := :p_leave_deails_ids;\
                            delete_leave_ids t_leave_detail_ids_table := :p_delete_leave_ids;\
                            l_leave_id number := :p_leave_id;\
                        begin
                            for i in 1..leave_dates.count
                            LOOP
                                p_leave_details(i).leave_date := leave_dates(i);\
                                p_leave_details(i).full_day := full_day(i);\
                                p_leave_details(i).leave_from_time := leave_from(i);\
                                p_leave_details(i).leave_hours := leave_hours(i);\
                                p_leave_details(i).leave_detail_id := leave_detail_ids(i);\
                            END LOOP;\

                            for i in 1..delete_leave_ids.count
                            LOOP
                                p_delete_ids(i).leave_detail_id := delete_leave_ids(i);\
                                p_delete_ids(i).leave_id := l_leave_id;\
                            END LOOP;

                            qpex_leavemanagement_pkg.leave_update(
                            :p_leave_id,
                            :p_user_id,
                            :p_manager_user_id,
                            :p_leave_type_id,
                            :p_reason,
                            :p_from_date,
                            :p_upto_date,
                            :p_status,
                            p_leave_details,
                            p_delete_ids,
                            :p_action,
                            :p_comments,
                            :x_status_code
                            );
                        end; """, p_leave_id=int(data['leave_id']),
                                 p_user_id=int(data['user_id']),
                                 p_leave_type_id=data['leave_type_id'],
                                 p_manager_user_id=data['manager_user_id'],
                                 p_reason=data['reason'],
                                 p_from_date=data['from_date'],
                                 p_upto_date=data['upto_date'],
                                 p_status=data['status'],
                                 p_leave_dates=leave_dates,
                                 p_full_day=full_day,
                                 p_leave_from=leave_from_time,
                                 p_leave_hours=leave_hours,
                                 p_leave_deails_ids=leave_detail_ids,
                                 p_delete_leave_ids=delete_ids,
                                 p_action=data['action'],
                                 p_comments=data['comments'],
                                 x_status_code=status_code)

                    status = status_code.getvalue()
                    if status == 'SUCCESS':
                        # Add attachments
                        self.add_attachment(data['attachments'],
                                            data['leave_id'], conn)

                        # To delete attachments
                        self.delete_attachments(data['deleted_attachments'], conn)

                        # Send email to user and manager if dates are deleted after approval
                        if data['send_email']:
                            LeaveManagement.send_update_email(data, deleted_dates)
                        result['status'] = 0
                        result['msg'] = 'Leave updated successfully'
                        result['leave_id'] = data['leave_id']
                    else:
                        result['status'] = 1
                        result['msg'] = 'Failed to update Leave - ' + str(status)
                        result['leave_id'] = -1
            else:
                result = {
                    'status': 1,
                    'duplicated_dates': duplicated_dates
                }
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - leavemanagement -
                leave_update """ + str(e))
            raise e
        logger.addinfo('@ models - leavemanagement - leave_update(-)')
        return result

    @staticmethod
    def send_update_email(data, deleted_dates):
        logger.addinfo('@models - leavemanagement - send_update_email')
        try:
            recipients_email = []
            common_obj = CommonUtils()
            # get the user name who has deleted the leaves
            user_data = common_obj.get_user_details_based_on_id(data['user_id'])
            deleted_user_name = user_data['user_description']

            # manager edited the leaves , send mail to recieve notification users
            if data['manager_user_id'] == data['user_id']:
                users = common_obj.get_users_with_role(
                    'UI-LEAVEMANAGEMENT-RECIEVE-NOTIFICATIONS')
                for i in range(len(users)):
                    if users[i]['user_id'] != data['user_id']:
                        recipients_email.append(users[i]['email_address'])
            # Get manager mail id
            user_data = common_obj.get_user_details_based_on_id(data['manager_user_id'])
            if data['manager_user_id'] != data['user_id']:
                recipients_email.append(user_data['email_address'])
            manager_name = user_data['user_description']

            # Get user mail id
            user_data = common_obj.get_user_details_based_on_id(data['applied_by'])
            applied_user_email = user_data['email_address']
            applied_user_name = user_data['user_description']

            if data['status'] == 'A':
                leave_status = 'Approved'
            elif data['status'] == 'R':
                leave_status = 'Rejected'
            else:
                leave_status = 'Pending'
            # Send email to user
            subject = 'Leave modified by {0}'.format(deleted_user_name)
            if data['from_date'] != data['upto_date']:
                subject += ' from {} to {}'.format(data['from_date'], data['upto_date'])
            else:
                subject += ' for {}'.format(data['from_date'])

            jsond = {'manager_name': manager_name,
                     'template_id': 579089,
                     'user_name': 'your',
                     'leave_type': data['leave_type'],
                     'no_of_days': data['no_of_days'],
                     'from_date': data['from_date'],
                     'upto_date': data['upto_date'],
                     'total_leaves': data['total_leaves'],
                     'leaves_used': data['leaves_used'],
                     'leaves_remaining': data['leaves_remaining'],
                     'leave_status': leave_status,
                     'deleted_user_name': deleted_user_name,
                     'dates': ','.join(
                         [deleted_dates[i] for i in range(len(deleted_dates))]),
                     'comments': data['comments'],
                     'subject': subject,
                     'created_date': data['created_date'],
                     'reason': data['reason'],
                     'applied_by': data['applied_by'],
                     'org_id': data['org_id'],
                     'leave_id': data['leave_id'],
                     'approve_link': '',
                     'reject_link': '',
                     'recipients': [applied_user_email],
                     'recipient_name': applied_user_name}

            LeaveManagement.send_email(jsond)

            # Send email to manager
            jsond['user_name'] = applied_user_name
            jsond['recipients'] = recipients_email
            jsond['recipient_name'] = manager_name

            LeaveManagement.send_email(jsond)
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION models - leavemanagement -
                send_update_email""" + str(error))
            raise error
        return "SUCCESS"

    def get_leaves(self, jsond):
        logger.addinfo('@ models - leavemanagement - get_leaves(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['leaves_detail_overview_query']
            self.cursor.execute(query, p_user_id=jsond['user_id'],
                                p_status=jsond['status'],
                                p_manager_user_id=jsond['manager_user_id'],
                                p_leave_type_id=jsond['leave_type_id'],
                                p_org_id=jsond['org_id'])
            leaves = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = leaves
        except Exception as e:
            logger.findaylog(""" @ 430 EXCEPTION - models - leavemanagement -
                get_leaves """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - get_leaves(-)')
        return result

    def delete_leave_type(self, leave_type_id):
        logger.addinfo('@ models - leavemanagement - delete_leave_type(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_leavemanagement_pkg.delete_leave_type(:p_leave_type_id,
                :x_status_code
                );
            end; """, p_leave_type_id=leave_type_id,
                                x_status_code=status_code)
        except Exception as e:
            logger.findaylog(""" @ 441 EXCEPTION - models - leavemanagement -
                             delete_leave_type """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - leavemanagement - delete_leave_type(-)')
        return status_code.getvalue()

    def get_leaves_summary(self, jsond):
        logger.addinfo('models - leavemanagement - get_leaves_summary(+)')
        try:
            self.acquire()
            query = self.sql_file['leaves_summary_query']
            self.cursor.execute(query, p_user_id=jsond['user_id'],
                                p_manager_user_id=jsond['manager_user_id'],
                                p_status=jsond['status'],
                                p_from_date=jsond['from_date'],
                                p_to_date=jsond['to_date'],
                                p_org_id=jsond['org_id'],
                                p_year=int(jsond['year']))
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 521 EXCEPTION - models - leavemanagement -
                             get_leaves_summary """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - leavemanagement - get_leaves_summary(-)')
        return result

    def get_leave_details(self, leave_id):
        logger.addinfo('models - leavemanagement - get_leave_details(+)')
        try:
            self.acquire()
            query = self.sql_file['leave_detail_query']
            self.cursor.execute(query, p_leave_id=leave_id)
            result = Code_util.iterate_data(self.cursor)
            history = self.get_leaves_history(leave_id)
            data = {
                'result': result,
                'history': history
            }
        except Exception as e:
            logger.findaylog(""" @ 537 EXCEPTION - models - leavemanagement -
                             get_leave_details """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - leavemanagement - get_leave_details(-)')
        return data

    def update_leave_status(self, jsond):
        logger.addinfo('models - leavemanagement - update_leave_status(+)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                    begin
                        qpex_leavemanagement_pkg.update_leave_status(
                            :p_leave_id,
                            :p_status,
                            :p_user_id,
                            :p_action,
                            :p_comments,
                            :x_status_code
                        );
                    end;""", p_leave_id=jsond['leave_id'],
                             p_status=jsond['status'],
                             p_user_id=jsond['user_id'],
                             p_action=jsond['action'],
                             p_comments=jsond['comments'],
                             x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS' and jsond['send_email']:
                common_obj = CommonUtils()
                # Send email to users having role recieve notifications
                users = common_obj.get_users_with_role('UI-LEAVEMANAGEMENT-RECIEVE-NOTIFICATIONS')
                recipients = [user['email_address'] for user in users
                              if user['user_id'] != jsond['user_id']]
                if jsond['status'] == 'A':
                    leave_status = 'approved'
                elif jsond['status'] == 'R':
                    leave_status = 'rejected'
                else:
                    leave_status = 'cancelled'
                    manager_email = common_obj.get_user_details_based_on_id(jsond['manager_id'])
                    if jsond['manager_id'] != jsond['user_id']:
                        recipients.append(manager_email['email_address'])
                edited_user_email = common_obj.get_user_details_based_on_id(jsond['user_id'])
                subject = 'Leave {0} by {1}'.format(
                    leave_status, edited_user_email['user_description'])
                if jsond['from_date'] != jsond['upto_date']:
                    subject += " from {0} to {1} ".format(jsond['from_date'], jsond['upto_date'])
                else:
                    subject += " for " + jsond['from_date']
                data = {
                    'manager_name': edited_user_email['user_description'],
                    'user_name': jsond['user_name'],
                    'no_of_days': jsond['no_of_days'],
                    'from_date': jsond['from_date'],
                    'upto_date': jsond['upto_date'],
                    'leave_status': leave_status,
                    'comments': jsond['comments'] if jsond['comments'] else '-',
                    'leaves_used': jsond['leaves_used'],
                    'leaves_remaining': jsond['leaves_remaining'],
                    'total_leaves': jsond['total_leaves'],
                    'reason': jsond['reason'],
                    'template_id': 781633,
                    'subject': subject,
                    'dates': '',
                    'leave_type': jsond['leave_type'],
                    'created_date': jsond['created_date'],
                    'deleted_user_name': '',
                    'recipients': recipients,
                    'recipient_name': '',
                    'leave_id': jsond['leave_id'],
                    'org_id': jsond['org_id'],
                    'applied_by': jsond['applied_by'],
                    'approve_link': '',
                    'reject_link': ''
                }
                LeaveManagement.send_email(data)

                # Get leave applied_by user get_mail_id
                email = common_obj.get_user_details_based_on_id(
                    jsond['applied_by'])['email_address']
                # Send email to leave applied_by user to notify status
                data = {
                    'manager_name': jsond['manager_name'],
                    'user_name': jsond['user_name'],
                    'no_of_days': jsond['no_of_days'],
                    'from_date': jsond['from_date'],
                    'upto_date': jsond['upto_date'],
                    'leave_status': leave_status,
                    'comments': jsond['comments'] if jsond['comments'] else '-',
                    'leaves_used': jsond['leaves_used'],
                    'leaves_remaining': jsond['leaves_remaining'],
                    'total_leaves': jsond['total_leaves'],
                    'reason': jsond['reason'],
                    'template_id': 781638,
                    'subject': subject,
                    'dates': '',
                    'leave_type': jsond['leave_type'],
                    'created_date': jsond['created_date'],
                    'deleted_user_name': '',
                    'recipients': [email],
                    'recipient_name': '',
                    'leave_id': jsond['leave_id'],
                    'org_id': jsond['org_id'],
                    'applied_by': jsond['applied_by'],
                    'approve_link': '',
                    'reject_link': ''
                }
                LeaveManagement.send_email(data)

        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - leavemanagement -
                            update_leave_status """ + str(e))
            raise e
        logger.addinfo('models - leavemanagement - update_leave_status(-)')
        return status_code.getvalue()

    def get_leaves_history(self, leave_id):
        logger.addinfo('@ models - leavemanagement - get_leaves_history(+)')
        try:
            query = self.sql_file['leaves_history']
            self.cursor.execute(query, p_leave_id=leave_id)
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 684 EXCEPTION - models - leavemanagement -
                             get_leaves_history """ + str(e))
            raise e
        logger.addinfo('models - leavemanagement - get_leaves_history(-)')
        return result

    def get_leave_type_withcount(self, jsond):
        logger.addinfo('models - leavemanagement - get_leave_type_withcount(+)')
        try:
            self.acquire()
            year = ','.join(str(year) for year in jsond['year'])
            query = self.sql_file['get_leave_type_withcount']
            query = query.format(year)
            self.cursor.execute(query, p_user_id=jsond['user_id'],
                                p_org_id=jsond['org_id'])
            result = Code_util.iterate_data(self.cursor)

            # Get users with leave management role and not yet aplied for any leaves
            query = self.sql_file['users_with_leave_management_role']
            query = query.format(year)
            self.cursor.execute(query, p_org_id=jsond['org_id'])
            users = Code_util.iterate_data(self.cursor)

            # Get initial balance for all users
            query = self.sql_file['users_initial_leave_balance']
            query = query.format(year)
            self.cursor.execute(query, p_org_id=jsond['org_id'],
                                p_user_id=jsond['user_id'])
            initial_balance = Code_util.iterate_data(self.cursor)
            response = {
                'result': result,
                'users': users,
                'initial_balance': initial_balance
            }
        except Exception as e:
            logger.findaylog(""" @ 691 EXCEPTION - models - leavemanagement -
                            get_leave_type_withcount """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - leavemanagement - get_leave_type_withcount(-)')
        return response

    # def get_role_users(self, org_id):
    #     logger.addinfo('@ models - leavemanagement - get_role_users(+)')
    #     try:
    #         self.acquire()
    #         role_name = 'UI-LEAVE-APPROVER-' + str(org_id)
    #         query = self.sql_file['get_role_users']
    #         self.cursor.execute(query, p_role_name=role_name)
    #         users = Code_util.iterate_data(self.cursor)
    #     except Exception as e:
    #         logger.findaylog("""@ 996 EXCEPTION - models - leavemanagement -
    #                         get_role_users """ + str(e.message))
    #         raise e
    #     finally:
    #         self.release()
    #     logger.addinfo('@ models - leavemanagement - get_role_users(-)')
    #     return users

    def get_approver_name(self, user_id):
        logger.addinfo('@ models - leavemanagement - get_approver_name(+)')
        try:
            self.acquire()
            query = self.sql_file['get_approver_name']
            self.cursor.execute(query, p_user_id=user_id)
            approvers = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 1014 EXCEPTION - models - leavemanagement -
                            get_approver_name """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - leavemanagement - get_approver_name(-)')
        return approvers

    def add_attachment(self, attachments, leave_id, conn):
        logger.addinfo('@ models - leavemanagement - add_attachment(+)')
        try:
            # with OracleConnectionManager as conn:
            for i in range(len(attachments)):
                if 'file_id' in attachments[i]:
                    continue
                conn.cursor.setinputsizes(p_blob=cx_Oracle.BLOB)
                return_value = conn.cursor.var(cx_Oracle.STRING)
                # Insert attachments
                conn.execute(""" declare
                    begin
                    :retval := qpex_attachments.add_attachment(:pref,
                    :ptitle, :pfilename,:pdesc, :p_blob, :pcontent_type,
                    :pentity, :pcategory);end;""", pref=leave_id,
                             ptitle=attachments[i]['title'],
                             pfilename=attachments[i]['filename'],
                             pdesc=attachments[i]['description'],
                             p_blob=attachments[i]['base64'],
                             pcontent_type=attachments[i]['filetype'],
                             pentity=attachments[i]['entity_name'],
                             pcategory=attachments[i]['category_name'],
                             retval=return_value)
            conn.connection.commit()
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - leavemanagement -
                            add_attachment """ + str(e))
            raise e
        logger.addinfo('@ models - leavemanagement - add_attachment(-)')
        return 'success'

    def delete_attachments(self, attachments, conn):
        logger.addinfo('@ models - leavemanagement - delete_attachments(+)')
        try:
            # with OracleConnectionManager as conn:
            status_code = conn.cursor.var(cx_Oracle.STRING)
            for a in attachments:
                conn.execute(""" declare
                        begin
                            :retval := qpex_attachments.delete_attachment(
                            :p_file_id);
                            end;""", p_file_id=a['file_id'],
                             retval=status_code)
            conn.connection.commit()
        except Exception as e:
            logger.findaylog(""" @ 1081 EXCEPTION - models - leavemanagement -
                            delete_attachments """ + str(e))
            raise e
        logger.addinfo('@ models - leavemanagement - delete_attachments(-)')
        return 'success'

    def update_initial_balance(self, jsond):
        logger.addinfo('@ models - leavemanagement - update_initial_balance(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute(""" declare
                begin
                    qpex_leavemanagement_pkg.update_initial_balance(
                    :p_user_id,
                    :p_created_by,
                    :p_initial_balance,
                    :p_org_id,
                    :p_year,
                    :x_status_code);
                    end;""", p_user_id=jsond['user_id'],
                                p_created_by=jsond['created_by'],
                                p_initial_balance=jsond['initial_balance'],
                                p_org_id=jsond['org_id'],
                                p_year=jsond['year'],
                                x_status_code=status_code)
            self.connection.commit()
        except Exception as e:
            logger.findaylog(""" @ 1121 EXCEPTION - models - leavemanagement -
                            update_initial_balance """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - leavemanagement - update_initial_balance(-)')
        return status_code.getvalue()

    def users_with_person_id(self, org_id):
        logger.addinfo('@ models - leavemanagement - update_initial_balance(+)')
        try:
            result = {}
            self.acquire()
            query = self.sql_file['get_persons']
            self.cursor.execute(query, p_org_id=org_id)
            users = Code_util.iterate_data(self.cursor)
            new_users = [i for i in users if i['role_id'] is None]
            result['new_users'] = new_users
            result['existing_users'] = [i for i in users if i['role_id'] is not None]
        except Exception as e:
            logger.findaylog(""" @ 1121 EXCEPTION - models - leavemanagement -
                            update_initial_balance """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - leavemanagement - update_initial_balance(-)')
        return result

    def add_leavemgmt_role_to_user(self, jsond):
        logger.addinfo(''' @ models - leavemanagement - add_leavemgmt_role_to_user''')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute(""" declare
                begin
                    qpex_leavemanagement_pkg.add_role_to_user(
                    :p_user_id,
                    :p_manager_id,
                    :p_approver_role,
                    :p_created_by,
                    :p_updated_by,
                    :x_status_code
                    );
                    end;""", p_user_id=jsond['user_id'],
                                p_manager_id=jsond['manager_id'],
                                p_approver_role=jsond['approval_rights'],
                                p_created_by=jsond['created_by'],
                                p_updated_by=jsond['updated_by'],
                                x_status_code=status_code)
            self.connection.commit()
        except Exception as e:
            logger.findaylog(""" @ 1205 EXCEPTION - models - leavemanagement -
                            add_leavemgmt_role_to_user """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - leavemanagement - add_leavemgmt_role_to_user(-)')
        return status_code.getvalue()

    def update_leavemgmt_role_to_user(self, jsond):
        logger.addinfo(''' @ models - leavemanagement - update_leavemgmt_role_to_user''')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute(""" declare
                begin
                    qpex_leavemanagement_pkg.update_role_to_user(
                    :p_user_id,
                    :p_manager_id,
                    :p_inactive_status,
                    :p_updated_by,
                    :x_status_code
                    );
                    end;""", p_user_id=jsond['user_id'],
                                p_manager_id=jsond['manager_id'],
                                p_inactive_status=jsond['inactive_status'],
                                p_updated_by=jsond['updated_by'],
                                x_status_code=status_code)
            self.connection.commit()
        except Exception as e:
            logger.findaylog(""" @ 1236 EXCEPTION - models - leavemanagement -
                            update_leavemgmt_role_to_user """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - leavemanagement - update_leavemgmt_role_to_user(-)')
        return status_code.getvalue()

    def send_approval_mail(self, jsond):
        """
        get the leave approval details and send email to manager for approving the leave
        :param jsond: {'leave_id':'', 'org_id':'','user_id':''}
        :return: json object with email status
        """
        leave_details = self.get_leave_details(jsond['leave_id'])['result'][0]
        leave_details['no_of_days'] = LeaveManagement.calculate_leave_count(
            leave_details['details'])
        leave_details['dates'] = leave_details['details']
        jsond['year'] = [max(jsond['year'])]
        leaves_count_details = self.get_leave_type_withcount(jsond)

        initial_balance = (leaves_count_details['initial_balance'][0]['initial_balance']
                           if leaves_count_details['initial_balance']
                           else 0)
        user_leave_details = leaves_count_details['result']
        contract_emp = False
        for user in user_leave_details:
            if user['leave_type_id'] == leave_details['leave_type_id']:
                leave_details['leave_type'] = user['leave_type']
                contract_emp = user['details'][0].get('contract_employee') or False

                user_details = [details for details in user['details']
                                if ((details['status'] == 'P' and datetime.datetime.strptime(
                                    details['from_date'], '%d-%b-%Y').date() <
                                    datetime.datetime.now().date()
                                ) or details['status'] == 'A')]
                leaves_count = LeaveManagement.calculate_leave_count(user_details)
                leave_details['leaves_used'] = round(leaves_count, 2)
                total_leave_count = (
                    user['contract_leaves_count'] if contract_emp and user['contract_leaves_count']
                    else user['leave_count'])
                if total_leave_count:
                    leave_details['leaves_remaining'] = round(
                        float(total_leave_count) - leaves_count, 2) + initial_balance
                    leave_details['total_leaves'] = float(
                        total_leave_count) + initial_balance
                else:
                    leave_details['leaves_remaining'] = '-'
                    leave_details['total_leaves'] = '-'
        leave_details['user_id'] = leave_details['applied_by']
        self.resend_approval_email(leave_details)
        result = {'status': Status.OK.value, 'msg': 'Mail has been sent successfully'}
        return result

    @staticmethod
    def calculate_leave_count(leave_details):
        leave_count = 0
        for leave in leave_details:
            if leave['full_day'] != 'Y':
                hours = leave['leave_hours'].split(':')
                leave_count += (float(hours[0]) + (float(hours[1]) / 60)) / 8
            else:
                leave_count += 1
        return leave_count

    @staticmethod
    def check_included_org(org_id):
        """
            Hide leave report till date in email templates for the orgs given below
        """
        return org_id in [82, 243, 141, 202]

    def resend_approval_email(self, data):
        """
        Approval Email to manager
        :param data: json object
        :return:
        """
        try:
            common_obj = CommonUtils()
            # for getting manager mail address and name
            user_data = common_obj.get_user_details_based_on_id(data['manager_user_id'])
            manager_email = user_data['email_address']
            manager_name = user_data['user_description']

            # Get user mail_address and name
            user_data = common_obj.get_user_details_based_on_id(data['user_id'])
            applied_user_name = user_data['user_description']

            subject = 'Leave ' + 'requested by ' + applied_user_name
            if data['from_date'] != data['upto_date']:
                subject += " from " + data['from_date']
                subject += " to " + data['upto_date']
            else:
                subject += " for " + data['from_date']

            jsond = {'manager_name': manager_name,
                     'manager_user_id': data['manager_user_id'],
                     'template_id': 779920,
                     'user_name': applied_user_name,
                     'leave_type': data['leave_type'],
                     'no_of_days': data['no_of_days'],
                     'from_date': data['from_date'],
                     'upto_date': data['upto_date'],
                     'total_leaves': data['total_leaves'],
                     'leaves_used': round(data['leaves_used'], 2),
                     'leaves_remaining': data['leaves_remaining'],
                     'leave_status': '',
                     'deleted_user_name': '',
                     'dates': data['dates'],
                     'comments': '',
                     'subject': subject,
                     'created_date': data['created_date'],
                     'reason': data['reason'],
                     'recipients': [manager_email],
                     'recipient_name': '',
                     'applied_by': data['applied_by'],
                     'org_id': data['org_id'],
                     'leave_id': data['leave_id'],
                     'approve': 'A'}
            # Create approve and reject links to send in mail
            approve_link = base64.b64encode(ujson.dumps(jsond).encode()).decode('utf-8')
            jsond['approve'] = 'R'
            reject_link = base64.b64encode(ujson.dumps(jsond).encode()).decode('utf-8')
            jsond['approve_link'] = approve_link
            jsond['reject_link'] = reject_link
            LeaveManagement.send_email(jsond)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - leavemanagement -
                            resend_approval_email """ + str(e))
            raise e
        return "SUCCESS"

    def get_leave_report(self, jsond):
        """
        To get leave details based on org and month
        :param jsond: {"org_id":"", "from_date":"", "to_date":""}
        :return: json array
        """
        logger.addinfo('@ models - leavemanagement - get_leave_report(+)')
        try:
            result = {}
            with OracleConnectionManager() as conn:
                # getting user details with leaves based on org and month
                query = self.sql_file['get_leave_report_based_on_org']
                if jsond.get('manager_id'):
                    users_list = self.sql_file['get_users_based_on_managers']
                    conn.execute(users_list, p_approver_id=jsond['manager_id'],
                                 p_org_id=jsond['org_id'],
                                 p_from_date=str(jsond['from_date']),
                                 p_to_date=str(jsond['to_date']))
                    users = ','.join([str(user['user_id'])
                                      for user in conn.get_result()] + [str(jsond['manager_id'])])
                else:
                    users_list = self.sql_file['get_leavemanagement_users_for_period']
                    conn.execute(users_list, p_org_id=jsond['org_id'],
                                 p_from_date=str(jsond['from_date']),
                                 p_to_date=str(jsond['to_date']))
                    users = ','.join([str(user['user_id']) for user in conn.get_result()])
                query += " AND user_id in ({0})".format(users)
                conn.execute(query, p_org_id=jsond['org_id'],
                             p_from_date=str(jsond['from_date']),
                             p_to_date=str(jsond['to_date']))
                result['users'] = conn.get_result()
                # get holiday list based on from_date and to_date
                query = self.sql_file['holiday_calender_query']
                query += self.sql_file['holiday_calendar_based_on_filter']
                conn.execute(query, p_org_id=jsond['org_id'],
                             p_from_date=str(jsond['from_date']),
                             p_to_date=str(jsond['to_date']))
                result['holidays'] = conn.get_result()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - leavemanagement -
                    get_leave_report """ + str(error))
            raise error
        logger.addinfo('@ models - leavemanagement - get_leave_report(-)')
        return result

    @staticmethod
    def multi_update_initial_balance(request_data):
        """
         Service for inserting or updating the initial balance once carryover button is
         clicked in front end to automate the initial balance to be updated to next year
        :param request_data: {"users":[{"user_id": "", "initial_balance": ""}],"year":"",
        "created_by": "", "org_id": ""}
        :return: {"status":"", "msg":""}
        """
        logger.addinfo('@ models - leavemanagement - multi_update_initial_balance(-)')
        try:
            user_id = []
            initial_balance = []
            for user in request_data['users']:
                user_id.append(user['user_id'])
                initial_balance.append(user['initial_balance'])
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                DECLARE\
                    initial_balance_obj QPEX_LEAVEMANAGEMENT_PKG.initial_balance_record_cover;\
                    type number_table_t is table of number
                        index by binary_integer;\

                    d_user_id number_table_t := :p_user_id;\
                    d_initial_balance  number_table_t := :p_initial_balance;\

                BEGIN\
                    for i in 1..d_user_id.count
                    LOOP
                        initial_balance_obj(i).user_id := d_user_id(i);
                        initial_balance_obj(i).initial_balance := d_initial_balance(i);
                        initial_balance_obj(i).created_by := :p_created_by;
                        initial_balance_obj(i).org_id := :p_org_id;
                        initial_balance_obj(i).year := :p_year;
                    END LOOP;

                    QPEX_LEAVEMANAGEMENT_PKG.multi_initial_balance(
                    initial_balance_obj,
                    :x_status_code
                    );

                END;
                """, p_user_id=user_id,
                             p_initial_balance=initial_balance,
                             p_created_by=request_data['created_by'],
                             p_org_id=request_data['org_id'],
                             p_year=request_data['year'],
                             x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Updated the users initial balance successfully'
                          }
            else:
                result = {'status': Status.OK.value,
                          'msg': 'Failed to update the users initial balances - {}'.format(
                              status_code.getvalue()
                          )
                          }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION -  models - leavemanagement -
                multi_update_initial_balance - """ + str(error))
            raise error
        logger.addinfo('@ models - leavemanagement - multi_update_initial_balance(+)')
        return result

    @staticmethod
    def get_days_and_hours(value):
        hrs, days = math.modf(value)
        hrs = hrs * 8
        return hrs, days
