import cx_Oracle
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.constants import Status


class AssetManagement:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    # for inserting a new attachment
    def add_attachment(self, attachments, reference_id,
                       created_id):
        logger.addinfo('@ models - assetmanagement - add_attachment(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
            file_id = self.cursor.var(cx_Oracle.NUMBER)
            status_codes = []
            result = {}
            for attachment in attachments:
                self.cursor.execute("""
                                    begin
                                        qpex_asset_management_pkg.add_attachment(
                                    :x_file_id,
                                    :p_reference_id,
                                    :p_reference_type,
                                    :p_file_name,
                                    :p_file_type,
                                    :p_file_content,
                                    :p_created_id,
                                    :x_status_code
                                        );
                                    end; """, x_file_id=file_id,
                                    p_reference_id=reference_id,
                                    p_reference_type=attachment['attachment_type'],
                                    p_file_name=attachment['file_name'],
                                    p_file_type=attachment['file_type'],
                                    p_file_content=attachment['file_content'],
                                    p_created_id=created_id,
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append({'file_name': attachment['file_name'],
                                         'error': status})
            if len(status_codes) > 0:
                result['status'] = Status.ERROR.value
            else:
                result['status'] = Status.OK.value
            result['failed_attachments'] = status_codes
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              add_attachment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - add_attachment(+)')
        return result

    # for updating a existing attachment
    def update_attachments(self, attachments):
        logger.addinfo('@ models - assetmanagement - update_attachment(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
            result = {}
            self.cursor.execute("""
                                begin
                                qpex_asset_management_pkg.update_attachment(
                                :p_file_id,
                                :p_reference_id,
                                :p_reference_type,
                                :p_file_name,
                                :p_file_type,
                                :p_file_content,
                                :p_created_id,
                                :x_status_code
                                    );
                                end; """,
                                p_file_id=attachments['file_id'],
                                p_reference_id=attachments['reference_id'],
                                p_reference_type=attachments[
                                    'attachment_type'],
                                p_file_name=attachments['file_name'],
                                p_file_type=attachments['file_type'],
                                p_file_content=attachments[
                                    'file_content'],
                                p_created_id=attachments['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status != 'SUCCESS':
                result['status'] = Status.ERROR.value
                result['msg'] = "Failed to update attachment"
            else:
                result['status'] = Status.OK.value
                result['msg'] = "Updated attachment successfully"

        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              update_attachment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - update_attachment(+)')
        return result

    # Deleting existing attachments
    def delete_attachments(self, attachment_ids):
        logger.addinfo('@ models - assetmanagement - delete_attachments(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_codes = []
            result = {}
            status_code = self.cursor.var(cx_Oracle.STRING)
            for attch_id in attachment_ids:
                self.cursor.execute("""
                                    begin
                                        qpex_asset_management_pkg.delete_attachment(
                                    :p_file_id,
                                    :x_status_code
                                        );
                                    end; """, p_file_id=attch_id,
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append({'file_id': attch_id,
                                        'error': status})
            if len(status_codes) > 0:
                result['status'] = Status.ERROR.value
            else:
                result['status'] = Status.OK.value
            result['failed_attachments'] = status_codes
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              delete_attachments """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - delete_attachments(+)')
        return result

    # inserting a new asset
    def add_asset(self, data):
        logger.addinfo('@ models - assetmanagement - add_asset(+)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            asset_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_asset_management_pkg.insert_asset_details(
                :x_asset_id,
                :p_asset_type_id,
                :p_location_id,
                :p_serial_number,
                :p_status,
                :p_warranty_expiry_date,
                :p_renewal_date,
                :p_license_number,
                :p_brand,
                :p_condition,
                :p_po_number,
                :p_purchased_price,
                :p_currency_code,
                :p_purchased_date,
                :p_org_id,
                :p_created_id,
                :p_asset_life_time,
                :p_description,
                :p_model,
                :p_inventory_number,
                :x_status_code
                );
            end; """, x_asset_id=asset_id,
                                p_asset_type_id=data['asset_type_id'],
                                p_location_id=data['location_id'],
                                p_serial_number=data['serial_number'],
                                p_status=data['status'],
                                p_warranty_expiry_date=data['warranty_expiry_date'],
                                p_renewal_date=data['renewal_date'],
                                p_license_number=data['license_number'],
                                p_brand=data['brand'],
                                p_condition=data['asset_condition'],
                                p_po_number=data['po_number'],
                                p_purchased_price=data['purchased_price'],
                                p_currency_code=data['currency_code'],
                                p_purchased_date=data['purchased_date'],
                                p_org_id=data['org_id'],
                                p_created_id=data['created_id'],
                                p_asset_life_time=data['asset_life_time'],
                                p_description=data['description'],
                                p_model=data['model'],
                                p_inventory_number=data['inventory_number'],
                                x_status_code=status_code)

            status = status_code.getvalue()

            if status == 'SUCCESS':
                status_attachments = {'status': 0}
                map_result = {'status': 0}
                if len(data['asset_attachments']) > 0:
                    status_attachments = self.add_attachment(data['asset_attachments'],
                                                             reference_id=asset_id,
                                                             created_id=data['created_id'])
                # linking users to asset
                if data['user_ids']:
                    # call the asset and users mapping/link function
                    map_result = self.asset_users_link({
                        'users': data['user_ids'],
                        'asset_id': int(asset_id.getvalue()),
                        'created_id': data['created_id']
                    })
                # checking both attachments and map_assets success or not
                if status_attachments['status'] == 0 and map_result['status'] == 0:
                    result['status'] = Status.OK.value
                    result['msg'] = 'Asset added successfully'
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = ''
                    if status_attachments['status'] != 0:
                        result['msg'] = 'Failed to add Asset attachments '
                    if map_result['status'] != 0:
                        result['msg'] += 'Failed to link user(s) to asset'
                    result['failed_attachments'] = status_attachments[
                        'failed_attachments']
                result['asset_id'] = int(asset_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to add an Asset'
                result['asset_id'] = -1
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              add_asset """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - add_asset(+)')
        return result

    # for updating asset details
    def asset_update(self, data):
        logger.addinfo('@ models - assetmanagement - asset_update(-) ')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    qpex_asset_management_pkg.update_asset_details(
                                    :p_asset_id,
                                    :p_asset_type_id,
                                    :p_location_id,
                                    :p_serial_number,
                                    :p_status,
                                    :p_warranty_expiry_date,
                                    :p_renewal_date,
                                    :p_license_number,
                                    :p_brand,
                                    :p_condition,
                                    :p_po_number,
                                    :p_purchased_price,
                                    :p_currency_code,
                                    :p_purchased_date,
                                    :p_org_id,
                                    :p_recent_updated_user_id,
                                    :p_asset_life_time,
                                    :p_description,
                                    :p_model,
                                    :p_inventory_number,
                                    :x_status_code
                                    );
                                end; """, p_asset_id=data['asset_id'],
                                p_asset_type_id=data['asset_type_id'],
                                p_location_id=data['location_id'],
                                p_serial_number=data['serial_number'],
                                p_status=data['status'],
                                p_warranty_expiry_date=data['warranty_expiry_date'],
                                p_renewal_date=data['renewal_date'],
                                p_license_number=data['license_number'],
                                p_brand=data['brand'],
                                p_condition=data['asset_condition'],
                                p_po_number=data['po_number'],
                                p_purchased_price=data['purchased_price'],
                                p_currency_code=data['currency_code'],
                                p_purchased_date=data['purchased_date'],
                                p_org_id=data['org_id'],
                                p_recent_updated_user_id=data['created_id'],
                                p_asset_life_time=data['asset_life_time'],
                                p_description=data['description'],
                                p_model=data['model'],
                                p_inventory_number=data['inventory_number'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            result = {}
            if status == 'SUCCESS':
                status_attachments = {'status': 0}
                delete_attach_status = {'status': 0}
                map_result = {'status': 0}
                unmap_result = {'status': 0}
                if len(data['asset_attachments']) > 0:
                    status_attachments = self.add_attachment(data['asset_attachments'],
                                                             reference_id=data['asset_id'],
                                                             created_id=data['created_id'])
                if len(data['delete_attachments']) > 0:
                    delete_attach_status = self.delete_attachments(
                        data['delete_attachments'])
                if data['unlink_user_ids']:
                    # call the asset and users mapping/link function
                    unmap_result = self.asset_users_unlink({
                        'user_ids': data['unlink_user_ids'],
                        'asset_id': data['asset_id'],
                    })
                # linking users to asset
                if data['user_ids']:
                    # call the asset and users mapping/link function
                    map_result = self.asset_users_link({
                        'users': data['user_ids'],
                        'asset_id': data['asset_id'],
                        'created_id': data['created_id']
                    })
                if status_attachments['status'] == 0 and \
                        delete_attach_status['status'] == 0 and map_result['status'] == 0 \
                        and unmap_result['status'] == 0:
                            result['status'] = Status.OK.value
                            result['msg'] = 'Asset updated successfully'
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = ''
                    if status_attachments['status'] != 0 or delete_attach_status['status'] != 0:
                        result['msg'] = 'Failed to update asset attachments'
                    if map_result['status'] != 0 or unmap_result['status'] != 0:
                        result['msg'] += 'Failed to link/unlink users'
                    if 'failed_attachments' in status_attachments:
                        result['failed_attachments'] = status_attachments[
                            'failed_attachments']
                    if 'failed_attachments' in delete_attach_status:
                        result['failed_del_attachments'] = delete_attach_status[
                            'failed_attachments']
                result['asset_id'] = data['asset_id']
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update asset - ' + str(status)
                result['asset_id'] = data['asset_id']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              asset_update""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - asset_update(+)')
        return result

    def delete_asset(self, asset_id):
        logger.addinfo('@ models - assetmanagement - delete_asset(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            result = {}
            self.cursor.execute("""
            begin
                qpex_asset_management_pkg.delete_asset_details(:p_asset_id,
                :x_status_code
                );
            end; """, p_asset_id=asset_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Asset deleted successfully'
                result['asset_id'] = asset_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete asset'
                result['asset_id'] = asset_id
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - assetmanagement -
                             delete_asset """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - assetmanagement - delete_asset(-)')
        return result

    # inserting service log for an asset
    def add_service_history(self, data):
        logger.addinfo('@ models - assetmanagement - add_service_history(+)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            service_history_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_asset_management_pkg.insert_service_history(
                :x_asset_service_history_id,
                :p_asset_id,
                :p_service_issue,
                :p_service_cost,
                :p_service_warranty_expiry,
                :p_currency_code,
                :p_org_id,
                :p_created_id,
                :x_status_code
                );
            end; """, x_asset_service_history_id=service_history_id,
                                p_asset_id=data['asset_id'],
                                p_service_issue=data['service_issue'],
                                p_service_cost=data['service_cost'],
                                p_service_warranty_expiry=data['service_warranty_date'],
                                p_currency_code=data['currency_code'],
                                p_org_id=data['org_id'],
                                p_created_id=data['created_id'],
                                x_status_code=status_code)

            status = status_code.getvalue()

            if status == 'SUCCESS':
                status_attachments = {'status': 0}
                # Add attachment
                if len(data['attachments']) > 0:
                    status_attachments = self.add_attachment(data['attachments'],
                                                             reference_id=data['asset_id'],
                                                             created_id=data['created_id'])
                # checking attachments
                if status_attachments['status'] == 0:
                    result['status'] = Status.OK.value
                    result['msg'] = 'Service History logged successfully'
                    result['service_history_id'] = int(service_history_id.getvalue())
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to add attachments'
                    result['failed_attachments'] = status_attachments[
                        'failed_attachments']
                    result['service_history_id'] = int(service_history_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to log service history'
                result['service_history_id'] = -1
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              add_service_history """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - add_service_history(+)')
        return result

    # for updating service history
    def update_service_history(self, data):
        logger.addinfo('@ models - assetmanagement - update_service_history(-) ')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    qpex_asset_management_pkg.update_service_history(
                                    :p_asset_history_id,
                                    :p_service_issue,
                                    :p_service_cost,
                                    :p_service_warranty_expiry,
                                    :p_currency_code,
                                    :p_org_id,
                                    :p_recent_updated_user_id,
                                    :x_status_code
                                    );
            end; """, p_asset_history_id=data['service_history_id'],
                                p_service_issue=data['service_issue'],
                                p_service_cost=data['service_cost'],
                                p_service_warranty_expiry=data['service_warranty_date'],
                                p_currency_code=data['currency_code'],
                                p_org_id=data['org_id'],
                                p_recent_updated_user_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            result = {}
            if status == 'SUCCESS':
                status_attachments = {'status': 0}
                delete_attach_status = 'SUCCESS'
                if len(data['attachments']) > 0:
                    status_attachments = self.add_attachment(data['attachments'],
                                                             reference_id=data['asset_id'],
                                                             created_id=data['created_id'])
                if len(data['delete_attachments']) > 0:
                    delete_attach_status = self.delete_attachments(
                        data['delete_attachments'])
                if status_attachments['status'] == 0 and \
                        delete_attach_status == 'SUCCESS':
                        result['status'] = Status.OK.value
                        result['msg'] = 'Service History updated successfully'
                        result['service_history_id'] = data['service_history_id']
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to update attachments'
                    result['failed_attachments'] = status_attachments[
                        'failed_attachments']
                    result['service_history_id'] = data['service_history_id']

            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update service history - ' + str(status)
                result['service_history_id'] = data['service_history_id']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              update_service_history""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - update_service_history(+)')
        return result

    def delete_service_history(self, service_history_id):
        logger.addinfo('@ models - assetmanagement - delete_service_history(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            result = {}
            self.cursor.execute("""
            begin
                qpex_asset_management_pkg.delete_service_history(:p_asset_service_history_id,
                :x_status_code
                );
            end; """, p_asset_service_history_id=service_history_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Service history deleted Successfully'
                result['asset_id'] = service_history_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to service history'
                result['asset_id'] = service_history_id
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - assetmanagement -
                             delete_service_history """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - assetmanagement - delete_service_history(-)')
        return result

    # inserting history for an asset
    def add_asset_history(self, data):
        logger.addinfo('@ models - assetmanagement - add_asset_history(+)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            asset_history_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_asset_management_pkg.insert_asset_history(
                :x_asset_history_id,
                :p_asset_id,
                :p_description,
                :p_notes,
                :p_created_id,
                :x_status_code
                );
            end; """, x_asset_history_id=asset_history_id,
                                p_asset_id=data['asset_id'],
                                p_description=data['description'],
                                p_notes=data['notes'],
                                p_created_id=data['created_id'],
                                x_status_code=status_code)

            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Asset History logged successfully'
                result['asset_history_id'] = int(asset_history_id.getvalue())

            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to log asset history'
                result['asset_history_id'] = -1
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              add_asset_history """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - add_asset_history(+)')
        return result

    # for updating asset history
    def update_asset_history(self, data):
        logger.addinfo('@ models - assetmanagement - update_asset_history(-) ')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    qpex_asset_management_pkg.update_asset_history(
                                    :p_asset_history_id,
                                    :p_description,
                                    :p_notes,
                                    :p_created_id,
                                    :x_status_code
                );
            end; """, p_asset_history_id=data['asset_history_id'],
                                p_description=data['description'],
                                p_notes=data['notes'],
                                p_created_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            result = {}
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Asset History updated successfully'
                result['asset_history_id'] = data['asset_history_id']
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update asset history - ' + str(status)
                result['asset_history_id'] = data['asset_history_id']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - assetmanagement -
              update_asset_history""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - update_asset_history(+)')
        return result

    def delete_asset_history(self, asset_history_id):
        logger.addinfo('@ models - assetmanagement - delete_asset_history(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            result = {}
            self.cursor.execute("""
            begin
                qpex_asset_management_pkg.delete_asset_history(:p_asset_history_id,
                :x_status_code
                );
            end; """, p_asset_history_id=asset_history_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Asset history deleted Successfully'
                result['asset_id'] = asset_history_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete asset history'
                result['asset_id'] = asset_history_id
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - assetmanagement -
                             delete_asset_history """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - assetmanagement - delete_asset_history(-)')
        return result

    # for mapping users and assets
    def asset_users_link(self, jsond):
        logger.addinfo('@ models - assetmanagement - asset_users_link(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            status_codes = []
            for user_id in jsond['users']:
                self.cursor.execute("""
                                    begin
                                        qpex_asset_management_pkg.link_assets_users(
                                            :p_asset_id,
                                            :p_user_id,
                                            :p_created_id,
                                            :x_status_code);
                                    end;""",
                                    p_asset_id=jsond['asset_id'],
                                    p_user_id=user_id,
                                    p_created_id=jsond['created_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append(
                        {'user_id': user_id,
                         'asset_id': jsond['asset_id'],
                         'status': status})
            result = {}
            if status_codes:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to link Asset and Users'
                result['failed_links'] = status_codes
            else:
                result['status'] = Status.OK.value
                result['msg'] = 'Link between Asset and Users is Successful'
                result['failed_links'] = status_codes
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - assetmanagement -
              asset_users_link""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - asset_users_link(+)')
        return result

    # for deleting the link between users and assets
    def asset_users_unlink(self, jsond):
        logger.addinfo('@ models - assetmanagement - asset_users_unlink(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            status_codes = []
            for user_id in jsond['user_ids']:
                self.cursor.execute("""
                                    begin
                                        qpex_asset_management_pkg.unlink_assets_users(
                                            :p_asset_id,
                                            :p_user_id,
                                            :x_status_code);
                                    end;""",
                                    p_asset_id=jsond['asset_id'],
                                    p_user_id=user_id,
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append(
                        {'user_id': user_id,
                         'asset_id': jsond['asset_id'],
                         'status': status})
            result = {}
            if status_codes:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete link between users and asset'
                result['failed_links'] = status_codes
            else:
                result['status'] = Status.OK.value
                result['msg'] = 'Deleted the link successfully'
                result['failed_links'] = []
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - assetmanagement -
              asset_users_unlink""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - assetmanagement - asset_users_unlink(+)')
        return result

    def get_attachment_data(self, file_id):
        logger.addinfo("@ models - assetmanagement - get_attachment_data(+)")
        try:
            self.acquire()
            query = self.sql_file['get_attachment_content']
            self.cursor.execute(query,
                                p_file_id=file_id)
            file_details = self.cursor.fetchone()[0]
            if file_details:
                file_details = file_details.read()
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models -
            assetmanagement - get_attachment_data""" + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo("@ models - assetmanagement - get_attachment_data(-)")
        return file_details

    # get locations and asset type for an organization
    def get_assets_lov(self, org_id):
        logger.addinfo('@ models - assetmanagement - get_assets_lov(-)')
        result = {}
        try:
            self.acquire()
            # to check the manager details of the user
            query = self.sql_file['get_locations']
            self.cursor.execute(query, p_org_id=org_id)
            locations = Code_util.iterate_data(self.cursor)
            query = self.sql_file['get_asset_types']
            self.cursor.execute(query)
            asset_types = Code_util.iterate_data(self.cursor)
            result['locations'] = locations
            result['asset_types'] = asset_types
            result['status'] = Status.OK.value
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - assetmanagement -
              get_assets_lov """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - assetmanagement - get_assets_lov(+)')
        return result

    def get_asset_summary(self, org_id):
        logger.addinfo('@ models - assetmanagement - get_asset_summary(-)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['get_asset_summary']
            self.cursor.execute(query, p_org_id=org_id)
            result['status'] = Status.OK.value
            result['summary'] = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - assetmanagement -
              get_asset_summary""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - assetmanagement - get_asset_summary(+)')
        return result

    def get_asset_details(self, asset_id):
        logger.addinfo('@ models - assetmanagement - get_asset_details(-)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['get_asset_details']
            self.cursor.execute(query, p_asset_id=asset_id)
            result['status'] = Status.OK.value
            result['asset_details'] = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - assetmanagement -
              get_asset_details""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - assetmanagement - get_asset_details(+)')
        return result
