import cx_Oracle
import os
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.constants import Status
from finapi.utils.common_utils import CommonUtils


class EmployeeOnboard:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False
        self.support_email = self.strings['support_email']

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def add_onboard_emp(self, data):
        """inserting a on-boarding employee, links assets to user"""
        logger.addinfo('@ models - employeeonboard - add_onboard_emp(+)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            onboarding_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_employee_onboard_pkg.insert_employee_details(
                :x_onboarding_id,
                :p_employee_name,
                :p_employment_type,
                :p_job_title,
                :p_manager_id,
                :p_telephone_nbr,
                :p_email_address,
                :p_default_org_id,
                :p_access_to_cruscott,
                :p_cruscott_similar_user,
                :p_onboard_description,
                :p_access_to_oracle,
                :p_oracle_similar_user,
                :p_access_to_almo_email,
                :p_joining_date,
                :p_created_id,
                :x_status_code
                );
            end; """, x_onboarding_id=onboarding_id,
                                p_employee_name=data['employee_name'],
                                p_employment_type=data['employment_type'],
                                p_job_title=data['job_title'],
                                p_manager_id=data['manager_id'],
                                p_telephone_nbr=data['telephone_nbr'],
                                p_email_address=data['email_address'],
                                p_default_org_id=data['default_org_id'],
                                p_access_to_cruscott=data['access_to_cruscott'],
                                p_cruscott_similar_user=data['cruscott_similar_user'],
                                p_onboard_description=data['onboard_description'],
                                p_access_to_oracle=data['access_to_oracle'],
                                p_oracle_similar_user=data['oracle_similar_user'],
                                p_access_to_almo_email=data['almo_email_access'],
                                p_joining_date=data['joining_date'],
                                p_created_id=data['created_id'],
                                x_status_code=status_code)

            status = status_code.getvalue()

            if status == 'SUCCESS':
                query = self.sql_file['get_mail_id']
                self.cursor.execute(query, p_user_id=data['created_id'])
                user_data = Code_util.iterate_data(self.cursor)
                created_email = user_data[0]['email_address']
                created_user_name = user_data[0]['user_description']
                employment_type = 'Part' if data['employment_type'] == 'part-time' else 'Full'
                employment_type += ' Time'
                req_data = {
                    'template_id': 1011445,
                    'to_email': self.support_email,
                    'to_name': 'Almonature Support Team',
                    'subject': 'New Request for On-boarding User has been Created - #' +
                               str(int(onboarding_id.getvalue())),
                    'params': [
                        {
                            'key': 'template_body',
                            'value': 'Please review on-Boarding request raised by - '
                                     + created_user_name + '. After creating email in Almonature domain please '
                                                           'communicate using employee personal email, Crussott login '
                                                           'details will be send to Almonature email only.'
                        },
                        {
                            'key': 'access_to_cruscott',
                            'value': 'Yes' if data['access_to_cruscott'] == 'Y' else 'No'
                        },
                        {
                            'key': 'access_to_oracle',
                            'value': 'Yes' if data['access_to_oracle'] == 'Y' else 'No'
                        },
                        {
                            'key': 'joining_date',
                            'value': data['joining_date']
                        },
                        {
                            'key': 'email_address',
                            'value': data['email_address']
                        },
                        {
                            'key': 'employee_name',
                            'value': data['employee_name']
                        },
                        {
                            'key': 'employment_type',
                            'value': employment_type
                        },
                        {
                            'key': 'additional_notes',
                            'value': data['onboard_description'] or '-'
                        },
                        {
                            'key': 'asset_count',
                            'value': len(data.get('asset_ids', []))
                        },
                        {
                            'key': 'almo_email',
                            'value': 'Yes' if data['almo_email_access'] == 'Y' else 'No'
                        }]
                }
                mail_status = CommonUtils.send_mail(req_data)
                map_result = {'status': 0}
                if data['asset_ids']:
                    map_result = self.asset_users_link({
                        'asset_ids': data['asset_ids'],
                        'onboarding_id': int(onboarding_id.getvalue()),
                        'created_id': data['created_id']
                    })
                if map_result['status'] == 0:
                    if mail_status == 'SUCCESS':
                        result['status'] = Status.OK.value
                        result['msg'] = 'Your on-board request has Submitted Successfully'
                    else:
                        result['status'] = Status.ERROR.value
                        result['msg'] = 'Failed to send email to IT support team'
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to link assets(s) to user'
                    result['failed_assets'] = map_result['failed_links']
                result['onboard_id'] = int(onboarding_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to created on-board request'
                result['onboard_id'] = -1
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - employeeonboard -
              add_onboard_emp """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - employeeonboard - add_onboard_emp(+)')
        return result

    def onboard_update(self, data):
        """
            Updates existing on board request, unlinks/links assets from user
        """
        """
        :param data:
        :return:
        """
        logger.addinfo('@ models - employeeonboard - onboard_update(-) ')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    qpex_employee_onboard_pkg.update_employee_details(
                                    :p_onboarding_id,
                                    :p_employee_name,
                                    :p_employment_type,
                                    :p_job_title,
                                    :p_manager_id,
                                    :p_telephone_nbr,
                                    :p_email_address,
                                    :p_default_org_id,
                                    :p_access_to_cruscott,
                                    :p_cruscott_similar_user,
                                    :p_onboard_description,
                                    :p_access_to_oracle,
                                    :p_oracle_similar_user,
                                    :p_access_to_almo_email,
                                    :p_status,
                                    :p_joining_date,
                                    :p_recent_updated_user_id,
                                    :x_status_code
                                    );
                                end; """, p_onboarding_id=data['onboarding_id'],
                                p_employee_name=data['employee_name'],
                                p_employment_type=data['employment_type'],
                                p_job_title=data['job_title'],
                                p_manager_id=data['manager_id'],
                                p_telephone_nbr=data['telephone_nbr'],
                                p_email_address=data['email_address'],
                                p_default_org_id=data['default_org_id'],
                                p_access_to_cruscott=data['access_to_cruscott'],
                                p_cruscott_similar_user=data['cruscott_similar_user'],
                                p_onboard_description=data['onboard_description'],
                                p_access_to_oracle=data['access_to_oracle'],
                                p_oracle_similar_user=data['oracle_similar_user'],
                                p_access_to_almo_email=data['almo_email_access'],
                                p_status=data['status'],
                                p_joining_date=data['joining_date'],
                                p_recent_updated_user_id=data['recent_updated_user_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            result = {}
            if status == 'SUCCESS':
                map_result = {'status': 0}
                unmap_result = {'status': 0}
                if data['unlink_asset_ids']:
                    unmap_result = self.asset_users_unlink({
                        'asset_ids': data['unlink_asset_ids'],
                        'onboarding_id': data['onboarding_id'],
                    })
                if data['asset_ids']:
                    map_result = self.asset_users_link({
                        'asset_ids': data['asset_ids'],
                        'onboarding_id': data['onboarding_id'],
                        'created_id': data['created_id']
                    })
                if map_result['status'] == 0 \
                        and unmap_result['status'] == 0:
                    result['status'] = Status.OK.value
                    result['msg'] = 'on-board request updated successfully'
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to update on-board Request, '
                    if map_result['status'] != 0 or unmap_result['status'] != 0:
                        result['msg'] += 'Failed to link/unlink users'
                        result['link_assets'] = map_result['failed_links']
                        result['unlink_assets'] = unmap_result['unmap_result']
                result['onboard_id'] = data['onboarding_id']
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update asset - ' + str(status)
                result['onboard_id'] = data['onboarding_id']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - employeeonboard -
              onboard_update""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - employeeonboard - onboard_update(+)')
        return result

    def asset_users_link(self, jsond):
        """
        for mapping assets and users (this will only insert in on-board request but not in actual
        asset management tables).
        """
        logger.addinfo('@ models - employeeonboard - asset_users_link(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            status_codes = []
            for asset_id in jsond['asset_ids']:
                self.cursor.execute("""
                                    begin
                                        qpex_employee_onboard_pkg.link_asset_user(
                                            :p_onboarding_id,
                                            :p_asset_id,
                                            :p_created_id,
                                            :x_status_code);
                                    end;""",
                                    p_onboarding_id=jsond['onboarding_id'],
                                    p_asset_id=asset_id,
                                    p_created_id=jsond['created_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append(
                        {'asset_id': asset_id,
                         'onbord_id': jsond['onboarding_id'],
                         'status': status})
            result = {}
            if status_codes:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to link Asset and Users'
                result['failed_links'] = status_codes
            else:
                result['status'] = Status.OK.value
                result['msg'] = 'Link between Asset and Users is Successful'
                result['failed_links'] = status_codes
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - employeeonboard -
              asset_users_link""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - employeeonboard - asset_users_link(+)')
        return result

    def asset_users_unlink(self, jsond):
        """
        for deleting the link between user and assets
        """
        logger.addinfo('@ models - employeeonboard - asset_users_unlink(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            status_codes = []
            for asset_id in jsond['asset_ids']:
                self.cursor.execute("""
                                    begin
                                        qpex_employee_onboard_pkg.unlink_asset_user(
                                            :p_onboarding_id,
                                            :p_asset_id,
                                            :x_status_code);
                                    end;""",
                                    p_onboarding_id=jsond['onboarding_id'],
                                    p_asset_id=asset_id,
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append(
                        {'asset_id': asset_id,
                         'onboard_id': jsond['onboarding_id'],
                         'status': status})
            result = {}
            if status_codes:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete link between users and asset'
                result['failed_links'] = status_codes
            else:
                result['status'] = Status.OK.value
                result['msg'] = 'Deleted the link successfully'
                result['failed_links'] = status_codes
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - employeeonboard -
              asset_users_unlink""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - employeeonboard - asset_users_unlink(+)')
        return result

    def get_onboard_summary(self, onboard_status, org_id):
        logger.addinfo('@ models - employeeonboard - get_onboard_summary(-)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['get_onboard_summary']
            self.cursor.execute(query, p_org_id=org_id,
                                       p_status=onboard_status)
            result['status'] = Status.OK.value
            result['summary'] = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - employeeonboard -
              get_onboard_summary""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - employeeonboard - get_onboard_summary(+)')
        return result

    def get_onboard_details(self, onboard_id):
        logger.addinfo('@ models - employeeonboard - get_onboard_details(-)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['get_onboard_details']
            self.cursor.execute(query, p_onboard_id=onboard_id)
            result['status'] = Status.OK.value
            result['onboard_details'] = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - employeeonboard -
              get_onboard_details""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - employeeonboard - get_onboard_details(+)')
        return result

    def get_available_assets(self):
        logger.addinfo('@ models - employeeonboard - get_available_assets(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['get_available_assets']
            self.cursor.execute(query)
            result['status'] = Status.OK.value
            result['asset_details'] = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - employeeonboard -
              get_available_assets""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - employeeonboard - get_available_assets(1)')
        return result
