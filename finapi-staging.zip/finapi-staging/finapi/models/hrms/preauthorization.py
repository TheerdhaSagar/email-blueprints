import base64
import cx_Oracle
import ujson

from finapi.utils.code_util import Code_util
from finapi.utils.common_utils import CommonUtils
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.logdata import logger


class PreAuthorization:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def get_requests(self, jsond):
        logger.addinfo('@ models - preauthorization - get_requests(+)')
        result = {}
        try:
            self.acquire()
            header_id = jsond['header_id'] if 'header_id' in jsond else None
            query = self.sql_file['preauthorization_summary_query']
            self.cursor.execute(query, p_org_id=jsond['org_id'], p_authorization_id=header_id,
                                p_user_id=jsond['user_id'])
            departments = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = departments
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - preauthorization -
                get_requests """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - preauthorization - get_requests(-)')
        return result

    def add_attachment(self, attachments, request_id):
        logger.addinfo('@ models - preauthorization - add_attachment(+)')
        status = None
        try:
            for i in range(len(attachments)):
                if 'file_id' in attachments[i]:
                    continue
                self.cursor.setinputsizes(p_blob=cx_Oracle.BLOB)
                return_value = self.cursor.var(cx_Oracle.STRING)
                # Insert attachments
                self.cursor.execute(""" declare
                begin
                :retval := qpex_attachments.add_attachment(:pref,
                :ptitle, :pfilename,:pdesc, :p_blob, :pcontent_type,
                :pentity, :pcategory);end;""", pref=request_id,
                                    ptitle=attachments[i]['title'],
                                    pfilename=attachments[i]['filename'],
                                    pdesc=attachments[i]['description'],
                                    p_blob=attachments[i]['base64'],
                                    pcontent_type=attachments[i]['filetype'],
                                    pentity=attachments[i]['entity_name'],
                                    pcategory=attachments[i]['category_name'],
                                    retval=return_value)
                if return_value == 'E':
                    status = 'error'
                elif return_value:
                    status = 'success'
            self.connection.commit()
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - preauthorization -
                            add_attachment """ + str(e))
            raise e
        logger.addinfo('@ models - preauthorization - add_attachment(-)')
        return status

    def delete_attachments(self, attachments):
        logger.addinfo('@ models - preauthorization - delete_attachments(+)')
        status = None
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            for a in attachments:
                self.cursor.execute(""" declare
                    begin
                        :retval := qpex_attachments.delete_attachment(
                        :p_file_id);
                        end;""", p_file_id=a['file_id'],
                                    retval=status_code)
            if status_code == 'S':
                status = 'success'
            elif status_code == 'E':
                status = 'error'
            self.connection.commit()
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - preauthorization -
                            delete_attachments """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - preauthorization - delete_attachments(-)')
        return status

    def request_insert(self, data):
        logger.addinfo('@ models - preauthorization - request_insert(+)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            request_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_preauthorization_pkg.insert_request(
                                    :x_request_id,
                                    :p_user_id,
                                    :p_request_for,
                                    :p_request_type,
                                    :p_need_by,
                                    :p_has_offer,
                                    :p_estimated_cost,
                                    :p_currency_code,
                                    :p_description,
                                    :p_org_id,
                                    :p_request_status,
                                    :p_approver_user_id,
                                    :p_approver_comments,
                                    :p_employee_id,       
                                    :x_status_code
                );
            end; """, x_request_id=request_id,
                                p_user_id=int(data['user_id']),
                                p_request_for=data['request_for'],
                                p_request_type=data['request_type'],
                                p_need_by=data['need_by'],
                                p_has_offer=data['has_offer'],
                                p_estimated_cost=int(data['estimated_cost']),
                                p_currency_code=data['currency_code'],
                                p_description=data['description'],
                                p_org_id=int(data['org_id']),
                                p_request_status=data['request_status'],
                                p_approver_user_id=int(data['approver_user_id']),
                                p_approver_comments=data['approver_comments'],
                                p_employee_id=data['employee_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                attachments = []
                # Insert attachments
                if len(data['attachments']) > 0:
                    self.add_attachment(data['attachments'],
                                        request_id.getvalue())

                    for d in data['attachments']:
                        attachment = {}
                        attachment['file_name'] = d['filename']
                        attachment['file_type'] = d['filetype']
                        attachment['file_data'] = d['base64']
                        attachments.append(attachment)
                query = self.sql_file['get_mail_id']
                self.cursor.execute(query, p_user_id=data['approver_user_id'])
                user_data = Code_util.iterate_data(self.cursor)
                manager_email = user_data[0]['email_address']
                manager_name = user_data[0]['user_description']

                # Get user mail_address and name
                self.cursor.execute(query, p_user_id=data['user_id'])
                user_data = Code_util.iterate_data(self.cursor)
                created_user_name = user_data[0]['user_description']

                # Get applied user mail_address and name
                self.cursor.execute(query, p_user_id=data['employee_id'])
                user_data = Code_util.iterate_data(self.cursor)
                applied_user_name = user_data[0]['user_description']

                jsond = {
                    'request_for': data['request_for'],
                    'request_type': data['request_type'],
                    'request_status': data['request_status'],
                    'need_by': data['need_by'],
                    'has_offer': data['has_offer'],
                    'estimated_cost': data['estimated_cost'],
                    'currency_code': data['currency_code'],
                    'description': data['description'],
                    'subject': data['subject'],
                    'created_date': data['created_date'],
                    'org_id': data['org_id'],
                    'applied_by': int(data['user_id']),
                    'request_id': int(request_id.getvalue()),
                    'manager_name': data['manager_name'],
                    'applied_user_name': applied_user_name,
                    'attachment_count': len(data['attachments']),
                    'employee_id': data['employee_id'],
                    'created_user_name': created_user_name
                }
                query = self.sql_file['get_role_users']
                self.cursor.execute(query,
                                    p_role_name='UI-PREAUTHORIZATION-RECIEVE-NOTIFICATIONS')
                users = Code_util.iterate_data(self.cursor)
                recipients = []
                recieve_notification_names = []
                for i in range(len(users)):
                    if users[i]['employee_number'] != data['user_id']:
                        recipients.append({
                            'Email': users[i]['email_address'],
                            'Name': ''
                        })
                        recieve_notification_names.append(users[i]['full_name'])
                mail_data_common = {
                    # 'template_id': 867098, -- old template id
                    'template_id': 925106,
                    'subject': 'New authorization request(#'+ str(jsond['request_id']) + \
                                ') has been raised for : ' + applied_user_name,
                    'params': [
                        {
                            'key': 'template_subject',
                            'value': 'Please review authorization request for the below item(s),raised for '
                                     + applied_user_name
                        },
                        {
                            'key': 'request_for',
                            'value': data['request_for']
                        },
                        {
                            'key': 'request_type',
                            'value': data['request_type']
                        },
                        {
                            'key': 'need_by',
                            'value': data['need_by']
                        },
                        {
                            'key': 'estimated_cost',
                            'value': data['estimated_cost']
                        },
                        {
                            'key': 'currency_code',
                            'value': data['currency_code']
                        },
                        {
                            'key': 'description',
                            'value': data['description']
                        },
                        {
                            'key': 'attachment_count',
                            'value': jsond['attachment_count']
                        },
                        {
                            'key': 'notification_users',
                            'value': ', '.join(recieve_notification_names)
                        },
                        {
                            'key': 'created_user_name',
                            'value': jsond['created_user_name']
                        },
                        {
                            'key': 'applied_user_name',
                            'value': jsond['applied_user_name']
                        }
                    ],
                }
                mail_data = mail_data_common
                mail_data['params'].append({
                    'key': 'user_name',
                    'value': ''
                })
                mail_data['params'].append({
                    'key': 'approve_link',
                    'value': ''
                })
                mail_data['params'].append({
                    'key': 'reject_link',
                    'value': ''
                })

                mail_data['recipients'] = recipients
                if len(attachments) > 0:
                    mail_data['attachments'] = attachments
                if len(recipients) > 0:
                    mail_status_rec = CommonUtils.send_mail(mail_data)
                else:
                    mail_status_rec = 'SUCCESS'
                # Create approve and reject links to send in mail
                jsond['status'] = 'A'
                approve_link = base64.b64encode(str(ujson.dumps(jsond)))
                jsond['status'] = 'R'
                reject_link = base64.b64encode(str(ujson.dumps(jsond)))
                mail_data = mail_data_common
                mail_data['subject'] = data['subject']
                mail_data['params'].append({
                    'key': 'user_name',
                    'value': manager_name
                })
                mail_data['params'].append({
                    'key': 'approve_link',
                    'value': approve_link
                })
                mail_data['params'].append({
                    'key': 'reject_link',
                    'value': reject_link
                })
                mail_data.pop('recipients')
                mail_data['to_email'] = manager_email
                mail_data['to_name'] = manager_name

                if len(attachments) > 0:
                    mail_data['attachments'] = attachments
                mail_status_manager = CommonUtils.send_mail(mail_data)

                if mail_status_manager == 'SUCCESS' and \
                        mail_status_rec == 'SUCCESS':
                    result['status'] = 0
                    result['msg'] = 'Request created Successfully'
                    result['request_id'] = request_id.getvalue()
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to send emails to recipients'
                    result['request_id'] = request_id.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to create Request - ' + str(status)
                result['request_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 235 EXCEPTION models - preauthorization -
                request_insert """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - preauthorization - request_insert(-)')
        return result

    def update_request_status(self, jsond):
        logger.addinfo('models - preauthorization - update_request_status(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            query = self.sql_file['get_request_id_count']
            self.cursor.execute(query, p_authorization_id=jsond['request_id'])
            count = self.cursor.fetchone()[0]
            final_result = ''
            if count == 0:
                final_result = "Request has been deleted"
            else:
                self.cursor.execute("""
                    begin
                        QPEX_PREAUTHORIZATION_PKG.update_request_status(
                            :p_request_id,
                            :p_status,
                            :p_user_id,
                            :x_status_code
                        );
                    end;""", p_request_id=jsond['request_id'],
                                    p_status=jsond['status'],
                                    p_user_id=jsond['user_id'],
                                    x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':

                    # Send email to users having role recieve notifications
                    query = self.sql_file['get_role_users']
                    self.cursor.execute(query,
                                        p_role_name='UI-PREAUTHORIZATION-RECIEVE-NOTIFICATIONS')
                    users = Code_util.iterate_data(self.cursor)
                    recipients = []
                    recieve_notification_names = []
                    for i in range(len(users)):
                        if users[i]['employee_number'] != jsond['user_id']:
                            recipients.append({
                                'Email': users[i]['email_address'],
                                'Name': ''
                            })
                            recieve_notification_names.append(users[i]['full_name'])
                    # Get requester user get_mail_id
                    query = self.sql_file['get_mail_id']
                    self.cursor.execute(query, p_user_id=jsond['applied_by'])
                    user_details = Code_util.iterate_data(self.cursor)[0]
                    email = user_details['email_address']

                    subject = 'Request '
                    subject += 'approved' if jsond['status'] == 'A' else 'rejected'
                    subject += " by " + jsond['manager_name']
                    mail_data_common = {
                        # 'template_id': 867098, -- old template id
                        'template_id': 925106,
                        'subject': subject,
                        'params': [
                            {
                                'key': 'user_name',
                                'value': ''
                            },
                            {
                                'key': 'request_for',
                                'value': jsond['request_for']
                            },
                            {
                                'key': 'request_type',
                                'value': jsond['request_type']
                            },
                            {
                                'key': 'need_by',
                                'value': jsond['need_by']
                            },
                            {
                                'key': 'estimated_cost',
                                'value': jsond['estimated_cost']
                            },
                            {
                                'key': 'currency_code',
                                'value': jsond['currency_code']
                            },
                            {
                                'key': 'description',
                                'value': jsond['description']
                            },
                            {
                                'key': 'approve_link',
                                'value': ''
                            },
                            {
                                'key': 'reject_link',
                                'value': ''
                            },
                            {
                                'key': 'attachment_count',
                                'value': jsond['attachment_count']
                            },
                            {
                                'key': 'notification_users',
                                'value': ', '.join(recieve_notification_names)
                            },
                            {
                                'key': 'created_user_name',
                                'value': jsond['created_user_name']
                            },
                            {
                                'key': 'applied_user_name',
                                'value': jsond['applied_user_name']
                            }
                        ]
                    }
                    mail_data = mail_data_common
                    mail_data['params'].append({
                        'key': 'template_subject',
                        'value': 'Authorization request (#' + str(jsond['request_id']) +
                                 ') raised for ' + jsond['applied_user_name'] + ' has been ' +
                                 ('approved. ' if jsond['status'] == 'A' else 'rejected.'),
                    })
                    mail_data['recipients'] = recipients
                    CommonUtils.send_mail(mail_data)

                    # Send email to requester user to notify status
                    mail_data = mail_data_common
                    mail_data['to_name'] = ''
                    mail_data['params'].append({
                        'key': 'template_subject',
                        'value': 'Your authorization request (#' +
                                 str(jsond['request_id']) + ') has been ' +
                                 ('approved. ' if jsond['status'] == 'A' else
                                  'rejected.'),
                    })
                    mail_data.pop('recipients')
                    mail_data['to_email'] = email
                    mail_data['params'][0]['value'] = jsond['created_user_name']
                    CommonUtils.send_mail(mail_data)
                    final_result = status_code.getvalue()
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - preauthorization -
                            update_request_status """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - preauthorization - update_request_status(-)')
        return final_result

    def request_update(self, data):
        logger.addinfo('@ models - preauthorization - request_update(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                QPEX_PREAUTHORIZATION_PKG.request_update(
                    :p_request_id,
                    :p_user_id,
                    :p_request_for,
                    :p_request_type,
                    :p_need_by,
                    :p_has_offer,
                    :p_estimated_cost,
                    :p_currency_code,
                    :p_description,
                    :p_org_id,
                    :p_request_status,
                    :p_approver_user_id,
                    :p_approver_comments,
                    :p_employee_id,        
                    :x_status_code
                );
            end; """, p_request_id=data['request_id'],
                                p_user_id=int(data['user_id']),
                                p_request_for=data['request_for'],
                                p_request_type=data['request_type'],
                                p_need_by=data['need_by'],
                                p_has_offer=data['has_offer'],
                                p_estimated_cost=int(data['estimated_cost']),
                                p_currency_code=data['currency_code'],
                                p_description=data['description'],
                                p_org_id=int(data['org_id']),
                                p_request_status=data['request_status'],
                                p_approver_user_id=int(data['approver_user_id']),
                                p_approver_comments=data['approver_comments'],
                                p_employee_id=data['employee_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                # Add attachments
                if len(data['attachments']) > 0:
                    self.add_attachment(data['attachments'],
                                        data['request_id'])

                # To delete attachments
                if len(data['deleted_attachments']) > 0:
                    self.delete_attachments(data['deleted_attachments'])
                query = self.sql_file['get_mail_id']
                self.cursor.execute(query, p_user_id=data['approver_user_id'])
                user_data = Code_util.iterate_data(self.cursor)
                manager_email = user_data[0]['email_address']
                manager_name = user_data[0]['user_description']

                # Get user mail_address and name
                self.cursor.execute(query, p_user_id=data['user_id'])
                user_data = Code_util.iterate_data(self.cursor)
                created_user_name = user_data[0]['user_description']

                # Get requested for user mail_address and name
                self.cursor.execute(query, p_user_id=data['employee_id'])
                user_data = Code_util.iterate_data(self.cursor)
                applied_user_name = user_data[0]['user_description']

                jsond = {
                    'request_for': data['request_for'],
                    'request_type': data['request_type'],
                    'request_status': data['request_status'],
                    'need_by': data['need_by'],
                    'has_offer': data['has_offer'],
                    'estimated_cost': data['estimated_cost'],
                    'currency_code': data['currency_code'],
                    'description': data['description'],
                    'subject': data['subject'],
                    'created_date': data['created_date'],
                    'org_id': data['org_id'],
                    'applied_by': int(data['user_id']),
                    'request_id': int(data['request_id']),
                    'manager_name': data['manager_name'],
                    'applied_user_name': applied_user_name,
                    'attachment_count': data['attachments'],
                    'employee_id': data['employee_id'],
                    'created_user_name': created_user_name
                }

                # Sending notification to Giovanna
                query = self.sql_file['get_role_users']
                self.cursor.execute(query,
                                    p_role_name='UI-PREAUTHORIZATION-RECIEVE-NOTIFICATIONS')
                users = Code_util.iterate_data(self.cursor)
                recipients = []
                recieve_notification_names = []
                for i in range(len(users)):
                    if users[i]['employee_number'] != data['user_id']:
                        recieve_notification_names.append(users[i]['full_name'])
                        recipients.append({
                            'Email': users[i]['email_address'],
                            'Name': ''
                        })
                mail_data_common = {
                    # 'template_id': 867098, -- old template id
                    'template_id': 925106,
                    'subject': 'New Authorization request has been raised for : ' + applied_user_name,
                    'params': [
                        {
                            'key': 'template_subject',
                            'value': 'Authorization request(#' + str(data['request_id']) + ') is updated for the below item(s), '
                                     ' which is raised for ' + applied_user_name
                        },
                        {
                            'key': 'request_for',
                            'value': data['request_for']
                        },
                        {
                            'key': 'request_type',
                            'value': data['request_type']
                        },
                        {
                            'key': 'need_by',
                            'value': data['need_by']
                        },
                        {
                            'key': 'has_offer',
                            'value': data['has_offer']
                        },
                        {
                            'key': 'estimated_cost',
                            'value': data['estimated_cost']
                        },
                        {
                            'key': 'currency_code',
                            'value': data['currency_code']
                        },
                        {
                            'key': 'description',
                            'value': data['description']
                        },
                        {
                            'key': 'attachment_count',
                            'value': jsond['attachment_count']
                        },
                        {
                            'key': 'notification_users',
                            'value': ', '.join(recieve_notification_names)
                        },
                        {
                            'key': 'created_user_name',
                            'value': jsond['created_user_name']
                        },
                        {
                            'key': 'applied_user_name',
                            'value': jsond['applied_user_name']
                        }
                    ]
                }

                mail_data = mail_data_common
                mail_data['params'].append({
                    'key': 'user_name',
                    'value': ''
                })
                mail_data['params'].append({
                    'key': 'approve_link',
                    'value': ''
                })
                mail_data['params'].append({
                    'key': 'reject_link',
                    'value': ''
                })
                mail_data['recipients'] = recipients
                if len(recipients) > 0:
                    mail_status_rec = CommonUtils.send_mail(mail_data)
                else:
                    mail_status_rec = 'SUCCESS'

                # Create approve and reject links to send in mail
                jsond['status'] = 'A'
                approve_link = base64.b64encode(str(ujson.dumps(jsond)))
                jsond['status'] = 'R'
                reject_link = base64.b64encode(str(ujson.dumps(jsond)))

                mail_data = mail_data_common
                mail_data['subject'] = data['subject']
                mail_data['params'].append({
                    'key': 'user_name',
                    'value': manager_name
                })
                mail_data['params'].append({
                    'key': 'approve_link',
                    'value': approve_link
                })
                mail_data['params'].append({
                    'key': 'reject_link',
                    'value': reject_link
                })
                mail_data['to_email'] = manager_email
                mail_data['to_name'] = manager_name
                mail_status_manager = CommonUtils.send_mail(mail_data)
                if mail_status_manager == 'SUCCESS' and \
                        mail_status_rec == 'SUCCESS':
                    result['status'] = 0
                    result['msg'] = 'Request updated Successfully'
                    result['request_id'] = data['request_id']
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to send emails to recipients'
                    result['request_id'] = data['request_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update Request - ' + str(status)
                result['request_id'] = data['request_id']
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - preauthorization -
                request_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - preauthorization - request_update(-)')
        return result

    def delete_request(self, request_id):
        logger.addinfo('@ models - preauthorization - delete_request(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            result = {}
            self.cursor.execute("""
            begin
                QPEX_PREAUTHORIZATION_PKG.delete_request(:p_request_id,
                :x_status_code
                );
            end; """, p_request_id=request_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Request deleted Successfully'
                result['request_id'] = request_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete Request'
                result['request_id'] = request_id
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - preauthorization -
                             delete_request """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - preauthorization - delete_request(-)')
        return result

    def get_role_users_details(self, jsond):
        logger.addinfo('models - preauthorization - get_role_users_details(+)')
        try:
            self.acquire()
            query = self.sql_file['get_role_users']
            self.cursor.execute(query,
                                p_role_name=jsond['role_name'])
            users = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - preauthorization -
                             get_role_users_details """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - preauthorization - get_role_users_details(-)')
        return users

    def get_attachment_data(self, file_id):
        logger.addinfo("@ models - preauthorization - get_attachment_data(+)")
        try:
            self.acquire()
            query = self.sql_file['get_attachment_details']
            self.cursor.execute(query,
                                p_file_id=file_id)
            file_details = self.cursor.fetchone()[0]
            if file_details is not None:
                file_details = file_details.read()
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models -
            preauthorization - get_attachment_data""" + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo("@ models - preauthorization - get_attachment_data(-)")
        return file_details
