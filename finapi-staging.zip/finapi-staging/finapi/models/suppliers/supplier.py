import base64
import os
import smtplib
import ujson
import urllib.request
import urllib.parse
import urllib.error
from finapi.utils.code_util import Code_util
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from finapi.models.cms.cms import CMS

import cx_Oracle
import jinja2

from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.common_utils import CommonUtils
from finapi.models.procurement.procurement import Procurement
from finapi.utils.conn_util import OracleConnectionManager


class Supplier:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_supplier_invoices(org_id):
        logger.addinfo("@ models - supplier - get_supplier_invoices(+)")
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_invoices_query']
            cursor.execute(query, p_org_id=org_id)
            result = Code_util.iterate_data(cursor)
        except Exception as e:
            logger.findaylog("""@EXCEPTION - models -
            supplier - get_supplier_invoices""" + str(e))
            raise e
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - supplier - get_supplier_invoices(-)")
        return result

    @staticmethod
    def update_supplier_invoices(jsond):
        logger.addinfo("@ models - supplier - update_supplier_invoices(+)")
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            # if the invoice update fails send the invoice id's
            # in the response
            bank_failed = []
            failed = []
            for invoice_id in jsond['invoices']:
                cursor.execute("""
                begin
                    qpex_ap_aging_pkg.update_payment_schedules(
                        :p_invoice_id,
                        :x_status_code
                    );
                end; """, p_invoice_id=invoice_id,
                               x_status_code=status_code)
                if status_code.getvalue() == 'NO_BANK_ACCOUNT':
                    bank_failed.append(invoice_id)
                elif status_code.getvalue() != 'SUCCESS':
                    failed.append(invoice_id)
            if not failed and not bank_failed:
                result['msg'] = 'Invoice updated Successfully'
                result['status'] = 0
                # submit concurrent request
                cursor.execute("""
                begin
                    qpex_ap_aging_pkg.submit_interface(
                        :p_org_id,
                        :p_template_id
                    );
                end; """, p_org_id=jsond['org_id'],
                               p_template_id=jsond['template_id'])
            else:
                result['msg'] = 'Failed to update some invoices'
                result['status'] = 1
                result['invoices'] = failed
                result['failed_bank_invoices'] = bank_failed
        except Exception as e:
            logger.findaylog("""@EXCEPTION - models -
            supplier - update_supplier_invoices""" + str(e))
            raise e
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - suppliers - update_supplier_invoices(-)')
        return result

    @staticmethod
    #  used to get suppliers based on org
    @db_util.langs("American")
    def get_suppliers(org_id, vendor_id):
        logger.addinfo('@ models - suppliers - get_suppliers(+)')
        cm_DebitTo = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file["supplier_query"]
            cursor.execute(query, p_org_id=org_id, p_vendor_id=vendor_id)
        except Exception as error:
            logger.findaylog("""@ 32 EXCEPTION - suppliers - creditnotes -
                 get_suppliers """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for debitTo in cursor:
                tmpDebitTo = {}
                for index, fn in enumerate(fieldnames):
                    tmpDebitTo[fn] = debitTo[index]
                cm_DebitTo.append(tmpDebitTo)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - suppliers - get_suppliers(-)')
        return cm_DebitTo

    @staticmethod
    #  used to get supplier_names based on org
    @db_util.langs("American")
    def get_supplier_names(org_id):
        logger.addinfo('@ models - supplier - get_supplier_names(+)')
        suppliers = getSuppliersByOrg('supplier_names_query', org_id)
        logger.addinfo('@ models - supplier - get_supplier_names(-)')
        return suppliers

    @staticmethod
    #  used to get suppliers based on org
    @db_util.langs("American")
    def get_group_by_vendor(org_id, vendor_id):
        logger.addinfo('@ models - supplier - get_group_by_vendor(+)')
        try:
            with OracleConnectionManager() as conn:
                sql_file = db_util.getSqlData()
                query = sql_file['supplier_groupby_vendor']
                conn.execute(query, p_org_id=org_id, p_vendor_id=vendor_id)
                suppliers = conn.get_result()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                     get_group_by_vendor """ + str(error))
            raise error
        logger.addinfo('@ models - supplier - get_group_by_vendor(-)')
        return suppliers

    @staticmethod
    #  used to get suppliers based on org
    @db_util.langs("American")
    def get_groupBy_currency(org_id):
        logger.addinfo('@ models - supplier - get_groupBy_currency(+)')
        suppliers = getSuppliersByOrg('supplier_group_by_currency', org_id)
        logger.addinfo('@ models - supplier - get_groupBy_currency(-)')
        return suppliers

    @staticmethod
    #  used to get suppliers based on org
    @db_util.langs("American")
    def get_group_by_due_days(org_id, vendor_id):
        logger.addinfo('@ models - supplier - get_group_by_due_days(+)')
        try:
            with OracleConnectionManager() as conn:
                sql_file = db_util.getSqlData()
                query = sql_file['supplier_group_due_days']
                conn.execute(query, p_org_id=org_id, p_vendor_id=vendor_id)
                suppliers = conn.get_result()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                     get_group_by_due_days """ + str(error))
            raise error
        logger.addinfo('@ models - supplier - get_group_by_due_days(-)')
        return suppliers

    @staticmethod
    #  used to get suppliers based on org
    @db_util.langs("American")
    def groupBy_dueDays_range(org_id, from_Days, to_days):
        logger.addinfo('@ models - supplier - groupBy_dueDays_range(+)')
        cur = None
        con = None
        sqlFile = db_util.getSqlData()
        query = sqlFile['supplier_duedays_range']
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute(query, p_org_id=org_id, p_from_days=from_Days,
                        p_to_days=to_days)
        except Exception as error:
            logger.findaylog("""@ 73 EXCEPTION - models - supplier -
                 groupBy_dueDays_range """ + str(error))
            raise error
        else:
            suppliers = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in cur:
                supplier = {}
                for index, fn in enumerate(fieldnames):
                    supplier[fn] = row[index]
                suppliers.append(supplier)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - supplier - groupBy_dueDays_range(-)')
        return suppliers

    @staticmethod
    #  used to get suppliers based on vendor id and site id
    @db_util.langs("American")
    def get_suppliers_id(org_id, vendor_id, site_id):
        logger.addinfo('@ models - supplier - get_suppliers_id(+)')
        cur = None
        con = None
        sqlFile = db_util.getSqlData()
        query = sqlFile['supplier_query_vendor']
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute(query, porg_id=org_id, pvendor_id=vendor_id,
                        pvendor_site_id=site_id)
        except Exception as error:
            logger.findaylog("""@ 105 EXCEPTION - models - supplier -
                 get_suppliers_id """ + str(error))
            raise error
        else:
            suppliers = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in cur:
                supplier = {}
                for index, fn in enumerate(fieldnames):
                    supplier[fn] = row[index]
                suppliers.append(supplier)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - supplier - get_suppliers_id(-)')
        return suppliers

    #  used to get suppliers based on vendor id and site id
    @staticmethod
    @db_util.langs("American")
    def getSuplier_payment_details(check_id):
        logger.addinfo('@ models - supplier - getSuplier_payment_details(+)')
        cur = None
        con = None
        payment_detals = {}
        sqlFile = db_util.getSqlData()
        query = sqlFile['supply_payment_details']
        invQuery = sqlFile['supplier_paymt_invDetails']
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute(query, pcheck_id=check_id)
            fieldnames = [a[0].lower() for a in cur.description]
            for row in cur:
                for index, fn in enumerate(fieldnames):
                    payment_detals[fn] = row[index]
            cur.execute(invQuery, pcheck_id=check_id)
        except Exception as error:
            logger.findaylog("""@ 143 EXCEPTION - models - supplier -
                 getSuplier_payment_details """ + str(error))
            raise error
        else:
            paymentInvoices = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in cur:
                invoice = {}
                for index, fn in enumerate(fieldnames):
                    invoice[fn] = row[index]
                paymentInvoices.append(invoice)
            setattr(payment_detals, "invoiceDetails", paymentInvoices)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - supplier - getSuplier_payment_details(-)')
        return payment_detals

    @staticmethod
    @db_util.langs("American")
    def get_invoice_details(invoice_id):
        logger.addinfo('@ models - supplier - get_invoice_details(+)')
        connection = None
        cursor = None
        lines_details = []
        hold_details = []
        schedule_payment_details = []
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['sup_invoice_header_query']
            cursor.execute(query, p_invoice_id=invoice_id)
        except Exception as error:
            logger.findaylog("""@ 177 EXCEPTION - models - supplier -
                 get_invoice_details """ + str(error))
            raise error
        else:
            lines_details = Supplier.show_lines(invoice_id)
            hold_details = Supplier.hold_details_com(invoice_id)
            summary_details = Supplier.summary_details_com(invoice_id)
            schedule_payment_details = Supplier.payment_details(invoice_id)
            fieldnames = [a[0].lower() for a in cursor.description]
            invoice_header = {}
            header_details = []
            for row in cursor:
                header = {}
                for index, fn in enumerate(fieldnames):
                    header[fn] = row[index]
                header_details.append(header)
            invoice_header['header'] = header_details
            invoice_header['lines'] = lines_details
            invoice_header['hold'] = hold_details
            invoice_header['payment_summary'] = summary_details
            invoice_header['schedule_payment'] = schedule_payment_details
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_invoice_details(-)')
        return invoice_header

    @staticmethod
    def get_xml_invoices(jsond):
        logger.addinfo('@ models - supplier - get_xml_invoices(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            if jsond['start_date'] and jsond['end_date']:
                query = sql_file['sup_xml_invoice_query'] + sql_file['sup_xml_invoice_dates_query']
                cursor.execute(query, p_status=jsond['status'], p_invoice_num=jsond['invoice_number'],
                               p_start_date=jsond['start_date'], p_end_date=jsond['end_date'])
            elif jsond['start_date']:
                query = sql_file['sup_xml_invoice_query'] + \
                    sql_file['sup_xml_invoice_start_date_query']
                cursor.execute(query, p_status=jsond['status'], p_invoice_num=jsond['invoice_number'],
                               p_start_date=jsond['start_date'])
            elif jsond['end_date']:
                query = sql_file['sup_xml_invoice_query'] + \
                    sql_file['sup_xml_invoice_end_date_query']
                cursor.execute(query, p_status=jsond['status'], p_invoice_num=jsond['invoice_number'],
                               p_end_date=jsond['end_date'])
            else:
                query = sql_file['sup_xml_invoice_query']
                cursor.execute(query, p_status=jsond['status'],
                               p_invoice_num=jsond['invoice_number'])

        except Exception as error:
            logger.findaylog("""@EXCEPTION - models - supplier -
                 get_xml_invoices """ + str(error))
            raise error
        else:
            xml_suppliers = Code_util.iterate_data(cursor)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_xml_invoices(-)')
        return xml_suppliers

    @staticmethod
    def get_xml_attachments(load_id):
        logger.addinfo('@ models - supplier - get_xml_attachments(+)')
        connection = None
        cursor = None
        attachments = []
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['xml_attachment_query']
            cursor.execute(query, p_load_id=load_id)
        except Exception as error:
            logger.findaylog("""@EXCEPTION - models - supplier -
                 get_xml_attachments """ + str(error))
            raise error
        else:
            attachmentsFn = [a[0].lower() for a in cursor.description]
            for attachment in cursor:
                attachment_data = {}
                for index, fn in enumerate(attachmentsFn):
                    if fn == 'attachment_data':
                        encoded_string = ''
                        if attachment[index]:
                            encoded_string = (base64.b64encode(attachment[index].read()))
                        attachment_data[fn] = encoded_string
                    else:
                        attachment_data[fn] = attachment[index]
                attachments.append(attachment_data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_xml_attachments(-)')
        return attachments

    @staticmethod
    def show_lines(invoice_id):
        logger.addinfo('@ models - supplier - show_lines(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['sup_invoice_lines']
            cursor.execute(query, p_invoice_id=invoice_id)
        except Exception as error:
            logger.findaylog("""@ 215 EXCEPTION - models - supplier -
                 show_lines """ + str(error))
            raise error
        else:
            inv_lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                inv_line = {}
                for index, fn in enumerate(fieldnames):
                    inv_line[fn] = row[index]
                inv_lines.append(inv_line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - show_lines(-)')
        return inv_lines

    @staticmethod
    def hold_details_com(invoice_id):
        hold_details = []
        logger.addinfo('@ models - supplier - hold_details_com(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_hold_query']
            cursor.execute(query, p_invoice_id=invoice_id)
        except Exception as error:
            logger.findaylog("""@ 243 EXCEPTION - models - supplier -
                 hold_details_com """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                tax_line = {}
                for index, fn in enumerate(fieldnames):
                    tax_line[fn] = row[index]
                hold_details.append(tax_line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - hold_details_com(-)')
        return hold_details

    @staticmethod
    def summary_details_com(invoice_id):
        summary_details = []
        logger.addinfo('@ models - supplier - summary_details_com(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['payment_summary_query']
            cursor.execute(query, p_invoice_id=invoice_id)
        except Exception as error:
            logger.findaylog("""@ 270 EXCEPTION - models - supplier -
                 summary_details_com """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                address_line = {}
                for index, fn in enumerate(fieldnames):
                    address_line[fn] = row[index]
                summary_details.append(address_line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - summary_details_com(-)')
        return summary_details

    @staticmethod
    def get_drill_down_details(jsond):
        logger.addinfo('@ models - supplier - get_drill_down_details(+)')
        connection = None
        cursor = None
        period = jsond['period']
        ledger_id = jsond['ledger_id']
        account = jsond['account']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['trail_bal_drill_down_query']
            cursor.execute(qry, p_account=account,
                           p_period_name=period,
                           p_ledger_id=ledger_id)
        except Exception as error:
            logger.findaylog("""@ 303 EXCEPTION - models - supplier -
                 get_drill_down_details """ + str(error))
            raise error
        else:
            suppliers = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                supplier = {}
                for index, fn in enumerate(fieldnames):
                    supplier[fn] = row[index]
                suppliers.append(supplier)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_drill_down_details(-)')
        return suppliers

    @staticmethod
    def payment_details(invoice_id):
        schedule_payment_details_info = []
        logger.addinfo('@ models - supplier - payment_details(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['scheduled_payments_query']
            cursor.execute(query, p_invoice_id=invoice_id)
        except Exception as error:
            logger.findaylog("""@ 333 EXCEPTION - models - supplier -
                 payment_details """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                note_line = {}
                for index, fn in enumerate(fieldnames):
                    note_line[fn] = row[index]
                schedule_payment_details_info.append(note_line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - payment_details(-)')
        return schedule_payment_details_info

    @staticmethod
    @db_util.langs("American")
    def get_purchase_order_details(po_header_id):
        logger.addinfo('@ models - supplier - get_purchase_order_details(+)')
        connection = None
        cursor = None
        lines_details = []
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['po_headers_query']
            cursor.execute(query, p_po_header_id=po_header_id)
            cursor.arraysize = 1000
            obj = {}
            if po_header_id:
                lines_details = Supplier.po_lines(po_header_id)
                obj['lines'] = lines_details
            fieldnames = [a[0].lower() for a in cursor.description]
            header_details = []
            for row in cursor:
                header = {}
                for index, fn in enumerate(fieldnames):
                    header[fn] = row[index]
                header_details.append(header)
            obj['header'] = header_details
        except Exception as error:
            logger.findaylog("""@ 376 EXCEPTION - models - supplier -
                 get_purchase_order_details """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_purchase_order_details(-)')
        return obj

    @staticmethod
    def get_chart_accounts():
        logger.addinfo('@ models - supplier - get_chart_accounts(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['coa_query']
            cursor.execute(qry)
        except Exception as error:
            logger.findaylog("""@ 397 EXCEPTION - models - supplier -
                 get_chart_accounts """ + str(error))
            raise error
        else:
            accounts = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                account = {}
                for index, fn in enumerate(fieldnames):
                    account[fn] = row[index]
                accounts.append(account)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_chart_accounts(-)')
        return accounts

    @staticmethod
    def update_attachment(attachment):
        logger.addinfo('@ models - supplier - update_attachment(+)')
        connection = None
        cursor = None
        try:
            file_data = attachment['file_data']
            file_id = attachment['file_id']
            file_name = attachment['file_name']
            content = attachment['file_content_type']
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['attachement_update_query']
            cursor.setinputsizes(p_file_data=cx_Oracle.BLOB)
            cursor.execute(qry, p_file_name=file_name, p_file_id=file_id,
                           p_file_data=file_data, p_content_type=content)
        except Exception as error:
            logger.findaylog("""@ 432 EXCEPTION - models - supplier -
                 update_attachment """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - update_attachment(-)')
        return "succcess"

    @staticmethod
    def po_lines(po_header_id):
        logger.addinfo('@ models - supplier - po_lines(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['po_lines_query']
            cursor.execute(query, p_po_header_id=po_header_id)
        except Exception as error:
            logger.findaylog("""@ 452 EXCEPTION - models - supplier -
                 po_lines """ + str(error))
            raise error
        else:
            inv_lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                inv_line = {}
                for index, fn in enumerate(fieldnames):
                    inv_line[fn] = row[index]
                inv_lines.append(inv_line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - po_lines(-)')
        return inv_lines

    @staticmethod
    def get_shipment_details(po_line_id):
        logger.addinfo('@ models - supplier - get_shipment_details(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['po_line_shipment_query']
            cursor.execute(query, p_po_line_id=po_line_id)
        except Exception as error:
            logger.findaylog("""@ 479 EXCEPTION - models - supplier -
                 get_shipment_details """ + str(error))
            raise error
        else:
            lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                line = {}
                for index, fn in enumerate(fieldnames):
                    line[fn] = row[index]
                lines.append(line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_shipment_details(-)')
        return lines

    #  used to get payment registerd data
    @staticmethod
    @db_util.langs("American")
    def payment_register(jsond):
        from_date = jsond['from_date']
        to_date = jsond['to_date']
        status = jsond['status']
        orgid = jsond['org_id']
        logger.addinfo('@ models - supplier - payment_register(+)')
        cur = None
        con = None
        sqlFile = db_util.getSqlData()
        query = sqlFile['payment_register_query']
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.arraysize = 1000
            cur.execute(query, porg_id=orgid, pstatus=status,
                        p_from_date=from_date, p_to_date=to_date)
        except Exception as error:
            logger.findaylog("""@ 516 EXCEPTION - models - supplier -
                 payment_register """ + str(error))
            raise error
        else:
            suppliers = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in cur:
                supplier = {}
                for index, fn in enumerate(fieldnames):
                    supplier[fn] = row[index]
                suppliers.append(supplier)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - supplier - payment_register(-)')
        return suppliers

    @staticmethod
    def get_agent_address_details(org_id):
        logger.addinfo('@ models - supplier - get_agent_address_details(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['sup_agent_address_query']
            cursor.execute(query, p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ 543 EXCEPTION - models - supplier -
                 get_agent_address_details """ + str(error))
            raise error
        else:
            lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                line = {}
                for index, fn in enumerate(fieldnames):
                    line[fn] = row[index]
                lines.append(line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_agent_address_details(-)')
        return lines

    @staticmethod
    def get_supplier_address_inf(org_id, vendor_id, site_id):
        logger.addinfo('@ models - supplier - get_supplier_address_inf(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_address_query']
            cursor.execute(query, p_org_id=org_id,
                           p_site_id=site_id, p_vendor_id=vendor_id)
        except Exception as error:
            logger.findaylog("""@ 571 EXCEPTION - models - supplier -
                 get_supplier_address_inf """ + str(error))
            raise error
        else:
            lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                line = {}
                for index, fn in enumerate(fieldnames):
                    line[fn] = row[index]
                lines.append(line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_supplier_address_inf(-)')
        return lines

    @staticmethod
    def get_transaction_details(jsond):
        logger.addinfo('@ models - supplier - get_transaction_details(+)')
        connection = None
        cursor = None
        invoice_date_from = jsond['invoice_date_from']
        invoice_date_to = jsond['invoice_date_to']
        gl_date_from = jsond['gl_date_from']
        gl_date_to = jsond['gl_date_to']
        due_date_from = jsond['due_date_from']
        due_date_to = jsond['due_date_to']
        vendor_id = jsond['vendor_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['transction_query']
            cursor.execute(qry, p_invoice_date_from=invoice_date_from,
                           p_invoice_date_to=invoice_date_to,
                           p_gl_date_from=gl_date_from,
                           p_gl_date_to=gl_date_to,
                           p_due_date_from=due_date_from,
                           p_due_date_to=due_date_to,
                           p_vendor_id=vendor_id)
        except Exception as error:
            logger.findaylog("""@ 613 EXCEPTION - models - supplier -
                 get_transaction_details """ + str(error))
            raise error
        else:
            my_data = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                my_data.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_transaction_details(-)')
        return my_data

    @staticmethod
    def get_Status_lov():
        logger.addinfo('@ models - supplier - get_Status_lov(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['payment_status_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 640 EXCEPTION - models - supplier -
                 get_Status_lov """ + str(error))
            raise error
        else:
            lovs = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                love = {}
                for index, fn in enumerate(fieldnames):
                    love[fn] = row[index]
                lovs.append(love)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_Status_lov(-)')
        return lovs

    @staticmethod
    def get_address_by_vendorId(org_id, vendor_id):
        logger.addinfo('@ models - supplier - get_address_by_vendorId(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['addressbook_addressby_vendorid']
            cursor.execute(query, p_org_id=org_id, p_vendor_id=vendor_id)
        except Exception as error:
            logger.findaylog("""@ 667 EXCEPTION - models - supplier -
                 get_address_by_vendorId """ + str(error))
            raise error
        else:
            lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                line = {}
                for index, fn in enumerate(fieldnames):
                    line[fn] = row[index]
                lines.append(line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_address_by_vendorId(-)')
        return lines

    @staticmethod
    def get_addressbook_suppliers(org_id):
        logger.addinfo('@ models - supplier - get_addressbook_suppliers(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['addressbook_suppliers']
            cursor.arraysize = 1000
            cursor.execute(query, p_org_id=org_id)
        except Exception as error:
            logger.addinfo("EXCEPTION in database stmt in" +
                           "get_supplier_address_details")
            logger.findaylog("""@ models - supplier 
            - get_addressbook_suppliers - """ + str(error))
            raise error
        else:
            lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                line = {}
                for index, fn in enumerate(fieldnames):
                    line[fn] = row[index]
                lines.append(line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_addressbook_suppliers(-)')
        return lines

    @staticmethod
    def supplier_on_salesrep(org_id, salesrep_id):
        logger.addinfo('@ models - supplier - supplier_on_salesrep(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_on_salesrep']
            cursor.execute(query, p_org_id=org_id, p_sales_rep_id=salesrep_id)
        except Exception as error:
            logger.findaylog("""@ 724 EXCEPTION - models - supplier -
                 supplier_on_salesrep """ + str(error))
            raise error
        else:
            lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                line = {}
                for index, fn in enumerate(fieldnames):
                    line[fn] = row[index]
                lines.append(line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - supplier_on_salesrep(-)')
        return lines

    @staticmethod
    def lookup_data():
        logger.addinfo('@ models - supplier - lookup_data(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_lookup']
            cursor.execute("alter session set nls_language='American'")
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 754 EXCEPTION - models - supplier -
                 lookup_data """ + str(error))
            raise error
        else:
            lookup = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                love = {}
                for index, fn in enumerate(fieldnames):
                    love[fn] = row[index]
                lookup.append(love)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - lookup_data(-)')
        return lookup

    @staticmethod
    def update_supplier_details(jsond):
        logger.addinfo('@ models - supplier - update_supplier_details(+)')
        connection = None
        cursor = None
        group_name = jsond['group_name']
        status = jsond['status']
        end_date_active = jsond['end_date_active']
        supplier_number = jsond['supplier_number']
        email_address = jsond['email_address']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['supplier_update_query']
            cursor.execute(qry, p_group_name=group_name,
                           p_email_address=email_address,
                           p_status=status,
                           p_supplier_number=supplier_number,
                           p_end_date=end_date_active,
                           p_salesrep_id=salesrep_id)
        except Exception as error:
            logger.findaylog("""@ 794 EXCEPTION - models - supplier -
                 update_supplier_details """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            final = {}
            final['status'] = 1
            final['msg'] = "success"
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - update_supplier_details(-)')
        return final

    @staticmethod
    def trail_balance(ledg_id, period_name):
        logger.addinfo('@ models - supplier - trail_balance(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['trail_balance']
            cursor.execute("alter session set nls_language='American'")
            cursor.execute(query, P_PERIOD_NAME=period_name,
                           P_LEDGER_ID=ledg_id)
            cursor.arraysize = 1000
        except Exception as error:
            logger.findaylog("""@ 822 EXCEPTION - models - supplier -
                 trail_balance """ + str(error))
            raise error
        else:
            trail_balances = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                trail_balance = {}
                for index, fn in enumerate(fieldnames):
                    trail_balance[fn] = row[index]
                trail_balances.append(trail_balance)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - trail_balance(-)')
        return trail_balances

    @staticmethod
    def ledget_name():
        logger.addinfo('@ models - supplier - ledget_name(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['ledget_name']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 851 EXCEPTION - models - supplier -
                 ledget_name """ + str(error))
            raise error
        else:
            ledget_names = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                ledget_name = {}
                for index, fn in enumerate(fieldnames):
                    ledget_name[fn] = row[index]
                ledget_names.append(ledget_name)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - ledget_name(-)')
        return ledget_names

    @staticmethod
    def ledget_period():
        logger.addinfo('@ models - supplier - ledget_period(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['ledget_period']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 880 EXCEPTION - models - supplier -
                 ledget_period """ + str(error))
            raise error
        else:
            ledget_periods = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                ledget_period = {}
                for index, fn in enumerate(fieldnames):
                    ledget_period[fn] = row[index]
                ledget_periods.append(ledget_period)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - ledget_period(-)')
        return ledget_periods

    @staticmethod
    def supplier_invoice(inv_num, vendor_id, vendorsite_id):
        logger.addinfo('@ models - supplier - supplier_invoice(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_invoice']
            query += ' AND nvl(current_approver_id, -1) = nvl(:p_approver_id, nvl(current_approver_id, -1))'
            cursor.execute(query, p_invnum=inv_num,
                           pvendor_id=vendor_id,
                           p_vendor_siteid=vendorsite_id,
                           p_org_id=None,
                           p_approver_id=None)
        except Exception as error:
            logger.findaylog("""@ 910 EXCEPTION - models - supplier -
                 supplier_invoice """ + str(error))
            raise error
        else:
            supinv_data = []
            fieldnames = [a[0].lower() for a in cursor.description]
            attach_seq = ''
            for row in cursor:
                supinv = {}
                for index, fn in enumerate(fieldnames):
                    if inv_num:
                        if fn == 'invoice_num':
                            supinv['lines'] = Supplier.supplier_inv_lines(
                                row[index], vendor_id, vendorsite_id)
                        if fn == 'header_seq':
                            attach_seq = row[index]
                    supinv[fn] = row[index]
                if inv_num:
                    attachments = []
                    cursor.execute("alter session set nls_language='American'")
                    cursor.execute(sql_file['supplierattach_detailsonly'],
                                   p_attachseq=str(attach_seq))
                    data = cursor.fetchall()
                    attachmentsFn = [a[0].lower() for a in cursor.description]
                    for attachment in data:
                        attachment_data = {}
                        for index, fn in enumerate(attachmentsFn):
                            attachment_data[fn] = attachment[index]
                        attachments.append(attachment_data)
                    supinv['attachments'] = attachments
                supinv_data.append(supinv)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - supplier_invoice(-)')
        return supinv_data

    @staticmethod
    def supplier_invoice_data(req):
        logger.addinfo('@ models - supplier - supplier_invoice_data(+)')
        connection = None
        cursor = None
        kwargs = {'p_invnum': req.get('inv_num', None), 'pvendor_id': req.get('vendor_id', None),
                  'p_vendor_siteid': req.get('vendor_site', None),
                  'p_org_id': req.get('org_id', None)}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_invoice']
            # for getting employees invoice details that are under a manager
            if 'employees' in req:
                query += ' AND current_approver_id IN ({})'.format(req['employees'])
            else:
                query += ' AND nvl(current_approver_id, -1) = nvl(:p_approver_id, nvl(current_approver_id, -1))'
                kwargs['p_approver_id'] = req.get('approver_id', None)
            query += ' AND qp.INVOICE_STATUS = NVL(:p_status,qp.INVOICE_STATUS)'
            kwargs['p_status'] = req.get('status', None)
            size = req.get('size', None)
            if size:
                tmp_query = 'SELECT * FROM (' + query
                tmp_query += ' order by qp.creation_date desc)'
                tmp_query += ' where rownum < :p_row_num'
                size = int(size) + 1
                kwargs['p_row_num'] = size
                cursor.execute(tmp_query, kwargs)
            else:
                cursor.execute(query, kwargs)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                 supplier_invoice_data """ + str(error))
            raise error
        else:
            supinv_data = []
            inv_num = req.get('inv_num', None)
            fieldnames = [a[0].lower() for a in cursor.description]
            attach_seq = ''
            for row in cursor:
                supinv = {}
                for index, fn in enumerate(fieldnames):
                    if inv_num:
                        if fn == 'invoice_num':
                            supinv['lines'] = Supplier.supplier_inv_lines(
                                row[index], req.get('vendor_id', None), req.get('vendor_site', None))
                        if fn == 'header_seq':
                            attach_seq = row[index]
                    supinv[fn] = row[index]
                if inv_num:
                    attachments = []
                    cursor.execute("alter session set nls_language='American'")
                    cursor.execute(sql_file['supplierattach_detailsonly'],
                                   p_attachseq=str(attach_seq))
                    data = cursor.fetchall()
                    attachmentsFn = [a[0].lower() for a in cursor.description]
                    for attachment in data:
                        attachment_data = {}
                        for index, fn in enumerate(attachmentsFn):
                            attachment_data[fn] = attachment[index]
                        attachments.append(attachment_data)
                    supinv['attachments'] = attachments
                supinv_data.append(supinv)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - supplier_invoice_data(-)')
        return supinv_data

    @staticmethod
    def supplier_inv_lines(pinvnum, vendor_id, vendorsite_id):
        logger.addinfo('@ models - supplier - supplier_inv_lines(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_invoice_lines']
            cursor.execute(query, p_invnum=pinvnum,
                           p_vendorid=vendor_id, pvendor_site=vendorsite_id)
        except Exception as error:
            logger.findaylog("""@ 962 EXCEPTION - models - supplier -
                 supplier_inv_lines """ + str(error))
            raise error
        else:
            supinv_lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                supinv_line = {}
                for index, fn in enumerate(fieldnames):
                    supinv_line[fn] = row[index]
                supinv_lines.append(supinv_line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - supplier_inv_lines(-)')
        return supinv_lines

    @staticmethod
    def inv_typelov():
        logger.addinfo('@ models - supplier - inv_typelov(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invtype_lookup_code']
            cursor.execute("alter session set nls_language='American'")
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 992 EXCEPTION - models - supplier -
                 inv_typelov """ + str(error))
            raise error
        else:
            invtype_lookup_codes = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                invtype_lookup_code = {}
                for index, fn in enumerate(fieldnames):
                    invtype_lookup_code[fn] = row[index]
                invtype_lookup_codes.append(invtype_lookup_code)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - inv_typelov(-)')
        return invtype_lookup_codes

    @staticmethod
    def linetype_lookup(lang):
        logger.addinfo('@ models - supplier - linetype_lookup(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['linetype_lookup_code']
            cursor.execute(query, p_language=lang)
        except Exception as error:
            logger.findaylog("""@ 1022 EXCEPTION - models - supplier -
                 linetype_lookup """ + str(error))
            raise error
        else:
            linetype_lookups = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                linetype_lookup = {}
                for index, fn in enumerate(fieldnames):
                    linetype_lookup[fn] = row[index]
                linetype_lookups.append(linetype_lookup)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - linetype_lookup(-)')
        return linetype_lookups

    @staticmethod
    @db_util.langs("American")
    def vendor_lov(org_id, user_id):
        logger.addinfo('@ models - supplier - vendor_lov(+)')
        connection = None
        cursor = None
        exclude_suppliers = ''
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['vendor_lov']
            kwargs = {'p_org_id': org_id}
            if user_id:
                kwargs['p_user_id'] = user_id
                exclude_suppliers = sql_file['vendor_exclude_suppliers']
            query = query.format(user_filter=exclude_suppliers)
            cursor.execute(query, **kwargs)
        except Exception as error:
            logger.findaylog("""@ 1052 EXCEPTION - models - supplier -
                 vendor_lov """ + str(error))
            raise error
        else:
            vendor_lovs = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                vendor_lov = {}
                for index, fn in enumerate(fieldnames):
                    vendor_lov[fn] = row[index]
                vendor_lovs.append(vendor_lov)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - vendor_lov(-)')
        return vendor_lovs

    @staticmethod
    def vendor_sites(p_org, p_vendorid):
        logger.addinfo('@ models - supplier - vendor_sites(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['vendor_sites']
            cursor.execute(query, p_org_id=p_org, p_vendor_id=p_vendorid)
        except Exception as error:
            logger.findaylog("""@ 1081 EXCEPTION - models - supplier -
                 vendor_sites """ + str(error))
            raise error
        else:
            vendor_sites = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                vendor_site = {}
                for index, fn in enumerate(fieldnames):
                    vendor_site[fn] = row[index]
                vendor_sites.append(vendor_site)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - vendor_sites(-)')
        return vendor_sites

    @staticmethod
    def hubspot_contact_creation():
        logger.addinfo('@ models - supplier - hubspot_contact_creation(+)')
        connection = None
        cursor = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            personas = sql_file['supplier_persona_map']
            cursor.execute(sql_file['get_supplier_contacts'])
            supplier_contacts = Code_util.iterate_data(cursor)
            obj = CMS()
            failed_suppliers = []
            for contact in supplier_contacts:
                if contact['country'] not in personas:
                    persona = 'persona_47'
                else:
                    persona = personas[contact['country']]
                props = {
                    'email': contact['supplier_email'],
                    'firstname': contact['vendor_name'],
                    'hs_persona': persona,
                    'address': contact['address_line1'],
                    'city': contact['city'],
                    'province': contact['province'],
                    'state': contact['state'],
                    'country': contact['country'],
                    'zip': contact['zip'],
                    'workflow_trigger': 'send_gdpr_email'
                }
                status = obj.create_contact(props)
                if 'status' in status:
                    failed_suppliers.append({'supplier_email': contact['supplier_email']})
            if failed_suppliers:
                result['status'] = 1
                result['msg'] = 'Failed to add few contacts to Hubspot'
                result['failed_supplier'] = failed_suppliers
            else:
                result['status'] = 0
                result['msg'] = 'All Supplier contacts were moved to Hubspot'
                result['failed_supplier'] = failed_suppliers
        except Exception as error:
            logger.findaylog("""@ 1081 EXCEPTION - models - supplier -
                 hubspot_contact_creation """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - hubspot_contact_creation(-)')
        return result

    @staticmethod
    def create_invoice(jsond):
        logger.addinfo('@ models - supplier - create_invoice(+)')
        connection = None
        cur = None
        gl_date = None
        try:
            connection = db_util.get_connection()
            cur = connection.cursor()
            header_seq = cur.var(cx_Oracle.NUMBER)
            status_code = cur.var(cx_Oracle.STRING)
            gl_date = jsond.get('gl_date', None)
            cur.execute("""
            begin
                qpex_supplier_pkg.create_invoice(
                    :p_invoice_num,
                    :p_invoice_date,
                    :p_invoice_lookup_code,
                    :p_gl_date,
                    :p_description,
                    :p_vendor_id,
                    :p_vendor_site_id,
                    :p_invoice_amount,
                    :p_invoice_currency_code,
                    :p_invoice_status,
                    :p_po_number,
                    :p_term_change,
                    :p_term_id,
                    :p_created_by,
                    :p_invoice_type_id,
                    :p_invoice_type_code,
                    :p_is_matched,
                    :p_org_id,
                    :p_sdi_num,
                    :x_header_seq,
                    :x_status_code
                );
            end; """, p_invoice_num=jsond['invoice_num'],
                        p_invoice_date=jsond['invoice_date'],
                        p_invoice_lookup_code='',
                        p_gl_date=gl_date,
                        p_description=jsond['description'],
                        p_vendor_id=jsond['vendor_id'],
                        p_vendor_site_id=jsond['vendor_site_id'],
                        p_invoice_amount=jsond['invoice_amount'],
                        p_invoice_currency_code=jsond['invoice_currency_code'],
                        p_invoice_status=jsond['invoice_status'],
                        p_po_number=jsond['po_number'],
                        p_term_change=jsond['term_change'],
                        p_term_id=jsond['term_id'],
                        p_created_by=jsond['created_by'],
                        p_invoice_type_id=jsond['invoice_type_id'],
                        p_invoice_type_code=jsond['invoice_type_code'],
                        p_is_matched=jsond['is_matched'],
                        p_org_id=jsond['org_id'],
                        p_sdi_num='',
                        x_header_seq=header_seq,
                        x_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ 1233 EXCEPTION - models - supplier -
                 create_invoice """ + str(error))
            raise error
        finally:
            connection.commit()
            cur.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - create_invoice(-)')
        return header_seq.getvalue()

    @staticmethod
    def create_invoice_line(jsond):
        logger.addinfo('@ models - supplier - create_invoice_line(+)')
        connection = None
        cur = None
        status = ""
        try:
            connection = db_util.get_connection()
            cur = connection.cursor()
            line_number = cur.var(cx_Oracle.NUMBER)
            status_code = cur.var(cx_Oracle.STRING)
            for l in jsond:
                cur.execute("""
                begin
                    qpex_supplier_pkg.create_invoice_line(
                        :p_invoice_num,
                        :p_vendor_id,
                        :p_line_type_lookup_code,
                        :p_line_description,
                        :p_vendor_site_id,
                        :p_amount,
                        :p_po_header_id,
                        :p_po_line_id,
                        :p_po_line_location_id,
                        :p_quantity_invoiced,
                        :p_taxable_amount,
                        :p_tax_id,
                        :p_awt_tax_id,
                        :p_awt_group_id,
                        :p_receipt_num,
                        :p_close_po,
                        :x_line_number,
                        :x_status_code
                    );
                end; """, p_invoice_num=l['invoice_num'],
                            p_vendor_id=l['vendor_id'],
                            p_line_type_lookup_code=l['line_type_lookup_code'],
                            p_line_description=l['line_description'],
                            p_vendor_site_id=l['vendor_site_id'],
                            p_amount=l['amount'],
                            p_po_header_id=l['po_header_id'],
                            p_po_line_id=l['po_line_id'],
                            p_po_line_location_id=l['po_line_location_id'],
                            p_quantity_invoiced=l['quantity_invoiced'],
                            p_taxable_amount=l['taxable_amount'],
                            p_tax_id=l['tax_id'],
                            p_awt_tax_id=l['awt_tax_id'],
                            p_awt_group_id=l['awt_group_id'],
                            p_receipt_num=l['receipt_num'],
                            p_close_po=l['close_po'],
                            x_line_number=line_number,
                            x_status_code=status_code)
                status = status_code.getvalue().lower()
                if status != 'success':
                    logger.findaylog("""@ models - supplier - create_invoice_line 
                    - failed to create invoice line - """ + status)
        except Exception as error:
            logger.findaylog("""@ 1290 EXCEPTION - models - supplier -
                 create_invoice_line """ + str(error))
            raise error
        finally:
            connection.commit()
            cur.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - create_invoice_line(-)')
        return status

    @staticmethod
    def update_invoice(jsond):
        logger.addinfo('@ models - supplier - update_invoice(+)')
        con = None
        cur = None
        gl_date = None
        invoice_status = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status_code = cur.var(cx_Oracle.STRING)
            gl_date = jsond.get('gl_date', None)
            invoice_status = jsond.get('invoice_status', None)
            cur.execute("""
            begin
                qpex_supplier_pkg.update_invoice(
                    :p_invoice_num,
                    :p_newinvoice_num,
                    :p_invoice_date,
                    :p_gl_date,
                    :p_description,
                    :p_vendor_id,
                    :p_vendor_site_id,
                    :p_invoice_amount,
                    :p_invoice_currency_code,
                    :p_invoice_status,
                    :p_po_number,
                    :p_term_change,
                    :p_term_id,
                    :p_invoice_type_id,
                    :p_invoice_type_code,
                    :p_is_matched,
                    :p_org_id,
                    :p_accounting_approval,
                    :x_status_code
                );
            end; """, p_invoice_num=jsond['old_invoice'],
                        p_newinvoice_num=jsond['invoice_num'],
                        p_invoice_date=jsond['invoice_date'],
                        p_gl_date=gl_date,
                        p_description=jsond['description'],
                        p_vendor_id=jsond['vendor_id'],
                        p_vendor_site_id=jsond['vendor_site_id'],
                        p_invoice_amount=jsond['invoice_amount'],
                        p_invoice_currency_code=jsond['invoice_currency_code'],
                        p_invoice_status=invoice_status,
                        p_po_number=jsond['po_number'],
                        p_term_change=jsond['term_change'],
                        p_term_id=jsond['term_id'],
                        p_invoice_type_id=jsond['invoice_type_id'],
                        p_invoice_type_code=jsond['invoice_type_code'],
                        p_is_matched=jsond['is_matched'],
                        p_org_id=jsond['org_id'],
                        p_accounting_approval=jsond['accounting_approval'],
                        x_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ 1211 EXCEPTION - models - supplier -
                 update_invoice """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - supplier - update_invoice(-)')
        return con

    @staticmethod
    def update_invoice_line(line, invnum):
        logger.addinfo('@ models - supplier - update_invoice_line(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status_code = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
                qpex_supplier_pkg.update_invoice_line(
                    :p_invoice_num,
                    :p_oldinv_num,
                    :p_vendor_id,
                    :p_line_type_lookup_code,
                    :p_line_description,
                    :p_vendor_site_id,
                    :p_amount,
                    :p_po_header_id,
                    :p_po_line_id,
                    :p_po_line_location_id,
                    :p_quantity_invoiced,
                    :p_taxable_amount,
                    :p_tax_id,
                    :p_awt_tax_id,
                    :p_line_number,
                    :p_receipt_num,
                    :p_close_po,
                    :x_status_code
                );
            end; """, p_invoice_num=line['invoice_num'],
                        p_oldinv_num=invnum,
                        p_vendor_id=line['vendor_id'],
                        p_line_type_lookup_code=line['line_type_lookup_code'],
                        p_line_description=line['line_description'],
                        p_vendor_site_id=line['vendor_site_id'],
                        p_amount=line['amount'],
                        p_po_header_id=line['po_header_id'],
                        p_po_line_id=line['po_line_id'],
                        p_po_line_location_id=line['po_line_location_id'],
                        p_quantity_invoiced=line['quantity_invoiced'],
                        p_taxable_amount=line['taxable_amount'],
                        p_tax_id=line['tax_id'],
                        p_awt_tax_id=line['awt_tax_id'],
                        p_line_number=line['line_number'],
                        p_receipt_num=line['receipt_num'],
                        p_close_po=line['close_po'],
                        x_status_code=status_code)
            result = status_code.getvalue().lower()
            if result != 'success':
                logger.findaylog("""@ models - supplier - update_invoice_line
                 - failed to update invoice line - """ + result)
        except Exception as error:
            logger.findaylog("""@ 1242 EXCEPTION - models - supplier -
                 update_invoice_line """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - supplier - update_invoice_line(-)')
        return status_code.getvalue().lower()

    @staticmethod
    def inv_delete(pinv_num, pvendor_id, psite_id):
        logger.addinfo('@ models - supplier - inv_delete(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['sup_invhdr_delete']
            cursor.execute(query, p_invnum=pinv_num,
                           p_vendorid=pvendor_id, pvendor_site=psite_id)
            query = sql_file['sup_invline_delete']
            cursor.execute(query, p_invnum=pinv_num,
                           p_vendorid=pvendor_id, pvendor_site=psite_id)
        except Exception as error:
            logger.addinfo("EXCEPTION in database stmt in vendor_lov")
            logger.findaylog("""@ models - supplier - inv_delete 
            - """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - inv_delete(-)')
        return "success"

    @staticmethod
    def get_invvalidation(inv_num, vendor_id, site_id):
        logger.addinfo('@ models - supplier - get_invvalidation(+)')
        data = []
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_invoice']
            cursor.execute(query, p_invnum=inv_num,
                           pvendor_id=vendor_id, p_vendor_siteid=site_id,
                           p_org_id=None)
            data = cursor.fetchall()
        except Exception as error:
            logger.findaylog("""@ 1291 EXCEPTION - models - supplier -
                 get_invvalidation """ + str(error))
            raise error
        else:
            if data:
                result['msg'] = "Invoice with number #" + str(inv_num)
                result['msg'] = result['msg'] + " already exists"
                result['status'] = 1
                logger.findaylog("""@ models - supplier 
                - get_invvalidation - """ + result['msg'])
            else:
                result['msg'] = "Invoice with number #" + str(inv_num)
                result['msg'] = result['msg'] + " not exists"
                result['status'] = 0
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_invvalidation(-)')
        return result

    @staticmethod
    def transaction_register(jsond):
        logger.addinfo('@ models - supplier - transaction_register(+)')
        connection = None
        cursor = None
        try:
            p_datef = jsond['from_date']
            p_datet = jsond['to_date']
            cust_accnt = jsond['custaccnt_id']
            trx_num = jsond['trx_number']
            porg = jsond['org_id']
            user_id = jsond['user_id']
            intercompany = jsond.get('intercompany', False)
            customer_ids = []
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if not user_id:
                query = sql_file['tansaction_register']
                if intercompany:
                    query = sql_file['intercompany_transaction_register']
                cursor.execute(query, p_org_id=porg, p_date_from=p_datef,
                               p_date_to=p_datet, p_cust_account_id=cust_accnt,
                               p_trx_number=trx_num)
            else:
                salesid_qry = sql_file['salesrep_ids']
                cursor.execute(salesid_qry, user_id=user_id)
                ids = cursor.fetchall()
                length = len(ids)
                listk = []
                for count in range(length):
                    id = ids[count][0]
                    listk.append(id)
                query_temp = sql_file['new_customer_salesrep_qry']
                salesrep_query = query_temp % (',' . join([":" + str(i)
                                               for i in range(len(listk))]),
                                               porg)
                cursor.execute(salesrep_query, listk)
                fieldnames = [a[0].lower() for a in cursor.description]
                for row in cursor:
                    customer_ids.append(row[1])
                query = sql_file['transaction_register_agents']
                query = query % (',' . join(["'" + str(customer_ids[i]) + "'"
                                 for i in range(len(customer_ids))]),
                                 ',' . join(["'" + str(listk[i]) + "'"
                                            for i in range(len(listk))]))
                cursor.execute(query, p_org_id=porg, p_date_from=p_datef,
                               p_date_to=p_datet, p_trx_number=trx_num)
        except Exception as error:
            logger.findaylog("""@ 1326 EXCEPTION - models - supplier -
                 transaction_register """ + str(error))
            raise error
        else:
            transc_register = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                transc = {}
                for index, fn in enumerate(fieldnames):
                    transc[fn] = row[index]
                transc_register.append(transc)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - transaction_register(-)')
        return transc_register

    @staticmethod
    def attachment_save(jsond):
        logger.addinfo('@ models - supplier - attachment_save(+)')
        connection = None
        cursor = None
        try:
            p_ref_id = jsond['ref_id']
            p_title = jsond['title']
            p_desc = jsond['description']
            p_file_name = jsond['file_name']
            p_content = (jsond['file_blob'])
            if jsond['content_type'] != '':
                p_content_type = jsond['content_type']
            else:
                p_content_type = 'content_type'
            p_entity_name = jsond['entity_name']
            p_category_name = jsond['category_name']
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.setinputsizes(p_blob=cx_Oracle.BLOB)
            return_value = cursor.var(cx_Oracle.STRING)
            cursor.execute(""" declare
            begin
            :retval := qpex_attachments.add_attachment(:pref,
            :ptitle, :pfilename,:pdesc, :p_blob, :pcontent_type,
            :pentity, :pcategory);end;""", pref=p_ref_id, ptitle=p_title,
                           pfilename=p_file_name, pdesc=p_desc,
                           p_blob=p_content, pcontent_type=p_content_type,
                           pentity=p_entity_name,
                           pcategory=p_category_name, retval=return_value)
        except Exception as error:
            logger.findaylog("""@ 1371 EXCEPTION - models - supplier -
                 attachment_save """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - attachment_save(-)')
        return return_value

    @staticmethod
    def allvendor_data(vendor_id, p_org):
        logger.addinfo('@ models - supplier - allvendor_data(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['allvendor_data']
            cursor.arraysize = 1000
            cursor.execute("alter session set nls_language='American'")
            cursor.execute(query, pvendor_id=vendor_id, p_org_id=p_org)
        except Exception as error:
            logger.findaylog("""@ 1394 EXCEPTION - models - supplier -
                 allvendor_data """ + str(error))
            raise error
        else:
            allvendors = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                allvendor = {}
                for index, fn in enumerate(fieldnames):
                    allvendor[fn] = row[index]
                allvendors.append(allvendor)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - allvendor_data(-)')
        return allvendors

    @staticmethod
    def awttax_codes(p_org):
        logger.addinfo('@ models - supplier - awttax_codes(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['awttax_code']
            cursor.execute(query, p_org_id=p_org)
        except Exception as error:
            logger.findaylog("""@ 1423 EXCEPTION - models - supplier -
                 awttax_codes """ + str(error))
            raise error
        else:
            awttax_codes = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                awttax_code = {}
                for index, fn in enumerate(fieldnames):
                    awttax_code[fn] = row[index]
                awttax_codes.append(awttax_code)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - awttax_codes(-)')
        return awttax_codes

    @staticmethod
    def tax_codes(p_org):
        logger.addinfo('@ models - supplier - tax_codes(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['tax_code']
            cursor.execute(query, p_org_id=p_org)
        except Exception as error:
            logger.findaylog("""@ 1452 EXCEPTION - models - supplier -
                 tax_codes """ + str(error))
            raise error
        else:
            awttax_codes = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                tax_code = {}
                for index, fn in enumerate(fieldnames):
                    tax_code[fn] = row[index]
                awttax_codes.append(tax_code)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - tax_codes(-)')
        return awttax_codes

    @staticmethod
    def inv_linesonly_delete(p_invlinenum):
        logger.addinfo('@ models - supplier - inv_linesonly_delete(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supinv_lineonlydelete']
            cursor.execute(query, p_linenum=p_invlinenum)
        except Exception as error:
            logger.findaylog("""@ 1481 EXCEPTION - models - supplier -
                 inv_linesonly_delete """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - inv_linesonly_delete(-)')
        return "success"

    @staticmethod
    def invattach_print(attach_seq):
        logger.addinfo('@ models - supplier - invattach_print(+)')
        connection = None
        cursor = None
        attachments = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("alter session set nls_language='American'")
            cursor.execute(sql_file['supplier_attachment'],
                           p_attachseq=str(attach_seq))
        except Exception as error:
            logger.findaylog("""@ 1505 EXCEPTION - models - supplier -
                 invattach_print """ + str(error))
            raise error
        else:
            attachmentsFn = [a[0].lower() for a in cursor.description]
            for attachment in cursor:
                attachment_data = {}
                for index, fn in enumerate(attachmentsFn):
                    if fn == 'file_data':
                        encoded_string = ''
                        if attachment[index]:
                            if not (Supplier.is_base64(attachment[index].read())):
                                encoded_string = (base64.b64encode(attachment[index].read()))
                            else:
                                encoded_string = (attachment[index].read())
                        attachment_data[fn] = encoded_string.decode('utf-8')
                    else:
                        attachment_data[fn] = attachment[index]
                attachments.append(attachment_data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - invattach_print(-)')
        return attachments

    @staticmethod
    def is_base64(s):
        try:
            return base64.b64encode(base64.b64decode(s)) == s
        except Exception:
            return False

    @staticmethod
    def send_email(jsond):
        logger.addinfo("@ models - supplier - send_email(+)")
        gmail_user = 'support@qualitypeopleit.com'
        gmail_pwd = 'Welcome9'
        msg = ""
        result = ""
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            to = jsond['email_id']
            inv_no = jsond['inv_num']
            if to:
                msg = MIMEMultipart('alternative')
                html_data = """<html>
                      <head></head>
                      <body>
                     <div>
                   <div class="border-template"
                   style="background-color: #ffffff;
                   border-radius: 35px;
                   padding: 30px;
                   margin-left:15%;
                   border: 1px solid #269abc;
                   width: 400px;
                   height: 300px;">
                   <div class="template-header" style="padding-left: 5px;
                  background-color: #3498db;
                  color: #ffffff;font-size: 18px;">
                  <span>Invoice Confiramtion</span></div>
                 <div class="template-body" style="padding-top: 35px;">
                 <span><b style="font-size: 16px;">Invoice created successfully
                    with Invocie # """ + inv_no + """</b>
                 </span></div></div></div></body></html>"""
                msg['subject'] = "Reset Password"
                mesg = (MIMEText(html_data, 'html'))
                msg.attach(mesg)
                smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
                smtpserver.ehlo()
                smtpserver.starttls()
                smtpserver.ehlo
                smtpserver.login(gmail_user, gmail_pwd)
                smtpserver.sendmail(gmail_user, to, msg.as_string())
                smtpserver.quit()
                connection.commit()
                result = 'success'
            else:
                result = 'Invalid User'
                logger.findaylog("""@ models - supplier 
                - send_email - Failed to send email: """ + result)
        except Exception as error:
            logger.findaylog("""@ 218 EXCEPTION - models - supplier -
                 send_email """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - supplier - send_email(-)")
        return result

    @staticmethod
    def invoice_rejection(jsond):
        logger.addinfo('@ models - supplier - invoice_rejection(+)')
        connection = None
        cursor = None
        inv_num = jsond['invoice_num']
        vendor_id = jsond['vendor_id']
        reason = jsond['reason']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_reject_query']
            cursor.execute(query, p_inv_num=inv_num, p_vendor_id=vendor_id,
                           p_reason=reason)
        except Exception as error:
            logger.findaylog("""@ 1452 EXCEPTION - models - supplier -
                invoice_rejection """ + str(error))
            raise error
        else:
            result = 'success'
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - invoice_rejection(-)')
        return result

    @staticmethod
    def invoice_history(seq):
        logger.addinfo('@ models - supplier - invoice_history(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_history_query']
            cursor.execute(query, p_headerseq=seq)
        except Exception as error:
            logger.findaylog("""@ 1635 EXCEPTION - models - supplier -
                 invoice_history """ + str(error))
            raise error
        else:
            return_data = []
            field_names = [a[0].lower() for a in cursor.description]
            for row in cursor:
                data = {}
                for index, fn in enumerate(field_names):
                    data[fn] = row[index]
                return_data.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - invoice_history(-)')
        return return_data

    @staticmethod
    def save_history(history):
        logger.addinfo('@ models - supplier - save_history(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['history_insert_query']
            if history['status'] == 'C':
                creat = ' <span class="inv-created">created</span> the invoice'
                if history['user']:
                    resp = history['user'] + creat
                else:
                    resp = creat
            elif history['status'] == 'N':
                open = ' <span class="inv-opened">re-opened</span> the invoice'
                if history['user']:
                    resp = history['user'] + open
                else:
                    resp = open
            else:
                rej = ' <span class="inv-rejected">rejected</span> the invoice'
                if history['user']:
                    resp = history['user'] + rej
                else:
                    resp = rej
            cursor.execute(query, p_seq=history['seq'],
                           p_response=resp, p_comments=history['comments'],
                           p_approver=history['name'],
                           p_date=history['creation_date'])
        except Exception as error:
            logger.findaylog("""@ 1670 EXCEPTION - models - supplier -
                 save_history """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - save_history(-)')
        return True

    @staticmethod
    def invoice_approve(jsond):
        obj = {}
        logger.addinfo('@ models - supplier - invoice_approve(+)')
        connection = None
        cursor = None
        inv_num = jsond['invoice_num']
        vendor_id = jsond['vendor_id']
        vendor_site_id = jsond['vendor_site_id']
        org_name = jsond['org_name']
        supplier = jsond['supplier']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_approve_query']
            cursor.execute(query, p_inv_num=inv_num, p_vendor_id=vendor_id,
                           p_vendor_site_id=vendor_site_id)

            sql_file = db_util.getusermngSql()
            query = sql_file['accounting_team_query']
            param = 'INVOICE-NOTIFY-' + str(jsond['org_id'])
            cursor.execute(query, p_param=param)
            data = cursor.fetchall()

            strings = db_util.get_strings()
            sub = '(' + org_name + ') FYI: Invoice #' + str(inv_num)
            sub += ' is approved'
            mail_data = {
                'template_id': 309718,
                'subject': sub,
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                }
            }
            if len(data):
                for i in range(len(data)):
                    mail_data['params'] = [
                        {
                            'key': 'username',
                            'value': data[i][2]
                        },
                        {
                            'key': 'supplier_name',
                            'value': supplier
                        },
                        {
                            'key': 'inv_number',
                            'value': inv_num
                        }
                    ]
                    mail_data['recipients'] = [
                        {
                            'Email': data[i][3]
                        }
                    ]
                result = CommonUtils.send_mail(mail_data)
                if result != 'SUCCESS':
                    logger.findaylog("""@ models - supplier - invoice_approve
                     - Failed to send email - {} """.format(mail_data))
        except Exception as error:
            logger.findaylog("""@ 1052 EXCEPTION - models - supplier -
                 invoice_approve """ + str(error))
            raise error
        else:
            obj['status'] = 0
            obj['msg'] = 'Approved'
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - invoice_approve(-)')
        return obj

    @staticmethod
    def po_invoice(po_num):
        logger.addinfo('@ models - supplier - po_invoice(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_po_invoice']
            cursor.execute(query, p_po_num=po_num)
        except Exception as error:
            logger.findaylog("""@ 1788 EXCEPTION - models - supplier -
                 po_invoice """ + str(error))
            raise error
        else:
            invoices = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                invoice = {}
                for index, fn in enumerate(fieldnames):
                    invoice[fn] = row[index]
                invoices.append(invoice)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - po_invoice(-)')
        return invoices

    @staticmethod
    def get_invitations(user_id, status, org_id=None):
        logger.addinfo('@ models - supplier - get_invitations(+)')
        try:
            with OracleConnectionManager() as conn:
                sql_file = db_util.getSqlData()
                query = sql_file['invitations_summary']
                conn.execute(query, p_created_by=user_id,
                             p_status=status,
                             p_org_id=org_id)
                invitations = conn.get_result()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                 get_invitations """ + str(error))
            raise error
        logger.addinfo('@ models - supplier - get_invitations(-)')
        return invitations

    @staticmethod
    def get_supplier_summary(user_id, status):
        logger.addinfo('@ models - supplier - get_supplier_summary(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['suppliers_summary']
            cursor.execute(query, P_CREATED_BY=user_id, P_STATUS=status)
        except Exception as error:
            logger.findaylog("""@ 1845 EXCEPTION - models - supplier -
                 get_supplier_summary """ + str(error))
            raise error
        else:
            summary = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                summary.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_supplier_summary(-)')
        return summary

    @staticmethod
    def get_vendor_details(vendor_id):
        logger.addinfo('@ models - supplier - get_vendor_details(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            # get vendor details
            query = sql_file['vendor_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            result = {}
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
            # get vendor site details
            query = sql_file['vendor_site_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            sites = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                site = {}
                for index, fn in enumerate(fieldnames):
                    site[fn] = row[index]
                sites.append(site)
            result['sites'] = sites
            # get vendor contacts
            query = sql_file['vendor_contacts_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            contacts = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                contact = {}
                for index, fn in enumerate(fieldnames):
                    contact[fn] = row[index]
                contacts.append(contact)
            result['contacts'] = contacts
            # get vendor bank accounts
            query = sql_file['vendor_bank_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            accounts = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                account = {}
                for index, fn in enumerate(fieldnames):
                    account[fn] = row[index]
                accounts.append(account)
            result['bank_details'] = accounts
            # get vendor attachments
            query = sql_file['vendor_attachment_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            attachments = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                attachment = {}
                for index, fn in enumerate(fieldnames):
                    attachment[fn] = row[index]
                attachments.append(attachment)
            result['attachments'] = attachments
        except Exception as error:
            logger.findaylog("""@ 1925 EXCEPTION - models - supplier -
                 get_vendor_details """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_vendor_details(-)')
        return result

    @staticmethod
    def approve_supplier(supplier_id):
        logger.findaylog('@models - supplier - approve_supplier(+)', send_email=False)
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_client_suppliers_pkg.approve_supplier(
                        :p_supplier_id,
                        :p_status_code
                    );
                end; """, p_supplier_id=supplier_id,
                             p_status_code=status_code)
                status = status_code.getvalue()

            if status == 'SUCCESS':
                email_status = Supplier.update_hubspot_contact(
                    supplier_id, 'send_vendor_welcome_email')
                if not email_status.get('contact_id'):
                    status = 'Failure - Failed to send email to supplier.'

                sql_file = db_util.getSqlData()
                strings = db_util.get_strings()
                # roles for accounting team and treasury
                roles = ['UI-SUPPLIER-APPROVER-{}', 'UI-TREASURY-{}']
                bcc_list = []
                with OracleConnectionManager() as conn:
                    # get supplier and invited person details
                    query = sql_file['get_invited_supplier_details']
                    conn.execute(query, p_vendor_id=supplier_id)
                    data = conn.get_result()[0]

                    # get accounting and treasury details
                    query = sql_file['supplier_notify_internal_users_query']
                    org_id = data.get('default_org_id') or 82
                    query %= ','.join(["'UI-TREASURY'"] + ["'%s'" %
                                      role.format(org_id) for role in roles])
                    conn.execute(query)
                    users = conn.get_result()
                    for user in users:
                        bcc_list.append(user.get('email_address'))

                if data:
                    #  Email to invited user after supplier is approved by accounting team
                    mail_data = {
                        'template_id': 1143028,
                        'subject': strings['supplier_approval_to_user'],
                        'params': [
                            {
                                'key': 'user_name',
                                'value': data['invited_user']
                            },
                            {
                                'key': 'supplier_name',
                                'value': data['supplier_name']
                            }
                        ],
                        'recipients': [
                            {
                                'Email': data['invited_user_email'],
                                'Name': data['invited_user']
                            }
                        ],
                        'bcc': ','.join(bcc_list)
                    }
                    common_utils = CommonUtils()
                    result = common_utils.send_mail(mail_data)
                    if result != 'SUCCESS':
                        status += 'Failure - Failed to send email to user'
                        logger.findaylog(
                            '@models - supplier - approve_supplier - {} '.format(mail_data))
            else:
                logger.findaylog("""@ models - supplier - approve_supplier
                 - Failed to approve supplier with id: """ + str(supplier_id))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                approve_supplier """ + str(error))
            raise error
        logger.findaylog('@models - supplier - approve_supplier(-)', send_email=False)
        return status

    @staticmethod
    def reject_supplier(data):
        logger.findaylog('@models - supplier - reject_supplier(+)', send_email=False)
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_client_suppliers_pkg.reject_supplier(
                        :p_supplier_id,
                        :p_status_code
                    );
                end; """, p_supplier_id=data['supplier_id'],
                             p_status_code=status_code)
                status = status_code.getvalue()
            if status == 'SUCCESS':
                email_status = Supplier.update_hubspot_contact(data['supplier_id'],
                                                               'send_vendor_reject_email',
                                                               data['email_id'])
                if not email_status.get('contact_id'):
                    status = 'Failure - Failed to sent email'
            else:
                logger.findaylog("""@ models - supplier 
                - reject_supplier - failed to reject supplier """)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                reject_supplier """ + str(error))
            raise error
        logger.findaylog('@models - supplier - reject_supplier(-)', send_email=False)
        return status

    @staticmethod
    def get_currencies(org_id):
        logger.addinfo('@ models - supplier - get_currencies(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['currency_query']
            cursor.execute(query, P_ORG_ID=org_id)
        except Exception as error:
            logger.findaylog("""@ 2041 EXCEPTION - models - supplier -
                 get_currencies """ + str(error))
            raise error
        else:
            currencies = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                currencies.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_currencies(-)')
        return currencies

    @staticmethod
    def get_paymentterms():
        logger.addinfo('@ models - supplier - get_paymentterms(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['payment_terms_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 2070 EXCEPTION - models - supplier -
                 get_paymentterms """ + str(error))
            raise error
        else:
            terms = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                terms.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_paymentterms(-)')
        return terms

    @staticmethod
    def get_classifications():
        logger.addinfo('@models - supplier - get_classifications(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_classifications_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 2098 EXCEPTION - models - supplier -
                get_classifications """ + str(error))
            raise error
        else:
            classifications = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                classifications.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_classifications(-)')
        return classifications

    @staticmethod
    def insert_classification(data):
        logger.addinfo('@ models - supplier - insert_classification(+)')
        connection = None
        cursor = None
        id = data['classification_id']
        code = data['classification_code']
        desc = data['description']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['insert_classifications_query']
            cursor.execute(query, p_CLASSIFICATION_ID=id,
                           p_CLASSIFICATION_CODE=code, p_DESCRIPTION=desc)
        except Exception as error:
            logger.findaylog("""@ 2133 EXCEPTION - models - supplier -
                insert_classification""" + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - insert_classification(-)')
        return "success"

    @staticmethod
    def update_classification(data):
        logger.addinfo('@ models - supplier - update_classification(+)')
        connection = None
        cursor = None
        id = data['classification_id']
        code = data['classification_code']
        desc = data['description']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['update_classification_query']
            cursor.execute(query, p_CLASSIFICATION_ID=id,
                           p_CLASSIFICATION_CODE=code, p_DESCRIPTION=desc)
        except Exception as error:
            logger.findaylog("""@ 2162 EXCEPTION - models - supplier -
                update_classification """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - update_classification(-)')
        return 'success'

    @staticmethod
    def delete_classification(classification_id):
        logger.addinfo('@ models - supplier - delete_classification(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['delete_classification_query']
            cursor.execute(query, p_id=classification_id)
        except Exception as error:
            logger.findaylog("""@ 2188 EXCEPTION - models - supplier -
                delete_classification """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - delete_classification(-)')
        return 'success'

    @staticmethod
    def get_suppliertypes():
        logger.addinfo('@ models - supplier - get_suppliertypes(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['supplier_type_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 2203 EXCEPTION - models - supplier -
                 get_suppliertypes """ + str(error))
            raise error
        else:
            types = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                types.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_suppliertypes(-)')
        return types

    @staticmethod
    def get_vendor_attachment(id):
        logger.addinfo('@ models - supplier - get_vendor_attachment(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['vendor_attachment_data']
            cursor.execute(query, P_ATTACHMENT_ID=id)
        except Exception as error:
            logger.findaylog("""@ 2252 EXCEPTION - models - supplier -
                 get_vendor_attachment """ + str(error))
            raise error
        else:
            data = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = CommonUtils.encode_base64(row[index].read()).decode('utf-8')
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_vendor_attachment(-)')
        return data

    @staticmethod
    def send_mail(invoice_num, s_name, email, header_seq, org_name, jsond):
        logger.findaylog('@models - supplier - send_mail(+)', send_email=False)
        connection = None
        cursor = None
        attachments = None
        try:
            status = ''
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_attachment_query']
            cursor.execute(query, p_attachseq=header_seq)
            row = cursor.fetchone()
            if row:
                attachments = [{
                    'file_type': row[2],
                    'file_name': row[0],
                    'file_data': get_base64_attachment(row[1].read())
                }]
            template = get_inv_template(jsond['invoice_num'],
                                        jsond['vendor_id'],
                                        jsond['vendor_site_id'])
            strings = db_util.get_strings()
            sub = '(' + org_name + ') Invoice' + str(invoice_num)
            sub = sub + ' without a PO by ' + str(s_name)
            mail_data = {
                'template_id': 265137,
                'subject': sub,
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                },
                'params': [
                    {
                        'key': 'supplier_name',
                        'value': s_name
                    },
                    {
                        'key': 'invoice_num',
                        'value': invoice_num
                    },
                    {
                        'key': 'invoice_content',
                        'value': template
                    }
                ],
                'recipients': [
                    {
                        'Email': email
                    }
                ]
            }
            if attachments:
                mail_data['attachments'] = attachments
            result = CommonUtils.send_mail(mail_data)
            if result != 'SUCCESS':
                status = 'Failure - Failed to send email'
                logger.findaylog("""@models - supplier 
                - send_mail - Failed to send email {} """.format(mail_data))
            else:
                status = 'success'
        except Exception as error:
            logger.findaylog("""@ 1965 EXCEPTION - models - supplier -
                send_mail """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.findaylog('@models - supplier - send_mail(-)', send_email=False)
        return status

    @staticmethod
    def send_notification(org_id, supplier, invoice_num, header_seq,
                          po_receive, org_name, jsond):
        logger.findaylog('@models - supplier - send_notification(+)', send_email=False)
        connection = None
        cursor = None
        attachments = None
        row = None
        try:
            strings = db_util.get_strings()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getusermngSql()
            query = sql_file['accounting_team_query']
            param = 'ACCOUNTING-TEAM-' + str(org_id)
            cursor.execute(query, p_param=param)
            data = cursor.fetchall()
            if len(data):
                row = data[0]

            cursor.execute(query, p_param='INVOICE-CC')
            cc_data = cursor.fetchall()
            cc = None
            if len(cc_data):
                cc = ''
                for i in range(len(cc_data)):
                    cc += cc_data[i][2] + '<' + cc_data[i][3] + '>,'
                cc = cc[:-1]

            if header_seq:
                sql_file = db_util.getSqlData()
                query = sql_file['invoice_attachment_query']
                cursor.execute(query, p_attachseq=header_seq)
                attachment = cursor.fetchone()
                if attachment:
                    attachments = [{
                        'file_type': attachment[2],
                        'file_name': attachment[0],
                        'file_data': get_base64_attachment(attachment[1].read())
                    }]
            if jsond:
                template = get_inv_template(jsond['invoice_num'],
                                            jsond['vendor_id'],
                                            jsond['vendor_site_id'])
            else:
                template = ""
            temp_id = ''
            if po_receive == 'Y':
                # temp_id = 244108
                temp_id = 265140    # Invoice No PO Receive Copy
            else:
                # temp_id = 107423
                temp_id = 265139    # PO Notification Copy
            sub = '(' + org_name + ') ' + strings['po_notification_mail']
            sub += ' for Invoice #' + invoice_num
            mail_data = {
                'template_id': temp_id,
                'subject': sub,
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                },
                'recipients': [
                    {
                        'Email': row[3],
                        'Name': row[2]
                    }
                ],
                'params': [
                    {
                        'key': 'user_name',
                        'value': row[2]
                    },
                    {
                        'key': 'vendor',
                        'value': supplier
                    },
                    {
                        'key': 'invoice_num',
                        'value': invoice_num
                    },
                    {
                        'key': 'invoice_content',
                        'value': template
                    }
                ]
            }
            if cc:
                mail_data['cc'] = cc
            if attachments:
                mail_data['attachments'] = attachments
            result = CommonUtils.send_mail(mail_data)
            if result != 'SUCCESS':
                status = 'Failure - Failed to send email'
                logger.findaylog("""@models - supplier 
                - send_notification - Failed to send email {} """.format(mail_data))
            else:
                status = 'SUCCESS'
        except Exception as error:
            logger.findaylog("""@ 2399 EXCEPTION - models - supplier -
                send_notification """ + str(error))
            raise error
        logger.findaylog('@models - supplier - send_notification(-)', send_email=False)
        return status

    @staticmethod
    def creator_approval(jsond):
        logger.addinfo('@models - supplier - creator_approval(+)')
        try:
            org_id = jsond['org_id']
            with OracleConnectionManager() as conn:
                sql_file = db_util.getSqlData()
                query = sql_file['supplier_created_mail']
                conn.execute(query, P_SUPPLIER_ID=jsond['supplier_id'])
                invitation_details = conn.get_single_result()
                if invitation_details:
                    org_id = invitation_details['default_org_id']

                query = sql_file['org_name_query']
                conn.execute(query, p_org_id=org_id)
                org = conn.get_result()[0]['name']

                sql_file = db_util.getusermngSql()
                query = sql_file['accounting_team_query']
                conn.execute(query, p_param='UI-SUPPLIER-APPROVER-{}'.format(org_id))
                data = conn.get_result()

            if data:
                row = data[0]

                if row['ui_language'] == 'IT':
                    tid = 107440  # Supplier Pending Approval IT
                elif row['ui_language'] == 'FR':
                    tid = 107438  # Supplier Pending Approval FR
                elif row['ui_language'] == 'DE':
                    tid = 107439  # Supplier Pending Approval DE
                elif row['ui_language'] == 'EN':
                    tid = 107442  # Supplier Pending Approval
                else:
                    tid = 107442  # Supplier Pending

                strings = db_util.get_strings()

                result = CommonUtils.send_mail({
                    'template_id': tid,
                    'subject': strings['accounting_team_approval'].format(
                        org, jsond['supplier_name'].encode('utf-8')),
                    'params': [
                        {
                            'key': 'supplier_name',
                            'value': jsond['supplier_name']
                        },
                        {
                            'key': 'username',
                            'value': row['user_description']
                        },
                        {
                            'key': 'approver_name',
                            'value': jsond['approver_name']
                        },
                        {
                            'key': 'vendor_id',
                            'value': jsond['supplier_id']
                        }
                    ],
                    'recipients': [
                        {
                            'Email': row['email_address']
                        }
                    ]
                })

                if result != 'SUCCESS':
                    logger.findaylog(
                        '@ models - supplier - creator_approval - Error while approving')
                else:
                    with OracleConnectionManager() as conn:
                        sql_file = db_util.getSqlData()
                        query = sql_file['update_supplier_approver']
                        conn.execute(query, p_approver=row['user_id'],
                                     p_vendor_id=jsond['supplier_id'])
            else:
                result = 'No approver found for {} organisation'.format(org)
                logger.findaylog('@ models - supplier - creator_approval ' + result)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                creator_approval """ + str(error))
            raise error
        logger.addinfo('@models - supplier - creator_approval(-)')
        return result

    @staticmethod
    def get_existing_suppliers():
        logger.addinfo('@ models - supplier - get_existing_suppliers(+)')
        connection = None
        cursor = None
        result = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['existing_suppliers_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 2532 EXCEPTION - models - supplier -
                get_existing_suppliers """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                obj = {}
                for index, fn in enumerate(fieldnames):
                    obj[fn] = row[index]
                result.append(obj)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_existing_suppliers(-)')
        return result

    @staticmethod
    def receive_po(jsond):
        logger.addinfo('@ models - supplier - receive_po')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.execute("""
                begin
                    qpex_procurement_pkg.autocreate_receipts(:p_document_id);
                end; """, p_document_id=jsond['po_header_id'])
        except Exception as error:
            logger.findaylog("""@ 2564 EXCEPTION - models - supplier -
                receive_po """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - receive_po')
        return 'SUCCESS'

    @staticmethod
    def request_cn(jsond):
        logger.findaylog('@models - supplier - request_cn(+)', send_email=False)
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['vendor_email_query']
            cursor.execute(query, p_vendor_id=jsond['vendor_id'],
                           p_vendor_site_id=jsond['vendor_site_id'])
            user = cursor.fetchone()
            if user:
                strings = db_util.get_strings()
                mail_data = {
                    'template_id': 117998,
                    'subject': strings['request_creditnote'],
                    'sender': {
                        'email': strings['sender_email'],
                        'name': strings['sender_name']
                    },
                    'params': [
                        {
                            'key': 'supplier_name',
                            'value': jsond['supplier_name']
                        },
                        {
                            'key': 'message',
                            'value': jsond['message']
                        }
                    ],
                    'recipients': [
                        {
                            'Email': user[0]
                        }
                    ]
                }
                result = CommonUtils.send_mail(mail_data)
                if result != 'SUCCESS':
                    status = 'ERROR'
                    logger.findaylog("""@ models - supplier 
                    - request_cn - Failed to send email {} """.format(mail_data))
                else:
                    status = 'SUCCESS'
            else:
                status = 'NO EMAIL'
                logger.findaylog("""@ models - supplier 
                                    - request_cn - No email address for supplier""")
        except Exception as error:
            logger.findaylog("""@ 2614 EXCEPTION - models - supplier -
                request_cn """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.findaylog('@models - supplier - request_cn(-)', send_email=False)
        return status

    @staticmethod
    def receive_po_lines(jsond):
        logger.addinfo('@ models - supplier - receive_po_lines')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            for line in jsond:
                cursor.execute("""
                    begin
                        qpex_procurement_pkg.autocreate_receipts(
                        :p_document_id,
                        :p_line_id,
                        :p_qty);
                    end; """, p_document_id=line['po_header_id'],
                               p_line_id=line['po_line_id'],
                               p_qty=line['quantity'])
                query = db_util.getSqlData()['update_po_header_query']
                cursor.execute(query, p_receive_flag=line['receive_flag'],
                               p_po_header_id=line['po_header_id'],
                               p_po_line_id=line['po_line_id'])
        except Exception as error:
            logger.findaylog("""@ 2643 EXCEPTION - models - supplier -
                receive_po_lines """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - receive_po_lines')
        return 'SUCCESS'

    @staticmethod
    def validate_po(po_header_id, po_line_id):
        logger.addinfo('@ models - supplier - validate_po')
        connection = None
        cursor = None
        invoices = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['po_validate_query']
            cursor.execute(query, p_po_header_id=po_header_id,
                           p_po_line_id=po_line_id)
        except Exception as error:
            logger.findaylog("""@ 2665 EXCEPTION - models - supplier -
                validate_po """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                invoices.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - validate_po')
        return invoices

    @staticmethod
    def get_gl_details(po_header_id, po_line_id):
        logger.addinfo('@ models - supplier - get_gl_details')
        connection = None
        cursor = None
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['po_gl_account_query']
            cursor.execute(query, p_po_header_id=po_header_id,
                           p_po_line_id=po_line_id)
        except Exception as error:
            logger.findaylog("""@ 2698 EXCEPTION - models - supplier -
                get_gl_details """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_gl_details')
        return data

    @staticmethod
    def ask_to_receive(jsond):
        logger.addinfo('@models - supplier - ask_to_receive(+)')
        status = ''
        connection = None
        cursor = None
        attachments = None
        try:
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            # receive PO guide
            guide_path = path + '/static/po_receive_guide.pdf'
            guide = open(guide_path, 'r')
            pdf_guide = base64.b64encode(guide.read())

            # create PO guide
            guide_path = path + '/static/create_po_guide.pdf'
            guide = open(guide_path, 'r')
            po_guide = base64.b64encode(guide.read())

            strings = db_util.get_strings()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            if jsond['header_seq']:
                sql_file = db_util.getSqlData()
                query = sql_file['invoice_attachment_query']
                cursor.execute(query, p_attachseq=jsond['header_seq'])
                attachment = cursor.fetchone()
                if attachment:
                    attachments = [{
                        'file_type': attachment[2],
                        'file_name': attachment[0],
                        'file_data': get_base64_attachment(attachment[1].read())
                    }]
            if not attachments:
                attachments = []
            # adding PO receiving user guide
            attachments.append({
                'file_type': 'application/pdf',
                'file_name': 'PO Receiving Process.pdf',
                'file_data': pdf_guide
            })
            # adding create PO user guide
            attachments.append({
                'file_type': 'application/pdf',
                'file_name': 'Create PO Guide.pdf',
                'file_data': po_guide
            })
            if jsond['type'] == 'INV':
                template = get_inv_template(jsond['invoice_num'],
                                            jsond['vendor_id'],
                                            jsond['vendor_site_id'])
            else:
                template = get_po_template(jsond['header'], jsond['lines'])
            sub = '(' + jsond['org_name'] + ') ' + jsond['subject']
            mail_data = {
                'template_id': 297607,
                'subject': sub,
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                },
                'params': [
                    {
                        'key': 'message',
                        'value': jsond['message']
                    },
                    {
                        'key': 'user_name',
                        'value': jsond['name']
                    },
                    {
                        'key': 'invoice_content',
                        'value': template
                    }
                ],
                'recipients': [
                    {
                        'Email': jsond['email_address']
                    }
                ]
            }
            if jsond['cc_email']:
                mail_data['cc'] = jsond['cc_email']
            if attachments:
                mail_data['attachments'] = attachments
            result = CommonUtils.send_mail(mail_data)
            if result != 'SUCCESS':
                status = 'Failure - Failed to send email'
                logger.findaylog("""@ models - supplier 
                - ask_to_receive - Failed to send email {}""".format(mail_data))
            else:
                status = 'SUCCESS'
        except Exception as error:
            logger.findaylog("""@ 3081 EXCEPTION - models - supplier -
                ask_to_receive """ + str(error))
            raise error
        logger.addinfo('@models - supplier - ask_to_receive(-)')
        return status

    @staticmethod
    def get_invoice_type(jsond):
        logger.addinfo('@ models - supplier - get_invoice_type(+)')
        connection = None
        cursor = None
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_type_query']
            cursor.execute(query, p_invoice_date=jsond['invoice_date'],
                           p_org_id=jsond['org_id'])
        except Exception as error:
            logger.findaylog("""@ 2868 EXCEPTION - models - supplier -
                get_invoice_type """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_invoice_type(-)')
        return data

    @staticmethod
    def send_approval_mail(jsond, is_accounting):
        logger.addinfo('@ models - supplier - send_approval_mail(+)')
        connection = None
        cursor = None
        status = None
        attachments = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getusermngSql()
            query = sql_file['accounting_team_query']
            if is_accounting:
                param = 'ACCOUNTING-TEAM-' + str(jsond['org_id'])
                cursor.execute(query, p_param=param)
            else:
                cursor.execute(query, p_param='INVOICE-APPROVER')
            row = cursor.fetchone()
            if row is None:
                status = 'Failed to send email - No Approver found'
                logger.findaylog("""@ models - supplier 
                - send_approval_mail """ + status)
            else:
                sql_file = db_util.getSqlData()
                query = sql_file['invoice_attachment_query']
                cursor.execute(query, p_attachseq=jsond['header_seq'])
                attachment = cursor.fetchone()
                if attachment:
                    attachments = [{
                        'file_type': attachment[2],
                        'file_name': attachment[0],
                        'file_data': get_base64_attachment(attachment[1].read())
                    }]
                template = get_inv_template(jsond['invoice_num'],
                                            jsond['vendor_id'],
                                            jsond['vendor_site_id'])
                strings = db_util.get_strings()
                sub = '(' + jsond['org_name'] + ') '
                sub += 'Invoice #' + str(jsond['invoice_num'])
                sub += ' is ready for approval'
                params = {}
                params['inv'] = jsond['invoice_num']
                params['vid'] = jsond['vendor_id']
                params['vsid'] = jsond['vendor_site_id']
                params['sup'] = jsond['supplier_name']
                params['org'] = jsond['org_name']
                params['oid'] = jsond['org_id']
                mail_data = {
                    'template_id': 261669,
                    'subject': sub,
                    'sender': {
                        'email': strings['sender_email'],
                        'name': strings['sender_name']
                    },
                    'params': [
                        {
                            'key': 'invoice_num',
                            'value': jsond['invoice_num']
                        },
                        {
                            'key': 'supplier_name',
                            'value': jsond['supplier_name']
                        },
                        {
                            'key': 'invoice_content',
                            'value': template
                        },
                        {
                            'key': 'params',
                            'value': urllib.parse.urlencode(params)
                        }
                    ],
                    'recipients': [
                        {
                            'Email': row[3]
                        }
                    ]
                }
                if attachments:
                    mail_data['attachments'] = attachments
                result = CommonUtils.send_mail(mail_data)
                if result != 'SUCCESS':
                    status = 'Failure - Failed to send email to approver'
                    logger.findaylog("""@ models - supplier - send_approval_mail
                     - Failed to send email - {}""".format(mail_data))
                else:
                    status = 'success'
        except Exception as error:
            logger.findaylog("""@ 2937 EXCEPTION - models - supplier -
                send_approval_mail """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - send_approval_mail(-)')
        return status

    @staticmethod
    def get_po_lines(po_header_id):
        logger.addinfo('@ models - supplier - get_po_lines(+)')
        connection = None
        cursor = None
        lines_details = []
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['po_headers_query']
            cursor.execute(query, p_po_header_id=po_header_id)
            cursor.arraysize = 1000
            obj = {}
            if po_header_id:
                lines_details = Supplier.load_po_lines(po_header_id)
                obj['lines'] = lines_details
            fieldnames = [a[0].lower() for a in cursor.description]
            header_details = []
            for row in cursor:
                header = {}
                for index, fn in enumerate(fieldnames):
                    header[fn] = row[index]
                header_details.append(header)
            obj['header'] = header_details
        except Exception as error:
            logger.findaylog("""@ 3001 EXCEPTION - models - supplier -
                 get_po_lines """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_po_lines(-)')
        return obj

    @staticmethod
    def load_po_lines(po_header_id):
        logger.addinfo('@ models - supplier - load_po_lines(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['inv_po_lines_query']
            cursor.execute(query, p_po_header_id=po_header_id)
        except Exception as error:
            logger.findaylog("""@ 3020 EXCEPTION - models - supplier -
                 po_lines """ + str(error))
            raise error
        else:
            inv_lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                inv_line = {}
                for index, fn in enumerate(fieldnames):
                    inv_line[fn] = row[index]
                inv_lines.append(inv_line)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - load_po_lines(-)')
        return inv_lines

    @staticmethod
    def get_ca_taxcodes():
        logger.addinfo('@ models - supplier - get_ca_taxcodes(+)')
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['taxcodes_ca_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 3244 EXCEPTION - models - supplier -
                get_ca_taxcodes """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                code = {}
                for index, fn in enumerate(fieldnames):
                    code[fn] = row[index]
                data.append(code)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_ca_taxcodes(+)')
        return data

    @staticmethod
    def get_payment_templates(org_id):
        logger.addinfo('@ models - supplier - get_payment_templates(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['payment_templates_query']
            cursor.execute(query, p_org_id=org_id)
            data = Code_util.iterate_data(cursor)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - supplier -
                get_payment_templates """ + str(e))
            raise e
        finally:
            if cursor:
                cursor.close()
            if connection:
                db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - get_payment_templates(-)')
        return data

    @staticmethod
    def update_invoice_approver(req):
        '''
        change the approve details for the invoice
        '''
        logger.addinfo('@ models - supplier - update_invoice_approver(+)')
        connection = None
        cursor = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            assigned_to = cursor.var(cx_Oracle.STRING)
            assigned_by = cursor.var(cx_Oracle.STRING)
            assigned_to_email = cursor.var(cx_Oracle.STRING)
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute('''
            begin
                qpex_supplier_pkg.update_invoice_approver(
                    :p_invoice_num,
                    :p_vendor_id,
                    :p_vendor_site_id,
                    :p_assigned_to,
                    :p_assigned_by,
                    :p_action,
                    :x_assigned_to_name,
                    :x_assigned_by_name,
                    :x_assigned_to_email,
                    :x_status_code
                );
            end; ''', p_invoice_num=req['invoice_num'],
                           p_vendor_id=req['vendor_id'],
                           p_vendor_site_id=req['vendor_site_id'],
                           p_assigned_to=req['assigned_to'],
                           p_assigned_by=req['assigned_by'],
                           p_action=req['action'],
                           x_assigned_to_name=assigned_to,
                           x_assigned_by_name=assigned_by,
                           x_assigned_to_email=assigned_to_email,
                           x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Invoice assigned to {0} successfully'.format(assigned_to.getvalue())
                }

                # send email to the assignee informing that the invoice is
                # assigned for his review
                subject = '{0} assigned invoice no.{1} for your review'\
                    .format(assigned_by.getvalue(), req['invoice_num'])

                status = CommonUtils.send_mail({
                    'template_id':  1021191,
                    'subject': subject,
                    'params': [
                        {
                            'key': 'user_name',
                            'value': assigned_to.getvalue()
                        },
                        {
                            'key': 'assigned_by',
                            'value': assigned_by.getvalue()
                        },
                        {
                            'key': 'invoice_num',
                            'value': req['invoice_num']
                        },
                        {
                            'key': 'action',
                            'value': req['action']
                        },
                        {
                            'key': 'vendor_id',
                            'value': req['vendor_id']
                        },
                        {
                            'key': 'vendor_site_id',
                            'value': req['vendor_site_id']
                        }
                    ],
                    'to_email': assigned_to_email.getvalue(),
                    'to_name': assigned_to.getvalue()
                })
                if status != 'SUCCESS':
                    # failed to send email
                    result['msg'] += '. Failed to send email to {0}'\
                        .format(assigned_to.getvalue())
            else:
                result = {
                    'status': 1,
                    'msg': 'Failed to assign invoice to {0}'.format(assigned_to.getvalue())
                }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - supplier -
                update_invoice_approver ''' + str(error))
            raise error
        finally:
            if cursor:
                connection.commit()
                cursor.close()
                db_util.release_connection(connection)
        logger.addinfo('@ models - supplier - update_invoice_approver(-)')
        return result

    @staticmethod
    def get_invoice_users():
        logger.addinfo('@ models - supplier - get_invoice_users(+)')
        users = []
        try:
            with OracleConnectionManager() as conn:
                sql_file = db_util.getSqlData()
                query = sql_file["get_all_invoice_employees"]
                conn.execute(query)
                users = conn.get_result()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                    get_invoice_users """ + str(error))
            raise error
        logger.addinfo('@ models - supplier - get_invoice_users(-)')
        return users

    @staticmethod
    def get_invited_supplier_details(supplier_id):
        logger.addinfo('@ models - supplier - get_invited_supplier_details(+)')
        try:
            with OracleConnectionManager() as conn:
                sql_file = db_util.getSqlData()
                query = sql_file["get_invited_supplier_details"]
                conn.execute(query, p_vendor_id=supplier_id)
                data = conn.get_result()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                    get_invited_supplier_details """ + str(error))
            raise error
        logger.addinfo('@ models - supplier - get_invited_supplier_details(-)')
        return data

    @staticmethod
    def update_hubspot_contact(supplier_id, workflow, support_email=None):
        logger.addinfo('@ models - supplier - update_hubspot_contact(+)')
        try:
            invited_data = Supplier.get_invited_supplier_details(supplier_id)
            sql_file = db_util.getSqlData()
            personas = sql_file['supplier_persona_map']
            persona = personas.get(invited_data[0]['country'], 'persona_48')

            # Send rejected to invited supplier from hubspot
            props = {
                'vendor_name': invited_data[0]['supplier_name'],
                'firstname': invited_data[0]['first_name'],
                'lastname': invited_data[0]['last_name'],
                'email': invited_data[0]['email_address'],
                'cruscott_username': invited_data[0]['user_name'],
                'hs_persona': persona,
                'country': invited_data[0].get('country', ''),
                'vendor_support_email': support_email or '',
                'vendor_workflow': workflow
            }

            cms_obj = CMS()
            result = cms_obj.create_contact(props)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                    update_hubspot_contact """ + str(error))
            raise error
        logger.addinfo('@ models - supplier - update_hubspot_contact(-)')
        return result


def get_inv_template(inv_num, vendor_id, site_id):
    logger.addinfo('@ models - supplier - get_inv_template(+)')
    template = None
    try:
        result = Supplier.supplier_invoice(inv_num, vendor_id, site_id)
        res = ujson.loads(ujson.dumps(result))
        path = os.path.join(os.path.dirname(__file__))
        template = jinja2.Environment(
            loader=jinja2.FileSystemLoader(path)
        ).get_template('invoice.html').render(
            supplier=res[0]['vendor_name'],
            address1=res[0]['address_line1'],
            address2=res[0]['address_line2'],
            city=res[0]['city'],
            country=res[0]['country'],
            zip=res[0]['zip'],
            tax_num=res[0]['num_1099'],
            vat_num=res[0]['vat_registration_num'],
            invoice_num=res[0]['invoice_num'],
            invoice_date=res[0]['invoice_date'],
            gl_date=res[0]['gl_date'],
            invoice_total=res[0]['invoice_amount'],
            currency=res[0]['invoice_currency_code'],
            payment_term=res[0]['term_name'],
            invoice_type=res[0]['invoice_type_code'],
            notes=res[0]['description'],
            lines=res[0]['lines'])
    except Exception as error:
        logger.findaylog("""@ 3302 EXCEPTION - models - supplier -
            get_inv_template """ + str(error))
        raise error
    logger.addinfo('@ models - supplier - get_inv_template(-)')
    return template


def get_po_template(header, lines):
    logger.addinfo('@ models - supplier - get_po_template(+)')
    template = None
    history = None
    try:
        if header['po_header_id']:
            procurement_obj = Procurement()
            history = procurement_obj.get_history(header['po_header_id'])
        path = os.path.join(os.path.dirname(__file__))
        template = jinja2.Environment(
            loader=jinja2.FileSystemLoader(path)
        ).get_template('po_details.html').render(
            supplier=header['vendor_name'],
            address1=header['address_line1'],
            address=header['address_line2'],
            city=header['city'],
            country=header['country'],
            zip=header['zip'],
            creation_date=header['creation_date'],
            po_amount=header['po_amount'],
            status=header['status'],
            quantity=header['quantity'],
            authorization_status=header['authorization_status'],
            quantity_billed=header['quantity_billed'],
            approved_date=header['approved_date'],
            quantity_received=header['quantity_received'],
            lines=lines,
            history=history)
    except Exception as error:
        logger.findaylog("""@ 3350 EXCEPTION - models - supplier -
            get_po_template """ + str(error))
        raise error
    logger.addinfo('@ models - supplier - get_po_template(-)')
    return template


def getSuppliersByOrg(query, org_id):
    logger.addinfo('@ models - supplier - getSuppliersByOrg(+)')
    cur = None
    con = None
    sqlFile = db_util.getSqlData()
    query = sqlFile[query]
    try:
        con = db_util.get_connection()
        cur = con.cursor()
        cur.arraysize = 1000
        cur.execute(query, p_org_id=org_id)
    except Exception as error:
        logger.findaylog("""@ 2042 EXCEPTION - models - supplier -
             getSuppliersByOrg """ + str(error))
        raise error
    else:
        suppliers = []
        fieldnames = [a[0].lower() for a in cur.description]
        for row in cur:
            supplier = {}
            for index, fn in enumerate(fieldnames):
                supplier[fn] = row[index]
            suppliers.append(supplier)
    finally:
        cur.close()
        db_util.release_connection(con)
    logger.addinfo('@ models - supplier - getSuppliersByOrg(-)')
    return suppliers


def get_base64_attachment(attachment):
    if Supplier.is_base64(attachment):
        encoded_string = attachment
    else:
        encoded_string = base64.b64encode(attachment)
    return encoded_string
