import base64
import ujson

import cx_Oracle
from finapi.models.pob.pob import POB
from finapi.sql import sql_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.constants import Status
from finapi.utils.logdata import logger
from finapi.models.cms.cms import CMS
from finapi.utils import db_util
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('privacyconsent')
class PrivacyConsent:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    @staticmethod
    def get_persona_lov():
        cms_obj = CMS()
        result = cms_obj.get_persona_lov()
        return result['options']

    def insert_privacy_details(self, privacy_data):
        """
            to insert privacy consent details
        :param privacy_data: {
                'first_name':'',
                'last_name':'',
                'email_address':'',
                'persona':'',
                'created_by':'',
                'attachments':[],
                'org_id':'',
                'language':'',
                'history_description':''
                }

        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            privacy_id = conn.set_output_param('NUMBER')
            status = 'P'
            conn.execute("""
                        begin
                            qpex_privacy_consent_pkg.insert_privacy_consent(
                            :x_privacy_id,
                            :p_first_name,
                            :p_last_name,
                            :p_email_address,
                            :p_persona,
                            :p_video_url,
                            :p_email_status,
                            :p_created_by,
                            :p_org_id,
                            :p_language,
                            :x_status_code
                            );
                        end;
                        """,
                         output_key='x_status_code',
                         x_privacy_id=privacy_id,
                         p_first_name=privacy_data['first_name'],
                         p_last_name=privacy_data['last_name'],
                         p_email_address=privacy_data['email_address'],
                         p_persona=privacy_data['persona'],
                         p_video_url=privacy_data['video_url'],
                         p_email_status=status,
                         p_created_by=privacy_data['created_by'],
                         p_org_id=privacy_data['org_id'],
                         p_language=privacy_data['language']
                         )
            status_code = conn.get_output_param(raise_exception=False)
        if status_code == 'SUCCESS':
            privacy_id = int(privacy_id.getvalue())

            result = {
                'msg': 'Privacy consent is added successfully',
                'status': Status.OK.value,
                'privacy_id': privacy_id
            }
            privacy_data['privacy_id'] = privacy_id
            attachments_status = PrivacyConsent.add_attachment(privacy_data)
            if attachments_status and attachments_status['status'] == Status.ERROR.value:
                result['failed_attachments'] = attachments_status[
                    'failed_attachments']
            email_status = self.send_user_email(privacy_data)

            history = PrivacyConsent.update_history(privacy_data, is_created=True)

            if email_status['status'] == 0:
                history['description'] += ' and mail is sent'
                result['msg'] += ' and mail is sent'
            else:
                history['description'] += ' and failed to send mail'
                result['msg'] += ' and failed to send mail'

            PrivacyConsent.add_privacy_history(history, privacy_id)
        else:
            result = {
                'msg': status_code,
                'status': Status.ERROR.value,
                'privacy_id': -1
            }

        return result

    def update_privacy_details(self, privacy_data):
        """
            to update privacy consent details
            :param privacy_data: {
                    'first_name':'',
                    'last_name':'',
                    'email_address':'',
                    'persona':'',
                    'created_by':'',
                    'privacy_id':'',
                    'send_email':'',
                    'attachments':[],
                    'delete_attachments':[],
                    'language':'',
                    'org_id':'',
                    'history_description':''
                    }

            :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            status = 'P'
            conn.execute("""
                                begin
                                    qpex_privacy_consent_pkg.update_privacy_consent(
                                    :p_privacy_id,
                                    :p_first_name,
                                    :p_last_name,
                                    :p_email_address,
                                    :p_persona,
                                    :p_video_url,
                                    :p_email_status,
                                    :p_recent_updated_id,
                                    :p_language,
                                    :x_status_code
                                    );
                                end;

                                """,
                         output_key='x_status_code',
                         p_privacy_id=privacy_data['privacy_id'],
                         p_first_name=privacy_data['first_name'],
                         p_last_name=privacy_data['last_name'],
                         p_email_address=privacy_data[
                             'email_address'],
                         p_persona=privacy_data['persona'],
                         p_video_url=privacy_data['video_url'],
                         p_email_status=status,
                         p_recent_updated_id=privacy_data[
                             'created_by'],
                         p_language=privacy_data['language']
                         )
            status_code = conn.get_output_param(raise_exception=False)
        if status_code == 'SUCCESS':
            result = {
                'msg': 'Privacy consent is updated successfully',
                'status': Status.OK.value,
                'privacy_id': privacy_data['privacy_id']
            }
            attachments_status = PrivacyConsent.add_attachment(privacy_data)
            if attachments_status and attachments_status['status'] == Status.ERROR.value:
                result['failed_attachments'] = attachments_status[
                    'failed_attachments']
            if 'delete_attachments' in privacy_data and \
                    len(privacy_data['delete_attachments']) > 0:
                PrivacyConsent.delete_attachment(privacy_data[
                                                     'delete_attachments'])
            email_status = None
            if 'send_email' in privacy_data and \
                    privacy_data['send_email'] == 'Y':
                email_status = self.send_user_email(privacy_data)

            history = PrivacyConsent.update_history(privacy_data, is_created=False)

            if email_status is not None and email_status['status'] == 0:
                history['description'] += ' and mail is sent'
                result['msg'] += ' and mail is sent'
            elif email_status is not None:
                history['description'] += ' and failed to send mail'
                result['msg'] += ' and failed to send mail'

            PrivacyConsent.add_privacy_history(history,
                                               privacy_data['privacy_id'])
        else:
            result = {
                'msg': status_code,
                'status': Status.ERROR.value,
                'privacy_id': privacy_data['privacy_id']
            }
        return result

    @staticmethod
    def delete_privacy_consent(privacy_id):
        """
            to delete privacy consent details
            :param privacy_id
            :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                                begin
                                    qpex_privacy_consent_pkg.delete_privacy_consent(
                                    :p_privacy_id,
                                    :x_status_code
                                    );
                                end;

                                """,
                         output_key='x_status_code',
                         p_privacy_id=privacy_id
                         )
            status_code = conn.get_output_param()
            if status_code == 'SUCCESS':
                result = {
                    'msg': 'Privacy consent is deleted successfully',
                    'status': Status.OK.value,
                    'privacy_id': privacy_id
                }
            else:
                result = {
                    'msg': status_code,
                    'status': Status.ERROR.value,
                    'privacy_id': privacy_id
                }
        return result

    @staticmethod
    def update_history(privacy_data, is_created=False):
        if 'history_description' in privacy_data:
            history = {
                'description': privacy_data['history_description'],
                'created_id': privacy_data['created_by']
            }
        else:
            history = {
                'description': ('Consent details are successfully added' if is_created
                                else 'Consent details are updated successfully'),
                'created_id': privacy_data['created_by']
            }
        return history

    @staticmethod
    def add_attachment(privacy_data):
        """
        To add attachment to a specific privacy consent
        :param privacy_data: object with attachments data and privacy_id
        {'attachments': [{ 'file_name':'','file_type':'','file_content':'','created_id':''}],
         'privacy_id': ''}
        :return: json object {'status':'', 'failed_attachments':''}
        """
        if 'attachments' in privacy_data and \
                len(privacy_data['attachments']) > 0:
            attachment_data = privacy_data['attachments']
            reference_id = privacy_data['privacy_id']
            with OracleConnectionManager() as conn:
                file_id = conn.set_output_param('NUMBER')
                conn.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
                status_list = []
                for attachments in attachment_data:
                    conn.execute("""
                                    begin
                                        qpex_privacy_consent_pkg.add_attachment(
                                        :x_file_id,
                                        :p_reference_id,
                                        :p_file_name,
                                        :p_file_type,
                                        :p_file_content,
                                        :p_created_id,
                                        :x_status_code
                                        );
                                    end;
    
                                    """,
                                 output_key='x_status_code',
                                 x_file_id=file_id,
                                 p_reference_id=reference_id,
                                 p_file_name=attachments['file_name'],
                                 p_file_type=attachments['file_type'],
                                 p_file_content=attachments['file_content'],
                                 p_created_id=attachments['created_id']
                                 )
                    status_code = conn.get_output_param(raise_exception=False)
                    if status_code != 'SUCCESS':
                        status_list.append(
                            {'file_name': attachments['file_name'],
                             'error': status_code})
            if len(status_list) > 0:
                result = {'status': Status.ERROR.value}
            else:
                result = {'status': Status.OK.value}
            result['failed_attachments'] = status_list
        else:
            result = ''
        return result

    @staticmethod
    def delete_attachment(attachment_data):
        """
        Delete the attachments
        :param attachment_data: array of attachment ids
        :return: {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            for attch_id in attachment_data:
                conn.execute("""
                                    begin
                                        qpex_privacy_consent_pkg.delete_attachment(
                                        :p_file_id,
                                        :x_status_code
                                        );
                                    end; """,
                             output_key='x_status_code',
                             p_file_id=attch_id
                             )
        return conn.get_output_param(raise_exception=False)

    @staticmethod
    def add_privacy_history(history_details, privacy_id):
        """
        To add history for a specific privacy consent
        :param history_details: json object
        {'description':'', 'created_id':''}
        :param privacy_id: integer
        :return: {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            privacy_history_id = conn.set_output_param('NUMBER')
            conn.execute("""
                         begin
                            qpex_privacy_consent_pkg.insert_privacy_history(
                            :x_privacy_history_id,
                            :p_privacy_id,
                            :p_description,
                            :p_created_id,
                            :x_status_code
                            );
                         end;
                         """,
                         output_key='x_status_code',
                         x_privacy_history_id=privacy_history_id,
                         p_privacy_id=privacy_id,
                         p_description=history_details['description'],
                         p_created_id=history_details['created_id'])
            status = conn.get_output_param()
        if status == 'SUCCESS':
            result = {'status': Status.OK.value, 'msg': 'Privacy History logged successfully',
                      'privacy_history_id': int(privacy_history_id.getvalue())}
        else:
            result = {'status': Status.ERROR.value, 'msg': status, 'privacy_history_id': -1}
        return result

    @staticmethod
    def get_attachment_details(attachment_id):
        """
        To get the file content of a specific attachment
        :param attachment_id: integer
        :return: {'file_content': ''}
        """
        common_obj = CommonUtils()
        result = common_obj.get_attachment_data('file_content',
                                                'qpex_privacy_attachments',
                                                'file_id',
                                                attachment_id)
        final = {'file_content': result}
        return final

    def resend_email(self, req_data):
        """
        To resend an email to the user for confirmation
        :param req_data: {'privacy_id':'', 'created_id':''}
        :return: {'status':'', 'msg':''}
        """
        privacy_details = self.get_privacy_details(req_data['privacy_id'])
        result = self.send_user_email(privacy_details['details'][0])
        history = {
            'description': 'Mail is resent again',
            'created_id': req_data['created_id']
        }
        self.add_privacy_history(history, req_data['privacy_id'])
        return result

    def update_email_status(self, update_details):
        """
        to update the privacy details if the user gives his/her consent
        :param update_details: base64 encoded json object
        {'email_status':'', 'privacy_id':''}
        :return: {'status':'', 'msg':''}
        """
        status_files = []
        result = {'msg': ''}
        privacy = ujson.loads(base64.b64decode(update_details))
        privacy_details = self.get_privacy_details(privacy['privacy_id'])
        if len(privacy_details['details']) == 0:
            result = {'msg': 'Request cannot be processed',
                      'status': Status.OK.value}
            return result
        with OracleConnectionManager() as conn:
            if privacy['email_status'] == 'A':
                # to check and verify persona value and get contact id
                hubspot_contact = PrivacyConsent.get_hubspot_contact_id(
                    privacy)
                pob_obj = POB()
                if 'contact_id' in hubspot_contact:
                    # get details of attachments based on privacy id
                    query = self.sql_file['get_attachment_details']
                    conn.execute(query, p_privacy_id=privacy['privacy_id'])
                    attachments = conn.get_result()
                    for attachment in attachments:
                        file_path = '/tmp/' + attachment['file_name']
                        # create a temp file
                        with open(file_path, 'wb') as fh:
                            fh.write(
                                attachment['file_content'].decode('base64'))

                        tmp_folder = '/tmp/' + attachment['file_name']
                        hs_upload = '/privacy/' + str(
                            hubspot_contact['contact_id'])

                        # upload file to hubspot
                        result_pob = pob_obj.upload_file(tmp_folder,
                                                         hs_upload)
                        if result_pob['status'] == 1:
                            status_files.append(
                                {'file_name': attachment['file_name']})
                else:
                    hubspot_contact = {'contact_id': ''}
                    result = {'msg': 'Failed to create a contact'}
                    logger.findaylog(""" @ models - privacyconsent - update_email_status""" +
                                     result['msg'])
            else:
                hubspot_contact = {'contact_id': ''}

            # to update the status in db
            conn.execute("""
                                begin
                                qpex_privacy_consent_pkg.update_status(
                                :p_privacy_id,
                                :p_email_status,
                                :p_hubspot_id,
                                :x_status_code
                                );
                                end;
                                """,
                         output_key='x_status_code',
                         p_privacy_id=privacy['privacy_id'],
                         p_email_status=privacy['email_status'],
                         p_hubspot_id=hubspot_contact['contact_id']
                         )
            status_code = conn.get_output_param(raise_exception=False)
        result = PrivacyConsent.get_result(result, status_code, status_files)

        almo_status, history_description = PrivacyConsent.send_almo_email(privacy)

        if almo_status['status'] == 0:
            result['msg'] += ', mail is sent to almonature team'
            history_description += ', mail is sent to almonature team'
        else:
            result['msg'] += ', failed to send email to almonature team'
            history_description += ', failed to send email to almonature team'
            logger.findaylog(result['msg'])

        history = {'description': history_description, 'created_id': -1}
        self.add_privacy_history(history, privacy['privacy_id'])
        return result

    @staticmethod
    def get_hubspot_contact_id(privacy):
        """
        To check the contact exists or not && if persona value is changed ,
        the persona needs to be updated
        :param privacy:json objects
        :return:{'contact_id':''}
        """
        cms_obj = CMS()
        check_user = cms_obj.check_contact_details(privacy['email_address'])
        hs_persona = None
        if check_user['status'] != 'ERROR' and check_user['details']['properties'].get('hs_persona') is not None:
            hs_persona = check_user['details']['properties']['hs_persona']['value']
        if check_user['status'] == 'ERROR' or \
                (check_user['status'] == 'SUCCESS' and
                 (not hs_persona or hs_persona != privacy['persona'])):
            props = {
                'firstname': privacy['first_name'],
                'lastname': privacy['last_name'],
                'email': privacy['email_address'],
                'hs_persona': privacy['persona']
            }
            hubspot_contact = cms_obj.create_contact(props)
        else:
            hubspot_contact = {
                'contact_id': check_user['details']['vid']}
        return hubspot_contact

    def send_user_email(self, privacy_data):
        """
        This is to send the user regarding privacy consent
        :param privacy_data: json object
        :return: {'status':'', 'msg':''}
        """
        user_name = ' '.join([privacy_data['first_name'],
                              privacy_data['last_name']])
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_attachment_details']
            conn.execute(query, p_privacy_id=privacy_data['privacy_id'])
            attachments = conn.get_result()
        privacy_data['total_attachments'] = len(privacy_data['attachments'])
        privacy_data.pop('attachments')
        privacy_data.pop('history')
        privacy_data['email_status'] = 'A'
        approved_link = base64.b64encode(str(ujson.dumps(privacy_data)))
        privacy_data['email_status'] = 'R'
        rejected_link = base64.b64encode(str(ujson.dumps(privacy_data)))

        subject = self.sql_file['subject'][privacy_data['language']]
        template_id = int(self.sql_file['template'][privacy_data['language']])

        template_data = {'template_id': template_id, 'params': [
            {
                'key': 'user_name',
                'value': user_name
            },
            {
                'key': 'video_url',
                'value': privacy_data.get('video_url', '') or ''
            },
            {
                'key': 'approved_link',
                'value': approved_link
            },
            {
                'key': 'reject_link',
                'value': rejected_link
            },
            {
                'key': 'language',
                'value': privacy_data.get('language', 'it').lower()
            }
        ], 'subject': subject, 'to_email': privacy_data['email_address'], 'to_name': user_name, 'sender': {
            'email': self.strings['privacy_consent_sender_email'],
            'name': self.strings['sender_name']
        }, 'attachments': []}

        for i in range(len(attachments)):
            template_data['attachments'].append({
                'file_type': attachments[i]['file_type'],
                'file_name': attachments[i]['file_name'],
                'file_data': attachments[i]['file_content']
            })
        mail_status_manager = CommonUtils.send_mail(template_data)
        result = {}
        if mail_status_manager == 'SUCCESS':
            result['status'] = 0
            result['msg'] = 'Request sent to user'
        else:
            result['status'] = 1
            result['msg'] = 'Failed to send email'
        return result

    @staticmethod
    def send_almo_email(privacy_data):
        """
        To send an email to almo user of the response that the customer has
        given
        :param privacy_data: json object
        :return: {'status':'', 'msg':''}
        """
        common_obj = CommonUtils()
        almo_user = common_obj.get_user_details_based_on_id(
                                        privacy_data['created_by'])
        user_name = ' '.join([privacy_data['first_name'],
                              privacy_data['last_name']])
        if privacy_data['email_status'] == 'A':
            template_subject = 'Consent is given by the user'
            subject = 'Privacy consent is given by {0}'.format(user_name)
        else:
            template_subject = 'Consent has been rejected by the user'
            subject = 'Privacy consent is declined by {0}'.format(user_name)

        template_data = {
            'template_id': 1015510,
            'params': [
                {
                    'key': 'user_name',
                    'value': almo_user['user_description']
                },
                {
                    'key': 'privacy_id',
                    'value': privacy_data['privacy_id']
                },
                {
                    'key': 'first_name',
                    'value': str(privacy_data['first_name'])
                },
                {
                    'key': 'last_name',
                    'value': str(privacy_data['last_name'])
                },
                {
                    'key': 'email_address',
                    'value': str(privacy_data['email_address'])
                },
                {
                    'key': 'total_attach',
                    'value': privacy_data['total_attachments']
                },
                {
                    'key': 'description',
                    'value': template_subject
                }
            ],
            'subject': subject,
            'to_email': almo_user['email_address'],
            'to_name': almo_user['user_description'],
        }
        mail_status_manager = CommonUtils.send_mail(template_data)
        result = {}
        history_description = ('Consent is given'
                               if privacy_data['email_status'] == 'A'
                               else 'Consent is rejected')
        if mail_status_manager == 'SUCCESS':
            result['status'] = 0
            result['msg'] = 'Request sent to almo user'
        else:
            result['status'] = 1
            result['msg'] = 'Failed to send email'
        return result, history_description

    def get_summary(self):
        """
        To get  all privacy details based on org_id
        :return: array of json objects
        """
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_summary_details']
            conn.execute(query)
            summary_details = conn.get_result()
        result = {'summary': summary_details, 'status': Status.OK.value}
        return result

    def get_privacy_details(self, privacy_id):
        """
        To get complete details of a single privacy consent
        :param privacy_id: integer
        :return: array of json object
        """
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_privacy_details']
            conn.execute(query, p_privacy_id=privacy_id)
            privacy_details = conn.get_result()
        result = {'details': privacy_details, 'status': Status.OK.value}
        return result

    @staticmethod
    def get_result(result, status_code, status_files):
        if status_code == 'SUCCESS':
            result['status'] = Status.OK.value
            result['msg'] += 'Successfully updated'
            result['failed_attachments'] = status_files
        else:
            result['status'] = Status.ERROR.value
            result['msg'] += status_code
        return result
