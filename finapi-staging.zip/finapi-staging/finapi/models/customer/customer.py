from finapi.models.address.address import Address
from finapi.models.currency.currency import Currency
from finapi.models.operating_unit.operating_unit import OperatingUnit
from finapi.models.order_type.order_type import OrderType
from finapi.models.payment_method.payment_method import PaymentMethod
from finapi.models.payment_term.payment_term import PaymentTerm
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.code_util import Code_util
from finapi.models.cms.cms import CMS
from finapi.utils.logdata import logger


class Customer:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def get_data(self):
        field_names = [a[0].lower() for a in self.cursor.description]
        data = []
        for row in self.cursor:
            obj = {}
            for index, field in enumerate(field_names):
                obj[field] = row[index]
            data.append(obj)
        return data

    def hubspot_contact_creation(self):
        logger.addinfo('@ models - customer - hubspot_contact_creation(+)')
        result = {}
        try:
            self.acquire()
            personas = self.sql_file['customer_persona_map']
            self.cursor.execute(self.sql_file['get_customers_contacts'])
            customer_contacts = Code_util.iterate_data(self.cursor)
            obj = CMS()
            failed_customers = []
            for contact in customer_contacts:
                if contact['country'] not in personas:
                    persona = 'persona_40'
                else:
                    persona = personas[contact['country']]
                props = {
                    'email': contact['email_address'],
                    'firstname': contact['party_name'],
                    'hs_persona': persona,
                    'address': contact['address1'],
                    'city': contact['city'],
                    'province': contact['province'],
                    'state': contact['state'],
                    'country': contact['country'],
                    'workflow_trigger': 'send_gdpr_email'
                }
                status = obj.create_contact(props)
                if 'status' in status:
                    failed_customers.append({'customer_email': contact['customer_email']})
            if failed_customers:
                result['status'] = 1
                result['msg'] = 'Failed to add few contacts to Hubspot'
                result['failed_supplier'] = failed_customers
            else:
                result['status'] = 0
                result['msg'] = 'All Supplier contacts were moved to Hubspot'
                result['failed_customers'] = failed_customers
        except Exception as error:
            logger.findaylog("""@ 1081 EXCEPTION - models - customer -
                 hubspot_contact_creation """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - customer - hubspot_contact_creation(-)')
        return result

    # returns list of customers belonging to <user_id>
    def get_customers(self, user_id, org_id):
        logger.addinfo('@ models - customer - get_customers(+)')
        ref_id = None
        if user_id:
            user_details = Code_util.get_usertype(user_id)
            user_type = user_details['type']
            ref_id = user_details['refid']
        else:
            user_type = ''
        try:
            self.acquire()
            query = self.sql_file['customers_query']
            if user_type == 'b2b':
                query = query.format(org_id=org_id,
                                     cond=' AND cust.cust_account_id = \
                                     nvl(:p_cust_id,cust.cust_account_id)')
                self.cursor.execute(query, p_cust_id=ref_id)
            elif user_type == 'salesrep':
                salesreps_query = self.sql_file['salesrep_ids_query']
                self.cursor.execute(salesreps_query, user_id=user_id)
                ids = self.cursor.fetchall()
                length = len(ids)
                id_list = []
                for count in range(length):
                    rep_id = ids[count][0]
                    id_list.append(rep_id)
                query = query.format(org_id=org_id,
                                     cond=' AND primary_salesrep_id in (%s)')
                query %= (',' . join([":" + str(i)
                                     for i in range(len(id_list))]))
                self.cursor.arraysize = 512
                self.cursor.execute(query, id_list)
            elif user_type == 'manager':
                group_names_query = self.sql_file['group_names_query']
                self.cursor.execute(group_names_query, p_user_id=ref_id,
                                    p_org_id=org_id)
                group_names = self.cursor.fetchall()
                length = len(group_names)
                group_list = []
                for count in range(length):
                    group = group_names[count][0]
                    group_list.append(group)
                query = query.format(org_id=org_id,
                                     cond=' AND ra.attribute2 in (%s)')
                query %= (',' . join([":" + str(i)
                                     for i in range(len(group_list))]))
                self.cursor.arraysize = 512
                self.cursor.execute(query, group_list)
            else:
                query = query.format(org_id=org_id, cond='')
                self.cursor.arraysize = 1000
                self.cursor.execute(query)
            customers_list = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - views - customer -
                 get_customers """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - customer - get_customers(-)')
        return customers_list

    # returns details of customer by cust account id
    def get_customer_by_id(self, cust_id, price_list_id, user_id, org_id,
                           lang):
        logger.addinfo('@ models - customer - get_customer_by_id(+)')
        customer = dict()
        try:
            self.acquire()
            user_details = Code_util.get_usertype(user_id)
            user_type = user_details['type']
            operating_unit_obj = OperatingUnit()
            operating_units = operating_unit_obj.get_opr_details(org_id)
            # getting order types from order type class
            order_types = OrderType.get_defalutordr(org_id)
            customer['opr_units'] = operating_units
            customer['ordr_type'] = order_types
            #  ship to's are getting form ship to class by passing account id list
            salesreps = []
            if user_type == 'salesrep':
                query = self.sql_file['salesrep_ids_query']
                self.cursor.execute(query, user_id=user_id)
                ids = self.cursor.fetchall()
                length = len(ids)
                for count in range(length):
                    rep_id = ids[count][0]
                    salesreps.append(rep_id)
            ship_to_list = Address.get_allshipto_address(cust_id, salesreps,
                                                         org_id)
            bill_to_list = Address.get_allbillto_address(cust_id, org_id,
                                                         lang)
            customer['shipto'] = ship_to_list
            customer['billto'] = bill_to_list
            # price list id for credit notes
            if price_list_id:
                currency_data = Currency.get_currency(cust_id,
                                                      [price_list_id])
                if currency_data:
                    customer['currency'] = currency_data[cust_id]
                else:
                    customer['currency'] = ''
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - customer -
                 get_customer_by_id """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - customer - get_customer_by_id(-)')
        return customer

    def get_salesrep_customers(self, org_id, salesrep_id):
        logger.addinfo('@ models - customer - get_salesrep_customers(+)')
        try:
            self.acquire()
            query = self.sql_file['salesrep_customers']
            self.cursor.execute(query, p_org_id=org_id,
                                p_salesrep_id=salesrep_id)
            result = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - customer -
                 get_salesrep_customers """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - customer - get_salesrep_customers(-)')
        return result

    def get_customer_terms(self, site_id, org_id):
        logger.addinfo('@ models - customer - get_customer_terms(+)')
        try:
            self.acquire()
            query = self.sql_file['payment_terms_query']
            self.cursor.execute(query, p_party_site_id=site_id, p_org_id=org_id)
            result = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - customer -
                 get_customer_terms """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - customer - get_customer_terms(-)')
        return result

    @staticmethod
    def get_payment_terms(cust_id, site_id, org_id, lang):
        logger.addinfo('@ models - customer - get_payment_terms(+)')
        try:
            if site_id:
                payment_methods = PaymentTerm.get_payments([site_id], org_id,
                                                           lang, cust_id)
            else:
                payment_methods = PaymentMethod.get_paymentmethods(cust_id)

        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - customer -
                 get_payment_terms """ + str(error))
            raise error
        logger.addinfo('@ models - customer - get_payment_terms(-)')
        return payment_methods

    def get_price_list(self, cust_id):
        logger.addinfo('@ models - customer - get_price_list(+)')
        try:
            self.acquire()
            query = self.sql_file['price_list_query']
            self.cursor.execute(query, p_cust_id=cust_id)
            price_list = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - customer -
                 get_price_list """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - customer - get_price_list(-)')
        return price_list

    def delete_price_list(self, cust_id, list_id):
        logger.addinfo('@ models - customer - delete_price_list(+)')
        try:
            self.acquire()
            query = self.sql_file['delete_customer_pricelist_query']
            self.cursor.execute(query, p_cust_id=cust_id, p_list_id=list_id)
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - customer -
                delete_price_list ''' + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - customer - delete_price_list(-)')
        return {'status': 0, 'msg': 'Price list deleted successfully'}

    def save_customer_price_list(self, req):
        logger.addinfo('@ models - customer - save_customer_price_list(+)')
        try:
            self.acquire()
            query = self.sql_file['insert_customer_pricelist_query']
            self.cursor.execute(query, p_customer_id=req['customer_id'],
                                p_price_list_id=req['price_list_id'])
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - customer -
                save_customer_price_list ''' + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - customer - save_customer_price_list(-)')
        return {'status': 0, 'msg': 'Price list saved successfully'}

    # returns cust account id of customer based on account number
    def get_customer_number(self, cust_id):
        logger.addinfo('@ models - customer - get_customer_number(+)')
        try:
            self.acquire()
            query = self.sql_file['customer_number_query']
            self.cursor.execute(query, p_cust_id=cust_id)
            account_num = self.cursor.fetchone()[0]
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - customer -
                 get_customer_number """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - customer - get_customer_number(-)')
        return account_num
