import cx_Oracle
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.constants import Status


class Utilities:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_brands():
        logger.addinfo('@ models - utilities - get_brands(+)')
        return_data = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            query = file_data['product_family_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - models - utilities -
                 get_brands """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cursor.description]
            for row in cursor:
                data = {}
                for index, fn in enumerate(field_names):
                    data[fn] = row[index]
                return_data.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - utilities - get_brands(-)')
        return return_data

    @staticmethod
    def get_brands_lov():
        logger.addinfo('@ models - utilities - get_brands_lov(+)')
        return_data = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            query = file_data['product_brands_lov']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 54 EXCEPTION - models - utilities -
                 get_brands_lov """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cursor.description]
            for row in cursor:
                data = {}
                for index, fn in enumerate(field_names):
                    data[fn] = row[index]
                return_data.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - utilities - get_brands_lov(-)')
        return return_data

    @staticmethod
    def get_currencies():
        logger.addinfo('@ models - utilities - get_currencies(+)')
        return_data = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            query = file_data['currencies_lov']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 83 EXCEPTION - models - utilities -
                 get_currencies """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cursor.description]
            for row in cursor:
                data = {}
                for index, fn in enumerate(field_names):
                    data[fn] = row[index]
                return_data.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - utilities - get_currencies(-)')
        return return_data

    @staticmethod
    def get_exchange():
        logger.addinfo('@ models - utilities - get_exchange(+)')
        return_data = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            query = file_data['exchange_rates_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 112 EXCEPTION - models - utilities -
                 get_exchange """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cursor.description]
            for row in cursor:
                data = {}
                for index, fn in enumerate(field_names):
                    data[fn] = row[index]
                return_data.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - utilities - get_exchange(-)')
        return return_data

    @staticmethod
    def save_brand(jsond, is_update):
        logger.addinfo('@ models - utilities - save_brand(+)')
        connection = None
        cursor = None
        query = ""
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            if is_update:
                query = file_data['brand_update_query']
                cursor.execute(query)
                connection.commit()
                for row in jsond:
                    query1 = file_data['brand_insert_query']
                    cursor.execute(query1, p_brand=row['brand_animale'],
                                   p_order=row['ordinamento'])
            else:
                query = file_data['brand_insert_query']
                cursor.execute(query, p_brand=jsond['brand'],
                               p_order=jsond['order'])
        except Exception as error:
            logger.findaylog("""@ 148 EXCEPTION - models - utilities -
                 save_brand """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - utilities - save_brand(-)')
        return True

    @staticmethod
    def delete_brand(jsond):
        logger.addinfo('@ models - utilities - delete_brand(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            query = file_data['delete_brand_query']
            cursor.execute(query, p_order=jsond['order'])
        except Exception as error:
            logger.findaylog("""@ 170 EXCEPTION - models - utilities -
                 delete_brand """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - utilities - delete_brand(-)')
        return True

    @staticmethod
    def save_exchange(jsond, is_update):
        logger.addinfo('@ models - utilities - save_exchange(+)')
        connection = None
        cursor = None
        query = ""
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            if is_update:
                query = file_data['exchange_update_query']
                cursor.execute(query, p_year=jsond['year'],
                               p_rate=jsond['rate'],
                               p_condition=jsond['condition'])
            else:
                query = file_data['exchange_insert_query']
                cursor.execute(query, p_year=jsond['year'],
                               p_currency=jsond['currency'],
                               p_rate=jsond['rate'])
        except Exception as error:
            logger.findaylog("""@ 201 EXCEPTION - models - utilities -
                 save_exchange """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - utilities - save_exchange(-)')
        return True

    @staticmethod
    def delete_exchange(jsond):
        logger.addinfo('@ models - utilities - delete_exchange(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            query = file_data['delete_exchange_query']
            cursor.execute(query, p_currency=jsond['currency'],
                           p_year=jsond['year'])
        except Exception as error:
            logger.findaylog("""@ 224 EXCEPTION - models - utilities -
                 delete_exchange """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - utilities - delete_exchange(-)')
        return True

    @staticmethod
    def manage_purchase_or_sales_segments(jsond):
        """
         To update the sequence number when ordering of the segments are done
         it is either purchase segments or sales segments
         @param jsond: {"segments":[{"category_id":"", "structure_id":"", "sequnce_number": ""}],
                        "segment_type": "" }
         @return {"status": "", "msg": ""}
        """
        logger.addinfo('@ models - utilities - manage_purchase_or_sales_segments(-)')
        try:
            category_id = []
            structure_id = []
            sequence_number = []
            for segment in jsond['segments']:
                category_id.append(segment['category_id'])
                structure_id.append(segment['structure_id'])
                sequence_number.append(segment['sequnce_number'])
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                        BEGIN
                            qpex_purchasing_pkg.update_segments_order(
                                :p_category_ids,
                                :p_structure_ids,
                                :p_sequence_numbers,
                                :x_status_code
                            );
                        END;
                    """, p_category_ids=conn.cursor.arrayvar(cx_Oracle.NUMBER,
                                                             category_id),
                             p_structure_ids=conn.cursor.arrayvar(cx_Oracle.NUMBER,
                                                                  structure_id),
                             p_sequence_numbers=conn.cursor.arrayvar(cx_Oracle.STRING,
                                                                     sequence_number),
                             x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    result = {'status': Status.OK.value,
                              'msg': '{} updated successfully'.format(jsond['segment_type'])}
                else:
                    result = {'status': Status.OK.value,
                              'msg': 'Failed to update {}'.format(jsond['segment_type'])}

        except Exception as error:
            logger.findaylog("""@ EXCEPTION - model - utilities -
                manage_purchase_or_sales_segments - """ + str(error))
            raise error
        logger.addinfo('@ models - utilities - manage_purchase_or_sales_segments(+)')
        return result
