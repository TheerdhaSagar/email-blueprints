from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil


class Currency:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    #  used in cutomer to get curreny for customer
    @staticmethod
    @db_util.langs("American")
    def get_currency(accountid, pricelistid_list):
        logger.addinfo('@ models - currency - get_currency(+)')
        con = None
        cur = None
        currency_codedict = {}
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query_temp = sql_file['currency_code']
            query = query_temp % (',' . join([":" + str(i)
                                  for i in range(len(pricelistid_list))]),
                                  accountid)
            cur.execute(query, pricelistid_list)
        except Exception as error:
            logger.findaylog("""@ 30 EXCEPTION - models - currency -
                 get_currency """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                currency_data = {}
                for index, fn in enumerate(field_names):
                    currency_data[fn] = row[index]
                    if fn == 'cust_account_id':
                        keyval = row[index]
                if keyval in list(currency_codedict.keys()):
                    currency_codedict.get(keyval).append(currency_data)
                else:
                    mylist = []
                    mylist.append(currency_data)
                    currency_codedict[keyval] = mylist
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - currency - get_currency(-)')
        return currency_codedict


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'currency',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
