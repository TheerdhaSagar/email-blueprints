from finapi.utils.logdata import logger
from finapi.utils import db_util
from copy import deepcopy
from jinja2 import Template
from PyPDF2 import PdfFileReader, PdfFileWriter
from barcode.writer import ImageWriter
from finapi.sql import sql_util
from finapi.utils.code_util import Code_util
from finapi.utils.log_util import LogUtil
import ujson
import urllib.request, urllib.error, urllib.parse
import requests
import os
import pdfkit
import io
import barcode
import re
import base64
import redis
import json
import cx_Oracle
import paramiko
from finapi.utils.constants import Status
import datetime
import re


class Recipes:
    def __init__(self):
        self.redis = redis.StrictRedis(decode_responses=True)
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    def get_segment_details(self, segment_id, brand_id, language):
        logger.addinfo("@ models - recipes - get_segment_details(+)")
        try:
            key = ''
            if segment_id:
                key = str(segment_id) + ':' + brand_id + ':' + language
            data = []
            for key in self.redis.keys(key):
                details = self.redis.hgetall(key)
                if 'segment_images' in details:
                    details['segment_images'] = ujson.loads(
                                                details['segment_images'])
                else:
                    details['segment_images'] = []
                if 'packaging' in details:
                    details['packaging'] = ujson.loads(
                                            details['packaging'])
                else:
                    details['packaging'] = {}
                if 'segment_serving' in details:
                    details['segment_serving'] = ujson.loads(
                                                    details['segment_serving'])
                else:
                    details['segment_serving'] = []
                data.append(details)
            result = data
        except Exception as e:
            logger.findaylog("""@ 61 EXCEPTION - models - recipes -
                        get_segment_details """ + str(e))
            raise e
        logger.addinfo("@ models - recipes - get_segment_details(-)")
        return result

    def get_product_details(self, req_obj):
        logger.addinfo("@ models - recipes - get_product_details(+)")
        try:
            item_id = req_obj['item_id']
            segment_id = req_obj['segment_id']
            brand_id = req_obj['brand_id']
            food_type = req_obj['food_type']
            pet_type = req_obj['pet_type']
            language = req_obj['language']
            if item_id:
                key = item_id + ':*:' + language
            elif segment_id:
                key = '*:' + pet_type + ':' + food_type + ':' + brand_id + ':' + segment_id + ':*:' + language
            elif brand_id != '*':
                key = '*:' + pet_type + ':' + food_type + ':' + brand_id + ':*:' + language
            else:
                key = '*:' + pet_type + ':' + food_type + ':*:*:*:' + language
            data = []
            for key in self.redis.keys(key):
                details = self.redis.hgetall(key)
                if 'images' in details:
                    details['images'] = ujson.loads(details['images'])
                else:
                    details['images'] = []
                if 'segment_images' in details:
                    details['segment_images'] = ujson.loads(
                        details['segment_images'])
                else:
                    details['segment_images'] = []
                if 'constituents' in details:
                    details['constituents'] = ujson.loads(details['constituents'])
                else:
                    details['constituents'] = []
                if 'packaging' in details:
                    details['packaging'] = ujson.loads(details['packaging'])
                else:
                    details['packaging'] = {}
                if 'ingredients' in details:
                    details['ingredients'] = Recipes.order_composition_list(
                        ujson.loads(details['ingredients']))
                else:
                    details['ingredients'] = []
                if 'segment_serving' in details:
                    details['segment_serving'] = ujson.loads(
                        details['segment_serving'])
                else:
                    details['segment_serving'] = []
                if 'product_serving' in details:
                    details['product_serving'] = ujson.loads(
                        details['product_serving'])
                else:
                    details['product_serving'] = []
                data.append(details)
            result = data
        except Exception as e:
            logger.findaylog("""@ 92 EXCEPTION - models - recipes -
                        get_product_details """ + str(e))
            raise e
        logger.addinfo("@ models - recipes - get_product_details(-)")
        return result

    # for searching a products
    def search_product_onboard(self, jsond):
        logger.addinfo("@ models - recipes - search_product_onboard(+)")
        try:
            search = jsond["key"]
            animal = jsond.get("animal", "")
            food_type = jsond.get("wet_or_dry", "")
            language = Recipes.decode_value(jsond["language"])
            key = "*:*"
            if food_type and food_type.strip():
                key = food_type.upper() + ":" + key
            if animal and animal.strip():
                key = animal.upper() + ":" + key
            key = "*:" + key + ':*:' + language
            data = []
            for key in self.redis.keys(key):
                details = self.redis.hgetall(key)
                if 'images' in details:
                    details['images'] = ujson.loads(details['images'])
                else:
                    details['images'] = []
                if 'segment_images' in details:
                    details['segment_images'] = ujson.loads(details[
                                                        'segment_images'])
                    details['segment_image_url'] = (details[
                                                    'segment_images'][0]
                                                    if details[
                                                        'segment_images']
                                                    else "")
                else:
                    details['segment_images'] = []
                    details['segment_image_url'] = ''
                if 'constituents' in details:
                    details['constituents'] = ujson.loads(details[
                                                          'constituents'])
                else:
                    details['constituents'] = []
                if 'packaging' in details:
                    details['packaging'] = ujson.loads(details['packaging'])
                else:
                    details['packaging'] = {}
                if 'ingredients' in details:
                    details['ingredients'] = ujson.loads(details[
                                                         'ingredients'])
                else:
                    details['ingredients'] = []
                if 'product_serving' in details:
                    details['product_serving'] = ujson.loads(
                                                    details['product_serving'])
                else:
                    details['product_serving'] = []
                if 'segment_serving' in details:
                    details['segment_serving'] = ujson.loads(
                            details['segment_serving'])
                else:
                    details['segment_serving'] = []
                data.append(details)
            if len(data) > 0:
                if search:
                    final_d = []
                    if isinstance(Recipes.decode_value(search), str):
                        search = [search]
                    for d in search:
                        for i in data:
                            d = Recipes.decode_value(d)
                            if "item_description" in i and "item_code" in i and \
                                    "pet_type" in i:
                                item_description = i["item_description"].lower()
                                if re.search(d, i["item_code"]) or \
                                        re.search(d.lower(), item_description) \
                                        or \
                                        re.search(d.lower(), i["pet_type"]):
                                    final_d.append(i)
                    result = list(
                        {v["item_code"]: v for v in final_d}.values())
                else:
                    result = data
            else:
                result = data
        except Exception as error:
            logger.findaylog("""@ 154 EXCEPTION - models - recipes -
                search_product_onboard """ + str(error))
            raise error
        logger.addinfo("@ models - recipes - search_product_onboard(-)")
        return result

    # to download a particular product or products or a segment
    def download_products_pdf(self, jsond):
        logger.addinfo("@ models - recipes - download_products_pdf(+)")
        try:
            items = jsond["data"]
            language = jsond["language"]
            data = []
            for i in items:
                keys = i["item_code"] + ":*:" + language
                for key in self.redis.keys(keys):
                    details = self.redis.hgetall(key)
                    if details['generate_pdf'] == 'Y':
                        if 'images' in details:
                            details['images'] = ujson.loads(details['images'])
                        else:
                            details['images'] = []
                        if 'constituents' in details:
                            details['constituents'] = ujson.loads(
                                    details['constituents'])
                        else:
                            details['constituents'] = []
                        if 'packaging' in details:
                            details['packaging'] = ujson.loads(
                                    details['packaging'])
                        else:
                            details['packaging'] = []
                        if 'ingredients' in details:
                            details['ingredients'] = Recipes.order_composition_list(
                                ujson.loads(details['ingredients']))
                        else:
                            details['ingredients'] = ''
                        if 'product_serving' in details:
                            details['product_serving'] = ujson.loads(
                                    details['product_serving'])
                        else:
                            details['product_serving'] = []
                        if 'segment_serving' in details:
                            details['segment_serving'] = ujson.loads(
                                    details['segment_serving'])
                        else:
                            details['segment_serving'] = []
                        if 'segment_images' in details:
                            details['segment_images'] = ujson.loads(
                                                details['segment_images'])
                            details['segment_image_url'] = (details[
                                                            'segment_images'][0]
                                                            if details[
                                                                'segment_images']
                                                            else '')
                        else:
                            details['segment_images'] = []
                            details['segment_image_url'] = ''
                        data.append(details)
            if len(data) > 1:
                result = data
            else:
                result = data
        except Exception as error:
            logger.findaylog("""@ 196 EXCEPTION - models - recipes -
                download_products_pdf """ + str(error))
            raise error
        logger.addinfo("@ models - recipes - download_products_pdf(-)")
        return result

    # function to generate barcode and save it in the folder
    @staticmethod
    def generate_barcode(value, barcodes_path):
        logger.addinfo("@ models - recipes - generate_barcode(+)")
        try:
            value = value.replace(" ", "")
            check_digits = re.search(r"[^0-9]", value)
            if check_digits is not None or len(value) != 13:
                return ""
            if not os.path.exists(barcodes_path):
                os.makedirs(barcodes_path)
            file_name = barcodes_path + "barcode_" + str(value)
            png_filename = file_name + ".png"
            if not os.path.exists(png_filename):
                ean_class = barcode.get_barcode_class("ean13")
                ean = ean_class(value, writer=ImageWriter())
                ean.default_writer_options["font_size"] = 23
                ean.default_writer_options["center_text"] = True
                ean.default_writer_options["quiet_zone"] = 1.0
                ean.default_writer_options["text_distance"] = 2.0
                ean.default_writer_options["module_height"] = 10.0
                png_filename = ean.save(file_name)

        except Exception as e:
            logger.findaylog(""" @ 227 EXCEPTION - recipes - models -
                             generate_barcode """ + str(e))
            raise e
        logger.addinfo("@ models - recipes- generate_barcode(-)")
        return png_filename

    # to generate and get barcodes
    def get_barcode(self, jsond):
        logger.addinfo("@ models - recipes - get_barcode(+)")
        try:
            barcodes_path = self.sql_file["barcodes_path"]
            images = []
            for i in range(len(jsond)):
                obj = {}
                value = jsond[i]["barcode_value"]
                obj["barcode_value"] = value
                obj["product_id"] = jsond[i]["product_id"]
                obj["base64"] = ""
                f_value = value.replace(" ", "")
                image_name = "barcode_" + f_value + ".png"
                barcode_url = barcodes_path + image_name
                if not os.path.exists(barcode_url):
                    image_name = Recipes.generate_barcode(value, barcodes_path)
                if image_name:
                    obj["base64"] = base64.b64encode(open(
                        barcode_url, "rb").read())
                images.append(obj)
        except Exception as e:
            logger.findaylog(""" @ 257 EXCEPTION - models - recipes -
                             get_barcode""" + str(e))
            raise e
        logger.addinfo("@ models - recipes - get_barcode(-)")
        return images

    #  To upload the new changes and generate pdfs in particular folders
    def generate_pdf(self, jsond):
        logger.addinfo("@ models - recipes - generate_pdf(+)")
        try:
            if jsond["type"] == "old_pdf":
                file_name = os.path.join(
                    os.path.dirname(__file__) + "/detailpdf.html")
                with io.open(file_name, "r", encoding="utf-8") as original:
                    html_content = Template(original.read())
                    original.close()
            else:
                html_content = {}
                products_file_name = os.path.join(
                    os.path.dirname(__file__) + "/summarypdfproducts.html")

                with io.open(products_file_name,
                             "r", encoding="utf-8") as original:
                    html_content[
                        "products_content"] = Template(original.read())
                    original.close()

                html_content["header_name"] = os.path.join(os.path.dirname(
                    __file__) + "/pdfheader.html")
                footer_name = os.path.join(
                    os.path.dirname(__file__) + "/pdffooter.html")

                with io.open(footer_name,
                             "r", encoding="utf-8") as footer_original:
                    html_content[
                        "footer_content"] = Template(footer_original.read())
                    footer_original.close()
            response = []
            languages = self.get_language()
            for i in languages:
                for brands in jsond["brands"]:
                    if len(brands["segments"]) > 0:
                        search_json = {"language": i["language_id"],
                                       "brand": Recipes.decode_value(
                                                    brands["brand"]),
                                       "brand_name": Recipes.decode_value(
                                                    brands["brand_name"]),
                                       "animal": brands["pet_type"],
                                       "wet_or_dry": brands["wet_or_dry"],
                                       "type": Recipes.decode_value(
                                                        jsond["type"])}
                        result = self.find_products(search_json,
                                                    html_content)
                        if result == "error":
                            logger.findaylog(""" generatepdf - no segmentdata -
                             """ + brands["brand_name"])
                            # Recipes.send_log("generate_pdf",
                            #                  "no segment data",
                            #                  {"brands": brands["brand_name"]})

                    else:
                        logger.findaylog(""" generatepdf - no segmentdata -
                             """ + brands["brand_name"])
                        # Recipes.send_log("generate_pdf", "no segment data",
                        #                  brands["brand_name"])
                        result = "error"
                    response.append({
                        "brand": brands["brand_name"],
                        "language": i["language"],
                        "pet_type": brands["pet_type"],
                        "wet_or_dry": brands["wet_or_dry"],
                        "result": result
                    })

        except Exception as e:
            logger.findaylog(""" @ 329 EXCEPTION - models - recipes -
                             generate_pdf """ + str(e))
            raise e
        logger.addinfo("@ models - recipes - generate_pdf(-)")
        return response

    # to get all languages from db
    def get_language(self):
        logger.addinfo("@ models - recipes - get_language(+)")
        try:
            self.acquire()
            query = self.sql_file["language_query"]
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 345 EXCEPTION - models - recipes -
                 get_language """ + str(error))
            raise error
        else:
            language_list = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        logger.addinfo("@ models - recipes - get_language(-)")
        return language_list

    # To get products for particular brands list
    def find_products(self, jsond, html_content):
        logger.addinfo("@ models - recipes - find_products(+)")
        try:
            search = jsond["brand"]
            animal = jsond["animal"]
            food_type = jsond["wet_or_dry"]
            language = jsond["language"]
            data = []
            for b_id in search:
                keys = "*:" + animal + ":" + food_type + ":" + str(b_id) + \
                    ":*:" + language
                for key in self.redis.keys(keys):
                    details = self.redis.hgetall(key)
                    if details['generate_pdf'] == "Y":
                        if 'images' in details:
                            details['images'] = ujson.loads(details['images'])
                        else:
                            details['images'] = []
                        if 'constituents' in details:
                            details['constituents'] = ujson.loads(details[
                                                            'constituents'])
                        else:
                            details['constituents'] = []
                        if 'packaging' in details:
                            details['packaging'] = ujson.loads(details[
                                                               'packaging'])
                            if len(details['packaging']['single']) > 0 and\
                               details['packaging']['single'][0][
                                    'weight_uom'] == 'kg':
                                details['reorder_weight'] = details[
                                'packaging']['single'][0]['weight'] * 1000
                            elif len(details['packaging']['single']) > 0 and\
                                    details['packaging']['single'][0][
                                    'weight_uom'] == 'g':
                                details['reorder_weight'] = details[
                                'packaging']['single'][0]['weight']
                            else:
                                details['reorder_weight'] = 999999999

                        else:
                            details['packaging'] = {}
                            details['reorder_weight'] = 999999999
                        if 'ingredients' in details:
                            details['ingredients'] = Recipes.order_composition_list(
                                ujson.loads(details['ingredients']))
                        else:
                            details['ingredients'] = []
                        if 'product_serving' in details:
                            details['product_serving'] = ujson.loads(
                                    details['product_serving'])
                        else:
                            details['product_serving'] = []
                        if 'segment_serving' in details:
                            details['segment_serving'] = ujson.loads(
                                    details['segment_serving'])
                        else:
                            details['segment_serving'] = []
                        if 'segment_images' in details:
                            details['segment_images'] = ujson.loads(details[
                                                            'segment_images'])
                            details['segment_image_url'] = (details[
                                                            'segment_images'][0]
                                                            if details[
                                                                'segment_images']
                                                            else "")
                        else:
                            details['segment_images'] = []
                            details['segment_image_url'] = ''
                        data.append(details)
            data = sorted(data, key=lambda k: k['reorder_weight'])
            if len(data) > 0:
                if jsond["type"] == "old_pdf":
                    products = Recipes.pdf_format_data(data, language)
                    result = self.pdf_html_template(products, animal,
                                                    food_type,
                                                    jsond["brand_name"],
                                                    html_content)
                else:
                    products, tr_dict = Recipes.new_pdf_format_data(data,
                                                                    language
                                                                    )
                    result = self.new_pdf_html_template(products,
                                                        jsond["brand_name"],
                                                        animal,
                                                        food_type, language,
                                                        html_content,
                                                        tr_dict)

            else:
                result = "error"
        except Exception as error:
            logger.findaylog("""@ 412 EXCEPTION - models - recipes -
                find_products """ + str(error))
            raise error
        logger.addinfo("@ models - recipes - find_products(-)")
        return result

    # to change the encoded values to string
    @staticmethod
    def decode_value(value):
        logger.addinfo("@ models - recipes - decode_value(+)")
        try:
            if value and isinstance(value, str):
                value = value.encode("utf-8")
        except Exception as e:
            logger.findaylog(""" @ 427 EXCEPTION - models - recipes -
                             decode_value """ + str(e))
            raise e
        logger.addinfo("@ models - recipes - decode_value(-)")
        return value

    # Detail Pdf format data
    @staticmethod
    def pdf_format_data(data, language_id):
        try:
            translate_dict = Recipes.translate_words(language_id)
            products = []
            for item in data:
                product_d = {"image_url": (item["images"][0]
                                           if item["images"]
                                           else ""),
                             "description": item["product_description"],
                             "product_id": item["item_code"],
                             "product_name": item["product_name"],
                             "brand_name": item["brand_name"],
                             "newrecipe": item["new_recipe"],
                             "language": language_id}

                details = [{"label": translate_dict["RANGE"],
                            "value": item["segment_range"]},
                           {"label": translate_dict["PRODUCT_NAME"],
                            "value": item["product_name"]},
                           {"label": translate_dict["PRODUCT_CODE"],
                            "value": item["item_code"]},
                           {"label": translate_dict["EAN"],
                            "value": item["ean_code"]},
                           {"label": translate_dict["BARCODE"],
                            "value": item["bar_code"]},
                           {"label": translate_dict["WEIGHT"],
                            "value": " ".join([str(item["packaging"][
                                "single"][0]["weight"]),item["packaging"]["single"][
                                0]["weight_uom"]])
                            if (item["packaging"]["single"] and
                                len(item["packaging"]["single"]) > 0)
                            else " "}, {"label": translate_dict["BRAND"],
                                        "value": item["producer"]},
                           {"label": translate_dict["MADE_IN"],
                            "value": item["made_in"]},
                           {"label": translate_dict["TYPE"],
                            "value": item["type_description"]}]

                storage = []
                if item["shell_life"]:
                    storage.append({"label": "",
                                    "value": item["shell_life"]})
                else:
                    storage.append({"label": "",
                                    "value": " "})
                language = []
                if item["languages"]:
                    language.append({"label": "",
                                     "value": item["languages"]})
                else:
                    language.append({"label": "",
                                     "value": " "})

                energy = []
                if item["energy"]:
                    energy.append({"label": "",
                                   "value": item["energy"]})
                else:
                    energy.append({"label": " ",
                                   "value": " "})

                composition = []
                if item["ingredients"]:
                    for i in item["ingredients"]:
                        if isinstance(i, dict):
                            name = i["name"][:1].upper() + i["name"][1:]
                            if "percent" in i and i["percent"] != '' and \
                                    i["percent"] is not None:
                                composition.append({"label": name,
                                                    "value": i["percent"]})
                            else:
                                composition.append({"label": "",
                                                    "value": name})
                        else:
                            name = i[:1].upper() + i[1:]
                            composition.append({"label": "",
                                                "value": name})
                else:
                    composition.append({"label": " ",
                                        "value": " "})

                constituents = []
                if item["constituents"]:
                    for k in item["constituents"]:
                        name = k["name"][:1].upper() + k["name"][1:]
                        if k["percent"] is not None and k["percent"] != '':
                            constituents.append({"label": name,
                                                 "value": str(k["percent"]) + "%"})
                        else:
                            constituents.append({"label": "",
                                                 "value": name})

                else:
                    constituents.append({"label": " ",
                                         "value": " "})
                single_pack = []
                if item["packaging"]["single"] and \
                        len(item["packaging"]["single"]) > 0:
                        d = item["packaging"]["single"][0]
                        single_pack.append({"label": translate_dict[
                            "PACKAGING_TYPE"],
                                            "value": d["package_type"]})
                        single_pack.append({"label": translate_dict[
                            "NET_WEIGHT"],
                                            "value": ' '.join([
                                                str(d["weight"]),
                                                d["weight_uom"]
                                            ])})
                        single_pack.append({"label": translate_dict["HEIGHT"]
                                            + "(" + d["package_uom"] + ")",
                                            "value": d["height"]})
                        single_pack.append({"label":  translate_dict["WIDTH"] +
                                            "(" + d[
                                                    "package_uom"] + ")",
                                            "value": d["width"]})
                        single_pack.append({"label":  translate_dict[
                                                      "LENGTH"] + "(" + d[
                                                          "package_uom"] + ")",
                                            "value": d["length"]})
                else:
                    single_pack.append({"label": " ", "value": " "})
                multi_pack = []
                if item["packaging"]["multi"] and \
                        len(item["packaging"]["multi"]) > 0:
                    d = item["packaging"]["multi"][0]
                    multi_pack.append({"label": translate_dict[
                        "PIECES_PER_CARTON"],
                                       "value": d["pz_carton"]})
                    multi_pack.append({"label": (translate_dict[
                                                    "CARTON_WEIGHT"] +
                                                 "(" + d["weight_uom"] + ")"),
                                       "value": d["weight"]})
                    multi_pack.append({"label": translate_dict[
                                                    "CARTON_PER_PALLET"],
                                       "value": d["cartons_per_pallet"]})
                    multi_pack.append({"label": translate_dict[
                                                    "HEIGHT_PALLET"] +
                                       "(" + d["package_uom"] + ")",
                                       "value": d["pallet_height"]})
                    multi_pack.append({"label": translate_dict[
                                                    "CARTONS_PER_LAYER"],
                                       "value": d["cartons_per_layer"]})
                    multi_pack.append({"label": translate_dict[
                                                    "LAYERS_PER_PALLET"],
                                       "value": d["layers_per_pallet"]})
                    multi_pack.append({"label": (translate_dict[
                                                    "CARTON(LONG_SIDE)"] +
                                                 "(" + d["package_uom"] + ")"),
                                       "value": d["length"]})
                    multi_pack.append({"label": translate_dict[
                                                    "CARTON(SHORT_SIDE)"] +
                                       "(" + d["package_uom"] + ")",
                                       "value": d["width"]})
                    multi_pack.append({"label": translate_dict[
                                                    "CARTON(HEIGHT)"] +
                                       "(" + d["package_uom"] + ")",
                                       "value": d["height"]})
                    multi_pack.append({"label": translate_dict[
                                                    "PACKAGING_TYPE"] + "(ct)",
                                       "value": d["carton_package_type"]})
                else:
                    multi_pack.append({"label": " ",
                                       "value": " "})
                manufacture = [{"label": "",
                                "value": item["manufacturer_name"]
                                if item["manufacturer_name"]
                                else " "
                                },
                               {"label": "",
                                "value": item["manufacturer_website"]
                                if item["manufacturer_website"]
                                else " "
                                }]
                daily_serving = []
                if (item.get("product_serving", None) and
                        len(item["product_serving"]) > 0 and
                        item["product_serving"][0]["legacy_value"] != ''):
                    daily_serving.append({"label": "",
                                          "value": item["product_serving"][0][
                                                   "legacy_value"]})
                elif item.get("segment_serving", None) and \
                        len(item["segment_serving"]) > 0 and \
                        item["segment_serving"][0]["legacy_value"] != '':
                    daily_serving.append({"label": "",
                                          "value": item["segment_serving"][0][
                                                   "legacy_value"]})
                else:
                    daily_serving.append({"label": "", "value": " "})
                sections = [{"label": translate_dict["DETAILS"],
                             "fields": details
                             },
                            {"label": translate_dict["STORAGE"],
                             "fields": storage
                             },
                            {"label": translate_dict["LANGUAGES"],
                             "fields": language
                             },
                            {"label": translate_dict["ENERGY_VALUE"],
                             "fields": energy
                             },
                            {"label": translate_dict["COMPOSITION"],
                             "fields": composition
                             },
                            {"label": translate_dict[
                                            "ANALYTICAL_CONSTITUENTS"],
                             "fields": constituents
                             },
                            {"label": translate_dict[
                                        "SUGGESTED_DAILY_SERVING"],
                             "fields": daily_serving
                             },
                            {"label": translate_dict[
                                        "TECHNICAL_DATA_SINGLE_PACK"],
                             "fields": single_pack
                             },
                            {"label": translate_dict[
                                        "TECHNICAL_DATA_MULTI_PACK"],
                             "fields": multi_pack
                             },
                            {"label": translate_dict[
                                                "MANUFACTURER"],
                             "fields": manufacture
                             }]
                product_d["sections"] = sections
                products.append(product_d)
        except Exception as e:
            logger.findaylog("""@ 652 EXCEPTION - models - recipes -
                            pdf_format_data""" + str(e))
            # Recipes.send_log("pdf_format_data", e.message,
            #                  {"language": language_id})
            raise e
        return products

    # to get translated words for each language
    @staticmethod
    def translate_words(language_id):
        try:
            file_name = os.path.join(
                os.path.dirname(__file__) + "/translate.json")
            with open(file_name, mode="r") as f:
                data = json.load(f)
            keys = list(data.keys())
            if language_id in keys:
                language_values = data[language_id]
            else:
                language_values = data['I']
        except Exception as e:
            logger.findaylog(""" @ 669 EXCEPTION - models - recipes -
                             translate_words """ + str(e))
            raise e
        return language_values

    # To Generate the Detail PDF
    def pdf_html_template(self, jsond, pet_type, wet_or_dry,
                          brand_name, content, multiple_pdf=None):
        logger.addinfo("@ models - recipes - pdf_html_template(+)")
        try:
            if multiple_pdf:
                file_path = self.sql_file["pdf_path"] + multiple_pdf
            else:
                obj = {"language": jsond[0]["language"],
                       "brand_name": brand_name,
                       "pet_type": pet_type, "wet_or_dry": wet_or_dry,
                       "path": self.sql_file["pdf_path"]}
                file_path = Recipes.get_file_path(obj)
            options = {
                "page-size": "A4",
                "quiet": "",
                "encoding": "utf-8",
                "margin-bottom": "0mm",
                "margin-top": "3mm",
                "margin-left": "3mm",
                "margin-right": "3mm"
            }
            products = []
            url_heading = self.get_download_text(jsond[0]["language"])
            link_img = self.sql_file["link_img"]
            new_product_image = self.sql_file["new_product_image"]
            logo = self.sql_file["new_logo"]
            for s in range(len(jsond)):
                product = {}
                product_image = Recipes.get_product_image(
                    jsond[s]["product_id"])
                sections = jsond[s]["sections"]
                fields = sections[0]["fields"]
                product_name = fields[0]["value"]
                product_name += " " + fields[1]["value"]
                column_one_blocks = []
                column_two_blocks = []
                column_three_blocks = []
                for i in range(len(sections)):
                    if i < 4:
                        # sections in first column
                        column_one_blocks.append(sections[i])
                    elif 4 <= i < 7:
                        # sections in second column
                        column_two_blocks.append(sections[i])
                    else:
                        # sections in third column
                        column_three_blocks.append(sections[i])
                blocks = [column_one_blocks, column_two_blocks,
                          column_three_blocks]
                description = ""
                if jsond[s]["description"]:
                    description = jsond[s]["description"]

                image_url = ""
                if jsond[s]["image_url"]:
                    image_url = jsond[s]["image_url"]

                product["url_heading"] = url_heading
                product["image_url"] = image_url
                product["description"] = description
                product["link_img"] = link_img
                if product_image:
                    product["base64"] = product_image[
                        "img_product"].encode("base64")
                else:
                    product["base64"] = ""
                product["logo"] = logo
                product["new_image"] = new_product_image
                product["product_name"] = product_name
                product["blocks"] = blocks
                product["newrecipe"] = jsond[s]["newrecipe"]
                products.append(product)
            products_array = []
            for p_obj in products:
                composition_length = 0
                daily_serving_length = 0
                composition_stack = 0
                analytics_stack = 0
                sections = p_obj["blocks"][1]
                for k, sectn in enumerate(sections):
                    fields = sectn["fields"]
                    for f in range(len(fields)):
                        if fields[f]["value"] is not None:
                            if isinstance(fields[f]["value"],
                                          (int, float)):
                                fields[f]["value"] = str(fields[f]["value"])

                            value_length = len(fields[f]["value"])
                            name_length = len(fields[f]["label"])
                            # Composition fields length
                            if k == 0:
                                composition_length += value_length + \
                                                      name_length

                            # suggested daily serving fields length
                            elif k == 2:
                                daily_serving_length += value_length + \
                                                        name_length
                    if k == 0:
                        composition_stack = len(fields)
                        # set font size for compost field value
                        if composition_length > 700:
                            sections[k]["font_size"] = "15px"
                        elif composition_length > 500:
                            sections[k]["font_size"] = "16px"
                        else:
                            sections[k]["font_size"] = "17px"
                    if k == 1:
                        analytics_stack = len(fields)
                    if k == 2:
                        # set font size for suggested daily serving field value
                        if daily_serving_length > 400:
                            sections[k]["font_size"] = "15px"
                        else:
                            sections[k]["font_size"] = "16px"
                # composition_stack -- length of the composition array
                # analytics_stack -- length of constituents array
                stack_compare = (composition_stack > 20 or
                                 analytics_stack > 10
                                 or (
                                      composition_stack > 10 and
                                      analytics_stack > 8)
                                 )
                product_sub = []

                # composition_length - no.of characters in Composition fields
                # daily_serving_length - no.of characters in suggested serving
                if (composition_length > 750 and (
                        daily_serving_length > 400)) or (
                        composition_length > 1250) or (
                        daily_serving_length > 650) or (
                        composition_length > 1200 and (
                        daily_serving_length > 180)) or ( stack_compare):
                    temp_products = deepcopy(p_obj)
                    splice_list = []
                    if composition_length > 2000:
                        compostion_blocks = p_obj['blocks'][1].pop(0)
                        # pop first section of second column and append
                        # first section to first page and last two sections to
                        # duplicate page
                        temp_products['blocks'][1] = p_obj['blocks'][1]
                        p_obj[i]['blocks'][1] = [compostion_blocks]
                    else:
                        # pop the last section from the second column of pdf
                        daily_serving_block = p_obj[
                                                'blocks'][1].pop(2)

                        # duplicate the product & append only this last section
                        #  and generate as new product page
                        temp_products['blocks'][1] = [daily_serving_block]

                    products_array.append(p_obj)
                    products_array.append(temp_products)
                else:
                    products_array.append(p_obj)
            content = content.render(products=products_array)
            if multiple_pdf:
                temp_file_name = "/tmp/detailpdf" + "multiple_pdf.html"
            else:
                temp_file_name = "/tmp/detailpdf" + brand_name + pet_type
                temp_file_name += wet_or_dry + ".html"
            with io.open(temp_file_name, "w",
                         encoding="utf-8") as changed:
                changed.write(content)
                changed.close()
            pdfkit.from_file(temp_file_name, file_path, options=options)
            if os.path.exists(temp_file_name):
                os.remove(temp_file_name)
        except Exception as e:
            logger.findaylog(""" @ 898 EXCEPTION - models - recipes -
                             pdf_html_template """ + str(e))
            raise e
        logger.addinfo("@ models - recipes - pdf_html_template(-)")
        return "success"

    @staticmethod
    def split_array(arr, size):
        arrs = []
        while len(arr) > size:
            pice = arr[:size]
            arrs.append(pice)
            arr = arr[size:]
        arrs.append(arr)
        return arrs

    # To Get Product Image
    @staticmethod
    def get_product_image(product_id):
        logger.addinfo("@ models - recipes - get_product_image(+)")
        has_image = False
        product_image_details = {}
        try:
            base64_image = ""
            product_url = os.environ["IMAGE_URL"]
            product_url += product_id + ".png"
            r = requests.get(product_url)
            if r.status_code == 200:
                has_image = True
                product_image = urllib.request.urlopen(product_url)
                base64_image = product_image.read()
            product_image_details["img_product"] = base64_image
            product_image_details["has_image"] = has_image
        except requests.exceptions.ConnectionError as e1:
            logger.findaylog(""" @ 936 EXCEPTION - models - recipes -
                                       get_product_image""" + str(e1))
            product_image_details["img_product"] = ''
            product_image_details["has_image"] = False
            return product_image_details
        except Exception as e:
            logger.findaylog(""" @ 942 EXCEPTION - models - recipes -
                           get_product_image""" + str(e))
            # Recipes.send_log("get_product_image", e.message,
            #                  {"Products_id": product_id})
            raise e
        logger.addinfo("@ models - recipes - get_product_image(-)")
        return product_image_details

    # To Get File Path with file name
    @staticmethod
    def get_file_path(jsond):
        logger.addinfo(" @ models - recipes - get_file_path(+)")
        try:
            if jsond["language"] == "I":
                language = "IT"
            elif jsond["language"] == "F":
                language = "FR"
            else:
                language = jsond["language"]
            filename = jsond["brand_name"].split(" ")
            filename = "_".join(filename)
            filename += "_" + jsond["pet_type"]
            filename += "_" + jsond["wet_or_dry"]
            filename += "_" + language
            if not os.path.exists(jsond["path"]):
                os.makedirs(jsond["path"])
            file_path = jsond["path"] + filename + ".pdf"
        except Exception as e:
            logger.findaylog(""" @ 970 EXCEPTION models - recipes -
                            get_file_path """ + str(e))
            # Recipes.send_log("get_file_path", e.message, jsond)
            raise e
        logger.addinfo("@ models - recipes - get_file_path(-)")
        return file_path

    # To get translation for download high resolution
    def get_download_text(self, language):
        logger.addinfo("@ models - recipes - get_download_text(+)")
        try:
            if language == "D":
                url_heading = self.sql_file["d_url_heading"]
            elif language == "US":
                url_heading = self.sql_file["us_url_heading"]
            elif language == "F":
                url_heading = self.sql_file["f_url_heading"]
            else:
                url_heading = self.sql_file["I_url_heading"]
        except Exception as e:
            logger.findaylog(""" @ 990 EXCEPTION - models - recipes
                           get_download_text - """ + str(e))
            # Recipes.send_log("get_download_text", e.message,
            #                  {"language": language})
            raise e
        logger.addinfo("@ models - recipes - get_download_text(-)")
        return url_heading

    # to summary formatted data
    @staticmethod
    def new_pdf_format_data(data, language_id):
        logger.addinfo("@ models - recipes - new_pdf_format_data(+)")
        try:
            translate_dict = Recipes.translate_words(language_id)
            # get segment ids
            segment_ids = list({d["segment_id"] for d in data})
            segment_list = []
            for sid in segment_ids:
                for item in data:
                    if sid == item["segment_id"]:
                        segment_details = {"brand_name": item["brand_name"]}
                        segment_image = Recipes.get_segment_image(
                            item["segment_id"])
                        if segment_image:
                            segment_details["brand_logo"] = segment_image[
                                "img_segment"].encode(
                                "base64")
                        else:
                            segment_details["brand_logo"] = None
                        storage = []
                        if item["shell_life"]:
                            storage.append({"label": "",
                                            "value": item["shell_life"]})
                        else:
                            storage.append({"label": " ",
                                            "value": " "})
                        language = []
                        if item["languages"]:
                            language.append({"label": "",
                                             "value": item["languages"]})
                        else:
                            language.append({"label": " ",
                                             "value": " "})
                        single_pack = []
                        if item["packaging"]["single"] and \
                                len(item["packaging"]["single"]) > 0:
                                d = item["packaging"]["single"][0]
                                single_pack.append({"label": translate_dict[
                                    "PACKAGING_TYPE"],
                                                    "value": d["package_type"]}
                                                   )
                                single_pack.append({"label": translate_dict[
                                    "NET_WEIGHT"],
                                                    "value": ' '.join([
                                                        str(d["weight"]),
                                                        d["weight_uom"]])})
                                single_pack.append({"label": (translate_dict[
                                                                 "HEIGHT"] +
                                                              "(" + d[
                                                                 "package_uom"]
                                                              + ")"),
                                                    "value": str(d["height"])})
                                single_pack.append({"label": (translate_dict[
                                                                 "WIDTH"] +
                                                              "(" + d[
                                                                 "package_uom"]
                                                              + ")"),
                                                    "value": str(d["width"])})
                                single_pack.append({"label": (translate_dict[
                                                                 "LENGTH"] +
                                                              "(" + d[
                                                                 "package_uom"]
                                                              + ")"),
                                                    "value": str(d["length"])})
                        else:
                            single_pack.append({"label": " ", "value": " "})
                        multi_pack = []
                        if item["packaging"]["multi"] and \
                                len(item["packaging"]["multi"]) > 0:
                            d = item["packaging"]["multi"][0]
                            multi_pack.append(
                                {"label": translate_dict[
                                                        "PIECES_PER_CARTON"],
                                 "value": str(d["pz_carton"])
                                 })
                            multi_pack.append(
                                {"label": translate_dict[
                                              "CARTON_WEIGHT"] + "(" + d[
                                              "weight_uom"] + ")",
                                 "value": str(d["weight"])
                                 })
                            multi_pack.append(
                                {
                                    "label": translate_dict[
                                                "CARTON_PER_PALLET"],
                                    "value": str(d["cartons_per_pallet"])
                                })
                            multi_pack.append(
                                {
                                    "label": translate_dict[
                                                 "HEIGHT_PALLET"
                                             ] + "(" + d[
                                                 "package_uom"] + ")",
                                    "value": str(d["pallet_height"])
                                })
                            multi_pack.append(
                                {
                                    "label": translate_dict[
                                        "CARTONS_PER_LAYER"],
                                    "value": str(d["cartons_per_layer"])
                                })
                            multi_pack.append(
                                {
                                    "label": translate_dict[
                                        "LAYERS_PER_PALLET"],
                                    "value": str(d["layers_per_pallet"])
                                })
                            multi_pack.append(
                                {
                                    "label": translate_dict[
                                                 "CARTON(LONG_SIDE)"
                                             ] + "(" + d[
                                                 "package_uom"] + ")",
                                    "value": str(d["length"])
                                })
                            multi_pack.append(
                                {
                                    "label": translate_dict[
                                                 "CARTON(SHORT_SIDE)"
                                             ] + "(" + d[
                                                 "package_uom"] + ")",
                                    "value": str(d["width"])
                                })
                            multi_pack.append(
                                {
                                    "label": translate_dict[
                                                 "CARTON(HEIGHT)"
                                             ] + "(" + d[
                                                 "package_uom"] + ")",
                                    "value": str(d["height"])
                                })
                            multi_pack.append(
                                {
                                    "label": translate_dict[
                                                 "PACKAGING_TYPE"] + "(ct)",
                                    "value": d["carton_package_type"]
                                })
                        else:
                            multi_pack.append({"label": " ",
                                               "value": " "})
                        manufacture = list()
                        manufacture.append({"label": " ",
                                            "value": item["manufacturer_name"]
                                            if item[
                                                "manufacturer_name"]
                                            else " "
                                            })
                        manufacture.append({"label": " ",
                                            "value": item[
                                                "manufacturer_website"]
                                            if item[
                                                "manufacturer_website"]
                                            else " "
                                            })
                        daily_serving = []
                        if (item.get("product_serving", None) and
                                len(item["product_serving"]) > 0 and
                                item["product_serving"][0][
                                    "legacy_value"] != ''):
                            daily_serving.append({"label": "",
                                                  "value":
                                                      item["product_serving"][
                                                          0][
                                                          "legacy_value"]})
                        elif item.get("segment_serving", None) and \
                                len(item["segment_serving"]) > 0 and \
                                item["segment_serving"][0][
                                    "legacy_value"] != '':
                            daily_serving.append({"label": "",
                                                  "value":
                                                      item["segment_serving"][
                                                          0][
                                                          "legacy_value"]})
                        else:
                            daily_serving.append({"label": " ", "value": " "})
                        sections = [{"label": translate_dict["STORAGE"],
                                     "fields": storage,
                                     "field_name": "storage"
                                     },
                                    {"label": translate_dict["LANGUAGES"],
                                     "fields": language,
                                     "field_name": "languages"
                                     },
                                    {"label": translate_dict[
                                                    "SUGGESTED_DAILY_SERVING"],
                                     "fields": daily_serving,
                                     "field_name": "daily_serving"
                                     },
                                    {
                                        "label": translate_dict[
                                                "TECHNICAL_DATA_SINGLE_PACK"],
                                        "fields": single_pack,
                                        "field_name": "single_pack"
                                    },
                                    {"label": translate_dict[
                                                "TECHNICAL_DATA_MULTI_PACK"],
                                     "fields": multi_pack,
                                     "field_name": "multi_pack"
                                     },
                                    {"label": translate_dict["MADE_IN"],
                                     "fields": [
                                         {"label": translate_dict["MADE_IN"],
                                          "value": item["made_in"]
                                          }],
                                     "field_name": "made_in"
                                     },
                                    {"label": translate_dict["MANUFACTURER"],
                                     "fields": manufacture,
                                     "field_name": "manufacturer"
                                     }]

                        segment_details["sections"] = sections
                        if "segment_image_url" in item:
                            segment_details["segment_image_url"] = item[
                                "segment_image_url"
                            ]
                        else:
                            segment_details["segment_image_url"] = ""
                        segment_list.append({
                            "segment_id": sid,
                            "segments": segment_details,
                            "products": []
                        })
                        break

            for segment in segment_list:
                for d in data:
                    if segment["segment_id"] == d["segment_id"] and \
                            d["item_code"] not in segment["products"]:
                        obj = {"product_id": d["item_code"],
                               "product_description": d["product_description"],
                               "image_url": (d["images"][0]
                                             if d["images"] else "")}
                        details = [{"label": (translate_dict[
                                                        "PRODUCT_CODE"]).upper(),
                                    "value": d["item_code"]},
                                   {"label": (translate_dict["EAN"]).upper(),
                                    "value": d["ean_code"]},
                                   {"label": (translate_dict["BARCODE"]).upper(),
                                    "value": d["bar_code"]},
                                   {"label": (translate_dict["WEIGHT"]).upper(),
                                    "value": (" ".join([str(d["packaging"][
                                        "single"][0]["weight"]),d["packaging"]["single"][
                                            0]["weight_uom"]]))
                                    if (d["packaging"]["single"] and
                                        len(d["packaging"]["single"]) > 0)
                                    else " "},
                                   {"label": (translate_dict[
                                                        "PIECES_PER_CARTON"]).upper(),
                                    "value": d["packaging"][
                                                    "multi"][0]["pz_carton"]
                                    if (d["packaging"]["multi"] and
                                        len(d["packaging"][
                                               "multi"]) > 0)
                                    else " "},
                                   {"label": translate_dict["TYPE"],
                                    "value": d["type_description"]},
                                   {"label": translate_dict[
                                       "PRODUCT_NAME"],
                                    "value": d["product_name"]}]
                        obj["details"] = details
                        obj["energy"] = {"label": translate_dict[
                                                            "ENERGY_VALUE"],
                                         "value": d["energy"]
                                         if d["energy"]
                                         else " "
                                         }
                        obj["composition"] = {"label": translate_dict[
                                                                "COMPOSITION"],
                                              "value": " "}
                        if d["ingredients"]:
                            for k in d["ingredients"]:
                                if isinstance(k, dict):
                                    name = k["name"][:1].upper() + k["name"][1:]
                                    obj["composition"][
                                        "value"] += " ".join(
                                                              [name,
                                                               str(k["percent"]
                                                                   )
                                                               ]
                                                             ) + ", "
                                else:
                                    name = k[:1].upper() + k[1:]
                                    obj["composition"]["value"] += name + ", "

                        obj["constituents"] = {"label": translate_dict[
                                                    "ANALYTICAL_CONSTITUENTS"],
                                               "value": " "}
                        if d["constituents"]:
                            for val in d["constituents"]:
                                name = val["name"][:1].upper() + val["name"][1:]
                                if val['percent'] != '' and val['percent'] is not None:
                                    obj["constituents"]["value"] += " ".join(
                                                            [name,
                                                             str(val["percent"]
                                                                 )
                                                             ]) + "%, "
                                else:
                                    obj["constituents"]["value"] += " ".join(
                                                            [name,
                                                             str(val["percent"]
                                                                 )
                                                             ]) + ", "
                        segment["products"].append(obj)
        except Exception as e:
            logger.findaylog("""@ 1294 EXCEPTION - models - recipes -
                             new_pdf_format_data""" + str(e))
            # Recipes.send_log("new_pdf_format_data", e.message,
            #                  {"language": language_id})
            raise e
        logger.addinfo("@ models - recipes - new_pdf_format_data(-)")
        return segment_list, translate_dict

    # To set header details in summary pdf
    @staticmethod
    def get_header(product, base64_image, brand_logo):
        logger.addinfo("@ models - recipes - get_header(+)")
        header_details = {}
        try:
            header_details["product_image"] = base64_image
            header_details["brand_image"] = brand_logo
            header_details["product_description"] = ""
            if product["product_description"]:
                description = product["product_description"]
                header_details["product_description"] = description
        except Exception as e:
            logger.findaylog(""" @ 1315 EXCEPTION - models - recipes -
                           get_header """ + str(e))
            # Recipes.send_log("get_header", e.message,
            #                  {"product": product})
            raise e
        logger.addinfo("@ models - recipes - get_header(-)")
        return header_details

    # To build table with product details
    def build_products(self, products, brand_name, brand_logo,
                       translate_dict):
        logger.addinfo("@ models - recipes - build_products(+)")
        product_page = {"product_tables": [], "header_details": ""}
        set_header_description = False
        try:
            barcodes_path = self.sql_file["barcodes_path"]
            product_html_tables = []

            for j in range(len(products)):
                bar_code = ""
                product_html_table = {}
                product_image_details = Recipes.get_product_image(
                    products[j]["product_id"])
                if product_image_details:
                    base64_image = product_image_details[
                        "img_product"].encode("base64")
                else:
                    base64_image = ""
                product_html_table[
                    "img_product"] = base64_image
                if product_image_details["has_image"] and \
                        products[j]["product_description"] and \
                        not set_header_description:
                    product_page["header_details"] = Recipes.get_header(
                        products[j], base64_image,
                        brand_logo)
                    set_header_description = True
                if j == len(products) - 1 and not set_header_description:
                    product_page["header_details"] = Recipes.get_header(
                        products[j],
                        base64_image, brand_logo)
                header_row = []
                value_row = []

                # build products table
                product_range_name = brand_name + " - "
                product_index = [d["label"]
                                 for d in products[j]["details"]].index(
                    translate_dict["PRODUCT_NAME"]
                )
                if product_index != -1 and \
                        products[j]["details"][
                            product_index]["value"] is not None:
                    product_range_name += products[j]["details"][
                        product_index]["value"]
                product_html_table["product_range_name"] = product_range_name
                for i in range(len(products[j]["details"])):
                    block = products[j]["details"][i]
                    field_label = block["label"]
                    if block["label"] == translate_dict["PRODUCT_NAME"] or block["label"] == translate_dict["TYPE"]:
                        break
                    if block["value"] is not None:
                        field_value = block["value"]
                        # generate barcode with EAN field value
                        if block["label"] == translate_dict["EAN"]:
                            bar_code = Recipes.generate_barcode(field_value,
                                                                barcodes_path)
                    else:
                        field_value = ""
                    header_row.append(field_label)
                    value_row.append(field_value)
                product_html_table["header_row"] = header_row
                product_html_table["value_row"] = value_row
                if bar_code:
                    product_html_table["bar_code"] = bar_code
                else:
                    product_html_table["bar_code"] = ""
                composition_value = ""
                # [Composition, Analytical constituents, Energy value]
                composition_ids = ["composition", "constituents", "energy"]
                for i in composition_ids:
                    line = products[j][i]
                    composition_value += "<b>" + line["label"] + ":</b>"
                    composition_value += line["value"]
                product_html_table["composition_value"] = composition_value
                product_html_tables.append(product_html_table)
            product_page["product_tables"] = product_html_tables
        except Exception as e:
            logger.findaylog(""" @ 1402 EXCEPTION - models - recipes -
                             build_products """ + str(e))
            # Recipes.send_log("build_products", e.message,
            #                  {"products": products,
            #                   "brand": brand_name})
            raise e
        logger.addinfo("@ models - recipes - build_products(-)")
        return product_page

    # to build table for Segments
    @staticmethod
    def build_segments(segments):
        logger.addinfo("@ models - recipes - build_segments(+)")
        segment_tables = []
        try:
            # Order of the segments details
            segment_ids = ["storage", "languages", "daily_serving",
                           "single_pack", "multi_pack", "made_in",
                           "manufacturer"]
            for i in range(len(segment_ids)):
                segment_table = {"segment_label": "",
                                 "segment_index": i,
                                 "segment_value": ""
                                 }
                packaging_data = []
                for j in range(len(segments)):
                    if str(segments[j]["field_name"]) == str(segment_ids[i]):
                        segment_table["segment_label"] = (segments[j]["label"])
                        if segment_ids[i] == "multi_pack":
                            # Append field label and value to rows if
                            # segment is Technical data packaging
                            # index refers row number in table
                            for row in segments[j]["fields"]:
                                if row["label"] is not None:
                                    label = "<b>"
                                    label += row["label"]
                                    label += "</b>"
                                else:
                                    label = ""
                                if row["value"] is not None:
                                    value = row["value"]
                                else:
                                    value = ""
                                packaging_data.append(label)
                                packaging_data.append(value)
                            segment_table[
                                "segment_value"] = packaging_data
                        elif segment_ids[i] == "single_pack":
                            # Add field label if segment is
                            # Technical data single pack
                            for row in segments[j]["fields"]:
                                if row["label"] != " " and \
                                        row["value"] != " ":
                                    segment_table["segment_value"] += \
                                        row["label"] \
                                        + ": " \
                                        + row["value"]
                                    segment_table[
                                        "segment_value"] += "    "
                        else:
                            if len(segments[j]["fields"]) > 0:
                                for row in segments[j]["fields"]:
                                    if segment_ids[i] == "manufacturer":
                                        segment_table[
                                            "segment_value"] += "<b>" + \
                                                                row[
                                                                    "value"] \
                                                                + "</b>" + \
                                                                "<br>"
                                    else:
                                        segment_table[
                                            "segment_value"] += row[
                                            "value"]
                            segment_table["segment_value"] += " "
                segment_tables.append(segment_table)
        except Exception as e:
            logger.findaylog(""" @ 1478 EXCEPTION - models - recipes -
                           build_segments""" + str(e))
            # Recipes.send_log("build_segments", e.message, {
            #     "segments": segments})
            raise e
        logger.addinfo("@ models - recipes - build_segments(-)")
        return segment_tables

    def new_pdf_html_template(self, segment_details, brand_name, pet_type,
                              wet_or_dry, language, content, translate_dict,
                              multiple_pdf = None):
        logger.addinfo("@ models - recipes - new_pdf_html_template(+)")
        try:
            if multiple_pdf:
                file_path = self.sql_file["new_pdf_path"] + multiple_pdf
            else:
                file_obj = {"language": language, "pet_type": pet_type,
                            "brand_name": brand_name,
                            "path": self.sql_file["new_pdf_path"],
                            "wet_or_dry": wet_or_dry}
                file_path = Recipes.get_file_path(file_obj)
            products_page_content = content["products_content"]
            footer_content = content["footer_content"]
            header_name = content["header_name"]

            segments = []
            for k in range(len(segment_details)):
                segment = {"image_link": "", "brand_logo": ""}
                if len(segment_details[k]["products"]) > 0:
                    products = segment_details[k]["products"]
                    if segment_details[k]["segments"]:
                        segment["brand_logo"] = segment_details[k][
                            "segments"]["brand_logo"]
                        segment["segment_image"] = True
                        if segment["image_link"] == "" or \
                                segment["image_link"] is None:
                            segment["image_link"] = segment_details[k][
                                "segments"][
                                "segment_image_url"]

                    if segment["brand_logo"] is None or \
                            segment["brand_logo"] == "":
                        segment["brand_logo"] = self.sql_file[
                            "almo_nature_logo"]
                        segment["segment_image"] = False
                    # build products tables
                    products_page = self.build_products(products,
                                                        segment_details[k]['segments'][
                                                                    'brand_name'],
                                                        segment["brand_logo"],
                                                        translate_dict)
                    # has brand logo and product description
                    segment["header_details"] = products_page["header_details"]

                    segment["product_tables"] = products_page["product_tables"]

                    # build segment tables
                    segment_tables = Recipes.build_segments(
                                                segment_details[k][
                                                    "segments"]["sections"])

                    segment["segment_tables"] = segment_tables
                    segment["download_text"] = self.get_download_text(language)

                    # append each product and segment page to segments
                    segments.append(segment)
            obj = {
                "segments": segments,
                "page_content": products_page_content
            }
            if multiple_pdf:
                temp_file_name = "/tmp/summarypdf" + "multiple_products"
                footer_file_name = "/tmp/pdffooter" + "multiple_products"
            else:
                temp_file_name = "/tmp/summarypdf" + brand_name
                temp_file_name += wet_or_dry + pet_type
                footer_file_name = "/tmp/pdffooter" + brand_name
                footer_file_name += wet_or_dry + pet_type
            obj["file_name"] = temp_file_name
            obj["footer_file_name"] = footer_file_name
            obj["footer_content"] = footer_content
            obj["header_name"] = header_name
            obj["file_path"] = file_path
            Recipes.write_to_file(obj)
        except Exception as e:
            logger.findaylog(""" @ 1552 EXCEPTION - models - recipes -
                             new_pdf_html_template """ + str(e))
            raise e
        logger.addinfo("@ models - recipes - new_pdf_html_template(-)")
        return "success"

    @staticmethod
    def write_to_file(obj):
        logger.addinfo("@ models - recipes - write_to_file(+)")
        try:

            segments = obj["segments"]
            products_page_content = obj["page_content"]
            output_file = PdfFileWriter()
            options = {
                "page-size": "A4",
                "margin-top": "10mm",
                "margin-bottom": "24mm",
                "margin-left": "0mm",
                "margin-right": "0mm",
                "quiet": "",
                "encoding": "utf-8",
                "header-html": obj["header_name"],
                "header-spacing": "2",
                "footer-spacing": "8"
            }
            for i in range(len(segments)):
                content = products_page_content.render(
                    segment=segments[i])
                html_file_name = obj["file_name"] + str(i) + ".html"
                pdf_name = obj["file_name"] + str(i) + ".pdf"
                footer_file_name = obj["footer_file_name"] + str(i) + ".html"

                footer_content = obj["footer_content"].render(
                    download_text=segments[i][
                        "download_text"],
                    image_link=segments[i]["image_link"])
                # write footer html file
                with io.open(
                        footer_file_name, "w", encoding="utf-8") as footer:
                    footer.write(footer_content)
                    footer.close()
                options["footer-html"] = footer_file_name
                with io.open(html_file_name, "w", encoding="utf-8") as changed:
                    changed.write(content)
                    changed.close()
                pdfkit.from_file(html_file_name, pdf_name, options=options)
                file_reader = PdfFileReader(open(pdf_name, "rb"))
                no_of_pages = file_reader.getNumPages()
                for j in range(0, no_of_pages):
                    output_file.addPage(file_reader.getPage(j))

                if os.path.exists(html_file_name):
                    os.remove(html_file_name)
                if os.path.exists(pdf_name):
                    os.remove(pdf_name)
                if os.path.exists(footer_file_name):
                    os.remove(footer_file_name)
            output_file.write(open(obj["file_path"], "w"))

        except Exception as e:
            logger.findaylog(""" @ 1615 EXCEPTION - recipes - models -
                             write_to_file """ + str(e))
            raise e
        logger.addinfo("@ models - recipes - write_to_file(-)")
        return "success"

    # to search items of copia commissione
    def search_copia_details(self, jsond):
        logger.addinfo("@models - recipes - search_copia(+)")
        try:
            ids = jsond["key"]
            data = []
            for item in ids:
                keys = Recipes.decode_value(item) + ":*:" + jsond["language"]
                for key in self.redis.keys(keys):
                    details = self.redis.hgetall(key)
                    if 'images' in details:
                        details['images'] = ujson.loads(details['images'])
                    else:
                        details['images'] = ''
                    if 'constituents' in details:
                        details['constituents'] = ujson.loads(
                            details['constituents'])
                    else:
                        details['constituents'] = []
                    if 'packaging' in details:
                        details['packaging'] = ujson.loads(details[
                                                           'packaging'])
                    else:
                        details['packaging'] = {}
                    if 'ingredients' in details:
                        details['ingredients'] = ujson.loads(
                                details['ingredients'])
                    else:
                        details['ingredients'] = []
                    data.append(details)
        except Exception as e:
            logger.findaylog(""" @ 1641 EXCEPTION - recipes - models -
                             search_copia """ + str(e))
            raise e
        logger.addinfo("@ models - recipes - search_copia(-)")
        return data

    # To Get Segment Image
    @staticmethod
    def get_segment_image(segment_id):
        logger.addinfo("@ models - recipes - get_segment_image(+)")
        segment_image_details = {}
        base64img = ""
        try:
            segment_url = os.environ["IMAGE_URL"] + "segments/"
            segment_url += segment_id + ".png"
            r = requests.get(segment_url)
            if r.status_code == 200:
                segment_image = urllib.request.urlopen(segment_url)
                base64img = segment_image.read()
            segment_image_details["img_segment"] = base64img
        except requests.exceptions.ConnectionError as e1:
            logger.findaylog("""@ 1661 EXCEPTION - models - recipes -
                             get_segment_image""" + str(e1))
            segment_image_details["img_segment"] = ''
            return segment_image_details
        except Exception as e:
            logger.findaylog(""" @ 1668 EXCEPTION - models - recipes -
                           get_segment_image""" + str(e))
            # Recipes.send_log("get_segment_image", e.message,
            #                  {"segment_id": segment_id})
            raise e
        logger.addinfo("@ models - recipes - get_segment_image(-)")
        return segment_image_details

    # to upload image in local
    @staticmethod
    def insert_image(type_id, image, blocktype):
        logger.addinfo('@ models - recipes - insert_image(+)')
        try:
            if blocktype == 'segment':
                path_variable = 'IMAGE_SFTP_SEGMENTS_PATH'
            else:
                path_variable = 'IMAGE_SFTP_PATH'
            path = os.environ[path_variable]
            image_file = open(path + str(type_id) + '.png', 'w')
            image_file.write(image.decode('base64'))
            image_file.close()
            Recipes.upload_image(type_id, path_variable)
        except Exception as e:
            logger.findaylog(""" @ 1691 EXCEPTION - modesl - recipes -
                             insert_image """ + str(e))
            raise e
        logger.addinfo('@ models - recipes - insert_image(-)')

    @staticmethod
    def upload_image(type_id, path_variable):
        logger.addinfo('@ models - recipes - upload_image(+)')
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            host = os.environ['IMAGE_SFTP_HOST']
            username = os.environ['IMAGE_SFTP_USER']
            key_file_path = os.environ['IMAGE_SFTP_KEY']
            key = paramiko.RSAKey.from_private_key_file(key_file_path)
            path = os.environ[path_variable]
            port = os.environ['IMAGE_SFTP_PORT']
            client.connect(host, int(port), username=username, pkey=key)
            sftp = client.open_sftp()
            local_path = path + str(type_id) + '.png'
            remote_path = path + str(type_id) + '.png'
            sftp.put(local_path, remote_path)
            sftp.close()
        except Exception as e:
            logger.findaylog(""" @ 1720 EXCEPTION - models - recipes -
                             upload_image """ + str(e))
            raise e
        logger.addinfo('@ models - recipes - upload_image(-)')
        return 'success'

    def save(self, jsond):
        logger.addinfo('@ models - recipes - save(+)')
        try:
            if jsond['type'] == 'product':
                result = self.save_product(jsond)
            else:
                result = self.save_segment(jsond)
        except Exception as e:
            logger.findaylog(""" @ 1738 EXCEPTION - models - recipes -
                             save """ + str(e))
            raise e
        logger.addinfo('@ models - recipes - save(-)')
        return result

    def save_product(self, jsond):
        logger.addinfo('@ models - recipes - save_product(+)')
        ingredient_name = []
        ingredient_percent = []
        constituent_name = []
        constituent_percent = []
        constituent_ids = []
        ingredient_ids = []
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            legacy_value = jsond['product_serving'][0]['legacy_value']
            serving_id = jsond['product_serving'][0]['serving_id']
            if 'product_image' in jsond:
                Recipes.insert_image(jsond['item_code'],
                                     jsond['product_image'],
                                     'product')
            for i in range(len(jsond['ingredients'])):
                ingredient_name.append(jsond['ingredients'][i]['name'])
                if jsond['ingredients'][i]['percent']:
                    ingredient_percent.append(
                        float(jsond['ingredients'][i]['percent']))
                else:
                    ingredient_percent.append(float(0))
                if 'ingredient_id' in jsond['ingredients'][i]:
                    ingredient_ids.append(
                        jsond['ingredients'][i]['ingredient_id'])
                else:
                    ingredient_ids.append(9999999)
            for i in range(len(jsond['constituents'])):
                constituent_name.append(jsond['constituents'][i]['name'])
                if jsond['constituents'][i]['percent']:
                    constituent_percent.append(
                        float(jsond['constituents'][i]['percent']))
                else:
                    constituent_percent.append(float(0))
                if 'constituent_id' in jsond['constituents'][i]:
                    constituent_ids.append(
                        jsond['constituents'][i]['constituent_id'])
                else:
                    constituent_ids.append(9999999)
            keywords = ''
            if jsond['item_description']:
                keywords = jsond['item_description'].replace(' ', ',')
            self.cursor.execute("""
                DECLARE\
                    recipe_lines
                        qpex_products_pkg.recipe_ingredients_type_cover;\
                    constituent_lines
                        qpex_products_pkg.recipe_constituents_type_cover;\
                    product_serving
                        QPEX_PRODUCTS_PKG.recipe_serving_rec_type;\

                    type number_table_t is table of number
                        index by binary_integer;\
                    type string_table_t is table of nvarchar2(1000)
                        index by binary_integer;\

                    d_ingre_name string_table_t := :p_ingredient_names;
                    d_ingre_percent number_table_t := :p_ingredient_percent;
                    d_ingre_ids number_table_t := :p_ingredient_ids;
                    d_const_name string_table_t := :p_constituent_name;
                    d_const_percent number_table_t := :p_constituent_percent;
                    d_const_ids number_table_t := :p_constituent_ids;
                BEGIN
                    product_serving.serving_id := :p_serving_id;
                    product_serving.reference_id := :p_reference_id;
                    product_serving.reference_type := :p_reference_type;
                    product_serving.legacy_value := :p_legacy_value;
                    product_serving.food_type := :p_food_type;
                    product_serving.pet_type := :p_pet_type;

                    for i in 1..d_ingre_name.count
                    LOOP
                        recipe_lines(i).name := d_ingre_name(i);
                        recipe_lines(i).percent := d_ingre_percent(i);
                        recipe_lines(i).ingredient_id := d_ingre_ids(i);
                    END LOOP;\
                    for i in 1..d_const_name.count
                    LOOP
                        constituent_lines(i).name := d_const_name(i);
                        constituent_lines(i).percent := d_const_percent(i);
                        constituent_lines(i).constituent_id := d_const_ids(i);
                    END LOOP;\

                    qpex_products_pkg.insert_product(
                        :p_brand_id,
                        :p_segment_id,
                        :p_inventory_item_id,
                        :p_item_code,
                        :p_pet_type,
                        :p_food_type,
                        :p_type_description,
                        :p_new_recipe,
                        :p_ean_code,
                        :p_bar_code,
                        :p_energy,
                        :p_language,
                        :p_item_description,
                        :p_product_name,
                        :p_product_description,
                        :p_keywords,
                        :p_generate_pdf,
                        recipe_lines,
                        :p_image_url,
                        constituent_lines,
                        product_serving,
                        :p_created_by,
                        :p_weight,
                        :p_segment_range,
                        :p_made_in,
                        :p_producer,
                        :x_status_code
                    );
                END;
            """, p_brand_id=jsond['brand_id'],
                                p_segment_id=jsond['segment_id'],
                                p_inventory_item_id=jsond['inventory_item_id'],
                                p_item_code=jsond['item_code'],
                                p_pet_type=jsond['pet_type'],
                                p_food_type=jsond['food_type'],
                                p_type_description=jsond['type_description'],
                                p_new_recipe=jsond['new_recipe'],
                                p_ean_code=jsond['ean_code'],
                                p_bar_code=jsond['bar_code'],
                                p_energy=jsond['energy'],
                                p_language=jsond['language'],
                                p_item_description=jsond['item_description'],
                                p_product_name=jsond['product_name'],
                                p_product_description=jsond[
                                    'product_description'],
                                p_keywords=keywords,
                                p_generate_pdf=jsond['generate_pdf'],
                                p_image_url=jsond['image_url'],
                                p_created_by=jsond['created_by'],
                                p_weight=jsond['weight'],
                                p_segment_range=jsond['segment_range'],
                                p_made_in=jsond['made_in'],
                                p_producer = jsond['producer'],
                                x_status_code=status_code,
                                p_ingredient_names=ingredient_name,
                                p_ingredient_percent=ingredient_percent,
                                p_constituent_name=constituent_name,
                                p_constituent_percent=constituent_percent,
                                p_constituent_ids=constituent_ids,
                                p_ingredient_ids=ingredient_ids,
                                p_reference_id=jsond['inventory_item_id'],
                                p_reference_type='product',
                                p_legacy_value=legacy_value,
                                p_serving_id=serving_id)
            if status_code.getvalue() == 'SUCCESS':

                # Load languages lov
                query = self.sql_file['language_query']
                self.cursor.execute(query)
                languages = Code_util.iterate_data(self.cursor)
                for l_index in range(len(languages)):
                    if languages[l_index]['language_id'] is not None:
                        self.update_redis(jsond['inventory_item_id'],
                                          languages[l_index]['language_id'],
                                          jsond['segment_id'],
                                          jsond['brand_id'], sync=False)
        except Exception as e:
            logger.findaylog(""" @ 1899 EXCEPTION - models - recipes -
                             save_product """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - recipes - save_product(-)')
        return status_code.getvalue()

    @staticmethod
    def encode_data(data):
        if isinstance(data, float) or isinstance(data, int):
            data = str(data)
        return data

    def save_segment(self, jsond):
        logger.addinfo('@ models - recipes - save_segment(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            single_names = []
            single_values = []
            serving_id = jsond['segment_serving'][0]['serving_id']
            legacy_value = jsond['segment_serving'][0]['legacy_value']
            if 'segment_image' in jsond:
                Recipes.insert_image(jsond['segment_id'],
                                     jsond['segment_image'],
                                     'segment')
            if 'single_packaging' in jsond:
                for key in jsond['single_packaging']:
                    single_names.append(Recipes.encode_data(key))
                    if jsond['single_packaging'][key]:
                        single_values.append(
                            Recipes.encode_data(jsond['single_packaging'][key]))
                    else:
                        single_values.append('')
            multi_names = []
            multi_values = []
            if 'multi_packaging' in jsond:
                for key in jsond['multi_packaging']:
                    multi_names.append(Recipes.encode_data(key))
                    if jsond['multi_packaging'][key]:
                            multi_values.append(Recipes.encode_data(jsond['multi_packaging'][key]))
                    else:
                        multi_values.append('')
            self.cursor.execute("""
                DECLARE\
                    packaging_lines
                        QPEX_PRODUCTS_PKG.product_packaging_type_cover;\
                    segment_details
                        QPEX_PRODUCTS_PKG.product_segments_rec_type;\
                    type string_table_t is table of nvarchar2(2000)
                        index by binary_integer;\
                    serving_details
                        QPEX_PRODUCTS_PKG.recipe_serving_rec_type;\
                    c number;\

                    d_packaging_single_names
                        string_table_t:= :p_single_names;\
                    d_packaging_single_values
                        string_table_t:= :p_single_values;\
                    d_packaging_multi_names
                        string_table_t:= :p_multi_names;\
                    d_packaging_multi_values
                        string_table_t:= :p_multi_values;\
                    d_names string_table_t;\
                    d_values string_table_t;\

                BEGIN\
                    for c in 1..2
                    LOOP
                        if c = 1 then
                            d_names := d_packaging_single_names;\
                            d_values := d_packaging_single_values;\
                        else
                            d_names := d_packaging_multi_names;\
                            d_values := d_packaging_multi_values;\
                        end if;
                        for i in 1..d_names.count
                        LOOP
                            if ( d_names(i) = 'package_type' ) THEN
                                packaging_lines(c).package_type := d_values(i);
                            ELSIF ( d_names(i) = 'type' ) THEN
                                packaging_lines(c).type := d_values(i);
                            ELSIF ( d_names(i) = 'weight' ) THEN
                                if ( d_values(i) = '' or d_values(i) = null ) then
                                    packaging_lines(c).weight := null;
                                ELSE
                                    packaging_lines(
                                        c).weight := TO_NUMBER(d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'height') THEN
                                if ( d_values(i) = '' or d_values(i) = null) then
                                    packaging_lines(c).height := null;
                                ELSE
                                    packaging_lines(
                                        c).height := TO_NUMBER(d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'width') THEN
                                if ( d_values(i) = '' or d_values(i) = null) then
                                    packaging_lines(c).width := null;
                                ELSE
                                    packaging_lines(
                                        c).width := TO_NUMBER(d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'length') THEN
                                if ( d_values(i) = '' or d_values(i) = null) then
                                    packaging_lines(c).length := null;
                                ELSE
                                    packaging_lines(
                                        c).length := TO_NUMBER(d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'package_uom') THEN
                                packaging_lines(c).package_uom := d_values(i);
                            ELSIF (d_names(i) = 'weight_uom') THEN
                                packaging_lines(c).weight_uom := d_values(i);
                            ELSIF (d_names(i) = 'pz_carton') THEN
                                if ( d_values(i) = '' or d_values(i) = null) then
                                    packaging_lines(c).pz_carton := null;
                                ELSE
                                    packaging_lines(
                                        c).pz_carton := TO_NUMBER(d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'cartons_per_pallet') THEN
                                if ( d_values(i) = '' or d_values(i) = null) then
                                    packaging_lines(c).cartons_per_pallet :=
                                                                        null;
                                ELSE
                                    packaging_lines(
                                        c).cartons_per_pallet := TO_NUMBER(
                                                                 d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'cartons_per_layer') THEN
                                if ( d_values(i) = '' or d_values(i) = null) then
                                    packaging_lines(c).cartons_per_layer :=
                                                                    null;
                                ELSE
                                    packaging_lines(
                                        c).cartons_per_layer := TO_NUMBER(
                                                                d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'layers_per_pallet') THEN
                                if ( d_values(i) = '' or d_values(i) = null) then
                                    packaging_lines(c).layers_per_pallet :=
                                                                        null;
                                ELSE
                                    packaging_lines(
                                        c).layers_per_pallet := TO_NUMBER(
                                                                d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'pallet_height') THEN
                                if ( d_values(i) = '' or d_values(i) = null) then
                                    packaging_lines(c).pallet_height := null;
                                ELSE
                                    packaging_lines(
                                        c).pallet_height := TO_NUMBER(
                                                                d_values(i));
                                end if;\
                            ELSIF (d_names(i) = 'carton_package_type') THEN
                                packaging_lines(c
                                    ).carton_package_type := d_values(i);
                            END IF;
                        END LOOP;\
                    END LOOP;\

                    segment_details.producer := :p_producer;
                    segment_details.made_in := :p_made_in;
                    segment_details.languages := :p_languages;
                    segment_details.manufacturer_name := :p_manufacturer_name;
                    segment_details.manufacturer_address := :p_address;
                    segment_details.segment_name := :p_segment_name;
                    segment_details.description := :p_description;
                    segment_details.shell_life := :p_shell_life;
                    serving_details.pet_type := :p_pet_type;
                    serving_details.food_type := :p_food_type;
                    serving_details.legacy_value := :p_legacy_value;
                    serving_details.reference_type := :p_reference_type;
                    serving_details.reference_id := :p_reference_id;
                    serving_details.serving_id := :p_serving_id;

                    QPEX_PRODUCTS_PKG.insert_segment(
                        :p_brand_id,
                        :p_segment_id,
                        :p_language,
                        :p_image_url,
                        :p_created_by,
                        segment_details,
                        packaging_lines,
                        serving_details,
                        :x_status_code
                    );
                END;
            """, p_brand_id=jsond['brand_id'],
                                p_segment_id=jsond['segment_id'],
                                p_language=jsond['language'],
                                p_image_url=jsond['image_url'],
                                p_created_by=jsond['created_by'],
                                x_status_code=status_code,
                                p_producer=jsond['producer'],
                                p_made_in=jsond['made_in'],
                                p_languages=jsond['languages'],
                                p_manufacturer_name=jsond['manufacturer_name'],
                                p_address=jsond['manufacturer_address'],
                                p_segment_name=jsond['segment_name'],
                                p_description=jsond['description'],
                                p_shell_life=jsond['shell_life'],
                                p_single_names=single_names,
                                p_single_values=single_values,
                                p_multi_names=multi_names,
                                p_multi_values=multi_values,
                                p_pet_type=jsond['pet_type'],
                                p_food_type=jsond['food_type'],
                                p_legacy_value=legacy_value,
                                p_reference_type='segment',
                                p_reference_id=jsond['segment_id'],
                                p_serving_id=serving_id
                                )
            if status_code.getvalue() == 'SUCCESS':
                # Load languages lov
                query = self.sql_file['language_query']
                self.cursor.execute(query)
                languages = Code_util.iterate_data(self.cursor)
                for l_index in range(len(languages)):
                    self.update_redis('', languages[l_index]['language_id'],
                                      jsond['segment_id'],
                                      jsond['brand_id'],sync=False)
        except Exception as e:
            logger.findaylog(""" @ 2125 EXCEPTION - recipes - models -
                              save_segment """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - recipes - save_segment(-)')
        return status_code.getvalue()

    def get_brands(self, language, status):
        logger.addinfo('@ models - recipes - get_brands(+)')
        try:
            self.acquire()
            if status:
                query = self.sql_file['get_brands']
            else:
                query = self.sql_file['brands_query']
            self.cursor.execute(query, p_language=language)
        except Exception as error:
            logger.findaylog("""@ 2144 EXCEPTION - models - recipes -
                 get_brands """ + str(error))
            raise error
        else:
            brands_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                brand = {}
                for index, field in enumerate(field_names):
                    brand[field] = Recipes.decode_value(row[index])
                brands_list.append(brand)
        finally:
            self.release()
        logger.addinfo('@ models - recipes - get_brands(-)')
        return brands_list

    def get_segments(self, brand, language):
        logger.addinfo('@ models - recipes - get_segments(+)')
        try:
            self.acquire()
            query = self.sql_file['segements_brand_query']
            self.cursor.execute(query, p_brand=brand, p_language=language)
        except Exception as error:
            logger.findaylog("""@ 2169 EXCEPTION - models - recipes -
                 get_segments """ + str(error))
            raise error
        else:
            segments_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            data = self.cursor.fetchall()
            for row in data:
                segment = {}
                for index, field in enumerate(field_names):
                    segment[field] = Recipes.decode_value(row[index])
                    if index == 1:
                        c_query = self.sql_file['get_item_count_query']
                        data = self.cursor.execute(c_query,
                                                   p_segement=row[index],
                                                   p_language=language,
                                                   p_brand=brand).fetchone()
                        segment['count'] = data[0]
                segments_list.append(segment)
        finally:
            self.release()
        logger.addinfo('@ models - recipes - get_segments(-)')
        return segments_list

    def get_items(self, segment, language, brand):
        logger.addinfo('@ models - recipes - get_items(+)')
        try:
            self.acquire()
            query = self.sql_file['items_segment_query']
            self.cursor.execute(query, p_segement=segment,
                                p_language=language,
                                p_brand=brand)
        except Exception as error:
            logger.findaylog("""@ 2204 EXCEPTION - models - recipes -
                 get_items """ + str(error))
            raise error
        else:
            items_list = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                item = {}
                for index, field in enumerate(field_names):
                    item[field] = Recipes.decode_value(row[index])
                items_list.append(item)
        finally:
            self.release()
        logger.addinfo('@ models - recipes - get_items(-)')
        return items_list

    def delete_language(self, language_id):
        logger.addinfo('@ models - recipes - delete_language(+)')
        try:
            if language_id:
                self.acquire()
                query = self.sql_file['onboard_delete_language']
                self.cursor.execute(query, p_language_id=language_id)
                status = 'success'
            else:
                status = 'Fails'
        except Exception as error:
            logger.findaylog("""@ 2234 EXCEPTION - models - recipes -
                 delete_language """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo("@ models - recipes - delete_language(-)")
        return status

    def put_language(self, jsond):
        logger.addinfo('@ models - recipes - put_language(+)')
        try:
            self.acquire()
            if jsond['language_id']:
                query = self.sql_file['onboard_update_language']
                query = query.format(jsond['language_id'],
                                     jsond['new_language'],
                                     jsond['language'])
                self.cursor.execute(query)
                status = 'success'
            else:
                status = 'Fails'
        except Exception as error:
            logger.findaylog("""@ 2260 EXCEPTION - models - recipes -
                 put_language """ + str(error))
            raise error
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo("@ models - recipes - put_language(-)")
        return status

    def onboard_language(self, jsond):
        logger.addinfo('@ models - recipes - onboard_language(+)')
        try:
            if jsond:
                self.acquire()
                language = jsond['language']
                language_id = jsond['language_id']
                query = self.sql_file['onboard_save_language']
                self.cursor.execute(query, p_language=language,
                                    p_language_id=language_id)
                self.connection.commit()
            else:
                return 'Fails'
        except Exception as error:
            logger.findaylog("""@ 2284 EXCEPTION - models - recipes -
                 onboard_language """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo("@ models - recipes - onboard_language(-)")
        return 'success'

    def get_brand_animal_food_type(self, brand):
        logger.addinfo("@models - recipes - get_brand_animal_food_type")
        try:
            self.acquire()
            query = self.sql_file['recipes_animal_food_type']
            self.cursor.execute(query, p_brand_name=brand)
        except Exception as error:
            logger.findaylog("""@ 2300 EXCEPTION - models - recipes -
                             get_brand_animal_food_type """ +
                             str(error))
            raise error
        else:
            brand_list = Code_util.iterate_data(self.cursor)

        finally:
            self.release()
        logger.addinfo('@ models - recipes - get_brand_animal_food_type(-)')
        return brand_list

    def update_redis(self, item_code=None, language=None, segment_id=None,
                     brand_id=None, sync=False, del_key=False):
        logger.addinfo('@ models - recipes - update_redis(+)')
        try:
            segment_key_list = ['segment_id', 'segment_name', 'segment_range',
                                'producer', 'made_in', 'brand_name', 'language',
                                'brand_id']
            product_key_list = ['item_code', 'pet_type', 'food_type',
                                'ean_code', 'bar_code', 'segment_id',
                                'segment_name', 'segment_range', 'producer',
                                'made_in', 'brand_name', 'language',
                                'generate_pdf', 'brand_id', 'inventory_item_id']

            pipe = self.redis.pipeline()
            if sync is False:
                # Get segment fields
                query = self.sql_file['update_redis_segment_query']
                self.cursor.execute(query, p_language=language,
                                    p_segment_id=segment_id,
                                    p_brand_id=brand_id)
            else:
                # Get new segment fields
                query = self.sql_file['new_recipes_segment_query']
                self.cursor.execute(query)

            fieldnames = [a[0].lower() for a in self.cursor.description]
            segment_data = self.cursor.fetchall()
            for s_index, row in enumerate(segment_data):
                segment_keys = {}
                segment_obj = {}
                for index, field in enumerate(fieldnames):
                    val = row[index]
                    segment_obj[field] = val or ''
                    if field in segment_key_list:
                        segment_keys[field] = val or ''
                lang = segment_keys['language']
                brand = segment_keys['brand_id']
                segment = segment_keys['segment_id']

                # for querying segment image
                query = self.sql_file['recipe_segment_image_query']
                segment_obj['segment_images'] = ujson.dumps(
                    self.get_recipe_data(query,
                                         segment,
                                         None,
                                         'segment_image'))

                # for single packaging details
                query = self.sql_file['recipe_package_single_query']
                packaging = {
                    'single': self.get_recipe_data(query,
                                                   segment,
                                                   lang,
                                                   'single',
                                                   brand)
                }
                # for multi packaging details
                query = self.sql_file['recipe_package_multi_query']
                packaging['multi'] = self.get_recipe_data(query,
                                                          segment,
                                                          lang,
                                                          'multi', brand)
                segment_obj['packaging'] = ujson.dumps(packaging)

                # for segment level serving details
                query = self.sql_file['recipe_serving_segment_query']
                segment_obj['segment_serving'] = ujson.dumps(
                    self.get_recipe_data(query,
                                         segment,
                                         lang,
                                         'serving'))

                # segment key for redis
                segment_key = str(segment_keys['segment_id']) + ':' + \
                    str(segment_keys['brand_id']) + ':' + \
                    segment_keys['language']

                pipe.hmset(segment_key, segment_obj)

                if s_index % 100 == 0:
                    pipe.execute()

            if sync is False:
                # Get existing product fields
                query = self.sql_file['update_redis_query']
                self.cursor.execute(query, p_language=language,
                                    p_segment_id=segment_id,
                                    p_brand_id=brand_id)
            else:
                # Get new product fields
                query = self.sql_file['new_recipes_query']
                self.cursor.execute(query)

            fieldnames = [a[0].lower() for a in self.cursor.description]
            product_cursor_data = self.cursor.fetchall()
            for p_index, row in enumerate(product_cursor_data):
                product_keys = {}
                product_obj = {}
                item_id = ''
                for index, field in enumerate(fieldnames):
                    val = row[index]
                    if field == 'inventory_item_id':
                        item_id = val
                    product_obj[field] = val or ''
                    if field in product_key_list:
                        product_keys[field] = val or ''

                lang = product_keys['language']
                brand = product_keys['brand_id']
                segment = product_keys['segment_id']

                if item_code is None or item_id == item_code or item_code == '':

                    # for product image
                    query = self.sql_file['recipe_images_query']
                    product_obj['images'] = ujson.dumps(
                        self.get_recipe_data(query,
                                             item_id,
                                             None,
                                             'images'))
                    # for segment image
                    query = self.sql_file['recipe_segment_image_query']
                    product_obj['segment_images'] = ujson.dumps(
                                    self.get_recipe_data(query,
                                                         segment,
                                                         None,
                                                         'segment_image'))
                    # for composition in product
                    query = self.sql_file['recipe_ingredients_query']
                    product_obj['ingredients'] = ujson.dumps(
                        self.get_recipe_data(query,
                                             item_id,
                                             lang,
                                             'ingredients'))
                    # for constituents in products
                    query = self.sql_file['recipe_constituents_query']
                    product_obj['constituents'] = ujson.dumps(
                        self.get_recipe_data(query,
                                             item_id,
                                             lang,
                                             'constituents'))
                    # for product level daily serving details
                    query = self.sql_file['recipe_serving_product_query']
                    product_obj['product_serving'] = ujson.dumps(
                        self.get_recipe_data(query,
                                             item_id,
                                             lang,
                                             'serving'))
                    # for segment level daily serving
                    query = self.sql_file['recipe_serving_segment_query']
                    product_obj['segment_serving'] = ujson.dumps(
                                            self.get_recipe_data(query,
                                                                 segment,
                                                                 lang,
                                                                 'serving'))
                # for single package details for product
                query = self.sql_file['recipe_package_single_query']
                packaging = {
                    'single': self.get_recipe_data(query,
                                                   segment,
                                                   lang,
                                                   'single',
                                                   brand)
                }
                # for multi package details for product
                query = self.sql_file['recipe_package_multi_query']
                packaging['multi'] = self.get_recipe_data(query,
                                                          segment,
                                                          lang,
                                                          'multi', brand)

                product_obj['packaging'] = ujson.dumps(packaging)

                # Product key in redis
                product_key = product_keys['item_code'] + ':' + \
                    product_keys['pet_type'] + ':' + \
                    product_keys['food_type'] + ':' + \
                    str(product_keys['brand_id']) + ':' + \
                    str(product_keys['segment_id']) + ':' + \
                    str(product_keys['inventory_item_id']) + ':' + \
                    product_keys['language']

                if del_key is True:
                    new_id = str(product_keys['item_code']) + ":*:" + product_keys['language']
                    for scan_id in self.redis.scan_iter(new_id):
                        pipe.delete(scan_id)

                if item_code is None or item_id == item_code or item_code == '':
                    pipe.hmset(product_key, product_obj)
                elif len(self.redis.keys(product_key)) > 0:
                        pipe.hset(product_key, "packaging",
                                  product_obj["packaging"])
                        pipe.hset(product_key, "made_in",
                                  product_obj["made_in"])
                        pipe.hset(product_key, "producer",
                                  product_obj["producer"])
                if p_index % 100 == 0:
                    pipe.execute()
            pipe.execute()
        except Exception as e:
            logger.findaylog(""" @ 2514 EXCEPTION - models - recipes -
                             update_redis """ + str(e))
            raise e
        logger.addinfo('@ models - recipes - update_redis(-)')
        return 'success'

    def get_recipe_data(self, query, item_id, language, which, brand_id=None):
        try:
            data = []
            if language:
                if which == 'single' or which == 'multi':
                    self.cursor.execute(query, p_inventory_item_id=item_id,
                                        p_language=language,
                                        p_brand_id=brand_id)
                else:
                    self.cursor.execute(query, p_inventory_item_id=item_id,
                                        p_language=language)
            else:
                self.cursor.execute(query, p_inventory_item_id=item_id)

            fieldnames = [a[0].lower() for a in self.cursor.description]

            if which == 'images' or which == 'segment_image':
                data = []
                for row in self.cursor:
                    data.append(row[0])
            elif which == 'constituents' or which == 'single' or (
                    which == 'multi') or which == 'ingredients' or (
                    which == 'serving'):
                data = []
                for row in self.cursor:
                    obj = {}
                    for index, field in enumerate(fieldnames):
                        val = row[index] if row[index] else ''
                        obj[field] = val or ''
                    data.append(obj)
        except Exception as error:
            logger.findaylog(""" @ 2551 EXCEPTION - models - recipes -
                             get_recipe_data """ + str(error))
            raise error
        logger.addinfo('@ models - recipes - get_recipe_data(-)')
        return data

    def sync_ids(self):
        logger.addinfo('@ models - recipes - sync_ids(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            item_codes = self.cursor.var(cx_Oracle.STRING)
            segment_ids = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            self.cursor.execute("""
                                BEGIN
                                    qpex_products_pkg.sync_ids(
                                        :x_status_code,
                                        :x_item_codes,
                                        :x_segment_ids
                                    );
                                END;
                                """,
                                x_status_code=status_code,
                                x_item_codes=item_codes,
                                x_segment_ids=segment_ids)

            # Load languages lov
            query = self.sql_file['language_query']
            self.cursor.execute(query)
            languages = Code_util.iterate_data(self.cursor)

            if item_codes.getvalue() is not None:
                item_codes_arr = item_codes.getvalue()[1:].split(',')
                result = ["\'" + x + "\'" for x in item_codes_arr]
                item_codes_arr = ','.join(result)

                # get segment_ids for each item_code
                query = self.sql_file['get_segment_ids']
                query = query % item_codes_arr
                self.cursor.execute(query)
                item_codes_arr = Code_util.iterate_data(self.cursor)

                # Generate keys for each updated item in each language
                for item_index in range(len(item_codes_arr)):
                    for l_index in range(len(languages)):
                        self.update_redis(item_codes_arr[item_index][
                                                            'item_code'],
                                          languages[l_index]['language_id'],
                                          item_codes_arr[item_index][
                                                    'segments_category_id'],
                                          item_codes_arr[item_index][
                                              'brand_category_id'],sync=False,
                                              del_key=True)
            if segment_ids.getvalue() is not None:
                segment_ids_arr = segment_ids.getvalue()[1:]

                # get brand_id for each item_code
                query = self.sql_file['get_brand_ids']
                query = query % segment_ids_arr
                self.cursor.execute(query)
                segment_ids_arr = Code_util.iterate_data(self.cursor)

                # Generate keys for each updated segment in each language
                for s_index in range(len(segment_ids_arr)):
                    for l_index in range(len(languages)):
                        self.update_redis('',
                                          languages[l_index]['language_id'],
                                          segment_ids_arr[s_index][
                                              'segments_category_id'],
                                          segment_ids_arr[s_index][
                                              'brand_category_id'],sync=False,
                                              del_key=True)
            # add new products to redis
            self.update_redis(sync=True)

            # delete products that are not found in view table
            self.delete_product_recipes()

        except Exception as e:
            logger.findaylog(""" @ 2625 EXCEPTION - models - recipes -
                             sync_ids """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - recipes - sync_ids(-)')
        return status_code.getvalue()

    def get_all_segments(self, language):
        logger.addinfo('models - recipes - get_all_segments(+)')
        try:
            self.acquire()
            recipes = []

            """
             To differentiate product key from segment key
             added no.of *(s) same as no.of terms in product key
            """
            recipe_key = '*:*:*:*:*:*:' + language
            for key in self.redis.keys(recipe_key):
                details = self.redis.hgetall(key)
                if 'images' in details:
                    details['images'] = ujson.loads(details['images'])
                else:
                    details['images'] = []
                if 'segment_images' in details:
                    details['segment_images'] = ujson.loads(
                        details['segment_images'])
                else:
                    details['segment_images'] = []
                if 'constituents' in details:
                    details['constituents'] = ujson.loads(
                        details['constituents'])
                else:
                    details['constituents'] = []
                if 'packaging' in details:
                    details['packaging'] = ujson.loads(
                        details['packaging'])
                else:
                    details['packaging'] = []
                if 'ingredients' in details:
                    details['ingredients'] = Recipes.order_composition_list(
                        ujson.loads(details['ingredients']))
                else:
                    details['ingredients'] = []
                if 'segment_serving' in details:
                    details['segment_serving'] = ujson.loads(
                        details['segment_serving'])
                else:
                    details['segment_serving'] = []
                if 'product_serving' in details:
                    details['product_serving'] = ujson.loads(
                        details['product_serving'])
                else:
                    details['product_serving'] = []
                details['special_diet'] = ''
                details['health_benefits'] = ''
                details['quality_of_ingredients'] = ''
                details['product_image_links'] = []
                recipes.append(details)
            query = self.sql_file['product_filters_query']
            self.cursor.execute(query, p_language=language)
            filters_data = Code_util.iterate_data(self.cursor)
            for i in range(len(recipes)):
                for j in range(len(filters_data)):
                    if str(recipes[i]['inventory_item_id']) == str(filters_data[j]['inventory_item_id']):
                        recipes[i]['special_diet'] = filters_data[j]['special_diet']
                        recipes[i]['health_benefits'] = filters_data[j]['health_benefits']
                        recipes[i]['quality_of_ingredients'] = filters_data[j]['quality_of_ingredients']
                        recipes[i]['product_image_links'] = [{
                            'image_link': os.environ['PUBLIC_IMAGE_URL'] + recipes[i]['item_code'] + '.png'
                        }]
                recipes[i]['pet_age'] = ''
        except Exception as e:
            logger.findaylog(""" @ 2660 EXCEPTION - models - recipes -
                             get_all_segments """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - recipes - get_all_segments(-)')
        return recipes

    def get_brand_info(self, language):
        logger.addinfo('models - recipes - get_brand_info(+)')
        try:
            self.acquire()
            brand_image_path = os.environ['BRAND_IMAGE_PATH']
            brand_pdf_path = os.environ['PDF_PATH']
            if language == 'I':
                brand_language = 'IT'
            # elif language == 'D':
            #     brand_language = 'DE'
            elif language == 'F':
                brand_language = 'FR'
            else:
                brand_language = language
            query = self.sql_file['get_brand_info']
            self.cursor.execute(query, p_language=language)
            brands = Code_util.iterate_data(self.cursor)
            for i in range(len(brands)):
                brand_pet_food = ''
                brand_pet_food += '_'.join(brands[i]['brand_name'].split(' ')
                                           ).upper()
                brand_pet_food += '_' + brands[i]['animal'].upper()
                brand_pet_food += '_' + brands[i]['food_type'].upper()
                brands[i]['brand_logo'] = ''
                brands[i]['brand_image'] = brand_image_path + brand_pet_food + \
                    '.jpg'
                brands[i]['brand_pdf'] = brand_pdf_path + brand_pet_food
                brands[i]['brand_pdf'] += '_' + brand_language + '.pdf'
                brands[i]['description'] = ''
        except Exception as e:
            logger.findaylog(""" @ 2698 EXCEPTION - models - recipes -
                             get_brand_info """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models-recipes - get_brand_info(-)')
        return brands

    @staticmethod
    def pdf_html_content(pdf_type):
        try:
            if pdf_type == "old_pdf":
                file_name = os.path.join(
                    os.path.dirname(__file__) + "/detailpdf.html")
                with io.open(file_name, "r", encoding="utf-8") as original:
                    html_content = Template(original.read())
                    original.close()
            else:
                html_content = {}
                products_file_name = os.path.join(
                    os.path.dirname(__file__) + "/summarypdfproducts.html")

                with io.open(products_file_name,
                             "r", encoding="utf-8") as original:
                    html_content[
                        "products_content"] = Template(original.read())
                    original.close()

                html_content["header_name"] = os.path.join(os.path.dirname(
                    __file__) + "/pdfheader.html")
                footer_name = os.path.join(
                    os.path.dirname(__file__) + "/pdffooter.html")

                with io.open(footer_name,
                             "r", encoding="utf-8") as footer_original:
                    html_content[
                        "footer_content"] = Template(footer_original.read())
                    footer_original.close()
        except Exception as e:
            logger.findaylog(""" @ 341 EXCEPTION - models - recipes -
                                             pdf_html_content """ + str(e))
            raise e
        return html_content

    def export_pdf_for_product(self, json_array):
        logger.addinfo('models - recipes - export_pdf_for_product(+)')
        try:
            self.acquire()
            result = []
            no_pdf = []
            final = {}
            data = []
            if json_array["language"] == 'I':
                brand_language = 'IT'
            # elif json_array["language"] == 'D':
            #     brand_language = 'DE'
            elif json_array["language"] == 'F':
                brand_language = 'FR'
            else:
                brand_language = json_array["language"]
            if json_array["type"] == "old_pdf":
                dir_path = self.sql_file["pdf_path"]
            else:
                dir_path = self.sql_file["new_pdf_path"]

            if not os.path.exists(dir_path):
                os.makedirs(dir_path)
            for jsond in json_array['items']:
                # to get the file_path
                filename = jsond["item_code"].split(" ")
                filename = "_".join(filename)
                filename += "_" + jsond["animal"]
                filename += "_" + jsond["food_type"]
                filename += "_" + brand_language

                file_path = dir_path + filename + ".pdf"

                modified_time = ''

                if len(json_array['items']) == 1:
                    # to get the last updated date for a product
                    last_updated_date = self.sql_file[
                                                "get_product_last_update"]
                    self.cursor.execute(last_updated_date,
                                        p_product_id=jsond["item_code"])
                    query_data = Code_util.iterate_data(self.cursor)
                    # to get the time the pdf is generated in the path
                    if os.path.exists(file_path):
                        modified_time = datetime.datetime.fromtimestamp(
                            os.path.getmtime(file_path))

                        modified_time = modified_time.strftime('%Y-%m-%d')

                # to check if the pdf generated time greater than updated date
                if modified_time and \
                        modified_time > query_data[0]["recent_update_date"]:
                    result.append(filename + '.pdf')
                else:
                    # to get the html_content
                    html_content = Recipes.pdf_html_content(json_array["type"])

                    req_obj = {'item_id': jsond["item_code"],
                               'segment_id': None,
                               'brand_id': None,
                               'food_type': '*',
                               'pet_type': '*',
                               'language': json_array["language"]
                              }

                    product_details = self.get_product_details(req_obj)
                    if (product_details):
                        # to get the product details
                        data.append(product_details[0])
            if len(data) == 1:
                if json_array["type"] == "old_pdf":

                    products = self.pdf_format_data(data,
                                                    json_array["language"])

                    pdf_results = self.pdf_html_template(products,
                                                    data[0]["pet_type"],
                                                    data[0]["food_type"],
                                                    str(data[0][
                                                            "item_code"]),
                                                    html_content)
                else:
                    products, tr_dict = Recipes.new_pdf_format_data(data,
                                                                    json_array[
                                                                      "language"
                                                                    ])
                    pdf_results = self.new_pdf_html_template(products,
                                                        str(data[0][
                                                            "item_code"]),
                                                        data[0]["pet_type"],
                                                        data[0][
                                                            "food_type"],
                                                        json_array[
                                                             "language"],
                                                        html_content,
                                                        tr_dict)
                final = {"msg": filename + ".pdf", "status": Status.OK.value}
            elif len(data) > 1:
                if json_array["type"] == "old_pdf":

                    products = self.pdf_format_data(data,
                                                    json_array["language"])

                    filename = "multiple_products.pdf"

                    pdf_results = self.pdf_html_template(products,
                                                         None,
                                                         None,
                                                         None,
                                                         html_content,
                                                         filename)
                else:
                    products, tr_dict = Recipes.new_pdf_format_data(data,
                                                                    json_array[
                                                                       "language"
                                                                    ])
                    filename = "multiple_products.pdf"
                    pdf_results = self.new_pdf_html_template(products,
                                                             None,
                                                             None,
                                                             None,
                                                             json_array[
                                                                 "language"],
                                                             html_content,
                                                             tr_dict,
                                                             filename
                                                             )
                final = {"msg": "multiple_products.pdf",
                         "status": Status.OK.value}
            else:
                if len(result):
                    final = {"msg": result[0],
                             "status": Status.OK.value}
                else:
                    final = {"msg": "No data found",
                             "status": Status.ERROR.value}

        except Exception as error:
            logger.findaylog("""@ 2809 EXCEPTION - models - recipes -
                             export_pdf_for_product """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo("""@ models - recipes - export_pdf_for_product(-)""")
        return final

    @staticmethod
    def pdf_concat(input_files, output_stream):
        input_streams = []
        try:
            for input_file in input_files:
                input_streams.append(open(input_file, 'rb'))
            writer = PdfFileWriter()
            for reader in map(PdfFileReader, input_streams):
                for n in range(reader.getNumPages()):
                    writer.addPage(reader.getPage(n))
            writer.write(file(output_stream, "wb"))

        except Exception as error:
            logger.findaylog("""@ 2913 EXCEPTION - models - recipes -
                             pdf_concat """ + str(error))
            raise error
        finally:
            for f in input_streams:
                f.close()
        logger.addinfo("""@ models - recipes - pdf_concat(-)""")
        return output_stream

    def export_pdf_for_multiple_brands(self, jsond):
        logger.addinfo(""" @ models - recipes -
                        export_pdf_for_multiple_brands(+)""")
        try:
            if jsond["language"] == 'I':
                brand_language = 'IT'
            # elif jsond["language"] == 'D':
            #     brand_language = 'DE'
            elif jsond["language"] == 'F':
                brand_language = 'FR'
            else:
                brand_language = jsond["language"]
            dir_path = ''
            if jsond["type"] == "old_pdf":
                dir_path = self.sql_file["pdf_path"]
            else:
                dir_path = self.sql_file["new_pdf_path"]

            if not os.path.exists(dir_path):
                os.makedirs(dir_path)

            results = []

            for brands in jsond['brands']:
                file_obj = {"language": brand_language,
                            "pet_type": brands['animal'],
                            "brand_name": brands['brand_name'],
                            "path": dir_path,
                            "wet_or_dry": brands['food_type']}
                file_path = Recipes.get_file_path(file_obj)
                if os.path.exists(file_path):
                    results.append(file_path)
            final = {}
            if len(results) == 0:
                final = {"msg": "No brands details found",
                         "status": Status.ERROR.value}
            else:
                filename = 'multiple_brands.pdf'
                output_stream = dir_path + filename
                pdfmerger = Recipes.pdf_concat(results, output_stream)
                final = {"msg": filename, "status": Status.OK.value}
        except Exception as error:
            logger.findaylog("""@ 2962 EXCEPTION - models - recipes -
                             export_pdf_for_multiple_brands """ +
                             str(error))
            raise error
        logger.addinfo("""@ models - recipes -
                        export_pdf_for_multiple_brands(-)""")
        return final

    @staticmethod
    def order_composition_list(composition):
        order_composition = []
        percent = []
        string_list = []
        count = 0
        for comp in composition:
            # to find all the numbers with percentage in composition
            percent_list = [str(re.sub(r"\s+", "", group[0]))
                            for group in re.findall(r'(\d+([\.\,]\d+)?(\s*)%)',
                                                    comp['name'])]
            if len(percent_list) == 1:
                # to remove percent and replace ',' with '.'
                val1 = percent_list[0].replace('%', '')
                val = float(val1.replace(',', '.'))
                # to get the indexes of the val greater the val
                index = [ind for ind in range(len(percent))
                         if percent[ind] > val]
                if(len(index) == 0):
                    # append the value at the end
                    percent.append(val)
                    order_composition.append(comp)
                else:
                    # insert the val at the first number with greater value
                    percent.insert(index[0], val)
                    order_composition.insert(index[0], comp)
            else:
                # to append all the strings that come
                string_list.append(comp)
        # giving percentage strings priority and append the remaining strings
        #  to it. so the 'order_composition' is having comp list in asc order
        # of percentage , we need to reverse it for descending order
        string_list.sort(key=lambda k: k['ingredient_id'])
        shuffedlist = list(reversed(order_composition)) + string_list
        return shuffedlist


    def delete_product_recipes(self):
        logger.addinfo('@ models - recipes - delete_product_recipes(+)')
        try:
            conn = db_util.get_connection()
            cur = conn.cursor()
            delete_products_in_redis = []
            status_code = cur.var(cx_Oracle.STRING)
            deleted_products = cur.var(cx_Oracle.STRING)
            item_codes_arr = []
            # Delete the products not found in View table
            cur.execute("""
                                BEGIN
                                    qpex_products_pkg.delete_existing_products(
                                        :x_deleted_items,
                                        :x_status_code
                                    );
                                END;
                                """,
                                x_deleted_items=deleted_products,
                                x_status_code=status_code
                                )
            if status_code.getvalue() == 'SUCCESS':
                if deleted_products.getvalue() is not None:
                    item_codes_arr = deleted_products.getvalue()[1:].split(',')
                    self.delete_redis_keys(item_codes_arr)

        except Exception as e:
            logger.findaylog(""" @ 3172 EXCEPTION - models - recipes -
                             delete_product_recipes """ + str(e))
            raise e
        finally:
            cur.close()
        logger.addinfo('@ models - recipes - delete_product_recipes(-)')
        return status_code.getvalue()

    def delete_redis_keys(self, deleted_products):
        logger.addinfo('@ models - recipes - delete_redis_keys(+)')
        try:
            pipe = self.redis.pipeline()
            for p_index, product in enumerate(deleted_products):
                pipe.delete(product)
                if p_index % 100 == 0:
                    pipe.execute()
            pipe.execute()
        except Exception as e:
            logger.findaylog(""" @ 3192 EXCEPTION - models - recipes -
                             delete_redis_keys """ + str(e))
            raise e
        logger.addinfo('@ models - recipes - delete_redis_keys(-)')
        return 'success'

    @staticmethod
    def send_log(func, err, inp):
        LogUtil.send_log({
            "source": "Finapi",
            "module": "Product Onboard",
            "function": func,
            "error_msg": err,
            "input_data": inp
        })
