from finapi.utils.logdata import logger
from finapi.utils import db_util
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
import base64
import string
import random
import os
import xlrd
import cx_Oracle
import xlsxwriter
import re


class Pricelists:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    # create connection
    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    # release connection
    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    # Returns data in sheet with column names
    def get_sheet_data(self, data):
        logger.addinfo('@ models - pricelists - get_sheet_data(+)')
        code_column_name = ''
        try:

            # check no.of columns in sheet
            if data.ncols != 2:
                return False
            else:
                cols = []

                # Read column names in sheet
                for col in range(data.ncols):
                    cols.append(data.cell_value(0, col))

                has_code_column = False

                # Remove duplicate spaces in column names
                for i in range(len(cols)):
                    column_name = self.format_column_name(cols[i], True)

                    if column_name.find('code') != -1:
                        has_code_column = True

                        """Assign column name having 'code'
                        as substring to code_column_name
                        """
                        code_column_name = column_name
                    cols[i] = column_name

                if not has_code_column:
                    return False

                list = []

                # Push each row values as object to list
                for row in range(1, data.nrows):
                    row_data = {}
                    r = data.row_values(row)
                    has_code_value = False
                    has_price_value = False

                    for i in range(len(cols)):
                        if cols[i] == code_column_name and r[i] != '':
                            has_code_value = True
                            if type(r[i]) == float:
                                row_data[cols[i]] = str(int(r[i]))
                            else:
                                row_data[cols[i]] = r[i]
                        if cols[i] != code_column_name:
                            if r[i] != '':
                                has_price_value = True
                                row_data[cols[i]] = r[i]
                            else:
                                row_data[cols[i]] = None

                    """Append if item_code column & price has value
                    elseif item_code is null and price has value
                    consider it as error and return False
                    else ignore the row and continue the loop
                    """
                    if has_code_value:
                        list.append(row_data)
                    elif not has_code_value and has_price_value:
                        return False
                if len(list) == 0:
                    return False
        except Exception as e:
            logger.findaylog(""" @ 127 EXCEPTION - models - pricelists -
                           get_sheet_data """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - get_sheet_data(-)')
        return {'data': list, 'columns': cols,
                'code_column_name': code_column_name}

    # Remove duplicate spaces and convert to lower case
    def format_column_name(self, column_name, to_lower):
        logger.addinfo('@ models - pricelists - format_column_name(+)')
        try:
            # Remove duplicate spaces and join with single space
            f_column_name = " ".join(column_name.split())

            # Replcae space with '_' and covert to lower case
            # f_column_name = f_column_name.replace(" ", "_").lower()

            if to_lower:
                f_column_name = f_column_name.lower()
        except Exception as e:
            logger.findaylog(""" @ 150 EXCEPTION - models - pricelists -
                           format_column_name """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - format_column_name(-)')
        return f_column_name

    # Return list header for sheet name in uploaded file
    def get_list_header_id(self, sheet_name):
        logger.addinfo('@ models - pricelists - get_list_header_id(+)')
        try:
            list_header_id = ''
            formatted_sheet_name = self.format_column_name(sheet_name, True)
            # sheet names in standard intercompany excel file
            sheet_names = ['i.c eu in eur', 'i.c ch in chf',
                           'i.c uk in gbp',
                           'almo nature it in eur',
                           'almo nature it sam e car in eur']

            # list header ids for each price list in standard intercompany
            list_header_ids = ['6051', '6053', '2105811', '751286', '2338445']
            try:
                index = sheet_names.index(formatted_sheet_name)
                list_header_id = list_header_ids[index]
            except:
                if sheet_names[4].find(formatted_sheet_name) != -1:
                    list_header_id = list_header_ids[4]
        except Exception as e:
            logger.findaylog(""" @ 155 EXCEPTION -models - pricelists -
                             get_list_header_id """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - get_list_header_id(-)')
        return list_header_id

    # Returns formatted data in uploaded file
    def read_file(self, jsond):
        logger.addinfo('@ models - pricelists - read_file(+)')
        try:

            number_format = jsond['number_format']
            # Sheet names accepted in standard intercompany price list upload
            accepted_sheet_names = ['i.c eu in eur', 'i.c ch in chf',
                                    'i.c uk in gbp',
                                    'almo nature it in eur',
                                    'almo nature it sam e car in eur']
            invalid_msg = ''
            result = {}

            # Read uploaded file base64 and write to temporary files
            file_decode = base64.b64decode(jsond['base64'])
            file_id = self.id_generator()
            file_name = '/tmp/' + file_id + '.xls'
            temp_file = open(file_name, 'wb')
            temp_file.write(file_decode)
            temp_file.close()

            sheets = xlrd.open_workbook(file_name)
            sheet_names = sheets.sheet_names()
            all_sheets_data = []

            if jsond['single_file'] and len(sheet_names) != 1:
                invalid_msg = 'Maximum 1 sheet is allowed to upload. '
                invalid_msg += 'Please check format by downloading sample file'

            elif not jsond['single_file'] and len(sheet_names) != 5:
                invalid_msg = 'Invalid number of sheets - '
                invalid_msg += 'expecting 5 sheet format, '
                invalid_msg += 'download sample file for reference'

            elif not jsond['single_file']:
                """Compare uploaded sheet names with
                sheet names in accepted_sheet_names
                """
                msg = ''

                for i in range(len(sheet_names)):
                    has_sheet_name = False
                    formatted_sheet_name = self.format_column_name(
                        sheet_names[i], True)
                    for j in range(len(accepted_sheet_names)):
                        """ If accepted_sheet_names is
                        almo nature it sam e car in eur
                        compare with substring of sheet name"""
                        if j == 4:
                            if accepted_sheet_names[j].find(
                                    formatted_sheet_name) != -1:
                                has_sheet_name = True
                                break
                        else:
                            if formatted_sheet_name == accepted_sheet_names[j]:
                                has_sheet_name = True
                                break
                    if not has_sheet_name:
                        msg = sheet_names[i] + ', '

                if msg:
                    invalid_msg = 'Uploaded file has invalid sheet names '
                    msg = msg[:-2]
                    invalid_msg += msg + '. '
                    invalid_msg += 'Please check sheet names by '
                    invalid_msg += 'downloading sample file'
            if invalid_msg:
                result['msg'] = invalid_msg
                result['status'] = 1
            else:
                invalid_sheet_names = ''

                # To read data in each sheet
                for i in range(len(sheet_names)):
                    sheet_data = self.get_sheet_data(
                        sheets.sheet_by_name(sheet_names[i]))

                    if not sheet_data:
                        invalid_sheet_names += sheet_names[i] + ', '
                    else:
                        sheet_name = self.format_column_name(
                            sheet_names[i], False)
                        if jsond['single_file']:
                            list_header_id = jsond['list_header_id']
                        else:
                            list_header_id = self.get_list_header_id(
                                sheet_name)

                        all_sheets_data.append(
                            {'data': sheet_data['data'],
                             'column_names': sheet_data['columns'],
                             'sheet_name': sheet_name,
                             'list_header_id': list_header_id,
                             'code_column_name': sheet_data['code_column_name']
                             })

                # Delete temporary file
                os.remove(file_name)

                if invalid_sheet_names:
                    invalid_msg = 'Unable to process, check ('
                    invalid_msg += invalid_sheet_names[:-2] + ') has '
                    invalid_msg += 'a. Invalid number of columns, '
                    invalid_msg += "b. Sheet's doesn't have Item Code column "
                    invalid_msg += 'c. Item Code has no value '
                    invalid_msg += 'd. Sheet has no data'
                    result = {}
                    result['status'] = 1
                    result['msg'] = invalid_msg
                else:
                    # Get product description for item code
                    formatted_data = self.format_data(all_sheets_data)
                    result = {'invalid_products': [], 'duplicate_products': []}
                    for i in range(len(formatted_data)):
                        if len(formatted_data[i]['invalid_data']) > 0:
                            obj = {}
                            obj['item_codes'] = formatted_data[i][
                                'invalid_data']
                            obj['sheet_name'] = formatted_data[i]['sheet_name']
                            result['invalid_products'].append(obj)
                        if len(formatted_data[i]['duplicates']) > 0:
                            obj = {}
                            obj['item_codes'] = formatted_data[i]['duplicates']
                            obj['sheet_name'] = formatted_data[i]['sheet_name']
                            result['duplicate_products'].append(obj)
                    if len(result['invalid_products']) > 0 or len(
                            result['duplicate_products']) > 0:
                        result['status'] = 1
                    else:
                        result = self.insert_data(
                            formatted_data, number_format)

                    if result['status'] == 0:
                        oracle_price_obj = []
                        for i in range(len(result['list_data'])):
                            obj = {}
                            obj['list_header_id'] = result['list_data'][
                                i]['list_header_id']
                            obj['is_cursor_open'] = False
                            obj['generate_excel'] = False
                            oracle_price_obj.append(obj)
                        oracle_prices = self.download_file(oracle_price_obj)
                        result['oracle_prices'] = oracle_prices

        except xlrd.XLRDError as e:
            result['msg'] = 'Unsupported file format, '
            result['msg'] += 'please check by downloading sample file'
            result['status'] = 1
        except Exception as e:
            logger.findaylog(""" @ 275 EXCEPTION - models - pricelists -
                           read_file """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - read_file(-)')
        return result

    # Get product description for items in price list table
    def format_data(self, sheets_data):
        logger.addinfo('@ models - pricelists - format_data(+)')
        try:
            self.acquire()
            all_products = []
            product_codes = []

            # Append product codes from all sheets
            for i in range(len(sheets_data)):
                # column_names = sheets_data[i]['column_names']
                code_column_name = sheets_data[i]['code_column_name']

                sheet_data = sheets_data[i]['data']

                # Append item_codes in all sheets to product_codes
                for j in range(len(sheet_data)):
                    if sheet_data[j][code_column_name] not in product_codes:
                        product_codes.append(
                            str(sheet_data[j][code_column_name]))

            # Get description for item code
            query = self.sql_file['get_product_description']
            query = query % (',' . join(["'" + str(product_code) + "'"
                                         for product_code in product_codes]))
            self.cursor.execute(query)
            products = Code_util.iterate_data(self.cursor)

            """Validate products in uploaded sheet by comparing with
            product codes in price lists table
            """
            for i in range(len(sheets_data)):
                data = self.validate_data(sheets_data[i], products)
                all_products.append({
                    'data': data['valid_product_codes'],
                    'invalid_data': data['invalid_product_codes'],
                    'sheet_name': sheets_data[i]['sheet_name'],
                    'column_names': sheets_data[i]['column_names'],
                    'duplicates': data['duplicates'],
                    'list_header_id': sheets_data[i]['list_header_id']
                })
        except Exception as e:
            logger.findaylog(""" @ 324 EXCEPTION - models - pricelists -
                           format_data """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - pricelists - format_data(-)')
        return all_products

    # To map product_code with product description
    def validate_data(self, sheets_data, table_data):
        logger.addinfo('@ models - pricelists - validate_data(+)')
        try:
            # table_data - contains product data from database
            # sheet_data - contains data of uploaded sheet
            valid_product_codes = []
            obj = {}
            invalid_product_codes = []
            column_names = sheets_data['column_names']
            sheet_data = sheets_data['data']
            code_column_name = sheets_data['code_column_name']
            duplicates = []
            for i in range(len(sheet_data)):
                try:
                    index = -1
                    obj = {}

                    index = [str(line['segment1']) for
                             line in table_data].index(
                        str(sheet_data[i][code_column_name]))
                    if index != -1:
                        obj['product_description'] = table_data[index][
                            'description']
                        for j in range(len(column_names)):
                            if column_names[j] == code_column_name:
                                obj['product_code'] = sheet_data[
                                    i][code_column_name]
                            else:
                                obj['price'] = sheet_data[i][
                                    column_names[j]]
                        valid_product_codes.append(obj)
                    else:
                        # Append product codes that are not in database
                        invalid_product_codes.append(
                            sheet_data[i][code_column_name])
                except:
                    invalid_product_codes.append(
                        sheet_data[i][code_column_name])
            duplicates = self.validate_duplicates(valid_product_codes)
        except Exception as e:
            logger.findaylog(""" @ 371 EXCEPTION - models - pricelists -
                           validate_data """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - validate_data(-)')
        return {'valid_product_codes': valid_product_codes,
                'invalid_product_codes': invalid_product_codes,
                'duplicates': duplicates}

    def validate_duplicates(self, data):
        logger.addinfo('@ models - pricelists - validate_duplicates(+)')
        try:
            item_codes = []
            duplicates = []
            for i in range(len(data)):
                if str(data[i]['product_code']) not in item_codes:
                    item_codes.append(str(data[i]['product_code']))
                else:
                    duplicates.append(str(data[i]['product_code']))
        except Exception as e:
            logger.findaylog(""" @ 369 EXCEPTION - models - pricelists -
                             validate_duplicates """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - validate_duplicates(-)')
        return duplicates

    # validate price with user number format
    def validate_number(self, number_format, number):
        logger.addinfo('@ models - pricelists - validate_number(+)')
        try:
            number_array = []
            decimal = None
            decimal_seperator = '.'
            number_seperator = ','
            if number.find(',') != -1 and number_format == '999.999,99':
                decimal_seperator = ','
                number_seperator = '.'
            if number == '' or number is None:
                return None
            if (number.find(number_seperator) != -1) and (number.find(
                    number_seperator) > number.find(decimal_seperator)):
                return -1

            number_array = number.split(decimal_seperator)
            if len(number_array) > 2:
                return -1
            else:
                # Get decimal part of number
                if len(number_array) == 2:
                    decimal = number_array[1]
                integer = number_array[0].split(number_seperator)
                if len(integer) == 1:
                    floor = integer[0]
                else:
                    for i in range(len(integer)):
                        if i != 0 and len(integer[i]) != 3:
                            return -1
                    floor = "" . join(integer)
            if decimal is not None:
                number = "." . join([floor, decimal])
            number = round(float(number), 3)
        except Exception as e:
            logger.findaylog(""" @ 425 EXCEPTION - models - pricelists -
                             validate_number """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - validate_number(-)')
        return number

    # Insert data in uploaded file
    def insert_data(self, formatted_data, number_format):
        logger.addinfo('@ models - pricelists - insert_data')
        try:
            invalid_flag = False
            invalid_products_status = []
            self.acquire()

            result = []
            # Column names to insert into price lists table
            fields = ['batch_id', 'product_code', 'price']
            fieldnames_string = "("
            parameter_string = "("
            index_value = 1
            for i in range(len(fields)):
                fieldnames_string += str(fields[i]) + ","
                parameter_string += ":" + str(index_value) + ","
                index_value = index_value + 1
            fieldnames_string = fieldnames_string[:-1]
            parameter_string = parameter_string[:-1]
            fieldnames_string += ")"
            parameter_string += ")"
            for i in range(len(formatted_data)):
                invalid_price_products = []
                data = formatted_data[i]['data']
                for j in range(len(data)):

                    if data[j]['price'] is not None:
                        # compare if number has strings
                        is_number = re.search(r'[^0-9, , , .]',
                                              str(data[j]['price']))
                        if is_number is None:
                            data[j]['price'] = str(
                                data[j]['price']).replace(" ", "")
                            is_valid = self.validate_number(
                                number_format, str(data[j]['price']))
                            if is_valid == -1:
                                invalid_flag = True
                                invalid_price_products.append(
                                    data[j]['product_code'])
                            else:
                                data[j]['price'] = is_valid
                        else:
                            invalid_flag = True
                            invalid_price_products.append(
                                data[j]['product_code'])
                    else:
                        data[j]['price'] = None
                if len(invalid_price_products) > 0:
                    msg = 'Invalid price values for item codes '
                    msg += "," . join(invalid_price_products)
                    msg += ' in ' + formatted_data[i]['sheet_name']
                    invalid_products_status.append({'msg': msg, 'status': 1})

            if invalid_flag:
                formatted_data = []
            # Insert data from each sheet
            for i in range(len(formatted_data)):
                batch_id = self.get_sequence()
                batch_id = int(batch_id[0])
                row_data = []
                file_name = ''
                for line in formatted_data[i]['data']:
                    line['batch_id'] = batch_id
                    my_data = []
                    for index, field in enumerate(fields):
                        my_data.append(line[field])
                        tuple_data = tuple(my_data)
                    row_data.append(tuple_data)
                self.cursor.prepare(""" insert into qpex_price_lists """ +
                                    fieldnames_string + """ values """ +
                                    parameter_string)
                self.cursor.executemany(None, row_data)
                if self.cursor.rowcount != len(formatted_data[i]['data']):
                    result.append({
                        'upload_status': 1,
                        'sheet_name': formatted_data[i]['sheet_name']
                    })
                else:
                    result.append({
                        'upload_status': 0,
                        'sheet_name': formatted_data[i]['sheet_name'],
                        'data': formatted_data[i]['data'],
                        'batch_id': batch_id,
                        'file_name': file_name,
                        'list_header_id': formatted_data[i]['list_header_id']
                    })
        except Exception as e:
            logger.findaylog(""" @ 463 EXCEPTION - models - pricelists -
                            insert_data """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - pricelists - insert_data(-)')
        if not invalid_flag:
            return {'list_data': result, 'status': 0}
        else:
            return {'invalid_products': invalid_products_status, 'status': 1}

    # Generate random name for temporary file to write uplaoded file base64
    def id_generator(self):
        logger.addinfo('@ models - pricelists - id_generator(+)')
        try:
            size = 9
            chars = string.ascii_uppercase + string.digits
        except Exception as e:
            logger.findaylog(""" @ 482 EXCEPTION - models - pricelists -
                           id_generator """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - id_generator(-)')
        return ''.join(random.choice(chars) for _ in range(size))

    # Returns price list table sequence
    def get_sequence(self):
        logger.addinfo('@ models - pricelists - get_sequence(+)')
        try:
            query = self.sql_file['qpex_price_lists_sequence']
            sequence = self.cursor.execute(query).fetchone()
        except Exception as e:
            self.release()
            logger.findaylog(""" @ 496 EXCEPTION - models - pricelists -
            get_sequence """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - get_sequence(-)')
        return sequence

    # Package call to update prices
    def update_price(self, json):
        logger.addinfo('@ models - pricelists - update_price(+)')
        oracle_price_list = []
        try:
            self.acquire()
            if len(json['delete_products']) > 0:
                self.insert_deleted_products(json['delete_products'])
            jsond = json['batch_ids']
            return_status = self.cursor.var(cx_Oracle.STRING)
            return_message = self.cursor.var(cx_Oracle.STRING)
            result = []
            for i in range(len(jsond)):
                self.cursor.execute("""
                    begin
                    apps.qpex_price_list_pkg.main_list(
                    :p_price_list_name, :p_file_id,
                    :x_return_status, :x_return_msg
                    );
                    end; """, p_price_list_name=jsond[i]['file_name'],
                                    p_file_id=jsond[i]['batch_id'],
                                    x_return_status=return_status,
                                    x_return_msg=return_message)
                if not return_status.getvalue(
                ) and not return_message.getvalue():
                    self.connection.commit()
                    dict = {}
                    dict['list_header_id'] = jsond[i]['list_header_id']
                    dict['file_name'] = jsond[i]['file_name']
                    dict['number_format'] = jsond[i]['number_format']
                    dict['is_cursor_open'] = True
                    dict['generate_excel'] = False
                    dict['sheet_name'] = jsond[i]['sheet_name']
                    dict['batch_id'] = jsond[i]['batch_id']
                    oracle_price_list.append(dict)
                else:
                    result.append({'msg': return_message.getvalue(),
                                   'sheet_name': jsond[i]['sheet_name'],
                                   'file_name': jsond[i]['file_name']})
            self.connection.commit()
            oracle_prices = self.download_file(oracle_price_list)
            for i in range(len(oracle_price_list)):
                for j in range(len(oracle_prices)):
                    if oracle_price_list[i][
                        'list_header_id'] == oracle_prices[
                            j]['list_header_id']:
                        result.append(
                            {'msg': 'success',
                             'sheet_name': oracle_price_list[i]['sheet_name'],
                             'file_name': oracle_price_list[i]['file_name'],
                             'oracle_prices': oracle_prices[j][
                                 'oracle_prices']})
        except Exception as e:
            logger.findaylog(""" @ 590 EXCEPTION - models - pricelists -
                            update_price """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - pricelists - update_price(+)')
        return result

    # Delete data in price list table
    def clear_data(self):
        logger.addinfo('@ models - pricelists - clear_data(+)')
        try:
            self.acquire()
            query = self.sql_file['delete_price_list']
            self.cursor.execute(query)
        except Exception as e:
            logger.findaylog(""" @ 607 EXCEPTION - models - pricelists -
                           clear_data """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - pricelists - clear_data(-)')
        return 'success'

    # Returns list of price list names
    def get_file_names(self):
        logger.addinfo('@ models - pricelists - get_file_names(+)')
        try:
            self.acquire()
            query = self.sql_file['pricelist_file_names']
            self.cursor.execute(query)
            file_names = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 625 EXCEPTION - models - pricelists -
                             get_file_names """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - pricelists - get_file_names(-)')
        return file_names

    # generate 5 sheet excel file for standard intercompany
    def standard_sample_file(self):
        logger.addinfo('@ models - pricelists - standard_sample_file(+)')

        # sheet names in standard intercompany excel file
        sheet_names = ['I.C EU in EUR', 'I.C CH in CHF', 'I.C UK in GBP',
                       'ALMO NATURE IT in EUR',
                       'ALMO NATURE IT SAM E CAR in EUR']

        # list header ids for each price list in standard intercompany
        list_header_id = ['6051', '6053', '2105811', '751286', '2338445']

        # column name background colors
        header_bg = ['#ff99cc', '#99ccff', '#99cc00', '#00ffff', '#00ffff']
        try:
            price_list_data = []
            for i in range(len(sheet_names)):
                dict = {}
                dict['sheet_name'] = sheet_names[i]
                dict['list_header_id'] = list_header_id[i]
                dict['generate_excel'] = True
                dict['is_cursor_open'] = False
                # dict['number_format'] = jsond['number_format']
                dict['file_name'] = 'standard_price_list'
                dict['header_bg'] = header_bg[i]
                price_list_data.append(dict)
            self.download_file(price_list_data)
        except Exception as e:
            logger.findaylog(""" @ 654 EXCEPTION - models - pricelists -
                             standard_sample_file """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - standard_sample_file(-)')
        return 'success'

    # Returns list of prices for items from oracle for selected price list
    def download_file(self, jsond):
        logger.addinfo('@ models - pricelists - download_file(+)')
        try:
            list_header_ids = []
            oracle_price_list = []
            excel_obj = []
            for i in range(len(jsond)):
                list_header_ids.append(jsond[i]['list_header_id'])
            is_cursor_open = jsond[0]['is_cursor_open']
            # list_header_id = jsond['list_header_id']
            if not is_cursor_open:
                self.acquire()

            # Get oracle prices for given list header ids
            query = self.sql_file['get_price_list']
            query = query % (',' . join([str(list_header_ids[i])
                                        for i in range(len(list_header_ids))]))
            self.cursor.execute(query)
            pricelist = Code_util.iterate_data(self.cursor)
            for i in range(len(jsond)):
                jsond[i]['oracle_prices'] = []
                for j in range(len(pricelist)):
                    if str(jsond[i]['list_header_id']) == str(pricelist[
                            j]['list_header_id']):
                        jsond[i]['oracle_prices'].append(pricelist[j])
                oracle_price_list.append(
                    {'list_header_id': jsond[i]['list_header_id'],
                     'oracle_prices': jsond[i]['oracle_prices']})
                if jsond[i]['generate_excel']:
                    excel_obj.append(jsond[i])
            if len(excel_obj) > 0:
                self.generate_excel(excel_obj)
        except Exception as e:
            logger.findaylog(""" @ 633 EXCEPTION - models - pricelists -
                             download_file """ + str(e))
            raise e
        finally:
            if not is_cursor_open:
                self.release()
        logger.addinfo('@ models - pricelists - download_file(-)')
        return oracle_price_list

    # Generate excel file
    def generate_excel(self, jsond):
        logger.addinfo('@ models - pricelists - generate_excel(+)')
        file_data = []
        try:
            list_header_ids = []
            for i in range(len(jsond)):
                list_header_ids.append(jsond[i]['list_header_id'])
            is_cursor_open = jsond[0]['is_cursor_open']
            if len(jsond) > 1:
                file_name = 'standard_price_list'
            else:
                file_name = jsond[0]['file_name']
            if is_cursor_open:
                query = self.sql_file['get_price_list_data']
                self.cursor.execute(query)
                file_data = Code_util.iterate_data(self.cursor)
                for i in range(len(jsond)):
                    jsond[i]['file_data'] = []
                    for j in range(len(file_data)):
                        if str(jsond[i]['batch_id']) == str(
                                file_data[j]['batch_id']):
                            jsond[i]['file_data'].append(file_data[j])
            workbook = xlsxwriter.Workbook('/tmp/' + file_name + '.xlsx')
            for k in range(len(jsond)):
                data = jsond[k]['oracle_prices']
                if 'file_data' in jsond[k]:
                    file_data = jsond[k]['file_data']
                else:
                    file_data = []
                sheet_name = file_name
                if 'sheet_name' in jsond[k]:
                    sheet_name = jsond[k]['sheet_name']

                # slice sheet name if no.of characters gretaer than 31
                if len(sheet_name) > 31:
                    sheet_name = sheet_name[0:29]
                    sheet_name = sheet_name + '..'

                worksheet = workbook.add_worksheet(sheet_name)

                # Set column width for first 2 columns in excel
                worksheet.set_column('A:C', 15)

                # Add background color to column names
                header_bg = 'white'
                if 'header_bg' in jsond[k]:
                    header_bg = jsond[k]['header_bg']

                # Set background color to sheet name tabs
                worksheet.set_tab_color(header_bg)

                for i in range(len(file_data)):
                    file_data[i]['oracle_price'] = None
                    for j in range(len(data)):
                        if file_data[i]['item_code'] == data[
                                j]['item_code']:
                            file_data[i][
                                'oracle_price'] = float(data[j]['price'])
                            break

                # In excel for uploaded file include file price & oracle price
                if len(file_data) > 0:
                    # format number to decimal points
                    for i in range(len(file_data)):
                        if file_data[i]['price'] is not None:
                            file_data[i]['price'] = round(
                                float(file_data[i]['price']), 3)
                    column_names = ['item_code', 'price', 'oracle_price']
                    data = file_data
                else:
                    column_names = ['item_code', 'price']
                bold = workbook.add_format({'bold': True,
                                            'font_size': 9,
                                            'bg_color': header_bg,
                                            'border': 1,
                                            'border_color': 'black'})

                # Build headers in excel
                worksheet.write('A1', 'Item Code', bold)
                if len(file_data) > 0:
                    worksheet.write('B1', 'Price in File', bold)
                    worksheet.write('C1', 'Existing Price list', bold)
                else:
                    worksheet.write('B1', 'Existing Price list', bold)

                row = 1
                col = 0
                font_format = workbook.add_format()
                font_format.set_font_size(9)

                align_number = workbook.add_format({'font_size': 9,
                                                    'align': 'right',
                                                    'num_format': '#,##0.00'})

                red_format = workbook.add_format({'font_size': 9,
                                                  'bg_color': 'red',
                                                  'align': 'right',
                                                  'bold': True,
                                                  'num_format': '#,##0.00'})

                # To build rows in excel
                for i in range(len(data)):
                    col = 0
                    for j in range(len(column_names)):
                        # set red font color if file price is not updated
                        if ('oracle_price' in data[i]) and (
                                str(data[i]['oracle_price']
                                    ) != str(data[i]['price'])
                        ) and (column_names[j] == 'price') and (
                                data[i]['price'] is not None) and (
                                data[i]['price'] != ''):
                            worksheet.write_number(
                                row, col, data[i][column_names[j]],
                                red_format)
                        elif j == 0:
                            worksheet.write_string(
                                row, col, data[i][column_names[j]],
                                font_format)
                        elif j == 1 and data[i]['price'] is None:
                            worksheet.write(row, col, None, red_format)
                        elif j == 2 and data[i]['oracle_price'] is None:
                            worksheet.write(row, col, None, align_number)
                        else:
                            worksheet.write_number(
                                row, col, data[i][column_names[j]],
                                align_number)
                        col = col + 1
                    row = row + 1
            workbook.close()
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - pricelists -
                             generate_excel """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - generate_excel(-)')
        return

    # Insert deleted products with end date
    def insert_deleted_products(self, deleted_products):
        logger.addinfo('@ models - pricelists - insert_deleted_products(+)')
        try:
            query = self.sql_file['insert_deleted_products']
            self.cursor.executemany(query, deleted_products)
            self.connection.commit()
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - pricelists -
                             insert_deleted_products """ + str(e))
            raise e
        logger.addinfo('@ models - pricelists - insert_deleted_products(-)')
        return 'success'
