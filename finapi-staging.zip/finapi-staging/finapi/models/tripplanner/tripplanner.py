import cx_Oracle
import os
import datetime
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.logdata import logger
from mailjet_rest import Client


class TripPlanner:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def activity_add(self, data):
        logger.addinfo('@ models - tripplanner - activity_add(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            trip_id = self.cursor.var(cx_Oracle.NUMBER)
            attachment_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)

            if data['activity_type'] == 'Trip':
                self.cursor.execute("""
                        begin
                            qpex_tripplanner_pkg.add_trip(
                            :x_trip_id,
                            :p_user_id,
                            :p_trip_title,
                            :p_trip_description,
                            :p_start_date,
                            :p_end_date,
                            :p_trip_budget,
                            :p_currency_code,
                            :p_location,
                            :p_status,
                            :p_approval_status,
                            :p_approval_id,
                            :p_purpose_achieved,
                            :p_notes,
                            :p_has_attachments,
                            :p_org_id,
                            :p_hotel,
                            :p_transport,
                            :p_transport_budget,
                            :p_entertainment_expenses,
                            :p_entertainment_budget,
                            :p_activity_type,
                            :x_status_code
                            );
                        end; """, x_trip_id=trip_id,
                                    p_user_id=int(data['user_id']),
                                    p_trip_title=data['trip_title'],
                                    p_trip_description=data['trip_description'],
                                    p_start_date=data['start_date'],
                                    p_end_date=data['end_date'],
                                    p_trip_budget=data['trip_budget'],
                                    p_currency_code=data['currency_code'],
                                    p_location=data['location'],
                                    p_status=data['status'],
                                    p_approval_status=data['approval_status'],
                                    p_approval_id=data['approval_id'],
                                    p_purpose_achieved=data['purpose_achieved'],
                                    p_notes=data['notes'],
                                    p_has_attachments=data['has_attachments'],
                                    p_org_id=data['org_id'],
                                    p_hotel=data['hotel_accomodation'],
                                    p_transport=data['transport'],
                                    p_transport_budget=data['transport_budget'],
                                    p_entertainment_expenses=data['entertainment_expenses'],
                                    p_entertainment_budget=data['entertainment_budget'],
                                    p_activity_type=data['activity_type'],
                                    x_status_code=status_code)
            else:
                if data['activity_type'] == 'Task':
                    self.cursor.execute("""
                            begin
                                qpex_tripplanner_pkg.add_task(
                                :x_trip_id,
                                :p_user_id,
                                :p_trip_title,
                                :p_trip_description,
                                :p_start_date,
                                :p_notes,
                                :p_approval_status,
                                :p_approval_id,
                                :p_org_id,
                                :p_activity_type,
                                :x_status_code
                                );
                            end; """, x_trip_id=trip_id,
                                        p_user_id=int(data['user_id']),
                                        p_trip_title=data['trip_title'],
                                        p_trip_description=data['trip_description'],
                                        p_start_date=data['start_date'],
                                        p_notes=data['notes'],
                                        p_approval_status=data['approval_status'],
                                        p_approval_id=data['approval_id'],
                                        p_org_id=data['org_id'],
                                        p_activity_type=data['activity_type'],
                                        x_status_code=status_code)
            status = status_code.getvalue()
            if data['activity_type'] == 'Trip' and data['has_attachments'] == 'Y' and \
               status == 'SUCCESS':
                self.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
                attachments = data['attachments']
                for i in range(len(attachments)):
                    self.cursor.execute("""
                                        begin
                                            qpex_tripplanner_pkg.add_attachment(
                                            :p_trip_id,
                                            :x_attachment_id,
                                            :p_file_name,
                                            :p_file_type,
                                            :p_file_content,
                                            :p_user_id,
                                            :x_status_code
                                            );
                                        end; """, p_trip_id=trip_id,
                                        x_attachment_id=attachment_id,
                                        p_file_name=attachments[i]['file_name'],
                                        p_file_type=attachments[i]['file_type'],
                                        p_file_content=attachments[i]['file_content'],
                                        p_user_id=int(data['user_id']),
                                        x_status_code=status_code)
                status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = data['activity_type'] + ' added successfully'
                result['trip_id'] = int(trip_id.getvalue())
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add - ' + str(status)
                result['trip_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 154 EXCEPTION models - tripplanner -
            activity_add """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - activity_add(-)')
        return result

    def get_trip_details(self, jsond):
        logger.addinfo('@ models - tripplanner - get_trip_details(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['get_trip_details']
            if 'users' in jsond:
                user_ids = ','.join("'" + jsond['users'][i] + "'"
                                for i in range(len(jsond['users'])))
                query += " AND qtc.requested_id IN ({0})"
                query = query.format(user_ids)
            elif 'trips' not in jsond:
                query_all = self.sql_file['all_trip_users']
                self.cursor.execute(query_all,p_start_date=jsond['start_date'],
                                p_end_date=jsond['end_date'])
                result['employees'] = Code_util.iterate_data(self.cursor)
            if 'trips' in jsond:
                trip_ids = ','.join(str(jsond['trips'][i])
                                for i in range(len(jsond['trips'])))
                query += " AND qtc.trip_id IN ({})"
                query = query.format(trip_ids)
            self.cursor.execute(query, p_start_date=jsond['start_date'],
                                p_end_date=jsond['end_date'])
            # result['result'] = Code_util.iterate_data(self.cursor)
            records = Code_util.iterate_data(self.cursor)
            trips = list([d for d in records if d['activity_type'] == 'Trip'])
            tasks = list([d for d in records if d['activity_type'] == 'Task'])
            result['trips'] = trips
            result['tasks'] = tasks
        except Exception as e:
            logger.findaylog(""" @ 194 EXCEPTION - models - tripplanner -
                get_trip_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - get_trip_details(-)')
        return result

    def attachment_data(self, attachment_id):
        logger.addinfo("@ models - tripplanner - attachment_data(+)")
        try:
            self.acquire()
            query = self.sql_file['trip_attachment_data_query']
            self.cursor.execute(query,
                                p_attachment_id=attachment_id)
            field_data = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                data = {}
                for index, field in enumerate(field_names):
                    if field == 'file_content':
                        encoded_string = ''
                        if row[index]:
                            encoded_string = row[index].read()
                        data[field] = encoded_string
                    else:
                        data[field] = row[index]
                field_data.append(data)
        except Exception as e:
            logger.findaylog("""@ 225 EXCEPTION - models -
            tripplanner - attachment_data""" + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo("@ models - tripplanner - attachment_data(-)")
        return field_data

    def get_managers_lov(self, user_id):
        logger.addinfo('@ models - tripplanner - get_managers_lov(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['check_reports_to_id']
            self.cursor.execute(query, p_user_id=user_id)
            manager = Code_util.iterate_data(self.cursor)
            result['managers'] = manager
            query = self.sql_file['employee_list']
            self.cursor.execute(query, p_user_id=user_id)
            employee = Code_util.iterate_data(self.cursor)
            result['employees'] = employee
            result['status'] = 0
        except Exception as e:
            logger.findaylog(""" @ 248 EXCEPTION - models - tripplanner -
                get_managers_lov """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - get_managers_lov(-)')
        return result

    def activity_update(self, data):
        logger.addinfo('@ models - tripplanner - activity_update(+)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            mail_details = {}
            query = self.sql_file['get_mail_id']
            user_details = self.cursor.execute(query, p_user_id=data['user_id'])
            user_data = Code_util.iterate_data(user_details)
            mail_details['user_email'] = user_data[0]['email_address']
            mail_details['user_name'] = user_data[0]['user_description']

            query = self.sql_file['get_mail_id']
            # Get manager mail_address and name
            self.cursor.execute(query, p_user_id=data['approval_id'])
            user_data = Code_util.iterate_data(self.cursor)
            mail_details['manager_email'] = user_data[0]['email_address']
            mail_details['manager_name'] = user_data[0]['user_description']

            mail_details['applied_user_name'] = data['user_name']

            if data['activity_type'] == 'Trip' :
                result = self.trip_update(data, mail_details)
            else:
                result = self.task_update(data, mail_details)
        except Exception as e:
            logger.findaylog("""@ 285 EXCEPTION models - tripplanner -
                trip_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - trip_update(-)')
        return result

    # for updating a trip in activity planner  
    def trip_update(self, data, mail_details):
        logger.addinfo('@ models - tripplanner - trip_update(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    qpex_tripplanner_pkg.trip_update(
                                    :p_trip_id,
                                    :p_user_id,
                                    :p_trip_title,
                                    :p_trip_description,
                                    :p_start_date,
                                    :p_end_date,
                                    :p_trip_budget,
                                    :p_currency_code,
                                    :p_location,
                                    :p_status,
                                    :p_approval_id,
                                    :p_approval_status,
                                    :p_approval_comments,
                                    :p_user_comments,
                                    :p_purpose_achieved,
                                    :p_notes,
                                    :p_has_attachments,
                                    :p_org_id,
                                    :p_hotel,
                                    :p_transport,
                                    :p_transport_budget,
                                    :p_entertainment_expenses,
                                    :p_entertainment_budget,
                                    :p_activity_type,
                                    :x_status_code
                                    );
                                end; """, p_trip_id=data['trip_id'],
                                p_user_id=int(data['user_id']),
                                p_trip_title=data['trip_title'],
                                p_trip_description=data['trip_description'],
                                p_start_date=data['start_date'],
                                p_end_date=data['end_date'],
                                p_trip_budget=data['trip_budget'],
                                p_currency_code=data['currency_code'],
                                p_location=data['location'],
                                p_status=data['status'],
                                p_approval_id=data['approval_id'],
                                p_approval_status=data['approval_status'],
                                p_approval_comments=data['approval_comments'],
                                p_user_comments=data['user_comments'],
                                p_purpose_achieved=data['purpose_achieved'],
                                p_notes=data['notes'],
                                p_has_attachments=data['has_attachments'],
                                p_org_id=data['org_id'],
                                p_hotel=data['hotel_accomodation'],
                                p_transport=data['transport'],
                                p_transport_budget=data['transport_budget'],
                                p_entertainment_expenses=data['entertainment_expenses'],
                                p_entertainment_budget=data['entertainment_budget'],
                                p_activity_type=data['activity_type'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                attachments = data['attachments']
                if len(attachments) > 0:
                    self.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
                    attachment_id = self.cursor.var(cx_Oracle.NUMBER)
                    for i in range(len(attachments)):
                        self.cursor.execute("""
                                                begin
                                                    qpex_tripplanner_pkg.add_attachment(
                                                    :p_trip_id,
                                                    :x_attachment_id,
                                                    :p_file_name,
                                                    :p_file_type,
                                                    :p_file_content,
                                                    :p_user_id,
                                                    :x_status_code
                                                    );
                                                    end; """, p_trip_id=data['trip_id'],
                                            x_attachment_id=attachment_id,
                                            p_file_name=attachments[i]['file_name'],
                                            p_file_type=attachments[i]['file_type'],
                                            p_file_content=attachments[i]['file_content'],
                                            p_user_id=int(data['user_id']),
                                            x_status_code=status_code)
                    status = status_code.getvalue()
                delete_attachments_id = data['delete_attachments']
                if len(delete_attachments_id) > 0:
                    for i in range(len(delete_attachments_id)):
                        self.cursor.execute("""
                         begin
                             qpex_tripplanner_pkg.delete_attachment(
                                 :p_attachment_id,
                                 :x_status_code
                             );
                         end; """, p_attachment_id=delete_attachments_id[i]['attachment_id'],
                                            x_status_code=status_code)
                status = status_code.getvalue()

                # for sending mails   
                self.send_trip_mails(data, mail_details)

            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Trip updated successfully'
                result['trip_id'] = data['trip_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update trip - ' + str(status)
                result['trip_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 407 EXCEPTION models - tripplanner -
                trip_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - trip_update(-)')
        return result

    # for updating a task in activity planner   
    def task_update(self, data, mail_details):
        logger.addinfo('@ models - tripplanner - trip_update(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()

            status_code = self.cursor.var(cx_Oracle.STRING)    
            self.cursor.execute("""
                        begin
                            qpex_tripplanner_pkg.task_update(
                            :p_trip_id,
                            :p_user_id,
                            :p_trip_title,
                            :p_trip_description,
                            :p_start_date,
                            :p_notes,
                            :p_approval_id,
                            :p_approval_status,
                            :p_approval_comments,
                            :p_org_id,
                            :p_activity_type,
                            :x_status_code
                            );
                        end; """, p_trip_id=data['trip_id'],
                        p_user_id=int(data['user_id']),
                        p_trip_title=data['trip_title'],
                        p_trip_description=data['trip_description'],
                        p_start_date=data['start_date'],
                        p_notes=data['notes'],
                        p_approval_id=data['approval_id'],
                        p_approval_status=data['approval_status'],
                        p_approval_comments=data['approval_comments'],
                        p_org_id=data['org_id'],
                        p_activity_type=data['activity_type'],
                        x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                # for sending mails   
                self.send_task_mails(data, mail_details)
                result['status'] = 0
                result['msg'] = 'Task updated successfully'
                result['trip_id'] = data['trip_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update trip - ' + str(status)
                result['trip_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 466 EXCEPTION models - tripplanner -
                trip_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - trip_update(-)')
        return result

    # Send mails for Trip
    def send_trip_mails(self, data, mail_details):
        logger.addinfo('@ models - tripplanner - send_trip_mails(-)')
        try:
            start_date = datetime.datetime.strptime(data['start_date'],'%d-%b-%Y')
            end_date = datetime.datetime.strptime(data['end_date'],'%d-%b-%Y')
            trips = [
                     {
                        'trip_name': data['trip_title'],
                        'start_date': data['start_date'],
                        'end_date': data['end_date'],
                        'location': data['location'],
                        'trip_budget': data['trip_budget'],
                        'currency_code': data['currency_code'],
                        'trip_id': data['trip_id'],
                        'user_id': data['user_id']
                    }
                ]
            user_trips = data['trip_id']
            user_id = data['user_id']

            if (data['clickedBtn'] == 'approve'  or data['clickedBtn'] == 'reject') and \
            (data['approval_status'] == 'Approved' or data['approval_status'] == 'Rejected'):
                
                if start_date == end_date:
                    subject = 'Trip: {0} has {1} your trip dated on {2}'.format(
                                                               data['approver_name'],
                                                               data['approval_status'].lower(),
                                                               data['start_date'])
                    template_subject = '{0} has <b>{1}</b> your <b>1</b> trip(s) dated on {2}'.format(
                                           data['approver_name'],
                                           data['approval_status'].lower(),
                                           data['start_date'])
                else:
                    subject = 'Trip: {0} has {1} your trips from {2} to {3}'.format(
                                           data['approver_name'],
                                           data['approval_status'].lower(),
                                           data['start_date'],
                                           data['end_date'])
                    template_subject = '{0} has <b>{1}</b> your <b>1</b> trip(s) from <b>{2}</b> to <b>{3}</b>'.format(
                                           data['approver_name'],
                                           data['approval_status'].lower(),
                                           data['start_date'],
                                           data['end_date'])

                jsond = {
                            'subjected_to': mail_details['user_name'],
                            'template_subject': template_subject,
                            'template_id': 755521,
                            'subjected_by': data['approver_name'],
                            'trips': trips,
                            'recipients': [mail_details['user_email']],
                            'approval_comments': data['approval_comments'],
                            'recipient_name': '',
                            'subject': subject,
                            'user_trips': user_trips,
                            'user_id': user_id
                        }
                self.send_new_email(jsond)

            if data['send_email'] == 'Y' and data['approval_status'] == 'Pending':
                                
                if start_date == end_date:
                    subject = 'Trip: {0} has submitted trip(s) dated on {1}'.format(
                                                               mail_details['applied_user_name'],
                                                               data['start_date'])
                    template_subject = '{0} has submitted <b>1</b> trip(s) dated on <b>{1}</b> \
                                 for approval'.format(mail_details['applied_user_name'],
                                                        data['start_date'])
                else:
                    subject = 'Trip: {0} has submitted trip(s) from {1} to {2} \
                                 for approval'.format(
                                           mail_details['applied_user_name'],
                                           data['start_date'],
                                           data['end_date'])
                template_subject = '{0} has submitted <b>1</b> trip(s) from <b>{1}</b> to <b>{2}</b> \
                                 for approval'.format(mail_details['applied_user_name'],
                                                      data['start_date'],
                                                      data['end_date'])
                jsond = {
                        'subjected_to': mail_details['manager_name'],
                        'template_subject': template_subject,
                        'template_id': 755521,
                        'subjected_by': mail_details['applied_user_name'],
                        'trips': trips,
                        'recipients': [mail_details['manager_email']],
                        'recipient_name': '',
                        'subject': subject,
                        'approval_comments': '',
                        'user_trips': user_trips,
                        'user_id': user_id
                        }
                status = self.send_new_email(jsond)

            if  data['send_email'] == 'Y' and data['approval_status'] == 'Deleted':
                if start_date == end_date:
                    subject = 'Trip: {0} has cancelled trip(s) dated on {1}.'.format(
                                                               mail_details['applied_user_name'],
                                                               data['start_date'])
                    template_subject = '{0} has cancelled their trip dated on <b>{1}</b>.'.format(
                                                                   mail_details['applied_user_name'],
                                                                   data['start_date'])
                else:
                    subject = 'Trip: {0} has cancelled trip(s) from {1} to {2}.'.format(
                                           mail_details['applied_user_name'],
                                           data['start_date'],
                                           data['end_date'])
                    template_subject = '{0} has cancelled their trip from <b>{1}</b> to <b>{2}</b>.'.format(
                                                                   mail_details['applied_user_name'],
                                                                   data['start_date'],
                                                                   data['end_date'])
                
                jsond = {
                        'subjected_to': mail_details['manager_name'],
                        'template_subject': template_subject,
                        'template_id': 755521,
                        'subjected_by': mail_details['applied_user_name'],
                        'trips': trips,
                        'recipients': [mail_details['manager_email']],
                        'recipient_name': '',
                        'subject': subject,
                        'approval_comments': '',
                        'user_trips': user_trips,
                        'user_id': user_id
                        }

                self.send_new_email(jsond)
        except Exception as e:
            logger.findaylog("""@ 281 EXCEPTION models - tripplanner -
                send_trip_mails """ + str(e))
            raise e
        logger.addinfo('@ models - tripplanner - send_trip_mails(-)')
        return "SUCCESS"

    # Send mails for Trip    
    def send_task_mails(self, data, mail_details):
        logger.addinfo('@ models - tripplanner - send_task_mails(-)')
        try:
            start_date = datetime.datetime.strptime(data['start_date'],'%d-%b-%Y')
            trips = [
                     {
                        'task_title': data['trip_title'],
                        'start_date': data['start_date'],
                        'task_id': data['trip_id'],
                        'user_id': data['user_id']
                    }
                ]
            user_tasks = data['trip_id']
            user_id = data['user_id']

            if (data['clickedBtn'] == 'approve'  or data['clickedBtn'] == 'reject') and \
            (data['approval_status'] == 'Approved' or data['approval_status'] == 'Rejected'):
                
                subject = 'Task: {0} has {1} your task dated on {2}.'.format(
                                                           data['approver_name'],
                                                           data['approval_status'].lower(),
                                                           data['start_date'])
                
                template_subject = '{0} has <b>{1}</b> your <b>1</b> task(s) dated on <b>{2}</b>.'.format(
                                       data['approver_name'],
                                       data['approval_status'].lower(),
                                       data['start_date'])

                jsond = {
                            'subjected_to': mail_details['user_name'],
                            'template_subject': template_subject,
                            'template_id': 775162,
                            'subjected_by': data['approver_name'],
                            'tasks': trips,
                            'recipients': [mail_details['user_email']],
                            'approval_comments': data['approval_comments'],
                            'recipient_name': '',
                            'subject': subject,
                            'user_tasks': user_tasks,
                            'user_id': user_id
                        }
                self.send_new_task_email(jsond)

            if data['send_email'] == 'Y' and data['approval_status'] == 'Pending':
                                
                subject = 'Task: {0} has submitted task dated on {1}.'.format(
                                                           mail_details['applied_user_name'],
                                                           data['start_date'])
                template_subject = '{0} has submitted <b>1</b> task(s) dated on <b>{1}</b> for approval.'.format(
                                                                   mail_details['applied_user_name'],
                                                                   data['start_date'])
                jsond = {
                        'subjected_to': mail_details['manager_name'],
                        'template_subject': template_subject,
                        'template_id': 775162,
                        'subjected_by': mail_details['applied_user_name'],
                        'tasks': trips,
                        'recipients': [mail_details['manager_email']],
                        'recipient_name': '',
                        'subject': subject,
                        'approval_comments': '',
                        'user_tasks': user_tasks,
                        'user_id': user_id
                        }
                status = self.send_new_task_email(jsond)
        except Exception as e:
            logger.findaylog("""@ 735 EXCEPTION models - tripplanner -
                send_trip_mails """ + str(e))
            raise e
        logger.addinfo('@ models - tripplanner - send_task_mails(-)')
        return "SUCCESS"


    def adding_to_expenses(self, data):
        logger.addinfo('@ models - tripplanner - adding_to_expenses(+)')
        result = dict()
        try:
            self.acquire()
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    qpex_tripplanner_pkg.trip_column_update(
                                    :p_trip_id,
                                    :p_expense_header_id,                  
                                    :x_status_code
                                    );
                                end; """, p_trip_id=data['trip_id'],
                                p_expense_header_id=data['expense_header_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Trip updated successfully'
                result['trip_id'] = data['trip_id']
                result['expense_header_id'] = data['expense_header_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update trip - ' + data['field_name']
                result['trip_id'] = -1
                result['expense_header_id'] = -1
        except Exception as e:
            logger.findaylog("""@ 281 EXCEPTION models - tripplanner -
                    adding_to_expenses """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - adding_to_expenses(-)')
        return result

    def get_user_trip_details(self, user_id, trip_id):
        logger.addinfo('@ models - tripplanner - get_user_trip_details(+)')
        try:
            self.acquire()
            query = self.sql_file['approved_trips']
            if trip_id is None:
                query += " AND qtc.start_date >= add_months(SYSDATE, -6)"
            self.cursor.execute(query, p_user_id = user_id, p_trip_id=trip_id)

            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - tripplanner -
                get_user_trip_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - get_user_trip_details(-)')
        return result

    def trip_status_change(self, jsond):
        logger.addinfo('@ models - tripplanner - trip_status_change(+)')
        try:
            self.acquire()
            trip_ids = ','.join(str(jsond['trips'][i])
                                for i in range(len(jsond['trips'])))
            if 'approval_comments' in jsond:
                query = self.sql_file['update_trip_status_with_comments']
            else:
                query = self.sql_file['update_trip_status']
            query = query.format(trip_ids)
            if 'approval_comments' in jsond:
                self.cursor.execute(query, p_status=jsond['status'], 
                                p_approval_comments=jsond['approval_comments'])
            else:
                self.cursor.execute(query, p_status=jsond['status'])
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - tripplanner -
                get_user_trip_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - get_user_trip_details(-)')
        return "SUCCESS"

    def status_mail(self, jsond):
        logger.addinfo('@ models - tripplanner - status_mail(+)')
        try:
            self.acquire()
            trip_ids = ','.join(str(jsond['trips'][i])
                                for i in range(len(jsond['trips'])))
            query = self.sql_file['send_email']
            query = query.format(trip_ids)
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor)
            dates = []
            for user in result:
                user_trips = ''
                for trip in user['trips']:
                    dates.append(datetime.datetime.strptime(trip['start_date'],'%d-%b-%Y'))
                    dates.append(datetime.datetime.strptime(trip['end_date'],'%d-%b-%Y'))
                    user_trips = ",".join([str(trip['trip_id']),user_trips])
                user_id = user['trips'][0]['user_id']
                old = min(dates)
                new_date = max(dates)
                user_trips = user_trips[:-1]
                if jsond['status'] == 'Pending':
                    if old == new_date:
                        subject = 'Trip: {0} has submitted trip(s)  dated on {1} \
                                 for approval'.format(
                                           user['employee_name'],
                                           old.strftime("%d-%b-%Y"))

                        template_subject = '{0} has submitted <b>{1}</b> trip(s) dated on <b>{2}</b> for approval.'.format(
                                                                        user['employee_name'],
                                                                        len(user['trips']),
                                                                        old.strftime("%d-%b-%Y"))
                    else:
                        subject = 'Trip: {0} has submitted trips from {1} to {2} \
                                     for approval'.format(
                                               user['employee_name'],
                                               old.strftime("%d-%b-%Y"),
                                               new_date.strftime("%d-%b-%Y"))
                        template_subject = '{0} has submitted <b>{1}</b> trip(s) from <b>{2}</b> to <b>{3}</b> for approval.'.format(
                                                                            user['employee_name'],
                                                                            len(user['trips']),
                                                                            old.strftime("%d-%b-%Y"),
                                                                            new_date.strftime("%d-%b-%Y"))

                    mail_json = {
                            'subjected_to': user['manager_name'],
                            'template_subject': template_subject,
                            'template_id': 755521,
                            'subjected_by': user['employee_name'],
                            'trips': user['trips'],
                            'recipients': [user['manager_email']],
                            'recipient_name': '',
                            'subject': subject,
                            'approval_comments': '',
                            'user_trips': user_trips,
                            'user_id': user_id
                            }
                else:
                    if old ==  new_date:
                        subject = 'Trip: {0} has {1} your trip dated on {2}'.format(
                                                               user['manager_name'],
                                                               jsond['status'].lower(),
                                                               old.strftime("%d-%b-%Y"))

                        template_subject = '{0} has <b>{1}</b> your <b>{2}</b> trip(s) dated on <b>{3}</b>.'.format(
                                           user['manager_name'],
                                           jsond['status'],
                                           len(user['trips']),
                                           old.strftime("%d-%b-%Y"))
                    else:
                        subject = 'Trip: {0} has {1} your trips from {2} to {3}'.format(
                                               user['manager_name'],
                                               jsond['status'].lower(),
                                               old.strftime("%d-%b-%Y"),
                                               new_date.strftime("%d-%b-%Y"))

                        template_subject = '{0} has <b>{1}</b> your <b>{2}</b> trip(s) from <b>{3}</b> to <b>{4}</b>.'.format(
                                               user['manager_name'],
                                               jsond['status'],
                                               len(user['trips']),
                                               old.strftime("%d-%b-%Y"),
                                               new_date.strftime("%d-%b-%Y"))
                    mail_json = {
                                'subjected_to': user['employee_name'],
                                'template_subject': template_subject,
                                'template_id': 755521,
                                'subjected_by': user['manager_name'],
                                'trips': user['trips'],
                                'recipients': [user['employee_email']],
                                'approval_comments': jsond['approval_comments'],
                                'recipient_name': '',
                                'subject': subject,
                                'user_trips': user_trips,
                                'user_id': user_id
                            }
                self.send_new_email(mail_json)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - tripplanner -
                get_user_trip_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - get_user_trip_details(-)')
        return "SUCCESS"


    def status_task_mail(self, jsond):
        logger.addinfo('@ models - tripplanner - status_task_mail(+)')
        try:
            self.acquire()
            trip_ids = ','.join(str(jsond['trips'][i])
                                for i in range(len(jsond['trips'])))
            query = self.sql_file['send_email']
            query = query.format(trip_ids)
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor)
            dates = []
            for user in result:
                user_tasks = ''
                for trip in user['trips']:
                    dates.append(datetime.datetime.strptime(trip['start_date'],'%d-%b-%Y'))
                    user_tasks = ",".join([str(trip['trip_id']),user_tasks])
                    trip["task_title"] = trip['trip_name']
                user_id = user['trips'][0]['user_id']
                old = min(dates)
                new_date = max(dates)
                user_tasks = user_tasks[:-1]
                if jsond['status'] == 'Pending':
                    if old == new_date:
                        subject = 'Task: {0} has submitted tasks dated on {1}\
                                     for approval'.format(
                                               user['employee_name'],
                                               old.strftime("%d-%b-%Y"))

                        template_subject = '{0} has submitted <b>{1}</b> task(s) dated on <b>{2}</b> \
                                            for approval.'.format(user['employee_name'],
                                                                 len(user['trips']),
                                                                 old.strftime("%d-%b-%Y"))
                    else:
                        subject = 'Task: {0} has submitted tasks from {1} to {2} \
                                 for approval'.format(
                                           user['employee_name'],
                                           old.strftime("%d-%b-%Y"),
                                           new_date.strftime("%d-%b-%Y"))

                        template_subject = '{0} has submitted <b>{1}</b> task(s) from <b>{2}</b> to <b>{3}</b> \
                                            for approval.'.format(user['employee_name'],
                                                                 len(user['trips']),
                                                                 old.strftime("%d-%b-%Y"),
                                                                 new_date.strftime("%d-%b-%Y"))

                    mail_json = {
                            'subjected_to': user['manager_name'],
                            'template_subject': template_subject,
                            'template_id': 775162,
                            'subjected_by': user['employee_name'],
                            'tasks': user['trips'],
                            'recipients': [user['manager_email']],
                            'recipient_name': '',
                            'subject': subject,
                            'approval_comments': '',
                            'user_tasks': user_tasks,
                            'user_id': user_id
                            }
                else:
                    if old ==  new_date:
                        subject = 'Task: {0} has {1} your task dated on {2}'.format(
                                                               user['manager_name'],
                                                               jsond['status'].lower(),
                                                               old.strftime("%d-%b-%Y"))
                        template_subject = '{0} has <b>{1}</b> your <b>{2}</b> task(s) dated on <b>{3}</b>.'.format(
                                               user['manager_name'],
                                               jsond['status'],
                                               len(user['trips']),
                                               old.strftime("%d-%b-%Y"))
                    else:
                        subject = 'Task: {0} has {1} your tasks from {2} to {3}'.format(
                                               user['manager_name'],
                                               jsond['status'].lower(),
                                               old.strftime("%d-%b-%Y"),
                                               new_date.strftime("%d-%b-%Y"))

                        template_subject = '{0} has <b>{1}</b> your <b>{2}</b> task(s) from <b>{3}</b> to <b>{4}</b>.'.format(
                                               user['manager_name'],
                                               jsond['status'],
                                               len(user['trips']),
                                               old.strftime("%d-%b-%Y"),
                                               new_date.strftime("%d-%b-%Y"))
                    mail_json = {
                                'subjected_to': user['employee_name'],
                                'template_subject': template_subject,
                                'template_id': 775162,
                                'subjected_by': user['manager_name'],
                                'tasks': user['trips'],
                                'recipients': [user['employee_email']],
                                'approval_comments': jsond['approval_comments'],
                                'recipient_name': '',
                                'subject': subject,
                                'user_tasks': user_tasks,
                                'user_id': user_id
                            }
                self.send_new_task_email(mail_json)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - tripplanner -
                get_user_trip_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tripplanner - get_user_trip_details(-)')
        return "SUCCESS"

    def send_new_email(self, jsond):
        logger.addinfo('models - tripplanner - send_email(+)')
        try:
            recipients = []
            for i in range(len(jsond['recipients'])):
                recipients.append({
                    'Email': jsond['recipients'][i]
                })
            api_key = os.environ['MJ_APIKEY_PUBLIC']
            api_secret = os.environ['MJ_APIKEY_PRIVATE']
            mailjet = Client(auth=(api_key, api_secret))
            mail_data = {
                'FromEmail': self.strings['sender_email'],
                'FromName': self.strings['sender_name'],
                'Subject': jsond['subject'],
                'MJ-TemplateID': jsond['template_id'],
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': self.strings['mj_error_report_mail'],
                'Vars': {
                            'subjected_to': jsond['subjected_to'],
                            'template_subject': jsond['template_subject'],
                            'subjected_by': jsond['subjected_by'],
                            'trips': jsond['trips'],
                            'approval_comments': jsond['approval_comments'],
                            'subject': jsond['subject'],
                            'user_trips': jsond['user_trips'],
                            'user_id':jsond['user_id']
                        },
                'Recipients': recipients
            }
            mailjet.send.create(data=mail_data)
            status = 'SUCCESS'
        except Exception as e:
            status = 'FAILED'
            raise
        return status


    def send_new_task_email(self, jsond):
        logger.addinfo('models - tripplanner - send_email(+)')
        try:
            recipients = []
            for i in range(len(jsond['recipients'])):
                recipients.append({
                    'Email': jsond['recipients'][i]
                })
            api_key = os.environ['MJ_APIKEY_PUBLIC']
            api_secret = os.environ['MJ_APIKEY_PRIVATE']
            mailjet = Client(auth=(api_key, api_secret))
            mail_data = {
                'FromEmail': self.strings['sender_email'],
                'FromName': self.strings['sender_name'],
                'Subject': jsond['subject'],
                'MJ-TemplateID': jsond['template_id'],
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': self.strings['mj_error_report_mail'],
                'Vars': {
                            'subjected_to': jsond['subjected_to'],
                            'template_subject': jsond['template_subject'],
                            'subjected_by': jsond['subjected_by'],
                            'tasks': jsond['tasks'],
                            'approval_comments': jsond['approval_comments'],
                            'subject': jsond['subject'],
                            'user_tasks': jsond['user_tasks'],
                            'user_id':jsond['user_id']
                        },
                'Recipients': recipients
            }
            mailjet.send.create(data=mail_data)
            status = 'SUCCESS'
        except Exception as e:
            status = 'FAILED'
            raise
        return status

    def activity_user_summary(self, data):
        logger.addinfo('models - tripplanner - activity_user_summary(+)')
        try:
            result = {}
            leaves_applied = 0
            self.acquire()
            query = self.sql_file['get_employee_leave_summary']
            self.cursor.execute(query, p_user_id=data['user_id'],
                                       p_org_id=data['org_id'],
                                        p_start_date=data['start_date'],
                                        p_end_date=data['end_date'])
            leaves_list = Code_util.iterate_data(self.cursor)
            for x in leaves_list:
                if (x['full_day'] != 'Y'):
                    hours = x['leave_hours'].split(':');
                    x['no_of_days'] = (float(hours[0]) + (float(hours[1]) / 60)) / 8
                else:
                    x['no_of_days'] = 1
                leaves_applied += x['no_of_days']
            query = self.sql_file['get_holiday_list_count']
            self.cursor.execute(query,p_org_id=data['org_id'],
                                        p_start_date=data['start_date'],
                                        p_end_date=data['end_date'])
            holidays_list = Code_util.iterate_data(self.cursor)
            holidays = holidays_list[0]['holidays_count']
            now = datetime.datetime.strptime(data['start_date'], "%d-%b-%Y")
            businessdays = 0
            for i in range(1, 32):
                try:
                    thisdate = datetime.date(now.year, now.month, i)
                except(ValueError):
                    break
                if thisdate.weekday() < 5: # Monday == 0, Sunday == 6 
                    businessdays += 1

            result['working_days'] = businessdays - int(holidays)
            result['present_days'] = float(result['working_days']) - float(leaves_applied)


        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - tripplanner -
                activity_user_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - tripplanner - activity_user_summary(-)')
        return result


    # def delete_trip(self, trip_id, attachment_id):
    #     logger.addinfo('@ models - tripplanner - delete_trip(+)')
    #     result = {}
    #     try:
    #         if not self.is_acquired:
    #             self.acquire()
    #         status_code = self.cursor.var(cx_Oracle.STRING)
    #         if attachment_id:
    #             self.cursor.execute("""
    #             begin
    #                 qpex_tripplanner_pkg.delete_attachment(
    #                     :p_attachment_id,
    #                     :x_status_code
    #                 );
    #             end; """, p_attachment_id=attachment_id,
    #                                 x_status_code=status_code)
    #             status = status_code.getvalue()
    #             if status == 'SUCCESS':
    #                 result['status'] = 0
    #                 result['msg'] = 'Attachment deleted successfully'
    #                 result['trip_id'] = trip_id
    #             else:
    #                 result['status'] = 1
    #                 result['msg'] = 'Failed to delete Attachment - ' + str(status)
    #                 result['trip_id'] = -1
    #         else:
    #             self.cursor.execute("""
    #             begin
    #                 qpex_tripplanner_pkg.delete_trip(
    #                     :p_trip_id,
    #                     :x_status_code
    #                 );
    #             end; """, p_trip_id=trip_id,
    #                                 x_status_code=status_code)
    #             status = status_code.getvalue()
    #             if status == 'SUCCESS':
    #                 result['status'] = 0
    #                 result['msg'] = 'Trip deleted successfully'
    #                 result['trip_id'] = trip_id
    #             else:
    #                 result['status'] = 1
    #                 result['msg'] = 'Failed to delete Trip - ' + str(status)
    #                 result['trip_id'] = -1
    #     except Exception as e:
    #         logger.findaylog("""@ EXCEPTION models - tripplanner -
    #             delete_trip """ + str(e.message))
    #         raise e
    #     finally:
    #         if self.is_acquired:
    #             self.connection.commit()
    #             self.release()
    #     logger.addinfo('@ models - tripplanner - delete_trip(-)')
    #     return result




