from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil


class Dispute:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def getinvoicebyid(ptrxId):
        logger.addinfo('@ models - dispute - getinvoicebyid(+)')
        dispute_list = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["invoice_header"]
            cursor.execute(query, pcust_trx_id=ptrxId)
            fieldnames = [a[0].lower() for a in cursor.description]
            field_types = [a[1] for a in cursor.description]
            datatype = {}
            dispute_list.append(setHeader(fieldnames, field_types, datatype))
            dispute_lines = Dispute.getinvoicelines(ptrxId)
            for dispute in cursor:
                tmpdispute = {}
                for index, fn in enumerate(fieldnames):
                    tmpdispute[fn] = dispute[index]
                tmpdispute['lines'] = dispute_lines
                dispute_list.append(tmpdispute)
        except Exception as error:
            logger.findaylog("""@ 36 EXCEPTION - models - dispute -
                 getinvoicebyid """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - dispute - getinvoicebyid(-)')
        return dispute_list

    @staticmethod
    def getinvoicelines(ptrxId):
        logger.addinfo('@ models - dispute - getinvoicelines(+)')
        dispute_lines = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["invoice_lines"]
            cursor.execute(query, pcust_trx_id=ptrxId)
            fieldnames = [a[0].lower() for a in cursor.description]
            field_types = [a[1] for a in cursor.description]
            datatype = {}
            dispute_lines.append(setHeader(fieldnames, field_types, datatype))
            for dispute in cursor:
                tmpdispute = {}
                for index, fn in enumerate(fieldnames):
                    tmpdispute[fn] = dispute[index]
                dispute_lines.append(tmpdispute)
        except Exception as error:
            logger.findaylog("""@ 68 EXCEPTION - models - dispute -
                 getinvoicelines(+) """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - dispute - getinvoicelines(-)')
        return dispute_lines

    @staticmethod
    def getdisputedata(preqid, ptrxid):
        logger.addinfo('@ models - dispute - getdisputedata(+)')
        dispute_list = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["dispute_header"]
            cursor.execute(query, preq_id=preqid, ptrx_id=ptrxid)
            fieldnames = [a[0].lower() for a in cursor.description]
            field_types = [a[1] for a in cursor.description]
            datatype = {}
            dispute_list.append(setHeader(fieldnames, field_types, datatype))
            dispute_lines = []
            if preqid:
                dispute_lines = Dispute.getdisputelines(preqid)
            for dispute in cursor:
                tmpdispute = {}
                for index, fn in enumerate(fieldnames):
                    tmpdispute[fn] = dispute[index]
                tmpdispute['lines'] = dispute_lines
                dispute_list.append(tmpdispute)
        except Exception as error:
            logger.findaylog("""@ 104 EXCEPTION - models - dispute -
                 getdisputedata """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - dispute - getdisputedata(-)')
        return dispute_list

    @staticmethod
    def getdisputelines(preqid):
        logger.addinfo('@ models - dispute - getdisputelines(+)')
        dispute_lines = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["dispute_lines"]
            cursor.execute(query, preq_id=preqid)
            fieldnames = [a[0].lower() for a in cursor.description]
            field_types = [a[1] for a in cursor.description]
            datatype = {}
            dispute_lines.append(setHeader(fieldnames, field_types, datatype))
            for dispute in cursor:
                tmpdispute = {}
                for index, fn in enumerate(fieldnames):
                    tmpdispute[fn] = dispute[index]
                dispute_lines.append(tmpdispute)
        except Exception as error:
            logger.findaylog("""@ 136 EXCEPTION - models - dispute -
                 getdisputelines """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - dispute - getdisputelines(-)')
        return dispute_lines


def setHeader(fieldnames, field_types, Object):
    logger.addinfo('@ models - dispute - setHeader(+)')
    for index, fn in enumerate(fieldnames):
        type_str = str(field_types[index])
        for ch in ['cx_Oracle', '.', '<', '>', '\'', 'type']:
            if ch in type_str:
                type_str = type_str.replace(ch, "")
        type_str = type_str.strip()
        Object[fn] = type_str
    logger.addinfo('@ models - dispute - setHeader(-)')
    return Object


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'dispute',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
