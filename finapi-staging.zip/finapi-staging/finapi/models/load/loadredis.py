
from finapi.utils import db_util
from finapi.utils import reports_util
from finapi.utils.logdata import logger
import threading


class LoadRedis:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def loadPeriods(r):
        logger.addinfo('@ models - load - loadPeriods(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.get_reports_sql()
            query = sqlFile['periods_lov_query']
            data = cursor.execute(query).fetchall()
            pipe = r.pipeline()

            for i, row in enumerate(data):
                obj = {}
                fieldnames = [a[0].lower() for a in cursor.description]
                for index, field in enumerate(fieldnames):
                    if field == 'period':
                        obj[field] = row[index]

                key = 'Periods'
                pipe.zadd(key, i, obj['period'])

            pipe.execute()
        except Exception as error:
            logger.findaylog("""@ 37 EXCEPTION - models - load -
                 loadPeriods """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - load - loadPeriods(-)')
        return 'success'

    @staticmethod
    def loadSalesChannels(r):
        logger.addinfo('@ models - load - loadSalesChannels(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.get_reports_sql()
            query = sqlFile['sales_channels_query']
            data = cursor.execute(query).fetchall()
            pipe = r.pipeline()

            for i, row in enumerate(data):
                obj = {}
                fieldnames = [a[0].lower() for a in cursor.description]
                for index, field in enumerate(fieldnames):
                    if field == 'group_name':
                        obj[field] = row[index]

                key = 'SalesChannels'
                pipe.zadd(key, i, obj['group_name'])

            pipe.execute()
        except Exception as error:
            logger.findaylog("""@ 69 EXCEPTION - models - load -
                 loadSalesChannels """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - load - loadSalesChannels(-)')

    def report_thread(self, r, report):
        LoadRedis.loadReport(r, report)

    @staticmethod
    def loadCruscott(r):
        logger.addinfo('@ models - load - loadCruscott(+)')
        status = LoadRedis.loadReport(r, 'cruscott')
        logger.addinfo('@ models - load - loadCruscott(-)')
        return status

    @staticmethod
    def loadCruscottSales(r):
        logger.addinfo('@ models - load - loadCruscottSales(+)')
        status = LoadRedis.loadReport(r, 'cruscott_sales')
        logger.addinfo('@ models - load - loadCruscottSales(-)')
        return status

    @staticmethod
    def loadAgentsRevenue(r):
        logger.addinfo('@ models - load - loadAgentsRevenue(+)')
        status = LoadRedis.loadReport(r, 'revenue_agent')
        logger.addinfo('@ models - load - loadAgentsRevenue(-)')
        return status

    def loadSegments(self, r):
        logger.addinfo('@ models - load - loadSegments(+)')
        thread = threading.Thread(target=self.report_thread,
                                  args=(r, 'revenue_segments'))
        thread.start()
        logger.addinfo('@ models - load - loadSegments(-)')
        return 'success'

    @staticmethod
    def loadSalesNetworks(r):
        logger.addinfo('@ models - load - loadSalesNetworks(+)')
        status = LoadRedis.loadReport(r, 'revenue_network')
        logger.addinfo('@ models - load - loadSalesNetworks(-)')
        return status

    @staticmethod
    def loadItems(r):
        logger.addinfo('@ models - load - loadItems(+)')
        status = LoadRedis.loadReport(r, 'revenue_items')
        logger.addinfo('@ models - load - loadItems(-)')
        return status

    @staticmethod
    def loadItemsAgent(r):
        logger.addinfo('@ models - load - loadItemsAgent(+)')
        status = LoadRedis.loadReport(r, 'revenue_items_agent')
        logger.addinfo('@ models - load - loadItemsAgent(-)')
        return status

    @staticmethod
    def loadSegmentsAgent(r):
        logger.addinfo('@ models - load - loadSegmentsAgent(+)')
        status = LoadRedis.loadReport(r, 'revenue_segments_agent')
        logger.addinfo('@ models - laod - loadSegmentsAgent(-)')
        return status

    @staticmethod
    def loadSalesAvg(r):
        logger.addinfo('@ models - load - loadSalesAvg(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            pipe = r.pipeline()
            query = reports_util.get_query('sales_avg')
            key_list = reports_util.get_key_list('sales_avg')
            size = len(key_list)

            cursor.arraysize = 1000
            cursor.execute(query, P_YEAR='2015')
            for i, row in enumerate(cursor):
                obj = {}
                keys = {}
                fieldnames = [a[0].lower() for a in cursor.description]
                for index, field in enumerate(fieldnames):
                    value = ''
                    if row[index] is None:
                        obj[field] = value
                    else:
                        value = row[index]
                        obj[field] = value

                    if field in key_list:
                        keys[field] = value

                key = key_list[0] + ':'
                for j in range(size - 2):
                    key = key + str(keys[key_list[j + 1]]) + ':'
                key = key + str(keys[key_list[size - 1]])
                pipe.hmset(key, obj)
            if i % 1000 == 0:
                pipe.execute()

            pipe.execute()
        except Exception as error:
            logger.findaylog("""@ 175 EXCEPTION - models - load -
                 loadSalesAvg """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - load - loadSalesAvg(-)')
        return 'success'

    @staticmethod
    def loadBrand(r):
        logger.addinfo('@ models - load - loadBrand(+)')
        status = LoadRedis.loadReport(r, 'revenue_brand')
        logger.addinfo('@ models - load - loadBrand(-)')
        return status

    @staticmethod
    def loadBrandAgent(r):
        logger.addinfo('@ models - load - loadBrandAgent(+)')
        status = LoadRedis.loadReport(r, 'revenue_brand_agent')
        logger.addinfo('@ models - load - loadBrandAgent(-)')
        return status

    @staticmethod
    def loadClass(r):
        logger.addinfo('@ models - load - loadClass(+)')
        status = LoadRedis.loadReport(r, 'revenue_class')
        logger.addinfo('@ models - load - loadClass(-)')
        return status

    @staticmethod
    def loadReport(r, report_name):
        logger.addinfo('@ models - load - loadReport(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.get_reports_sql()
            periods_query = sqlFile['periods_query']

            periods = cursor.execute(periods_query).fetchall()
            query = reports_util.get_query(report_name)
            key_list = reports_util.get_key_list(report_name)
            size = len(key_list)
            for period in periods:
                pipe = r.pipeline()
                cursor.execute(query, P_PERIOD=str(period[0]))
                for row in cursor:
                    obj = {}
                    keys = {}
                    fieldnames = [a[0].lower() for a in cursor.description]
                    for index, field in enumerate(fieldnames):
                        value = ''
                        if row[index] is None:
                            obj[field] = value
                        else:
                            value = row[index]
                            obj[field] = value

                        if field in key_list:
                            keys[field] = value

                    key = key_list[0] + ':'
                    for i in range(size - 2):
                        key = key + str(keys[key_list[i + 1]]) + ':'
                    key = key + str(keys[key_list[size - 1]])
                    pipe.hmset(key, obj)

            pipe.execute()
        except Exception as error:
            logger.findaylog("""@ 246 EXCEPTION - models - load -
                 loadReport """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - load - loadReport(-)')
        return 'success'
