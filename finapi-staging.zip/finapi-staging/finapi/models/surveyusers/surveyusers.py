from finapi.utils import db_util
from finapi.utils.logdata import logger
import cx_Oracle
from finapi.models.usermngmnt.users import Users
import ujson


class Surveyusers:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_users(email_id):
        logger.addinfo('@ models - surveyusers - get_users(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_users_query']
            user_details = []
            cursor.execute(query, p_contact=email_id)
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                user = Surveyusers()
                for index, fn in enumerate(fieldnames):
                    setattr(user, fn, row[index])
                user_details.append(user)
        except Exception as error:
            logger.findaylog("""@ 31 EXCEPTION - models - surveyusers -
                 get_users """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveyusers - get_users(-)')
        return user_details

    @staticmethod
    def approve_user(user_id):
        logger.addinfo("@ models - surveyusers - approve_user(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            return_value = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
            QPEX_SURVEYS_PKG.APPROVE_USER(:p_user_id, :status);
            end;""", p_user_id=user_id, status=return_value)
            if return_value.getvalue() == 'S':
                query = sql_file['get_user_details']
                cur = connection.cursor()
                cur.execute(query, p_user_id=user_id)
                fieldnames = [a[0].lower() for a in cur.description]
                for row in cur:
                    user = Surveyusers()
                    for index, fn in enumerate(fieldnames):
                        setattr(user, fn, row[index])
                tmp_user = ujson.dumps(user)
                final_user = ujson.loads(tmp_user)
                cur.close()
                result = Users.email_service(final_user['email_address'],
                                             final_user['password'],
                                             final_user['email_address'],
					     'reddy@finday.com',
					     'chris@finday.com')
        except Exception as error:
            logger.findaylog("""@ 52 EXCEPTION - models - surveyusers -
                 approve_user """ + str(error.message))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - surveyusers - approve_user(-)")
        if return_value.getvalue() == 'S':
            return result
        else:
            return return_value.getvalue()
