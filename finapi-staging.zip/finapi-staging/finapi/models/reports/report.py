import os
import base64
import tempfile
from collections import OrderedDict

import cx_Oracle
import xlrd
import xlsxwriter
import redis

from xlsxwriter.utility import xl_rowcol_to_cell

from finapi.utils.log_util import LogUtil
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.constants import Status


@LogUtil.class_module_logs('report')
class Report:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    def get_data_array(self):
        result = []
        fieldnames = [a[0].lower() for a in self.cursor.description]
        for row in self.cursor:
            obj = {}
            for index, field_name in enumerate(fieldnames):
                obj[field_name] = row[index]
            result.append(obj)
        return result

    def get_array_chunks(self):
        while True:
            rows = self.cursor.fetchmany()
            if not rows:
                break
            yield rows

    def get_data_chunks(self):
        result = []
        fieldnames = [a[0].lower() for a in self.cursor.description]
        for index, chunk in enumerate(self.get_array_chunks()):
            for row in chunk:
                obj = {}
                for i, field_name in enumerate(fieldnames):
                    obj[field_name] = row[i]
                result.append(obj)
        return result

    def pmmv_report(self, jsond):
        logger.addinfo('@ models - report - pmmv_report(+)')
        group_name = None
        user_id = None
        try:
            year = jsond['year']
            if 'user_id' in jsond:
                user_id = jsond['user_id']
            if 'sales_grp_name' in jsond:
                group_name = jsond['sales_grp_name']
            self.acquire()
            if not group_name:
                salesid_qry = self.sql_file['salesgrp_names_query']
                self.cursor.execute(salesid_qry, p_user_id=user_id)
                ids = self.cursor.fetchall()
                length = len(ids)
                name_list = []
                for count in range(length):
                    name = ids[count][1]
                    name_list.append(name)
                query_temp = self.sql_file['pmmv_query']
                report_query = query_temp % (year, ',' . join([":" + str(i)
                                                               for i in range(len(name_list))]))
                self.cursor.execute(report_query, name_list)
            else:
                pmmv_sales = self.sql_file['pmmv_query_sales']
                self.cursor.execute(pmmv_sales, p_year=year,
                                    p_sales_grp_name=group_name)
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 pmmv_report """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - pmmv_report(-)')
        return result

    def get_cm_report(self):
        logger.addinfo('@ models - report - get_cm_report(+)')
        try:
            self.acquire()
            query = self.sql_file['creditmemo_report_query']
            self.cursor.execute(query)
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_cm_report """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_cm_report(-)')
        return result

    def invoice_by_segment(self, jsond):
        logger.addinfo('@ models - report - invoice_by_segment(+)')
        sales_channel = None
        try:
            alter_session = "ALTER SESSION SET NLS_LANGUAGE='American'"
            from_date = jsond['from_date']
            to_date = jsond['to_date']
            user_id = jsond['user_id']
            orgid = jsond['org_id']
            if 'sales_channel' in jsond:
                sales_channel = jsond['sales_channel']
            user_type = Code_util.get_usertype(user_id)
            ptype = user_type['type']
            sales_id_list = []
            self.acquire()
            self.cursor.execute(alter_session)
            if ptype == 'salesrep':
                salesid_qry = self.sql_file['salesrep_ids']
                self.cursor.execute(alter_session)
                self.cursor.execute(salesid_qry, user_id=user_id)
                ids = self.cursor.fetchall()
                length_salesrep = len(ids)
                for count in range(length_salesrep):
                    _id = ids[count][0]
                    sales_id_list.append(_id)
            sales_grps = []
            if sales_channel:
                sales_grps.append(sales_channel)
            else:
                sales_grp_qry = self.sql_file['salesgrp_names_query']
                self.cursor.execute(sales_grp_qry, p_user_id=user_id)
                ids = self.cursor.fetchall()
                length = len(ids)
                for count in range(length):
                    name = ids[count][1]
                    sales_grps.append(name)
            if ptype != 'salesrep':
                query_temp = self.sql_file['invoiced_by_seg_query']
                bil_query = query_temp % (',' . join([":" + str(i)
                                                      for i in range(len(sales_grps))]),
                                          orgid, "'" + from_date + "'", "'" +
                                          to_date + "'")
                self.cursor.execute(bil_query, sales_grps)
            else:
                query_temp = self.sql_file['inv_by_seg_agent_query']
                bil_query = query_temp % (orgid, ',' . join([":" + str(i)
                                                             for i in range(len(sales_grps))]),
                                          ',' . join([":" + str(index2)
                                                      for index2 in
                                                      range(len(sales_grps),
                                                            len(sales_id_list) +
                                                            len(sales_grps))]),
                                          "'" + from_date + "'", "'" + to_date
                                          + "'")
                self.cursor.execute(bil_query, sales_grps + sales_id_list)

            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 invoice_by_segment """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - invoice_by_segment(-)')
        return result

    def get_agent_annual_analysis(self, jsond):
        logger.addinfo('@ models - report - get_agent_annual_analysis(+)')
        try:
            period = jsond['period']
            agent_name = jsond['agent_name']
            self.acquire()
            qry = self.sql_file['agent_zone_revenue_query']
            self.cursor.execute(qry, p_agent_name=agent_name, p_period=period)
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_agent_annual_analysis """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_agent_annual_analysis(-)')
        return result

    @staticmethod
    def sales_avg_price(jsond):
        logger.addinfo('@ models - report - sales_avg_price(+)')
        connection = None
        cursor = None
        sales_channel = jsond['sales_channel']
        agent_name = jsond['agent_name']
        customer_number = jsond['customer_number']
        segment = jsond['segment']
        item_code = jsond['item_code']
        period_from = jsond['period_from']
        period_to = jsond['period_to']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['sales_avg_price_analysis']
            cursor.execute(qry, P_SALES_CHANNEL=sales_channel,
                           P_AGENT_NAME=agent_name,
                           P_CUSTOMER_NUMBER=customer_number,
                           P_SEGMENT=segment,
                           P_ITEM_CODE=item_code,
                           P_PERIOD_FROM=period_from,
                           P_PERIOD_TO=period_to)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 sales_avg_price """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - sales_avg_price(-)')
        return reports

    def get_store_locator(self):
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_store_locator']
                conn.execute(query)
                result = conn.get_result()
        except Exception as error:
            logger.findaylog("""EXCEPTION - reports - models - 
                                get_store_locator""" + str(error))
            raise error
        return result

    def get_store_campaign(self):
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_store_campaign']
                conn.execute(query)
                result = conn.get_result()
        except Exception as error:
            logger.findaylog("""EXCEPTION - reports - models - 
                                get_store_campaign""" + str(error))
            raise error
        return result

    def update_store_locator_campaign(self, jsond):
        try:
            store_locator_array = []
            store_campaign_array = []
            cust_acct_site_id_array = []
            cust_account_id_array = []
            home_delivery_array = []
            with OracleConnectionManager() as conn:
                for i in range(len(jsond)):
                    store_locator_array.append(str(jsond[i]['store_locator']))
                    store_campaign_array.append(str(jsond[i]['store_campaign']))
                    cust_acct_site_id_array.append(int(jsond[i]['site_id']))
                    cust_account_id_array.append(int(jsond[i]['cust_account_id']))
                    home_delivery_array.append(str(jsond[i]['home_delivery']))
                status = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                    declare\
                        p_store_locator_campaign qpex_reports_pkg.l_store_locator_campaign_cover;\
                        
                        type string_table is table of varchar2(200)
                            index by binary_integer;\
                        
                        type number_table is table of number
                            index by binary_integer;\
                        
                        d_store_locator string_table := :p_store_locator;
                        d_store_campaign string_table := :p_store_campaign;   
                        d_home_delivery string_table := :p_home_delivery;   
                        d_cust_acct_site_id number_table := :p_cust_acct_site_id;                     
                        d_cust_account_id number_table := :p_cust_account_id;                     
                    begin                    
                        for i in 1..d_store_locator.count
                        loop
                            p_store_locator_campaign(i).store_locator := d_store_locator(i);\
                            p_store_locator_campaign(i).store_campaign := d_store_campaign(i);\
                            p_store_locator_campaign(i).home_delivery := d_home_delivery(i);\
                            p_store_locator_campaign(i).cust_acct_site_id := d_cust_acct_site_id(i);\
                            p_store_locator_campaign(i).cust_account_id := d_cust_account_id(i);\
                        end loop;\
                        qpex_reports_pkg.update_store_locator_campaign(
                            p_store_locator_campaign,
                            :x_status_code
                        );
                    end;""", p_cust_account_id=cust_account_id_array,
                                    p_cust_acct_site_id=cust_acct_site_id_array,
                                    p_store_locator=store_locator_array,
                                    p_store_campaign=store_campaign_array,
                                    p_home_delivery=home_delivery_array,
                                    x_status_code=status)
                if status.getvalue() == 'SUCCESS':
                    result = {
                        'msg': 'Updated successfully',
                        'status': Status.OK.value
                    }

                    # update redis key value for selected cutomer and sales group

                    # Customer list from redis is used no where
                    # self.update_redis(jsond)
                else:
                    result = {
                        'msg': status,
                        'status': Status.ERROR.value
                    }
        except Exception as error:
            logger.findaylog("""EXCEPTION - models- report - 
                            update_store_locator_campaign""" + str(error))
            raise error
        return result

    def update_redis(self, jsond):
        try:
            r = redis.StrictRedis(host='localhost', port=6379, db=15)
            pipe = r.pipeline()
            for i in range(len(jsond)):
                # Prepare Redis key with selected customer_number, group_name, salesrep and org
                customer_key = 'CL:' + jsond[i]['group_name'] + ':' + jsond[i]['customer_number']
                customer_key += ':' + str(jsond[i]['primary_salesrep_id']
                                          ) + ':' + str(jsond[i]['org_id'])
                query = self.sql_file['customer_list_agent_query']
                query += self.sql_file['customer_number_condition']
                with OracleConnectionManager() as conn:
                    conn.execute(query, p_org_id=jsond[i]['org_id'],
                                 p_salesrep_id=jsond[i]['primary_salesrep_id'],
                                 p_group_name=jsond[i]['group_name'],
                                 p_customer_number=jsond[i]['customer_number'])
                    result = conn.get_single_result()

                # redis not accepting None values. So replace None with empty string
                for key, value in result.items():
                    if value is None:
                        result[key] = ''
                pipe.hmset(customer_key, result)
            pipe.execute()

        except Exception as error:
            logger.findaylog("""EXCEPTION - models - report -
                                update_redis""" + str(error))
            raise error

    @staticmethod
    def get_period_values():
        logger.addinfo('@ models - report - get_period_values(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['period_query']
            cursor.execute(qry)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_period_values """ + str(error))
            raise error
        else:
            periods = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                period = {}
                for index, fn in enumerate(fieldnames):
                    period[fn] = row[index]
                periods.append(period)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_period_values(-)')
        return periods

    @staticmethod
    def get_revenue_saleschannel(sales_channel, period):
        logger.addinfo('@ models - report - get_revenue_saleschannel(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['revenue_sales_channel']
            cursor.execute(qry, p_sales_channel=sales_channel,
                           p_period=period)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_saleschannel """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_saleschannel(-)')
        return revenue_list

    @staticmethod
    def get_net_revenue_saleschannel(sales_channel, period):
        logger.addinfo('@ models - report - get_net_revenue_saleschannel(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['revenue_net_sales_channel']
            cursor.execute(qry, p_sales_channel=sales_channel,
                           p_period=period)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_net_revenue_saleschannel """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_net_revenue_saleschannel(-)')
        return revenue_list

    @staticmethod
    def get_revenue_agent(agent_name, group_name, period):
        logger.addinfo('@ models - report - get_revenue_agent(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['revenue_agent']
            cursor.execute(qry, p_sales_channel=group_name,
                           p_agent_name=agent_name,
                           p_period=period)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_agent """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_agent(-)')
        return revenue_list

    @staticmethod
    def get_revenue_agentzone(agent, sales_channel, period):
        logger.addinfo('@ models - report - get_revenue_agentzone(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['revenue_agent_zone']
            cursor.execute(qry, p_agent_name=agent, p_group_name=sales_channel,
                           p_period=period)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_agentzone """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_agentzone(-)')
        return revenue_list

    @staticmethod
    def get_revenue_customer(jsond):
        logger.addinfo('@ models - report - get_revenue_customer(+)')
        connection = None
        cursor = None
        cust_acc_id = jsond['cust_acc_id']
        agent_name = jsond['agent_name']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['revenue_customer_query']
            cursor.execute(qry, p_cust_acc_id=cust_acc_id,
                           p_agent_name=agent_name,
                           p_period=jsond['period'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_customer """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_customer(-)')
        return reports

    @staticmethod
    def getsalesrep_name(salesrep_id):
        logger.addinfo('@ models - report - getsalesrep_name(+)')
        connection = None
        cursor = None
        final = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file["salesrep_name_query"]
            cursor.execute(query, p_salesrep_id=salesrep_id)
            salesrep_name = cursor.fetchone()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 getsalesrep_name """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        final['salesrep'] = salesrep_name[0]
        logger.addinfo('@ models - report - getsalesrep_name(-)')
        return final

    @staticmethod
    def get_saleschannels(agent):
        logger.addinfo('@ models - report - get_saleschannels(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['sales_channels_query']
            cursor.execute(qry, p_agent_name=agent)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_saleschannels """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_saleschannels(-)')
        return revenue_list

    def get_agent_revenue(self, jsond):
        logger.addinfo('@ models - report - get_agent_revenue(+)')
        salesrep_id = jsond['salesrep_id']
        period = jsond['period']
        cust_acc_id = jsond['cust_acc_id']
        is_zone = jsond.get('is_zone', 'N')
        try:
            self.acquire()
            kwargs = dict(p_period=period)
            codice_qry = ''
            province_qry = ''
            # if the report is customer zone then we need to use different
            # column in the query condition
            if is_zone == 'Y':
                salesrep_cond = self.sql_file['customer_zone_salesrep_condition']
            else:
                salesrep_cond = self.sql_file['customer_salesrep_condition']
            if jsond.get('codice_centrale'):
                codice_qry = self.sql_file['codice_centrale_condition']
                kwargs['p_codice_centrale'] = jsond.get('codice_centrale')
            if jsond.get('province'):
                province_qry = self.sql_file['province_condition']
                kwargs['p_province'] = jsond.get('province')
            if jsond['sales_channel']:
                kwargs['p_cust_acc_id'] = cust_acc_id
                kwargs['p_sales_channel'] = jsond['sales_channel']
                if salesrep_id:
                    query = self.sql_file['customer_revenue_agent_query']
                    query = query.format(cond=salesrep_cond, codice_centrale_filter=codice_qry,
                                         province_filter=province_qry)
                    query %= ','.join(["'{}'".format(
                        salesrep_id[i]) for i in range(len(salesrep_id))])
                else:
                    query = self.sql_file['customer_revenue_query']
                    query = query.format(codice_centrale_filter=codice_qry,
                                         province_filter=province_qry)
                self.cursor.execute(query, **kwargs)
            else:
                query = self.sql_file['agent_revenue_query']
                query = query.format(cond=salesrep_cond, codice_centrale_filter=codice_qry,
                                     province_filter=province_qry)
                query %= ','.join(["'{}'".format(
                    salesrep_id[i]) for i in range(len(salesrep_id))])
                self.cursor.execute(query, **kwargs)
            result = self.get_data_chunks()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_agent_revenue """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_agent_revenue(-)')
        return result

    def get_agent_revenue_yearly(self, jsond):
        logger.addinfo('@ models - report - get_agent_revenue(+)')
        salesrep_id = jsond['salesrep_id']
        period = jsond['period']
        cust_acc_id = jsond['cust_acc_id']
        is_zone = jsond.get('is_zone', 'N')
        try:
            self.acquire()
            kwargs = dict(p_period=period)
            codice_qry = ''
            province_qry = ''
            # if the report is customer zone then we need to use different
            # column in the query condition
            if is_zone == 'Y':
                salesrep_cond = self.sql_file['customer_zone_yearly_salesrep_condition']
            else:
                salesrep_cond = self.sql_file['customer_yearly_salesrep_condition']
            if jsond.get('codice_centrale'):
                codice_qry = self.sql_file['codice_centrale_condition']
                kwargs['p_codice_centrale'] = jsond.get('codice_centrale')
            if jsond.get('province'):
                province_qry = self.sql_file['province_condition']
                kwargs['p_province'] = jsond.get('province')
            if jsond['sales_channel']:
                kwargs['p_sales_channel'] = jsond['sales_channel']
                kwargs['p_cust_acc_id'] = cust_acc_id
                if salesrep_id:
                    query = self.sql_file['customer_revenue_agent_query_yearly']
                    query = query.format(cond=salesrep_cond, codice_centrale_filter=codice_qry,
                                         province_filter=province_qry)
                    query %= ','.join(["'{}'".format(
                        salesrep_id[i]) for i in range(len(salesrep_id))])
                else:
                    query = self.sql_file['customer_revenue_query_yearly']
                    query = query.format(codice_centrale_filter=codice_qry,
                                         province_filter=province_qry)
                self.cursor.execute(query, **kwargs)
            else:
                query = self.sql_file['agent_revenue_query_yearly']
                query = query.format(cond=salesrep_cond, codice_centrale_filter=codice_qry,
                                     province_filter=province_qry)
                query %= ','.join(["'{}'".format(
                    salesrep_id[i]) for i in range(len(salesrep_id))])
                self.cursor.execute(query, **kwargs)
            result = self.get_data_chunks()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_agent_revenue """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_agent_revenue(-)')
        return result

    @staticmethod
    def get_customer_revenue(jsond):
        logger.addinfo('@ models - report - get_customer_revenue(+)')
        connection = None
        cursor = None
        org_id = jsond['org_id']
        cust_acc_id = jsond['cust_acc_id']
        cust_agent_name = jsond['cust_agent_name']
        year = jsond['year']
        try:
            manager_salesrep_id = jsond.get('manager_salesrep_id', None)
            sales_channel = jsond.get('sales_channel', None)
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if cust_agent_name != '':
                qry = sql_file['cusomer_revenue_agent_query']
                cursor.execute(qry,
                               p_sales_channel=sales_channel,
                               p_cust_acc_id=cust_acc_id,
                               p_agent_name=cust_agent_name,
                               p_year=year)
            elif manager_salesrep_id and not cust_acc_id:
                qry = sql_file['customer_revenue_manager_agent_query']
                cursor.execute(qry,
                               p_year=year,
                               p_manager_salesrep_id=manager_salesrep_id)
            else:
                qry = sql_file['cusomer_revenue_query']
                cursor.execute(qry,
                               p_sales_channel=sales_channel,
                               p_cust_acc_id=cust_acc_id,
                               p_year=year)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_customer_revenue """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            if cursor:
                cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_customer_revenue(-)')
        return reports

    @staticmethod
    def get_quali_report(jsond):
        logger.addinfo('@ models - report - get_quali_report(+)')
        connection = None
        cursor = None
        data = []
        org_name = jsond['org_name']
        sales_channel = jsond['sales_channel']
        salesrep_id = jsond['salesrep_id']
        is_agent = jsond['is_agent']
        is_overview = jsond.get('overview', False)
        cust_acc_id = None
        try:
            if 'cust_account_id' in jsond:
                cust_acc_id = jsond['cust_account_id']
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if is_agent == 'Y':
                query = sql_file['quali_credit_agent_query']
                query %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, P_ORGANIZATION_NAME=org_name,
                               P_SALES_CHANNEL=sales_channel)
            elif is_overview:
                query = sql_file['quali_overview_query']
                cursor.execute(query)
            else:
                query = sql_file['quali_credit_query']
                cursor.execute(query, P_SALESREP_ID=salesrep_id,
                               P_ORGANIZATION_NAME=org_name,
                               P_SALES_CHANNEL=sales_channel,
                               P_CUST_ACC_ID=cust_acc_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_quali_report """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_quali_report(-)')
        return data

    @staticmethod
    def get_quali_ninety(jsond):
        logger.addinfo('@ models - report - get_quali_ninety(+)')
        connection = None
        cursor = None
        data = []
        sales_channel = jsond['sales_channel']
        salesrep_id = jsond['salesrep_id']
        is_agent = jsond['is_agent']
        cust_acc_id = None
        try:
            if 'cust_account_id' in jsond:
                cust_acc_id = jsond['cust_account_id']
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if is_agent == 'Y':
                query = sql_file['quali_credit_90_agent_query']
                query %= ',' . join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, P_SALES_CHANNEL=sales_channel)
            else:
                query = sql_file['quali_credit_90_query']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_SALESREP_ID=salesrep_id,
                               P_CUST_ACC_ID=cust_acc_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_quali_ninety """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_quali_ninety(-)')
        return data

    @staticmethod
    def get_revenue_items(jsond):
        logger.addinfo('@ models - report - get_revenue_items(+)')
        connection = None
        cursor = None
        data = []
        sales_channel = jsond['sales_channel']
        agent_name = jsond['agent_name']
        period = jsond['period']
        customer_number = jsond['customer_number']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if (agent_name == '' and customer_number == '' and
                    salesrep_id == ''):
                query = sql_file['revenue_items_other_query']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period)
            elif customer_number != '':
                query = sql_file['revenue_customer_items_query']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period,
                               p_customer_number=customer_number)
            elif salesrep_id != '':
                query = sql_file['revenue_agent_items_query']
                query %= ',' . join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period, p_agent_name=agent_name)
            elif agent_name != '' and customer_number == '':
                query = sql_file['revenue_items_query_agent']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period, p_agent_name=agent_name)
            else:
                query = sql_file['revenue_items_query']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period, p_agent_name=agent_name,
                               p_customer_number=customer_number,
                               p_salesrep_id=salesrep_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_items """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_items(-)')
        return data

    @staticmethod
    def get_revenue_segments(jsond):
        logger.addinfo('@ models - report - get_revenue_segments(+)')
        connection = None
        cursor = None
        data = []
        sales_channel = jsond['sales_channel']
        agent_name = jsond['agent_name']
        period = jsond['period']
        customer_number = jsond['customer_number']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if (agent_name == '' and customer_number == '' and
                    salesrep_id == ''):
                query = sql_file['segments_query']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period)
            elif customer_number != '':
                query = sql_file['revenue_customer_segments_query']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period,
                               p_customer_number=customer_number)
            elif salesrep_id != '':
                query = sql_file['revenue_agent_segments_query']
                query %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period, p_agent_name=agent_name)
            elif agent_name != '' and customer_number == '':
                query = sql_file['revenue_segments_query_agent']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period, p_agent_name=agent_name)
            else:
                query = sql_file['segments_query']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period, p_agent_name=agent_name,
                               p_customer_number=customer_number,
                               p_salesrep_id=salesrep_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_quali_ninety """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_segments(-)')
        return data

    @staticmethod
    def get_revenue_brand(jsond):
        logger.addinfo('@ models - report - get_revenue_brand(+)')
        connection = None
        cursor = None
        data = []
        sales_channel = jsond['sales_channel']
        agent_name = jsond['agent_name']
        period = jsond['period']
        customer_number = jsond['customer_number']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if salesrep_id != '':
                query = sql_file['revenue_brand_multi_agent_query']
                query %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, p_sales_channel=sales_channel,
                               P_PERIOD=period)
            elif agent_name == '' and customer_number == '':
                query = sql_file['revenue_brand_query']
                cursor.execute(query, p_sales_channel=sales_channel,
                               P_PERIOD=period)
            elif customer_number != '':
                query = sql_file['revenue_brand_customer_query']
                cursor.execute(query, p_sales_channel=sales_channel,
                               P_PERIOD=period,
                               p_customer_number=customer_number)
            elif agent_name != '':
                query = sql_file['revenue_brand_agent_query']
                cursor.execute(query, p_sales_channel=sales_channel,
                               P_PERIOD=period, p_agent_name=agent_name)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_brand """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_brand(-)')
        return data

    @staticmethod
    def get_all_reports_info():
        logger.addinfo('@ models - report - get_all_reports_info(+)')
        connection = None
        cursor = None
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['all_reports_info']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_all_reports_info """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_all_reports_info(-)')
        return data

    @staticmethod
    def get_agent_target(jsond):
        logger.addinfo('@ models - report - get_agent_target(+)')
        connection = None
        cursor = None
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if jsond['salesrep_id'] != '':
                query = sql_file['multi_agent_target_query']
                salesrep_ids = jsond['salesrep_id']
                query %= ','.join([salesrep_ids[i] for i in range(len(salesrep_ids))])
                cursor.execute(query, P_MONTH=jsond['period'])
            else:
                query = sql_file['agent_target_query']
                cursor.execute(query, P_SALESREP_ID=jsond['salesrep_id'],
                               P_MONTH=jsond['period'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_agent_target """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_agent_target(-)')
        return data

    @staticmethod
    def get_customer_objectives(cust_num, year):
        logger.addinfo('@ models - report - get_customer_objectives(+)')
        connection = None
        cursor = None
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['agent_customer_obectives']
            cursor.execute(query, P_CUSTOMER_NUMBER=cust_num,
                           P_PERIOD=year)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_customer_objectives """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_customer_objectives(-)')
        return data

    @staticmethod
    def get_salesreps_name(req):
        logger.addinfo('@ models - report - get_salesreps_name(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['salesrep_names_query']
            query %= ','.join(req)
            cursor.execute(query)
            result = Code_util.iterate_data(cursor)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_salesreps_name """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_salesreps_name(-)')
        return result

    @staticmethod
    def get_brand_drilldown(jsond):
        logger.addinfo('@ models - report - get_brand_drilldown(+)')
        connection = None
        cursor = None
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['revenue_brand_drilldown']
            cursor.execute(query, p_sales_channel=jsond['sales_channel'],
                           p_period=jsond['period'], p_brand=jsond['brand'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_brand_drilldown """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_brand_drilldown(-)')
        return data

    @staticmethod
    def get_segment_drilldown(jsond):
        logger.addinfo('@ models - report - get_segment_drilldown(+)')
        connection = None
        cursor = None
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['revenue_segments_drilldown']
            cursor.execute(query, p_sales_channel=jsond['sales_channel'],
                           p_salesrep_id=jsond['salesrep_id'],
                           p_period=jsond['period'],
                           p_segment=jsond['segment'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_segment_drilldown """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_segment_drilldown(-)')
        return data

    @staticmethod
    def get_revenue_macro(jsond):
        logger.addinfo('@ models - report - get_revenue_macro(+)')
        connection = None
        cursor = None
        period = jsond['period']
        group_name = jsond['group_name']
        agent_name = jsond['agent_name']
        customer_number = jsond['customer_number']
        salesrep_id = jsond['salesrep_id']
        data = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if salesrep_id != '':
                query = sql_file['revenue_micro_agent_query']
                query %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, p_group_name=group_name,
                               P_PERIOD=period)
            else:
                qry = sql_file['revenue_micro_query']
                cursor.execute(qry, p_group_name=group_name, P_PERIOD=period,
                               p_agent_name=agent_name,
                               p_customer_number=customer_number)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_macro """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                data.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_macro(-)')
        return data

    @staticmethod
    def get_net_revenue_agent(agent, sales_channel, period):
        logger.addinfo('@ models - report - get_net_revenue_agent(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['agent_net_revenue_query']
            cursor.execute(qry, p_agent_name=agent, p_group_name=sales_channel,
                           p_period=period)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_net_revenue_agent """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_net_revenue_agent(-)')
        return revenue_list

    @staticmethod
    def get_net_revenue_agentzone(agent, sales_channel, period):
        logger.addinfo('@ models - report - get_net_revenue_agentzone(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['agent_zone_net_revenue_query']
            cursor.execute(qry, p_agent_name=agent, p_group_name=sales_channel,
                           p_period=period)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_net_revenue_agentzone """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_net_revenue_agentzone(-)')
        return revenue_list

    @staticmethod
    def get_net_revenue_customer(jsond):
        logger.addinfo('@ models - report - get_net_revenue_customer(+)')
        connection = None
        cursor = None
        cust_acc_id = jsond['cust_acc_id']
        agent_name = jsond['agent_name']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['cust_net_revenue_query']
            cursor.execute(qry, p_cust_acc_id=cust_acc_id,
                           p_agent_name=agent_name,
                           p_period=jsond['period'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_customer """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_net_revenue_customer(-)')
        return reports

    @staticmethod
    def get_agent_turnover(jsond):
        logger.addinfo('@ models - report - get_agent_turnover(+)')
        connection = None
        cursor = None
        period = jsond['period']
        agent_name = jsond['agent_name']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if salesrep_id != '':
                query = sql_file['multi_agent_turnover_query']
                query %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, P_PERIOD=period)
            else:
                qry = sql_file['agent_turnover_query']
                cursor.execute(qry, P_PERIOD=period,
                               p_agent_name=agent_name)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_agent_turnover """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_agent_turnover(-)')
        return reports

    @staticmethod
    def get_customer_turnover(jsond):
        logger.addinfo('@ models - report - get_customer_turnover(+)')
        connection = None
        cursor = None
        period = jsond['period']
        cust_acc_id = jsond['cust_acc_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['customer_turnover_query']
            cursor.execute(qry, P_PERIOD=period,
                           p_cust_acc_id=cust_acc_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_customer_turnover """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_customer_turnover(-)')
        return reports

    @staticmethod
    def get_budget_analysis(jsond):
        logger.addinfo('@ models - report - get_budget_analysis(+)')
        connection = None
        cursor = None
        year = jsond['year']
        sales_group = jsond['sales_group']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['budget_analysis_query']
            cursor.execute(qry, p_year=year,
                           p_sales_group=sales_group)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_budget_analysis """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_budget_analysis(-)')
        return reports

    @staticmethod
    def get_revenue_shipto(jsond):
        logger.addinfo('@ models - report - get_revenue_shipto(+)')
        connection = None
        cursor = None
        year = jsond['year']
        sales_group = jsond['sales_group']
        cust_acc_id = jsond['cust_acc_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['revenue_shipto_query']
            cursor.execute(qry, p_year=year, p_sales_channel=sales_group,
                           p_cust_acc_id=cust_acc_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_shipto """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_shipto(-)')
        return reports

    @staticmethod
    def get_customertype_revenue(jsond):
        logger.addinfo('@ models - report - get_customertype_revenue(+)')
        connection = None
        cursor = None
        sales_channel = jsond['sales_channel']
        period = jsond['period']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if salesrep_id != '':
                query = sql_file['customer_type_agent_query']
                query %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period)
            else:
                qry = sql_file['customer_type_query']
                cursor.execute(qry, P_PERIOD=period,
                               P_SALES_CHANNEL=sales_channel)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_customertype_revenue """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_customertype_revenue(-)')
        return reports

    @staticmethod
    def get_internal_transactions(year):
        logger.addinfo('@ models - report - get_internal_transactions(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['internal_transaction_query']
            cursor.execute(qry, P_YEAR=year)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_internal_transactions """ + str(error))
            raise error
        else:
            reports = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_internal_transactions(-)')
        return reports

    @staticmethod
    def get_punto_verde(jsond):
        logger.addinfo('@ models - report - get_punto_verde(+)')
        connection = None
        cursor = None
        reports = []
        orgid = jsond['org_id']
        from_date = jsond['from_date']
        to_date = jsond['to_date']
        try:
            cust_account_id = None
            if 'cust_account_id' in jsond:
                cust_account_id = jsond['cust_account_id']
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.get_reports_sql()
            if orgid != '' and from_date != '' and to_date != '':
                if cust_account_id:
                    query = sql_file['punto_verde_customer_query']
                    cursor.execute(query, p_org_id=orgid, p_date_to=to_date,
                                   p_date_from=from_date,
                                   p_cust_account_id=cust_account_id)
                else:
                    query = sql_file['punto_verde_query']
                    cursor.execute(query, p_org_id=orgid, p_date_to=to_date,
                                   p_date_from=from_date)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_punto_verde """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                report = {}
                for index, fn in enumerate(fieldnames):
                    report[fn] = row[index]
                reports.append(report)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_punto_verde(-)')
        return reports

    @staticmethod
    def get_revenue_class(jsond):
        logger.addinfo('@ models - report - get_revenue_class(+)')
        connection = None
        cursor = None
        data = []
        sales_channel = jsond['sales_channel']
        period = jsond['period']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.get_reports_sql()
            if salesrep_id != '':
                query = sql_file['revenue_class_agent_query']
                query %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period)
            else:
                query = sql_file['revenue_class_query']
                cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                               P_PERIOD=period)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_class """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_class(-)')
        return data

    @staticmethod
    def get_revenuemonth_agent(jsond):
        logger.addinfo('@ models - report - get_revenuemonth_agent(+)')
        connection = None
        cursor = None
        sales_channel = jsond['sales_channel']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['revenue_month_agent']
            qry %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
            cursor.execute(qry, p_sales_channel=sales_channel)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenuemonth_agent """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenuemonth_agent(-)')
        return revenue_list

    @staticmethod
    def get_net_revenuemonth_agent(jsond):
        logger.addinfo('@ models - report - get_net_revenuemonth_agent(+)')
        connection = None
        cursor = None
        sales_channel = jsond['sales_channel']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['multi_agent_net_revenue_query']
            qry %= ','.join([salesrep_id[i]for i in range(len(salesrep_id))])
            cursor.execute(qry, p_group_name=sales_channel)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_net_revenuemonth_agent """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_net_revenuemonth_agent(-)')
        return revenue_list

    @staticmethod
    def get_revenuemonth_agentzone(jsond):
        logger.addinfo('@ models - report - get_revenuemonth_agentzone(+)')
        connection = None
        cursor = None
        sales_channel = jsond['sales_channel']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['revenue_multi_agent_zone']
            qry %= ','.join(["'{}'".format(str(salesrep_id[i])) for i in range(len(salesrep_id))])
            cursor.execute(qry, p_group_name=sales_channel,
                           p_period=jsond['period'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenuemonth_agentzone """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenuemonth_agentzone(-)')
        return revenue_list

    @staticmethod
    def get_net_revenuemonth_agentzone(jsond):
        logger.addinfo('@ models - report - get_net_revenuemonth_agentzone(+)')
        connection = None
        cursor = None
        sales_channel = jsond['sales_channel']
        salesrep_id = jsond['salesrep_id']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            qry = sql_file['multi_agent_zone_net_revenue_query']
            qry %= ',' . join(["'{}'".format(str(salesrep_id[i])) for i in range(len(salesrep_id))])
            cursor.execute(qry, p_group_name=sales_channel,
                           p_period=jsond['period'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_net_revenuemonth_agentzone """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_net_revenuemonth_agentzone(-)')
        return revenue_list

    @staticmethod
    def get_revenue_itemsrange(jsond):
        logger.addinfo('@ models - report - get_revenue_itemsrange(+)')
        connection = None
        cursor = None
        sales_channel = jsond['sales_channel']
        salesrep_id = jsond['salesrep_id']
        is_agent = jsond['is_agent']
        customer_num = jsond['customer_num']
        from_date = jsond['from_date']
        to_date = jsond['to_date']
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.get_reports_sql()
            if is_agent == 'Y':
                query = sql_file['revenue_items_range_agent_query']
                query %= ','.join([salesrep_id[i]for i in range(len(salesrep_id))])
                cursor.execute(query, p_sales_channel=sales_channel,
                               p_from_date=from_date,
                               p_to_date=to_date)
            else:
                query = sql_file['revenue_items_range_query']
                cursor.execute(query, p_sales_channel=sales_channel,
                               p_from_date=from_date,
                               p_to_date=to_date, p_customer_num=customer_num)
        except Exception as error:
            logger.findaylog("""@ 1529 EXCEPTION - models - report -
                 get_revenue_itemsrange """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - report - get_revenue_itemsrange(-)')
        return revenue_list

    def get_revenue_formats(self, jsond):
        logger.addinfo('@ models - report - get_revenue_formats(+)')
        try:
            sales_channel = jsond['sales_channel']
            agent_name = jsond['agent_name']
            period = jsond['period']
            customer_number = jsond['customer_number']
            salesrep_id = jsond['salesrep_id']
            self.acquire()
            if (agent_name == '' and customer_number == '' and
                    salesrep_id == ''):
                query = self.sql_file['formats_query']
                self.cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                                    P_PERIOD=period)
            elif customer_number != '':
                query = self.sql_file['revenue_customer_formats_query']
                self.cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                                    P_PERIOD=period,
                                    p_customer_number=customer_number)
            elif salesrep_id != '':
                query = self.sql_file['revenue_agent_formats_query']
                query %= ','.join([salesrep_id[i] for i in range(len(salesrep_id))])
                self.cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                                    P_PERIOD=period, p_agent_name=agent_name)
            elif agent_name != '' and customer_number == '':
                query = self.sql_file['revenue_formats_query_agent']
                self.cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                                    P_PERIOD=period, p_agent_name=agent_name)
            else:
                query = self.sql_file['formats_query']
                self.cursor.execute(query, P_SALES_CHANNEL=sales_channel,
                                    P_PERIOD=period, p_agent_name=agent_name,
                                    p_customer_number=customer_number,
                                    p_salesrep_id=salesrep_id)
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_revenue_formats """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_revenue_formats(-)')
        return result

    def get_format_drilldown(self, jsond):
        logger.addinfo('@ models - report - get_format_drilldown(+)')
        try:
            self.acquire()
            query = self.sql_file['revenue_formats_drilldown']
            self.cursor.execute(query, p_sales_channel=jsond['sales_channel'],
                                p_period=jsond['period'],
                                p_segment=jsond['segment'])
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                 get_format_drilldown """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_format_drilldown(-)')
        return result

    def get_customer_details(self, cust_id):
        logger.addinfo('@ models - report - get_customer_details(+)')
        try:
            self.acquire()
            query = self.sql_file['customer_details_query']
            self.cursor.execute(query, p_cust_acc_id=cust_id)
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                get_customer_details """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_customer_details(+)')
        return result

    def get_revenueitems_quarter(self, jsond):
        logger.addinfo('@ models - report - get_revenueitems_quarter(+)')
        try:
            self.acquire()
            query = self.sql_file['revenue_items_quarter_query']
            self.cursor.execute(query, P_PERIOD=jsond['period'],
                                P_SALES_CHANNEL=jsond['sales_channel'],
                                P_CUSTOMER_NUMBER=jsond['customer_number'])
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                get_revenueitems_quarter """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_revenueitems_quarter(+)')
        return result

    def get_weightedprice_data(self, req):
        logger.addinfo('@ models - report - get_weightedprice_data(+)')
        try:
            self.acquire()
            query = self.sql_file['weighted_price_query']
            self.cursor.execute(query, p_cust_id=req['cust_account_id'],
                                p_from_date=req['from_date'],
                                p_to_date=req['to_date'],
                                p_codice_centrale=req['codice_centrale'])
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                get_weightedprice_data """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_weightedprice_data(+)')
        return result

    def get_notifications(self):
        logger.addinfo('@ models - report - get_notifications(+)')
        try:
            self.acquire()
            query = self.sql_file['cruscott_notifications_query']
            self.cursor.execute(query)
            result = self.get_data_array()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                get_notifications """ + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_notifications(-)')
        return result

    def get_customers_revenue(self, req):
        logger.addinfo('@ models - report - get_customers_revenue(+)')
        try:
            self.acquire()
            customer_qry = ''
            codice_qry = ''
            kwargs = {'p_period': req['period'], 'p_user_id': req['user_id'],
                      'p_sales_channel': req['sales_channel']}
            if req['is_items']:
                query = self.sql_file['customers_revenue_item_query']
            elif req['is_customers']:
                query = self.sql_file['customers_revenue_detail_query']
            elif req['is_yearly']:
                query = self.sql_file['customers_revenue_detail_query_yearly']
            else:
                query = self.sql_file['customers_revenue_segment_query']
            if req.get('account_mgr_flag'):
                customer_qry = self.sql_file['revenue_by_segments_cust_cond']
                kwargs['p_customer_number'] = req.get('customer_number')
            if req.get('codice_centrale'):
                codice_qry = self.sql_file['codice_centrale_condition']
                kwargs['p_codice_centrale'] = req.get('codice_centrale')

            query = query.format(p_customer_number_qry=customer_qry,
                                 codice_centrale_filter=codice_qry)
            self.cursor.execute(query, **kwargs)
            data = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - report -
                get_customers_revenue """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - report - get_customers_revenue(-)')
        return data

    def get_customers(self, user_id):
        logger.addinfo('@ models - report - get_customers(+)')
        try:
            self.acquire()
            query = self.sql_file['customers_query']
            self.cursor.execute(query, p_user_id=user_id)
            data = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - report -
                get_customers """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - report - get_customers(-)')
        return data

    def get_customers_revenue_month(self, req):
        logger.addinfo('@ models - report - get_customers_revenue_month(+)')
        try:
            result = {}
            self.acquire()
            query = self.sql_file['customers_revenue_turnover_query']
            self.cursor.execute(query, p_period=req['period'],
                                p_user_id=req['user_id'], p_sales_channel=req['sales_channel'])
            result['turnover'] = Code_util.iterate_data(self.cursor)

            query = self.sql_file['customers_revenue_gross_query']
            self.cursor.execute(query, p_period=req['period'],
                                p_user_id=req['user_id'], p_sales_channel=req['sales_channel'])
            result['gross'] = Code_util.iterate_data(self.cursor)

            query = self.sql_file['customers_revenue_net_query']
            self.cursor.execute(query, p_period=req['period'],
                                p_user_id=req['user_id'], p_sales_channel=req['sales_channel'])
            result['net'] = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - report -
                get_customers_revenue_month """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - report - get_customers_revenue_month(-)')
        return result

    def get_agent_customers(self, req):
        logger.addinfo('@ models - report - get_agent_customers(+)')
        try:
            self.acquire()
            query = self.sql_file['customer_list_agent_query']

            query = query.format(req['salesrep_id'] if req.get(
                'salesrep_id') else 'primary_salesrep_id')
            self.cursor.execute(query, p_org_id=req['org_id'],
                                p_group_name=req['sales_channel'])
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - report -
                get_agent_customers """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - report - get_agent_customers(-)')
        return result

    def get_revenue_by_date_range(self, req, download=None):
        logger.addinfo('@ models - report - get_revenue_by_dateRange(+)')
        try:
            self.acquire()
            query = self.sql_file['get_revenue_by_date_range']
            if download is None:
                query += self.sql_file['get_limit_records']
            query += self.sql_file['get_group_by_date_range']
            self.cursor.execute(query, p_sales_group=req['sales_group'],
                                p_invoice_date_from=req['invoice_date_from'],
                                p_invoice_date_to=req['invoice_date_to'],
                                p_customer_number=req['customer_number'],
                                p_province=req['province'],
                                p_item_code=req['item_code'],
                                p_segments=req['segments'],
                                p_brand=req['brand'],
                                p_agent_name=req['agent_name'],
                                p_city=req['city'],
                                p_codice_centrale=req['codice_centrale'])
            result = Code_util.iterate_data(self.cursor)
            final = {'result': result[:1000]}
            if download:
                file_name = Report.export_data(result)
                final['file_name'] = file_name
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - report -
                get_revenue_by_date_range """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - report - get_revenue_by_date_range(-)')
        return final

    def get_revenue_share_by_country(self, req):
        logger.addinfo('@ models - report - get_revenue_share_by_country(+)')
        try:
            self.acquire()
            group_name = req.get('group_name', '')
            # group_name is not there or is zooplus then we show
            # share data related to zooplus customer in each country
            # otherwise we get revenue overview by country
            if not group_name or group_name == 'ZOOPLUS':
                query = self.sql_file['revenue_share_zooplus_query']
                self.cursor.execute(query)
            else:
                query = self.sql_file['revenue_distributor_country_query']
                self.cursor.execute(query, p_period=req['period'],
                                    p_group_name=group_name)
            result = Code_util.iterate_data(self.cursor)
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - report -
                get_revenue_share_by_country ''' + str(error))
            raise error
        finally:
            self.release()
        logger.addinfo('@ models - report - get_revenue_share_by_country(+)')
        return result

    def get_agent_commission(self, req):
        logger.addinfo('@ models - report - get_agent_commission(+)')
        try:
            with OracleConnectionManager() as connection:
                query = self.sql_file['agent_commission_trend_query']
                connection.execute(query, p_period=req['period'],
                                   p_sales_channel=req['sales_channel'])
                result = connection.get_result()
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - report -
                get_agent_commission ''' + str(error))
            raise error
        logger.addinfo('@ models - report - get_agent_commission(-)')
        return result

    def get_package_disposal_report(self, req):
        try:
            with OracleConnectionManager() as connection:
                query = self.sql_file['package_disposal_report_query']
                error_msg = connection.cursor.var(cx_Oracle.STRING)
                return_val = connection.cursor.var(cx_Oracle.STRING)
                connection.execute('''
                begin
                    almo_landbell_report.populate_data(
                        :errbuf,
                        :retcode,
                        :pDateFrom,
                        :pDateTo
                    );
                end;''', errbuf=error_msg,
                                   retcode=return_val,
                                   pDateFrom=req['from_date'],
                                   pDateTo=req['to_date'])
                if return_val.getvalue() != '1':
                    result = {
                        'status': Status.ERROR.value,
                        'msg': error_msg.getvalue()
                    }
                else:
                    connection.execute(query, p_period=req['from_date'])
                    result = connection.get_result()
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - report -
                get_package_disposal_report ''' + str(error))
            raise error
        return result

    def update_qualicredit_notes(self, jsond):
        logger.addinfo('@ models - report - update_qualicredit_report(+)')
        try:
            with OracleConnectionManager() as conn:
                conn.execute(
                    """
                        begin
                            qpex_reports_pkg.update_qualicredit_notes(
                                :p_trx_number,
                                :p_salesrep_id,
                                :p_notes,
                                :x_status_code
                            );
                        end;
                    """, output_key='x_status_code',
                    p_trx_number=jsond['trx_number'],
                    p_salesrep_id=jsond['salesrep_id'],
                    p_notes=jsond['notes']
                )
                status = conn.get_output_param()
                if status == 'SUCCESS':
                    result = {
                        'msg': 'Successfully updated notes',
                        'status': 0
                    }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - reports -
                            update_qualicredit_report - """ + str(error))
            raise error
        logger.addinfo('@ models - report - update_qualicredit_report(-)')
        return result

    def revenue_by_segments(self, jsond):
        agent_cus_cond = ''
        agent_cus_grp = ''
        result = []
        qry_params = {
            'p_period': jsond['period'],
            'p_sales_channel': jsond.get('sales_channel')
        }
        with OracleConnectionManager() as conn:
            if jsond.get('UILimitAccess', False):
                agent_cus_cond = self.sql_file['revenue_seg_report_limit_cond']
                if jsond.get('customer_number'):
                    agent_cus_cond += self.sql_file['revenue_by_segments_cust_cond']
                    agent_cus_grp = self.sql_file['revenue_by_segments_cust_group']
                    qry_params['p_customer_number'] = jsond.get('customer_number')
                qry_params['p_user_id'] = jsond.get('user_id')
            elif jsond.get('customer_number') != '':
                agent_cus_cond = self.sql_file['revenue_by_segments_cust_cond']
                agent_cus_grp = self.sql_file['revenue_by_segments_cust_group']
                qry_params['p_customer_number'] = jsond.get('customer_number')
            elif jsond.get('agent_name') != '':
                agent_cus_cond = self.sql_file['revenue_by_segments_agent_cond']
                agent_cus_grp = self.sql_file['revenue_by_segments_agent_group']
                qry_params['p_agent_name'] = jsond.get('agent_name')
            elif jsond.get('salesrep_id') != '':
                agent_cus_cond = (
                    self.sql_file['revenue_by_segments_agent_cond'] +
                    self.sql_file['revenue_by_segments_salesrep_qry']
                )
                agent_cus_cond %= ','.join(
                    [jsond['salesrep_id'][i] for i in range(len(jsond['salesrep_id']))])
                agent_cus_grp = self.sql_file['revenue_by_segments_agent_group']
                qry_params['p_agent_name'] = jsond.get('agent_name')
            qry = self.sql_file['revenue_by_segments']
            qry = qry.format(agent_cus_cond=agent_cus_cond,
                             agent_cus_grp=agent_cus_grp)
            conn.execute(qry, **qry_params)
            result = conn.get_result()
        return result

    @staticmethod
    def read_revenue_share_file(jsond):
        logger.addinfo('@ models - report - read_revenue_share_file(-)')
        try:
            # Read uploaded file base64 and write to temporary files
            file_decode = base64.b64decode(jsond['base64'])
            file_id = CommonUtils.generate_random_string(5)
            file_name = '/tmp/' + file_id + '.xls'
            with open(file_name, 'wb') as f:
                f.write(file_decode)
            workbook = xlrd.open_workbook(file_name)
            worksheet = workbook.sheet_by_index(0)
            status_codes = []
            result = {}
            if worksheet.nrows < 4:
                result['status'] = 1
                result['msg'] = 'Failed - Please check the file format'
                return result
            elif worksheet.cell_value(3, 1) != 'Almo Nature':
                result['status'] = 1
                result['msg'] = 'Failed - Please check the file format'
                return result
            with OracleConnectionManager() as conn:
                delete_status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                                    begin
                                        qpex_reports_pkg.delete_zooplus_shares(
                                    :x_status_code
                                        );
                                    end; """, x_status_code=delete_status_code)
                if delete_status_code.getvalue() == 'SUCCESS':
                    for row in range(worksheet.nrows):
                        # Expecting first 4 rows as null values
                        if row > 3:
                            status_code = conn.cursor.var(cx_Oracle.STRING)
                            '''Look at only column 2, 3 and when row value has Grand total,
                            all data is extracted.'''
                            if worksheet.cell_value(row, 1).strip() == 'Grand Total' \
                                    or worksheet.cell_value(row, 2) == 1.0:
                                break
                            conn.cursor.execute("""
                                                begin
                                                    qpex_reports_pkg.insert_zooplus_shares(
                                                :p_country_code,
                                                :p_country_name,
                                                :p_share_percentage,
                                                :x_status_code
                                                    );
                                                end; """, p_country_code=worksheet.cell_value(row, 1)[:2],
                                                p_country_name=worksheet.cell_value(row, 1),
                                                p_share_percentage=worksheet.cell_value(
                                                    row, 2) * 100,
                                                x_status_code=status_code)
                            status = status_code.getvalue()
                            if status != 'SUCCESS':
                                status_codes.append({'country_code': worksheet.cell_value(row, 1)[:2],
                                                     'error': status})
                if len(status_codes) > 0:
                    result['status'] = 1
                    result['msg'] = 'Failed to load ZOOPLUS percentage Shares'
                else:
                    result['status'] = 0
                    result['msg'] = 'ZOOPLUS shares uploaded successfully'
                result['failed_county_codes'] = status_codes
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - report - 
              read_revenue_share_file """ + str(e))
            raise e
        logger.addinfo('@ models - report - read_revenue_share_file(+)')
        return result

    @staticmethod
    def export_data(data):
        logger.addinfo('@ models - report - export_data(+)')
        file_name = "revenue_by_date_range_" + CommonUtils.generate_random_string(8)
        static_path = '/tmp/'
        file_path = os.path.join(static_path, (file_name + ".xlsx"))
        amount_array = ['Amount', 'Quantity']
        keys_order = OrderedDict([
            ('Customer Number',
             'customer_number'),
            ('Customer Name', 'customer_name'),
            ('Address',
             'address'),
            ('City', 'city'),
            ('Postal Code', 'postal_code'),
            ('Province', 'billacc_county'),
            ('Agent Name', 'agent_name'),
            ('Codice Centrale', 'codice_centrale'),
            ('Item Code', 'item_code'),
            ('Item Description', 'item_description'),
            ('Segments', 'segments'),
            ('Brands', 'brand'),
            ('UOM', 'uom'),
            ('Quantity', 'qty'),
            ('Amount', 'amount')
        ])
        try:
            # to remove existing file with the file_name
            if os.path.exists(file_path):
                os.remove(file_path)

            # to create a new excel file
            workbook = xlsxwriter.Workbook(file_path, {'constant_memory': True})
            # to have a format for a row
            bold = workbook.add_format({'bold': True})
            excel_data = []
            if data is not None and isinstance(data, list) and len(data) > 0:
                for index, f_data in enumerate(data):
                    ordered = OrderedDict()
                    for key, values in list(keys_order.items()):
                        ordered[key] = f_data[values]
                    excel_data.append(ordered)
                excel_data.sort(key=lambda x: int(x['Customer Number']))
                # to create a sheet in the excel
                worksheet = workbook.add_worksheet('Revenue by date range')
                headers = [header for header in list(excel_data[0].keys())]
                # to create header names in excel sheet
                for h_index, header in enumerate(headers):
                    worksheet.write(0, h_index, header, bold)
                # to insert data w.r.t to the header values
                for v_index, excel_value in enumerate(excel_data):
                    for h_index, header in enumerate(headers):
                        if excel_value[header] is None:
                            excel_value[header] = 0 if header in amount_array else ''
                        if isinstance(excel_value[header], (int, float)):
                            worksheet.write_number(v_index + 1, h_index,
                                                   excel_value[header])
                        else:
                            worksheet.write(v_index + 1, h_index,
                                            excel_value[header])
                #  Sum the column values
                worksheet.write(len(excel_data)+1, 0, "TOTALS", bold)
                for h_index, header in enumerate(headers):
                    if header in amount_array:
                        first = xl_rowcol_to_cell(1, h_index)
                        second = xl_rowcol_to_cell(len(excel_data), h_index)
                        worksheet.write_formula(len(excel_data)+1, h_index,
                                                '{=ROUND(SUM(%s:%s), 3)}' %
                                                (first, second),
                                                bold)
                workbook.close()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                     export_data """ + str(error))
            raise error
        finally:
            workbook.close()

        logger.addinfo('@ models - report - export_data(-)')
        return file_name + ".xlsx"

    def revenue_by_agents_zone(self, jsond):
        with OracleConnectionManager() as conn:
            agent_filter = ''
            query = self.sql_file['revenue_by_agents_zone']
            kwargs = dict(p_sales_channel=jsond['salesChannel'],
                          p_period=jsond['period'])
            if jsond.get('agent_name') and jsond.get('agent_name') != '':
                agent_filter = self.sql_file['revenue_by_agents_zone_agent_condition']
                kwargs['p_agent_name'] = jsond.get('agent_name')
            query = query.format(agent_name_filter=agent_filter)
            conn.execute(query, **kwargs)
            result = conn.get_result()
        return result

    def revenue_by_shipto_download(self, jsond):
        data = self.get_customer_revenue(jsond)
        revenue_arr = []
        customer_name = ''
        address = ''
        agent_name = ''
        tmp_obj = {}
        for revenue in data:
            if customer_name == revenue['customer_name'] and address == revenue['address'] and \
                    agent_name == revenue['agent']:
                tmp_obj[revenue['month'].strip().lower() + '_amt'] = revenue['amount']
                tmp_obj['total'] += revenue['amount']
            else:
                if tmp_obj != {}:
                    revenue_arr.append(tmp_obj)
                customer_name = revenue['customer_name']
                address = revenue['address']
                agent_name = revenue['agent']
                tmp_obj = revenue
                tmp_obj[revenue['month'].strip().lower() + '_amt'] = revenue['amount']
                tmp_obj['total'] = revenue['amount']
        if tmp_obj:
            revenue_arr.append(tmp_obj)
        if revenue_arr:
            file_name = Report.export_shipto_data(Report.ordering_keys(revenue_arr))
            return {'file_name': file_name, 'status': 0}
        return {'status': 1, 'msg': 'No Data Found', 'revenue_arr': revenue_arr}

    @staticmethod
    def ordering_keys(data):
        keys_order = OrderedDict([
            ('Customer Name',
             'customer_name'),
            ('Atradius Code',
             'atradius_code'),
            ('Customer Category',
             'customer_catgeory'),
            ('GDO Group',
             'gdo_group'),
            ('GDO sub group', 'gdo_sub_group'),
            ('Partner Account',
             'partner_account'),
            ('Account Manager',
             'account_manager'),
            ('Address',
             'address'),
            ('City', 'city'),
            ('Province', 'province'),
            ('Agent', 'agent'),
            ('January', 'january_amt'),
            ('February', 'february_amt'),
            ('March', 'march_amt'),
            ('April', 'april_amt'),
            ('May', 'may_amt'),
            ('June', 'june_amt'),
            ('July', 'july_amt'),
            ('August', 'august_amt'),
            ('September', 'september_amt'),
            ('October', 'october_amt'),
            ('November', 'november_amt'),
            ('December', 'december_amt'),
            ('Total', 'total')
        ])
        excel_data = []
        for _, f_data in enumerate(data):
            ordered = OrderedDict()
            for key, values in list(keys_order.items()):
                ordered[key] = f_data.get(values, None)
            excel_data.append(ordered)
        excel_data.sort(key=lambda x: x['Address'])
        return excel_data

    @staticmethod
    def export_shipto_data(excel_data):
        file_name = 'revenue_by_ship_to_' + CommonUtils.generate_random_string(8)
        static_path = tempfile.gettempdir() + '/'
        file_path = os.path.join(static_path, (file_name + '.xlsx'))
        try:
            # to remove existing file with the file_name
            if os.path.exists(file_path):
                os.remove(file_path)

            # to create a new excel file
            workbook = xlsxwriter.Workbook(file_path, {'constant_memory': True})
            # to have a format for a row
            bold = workbook.add_format({'bold': True})
            # to create a sheet in the excel
            worksheet = workbook.add_worksheet('Revenue by ShipTo')

            headers = [header for header in list(excel_data[0].keys())]
            # to create header names in excel sheet

            for h_index, header in enumerate(headers):
                worksheet.write(0, h_index, header, bold)
            # to insert data w.r.t to the header values
            for v_index, excel_value in enumerate(excel_data):
                for h_index, header in enumerate(headers):
                    if excel_value[header] is None:
                        excel_value[header] = ''
                    if isinstance(excel_value[header], (int, float)):
                        worksheet.write_number(v_index + 1, h_index, excel_value[header])
                    else:
                        worksheet.write(v_index + 1, h_index,
                                        excel_value[header])
            workbook.close()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - report -
                     export_shipto_data """ + str(error))
            raise error
        finally:
            workbook.close()

        logger.addinfo('@ models - report - export_shipto_data(-)')
        return file_name + '.xlsx'

    def revenue_items_yearly(self, jsond):
        cust_acc_filter = ''
        city_filter = ''
        province_filter = ''
        salesrep_filter = ''
        agent_filter = ''
        with OracleConnectionManager() as conn:
            query = self.sql_file['revenue_by_items_yearly']
            kwargs = dict(p_sales_channel=jsond['sales_channel'],
                          p_year=jsond['period'])
            if jsond.get('salesrep_id'):
                salesrep_filter = self.sql_file['revenue_by_segments_salesrep_qry']
                salesrep_filter %= ','.join(
                    [jsond['salesrep_id'][i] for i in range(len(jsond['salesrep_id']))])
            if jsond.get('customer_number'):
                cust_acc_filter = self.sql_file['revenue_by_segments_cust_cond']
                kwargs['p_customer_number'] = jsond.get('customer_number')
            if jsond.get('city'):
                city_filter = self.sql_file['city_condition']
                kwargs['p_city'] = jsond.get('city')
            if jsond.get('province'):
                province_filter = self.sql_file['province_condition']
                kwargs['p_province'] = jsond.get('province')
            if jsond.get('agent_name'):
                agent_filter = self.sql_file['agent_condition']
                kwargs['p_agent_name'] = jsond.get('agent_name')
            query = query.format(cust_acc_filter=cust_acc_filter,
                                 city_filter=city_filter,
                                 province_filter=province_filter,
                                 salesrep_filter=salesrep_filter,
                                 agent_filter=agent_filter)
            conn.execute(query, **kwargs)
            result = conn.get_result()
        return {'status': 0, 'items': Report.get_revenue_yearly_details(result)}

    @staticmethod
    def get_revenue_yearly_details(data):
        item_display_no = ''
        tmp_obj = {}
        revenue_arr = []
        for revenue in data:
            if item_display_no == revenue['item_display_seq']:
                tmp_obj[revenue['month'].strip().lower()] = revenue['amount']
                tmp_obj['total'] += revenue['amount']
            else:
                if tmp_obj != {}:
                    revenue_arr.append(tmp_obj)
                item_display_no = revenue['item_display_seq']
                tmp_obj = revenue
                tmp_obj[revenue['month'].strip().lower()] = revenue['amount']
                tmp_obj['total'] = revenue['amount']
        if tmp_obj:
            revenue_arr.append(tmp_obj)
        return revenue_arr


def generic_revenue_call(jsond, query_name):
    logger.addinfo("@ models - report - generic_revenue_call(+)")
    connection = None
    cursor = None
    agent_name = None
    customer_number = None
    customer_id = None
    data = []
    sales_channel = jsond['sales_channel']
    if 'agent_name' in jsond:
        agent_name = jsond['agent_name']
    if 'customer_number' in jsond:
        customer_number = jsond['customer_number']
    if 'customer_id' in jsond:
        customer_id = jsond['customer_id']
    period = jsond['period']
    try:
        connection = db_util.get_connection()
        cursor = connection.cursor()
        sql_file = db_util.getSqlData()
        query = sql_file[query_name]
        cursor.execute(query, p_agent_name=agent_name,
                       p_sales_channel=sales_channel,
                       P_PERIOD=period, p_customer_number=customer_number,
                       p_customer_id=customer_id)
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - models - report -
            generic_revenue_call """ + str(error))
        raise error
    else:
        fieldnames = [a[0].lower() for a in cursor.description]
        for row in cursor:
            result = {}
            for index, field in enumerate(fieldnames):
                result[field] = row[index]
            data.append(result)
    finally:
        cursor.close()
        db_util.release_connection(connection)
    logger.addinfo("@ models - report - generic_revenue_call(-)")
    return data
