import os

import boto3

from finapi.models.cms.cms import CMS
from finapi.utils.logdata import logger


class Gateway:
    """Wrapper class to access AWS API Gateway"""
    def __init__(self):
        self.region = os.environ['COGNITO_REGION']
        self.table_api_id = os.environ['GATEWAY_TABLE_API_ID']
        self.stage_name = os.environ['GATEWAY_STAGE_NAME']
        self.access_key = os.environ['GATEWAY_ACCESS_KEY']
        self.access_secret = os.environ['GATEWAY_ACCESS_SECRET']

    def get_client(self):
        return boto3.client('apigateway',
                            self.region,
                            aws_access_key_id=self.access_key,
                            aws_secret_access_key=self.access_secret)

    def delete_cache(self):
        logger.addinfo('@ models - gateway - delete_cache(+)')
        result = {}
        try:
            client = self.get_client()
            response = client.flush_stage_cache(
                restApiId=self.table_api_id,
                stageName=self.stage_name
            )
            if 'ResponseMetadata' in response and\
                    response['ResponseMetadata'].get('HTTPStatusCode', -1) == 202:
                cms = CMS()
                result = cms.clean_json_cache()
            else:
                result['status'] = 1
                result['msg'] = str(response)
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - delete_cache -
                delete_cache ''' + str(error))
            raise error
        logger.addinfo('@ models - gateway - delete_cache(-)')
        return result
