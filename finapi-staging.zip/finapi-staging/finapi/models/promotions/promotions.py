import base64
import datetime
import ujson
import cx_Oracle
from finapi.utils.log_util import LogUtil
from finapi.utils.conn_util import OracleConnectionManager
from finapi.sql import sql_util
from finapi.utils.constants import Status
from finapi.utils.common_utils import CommonUtils
from finapi.models.donation.donation import Donation
from finapi.models.workflows.workflows import Workflows


@LogUtil.class_module_logs('promotions')
class Promotions(object):

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def get_promotion_summary(self, org_id, header_id, promo_status):
        cust_cursor = ''
        segments_query = ''
        segments_arr = []
        items_arr = []
        kwargs = dict(p_org_id=org_id)
        with OracleConnectionManager() as conn:
            conn.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = self.sql_file['promotion_summary']
            cust_cursor = self.sql_file['promotion_view_customer']
            if header_id:
                segments_query = self.sql_file['promotion_view_segments']
                items_query = self.sql_file['promotion_view_items']
                query += self.sql_file['promotion_view_header_filter']
                kwargs['p_header_id'] = header_id
                conn.execute(segments_query, p_header_id=header_id)
                segments_arr = conn.get_result()
                conn.execute(items_query, p_org_id=org_id, p_header_id=header_id)
                items_arr = conn.get_result()
                query = query.format(cust_cursor=cust_cursor)
                conn.execute(query, **kwargs)
                result = conn.get_result()[0]
                result['items'] = items_arr
                result['segments'] = segments_arr
            else:
                query = query.format(cust_cursor=cust_cursor)
                if promo_status != 'ALL':
                    query += self.sql_file['promotion_summary_status']
                    kwargs['p_approval_flag'] = promo_status
                conn.execute(query, **kwargs)
                result = conn.get_result()
        return {'status':  Status.OK.value, 'promotions': result}

    def delete_promo_details(self, header_id):
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
            almo_promo_pkg.delete_promotion(
                :p_header_id,
                :x_status_code
            );
            END;
            """, output_key='x_status_code', p_header_id=header_id)
            conn.get_output_param(raise_exception=True, send_email=True)
        return {'status': Status.OK.value, 'msg': 'cancelled successfully:{}'.format(header_id)}

    def insert_promotions(self, jsond):
        with OracleConnectionManager() as conn:
            segment_arr_json = Promotions.factoring_segments_into_array(jsond['segments'])
            items_arr_json = Promotions.factoring_items_into_array(jsond['items'])
            customer_arr_json = Promotions.factoring_customers_into_array(jsond['customers'])
            x_error_msg = conn.set_output_param('STRING')
            header_id = conn.set_output_param('NUMBER')
            conn.execute("""
            BEGIN
                almo_promo_pkg.insert_promotion (
                        :p_header_id,
                        :p_modifier_name,
                        :p_modifier_start_date,
                        :p_modifier_end_date,
                        :p_org_id,
                        :p_approval_flag,
                        :p_process_flag,
                        :p_created_by,
                        :p_customer_ids_arr,
                        :p_segment_name_arr,
                        :p_segment_promo_arr,
                        :p_segment_discount_arr,
                        :p_segment_sell_in_from,
                        :p_segment_sell_in_to,
                        :p_segment_sell_out_from,
                        :p_segment_sell_out_to,
                        :p_item_id_arr,
                        :p_item_promo_arr,
                        :p_item_discount_arr,
                        :p_item_sell_in_from,
                        :p_item_sell_in_to,
                        :p_item_sell_out_from,
                        :p_item_sell_out_to,
                        :p_approver_id,
                        :x_status_code,
                        :x_error_msg);
            end;
            """, output_key='x_status_code',
                         p_header_id=header_id,
                         p_modifier_name=jsond['modifier_name'],
                         p_modifier_start_date=jsond['start_date'],
                         p_modifier_end_date=jsond['end_date'],
                         p_org_id=jsond['org_id'],
                         p_approval_flag=jsond['approval_flag'],
                         p_process_flag=jsond['process_flag'],
                         p_created_by=jsond['created_by'],
                         p_customer_ids_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, customer_arr_json),
                         p_segment_name_arr=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['category_name']),
                         p_segment_promo_arr=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['promo_name']),
                         p_segment_discount_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, segment_arr_json['discount']),
                         p_segment_sell_in_from=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['sell_in_from_date']),
                         p_segment_sell_in_to=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['sell_in_to_date']),
                         p_segment_sell_out_from=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['sell_out_from_date']),
                         p_segment_sell_out_to=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['sell_out_to_date']),
                         p_item_id_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, items_arr_json['inventory_item_id']),
                         p_item_promo_arr=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['promo_name']),
                         p_item_discount_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, items_arr_json['discount']),
                         p_item_sell_in_from=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['sell_in_from_date']),
                         p_item_sell_in_to=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['sell_in_to_date']),
                         p_item_sell_out_from=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['sell_out_from_date']),
                         p_item_sell_out_to=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['sell_out_to_date']),
                         p_approver_id=jsond['approver_id'],
                         x_error_msg=x_error_msg)
            conn.get_output_param(raise_exception=True, send_email=True)
            msg = 'Insert promotions successfully - {}.'.format(header_id.getvalue())
            jsond['qp_list_header_id'] = int(header_id.getvalue())
            Workflows.delete_workflow_with_wf_key(
                jsond['qp_list_header_id'])
            if jsond['approver_id']:
                jsond['manager_name'], jsond['manager_email'] = Donation(
                ).get_approver_details(jsond['approver_id'])
                promotion_url = {'header_id': jsond['qp_list_header_id'],
                                 'process_flag': jsond['process_flag'],
                                 'org_id': jsond['org_id'],
                                 'approval_flag': jsond['approval_flag'],
                                 'approver_id': jsond['approver_id'],
                                 'created_by': jsond['created_by'],
                                 'org_name': jsond['org_name']}
                dump_data = ujson.dumps(promotion_url).encode('utf-8')
                jsond['approve_link'] = base64.b64encode(dump_data).decode('utf-8')
                promotion_url['process_flag'] = 'R'
                promotion_url['approval_flag'] = 'R'
                dump_data = ujson.dumps(promotion_url).encode('utf-8')
                jsond['reject_link'] = base64.b64encode(dump_data).decode('utf-8')
                mail_response = Promotions.send_promotion_to_approver(jsond)
                msg = msg + mail_response
            else:
                self.change_status(jsond, 'N')

        return {'status': Status.OK.value, 'msg': msg}

    @staticmethod
    def send_promotion_to_approver(jsond):
        jsond['segments'] = Promotions.factoring_email_segments(jsond['segments'])
        if jsond['segments']:
            subj = '[Approval] Promo({0}) for the time period ({1}-{2}) is awaiting your approval'
            mail_data = {
                'subject': subj.format(jsond['modifier_name'],
                                       jsond['start_date'], jsond['end_date']),
                'template_id': 'promotion_approve',
                'params': [{'key': key, 'value': value} for key, value in jsond.items()],
                'to_email': jsond['manager_email']
            }
            result = CommonUtils.send_mail(mail_data)
            if result != 'SUCCESS':
                return 'Failed to send Email to approver'
        return 'Mail has been sent to approver'

    @staticmethod
    def send_promotion_draft_to_approver(jsond):
        subj = 'Notification: Promo({0}) for the time period ({1}-{2}) is moved to Draft'
        mail_data = {
            'subject': subj.format(jsond['modifier_name'],
                                   jsond['start_date'], jsond['end_date']),
            'template_id': 'promotion_draft',
            'params': [{'key': key, 'value': value} for key, value in jsond.items()],
            'to_email': jsond['manager_email']
        }
        result = CommonUtils.send_mail(mail_data)
        if result != 'SUCCESS':
            return 'Failed to send Email to approver'
        return 'Mail has been sent to approver'

    @staticmethod
    def factoring_email_segments(segments):
        new_segments = [segment for segment in segments
                        if datetime.datetime.strptime(
                            segment['sell_out_to_date'], '%d-%b-%Y').date()
                        >= datetime.datetime.now().date()]
        sort_key = 'type' if new_segments and 'type' in new_segments[0].keys() else 'creation_date'
        return sorted(new_segments, key=lambda k: k[sort_key], reverse=True)

    @staticmethod
    def create_promo(conn, header_id):
        conn.execute("""
        BEGIN
            almo_promo_pkg.create_promo(
                :p_header_id
            );
        END;
        """, p_header_id=header_id)
        return 'SUCCESS'

    @staticmethod
    def factoring_customers_into_array(customers):
        customer_id_arr = []
        for customer in customers:
            if customer['type'] == 'new':
                customer_id_arr.append(customer['cust_account_id'])
        return customer_id_arr

    @staticmethod
    def factoring_segments_into_array(segments):
        segment_arr_json = {'category_name': [], 'promo_name': [], 'discount': [],
                            'sell_in_from_date': [], 'line_number': [],
                            'sell_out_from_date': [], 'sell_in_to_date': [], 'sell_out_to_date': []}
        for segment in segments:
            if segment['type'] == 'new' or segment['type'] == 'update':
                segment_arr_json['line_number'].append(segment['line_number'])
                segment_arr_json['category_name'].append(segment['category_name'])
                segment_arr_json['promo_name'].append(segment['promo_name'])
                segment_arr_json['discount'].append(float(segment['discount']))
                segment_arr_json['sell_in_from_date'].append(segment['sell_in_from_date'])
                segment_arr_json['sell_out_from_date'].append(segment['sell_out_from_date'])
                segment_arr_json['sell_in_to_date'].append(segment['sell_in_to_date'])
                segment_arr_json['sell_out_to_date'].append(segment['sell_out_to_date'])
        return segment_arr_json

    @staticmethod
    def factoring_items_into_array(items):
        item_arr_json = {'inventory_item_id': [],
                         'promo_name': [],
                         'discount': [],
                         'sell_in_from_date': [],
                         'sell_out_from_date': [],
                         'sell_in_to_date': [],
                         'sell_out_to_date': []}
        for item in items:
            if item['type'] == 'new' or item['type'] == 'update':
                item_arr_json['inventory_item_id'].append(item['inventory_item_id'])
                item_arr_json['promo_name'].append(item['promo_name'])
                item_arr_json['discount'].append(float(item['discount']))
                item_arr_json['sell_in_from_date'].append(item['sell_in_from_date'])
                item_arr_json['sell_out_from_date'].append(item['sell_out_from_date'])
                item_arr_json['sell_in_to_date'].append(item['sell_in_to_date'])
                item_arr_json['sell_out_to_date'].append(item['sell_out_to_date'])
        return item_arr_json

    def update_promotions(self, jsond):
        with OracleConnectionManager() as conn:
            customer_arr_json = Promotions.factoring_customers_into_array(jsond['customers'])
            segment_arr_json = Promotions.factoring_segments_into_array(jsond['segments'])
            items_arr_json = Promotions.factoring_items_into_array(jsond['items'])
            conn.execute("""
            BEGIN
                almo_promo_pkg.update_promotion (
                        :p_header_id,
                        :p_modifier_name,
                        :p_modifier_start_date,
                        :p_modifier_end_date,
                        :p_org_id,
                        :p_approval_flag,
                        :p_process_flag,
                        :p_created_by,
                        :p_customer_ids_arr,
                        :p_line_number_arr,
                        :p_segment_name_arr,
                        :p_segment_promo_arr,
                        :p_segment_discount_arr,
                        :p_segment_sell_in_from,
                        :p_segment_sell_in_to,
                        :p_segment_sell_out_from,
                        :p_segment_sell_out_to,
                        :p_item_id_arr,
                        :p_item_promo_arr,
                        :p_item_discount_arr,
                        :p_item_sell_in_from,
                        :p_item_sell_in_to,
                        :p_item_sell_out_from,
                        :p_item_sell_out_to,
                        :p_approver_id,
                        :x_status_code);
            end;
            """, output_key='x_status_code',
                         p_header_id=jsond['qp_list_header_id'],
                         p_modifier_name=jsond['modifier_name'],
                         p_modifier_start_date=jsond['start_date'],
                         p_modifier_end_date=jsond['end_date'],
                         p_org_id=jsond['org_id'],
                         p_approval_flag=jsond['approval_flag'],
                         p_process_flag=jsond['process_flag'],
                         p_created_by=jsond['created_by'],
                         p_customer_ids_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, customer_arr_json),
                         p_approver_id=jsond['approver_id'],
                         p_line_number_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, segment_arr_json['line_number']),
                         p_segment_name_arr=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['category_name']),
                         p_segment_promo_arr=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['promo_name']),
                         p_segment_discount_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, segment_arr_json['discount']),
                         p_segment_sell_in_from=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['sell_in_from_date']),
                         p_segment_sell_in_to=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['sell_in_to_date']),
                         p_segment_sell_out_from=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['sell_out_from_date']),
                         p_segment_sell_out_to=conn.cursor.arrayvar(
                             cx_Oracle.STRING, segment_arr_json['sell_out_to_date']),
                         p_item_id_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, items_arr_json['inventory_item_id']),
                         p_item_promo_arr=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['promo_name']),
                         p_item_discount_arr=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, items_arr_json['discount']),
                         p_item_sell_in_from=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['sell_in_from_date']),
                         p_item_sell_in_to=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['sell_in_to_date']),
                         p_item_sell_out_from=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['sell_out_from_date']),
                         p_item_sell_out_to=conn.cursor.arrayvar(
                             cx_Oracle.STRING, items_arr_json['sell_out_to_date']))
            conn.get_output_param(raise_exception=True, send_email=True)
            msg = 'Update promotions successfully.'
            # Delete Workflow if the approver is changed
            Workflows.delete_workflow_with_wf_key(
                jsond['qp_list_header_id'])
            if jsond['approver_id']:
                jsond['manager_name'], jsond['manager_email'] = Donation(
                ).get_approver_details(jsond['approver_id'])
                promotion_url = {'header_id': jsond['qp_list_header_id'],
                                 'process_flag': jsond['process_flag'],
                                 'org_id': jsond['org_id'],
                                 'approval_flag': jsond['approval_flag'],
                                 'approver_id': jsond['approver_id'],
                                 'created_by': jsond['created_by'],
                                 'org_name': jsond['org_name']}
                dump_data = ujson.dumps(promotion_url).encode('utf-8')
                jsond['approve_link'] = base64.b64encode(dump_data).decode('utf-8')
                promotion_url['process_flag'] = 'R'
                promotion_url['approval_flag'] = 'R'
                dump_data = ujson.dumps(promotion_url).encode('utf-8')
                jsond['reject_link'] = base64.b64encode(dump_data).decode('utf-8')
                mail_response = Promotions.send_promotion_to_approver(jsond)
                msg = msg + mail_response
            else:
                self.change_status(jsond, 'N')
        return {'status': Status.OK.value, 'msg': msg}

    @ staticmethod
    def delete_promotion_segments(jsond):
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                almo_promo_pkg.delete_promo_segments(
                    :p_header_id,
                    :p_category_id,
                    :p_category_name,
                    :x_status_code
                );
            END;
            """, output_key='x_status_code',
                         p_header_id=jsond['header_id'],
                         p_category_id=None,
                         p_category_name=jsond['category_name'])
            conn.get_output_param(raise_exception=True, send_email=True)
            if jsond.get('items'):
                for item in jsond.get('items'):
                    data = {'inventory_item_id': item['inventory_item_id'],
                            'header_id': jsond['header_id']}
                    Promotions.delete_promotion_items(data)
        return {'status': Status.OK.value,
                'msg': 'deleted segment successfully:{}'.format(jsond['category_name'])}

    @ staticmethod
    def delete_promotion_items(jsond):
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                almo_promo_pkg.delete_promo_items(
                    :p_header_id,
                    :p_inventory_item_id,
                    :x_status_code
                );
            END;
            """, output_key='x_status_code',
                         p_header_id=jsond['header_id'],
                         p_inventory_item_id=jsond['inventory_item_id'])
            conn.get_output_param(raise_exception=True, send_email=True)
            return {'status': Status.OK.value,
                    'msg': 'deleted item successfully:{}'.format(jsond['inventory_item_id'])}

    def get_segments(self):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_all_segments']
            conn.execute(query)
            result = conn.get_result()
        return {'status': Status.OK.value, 'segments': result}

    def get_items(self, segment_name):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['items_based_on_segments']
            query = query.format(segment_name)
            conn.execute(query)
            result = conn.get_result()
        return {'status': Status.OK.value, 'items': result}

    def change_status(self, jsond, status_flag='Y'):
        with OracleConnectionManager() as conn:
            workflow_name = 'QPEX_PROMOTIONS_{}'.format(jsond['org_name'])
            query = self.sql_file['workflow_details']
            conn.execute(query, p_workflow=workflow_name)
            workflow_details = conn.get_single_result()
            jsond['workflow_id'] = workflow_details['workflow_id']
            jsond['wf_name'] = workflow_name
        if jsond['process_flag'] == 'D':
            # Delete Workflow if the approver is changed
            Workflows.delete_workflow_with_wf_key(
                jsond['qp_list_header_id'])
            name, email = Donation().get_approver_details(jsond['approver_id'])
            jsond['manager_email'] = email
            jsond['manager_name'] = name
            jsond['process_flag'] = 'D'
            jsond['approval_flag'] = 'I'
            jsond['approver_id'] = None
            Promotions.send_promotion_draft_to_approver(jsond)

        elif jsond['process_flag'] != 'R':
            # start the workflow if notifications
            approver_id = Donation().start_lovefood_flow(
                jsond['qp_list_header_id'], jsond)
            if approver_id:
                name, email = Donation().get_approver_details(approver_id)
                jsond['approver_id'] = approver_id
                jsond['manager_email'] = email
                jsond['manager_name'] = name
                promotion_url = {'header_id': jsond['qp_list_header_id'],
                                 'process_flag': jsond['process_flag'],
                                 'org_id': jsond['org_id'],
                                 'approval_flag': jsond['approval_flag'],
                                 'approver_id': jsond['approver_id'],
                                 'created_by': jsond['created_by'],
                                 'org_name': jsond['org_name']}
                dump_data = ujson.dumps(promotion_url).encode('utf-8')
                jsond['approve_link'] = base64.b64encode(dump_data).decode('utf-8')
                promotion_url['process_flag'] = 'R'
                promotion_url['approval_flag'] = 'R'
                dump_data = ujson.dumps(promotion_url).encode('utf-8')
                jsond['reject_link'] = base64.b64encode(dump_data).decode('utf-8')
                Promotions.send_promotion_to_approver(jsond)
            else:
                jsond['process_flag'] = 'A'
                jsond['approval_flag'] = 'A'
                jsond['approver_id'] = None
        return Promotions.update_promotion_status(jsond, status_flag)

    @staticmethod
    def update_promotion_status(jsond, status_flag):
        with OracleConnectionManager() as conn:
            conn.execute("""
                BEGIN
                    almo_promo_pkg.update_promotion_status(
                    :p_header_id,
                    :p_process_flag,
                    :p_approval_flag,
                    :p_approver_id,
                    :p_created_by,
                    :p_status_flag,
                    :x_status_code
                );
                END;
            """, output_key='x_status_code',
                         p_header_id=jsond['header_id'] or jsond['qp_list_header_id'],
                         p_process_flag=jsond['process_flag'],
                         p_approval_flag=jsond['approval_flag'],
                         p_approver_id=jsond['approver_id'],
                         p_created_by=jsond['created_by'],
                         p_status_flag=status_flag
                         )
            conn.get_output_param(raise_exception=True)
            if jsond['approval_flag'] == 'A':
                Promotions.create_promo(conn, jsond['header_id'])
        return {'status': 0, 'msg': 'Status Updated successfully'}

    def check_modifier(self, val):
        result = {}
        with OracleConnectionManager() as conn:
            conn.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = self.sql_file['modifier_validation']
            conn.execute(query, p_parm=val)
            response = conn.get_result()
            if response:
                result['msg'] = "Modifier Name already exists !!"
                result['status'] = 1
            else:
                result['msg'] = "Success !!"
                result['status'] = 0
        return result
