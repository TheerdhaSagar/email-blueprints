from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util
from finapi.utils.log_util import LogUtil
from finapi.utils.common_utils import CommonUtils
from finapi.sql import sql_util
import requests
import base64


@LogUtil.class_module_logs('Invoice')
class Invoice:

    def __init__(self, **kwargs):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    def invoice_print(self, trx_id, org_id, language, intercompany=False):
        logger.addinfo('@ models - invoice - invoice_print(+)')
        connection = None
        cursor = None
        header_details = []
        inv_header = []
        lines_list = []
        tax_details = []
        address_details = []
        note_details = []
        sql_file = db_util.getSqlData()
        image_base64 = ''
        footer_base64 = ''
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            if intercompany:
                query = sql_file['inv_header_print_view_query']
            else:
                query = sql_file['inv_header_print']
            cursor.execute(query, p_trx_id=trx_id)
            lines_list = Invoice.show_lines(trx_id)
            tax_details = Invoice.tax_data(trx_id)
            address_details = Invoice.address_data(org_id)
            note_details = Invoice.note_details(trx_id, org_id, language)
            try:
                # get header logo base64 based on org id
                header_image = requests.get(CommonUtils.get_header_logo(org_id)).content
                image_base64 = base64.b64encode(header_image).decode('utf-8')
                image_base64 = 'data:image/png;base64,' + image_base64
                header_info_details = 'header_text_{}'.format(org_id)
                # get footer image base64
                footer_image = requests.get(
                    'https://cdn.almonature.com/hubfs/pdf-footer/reports-footer.jpg').content
                footer_base64 = base64.b64encode(footer_image).decode('utf-8')
                footer_base64 = 'data:image/png;base64,' + footer_base64
            except Exception as e:
                logger.findaylog("""@ EXCEPTION - models - invoice -
                                 invoice_print """ + str(e))
        except Exception as error:
            logger.findaylog("""@ 34 EXCEPTION - models - invoice -
                 invoice_print """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            myinvoice = Code_util.get_fieldtype(fieldnames, field_type)
            header_details.append(myinvoice)
            invoice_header = {}
            for row in cursor:
                header = {}
                for index, fn in enumerate(fieldnames):
                    header[fn] = row[index]
                header_details.append(header)
            invoice_header['header'] = header_details
            invoice_header['lines'] = lines_list
            invoice_header['tax'] = tax_details
            invoice_header['address'] = address_details
            invoice_header['notes'] = note_details
            invoice_header['header_logo'] = image_base64
            try:
                invoice_header['header_text'] = self.sql_file[header_info_details]
            except KeyError:
                invoice_header['header_text'] = self.sql_file['header_text_default']
            invoice_header['footer_logo'] = footer_base64
            inv_header.append(invoice_header)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - invoice - invoice_print(-)')
        return inv_header

    @staticmethod
    def show_lines(trx_id):
        logger.addinfo('@ models - invoice - show_lines(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['inv_line_print']
            cursor.execute(query, P_CUST_TRX_ID=trx_id,
                           print_lang=None, CUSTOMER_NUMBER=None)
            inv_lines = []
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            invoice = Code_util.get_fieldtype(fieldnames, field_type)
            inv_lines.append(invoice)
            for row in cursor:
                inv_line = {}
                for index, fn in enumerate(fieldnames):
                    inv_line[fn] = row[index]
                inv_lines.append(inv_line)
        except Exception as error:
            logger.findaylog("""@ 83 EXCEPTION - models - invoice -
                 show_lines """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - invoice - show_lines(-)')
        return inv_lines

    @staticmethod
    def tax_data(trx_id):
        logger.addinfo('@ models - invoice - tax_data(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['tax_note']
            tax_details = []
            cursor.execute(query, P_CUST_TRX_ID=trx_id)
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            tax_data = Code_util.get_fieldtype(fieldnames, field_type)
            tax_details.append(tax_data)
            for row in cursor:
                tax_line = {}
                for index, fn in enumerate(fieldnames):
                    tax_line[fn] = row[index]
                tax_details.append(tax_line)
        except Exception as error:
            logger.findaylog("""@ 114 EXCEPTION - models - invoice -
                 tax_data """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - invoice - tax_data(-)')
        return tax_details

    @staticmethod
    def address_data(org_id):
        logger.addinfo('@ models - invoice - address_data(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['tax_footer']
            address_details = []
            cursor.execute(query, p_org_id=org_id)
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            address = Code_util.get_fieldtype(fieldnames, field_type)
            address_details.append(address)
            for row in cursor:
                address_line = {}
                for index, fn in enumerate(fieldnames):
                    address_line[fn] = row[index]
                address_details.append(address_line)
        except Exception as error:
            logger.findaylog("""@ 145 EXCEPTION - models - invoice -
                 address_data """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - invoice - address_data(-)')
        return address_details

    @staticmethod
    def note_details(trx_id, org_id, language):
        logger.addinfo('@ models - invoice - note_details(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_note']
            note_details_info = []
            cursor.execute(query, P_CUST_TRX_ID=trx_id, print_lang=language,
                           P_ORG_ID=org_id)
            fieldnames = [a[0].lower() for a in cursor.description]
            field_type = [a[1] for a in cursor.description]
            note_data = Code_util.get_fieldtype(fieldnames, field_type)
            note_details_info.append(note_data)
            for row in cursor:
                note_line = {}
                for index, fn in enumerate(fieldnames):
                    note_line[fn] = row[index]
                note_details_info.append(note_line)
        except Exception as error:
            logger.findaylog("""@ 177 EXCEPTION - models - invoice -
                 note_details """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - invoice - note_details(-)')
        return note_details_info

    @staticmethod
    def get_payment(name):
        logger.addinfo('@ models - invoice - get_payment(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            all_query = sql_file['payment_term_query']
            cursor.execute(all_query, p_name=name)
            result = cursor.fetchone()
        except Exception as error:
            logger.findaylog("""@ 201 EXCEPTION - models - invoice -
                 get_payment """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - invoice - get_payment(-)')
        return result[0]


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'invoice',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
