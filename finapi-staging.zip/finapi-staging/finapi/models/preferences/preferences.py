import smtplib
from finapi.utils import db_util
from finapi.sql import sql_util
from finapi.utils.logdata import logger
from finapi.utils import auth_util
from finapi.utils.common_utils import CommonUtils
from finapi.models.login.login import Login
import random
from mailjet_rest import Client
import os
import string
from finapi.utils.log_util import LogUtil
from finapi.utils.conn_util import OracleConnectionManager


@LogUtil.class_module_logs('preferences')
class Preferences:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def reset_password(user_name, password, new_password):
        gmail_user = 'support@qualitypeopleit.com'
        gmail_pwd = 'Welcome9'
        result = ""
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.getSqlData()
            update = sqlFile['update_password']
            cursor.execute(update, p_user_name=user_name.upper(),
                           p_new_password=password)
            connection.commit()
            password_query = sqlFile['password_query']
            cursor.execute(password_query, p_user_name=user_name.upper())
            data = cursor.fetchone()
            if data[0] == password:
                email = sqlFile['email-query']
                cursor.execute(email, p_user_name=user_name.upper())
                to = cursor.fetchone()
                smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
                smtpserver.ehlo()
                smtpserver.starttls()
                smtpserver.ehlo
                smtpserver.login(gmail_user, gmail_pwd)
                subject = 'Reset Password'
                msg = 'Subject: %s\n\n' % (subject)
                message = msg + """
                New Password: """ + new_password + """
                """
                smtpserver.sendmail(gmail_user, to, message)
                smtpserver.quit()
                result = 'success'
            else:
                result = "fails"
                logger.findaylog(
                    'models - prefefences - reset_password - Failed to change password')
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - preference -
                 reset_password """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return result

    @staticmethod
    # used in cutomer to get ordertypes of organization
    @db_util.langs("American")
    def get_dateformat():
        with OracleConnectionManager() as conn:
            sql_file = db_util.getSqlData()
            query = sql_file['dateformat_qry']
            conn.execute(query)
            datefrmt_list = conn.get_result()
        return datefrmt_list

    @staticmethod
    def save(preference, usr_id, old_passwd, new_passwd):
        with OracleConnectionManager() as conn:
            sql_file = db_util.getSqlData()
            if old_passwd and new_passwd:
                query = sql_file['password_query_id']
                conn.execute(query, p_user_id=usr_id)
                data = conn.get_single_result()
                if data:
                    _value = data['encrypted_password']
                    real_password = str(_value)
                    setattr(preference, "ENCRYPTED_PASSWORD",
                            auth_util.encrypt(new_passwd))
                    setattr(preference, "PASSWORD_CHANGE_ON_LOGIN",
                            "N")
                    setattr(preference, "ADDITIONAL_INFO_1", new_passwd)
                    if auth_util.verify(old_passwd, real_password):
                        sql_data = 'update  qpex_client_users set '
                        for key, value in preference.__dict__.items():
                            sql_data += str(key)+'='+"'"
                            if value is not None:
                                sql_data += str(value)
                            sql_data += "'"+','
                        sql_data = sql_data[:-1]
                        sql_data += str(' '+'where user_id ='+str(usr_id))
                        conn.execute(sql_data)
                        result = "success"
                    else:
                        result = "password"
                        logger.findaylog(
                            'models - Preferences - save - Please enter valid password')
                else:
                    result = "user_id"
                    logger.findaylog('models - Preferences - save - User id has invalid data')
            else:
                sql_data = 'update  qpex_client_users set '
                for key, value in preference.__dict__.items():
                    sql_data += str(key)+'='+"'"
                    if value is not None:
                        sql_data += str(value)
                    sql_data += "'"+','
                sql_data = sql_data[:-1]
                sql_data += str(' '+'where user_id ='+str(usr_id))
                conn.execute(sql_data)
                result = "success"
        return result

    @staticmethod
    def reset_passwd(user_name):
        hashval = ''.join(random.choice
                          (string.ascii_uppercase +
                           string.ascii_lowercase +
                           string.digits) for i in range(20))
        user_data = {'link': hashval}
        sqlFile = db_util.getSqlData()
        with OracleConnectionManager() as conn:
            conn.execute(sqlFile['key_save'], pkey=hashval,
                         p_user_name=user_name.upper())
            email_qry = sqlFile['email-query']
            conn.execute(email_qry, p_user_name=user_name.upper())
            user_details = conn.get_single_result()
        user_data['to'] = user_details['email_address']
        user_data['language'] = user_details['ui_language']
        user_data['user_name'] = user_name
        if not user_data['language']:
            user_data['language'] = 'EN'

        if user_data['to']:
            status = Preferences.send_email(user_data, 1260839, 'resetpwd')
        else:
            status = 'invalid_user'
            logger.findaylog('models - Preferences - reset_passed - Invalid user')
        return status

    @staticmethod
    def send_email(jsond, template_id, emailtype):
        sql_file = sql_util.get_translation_sql(jsond['language'])
        strings = db_util.get_strings()
        subject = sql_file[emailtype + '_subject']
        template_subject = sql_file[emailtype + '_template_subject']
        template_data = {
            'template_id': template_id,
            'params': [
                {
                    'key': 'user_name',
                    'value': jsond['user_name']
                },
                {
                    'key': 'link',
                    'value': jsond['link']
                },
                {
                    'key': 'resetpwd_template_subject',
                    'value': template_subject
                },
                {
                    'key': 'resetbtn_click_text',
                    'value': sql_file['resetbtn_click_text']
                },
                {
                    'key': 'reset_password',
                    'value': sql_file['reset_password']
                }
            ], 'subject': subject,
            'to_email': jsond['to'],
            'to_name': '',
            'sender': {
                'email': strings['sender_email'],
                'name':  strings['sender_name']
            },
            'attachments': []
        }
        result = CommonUtils.send_mail(template_data)
        if result == 'SUCCESS':
            status = 'success'
        else:
            status = 'Failed to send the email'
            logger.findaylog(
                'models - Preferences - send_mail - Failed to send_email - {}'.format(template_data))
        return status

    #  used in cutomer to get ordertypes of organization
    @staticmethod
    def get_userdetails(user_key):
        sql_file = db_util.getSqlData()
        with OracleConnectionManager() as conn:
            conn.execute(sql_file['user_idqry'], p_key=user_key)
            idval = conn.get_single_result()
        if idval:
            user_details = Login.get_user_preferences(idval['user_id'])
        else:
            user_details = "Incorrect Key"
            logger.findaylog('models - Preferences - get_userdetails - Incorrect key')
        return user_details

    @staticmethod
    def password_change(user_name, password):
        status = ''
        user_details = {}
        hash_val = ''.join(random.choice(
            string.ascii_uppercase +
            string.ascii_lowercase +
            string.digits) for _ in range(20))
        sql_file = db_util.getSqlData()
        new_password = CommonUtils.decode_credential(password)
        encrypted_password = auth_util.encrypt(new_password)
        with OracleConnectionManager() as conn:
            conn.execute(sql_file['passwd_change'],
                         p_enpasswd=encrypted_password,
                         p_user_name=user_name.upper())
            email_qry = sql_file['email-query']
            conn.execute(email_qry, p_user_name=user_name.upper())
            email_details = conn.get_single_result()
        user_details['to'] = email_details['email_address']
        user_details['language'] = email_details['ui_language']

        if not user_details['language']:
            user_details['language'] = 'EN'
        user_details['link'] = hash_val
        if user_details['to']:
            # '697287' old template Id for password change
            translate_file = sql_util.get_translation_sql(user_details['language'])
            strings = db_util.get_strings()
            subject = translate_file['pwdchange_subject']
            template_data = {
                'template_id': translate_file['pwdchange_template_id'],
                'params': [
                    {
                        'key': 'link',
                        'value': hash_val
                    }
                ], 'subject': subject,
                'to_email': user_details['to'],
                'to_name': '',
                'sender': {
                    'email': strings['sender_email'],
                    'name':  strings['sender_name']
                },
                'attachments': []
            }
            result = CommonUtils.send_mail(template_data)
            if result == 'SUCCESS':
                status = 'success'
            else:
                status = 'Failed to send the email'
                logger.findaylog(
                    'models - Preferences - password_change - Failed to send email - {}'.format(template_data))
        with OracleConnectionManager() as conn:
            conn.execute(sql_file['key_delete'],
                         p_user_name=user_name.upper())
            conn.execute(sql_file['key_save'], pkey=hash_val,
                         p_user_name=user_name.upper())
        return status

    @staticmethod
    def get_homepage_Lookup(lookup_id):
        with OracleConnectionManager() as conn:
            sql_file = db_util.getSqlData()
            query = sql_file['homepage_lookup_code_query']
            conn.execute(query, p_lookup_id=lookup_id)
            lookup = conn.get_result()
        return lookup
