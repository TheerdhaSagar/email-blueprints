import unittest


from finapi.models.cms.cms import CMS
from manage import app


class TestCMS(unittest.TestCase):
    def setUp(self):
        self.app_context = app.app_context()
        self.app_context.push()
        self.cms = CMS()

    def tearDown(self):
        self.app_context.pop()
        self.cms = None

    def test_get_stores(self):
        stores = self.cms.get_stores('IT', 'online')
        self.assertIsInstance(stores, list, 'result is not a list')
        self.assertGreater(len(stores), 0, 'length of the result is zero')
        store = stores[0]
        self.assertIsInstance(store, dict, 'result is not array of objects')
        self.assertIn('name', store, 'name attribute is not in result')
        self.assertIn('url', store, 'url attribute is not in result')
        self.assertIn('icon', store, 'icon attribute is not in result')
        stores = self.cms.get_stores('IT', None)
        self.assertIsInstance(stores, list, 'result is not a list')

    def test_parse_filter_params(self):
        pass

    def test_get_recipe_table_id(self):
        pass

    def test_get_recipes(self):
        pass

    def test_filter_recipes_data(self):
        pass

    def test_sort_recipe_weights(self):
        pass

    def test_get_recipe_pet_ages(self):
        pass

    def test_get_recipe_advantages(self):
        pass

    def test_get_recipe_weights(self):
        pass

    def test_aggregate_data(self):
        pass

    def test_get_product_page_label(self):
        pass

    def test_map_column_values(self):
        pass

    def test_get_table_data(self):
        pass

    def test_get_table_schema(self):
        pass

    def test_get_filter_data(self):
        pass

    def test_get_recipe_filters(self):
        pass
