"""HubSpot API wrapper module."""


import os
import time
import urllib.request
import urllib.parse
import urllib.error

import ujson
import cx_Oracle
import requests
import copy

from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.logdata import logger


class CMS(object):
    """HubSpot API wrapper."""

    yaml_file = sql_util.get_sql('cms')

    # HubSpot api_key and portal id
    hub_id = os.environ['CMS_HUB_ID']
    hub_api = os.environ['CMS_HUB_API']
    hubdb_api = os.environ['CMS_HUBDB_API']
    api_key = os.environ['CMS_HUB_API_KEY']
    # API gateway URL
    api_url = os.environ['GATEWAY_URL']

    # these objects contain the cached data related to recipes
    table_schemas = {}
    filter_data = {}
    recipes_data = {}
    single_recipe_data = {}
    label_data = {}
    other_recipe_data = {}
    images_data = {}
    brand_data = {}

    # HubSpot tables
    # tables related to recipes API
    items_table = os.environ['CMS_ITEMS_TABLE']
    recipes_it = os.environ['CMS_ITEM_RECIPES_IT']
    recipes_us = os.environ['CMS_ITEM_RECIPES_US']
    item_images_tbl = os.environ['CMS_ITEM_IMAGES']
    food_type_tbl = os.environ['CMS_FOOD_TYPE_TABLE']
    nutrition_tbl = os.environ['CMS_NUTRITION_TABLE']
    pet_age_tbl = os.environ['CMS_PET_AGE_TABLE']
    pet_size_tbl = os.environ['CMS_PET_SIZE_TABLE']
    brand_name_tbl = os.environ['CMS_BRAND_NAME_TABLE']
    food_flavour_tbl = os.environ['CMS_FOOD_FLAVOUR_TABLE']
    special_care_tbl = os.environ['CMS_SPECIAL_CARE_TABLE']
    package_type_tbl = os.environ['CMS_PACKAGE_TYPE_TABLE']
    product_range_tbl = os.environ['CMS_PRODUCT_RANGE_TABLE']
    food_benefits_tbl = os.environ['CMS_FOOD_BENEFITS_TABLE']
    product_labels_tbl = os.environ['CMS_PRODUCT_LABELS_TABLE']
    product_reviews_tbl = os.environ['CMS_PRODUCT_REVIEWS_TABLE']

    contacts_api = os.environ['CMS_CONTACTS_API']
    stores_table = os.environ['CMS_STORES_TABLE']
    contact_us_table = os.environ['CMS_CONTACT_US_TABLE']
    contact_us_tl_table = os.environ['CMS_CONTACT_US_TL_TABLE']
    fnd_territories_table = os.environ['CMS_FND_TERRITORIES_TABLE']
    platform_contact_us_tbl = os.environ['CMS_PLATFORM_CONTACT_US_TABLE']
    business_inquiry_emails_tbl = os.environ['CMS_BUSINESS_INQUIRY_EMAIL_TABLE']
    platform_contact_sub_tbl = os.environ['CMS_PLATFORM_CONTACT_SUB_REASONS_TABLE']
    store_locator_label_tbl = os.environ['STORE_LOCATOR_LABEL_TRANSLATIONS_TABLE']
    store_locator_display_tbl = os.environ['STORE_LOCATOR_DISPLAY_TABLE']
    store_locator_brands_tbl = os.environ['STORE_LOCATOR_BRANDS_TABLE']
    cafl_metrics_table = os.environ['CMS_CAFL_METRICS_TABLE']

    def __init__(self):
        self.connection = None
        self.cursor = None
        self.is_acquired = None
        self.session = requests.Session()
        self.session.trust_env = False
        self.logging = True
        self.headers = {
            'Content-Type': 'application/json'
        }

    def __acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def __generate_hash(self, obj):
        """ return hash value of a given object or string """
        if type(obj) == str:
            return hash(obj)
        return hash(ujson.dumps(obj))

    def get_contact_id(self, email):
        """
        Get HubSpot contact id for the email.

        Notes:
            See https://developers.hubspot.com/docs/methods/contacts/get_contact_by_email

        """
        contact_id = -1
        try:
            url = self.hub_api + 'contacts/v1/contact/email/{0}/profile?hapikey={1}'
            url += '&property=firstname'
            url = url.format(email, self.api_key)
            res = ujson.loads(urllib.request.urlopen(url).read())
            if 'vid' in res:
                contact_id = res['vid']
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_contact_id ''' + str(error))
            raise error
        return contact_id

    def __get_recipe_advantages(self, filters, data, include_attrs=None):
        filter_keys = self.yaml_file['benefits_filters']
        benefits = CMS.get_filter_data(filters, filter_keys)
        result_keys = ['advantage_header', 'advantage_description', 'advantage_icon',
                       'advantage_alt_text', 'advantage_show_in_advantages']

        advantages = []
        for key in filter_keys:
            if key in data and key in benefits and data[key].lower() == 'yes':
                obj = {}
                for res_key in result_keys:
                    value = benefits[key].get(res_key, '')
                    if include_attrs:
                        if res_key in include_attrs:
                            obj[res_key] = value
                    else:
                        obj[res_key] = value
                advantages.append(obj)
        return advantages

    def __get_recipe_pet_ages(self, filters, data):
        filter_keys = self.yaml_file['pet_age_filters']
        pet_age = CMS.get_filter_data(filters, filter_keys)
        pet_ages = []
        for key in filter_keys:
            if 'pet_ager_adult' in data and data['pet_ager_adult'].lower() == 'yes':
                data['pet_ager_adult-' + data['animal'].lower()] = 'Yes'
            if 'pet_ager_senior' in data and data['pet_ager_senior'].lower() == 'yes':
                data['pet_ager_senior-' + data['animal'].lower()] = 'Yes'

            if key in data and data[key].lower() == 'yes':
                pet_ages.append({
                    'pet_age_new': pet_age[key]['pet_age_new'],
                    'pet_age_description': pet_age[key]['pet_age_description']
                })
        return pet_ages

    def __get_recipe_weights(self, filters, data):
        filter_keys = self.yaml_file['package_filters']
        packages = CMS.get_filter_data(filters, filter_keys)

        weights = data['weight']
        for index, row in enumerate(weights):
            weight = row['weight'].split(' ')
            if weight and weight[0] != '':
                weights[index]['weight_uom'] = weight[1].lower().replace('.', '').strip()
                try:
                    weights[index]['weight'] = int(weight[0].replace(',', '.'))
                except ValueError:
                    weights[index]['weight'] = float(weight[0].replace(',', '.'))
            else:
                weights[index]['weight_uom'] = ''
            weights[index]['weight_tradesheet'] = weights[index]['weight']
            package_type_icon = ''
            for package_type in filter_keys:
                if weights[index].get(package_type, '').lower() == 'yes':
                    package = packages.get(package_type)
                    if 'package_size' in weights[index]:
                        package_size = weights[index]['package_size']
                        del weights[index]['package_size']
                        del weights[index][package_type]
                    else:
                        package_size = 'small'
                    if package:
                        package_type_icon = package[package_size + '_package_type_icon']
                    # check if the package type is megapack or multipack and
                    # if no of bags, no of pouches value is present
                    if package_type in ['package_type_megapack', 'package_type_multipack'] and \
                            (weights[index].get('number_of_bags') or
                             weights[index].get('number_of_pouches')):
                        count = 0
                        # no of bags count
                        if weights[index].get('number_of_bags'):
                            count += int(weights[index].get('number_of_bags'))
                        # no of pouches count
                        if weights[index].get('number_of_pouches'):
                            count += int(weights[index].get('number_of_pouches'))
                        # calculate weight of a single bag/pouch
                        # display weight in -> weight eg: 6x70g
                        weights[index]['weight_tradesheet'] = str(
                            count) + "\u2715" + str(weights[index]['weight']/count)
                    break
            weights[index]['package_type_icon'] = package_type_icon
        return weights

    def __parse_filter_params(self, req):
        """
        parse the parameters which are passed in `filters` query param
        to the recipes API
        """
        filters = {}
        pet_age_filters = self.yaml_file['pet_age_filters']
        filter_categories = self.yaml_file['filter_categories']

        for key, values in list(req.items()):
            if key != 'filters':
                continue
            # values is a list of filters
            for item in values:
                filter_key = None
                # check if each item in the values list is a
                # valid filter type or not
                for filter_type in filter_categories:
                    if item.find(filter_type) != -1:
                        filters[filter_type] = filters.setdefault(filter_type, {})
                        filter_key = filter_type
                        break

                if item.find('-') != -1:
                    value_array = item.split('-')
                    if item in pet_age_filters:
                        filters[filter_key][value_array[0]] = 'YES'
                    else:
                        if value_array[0] in filters[filter_key]:
                            filters[filter_key][value_array[0]] += ',' + str(value_array[1]).upper()
                        else:
                            filters[filter_key][value_array[0]] = str(value_array[1]).upper()
                else:
                    filters[filter_key][item] = 'YES'
            break
        return filters

    def __release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def check_image(self, image, image_type):
        if not image:
            image_name = image_type + '_coming_soon_image'
            return self.yaml_file[image_name]
        return image

    def business_inquiry_support_email(self, country=None):
        """
        This method is used to get support email from HubDB
        """
        logger.addinfo('@ models - cms - business_inquiry_support_email(+)')
        try:
            if country:
                query_params = '&country__like=' + country
                data = self.get_table_data(self.business_inquiry_emails_tbl, query=query_params)
            else:
                data = []

            if not data:
                data = self.get_table_data(self.business_inquiry_emails_tbl)
                if 'status' not in data:
                    for i in range(len(data)):
                        values = data[i]
                        if 'country' not in values:
                            data = [values]
                            break

            if 'status' in data:
                result = CMS.get_error_message(data.get('msg'))
            else:
                result = []
                for i in range(len(data)):
                    values = data[i]
                    if 'mail_to_cc' in values:
                        mail_to_cc = values['mail_to_cc']
                    else:
                        mail_to_cc = ''
                    result.append({
                        'name': values['name'],
                        'support_email': values['support_email'],
                        'mail_to_cc': mail_to_cc
                    })

        except Exception as error:
            logger.findaylog(''''@ EXCEPTION models - cms -
                business_inquiry_support_email ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - business_inquiry_support_email(-)')
        return result

    def contact_log(self, props):
        """
        Create engagement log for contact in HubSpot.

        Notes:
            See https://developers.hubspot.com/docs/methods/engagements/create_engagement

        """
        logger.addinfo('@ models - cms - contact_log(+)')
        try:
            if 'type' in props and props['type'] != 'EMAIL':
                return {
                    'status': 'ERROR',
                    'msg': 'Log type ' + str(props['type']) + ' is not supported'
                }
            url = self.hub_api + 'engagements/v1/engagements?hapikey={0}'
            url = url.format(self.api_key)

            if 'contact_id' in props:
                contact_id = props['contact_id']
            else:
                contact_id = self.get_contact_id(props['email'])

            req = {
                'engagement': {
                    'active': True,
                    'type': 'EMAIL',
                },
                'associations': {
                    'contactIds': [contact_id]
                },
                'metadata': {
                    'from': {
                        'email': props['sender']
                    },
                    'to': [
                        {
                            'email': props['email']
                        }
                    ],
                    'subject': props['subject'],
                    'html': props['html_message']
                }
            }

            request = requests.post(url=url, headers=self.headers, data=ujson.dumps(req))
            if request.status_code != 200:
                result = ujson.dumps(request.text)
                logger.findaylog('models - contact_log ' + str(request.status_code))
            else:
                result = {
                    'status': 'OK',
                    'msg': 'Contact log added successfully'
                }
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                contact_log ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - contact_log(-)')
        return result

    def clean_json_cache(self):
        logger.addinfo('@ models - cms - clean_json_cache(+)')
        try:
            self.__acquire()
            query = self.yaml_file['clear_json_cache_query']
            self.cursor.execute(query)
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                clean_json_cache ''' + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.__release()
        logger.addinfo('@ models - cms - clean_json_cache(-)')
        return {'status': 0, 'msg': 'Cache cleared successfully'}

    def create_contact(self, props, update_with_vid=None):
        """
        Create/Update a contact in HubSpot based on the parameters.

        Notes:
            See https://developers.hubspot.com/docs/methods/contacts/create_or_update

        """
        logger.addinfo('@ models - cms - create_contact(+)')
        result = {}
        try:
            url = self.hub_api
            if not update_with_vid:
                url += 'contacts/v1/contact/createOrUpdate/email/{0}/?hapikey={1}'
                url = url.format(props['email'], self.api_key)
            else:
                url += 'contacts/v1/contact/vid/{0}/profile?hapikey={1}'
                url = url.format(update_with_vid, self.api_key)

            properties = []
            for key, val in list(props.items()):
                properties.append({
                    'property': key,
                    'value': props[key]
                })

            req = {
                'properties': properties
            }

            data = ujson.dumps(req)
            request = requests.post(data=data, url=url, headers=self.headers)
            if request.status_code not in [200, 204]:
                result = CMS.get_error_message(request.json())
            elif request and request.text:
                res = ujson.loads(request.text)
                if 'status' in res:
                    result = CMS.get_error_message(request.json())
                elif 'vid' in res:
                    result['contact_id'] = res['vid']
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                create_contact ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - create_contact(-)')
        return result

    def get_contact_hubspot_owner_id(self, reason, country, existing=False, hs_id=None):
        """
        This method is used to get support email from HubDB
        """
        logger.addinfo('@ models - cms - get_contact_hubspot_owner_id(+)')
        try:
            if existing:
                query_params = '&language__like=' + country
                query_params += '&contact_us_Reason__in=' + reason
                data = self.get_table_data(self.contact_us_table, query=query_params)
            else:
                query_params = '&hs_id=' + str(hs_id)
                data = self.get_table_data(self.platform_contact_sub_tbl, query=query_params,
                                           include_id=True)

            if 'status' in data:
                result = ''
            else:
                result = ''
                if len(data) > 0:
                    if 'hubspot_owner_id' in data[0]:
                        result = data[0]['hubspot_owner_id']
                    else:
                        # If there are no results assign contact to Marco
                        # 35516220 - is Marco's HubSpot Owner Id
                        result = 35516220

        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_contact_hubspot_owner_id ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_contact_hubspot_owner_id(-)')
        return result

    def get_contact_translations(self, country):
        logger.addinfo('@ models - cms - get_contact_translations(+)')
        try:
            query_params = '&language__like=' + country
            data = self.get_table_data(self.contact_us_tl_table, query=query_params)

            if 'status' in data:
                result = CMS.get_error_message(data.get('msg'))
            else:
                result = data
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_contact_translations ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_contact_translations(-)')
        return result

    def get_contact_reasons(self, country, project):
        logger.addinfo('@ models - cms - get_contact_reasons(+)')
        try:
            country = CMS.format_country_code(country)
            query_params = '&language__like=' + country
            query_params += '&project=' + project

            data = self.get_table_data(self.platform_contact_us_tbl, query=query_params,
                                       include_id=True)

            if 'status' in data:
                result = CMS.get_error_message(data.get('msg'))
            else:
                sub_reasons = self.get_contact_sub_reasons(country, project)
                result = []
                for i in range(len(data)):
                    values = data[i]
                    if 'translation' in values:
                        translation = values['translation']
                    else:
                        translation = ''
                    result.append({
                        'reason_id': values['rowid'],
                        'reason': values['contact_reason'],
                        'order': values['order'],
                        'translation': translation,
                        'sub_reasons': CMS.get_platform_sub_reason(values['contact_reason'],
                                                                   sub_reasons)
                    })
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_contact_reasons ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_contact_reasons(-)')
        return result

    def get_contact_sub_reasons(self, country, project):
        logger.addinfo('@ models - cms - get_contact_sub_reasons(+)')
        try:
            query_params = '&language__like=' + country
            query_params += '&project=' + project
            data = self.get_table_data(self.platform_contact_sub_tbl, query=query_params,
                                       include_id=True)

            if 'status' in data:
                result = CMS.get_error_message(data.get('msg'))
            else:
                result = []
                for i in range(len(data)):
                    values = data[i]
                    if 'translation' in values:
                        translation = values['translation']
                    else:
                        translation = ''
                    if 'mail_to_cc' in values:
                        mail_to_cc = values['mail_to_cc']
                    else:
                        mail_to_cc = ''
                    result.append({
                        'id': values['rowid'],
                        'reason': values['contact_reason'],
                        'sub_reason': values['contact_sub_reason'],
                        'translation': translation,
                        'support_email': values['support_email'],
                        'mail_to_cc': mail_to_cc,
                        'order': values['order']
                    })
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_contact_sub_reasons ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_contact_sub_reasons(-)')
        return result

    def get_data_from_cache(self, key):
        """
        Return JSON data from database cache
        """
        is_hit = False
        result = {}
        if self.logging:
            logger.addinfo('@ models - cms - get_data_from_cache(+)')
        try:
            self.__acquire()
            query = self.yaml_file['json_cache_query']
            data = self.cursor.execute(query, p_key=key).fetchone()
            if data:
                is_hit = True
                result = ujson.loads(data[0].read())
        except Exception as error:
            if self.logging:
                logger.findaylog('''@ EXCEPTION models - cms -
                    get_data_from_cache ''' + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.__release()
        if self.logging:
            logger.addinfo('@ models - cms - get_data_from_cache(-)')
        return is_hit, result

    def get_existing_contact_reasons(self, country):
        """
        These are existing contact reasons in current Website.
        """
        logger.addinfo('@ models - cms - get_contact_details(+)')
        try:
            query_params = '&language__like=' + country
            data = self.get_table_data(self.contact_us_table, query=query_params)

            if 'status' in data:
                result = CMS.get_error_message(data.get('msg'))
            else:
                translations = self.get_contact_translations(country)
                result = []
                for i in range(len(data)):
                    values = data[i]
                    if 'mail_to_cc' in values:
                        mail_to_cc = values['mail_to_cc']
                    else:
                        mail_to_cc = ''
                    result.append({
                        'name': values['contact_us_reason'],
                        'support_email': values['contact_email'],
                        'mail_to_cc': mail_to_cc,
                        'translation': CMS.get_contact_translation_value(translations,
                                                                         values['contact_us_reason'])
                    })
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_contact_details ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_contact_details(-)')
        return result

    def get_product_range(self, req):
        """
        Get product ranges. At this moment we have only for US & Canada
        """
        logger.addinfo('@ models - cms - get_product_range(+)')
        try:
            country = req.get('country', 'US')
            language = req.get('language', 'EN')
            pet_type = req.get('animal')

            query_params = '&country__in={}&language__in={}'.format(country, language)
            if pet_type:
                query_params += '&pet_type__in={}'.format(pet_type)

            stale_attrs = ['country', 'language']
            result = self.get_table_data(self.product_range_tbl, query=query_params,
                                         stale_attrs=stale_attrs, no_cache=True)

            # iterate through the ranges and get images of all the products
            # in each of the range
            for index, row in enumerate(result):
                # range_id column contains brand_name_new & segment_range_new
                # information from the item master table seperated by colon
                brand, segment = row['range_id'].split(':')
                if not pet_type:
                    pet_type = row['pet_type']

                params = {
                    'brand_name_new': brand,
                    'segment_range_new': segment,
                    'animal': pet_type
                }

                data = self.get_table_data(self.items_table, params=params, no_cache=True)
                images = []
                for item in data:
                    if item.get('card_image_main'):
                        images.append({
                            'item_code': item['item_code'],
                            'image_url': item['card_image_main']
                        })
                result[index]['images'] = images
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_product_range ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_product_range(-)')
        return result

    def get_recipe_filters(self, country, language=None, group_by=True, from_view=False,
                           no_cache=False, pet_type=None):
        if self.logging:
            logger.addinfo('@ models - cms - get_recipe_filters(+)')
        try:
            # check if the country and language are supported
            if country and language:
                countries_map = self.yaml_file['country_language_mapping']
                key = country + '_' + language
                if key not in countries_map:
                    logger.findaylog(
                        'models - get_recipe_filter - Not a valid country/language combination')
                    return {
                        'status': 1,
                        'msg': 'Not a valid country/language combination'
                    }

            query_params = '&country__like=' + country.upper()
            if language:
                query_params += '&language__like=' + language.upper()
            if pet_type:
                query_params += '&pet_type_filter__like=' + pet_type.upper()

            stale_attrs = ['country', 'language_code', 'language',
                           'display_sequence']

            brands = self.get_table_data(self.brand_name_tbl, query=query_params,
                                         stale_attrs=stale_attrs, no_cache=no_cache)
            special_care = self.get_table_data(self.special_care_tbl, query=query_params,
                                               stale_attrs=stale_attrs, no_cache=no_cache)
            food_flavour = self.get_table_data(self.food_flavour_tbl, query=query_params,
                                               stale_attrs=stale_attrs, no_cache=no_cache)
            food_benefits = self.get_table_data(self.food_benefits_tbl, query=query_params,
                                                stale_attrs=stale_attrs, no_cache=no_cache)
            pet_age = self.get_table_data(self.pet_age_tbl, query=query_params,
                                          stale_attrs=stale_attrs, no_cache=no_cache)
            nutrition = self.get_table_data(self.nutrition_tbl, query=query_params,
                                            stale_attrs=stale_attrs, no_cache=no_cache)
            food_type = self.get_table_data(self.food_type_tbl, query=query_params,
                                            stale_attrs=stale_attrs, no_cache=no_cache)
            pet_size = self.get_table_data(self.pet_size_tbl, query=query_params,
                                           stale_attrs=stale_attrs, no_cache=no_cache)
            # for package_type filter we need to send display_sequence in the
            # response so removing display_sequence from stale_attrs
            stale_attrs = stale_attrs[:-1]
            package_type = self.get_table_data(self.package_type_tbl, query=query_params,
                                               stale_attrs=stale_attrs, no_cache=no_cache)

            if group_by:
                # sort package_type data based on the display_sequence
                if 'status' not in package_type:
                    package_type = sorted(package_type,
                                          key=lambda x: x['display_sequence'])

                filters = {
                    'brands': brands,
                    'package_type': package_type,
                    'special_care': special_care,
                    'food_flavour': food_flavour,
                    'food_benefits': food_benefits,
                    'pet_age': pet_age,
                    'nutrition': nutrition,
                    'food_type': food_type,
                    'pet_size': pet_size
                }

                if from_view:
                    labels = self.get_table_data(self.product_labels_tbl,
                                                 query=query_params, no_cache=no_cache)
                    filter_labels = self.yaml_file['filter_labels']
                    if 'status' not in labels and 'status' not in filter_labels:
                        filters.update(
                            self.get_product_page_label(labels, filter_labels,
                                                        'filters')
                        )
            else:
                filters = brands + package_type + special_care + food_flavour
                filters += food_benefits + pet_age + nutrition + food_type
                filters += pet_size
        except Exception as error:
            if self.logging:
                logger.findaylog('''@ EXCEPTION models - cms -
                    get_recipe_filters ''' + str(error))
            raise error
        if self.logging:
            logger.addinfo('@ models - cms - get_recipe_filters(+)')
        return filters

    def find_filters_with_products(self, filters, country, language, pet_type):
        query_params = ''
        req = {'country': country, 'language': language}
        if pet_type:
            query_params += "&animal={}".format(pet_type.upper())

        query_params, result, recipes_data = self.get_products_and_recipes_data(req, query_params,
                                                                                None,
                                                                                False,
                                                                                False)

        new_filters = {key: recipe_filters for key, recipe_filters in list(filters.items())
                       if (isinstance(recipe_filters, list))}
        all_filters = [j for key, recipe_filters in list(
            new_filters.items()) for j in recipe_filters]
        if result and isinstance(result, list):
            for key, recipe_filters in list(new_filters.items()):
                new_recipe_filter = []
                for index, filter_label in enumerate(recipe_filters):
                    request_obj = {'filters': [filter_label['filter_key']],
                                   'language': language}
                    filter_params = self.__parse_filter_params(request_obj)
                    products = self.filter_related_data(all_filters, filter_params,
                                                        copy.deepcopy(result), request_obj,
                                                        recipes_data)
                    filter_label['product_count'] = len(products)
                    if len(products) > 0:
                        new_recipe_filter.append(filter_label)
                filters[key] = new_recipe_filter
        return filters

    def filter_related_data(self, filters, filter_params, result, req, recipes_data):
        """
        fetch products based on the filter that is selected
        """
        advantages_attrs = ['advantage_header', 'advantage_icon',
                            'advantage_show_in_advantages']
        package_filters = self.yaml_file['package_filters']
        language = req.get('language').lower()
        if filter_params.get('brand') == {'brand': 'HFC'}:
            filter_params['brand'] = {'brand': 'HFC,ALTERNATIVE,ALTERNATIVEDRY'}
        if 'filters' in req:
            result = CMS.filter_recipes_data(filter_params, result)
        for i in range(len(result)):
            result[i]['weight'] = result[i].setdefault('weight', '')
            result[i]['card_image_main'] = self.check_image(result[i].get('card_image_main'),
                                                            'card_main')
            result[i]['page_image_main'] = self.check_image(result[i].get('page_image_main'),
                                                            'page_main')
            result[i]['page_image_open'] = self.check_image(result[i].get('page_image_open'),
                                                            'page_open')

            if result[i]['animal'] == 'DOG' and 'pet_ager_kitten' in result[i]:
                # We are storing puppy information in pet_ager_kitten field
                # in HubSpot but if the pet type is DOG we should return
                # pet_ager_puppy in the response instead of pet_ager_kitten
                del result[i]['pet_ager_kitten']
                result[i]['pet_ager_puppy'] = 'Yes'

            for recipe in recipes_data:
                if recipe['item_code'] == result[i]['item_code'] and recipe.get('recipe'):
                    result[i]['recipe'] = recipe['recipe']
                    break

            weight = {pack_type: result[i][pack_type] for pack_type in package_filters
                      if pack_type in result[i]}
            weight['weight'] = result[i]['weight']
            weight['page_image_main'] = result[i].get('page_image_main', '')
            weight['card_image_main'] = result[i].get('card_image_main', '')

            result[i]['weight'] = [weight]
            result[i]['weight'] = self.__get_recipe_weights(filters, result[i])
            result[i]['pet_ages'] = self.__get_recipe_pet_ages(filters, result[i])
            result[i]['advantages'] = self.__get_recipe_advantages(filters, result[i],
                                                                   advantages_attrs)
            # if 'item_display_sequence' is not present for a product set it to null
            if 'item_display_sequence' not in result[i]:
                result[i]['item_display_sequence'] = 99999

        # Sorting the products based on 'item_display_sequence' so that they are
        # displayed based on the same order in Website product pages
        # when different weight variants are present for a single product
        result = sorted(result,
                        key=lambda x: (
                            x['item_display_sequence'] is None, x['item_display_sequence']))

        if req.get('group_by') == 'no':
            return result
        data = self.get_weight_related_products(result, language)

        return data

    def get_weight_related_products(self, result, language):
        # Group weights for similar recipes. Grouping is done based
        # on product brand, animal, food type and recipe name
        data = []
        compare_attrs = ['brand_name_new', 'animal', 'food_type', 'recipe',
                         'segment_range_new']
        for index, row in enumerate(result):
            try:
                # check if the row already exists in data if exists find the index
                row_index = CMS.find_index(compare_attrs, data, row)
                weights = data[row_index]['weight']
                row_weights = row['weight']
                if len(row_weights) > 0:
                    weights_found = list([weight for weight in weights if weight['weight'] == row_weights[0]['weight'] and weight[
                        'weight_uom'] == row_weights[0]['weight_uom']])
                    if len(weights_found) == 0:
                        data[row_index]['weight'].append(row_weights[0])
            except ValueError:
                data.append(row)
        for i in range(len(data)):
            data[i]['weight'] = CMS.sort_recipe_weights(data[i]['weight'])
            constituents = data[i].get('analytical_constituents', [])
            data[i]['analytical_constituents'] = self.sort_analytical_constituents(language,
                                                                                   constituents)
        return data

    def get_products_and_recipes_data(self, req, query_params, stale_attrs, include_id, no_cache=False):
        country = req.get('country', '')
        language = req.get('language', '')
        if not country:
            country = language.split('_')[0]
            language = self.yaml_file['language_mapping'][language]
        lang_country = '{}_{}'.format(country, language)

        table_id = CMS.get_recipe_table_id(country, language)
        if not no_cache:
            query_params += '&item_active_flag=Yes'
        if country == 'GB':
            query_params += '&country_uk=Yes'
        else:
            query_params += '&country_' + country.lower() + '=Yes'
        products = self.get_table_data(self.items_table, query=query_params,
                                       stale_attrs=stale_attrs, include_id=include_id,
                                       no_cache=no_cache)

        # get recipe data based on the language and country
        if not self.recipes_data.get(lang_country):
            self.recipes_data[lang_country] = self.get_table_data(
                table_id, no_cache=no_cache)
        recipes_data = self.recipes_data.get(lang_country)

        return query_params, products, recipes_data

    def get_recipes(self, req, include_stale_attrs=False, include_id=False):
        """
        This method is used to return all recipes or the data of a single recipe
        or the meta data for a single recipe.

        Args:
            req (dict): contains all query params as key, value pairs

            include_stale_attrs (bool): if `True` then the response will include all
            the attributes that are there for the recipe

            include_id (bool): if `True` then the response will include HubSpot
            rowid in the response
        """
        if self.logging:
            logger.addinfo('@ models - cms - get_recipes(+)')
        filter_params = {}
        try:
            country = req.get('country', '')
            language = req.get('language', '')
            no_cache = req.get('no_cache', False)
            if 'no_cache' in req:
                del req['no_cache']

            # the below code is added only to have backward compatibility with the
            # already existing API and will be deprecated
            if not country:
                country = language.split('_')[0]
                language = self.yaml_file['language_mapping'][language]
                req['country'] = country
                req['language'] = language
            lang_country = '{}_{}'.format(country, language)

            table_id = CMS.get_recipe_table_id(country, language)

            # Valid parameters list
            valid_params = self.yaml_file['recipe_possible_params']

            # Parameters to ignore for validating
            ignore_params = self.yaml_file['recipe_ignore_params']

            param_error = ''
            query_params = ''

            for key, value in list(req.items()):
                if key not in valid_params:
                    param_error = 'Unsupported parameter ' + key
                    break
                else:
                    if key == 'filters':
                        filter_params = self.__parse_filter_params(req)
                    else:
                        if key not in ignore_params:
                            query_params += '&' + key + '=' + value
            if param_error:
                error = CMS.get_error_message(param_error)
                error['msg'] += ' ' + param_error
                return error

            stale_attrs = None
            if not include_stale_attrs:
                stale_attrs = self.yaml_file['recipe_stale_attributes']

            query_params, result, recipes_data = self.get_products_and_recipes_data(req,
                                                                                    query_params,
                                                                                    stale_attrs,
                                                                                    include_id,
                                                                                    no_cache)

            # get filters data based on the country and language
            if not self.filter_data.get(lang_country):
                self.filter_data[lang_country] = self.get_recipe_filters(
                    country, language, group_by=False, no_cache=no_cache)
            filters = self.filter_data.get(lang_country)

            advantages_attrs = ['advantage_header', 'advantage_icon',
                                'advantage_show_in_advantages']
            package_filters = self.yaml_file['package_filters']

            if result and 'status' not in result and isinstance(result, list):
                if 'meta_data' in req and 'item_code' in req and req['meta_data'] == 'Y':
                    query_params = '&language__like=' + language
                    labels = self.get_table_data(self.product_labels_tbl, query=query_params)
                    meta_labels = self.yaml_file['meta_data_labels']
                    meta_data = CMS.get_product_page_label(labels, meta_labels,
                                                           label_group='meta_data')

                    result[0]['weight'] = result[0].get('weight', '')
                    weight = {'weight': result[0]['weight']}
                    result[0]['card_image_main'] = self.check_image(
                        result[0].get('card_image_main'), 'card_main')
                    result[0]['page_image_main'] = self.check_image(
                        result[0].get('page_image_main'), 'page_main')
                    result[0]['page_image_open'] = self.check_image(
                        result[0].get('page_image_open'), 'page_open')
                    for pack_type in package_filters:
                        if pack_type in result[0]:
                            weight[pack_type] = result[0][pack_type]

                    result[0]['weight'] = [weight]
                    result[0]['weight'] = self.__get_recipe_weights(filters, result[0])

                    params = {
                        'item_code': req['item_code']
                    }
                    stale_attrs = ['item_code']
                    data = self.get_table_data(table_id, params=params, stale_attrs=stale_attrs)

                    recipe = result[0].get('recipe', '')
                    if data and len(data) > 0 and 'recipe' in data[0]:
                        recipe = data[0]['recipe']

                    pack_type = result[0].get('pack', '')
                    animal = result[0].get('animal', '')
                    for key, value in list(meta_data.items()):
                        if pack_type.lower() in key:
                            pack_type = value
                        if animal.lower() in key:
                            animal = value

                    brand_name = result[0].get('brand_name_new', '')
                    segment = result[0].get('segment_range_new', '')
                    image = result[0].get('page_image_main', '')
                    obj = {
                        'recipe': recipe,
                        'brand_name_new': brand_name,
                        'segment_range_new': segment,
                        'pet_type': animal,
                        'package_type': pack_type,
                        'weight': result[0]['weight'][0]['weight'],
                        'weight_uom': result[0]['weight'][0]['weight_uom'],
                        'page_image_main': image
                    }
                    result = obj
                elif 'item_code' in req:
                    query_params = '&language__like=' + language + '&country__like=' + country
                    if not self.label_data.get(lang_country):
                        self.label_data[lang_country] = self.get_table_data(
                            self.product_labels_tbl, query=query_params,
                            no_cache=no_cache)
                    labels = self.label_data.get(lang_country)

                    for i in range(len(result)):
                        # In order to group different weights for the same recipe, the attribute
                        # `recipe` must be present in the result, in order to avoid unnecessary
                        # issues we added a empty recipe as placeholder. This is an edge case
                        result[i]['recipe'] = result[i].setdefault('recipe', '')
                        result[i]['weight'] = result[i].setdefault('weight', '')
                        result[i]['food_reference_name'] = result[i]['food_type']
                        result[i]['card_image_main'] = self.check_image(
                            result[i].get('card_image_main'), 'card_main')
                        result[i]['page_image_main'] = self.check_image(
                            result[i].get('page_image_main'), 'page_main')
                        result[i]['page_image_open'] = self.check_image(
                            result[i].get('page_image_open'), 'page_open')

                        # nutrition related data
                        filter_keys = self.yaml_file['nutrition_filters']
                        nutrition = CMS.get_filter_data(filters, filter_keys)
                        for key in filter_keys:
                            if key in result[i] and result[i][key].lower() == 'yes':
                                result[i].update({
                                    'nutrition_description': nutrition[key]['nutrition_description']
                                })

                        # pet age related data
                        if result[i]['animal'] == 'DOG' and result[i].get('pet_ager_kitten',
                                                                          '') == 'Y':
                            # We are storing puppy information in pet_ager_kitten field
                            # in HubSpot but if the pet type is DOG we should return
                            # pet_ager_puppy in the response instead of pet_ager_kitten
                            del result[i]['pet_ager_kitten']
                            result[i]['pet_ager_puppy'] = 'Yes'
                        result[i]['pet_ages'] = self.__get_recipe_pet_ages(filters, result[i])

                        # advantages related data
                        result[i]['advantages'] = self.__get_recipe_advantages(filters, result[i])

                        # package type related data
                        # packages = CMS.get_filter_data(filters, filter_keys)

                        # add other recipes belonged to the brand
                        segment = result[i].get('segment_range_new', '')
                        params = {
                            'animal': result[i]['animal'],
                            'brand_name_new': result[i]['brand_name_new'],
                            'food_type': result[i]['food_type']
                        }
                        if not no_cache:
                            params['item_active_flag'] = 'Yes'

                        if segment:
                            params['segment_range_new'] = segment

                        if country == 'GB':
                            params['country_uk'] = 'Yes'
                        else:
                            params['country_' + country.lower()] = 'Yes'

                        # check if recipes available for given params
                        param_hash = self.__generate_hash(params)
                        if not self.other_recipe_data.get(param_hash):
                            self.other_recipe_data[param_hash] = self.get_table_data(
                                self.items_table, params=params, stale_attrs=stale_attrs,
                                no_cache=no_cache)

                        recipes = self.other_recipe_data.get(param_hash)
                        if recipes and isinstance(recipes, list):
                            for index in range(len(recipes)):
                                # added empty recipe as a placeholder
                                recipes[index]['recipe'] = recipes[index].setdefault('recipe', '')
                                recipes[index]['weight'] = recipes[index].setdefault('weight', '')
                                recipes[index]['number_of_bags'] = recipes[index].get(
                                    'number_of_bags', '')
                                recipes[index]['number_of_pouches'] = recipes[index].get(
                                    'number_of_pouches', '')

                                for recipe in recipes_data:
                                    if recipe['item_code'] == recipes[index]['item_code']:
                                        if 'recipe' in recipe:
                                            recipes[index]['recipe'] = recipe['recipe']
                                        break
                        include_attrs = ['weight', 'page_image_main', 'card_image_main',
                                         'item_code', 'number_of_bags', 'number_of_pouches']
                        include_attrs += package_filters
                        secondary_attrs = ['item_code']
                        result[i]['recipes'] = CMS.aggregate_data(recipes, 'recipe', 'weight',
                                                                  include_attrs, secondary_attrs)
                        # If related recipes are empty instead of a string get weight in array with
                        # below parameters
                        if len(result[i]['recipes']) == 0:
                            weight = {pack_type: result[i][pack_type] for pack_type in package_filters
                                      if pack_type in result[i]}
                            weight['weight'] = result[i]['weight']
                            weight['page_image_main'] = result[i].get('page_image_main', '')
                            weight['card_image_main'] = result[i].get('card_image_main', '')
                            weight['item_code'] = result[i]['item_code']
                            weight['number_of_bags'] = result[i].get('number_of_bags', '')
                            weight['number_of_pouches'] = result[i].get('number_of_pouches', '')
                            all_weights = {
                                'weight': [weight],
                                'recipe': ''
                            }
                            all_weights = self.__get_recipe_weights(filters, all_weights)
                            result[i]['weight'] = CMS.sort_recipe_weights(all_weights)
                        params = {
                            'item_code': result[i]['item_code']
                        }
                        stale_attrs = ['item_code']

                        # check if recipe data is available for given params and language
                        param_hash = self.__generate_hash(params)
                        param_hash += self.__generate_hash(lang_country)
                        if not self.single_recipe_data.get(param_hash):
                            self.single_recipe_data[param_hash] = self.get_table_data(
                                table_id, params=params, stale_attrs=stale_attrs,
                                include_id=include_id, no_cache=no_cache)

                        data = self.single_recipe_data.get(param_hash)
                        if data and isinstance(data, list):
                            # get recipe related labels
                            recipe_labels = self.yaml_file['recipe_labels']
                            # analytical_constituents is saved as string in HubDB with ujson.dumps
                            # so unpacking the list of objects using ujson.loads
                            constituents = data[0].get('analytical_constituents', '[]')
                            try:
                                if type(constituents) in (str, str):
                                    constituents = ujson.loads(constituents)
                                # replace % sign if any in the constituent values
                                for index in range(len(constituents)):
                                    temp_val = constituents[index]['value']
                                    if type(temp_val) in (str, str):
                                        constituents[index]['value'] = temp_val.replace('%', '')

                                # sort constituents based on a pre-defined order
                                data[0]['analytical_constituents'] = \
                                    self.sort_analytical_constituents(language, constituents)
                            except (ValueError, KeyError, TypeError):
                                data[0]['analytical_constituents'] = []
                            data[0].update(
                                CMS.get_product_page_label(labels, recipe_labels,
                                                           label_group='recipe_info')
                            )
                            if 'rowid' in data[0]:
                                data[0]['recipe_rowid'] = data[0]['rowid']
                                del data[0]['rowid']
                            result[i].update(data[0])

                            # set updated recipe name for the selected product in other related
                            # recipes
                            for k in range(len(result[i]['recipes'])):
                                if result[i]['recipes'][k]['item_code'] == result[i]['item_code']:
                                    result[i]['recipes'][k]['recipe'] = data[0].get('recipe', '')

                        # get all images for the item
                        images = []
                        if not no_cache:
                            param_hash = self.__generate_hash(params)
                            if not self.images_data.get(param_hash):
                                self.images_data[param_hash] = self.get_table_data(
                                    self.item_images_tbl, params=params,
                                    stale_attrs=stale_attrs, no_cache=no_cache)
                            images = self.images_data.get(param_hash)
                        result[i]['images'] = images

                        # add weights to recipe
                        for index, recipe in enumerate(result[i]['recipes']):
                            recipe['weight'] = recipe.setdefault('weight', '')
                            weights = self.__get_recipe_weights(filters, recipe)
                            if recipe['recipe'] == result[i]['recipe']:
                                result[i]['weight'] = CMS.sort_recipe_weights(weights)
                            else:
                                result[i]['recipes'][index]['weight'] = CMS.sort_recipe_weights(
                                    weights)

                        # add slogan data to recipe
                        slogan_labels = self.yaml_file['slogan_labels']
                        result[i].update(
                            CMS.get_product_page_label(labels, slogan_labels, label_group='slogan')
                        )

                        # add profit logo to recipe
                        result[i].update(
                            CMS.get_product_page_label(labels,
                                                       ['profit_logo', 'profit_logo_alt_text'],
                                                       label_group='profit')
                        )

                        # other labels
                        result[i].update(
                            CMS.get_product_page_label(labels, ['other_products_title'],
                                                       label_group='other')
                        )

                        # get brand level info for the product
                        brand_name = ''
                        if 'brand_name_new' in result[i]:
                            brand_name = result[i]['brand_name_new'].upper().replace(' ', '')
                        elif 'brand' in result[i]:
                            brand_name = result[i]['brand'].upper().replace(' ', '')

                        params = {
                            'brand_code': brand_name,
                            'pet_type': result[i]['animal']
                        }
                        query_params = '&language__like=' + language + '&country__like=' + country
                        stale_attrs = ['pet_type', 'language', 'brand_code']

                        # check if the brand data is already available for the given params
                        param_hash = self.__generate_hash(params) + \
                            self.__generate_hash(query_params)
                        if not self.brand_data.get(param_hash):
                            self.brand_data[param_hash] = self.get_table_data(
                                self.brand_name_tbl, query=query_params,
                                params=params, stale_attrs=stale_attrs, no_cache=no_cache)

                        brand = self.brand_data.get(param_hash)
                        if 'status' not in brand and brand:
                            brand_name_new = None
                            if 'brand_name_new' in result[i]:
                                brand_name_new = result[i]['brand_name_new']
                            result[i].update(brand[0])
                            if brand_name_new:
                                result[i]['brand_name_new'] = brand_name_new

                        if not no_cache:
                            # add product reviews to response
                            stale_attrs += ['language']

                            query_params = '&language__like=' + language
                            reviews = self.get_table_data(self.product_reviews_tbl,
                                                          query=query_params,
                                                          params=params, stale_attrs=stale_attrs,
                                                          no_cache=no_cache)
                            if 'status' not in reviews:
                                result[i]['reviews'] = reviews

                        # since related recipes with no recipe ` doesn't add any value
                        # we make the recipes as empty list
                        if result[i]['recipe'] == '':
                            result[i]['recipes'] = []

                        # add related products to response
                        if 'show_related' in req and req['show_related'] == 'Y':
                            query_params = '&item_code__ne=' + str(result[i]['item_code'])
                            stale_attrs = self.yaml_file['recipe_stale_attributes']
                            params = {
                                'animal': result[i]['animal'],
                                'brand': result[i]['brand'],
                                'food_type': result[i]['food_type']
                            }
                            if country == 'GB':
                                params['country_uk'] = 'Yes'
                            else:
                                params['country_' + country.lower()] = 'Yes'
                            if 'family_product' in result[i]:
                                params['family_product'] = result[i]['family_product']

                            related = self.get_table_data(self.items_table, query=query_params,
                                                          params=params, stale_attrs=stale_attrs,
                                                          no_cache=no_cache)
                            if related and isinstance(related, list):
                                for index, row in enumerate(related):
                                    related[index]['weight'] = related[index].setdefault('weight',
                                                                                         '')
                                    for recipe in recipes_data:
                                        if recipe['item_code'] == related[index]['item_code']:
                                            if 'recipe' in recipe:
                                                related[index]['recipe'] = recipe['recipe']
                                            break
                                    weight = {'weight': related[index]['weight']}
                                    for pack_type in package_filters:
                                        if pack_type in row:
                                            weight[pack_type] = row[pack_type]

                                    related[index]['weight'] = [weight]
                                    related[index]['weight'] = self.__get_recipe_weights(
                                        filters, related[index])
                                    related[index]['pet_ages'] = self.__get_recipe_pet_ages(
                                        filters, row)
                                    related[index]['advantages'] = self.__get_recipe_advantages(
                                        filters, row, advantages_attrs)

                                result[i]['other_products'] = related
                else:

                    result = self.filter_related_data(filters, filter_params, result, req,
                                                      recipes_data)

                    # group data by brand
                    if 'group_by' in req and req['group_by'] == 'brand':
                        brands = {data['brand'].lower() if 'brand' in data else 'other' for data in
                                  result}
                        obj = {}
                        for brand in brands:
                            obj[brand] = {
                                'records': []
                            }

                            for row in result:
                                if 'brand' not in row:
                                    row['brand'] = 'other'
                                if row['brand'].lower() == brand:
                                    obj[brand]['records'].append(row)
                            obj[brand]['count'] = len(obj[brand]['records'])
                        result = obj
        except Exception as error:
            if self.logging:
                logger.findaylog('''@ EXCEPTION models - cms -
                    get_recipes ''' + str(error))
            raise error
        if self.logging:
            logger.addinfo('@ models - cms - get_recipes(-)')
        return result

    def get_stores(self, country, store_type):
        logger.addinfo('@ models - cms - get_stores(+)')
        try:
            query_params = '&country=' + country
            if store_type:
                query_params += '&store_type=' + store_type
            else:
                query_params += '&store_type__is_null=true'
            data = self.get_table_data(self.stores_table, query=query_params)

            if 'status' in data:
                result = CMS.get_error_message(data.get('msg'))
            else:
                result = []
                for i in range(len(data)):
                    values = data[i]
                    result.append({
                        'name': values['store_name'],
                        'url': values['store_url'],
                        'icon': values['store_image']
                    })
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_stores ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_stores(-)')
        return result

    def get_response(self, request):
        result = {}
        response = self.session.get(request)
        if response and response.status_code == 200:
            try:
                result = response.json()
            except ValueError as value_error:
                if response.text:
                    try:
                        result = ujson.loads(response.text)
                    except Exception as error:
                        result['status'] = 1
                        result['msg'] = str(error)
                else:
                    result['status'] = 1
                    result['msg'] = str(value_error)
        else:
            result['status'] = 1
            result['msg'] = ujson.dumps(response.json())
        return result

    @staticmethod
    def parse_table_data(row, stale_attrs):
        if stale_attrs:
            stale_attrs = [p.strip() for p in stale_attrs]
        obj = {}
        for _, key in enumerate(row):
            obj[key] = row[key]
            if isinstance(row[key], dict) and 'type' in row[key]:
                if row[key]['type'] == 'option':
                    obj[key] = row[key].get('name', '')
                elif row[key]['type'] == 'image':
                    obj[key] = row[key].get('url', '')
            elif stale_attrs and key in stale_attrs:
                del obj[key]
        return obj

    def get_table_data(self, table_id, query=None, params=None, stale_attrs=None,
                       include_id=False, no_cache=False):
        """
        Get table data for the given table_id.

        Args:
            table_id (int): HubDB id of the table
            query (str): query parameters as a string (default = None)
            params (dict): query parameters as an object (default = None)
            stale_attrs (list): attributes you don't need in response
            include_id (bool): Indicates whether to include HubDB row id in the response
            no_cache (bool): If `True` we get data directly from HubSpot without hitting
                             API Gateway

        Returns:
            list[dict]: Table data in case of success or (dict) in case of error

        Notes:
            See https://developers.hubspot.com/docs/methods/hubdb/v2/get_table_rows

        """
        time.sleep(0.01)
        result = []
        res = {}
        try:
            if no_cache:
                url = self.hubdb_api + 'tables/{0}/rows?portalId={1}'
            else:
                url = self.api_url + 'table/{0}?portalId={1}'
            if params:
                for key, value in list(params.items()):
                    url += '&' + key + '=' + value
            if query:
                url += query
            res = self.get_response(url.format(table_id, self.hub_id))
            if 'status' in res and res['status'] == 1:
                result = CMS.get_error_message(res.get('msg'))
            else:
                data = res.get('objects', [])
                # load schema only if not already exist
                if not self.table_schemas.get(table_id):
                    self.table_schemas[table_id] = self.get_table_schema(table_id, no_cache)

                columns = self.table_schemas.get(table_id)
                for item in data:
                    row = CMS.map_column_values(item.get('values', {}), columns,
                                                include_empty_attrs=include_id)
                    if include_id:
                        row['rowid'] = item.get('id', '')
                    result.append(CMS.parse_table_data(row, stale_attrs))
        except Exception as error:
            if self.logging:
                logger.findaylog('''@ EXCEPTION models - cms -
                    get_table_data ''' + str(error))
        return result

    def get_table_schema(self, table_id, no_cache=False):
        """
        Get column names & type of a specific table in HubDB.

        Notes:
            See https://developers.hubspot.com/docs/methods/hubdb/v2/get_table

        """
        if self.logging:
            logger.addinfo('@ models - cms - get_table_schema(+)')
        result = []
        try:
            if no_cache:
                url = self.hubdb_api + 'tables/{0}?portalId={1}'
            else:
                url = self.api_url + 'schema/{0}?portalId={1}'
            res = self.get_response(url.format(table_id, self.hub_id))
            if 'status' in res and res['status'] == 1:
                result = CMS.get_error_message(res.get('msg'))
            else:
                columns = res.get('columns', [])
                for column in columns:
                    result.append({
                        'id': str(column['id']),
                        'name': column['name'].lower(),
                        'type': column['type']
                    })
        except Exception as error:
            if self.logging:
                logger.findaylog('''@ EXCEPTION models - cms -
                    get_table_schema ''' + str(error))
        if self.logging:
            logger.addinfo('@ models - cms - get_table_schema(-)')
        return result

    def save_data_in_cache(self, key, data):
        if self.logging:
            logger.addinfo('@ models - cms - save_data_in_cache(+)')
        status = False
        try:
            self.__acquire()
            query = self.yaml_file['insert_json_query']
            self.cursor.setinputsizes(p_json_data=cx_Oracle.BLOB)
            self.cursor.execute(query, p_key=key, p_json_data=ujson.dumps(data))
            if self.cursor.rowcount > 0:
                status = True
        except Exception as error:
            if self.logging:
                logger.findaylog('''@ EXCEPTION models - cms -
                    save_data_in_cache ''' + str(error))
                raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.__release()
        if self.logging:
            logger.addinfo('@ models - cms - save_data_in_cache(-)')
        return status

    def send_contact_details(self, req):
        logger.addinfo('@ models - cms - send_contact_details(+)')
        result = {}
        try:
            is_valid_email = CommonUtils.check_email(req['email'])
            is_valid_support_email = CommonUtils.check_email(req['support_email'])

            if is_valid_email and is_valid_support_email:
                d_reason = req['reason']
                d_sub_reason = req['sub_reason']
                d_subject = req['subject']
                d_message = req['message']

                subject = '[%s - %s] - %s' % (req['country'], d_reason, d_subject)

                email = '''%s<br/><b>Reason:</b> %s<br/>
                    <b>Sub Reason:</b> %s<br/>''' % (req['email'], d_reason, d_sub_reason)

                data = {
                    'sender': {
                        'email': req['email'],
                        'name': req['name']
                    },
                    'subject': subject,
                    'template_id': 391586,
                    'params': [
                        {
                            'key': 'name',
                            'value': req['name']
                        },
                        {
                            'key': 'email',
                            'value': email
                        },
                        {
                            'key': 'message',
                            'value': d_message
                        },
                    ],
                    'to_email': req['support_email']
                }

                if 'mail_to_cc' in req:
                    is_valid_mail_to_cc = CommonUtils.check_email(req['mail_to_cc'])
                    if req['mail_to_cc'] and is_valid_mail_to_cc:
                        data['cc'] = req['mail_to_cc']
                res = CommonUtils.send_mail(data)
                if res != 'SUCCESS':
                    result['status'] = 'ERROR'
                    result['msg'] = 'Failed to send email. Please try again'
                    logger.findaylog('models - send_contact_details - ' + result['msg'])
                else:
                    format_country = CMS.format_country_code(req['country'])
                    privacy = req.get('privacy', [])
                    props = {
                        'email': req['email'],
                        'firstname': req['name'],
                        'hs_persona': 'persona_5',
                        'contact_reason_text': d_reason,
                        'contact_sub_reason_text': d_sub_reason,
                        'message': d_message,
                        'country': format_country,
                        'subject': d_subject
                    }

                    if privacy:
                        props['consent_projects'] = privacy[0].get('consent_projects', '')
                        props['consent_foundation'] = privacy[0].get('consent_foundation', '')

                    owner_id = self.get_contact_hubspot_owner_id(d_sub_reason,
                                                                 format_country,
                                                                 hs_id=req['sub_reason_id'])

                    if owner_id and len(str(owner_id)) > 0:
                        props['hubspot_owner_id'] = owner_id

                    self.create_contact(props)

                    result['status'] = 'OK'
                    result['msg'] = 'Contact email sent successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'User email or support email address is not in the correct format'

        except Exception as error:
            logger.findaylog('''@ EXCEPTION - models - cms -
                send_contact_details ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - send_contact_details(-)')
        return result

    @staticmethod
    def aggregate_data(data, primary_key, aggregator, include_attrs, secondary_attrs=None):
        """
        Aggregate data based on the aggregator with only the attributes mentioned in include_attrs.

        Args:
            data (list): array of objects
            primary_key (str): primary attribute in the data
            aggregator (str): string key
            include_attrs (list): array of keys that needs to be included in the return array of
                                  objects
            secondary_attrs (list): secondary attribute to be included in the data

        Returns:
            list[dict]: Returns aggregated data

        """
        result = []
        # building the result as list of dicts with attribute primary_key, aggregator
        # and attributes from secondary_attrs
        for row in data:
            key_exists = False
            # if the primary key not in the current item skip and
            # continue to next item
            if primary_key not in row:
                continue
            for res in result:
                # check if the primary_key is already added to the result
                if primary_key in res and primary_key in row:
                    if res[primary_key] == row[primary_key]:
                        key_exists = True

            # if primary_key not exists in the result and add it to result
            if not key_exists and primary_key in row:
                obj = {
                    primary_key: row[primary_key],
                    aggregator: []
                }
                if secondary_attrs:
                    for attr in secondary_attrs:
                        if attr in row:
                            obj.update({attr: row[attr]})
                result.append(obj)
        for row in data:
            if primary_key not in row:
                continue
            for res in result:
                if primary_key not in res:
                    continue
                if row[primary_key] == res[primary_key]:
                    value_exists = False
                    # check if all the include_attrs were present in the
                    # aggregator list
                    for value in res[aggregator]:
                        for attr in include_attrs:
                            if attr in value and row[aggregator] == value[attr]:
                                value_exists = True
                                break

                    if not value_exists:
                        obj = {}
                        for attr in include_attrs:
                            if attr in row:
                                obj[attr] = row[attr]
                        res[aggregator].append(obj)
        return result

    @staticmethod
    def decode_value(value):
        try:
            if value:
                value = value.encode('utf-8')
        except Exception:
            pass
        return value

    @staticmethod
    def filter_recipes_data(filters, data):
        filtered_data = data
        ignored_items = []
        for sub_filter in enumerate(filters):
            for i in range(len(filtered_data)):
                is_filter_exists = False
                for param, value in list(filters[sub_filter[1]].items()):
                    if param == 'brand':
                        param = 'brand_name_new'
                    if param in filtered_data[i]:
                        values = value.split(',')
                        if filtered_data[i][param].upper().replace(' ', '') in values:
                            is_filter_exists = True
                            break

                if not is_filter_exists and filtered_data[i]['item_code'] not in ignored_items:
                    ignored_items.append(filtered_data[i]['item_code'])

            for i in range(len(ignored_items)):
                for k in range(len(filtered_data)):
                    if filtered_data[k]['item_code'] == ignored_items[i]:
                        del filtered_data[k]
                        break

        return filtered_data

    @staticmethod
    def find_index(attrs, rows, record):
        """
        Search for `record` (dict) in `rows` (list) with attributes in `attrs` (list)
        and return the index of the records in rows
        """
        for index, row in enumerate(rows):
            is_exists = True
            for attr in attrs:
                if attr not in row and attr not in record:
                    continue

                if attr in row and attr in record:
                    if row[attr] != record[attr]:
                        is_exists = False
                        break
                else:
                    is_exists = False
                    break

            if is_exists:
                return index
        raise ValueError

    @staticmethod
    def format_country_code(country):
        country = country.upper()
        if country == 'EN_GB':
            return 'GB'
        elif country == 'EN_CA':
            return 'CA'
        elif country == 'EN':
            return 'US'
        elif country == 'FR_BE':
            return 'BE_FR'
        elif country == 'NL_BE':
            return 'BE_NL'
        return country

    @staticmethod
    def get_contact_translation_value(translations, value):
        logger.addinfo('@ models - cms - get_contact_translation_value(+)')
        result = ''
        if 'status' in translations:
            result = ''
        else:
            for i in range(len(translations)):
                if value == translations[i]['contact_us_reason']:
                    result = translations[i]['reason_description']
                    break
        logger.addinfo('@ models - cms - get_contact_translation_value(-)')
        return result

    @staticmethod
    def get_error_message(error_msg):
        logger.findaylog('models - CMS - {}'.format(error_msg or 'unable to process the request'))
        return {
            'status': 'ERROR',
            'msg': '{}'.format(error_msg or 'Unable to process the request')
        }

    @staticmethod
    def get_filter_data(filters, filter_keys):
        result = {}
        try:
            for row in filters:
                for key in filter_keys:
                    if 'filter_key' in row and key == row['filter_key']:
                        result.update({
                            key: row
                        })
                        break
        except Exception as error:
            raise error
        return result

    @staticmethod
    def get_platform_sub_reason(name, sub_reasons):
        name = name.upper()
        result = []

        for i in range(len(sub_reasons)):
            if name == sub_reasons[i]['reason'].upper():
                result.append({
                    'sub_reason_id': sub_reasons[i]['id'],
                    'sub_reason': sub_reasons[i]['sub_reason'],
                    'translation': sub_reasons[i]['translation'],
                    'support_email': sub_reasons[i]['support_email'],
                    'mail_to_cc': sub_reasons[i]['mail_to_cc'],
                    'order': sub_reasons[i]['order']
                })

        return result

    @staticmethod
    def get_product_page_label(data, label_keys, label_group):
        """
        Get product page label

        Args:
            data (list): List of objects
            label_keys (list): List of label keys for which you need translated labels
            label_group (str): Label Group

        Returns:
            label (str): Returns label that matches label_key & label_group
        """
        labels = {}
        try:
            for row in data:
                for key in label_keys:
                    if (key == row['label_key'] and
                            label_group == row['label_group']):
                        labels[key] = row['label_translation'] or row['label']
        except Exception as error:
            raise error
        return labels

    @staticmethod
    def get_recipe_table_id(country, language):
        """
        get recipe table id based on the country and language
        """
        try:
            return {
                'GB_EN': os.environ['CMS_ITEM_RECIPES_UK'],
                'IT_IT': os.environ['CMS_ITEM_RECIPES_IT'],
                'DE_DE': os.environ['CMS_ITEM_RECIPES_DE'],
                'FR_FR': os.environ['CMS_ITEM_RECIPES_FR'],
                'NL_NL': os.environ['CMS_ITEM_RECIPES_NL'],
                'US_EN': os.environ['CMS_ITEM_RECIPES_US'],
                'ES_ES': os.environ['CMS_ITEM_RECIPES_ES'],
                'SV_SV': os.environ['CMS_ITEM_RECIPES_SV'],
                'FI_FI': os.environ['CMS_ITEM_RECIPES_FI'],
                'CA_EN': os.environ['CMS_ITEM_RECIPES_CA_EN'],
                'CA_FR': os.environ['CMS_ITEM_RECIPES_CA_FR'],
                'CH_FR': os.environ['CMS_ITEM_RECIPES_CH_FR'],
                'CH_DE': os.environ['CMS_ITEM_RECIPES_CH_DE'],
                'CH_IT': os.environ['CMS_ITEM_RECIPES_CH_IT'],
                'BE_FR': os.environ['CMS_ITEM_RECIPES_BE_FR'],
                'BE_NL': os.environ['CMS_ITEM_RECIPES_BE_NL']
            }[country + '_' + language]
        except KeyError:
            raise KeyError('Invalid country and language combination')

    @staticmethod
    def map_column_values(row, columns, include_empty_attrs=False):
        obj = {}
        try:
            for column in columns:
                if column['id'] in row:
                    obj[column['name']] = row[column['id']]
                elif include_empty_attrs:
                    obj[column['name']] = ''
        except Exception as error:
            raise error
        return obj

    @staticmethod
    def sort_recipe_weights(weights):
        for i, weight in enumerate(weights):
            if 'weight' in weight:
                if 'weight_uom' in weight and weight['weight_uom'].lower() == 'kg':
                    weights[i]['weight_grams'] = weight['weight'] * 1000
                else:
                    weights[i]['weight_grams'] = weight['weight']
            else:
                weights[i]['weight'] = ''
                weights[i]['weight_grams'] = 0

        for i, weight_one in enumerate(weights):
            for j, weight_two in enumerate(weights):
                if int(weight_one['weight_grams']) < int(weight_two['weight_grams']):
                    weights[i], weights[j] = weights[j], weights[i]

        for i, weight in enumerate(weights):
            if 'weight_grams' in weight:
                del weights[i]['weight_grams']

        return weights

    def get_persona_lov(self):
        """
        Get Persona Lov details from HubSpot
        """
        logger.addinfo('@ models - cms - get_persona_lov(+)')
        try:
            url = self.hub_api + 'properties/v1/contacts/properties/'
            url += 'named/hs_persona?hapikey={0}'
            url = url.format(self.api_key)
            request = requests.get(url=url)
            res = ujson.loads(request.text)
            if 'status' in res:
                result = CMS.get_error_message(request.json())
            else:
                result = res
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                        get_persona_lov ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_persona_lov(-)')
        return result

    def check_contact_details(self, contact_address):
        """
        Check if the contact id exists in hubspot or not

        """
        logger.addinfo('@ models - cms - check_contact_details(+)')
        try:
            url = self.hub_api + 'contacts/v1/contact/email/'
            url += contact_address + '/profile?hapikey={0}'
            url = url.format(self.api_key)
            request = requests.get(url=url)
            res = ujson.loads(request.text)
            if 'status' in res:
                result = CMS.get_error_message(request.json())
            else:
                result = {'status': 'SUCCESS', 'details': res}
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                        check_contact_details ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - check_contact_details(-)')
        return result

    def get_labels_and_filters(self, languages):
        """
        Get table ids, filters and recipes data based on language and country
        :param languages: language list
        :return:
        """
        if self.logging:
            logger.addinfo('@ models - cms - get_labels_and_filters(+)')
        try:
            table_ids = {}
            filters_data = {}
            recipes_data = {}
            labels_data = {}
            for language in languages:
                if language == 'UK':
                    language = 'GB'
                country = language
                lang = self.yaml_file['language_mapping'][language]
                table_id = CMS.get_recipe_table_id(country, lang)
                table_ids[language] = table_id
                # get filters data based on the country and language
                filters = self.get_recipe_filters(country, lang, group_by=False,
                                                  no_cache=True)
                filters_data[language] = filters

                # get recipe data based on the language and country
                recipes = self.get_table_data(table_id, no_cache=True)
                recipes_data[language] = recipes

                query_params = '&language__like=' + lang + '&country__like=' + country
                labels = self.get_table_data(self.product_labels_tbl, query=query_params,
                                             no_cache=True)
                labels_data[language] = labels
            result = {'table_ids': table_ids, 'recipes_data': recipes_data,
                      'filters_data': filters_data, 'labels': labels_data}
        except Exception as e:
            if self.logging:
                logger.findaylog('''@ EXCEPTION models - cms -
                    get_labels_and_filters ''' + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - cms - get_labels_and_filters(+)')
        return result

    def get_labels_display_logic(self, table_name, query_locator, no_cache, attempts):
        data = self.get_table_data(table_name, query=query_locator, no_cache=no_cache)
        if 'status' in data and attempts < 5:
            time.sleep(0.1)
            attempts += 1
            self.get_labels_display_logic(table_name, query_locator, no_cache, attempts)
        else:
            return data

    def get_storelocator_labels(self, country, language, locator_key, campaign=None):
        """
        Get labels, translations, store types, api url, brands and
        display logic data based on language and country
        :param country: Country Code
        :param language: Language Code
        :param locator_key: Store Locator Key
        :param campaign: Campaign Name (optional)
        :return: JSON object with labels, display_logic, store_types, api_url & brands
        """
        logger.addinfo('@ models - cms - get_storelocator_labels(+)')
        try:
            # brands are not required for Association Locator
            brands = False

            # build query based on language and country
            query_locator = '&language_code__like={0}&country_code__like={1}&locator_key__like={2}'
            query_locator = query_locator.format(language, country, locator_key)

            # get labels based on the language and country
            labels = self.get_labels_display_logic(self.store_locator_label_tbl, query_locator,
                                                   True, 0)

            if campaign:
                # when optional field campaign is passed, get specific data for related campaign
                query_locator += '&campaign__like=' + campaign
            else:
                query_locator += '&campaign__is_null'

            # get display logic based on the language and country
            display_logic = self.get_labels_display_logic(self.store_locator_display_tbl,
                                                          query_locator, True, 0)

            # get brands based on the language and country
            if locator_key != 'association-locator':
                query_brands = '&language_code__like={0}&country_code__like={1}'
                query_brands = query_brands.format(language, country)

                brands = self.get_table_data(self.store_locator_brands_tbl, query=query_brands,
                                             no_cache=True)

            if 'status' in labels or 'status' in display_logic:
                result = CMS.get_error_message()
            else:
                display = CMS.format_display_logic(display_logic, campaign)
                result = {
                    'labels': CMS.format_locator_labels(labels),
                    'display_logic': display,
                    'store_icons': CMS.storelocator_icons(),
                    'api_url': CMS.storelocator_api(locator_key, display)
                }

                if brands and 'status' not in brands and 'show_product_ranges' in display \
                        and display['show_product_ranges'] == 'YES':
                    result['brands'] = CMS.format_brands(brands)

        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_storelocator_labels ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - get_storelocator_labels(-)')
        return result

    @staticmethod
    def format_locator_labels(labels):
        label_groups = {}
        for label in labels:
            if label['label_group'] not in label_groups:
                label_groups[label['label_group']] = {
                    'title': label['label_group_title'],
                    'labels': []
                }
        for key, value in list(label_groups.items()):
            for label in labels:
                if label['label_group'] == key:
                    label_groups[key]['labels'].append({
                        'label': label['label'],
                        'label_key': label['label_key'],
                        'label_translation': label['label_translation']
                    })
        return label_groups

    @staticmethod
    def format_display_logic(display_logic, campaign):
        result = {}
        for display in display_logic:
            if 'online_stores_tab' in display and \
                    'supermarket_stores_tab' in display and \
                    'show_product_ranges' in display:
                result = {
                    'online_stores_tab': display['online_stores_tab'],
                    'supermarket_stores_tab': display['supermarket_stores_tab'],
                    'show_product_ranges': display['show_product_ranges']
                }
                # if campaign, then get selected brand
                if campaign and 'selected_brand' in display:
                    result['selected_brand'] = display['selected_brand']
        return result

    @staticmethod
    def format_brands(brands):
        result = []
        if isinstance(brands, list):
            for brand in brands:
                obj = {
                    'brand_name': brand['brand_name'],
                    'brand_code': brand['brand_code'],
                    'brand_label': brand['brand_label'],
                }
                if isinstance(brand['pet_type'], list) and brand['pet_type']:
                    obj['pet_type'] = brand['pet_type'][0].get('name', '')
                else:
                    obj['pet_type'] = brand['pet_type']
                result.append(obj)
        return result

    @staticmethod
    def storelocator_icons():
        return [
            {
                'url': 'https://cdn.almonature.com/hubfs/storelocator/store-icons/A.svg',
                'name': 'Adopt Me',
                'key': 'A'
            },
            {
                'url': 'https://cdn.almonature.com/hubfs/storelocator/store-icons/C.svg',
                'name': 'Companion Animal For Life',
                'key': 'C'
            },
            {
                'url': 'https://cdn.almonature.com/hubfs/storelocator/store-icons/default.svg',
                'name': 'Sells Almo Nature Products',
                'key': 'Y'
            },
            {
                'url': 'https://cdn.almonature.com/hubfs/storelocator/store-icons/default.svg',
                'name': 'Default',
                'key': 'default'
            }
        ]

    @staticmethod
    def storelocator_api(locator_key, display_logic):
        result = []
        if locator_key != 'association-locator':
            result.append({
                'api_endpoint': '/wordpress/search/',
                'api_type': 'store_search'
            })

            if 'supermarket_stores_tab' in display_logic and \
                    display_logic['supermarket_stores_tab'] == 'YES':
                result.append({
                    'api_endpoint': '/cms/stores/',
                    'api_type': 'supermarkets'
                })

            if 'online_stores_tab' in display_logic and \
                    display_logic['online_stores_tab'] == 'YES':
                result.append({
                    'api_endpoint': '/cms/stores/',
                    'api_type': 'online_stores'
                })
        else:
            result.append({
                'api_endpoint': '/donation/associations/search/',
                'api_type': 'association_search'
            })

        return result

    def sort_analytical_constituents(self, language, constituents):
        result = []
        sorted_constituents = {}
        default_order_constituents = []
        if language and language.lower() in list(self.yaml_file[
                'analytical_constituents_ordering'].keys()):
            # Fetching the relevant ordering of analytical constituents for the language
            constituent_labels = self.yaml_file['analytical_constituents_ordering'][
                language.lower()]
            for constituent in constituents:
                # If the 'constituent' has an order defined, add it to the sorted_constituents
                # with index as the key
                if constituent['title'].lower() in constituent_labels:
                    sorted_constituents[
                        constituent_labels.index(constituent['title'].lower())] = constituent
                else:
                    # If the 'constituent' does not have a defined order,
                    # save it in the order added in Cruscott
                    default_order_constituents.append(constituent)
            # Sorting the constituents based on the index defined previously
            sorted_constituents = [sorted_constituents[i] for i in
                                   sorted(sorted_constituents.keys())]
            result = sorted_constituents + default_order_constituents
        else:
            result = constituents
        return result

    def enroll_into_workflow(self, workflow_id, email):
        """
        Enroll a contact into a HubSpot workflow, to trigger it.

        Notes:
            See https://developers.hubspot.com/docs/methods/workflows/add_contact

        """
        logger.addinfo('@ models - cms - enroll_into_workflow(+)')
        result = {'status': 0}
        try:
            url = self.hub_api + 'automation/v2/workflows/{0}/'
            url += 'enrollments/contacts/{1}?hapikey={2}'
            url = url.format(workflow_id, email, self.api_key)
            request = requests.post(url=url)
            if request and request.text:
                res = ujson.loads(request.text)
                if 'status' in res:
                    result = CMS.get_error_message(request.json())
                    result['status'] = 1
            else:
                result['msg'] = 'Workflow triggered successfully'
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                enroll_into_workflow ''' + str(error))
            raise error
        logger.addinfo('@ models - cms - enroll_into_workflow(-)')
        return result

    def get_contact_lists(self):
        """
        Get all static contact lists from HubSpot

        Notes:
            See https://legacydocs.hubspot.com/docs/methods/lists/get_lists
        """
        data = []
        try:
            url = self.hub_api + 'contacts/v1/lists/static?count=250&hapikey=%s' % self.api_key
            request = requests.get(url=url)
            if request.status_code != 200:
                CMS.get_error_message((request.json()))
                return {'status': 1, 'msg': 'Failed to load contact lists'}

            result = ujson.loads(request.text)
            if 'lists' not in result:
                result = CMS.get_error_message(request.json())
                result['status'] = 1
                return result

            for row in result['lists']:
                data.append({
                    'name': row['name'],
                    'list_id': row['listId'],
                    'internal_list_id': row['internalListId']
                })
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                get_contact_lists ''' + str(error))
        return data

    def add_contact_to_list(self, jsond):
        # get owner id of user from hubspot and add that id as hubspot_owner_id for contact
        if jsond.get('owner_email'):
            owner_id = self.get_contact_owner(jsond['owner_email'])
            if owner_id:
                jsond['props']['hubspot_owner_id'] = owner_id
        result = self.create_contact(jsond['props'])
        if jsond.get('list_id') and result.get('contact_id'):
            result = self.map_contact_to_contactlist(result['contact_id'], jsond['list_id'])
        elif 'status' in result:
            result = {'status': 1, 'msg': 'Failed to create contact'}
        else:
            result = {'status': 0, 'msg': 'Contact created successfully',
                      'contact_id': result['contact_id']}
        return result

    def get_contact_owner(self, owner_email):
        url = self.hub_api + 'owners/v2/owners?hapikey={}'.format(self.api_key)
        result = ''
        request = requests.get(url=url)
        if request.status_code != 200:
            CMS.get_error_message(request.json())
        else:
            contact_owners = ujson.loads(request.text)
            contact_owner = [owner for owner in contact_owners if owner['email'] == owner_email]
            if contact_owner:
                result = contact_owner[0]['ownerId']
        return result

    def map_contact_to_contactlist(self, contact_id, list_id):
        url = self.hub_api + '/contacts/v1/lists/{}/add?hapikey={}'.format(list_id, self.api_key)
        data = {
            "vids": [contact_id]
        }
        request = requests.post(data=ujson.dumps(data), url=url, headers=self.headers)
        if request.status_code != 200:
            result = CMS.get_error_message(request.json())
        else:
            result = {'status': 0, 'msg': 'Contact created and added to list successfully',
                      'contact_id': contact_id}
        return result

    def get_cafl_hw_metrics(self, aggregate='N', org_type=None):
        result = {}
        hubdb_data = self.get_table_data(self.cafl_metrics_table)
        list_of_org_types = list(set(details['org_type'] for details in hubdb_data))
        if org_type:
            result[org_type] = [assoc for assoc in hubdb_data if assoc['org_type'] == org_type]
            if aggregate == 'Y':
                result[org_type] = [CMS.get_aggregate_json(result[org_type])]
        else:
            result = {}
            for org in list_of_org_types:
                result[org] = [assoc for assoc in hubdb_data if assoc['org_type'] == org]
                if aggregate == 'Y':
                    result[org] = [CMS.get_aggregate_json(result[org])]
        return result

    @staticmethod
    def get_aggregate_json(metrics_data):
        aggregate_metrics = {}
        for details in metrics_data:
            for key, value in list(details.items()):
                if not isinstance(value, str):
                    aggregate_metrics[key] = value + aggregate_metrics.get(key, 0)
                else:
                    aggregate_metrics[key] = value
        return aggregate_metrics
