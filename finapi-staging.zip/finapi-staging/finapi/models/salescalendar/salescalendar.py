import cx_Oracle

from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.constants import Status
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('sales_calendar')
class SalesCalendar:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    @staticmethod
    def add_activity(data):
        """
        To insert new Activity details
        :param data: {
                'activity_name':'',
                'start_date':'',
                'end_date':'',
                'goal':'',
                'description':'',
                'communication_request':'',
                'communication_intensity':'',
                'editorial':'',
                'focus_point_id':'',
                'status':'',
                'created_by':''
                }

        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            activity_id = conn.set_output_param('NUMBER')
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.add_activity(
                                :x_activity_id,
                                :p_activity_name,
                                :p_start_date,
                                :p_end_date,
                                :p_goal,
                                :p_description,
                                :p_communication_request,
                                :p_communication_intensity,
                                :p_editorial,
                                :p_focus_point_id,
                                :p_status,
                                :p_created_by,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         x_activity_id=activity_id,
                         p_activity_name=data['activity_name'],
                         p_start_date=data['start_date'],
                         p_end_date=data['end_date'],
                         p_goal=data['goal'],
                         p_description=data['description'],
                         p_communication_request=data['communication_request'],
                         p_communication_intensity=data['communication_intensity'],
                         p_editorial=data['editorial'],
                         p_focus_point_id=data['focus_point_id'],
                         p_status=data['status'],
                         p_created_by=data['created_by']
                         )
            conn.get_output_param()
            activity_id = int(activity_id.getvalue())
            result = {
                'msg': 'Activity added successfully',
                'status': Status.OK.value,
                'activity_id': activity_id
            }
        return result

    @staticmethod
    def add_focus_point(data):
        """
        To insert new focus point details
        :param data: {
                'focus_point_name':'',
                'priority':'',
                'project_id':'',
                'status':'',
                'created_by':''
                }

        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            focus_point_id = conn.set_output_param('NUMBER')
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.add_focus_point(
                                :x_focus_point_id,
                                :p_focus_point_name,
                                :p_priority,
                                :p_project_id,
                                :p_status,
                                :p_created_by,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         x_focus_point_id=focus_point_id,
                         p_focus_point_name=data['focus_point_name'],
                         p_priority=data['priority'],
                         p_project_id=data['project_id'],
                         p_status=data['status'],
                         p_created_by=data['created_by']
                         )
            conn.get_output_param()
            focus_point_id = int(focus_point_id.getvalue())
            result = {
                'msg': 'Focus point added successfully',
                'status': Status.OK.value,
                'focus_point_id': focus_point_id
            }
        return result

    @staticmethod
    def add_project(data):
        """
        To insert new project details
        :param data: {
                'project_name':'',
                'color':'',
                'created_by':''
                }

        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            project_id = conn.set_output_param('NUMBER')
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.add_project(
                                :x_project_id,
                                :p_project_name,
                                :p_color,
                                :p_created_by,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         x_project_id=project_id,
                         p_project_name=data['project_name'],
                         p_color=data['color'],
                         p_created_by=data['created_by']
                         )
            conn.get_output_param()
            project_id = int(project_id.getvalue())
            result = {
                'msg': 'Project added successfully',
                'status': Status.OK.value,
                'project_id': project_id
            }
        return result

    @staticmethod
    def delete_activity(activity_id):
        """
        To delete an Activity
        :param activity_id
        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.delete_activity(
                                :p_activity_id,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         p_activity_id=activity_id
                         )
            conn.get_output_param()
            result = {
                'msg': 'Activity deleted successfully',
                'status': Status.OK.value
            }
        return result

    @staticmethod
    def delete_focus_point(focus_point_id):
        """
        To delete a focus point
        :param focus_point_id
        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.delete_focus_point(
                                :p_focus_point_id,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         p_focus_point_id=focus_point_id
                         )
            conn.get_output_param()
            result = {
                'msg': 'Focus Point deleted successfully',
                'status': Status.OK.value
            }
        return result

    @staticmethod
    def delete_project(project_id):
        """
        To delete a project
        :param project_id
        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.delete_project(
                                :p_project_id,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         p_project_id=project_id
                         )
            conn.get_output_param()
            result = {
                'msg': 'Project deleted successfully',
                'status': Status.OK.value
            }
        return result

    def get_project_list(self, status):
        """
        To get a list of all the projects
        """
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_project_list']
            status = str(status) if status else None
            conn.execute(query, p_status=status)
            result = conn.get_result()
        return result

    def get_activities(self, focus_point_id, status):
        """
        To get a list of all the activities related to a Focus Point
        :param focus_point_id: number
        :param status: string
        """
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_activities']
            conn.execute(query, p_focus_point_id=focus_point_id, p_status=status)
            result = conn.get_result()
        return result

    @staticmethod
    def update_activity(data):
        """
        To upate Activity details
        :param data: {
                'activity_id':'',
                'activity_name':'',
                'start_date':'',
                'end_date':'',
                'goal':'',
                'description':'',
                'communication_request':'',
                'communication_intensity':'',
                'editorial':'',
                'focus_point_id':'',
                'status':'',
                'updated_by':''
                }

        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.update_activity(
                                :p_activity_id,
                                :p_activity_name,
                                :p_start_date,
                                :p_end_date,
                                :p_goal,
                                :p_description,
                                :p_communication_request,
                                :p_communication_intensity,
                                :p_editorial,
                                :p_focus_point_id,
                                :p_status,
                                :p_updated_by,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         p_activity_id=data['activity_id'],
                         p_activity_name=data['activity_name'],
                         p_start_date=data['start_date'],
                         p_end_date=data['end_date'],
                         p_goal=data['goal'],
                         p_description=data['description'],
                         p_communication_request=data['communication_request'],
                         p_communication_intensity=data['communication_intensity'],
                         p_editorial=data['editorial'],
                         p_focus_point_id=data['focus_point_id'],
                         p_status=data['status'],
                         p_updated_by=data['updated_by']
                         )
            conn.get_output_param()
            result = {
                'msg': 'Activity updated successfully',
                'status': Status.OK.value
            }
        return result

    @staticmethod
    def update_focus_point(data):
        """
        To update focus point details
        :param data: {
                'focus_point_id':'',
                'focus_point_name':'',
                'priority':'',
                'project_id':'',
                'status':'',
                'updated_by':''
                }

        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.update_focus_point(
                                :p_focus_point_id,
                                :p_focus_point_name,
                                :p_priority,
                                :p_project_id,
                                :p_status,
                                :p_updated_by,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         p_focus_point_id=data['focus_point_id'],
                         p_focus_point_name=data['focus_point_name'],
                         p_priority=data['priority'],
                         p_project_id=data['project_id'],
                         p_status=data['status'],
                         p_updated_by=data['updated_by']
                         )
            conn.get_output_param()
            result = {
                'msg': 'Focus point updated successfully',
                'status': Status.OK.value
            }
        return result

    @staticmethod
    def update_project(data):
        """
        To update existing project details
        :param data: {
                'project_id':'',
                'project_name':'',
                'color':'',
                'updated_by':''
                }

        :return: json object  {'status':'', 'msg':''}
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                            begin
                                qpex_sales_cal_pkg.update_project(
                                :p_project_id,
                                :p_project_name,
                                :p_color,
                                :p_updated_by,
                                :x_status_code
                                );
                            end;
                            """,
                         output_key='x_status_code',
                         p_project_id=data['project_id'],
                         p_project_name=data['project_name'],
                         p_color=data['color'],
                         p_updated_by=data['updated_by']
                         )
            conn.get_output_param()
            result = {
                'msg': 'Project updated successfully',
                'status': Status.OK.value
            }
        return result

    def get_recent_updated_activities(self, jsond):
        """
            get recent updated activites after last updated date in firebase
        """
        query = self.sql_file['get_activities_based_on_timestamp']
        with OracleConnectionManager() as conn:
            conn.execute(query, p_date=jsond['datetime'], p_user_id=jsond['user_id'])
            results = conn.get_result()
        return {'status': 0, 'results': results}
