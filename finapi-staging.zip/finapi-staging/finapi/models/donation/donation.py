import base64
import io
import tempfile
import json
import os
import random
import re
import string
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime
import ast
import cx_Oracle
import jinja2
import pdfkit
import ujson
import time
from copy import deepcopy
import requests
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from mailjet_rest import Client
from PyPDF2 import PdfFileWriter, PdfFileReader

from finapi.models.aws.cognito.cognito import Cognito
from finapi.models.cms.cms import CMS
from finapi.models.pob.pob import POB
from finapi.models.contacts.contacts import Contacts
from finapi.models.creditNotes.creditNote import CreditNote
from finapi.models.storelocator.storelocator import StoreLocator
from finapi.sql import sql_util
from finapi.utils import auth_util, db_util
from finapi.utils.code_util import Code_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.log_util import LogUtil
from finapi.utils.logdata import logger
from finapi.utils.conn_util import OracleConnectionManager
from finapi.models.payment_method.payment_method import PaymentMethod
from finapi.utils.constants import Status
from finapi.models.workflows.workflows import Workflows


@LogUtil.class_module_logs('donation')
class Donation:

    FAILED_HUBSPOT_UPLOAD = '. Failed to upload coupon file to HubSpot'
    COUPONS_FOLDER = 'coupons/'

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False
        self.mj_api_key = os.environ['MJ_APIKEY_PUBLIC']
        self.mj_api_secret = os.environ['MJ_APIKEY_PRIVATE']
        self.api_key = os.environ['MAP_API_KEY']
        self.sender_email = self.strings['sender_email']
        self.sender_name = self.strings['sender_name']
        self.online_coupons_tbl = os.environ['CMS_COUPONS_ONLINE_STORE']
        self.campaign_coupons_tbl = os.environ['CMS_CAMPAIGN_COUPONS']
        self.token_secret_key = os.environ['SECRET_KEY']

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def get_file_data(self):
        fieldnames = [a[0].lower() for a in self.cursor.description]
        data = []
        for row in self.cursor:
            obj = {}
            for index, fn in enumerate(fieldnames):
                if fn == 'file_data':
                    obj[fn] = row[index].read().decode('utf-8')
                else:
                    obj[fn] = row[index]
            data.append(obj)
        return data

    def check_params(self, req, param):
        result = {}
        keys = ''
        attributes = self.sql_file[param].split(',')

        for i in range(len(attributes)):
            if attributes[i].strip() not in req:
                keys += attributes[i] + ','

        if keys:
            keys = keys[:-1]
            result['status'] = 'ERROR'
            result['msg'] = 'Missing ' + keys
            result['msg'] += ' parameter(s)'
            return False, result
        return True, result

    def register(self, req):
        response = {'status': 'OK', 'msg': ''}
        with OracleConnectionManager() as conn:
            missing_flag, missing_keys = self.check_params(req, 'register_attribute')
            if not missing_flag:
                return missing_keys

            req['country'], req['language'] = get_country_and_language(req.get('country'),
                                                                       req.get('language'))
            # check shop duplicates in organisation table with vat code
            is_org_existed, is_shop_existed, org_id = self.get_vat_code(conn, req)
            """
                if org not exists in database then get
                latitude & longitude and insert into database
            """
            if not is_org_existed:
                lat, lng = self.get_geolocation(req)
                org_id = conn.set_output_param('NUMBER')
                status_code = conn.set_output_param('STRING')
                conn.cursor.setinputsizes(p_shelter_agreement_data=cx_Oracle.BLOB)

                instagram_url = req.get('instagram_url', '')
                social_media = req.get('social_media', '')
                provinces = req.get('provinces', '')
                no_of_dogs = next((d["no_of_pets"] for d in req.get('lines', [])
                                   if d["pet_type"] == 'DOG'), '')
                no_of_cats = next((d["no_of_pets"] for d in req.get('lines', [])
                                   if d["pet_type"] == 'CAT'), '')

                ship_address = get_ship_address(req.get('ship_address', ''))
                supported_activity = req.get('supported_activity')
                if supported_activity and isinstance(supported_activity, dict):
                    supported_activity = ujson.dumps(supported_activity)
                sterilization_adoption_activity = req.get('sterilization_adoption_activity', '')
                conn.execute("""
                    begin
                        qpex_donation_pkg.insert_org(
                            :p_org_id,
                            :P_org_name,
                            :p_org_type,
                            :p_org_unique_code,
                            :p_telephone,
                            :p_address,
                            :p_province,
                            :p_city,
                            :p_zip,
                            :p_country,
                            :p_website_url,
                            :p_facebook_page,
                            :p_instagram_url,
                            :p_recent_updated_user_id,
                            :p_created_by,
                            :p_lat,
                            :p_lng,
                            :p_type,
                            :p_primary_social_media,
                            :p_adoption_provinces,
                            :p_shelter_agreement_data,
                            :p_ship_address,
                            :p_volunteers,
                            :p_operators,
                            :p_adoptions_dog,
                            :p_adoptions_cat,
                            :p_no_of_cats,
                            :p_no_of_dogs,
                            :p_events,
                            :p_events_outside,
                            :p_shelter_type,
                            :p_language,
                            :p_cat_sterilizations,
                            :p_dog_sterilizations,
                            :p_sterilization_adoption_act,
                            :p_shelter_activity,
                            :p_supported_activity,
                            :p_charity_registration_number,
                            :p_status_code
                        );
                    end; """, p_org_id=org_id,
                             p_org_name=req.get('association_name'),
                             p_org_type=req.get('org_type'),
                             p_org_unique_code=req.get('org_unique_code'),
                             p_telephone=req.get('telephone'),
                             p_address=req.get('address'),
                             p_province=req.get('province'),
                             p_city=req.get('city'),
                             p_zip=req.get('zip'),
                             p_country=req.get('country'),
                             p_website_url=req.get('website_url'),
                             p_facebook_page=req.get('facebook_page'),
                             p_instagram_url=instagram_url,
                             p_recent_updated_user_id=-1,
                             p_created_by=-1,
                             p_lat=lat,
                             p_lng=lng,
                             p_type=req.get('receiver'),
                             p_primary_social_media=social_media,
                             p_adoption_provinces=provinces,
                             p_shelter_agreement_data=ujson.dumps(
                                 req.get('shelter_agreement_data')) if req.get(
                                 'shelter_agreement_data')
                             else None,
                             p_ship_address=ship_address,
                             p_volunteers=req.get('volunteers'),
                             p_operators=req.get('operators'),
                             p_adoptions_dog=req.get('adoptions_dog'),
                             p_adoptions_cat=req.get('adoptions_cat'),
                             p_no_of_dogs=no_of_dogs,
                             p_no_of_cats=no_of_cats,
                             p_events=req.get('events'),
                             p_events_outside=req.get('events_outside'),
                             p_shelter_type=req.get('shelter_type'),
                             p_language=req.get('language'),
                             p_cat_sterilizations=req.get('no_of_cat_sterilizations'),
                             p_dog_sterilizations=req.get('no_of_dog_sterilizations'),
                             p_sterilization_adoption_act=sterilization_adoption_activity[:2000],
                             p_shelter_activity=req.get('shelter_activity'),
                             p_supported_activity=supported_activity,
                             p_charity_registration_number=req.get(
                                 'charity_registration_number', ''),
                             p_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    org_id = int(org_id.getvalue())
                    response['status'] = 'OK'
                    response['msg'] = 'Association registered successfully'
                    response['org_id'] = org_id
                    workflow_obj = Workflows()
                    # Get workflow name based on country
                    wf_name = Donation.get_workflow_name(
                        'QPEX_DDESK_LF_', req.get('country'), req.get('language'))

                    # To get list of approvers for the workflow
                    approvers = workflow_obj.get_workflows('', 'Donation Desk', wf_name)

                    # send association registration notification to first approver
                    if approvers:
                        # To get first approver name
                        approvers = sorted(approvers[0]['approvers'],
                                           key=lambda x: x['approver_seq'])
                        recipients = [
                            {
                                'Name': approvers[0]['approver_name'],
                                'Email': approvers[0]['approver_email']
                            }
                        ]
                        commonutils_obj = CommonUtils()
                        # Send notification to users having UI-DONATION-DESK-PROJECT-MANAGER role
                        managers = commonutils_obj.get_users_with_role(
                            'UI-DONATION-DESK-PROJECT-MANAGER')
                        for i in range(len(managers)):
                            recipients.append({
                                'Name': managers[i]['user_name'],
                                'Email': managers[i]['email_address']
                            })
                        Donation.notify_association_registration(recipients, req)
                else:
                    response['status'] = 'ERROR'
                    response['msg'] = status_code.getvalue()
                    logger.findaylog("""donation - models - register - """ + str(response['msg']))

            if response['status'] == 'OK':
                response['org_id'] = org_id
                if not is_shop_existed and org_id:
                    # insert lines in users table
                    req['approval_status'] = 'A'
                    req['org_id'] = org_id
                    user_result = self.insert_user(req)
                    if user_result['status'] != 'OK':
                        response['msg'] = user_result['msg']
                        response['status'] = user_result['status']
                        return response
                    else:
                        update_result = Donation.update_association(req)
                        response['msg'] = update_result['msg']
                        response['user_id'] = user_result['user_id']

                if (not is_org_existed) or (not is_shop_existed and org_id):
                    # upload organization specific documents
                    attachments = req.get('attachments', [])
                    for attachment in attachments:
                        attachment['org_id'] = org_id
                        attachment['created_by'] = org_id
                        self.upload_association_doc(attachment)
            if is_shop_existed and is_org_existed:
                response['msg'] = 'Shop already exists'
                response['status'] = 'OK'
                logger.findaylog("""@ models - donation -
                                register """ + str(response['msg']))
            # create contact for application
            if response['status'] == 'OK':
                Donation.create_association_contact(req)
            if req.get('notify', 'N') == 'N':
                self.create_association_mail(req)
        return response

    def get_vat_code(self, conn, req):
        is_org_existed = False
        is_shop_existed = False
        org_id = None
        query = self.sql_file['get_vat_code']
        conn.execute(query, p_vat_code=req['org_unique_code'])
        vat_codes = conn.get_result(convert_data=False)
        if vat_codes:
            is_org_existed = True
            org_id = vat_codes[0]['org_id']
            if vat_codes[0]['site_id']:
                try:
                    site_ids = vat_codes[0]['site_id'].split(',')
                    index = site_ids.index(str(req['site_id']))
                    if index != -1:
                        is_shop_existed = True
                except ValueError:
                    is_shop_existed = False
        return is_org_existed, is_shop_existed, org_id

    def org_is_shop(self, conn, req):
        # get salesrep_id for given site_id
        query = self.sql_file['get_salesresp_id']
        conn.execute(query, p_shop_id=req.get('site_id'))
        salesrep_ids = conn.get_result(convert_data=False)
        if len(salesrep_ids) > 0:
            # get agent email from salesrep_id
            reference_val = salesrep_ids[0]['primary_salesrep_id']
            query = self.sql_file['get_agent_email']
            conn.execute(query, p_reference_value=str(reference_val))
            agents = conn.get_result(convert_data=False)
            if len(agents) > 0 and agents[0]['email_address']:
                email = agents[0]['email_address']
                user_name = agents[0]['user_name']
                self.send_email(email, user_name)

    def get_geolocation(self, req):
        geocode_url = self.sql_file['geocode_url']
        formatted_address = ''
        if req.get('address'):
            formatted_address += req['address']
        if req.get('city'):
            formatted_address += ',' + req['city']
        if req.get('country'):
            formatted_address += ',' + req['country']
        if req.get('zip'):
            formatted_address += ',' + str(req['zip'])
        end_point = geocode_url
        if formatted_address:
            end_point += "&address=" + urllib.parse.quote(formatted_address)
        end_point += "&key=" + self.api_key
        result = urllib.request.urlopen(end_point).read().decode('utf-8')
        result = result.replace('\n', '')
        result = ujson.loads(result)
        lat = ''
        lng = ''
        if result['status'] == 'OK':
            results = result['results'][0]
            lat = results['geometry']['location']['lat']
            lng = results['geometry']['location']['lng']
        return lat, lng

    def insert_user(self, data):
        result = dict()
        with OracleConnectionManager() as conn:
            user_id = conn.set_output_param('NUMBER')
            if 'password' in data:
                password = data['password']
            else:
                password = CommonUtils.generate_random_string(8)
            passwd_hash = auth_util.encrypt_legacy(password)
            country, language = get_country_and_language(data.get('country'),
                                                         data.get('language'))
            if not language:
                language = data.get('ui_language')
            conn.execute("""
            begin
                qpex_donation_pkg.insert_user(
                    :p_user_id,
                    :p_org_id,
                    :p_first_name,
                    :p_last_name,
                    :p_user_name,
                    :p_additional_info_1,
                    :p_encrypted_passwd,
                    :p_user_email,
                    :p_user_telephone,
                    :p_address,
                    :p_cust_acct_site_id,
                    :p_approval_status,
                    :p_ui_language,
                    :p_recent_updated_user_id,
                    :p_status_code
                );
            end; """, output_key='p_status_code',
                         p_user_id=user_id,
                         p_org_id=data.get('org_id'),
                         p_first_name=data.get('first_name'),
                         p_last_name=data.get('last_name'),
                         p_user_name=data.get('user_name'),
                         p_additional_info_1=password,
                         p_encrypted_passwd=passwd_hash,
                         p_user_email=data.get('user_email'),
                         p_user_telephone=data.get('user_telephone'),
                         p_address=data.get('address'),
                         p_cust_acct_site_id=data.get('site_id'),
                         p_approval_status=data.get('approval_status') or 'A',
                         p_ui_language=language,
                         p_recent_updated_user_id=-1)
            status = conn.get_output_param(raise_exception=False)
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'User created successfully'
                result['user_id'] = user_id.getvalue()
                result['resend_flag'] = False
                # Create user account in Cognito
                req = {
                    'role': ['donation-desk'],
                    'assoc_id': data.get('org_id'),
                    'name': data.get('first_name'),
                    'username': data.get('user_email'),
                    'language': language
                }
                try:
                    req['notify'] = data.get('notify', 'N')
                    obj = Cognito()
                    obj.register(req)
                    result['resend_flag'] = True
                except Exception as error:
                    result['msg'] = """User details saved but failed to create user account -
                                    {0}""".format(error)
                    logger.findaylog("""@ models - donation -
                                     insert_user - """ + str(result['msg']))
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to create user - ' + str(status)
                result['resend_flag'] = False
                result['user_id'] = -1
        return result

    def shop_search(self, vat_code):
        logger.addinfo('@ models - donation - shop_search(+)')
        response = {'status': '', 'result': ''}
        try:
            self.acquire()
            query = self.sql_file['shop_search']
            self.cursor.execute(query, p_vat_code=vat_code)
            result = Code_util.iterate_data(self.cursor, convert_data=False)
            response['status'] = 'OK'
            response['result'] = result
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - donation -
                             shop_search """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - shop_search(-)')
        return response

    def login(self, jsond):
        logger.addinfo('@ models - donation - login(+)')
        response = {'status': '', 'result': ''}
        try:
            self.acquire()
            missing_keys = ''
            attribute_names = ['user_name', 'password']
            for i in range(len(attribute_names)):
                if attribute_names[i] not in jsond:
                    missing_keys += attribute_names[i] + ','

            if missing_keys:
                missing_keys = missing_keys[:-1]
                response = dict()
                response['status'] = 'ERROR'
                response['msg'] = 'Missing ' + missing_keys
                response['msg'] += ' parameter(s)'
            else:
                query = self.sql_file['login']
                user_name = jsond['user_name'].lower().strip()
                password = auth_util.encrypt_legacy(jsond['password'])
                self.cursor.execute(query, p_user_name=user_name,
                                    p_password=password)
                result = Code_util.iterate_data(self.cursor, convert_data=False)
                if len(result) == 0:
                    response['status'] = 'Invalid login credentials'
                    logger.findaylog("""@ models - donation -
                                    login """ + str(response['status']))
                else:
                    response['status'] = 'OK'
                    response['result'] = result
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                login """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - login(-)')
        return response

    def get_users_data(self, status, org_type, req):
        logger.addinfo('@ models - donation - get_users_data(+)')
        response = {'status': '', 'result': ''}
        try:
            self.acquire()
            if status or org_type:
                # To get users with given status or type
                query = self.sql_file['users_by_status_type']
                self.cursor.execute(query, p_approval_status=status,
                                    p_org_type=org_type)
            else:
                # To get all users
                query = self.sql_file['get_users_data']
                self.cursor.execute(query, p_org_type=req.get('org_type'),
                                    p_filter_status=req['status'],
                                    p_adopt_me=req['adopt_me'],
                                    p_almo_org_id=req.get('almo_org_id'))
            result = Code_util.iterate_data(self.cursor, convert_data=False)
            response['status'] = 'OK'
            response['result'] = result
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_users_data """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - get_users_data(-)')
        return response

    # Update shop approval_status in users table
    def update_status(self, user_id, status):
        logger.addinfo('@ models - donation - update_status(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.update_status(
                    :p_user_id,
                    :p_approval_status,
                    :p_status_code
                );
            end; """, p_user_id=user_id,
                                p_approval_status=status,
                                p_status_code=status_code)
            status = status_code.getvalue()
            if status != 'SUCCESS':
                logger.findaylog("""@ models - donation -
                                update_status - {}""".format(status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                update_status """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - donation - update_status(-)')
        return status

    def save_application(self, req_data):
        application_no = None
        request_id = None
        with OracleConnectionManager() as conn:
            # get count of no. of applications submitted by association
            query = self.sql_file['assoc_application_count_query']
            conn.execute(query, p_org_id=req_data['org_id'])
            data = conn.get_single_result(convert_data=False)
            count = data['count(1)']
        Donation.create_association_contact(req_data)

        """
        if the application count is > 0 then create only love food application,
        otherwise create 2 application 1 for love food and 1 for adopt me
        """
        template_id = 823641
        req_data['country'], req_data['language'] = get_country_and_language(req_data.get(
            'country'), req_data.get('language'))
        language = req_data['language'].upper()
        if language == 'IT':
            template_id = 838774
        elif language == 'FR':
            template_id = 838789
        elif language == 'NL':
            template_id = 838782
        elif language == 'DE':
            template_id = 838780
        appl_source = req_data.get('appl_source', 'CRUSCOTT')
        # create only adopt me applications if created from website otherwise
        # use the request_type from the request data
        req_data['request_type'] = 'A' if appl_source != 'CRUSCOTT' else req_data.get(
            'request_type', 'A')
        req_data['mail_template_id'] = template_id
        result = self.insert_request_header(req_data)
        if result['status'] == 'OK':
            request_id = result['request_id']
            application_no = result['application_no']

        if result['status'] == 'OK':
            result['msg'] = 'Application saved successfully'
            req_data['request_id'] = request_id
            req_data['application_no'] = application_no
            req_data['appl_count'] = count
            self.prepare_notification(req_data)
        return result

    @staticmethod
    def email_template_selection(req_data):
        if req_data.get('language') and req_data.get('country') != req_data.get('language'):
            country = '_'.join([req_data.get('country'),
                                req_data.get('language')]).upper()
        else:
            country = req_data.get('country').upper()
        return country

    @staticmethod
    def create_association_contact(data):
        logger.addinfo('@ models - donation - create_association_contact(+)')
        try:
            if not data.get('user_email'):
                return
            persona = ''
            cat_assoc = False
            dog_assoc = False

            lines = data.get('lines', [])
            for line in lines:
                if line['pet_type'] == 'DOG':
                    dog_assoc = True
                elif line['pet_type'] == 'CAT':
                    cat_assoc = True

            if data.get('assoc_type') == 'MUNICIPALITY':
                persona = 'persona_4'
            if data.get('org_type') == 'humansandwildlife':
                persona = 'persona_52'
            else:
                if cat_assoc and dog_assoc:
                    persona = 'persona_3'
                elif dog_assoc:
                    persona = 'persona_2'
                elif cat_assoc:
                    persona = 'persona_1'

            props = {
                'email': data.get('user_email'),
                'firstname': data.get('user_name'),
                'hs_persona': persona,
                'company': data.get('org_name'),
                'address': data.get('address'),
                'city': data.get('city'),
                'state': data.get('province'),
                'zip': data.get('zip'),
                'country': data.get('country')
            }

            cms_obj = CMS()
            cms_obj.create_contact(props)
        except Exception as e:
            logger.findaylog("""Exception while create contact in
                HubSpot """ + str(e))
        logger.addinfo('@ models - donation - create_association_contact(-)')

    @staticmethod
    def log_association_activity(data):
        logger.addinfo('@ models - donation - log_association_activity(+)')
        try:
            cms_obj = CMS()
            cms_obj.contact_log(data)
        except Exception as e:
            logger.findaylog("""Exception while logging association
                activity """ + str(e))
        logger.addinfo('@ models - donation - log_association_activity(-)')

    def prepare_notification(self, req_data, notify_user=True):
        logger.addinfo('@ models - donation - prepare_notification(+)')
        appl_no = req_data['application_no']
        request_type = req_data.get('request_type', 'A')
        params = []
        req_data['template_id'] = 344585
        language = (req_data.get('language') or 'en').lower()
        country = (req_data.get('country') or 'en').lower()
        subject_prefix = self.strings['dd_appl_notify_project'][request_type]
        subject = self.strings['dd_appl_notify_subject'][language]
        req_data['subject'] = '(' + req_data.get('assoc_type') + ') ' + subject + ' from '
        req_data['subject'] = req_data['subject'] + req_data.get('org_name')
        req_data['subject'] += ' #' + appl_no
        req_data['subject'] %= subject_prefix
        req_data['attachments'] = []
        params.append({
            'key': 'mail_template',
            'value': get_application_template(req_data)
        })
        req_data['params'] = params
        approver_id = self.start_lovefood_flow(appl_no, req_data)
        if approver_id:
            name, email = self.get_approver_details(approver_id)
            req_data['to_name'] = name
            req_data['to_email'] = email
            CommonUtils.send_mail(req_data)

        if notify_user:
            params = []
            req_data['subject'] = self.strings['dd_appl_notify_assoc'][language]
            req_data['subject'] %= (subject_prefix)
            # 351639 - old template id
            # 730440 - new template id
            # 783711 - FR template id
            req_data['template_id'] = self.get_application_template_id(req_data)
            req_data['to_name'] = req_data.get('user_name')
            req_data['to_email'] = req_data.get('user_email')
            req_data['sender'] = {
                'email': self.strings['dd_sender_email_' + country],
                'name': self.strings['dd_sender_name_' + country]
            }

            params.append({
                'key': 'country',
                'value': Donation.website_url_link(req_data.get('country', ''), req_data.get('language', ''))
            })
            params.append({
                'key': 'email',
                'value': req_data.get('user_email')
            })
            params.append({
                'key': 'application_no',
                'value': req_data['application_no']
            })
            req_data['params'] = params
            req_data['attachments'] = []
            if req_data['to_email']:
                mail_status = CommonUtils.send_mail(req_data)
                if mail_status != 'SUCCESS':
                    logger.findaylog("""@ models - donation - prepare_notification - Failed  to send
                                      application email""")
                date1 = datetime.strptime('19/12/2020', '%d/%m/%Y').date()
                date2 = datetime.strptime('06/01/2021', '%d/%m/%Y').date()
                req_data['language'] = req_data.get('language', 'EN')
                if date1 <= datetime.now().date() <= date2:
                    self.send_vacation_email(req_data)

            # Log email sent to association in HubSpot
            html_message = 'Your application has been submitted successfully. '
            html_message += 'Your application no. is <b>{0}</b> '
            html_message += 'please note your application number for '
            html_message += 'further reference.'
            html_message = html_message.format(req_data['application_no'])

            props = {
                'type': 'EMAIL',
                'sender': req_data['sender']['email'],
                'email': req_data['to_email'],
                'subject': req_data['subject'],
                'html_message': html_message
            }
            Donation.log_association_activity(props)
        logger.addinfo('@ models - donation - prepare_notification(-)')

    def send_vacation_email(self, req_data):
        """
        Send Almo vacation emails from 19th december to 6th jan to users
        when shelter applications are created
        """
        recipients = [{'Email': req_data['to_email']}]
        template_id = self.sql_file['August_closure_emails'].get(req_data['language'], 'EN')
        template_data = {
            'template_id': template_id,
            'params': [],
            'subject': 'Companion Animal For Life - Important Message (December Closure)',
            'recipients': recipients
        }
        mail_status = CommonUtils.send_mail(template_data)
        if mail_status != 'SUCCESS':
            logger.findaylog("""@ models - donation - send_vacation_email - Failed  to send
                              vacation email""")

    def get_application_template_id(self, req_data):
        request_type = req_data.get('request_type', 'A')
        language = (req_data.get('language') or 'EN').upper()
        if req_data.get('country') == 'CA':
            language = 'CA'
        if 'mail_template_id' in req_data:
            template_id = req_data['mail_template_id']
        else:
            if request_type == 'H':
                template_json = 'human_wildlife_welcome_templates'
            else:
                template_json = 'Adoptme_welcome_templates'

            if self.sql_file[template_json].get(language):
                template_id = self.sql_file[template_json].get(language)
            else:
                template_id = self.sql_file[template_json].get('EN')
        return template_id

    @staticmethod
    def website_url_link(country, language):
        if language and country != language:
            website_link = language.lower() + '_' + country.upper()
        elif country and '_' in country:
            words = country.split('_')
            website_link = words[1].lower() + '_' + words[0].upper()
        else:
            website_link = country.lower()
        return website_link

    def create_association_mail(self, req_data):
        params = []
        if req_data['org_type'] == 'humansandwildlife':
            req_data['request_type'] = 'H'
        subject_prefix = self.strings['dd_appl_notify_project'][req_data.get('request_type', 'A')]
        country = req_data.get('country', '').lower()
        language = req_data.get('language', '').lower()
        if self.sql_file['dd_appl_notify_assoc'].get(language):
            req_data['subject'] = self.sql_file['dd_appl_notify_assoc'][language]
        else:
            req_data['subject'] = self.sql_file['dd_appl_notify_assoc']['en']
        req_data['subject'] %= subject_prefix
        req_data['template_id'] = self.get_application_template_id(req_data)
        req_data['to_name'] = req_data.get('user_name')
        req_data['to_email'] = req_data.get('user_email')
        req_data['sender'] = {
            'email': self.strings['dd_sender_email_' + country],
            'name': self.strings['dd_sender_name_' + country]
        }
        obj = Cognito()
        password = obj.change_user_password({
            'username': req_data.get('user_email')
        })
        params.append({
            'key': 'username',
            'value': req_data.get('user_email')
        })
        params.append({
            'key': 'password',
            'value': password
        })

        params.append({
            'key': 'country',
            'value': Donation.website_url_link(req_data.get('country', ''), req_data.get('language', ''))
        })
        params.append({
            'key': 'email',
            'value': req_data.get('user_email')
        })
        params.append({
            'key': 'application_no',
            'value': req_data.get('application_no')
        })
        req_data['params'] = params
        req_data['attachments'] = []
        status = CommonUtils.send_mail(req_data)
        if status == 'SUCCESS':
            status = 'Mail is sent successfully'
        else:
            logger.findaylog(""" @ models - donation - create_association_mail - Failed to send
            mail to registered association """)
        return status

    def update_organization_details(self, req_data):
        """
        For updating the association related details like events etc in table
        :param req_data:
        :return:
        """
        with OracleConnectionManager() as conn:
            conn.execute("""
                        begin
                            qpex_donation_pkg.update_organization_details(
                                :p_org_id,
                                :p_created_by,
                                :p_ship_address,
                                :p_volunteers,
                                :p_operators,
                                :p_adoptions_dog,
                                :p_adoptions_cat,
                                :p_no_of_cats,
                                :p_no_of_dogs,
                                :p_events,
                                :p_events_outside,
                                :p_shelter_type,
                                :x_status_code
                            );
                        end; """, output_key='x_status_code',
                         p_org_id=req_data.get('org_id'),
                         p_created_by=req_data.get('user_id'),
                         p_ship_address=req_data.get('ship_address'),
                         p_volunteers=req_data.get('volunteers'),
                         p_operators=req_data.get('operators'),
                         p_adoptions_dog=req_data.get('adoptions_dog'),
                         p_adoptions_cat=req_data.get('adoptions_cat'),
                         p_no_of_dogs=req_data.get('no_of_dogs'),
                         p_no_of_cats=req_data.get('no_of_cats'),
                         p_events=req_data.get('events'),
                         p_events_outside=req_data.get('events_outside'),
                         p_shelter_type=req_data.get('shelter_type')
                         )
            status = conn.get_output_param(raise_exception=False)
            if status == 'SUCCESS':
                msg = 'Updated organization'
            else:
                msg = 'Failed to update organization details'
        return msg

    def insert_request_header(self, req_data):
        result = dict()
        with OracleConnectionManager() as conn:
            header_id = conn.set_output_param('NUMBER')
            application_no = conn.set_output_param('STRING')
            random_seq = Donation.get_random_sequence(4)
            req_data['ship_address'] = get_ship_address(req_data.get('ship_address', ''))
            conn.execute("""
            begin
                qpex_donation_pkg.insert_request_header(
                    :x_request_header_id,
                    :p_org_id,
                    :p_random_seq,
                    :p_request_type,
                    :p_created_by,
                    :p_ship_address,
                    :p_contact_name,
                    :p_contact_phone,
                    :p_carrier_note,
                    :p_message,
                    :p_volunteers,
                    :p_operators,
                    :p_adoptions_dog,
                    :p_adoptions_cat,
                    :p_events,
                    :p_events_outside,
                    :p_shelter_type,
                    :p_workflow_name,
                    :p_no_of_partners,
                    :x_application_no,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         x_request_header_id=header_id,
                         p_org_id=req_data.get('org_id'),
                         p_random_seq=random_seq,
                         p_request_type=req_data.get('request_type'),
                         p_created_by=req_data.get('user_id'),
                         p_ship_address=req_data.get('ship_address'),
                         p_contact_name=req_data.get('contact_name', req_data.get('first_name')),
                         p_contact_phone=req_data.get('contact_phone'),
                         p_carrier_note=req_data.get('carrier_note'),
                         p_message=req_data.get('need_desc'),
                         p_volunteers=req_data.get('volunteers'),
                         p_operators=req_data.get('operators'),
                         p_adoptions_dog=req_data.get('adoptions_dog'),
                         p_adoptions_cat=req_data.get('adoptions_cat'),
                         p_events=req_data.get('events'),
                         p_events_outside=req_data.get('events_outside'),
                         p_shelter_type=req_data.get('shelter_type'),
                         p_no_of_partners=req_data.get('no_of_partners'),
                         p_workflow_name=req_data.get('wf_name'),
                         x_application_no=application_no)
            status = conn.get_output_param(raise_exception=False)
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['request_id'] = int(header_id.getvalue())
                result['application_no'] = application_no.getvalue()
                update_result = self.insert_header_related_details(req_data, result)
                if update_result['status'] == 'ERROR':
                    result['msg'] = update_result['msg']
                    result['status'] = update_result['status']
            else:
                result['status'] = 'ERROR'
                result['msg'] = status
        return result

    def insert_header_related_details(self, req_data, result):
        attachments = req_data.get('attachments', [])
        try:
            if req_data.get('request_type') == 'A':
                lines = req_data['adoptme_kits']
            else:
                lines = req_data['lines']
        except KeyError:
            lines = req_data.get('lines', [])

        for line in lines:
            line['header_id'] = result['request_id']
            line['user_id'] = req_data.get('user_id')
            if line['pet_type'] == 'DOG':
                req_data['no_of_dogs'] = line['no_of_pets']
            elif line['pet_type'] == 'CAT':
                req_data['no_of_cats'] = line['no_of_pets']
            line_result = self.insert_request_line(line)
            if line_result['status'] == 'ERROR':
                result['msg'] = line_result['msg']
                result['status'] = line_result['status']

        for attachment in attachments:
            attachment['header_id'] = result['request_id']
            attachment['user_id'] = req_data.get('user_id')
            attachment['update_flag'] = 'N'
            attachment['verified_flag'] = 'N'
            attach_result = self.insert_request_attachment(attachment)
            if attach_result['status'] == 'ERROR':
                result['msg'] = attach_result['msg']
                result['status'] = attach_result['status']

        self.update_organization_details(req_data)
        return result

    def insert_request_line(self, line):
        logger.addinfo('@ models - donation - insert_request_line(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            line_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.insert_request_line(
                    :x_request_line_id,
                    :p_request_header_id,
                    :p_pet_type,
                    :p_pet_size,
                    :p_no_of_pets,
                    :p_no_of_qty,
                    :p_created_by,
                    :x_status_code
                );
            end; """, x_request_line_id=line_id,
                                p_request_header_id=line.get('header_id'),
                                p_pet_type=line.get('pet_type'),
                                p_pet_size=line.get('pet_size'),
                                p_no_of_pets=line.get('no_of_pets'),
                                p_no_of_qty=line.get('no_of_qty'),
                                p_created_by=line.get('user_id'),
                                x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result['status'] = 'OK'
                result['line_id'] = line_id.getvalue()
                result['msg'] = 'Line inserted successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = status_code.getvalue()
                logger.findaylog("""@ models - donation - insert_request_lines - {} """.format(
                    result['msg']))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                insert_request_line """ + str(error))
            raise error
        logger.addinfo('@ models - donation - insert_request_line(-)')
        return result

    def insert_request_attachment(self, attachment):
        logger.addinfo('@ models - donation - insert_request_attachment(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            attachment_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_file_data=cx_Oracle.BLOB)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.insert_request_attachment(
                    :x_atthmt_id,
                    :p_request_header_id,
                    :p_file_name,
                    :p_file_type,
                    :p_file_data,
                    :p_document_type,
                    :p_verified,
                    :p_created_by,
                    :p_update_flag,
                    :x_status_code
                );
            end; """, x_atthmt_id=attachment_id,
                                p_request_header_id=attachment.get('header_id'),
                                p_file_name=attachment.get('file_name'),
                                p_file_type=attachment.get('file_type'),
                                p_file_data=attachment.get('file_data'),
                                p_document_type=attachment.get('document_type'),
                                p_verified=attachment.get('verified_flag'),
                                p_created_by=attachment.get('user_id'),
                                p_update_flag=attachment.get('update_flag'),
                                x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result['status'] = 'OK'
                result['attachment_id'] = attachment_id.getvalue()
                result['msg'] = 'Attachment added successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = status_code.getvalue()
                logger.findaylog("""@ models - donation - insert_request_attachments -
                        {}""".format(result['msg']))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                insert_request_attachment """ + str(error))
            raise error
        finally:
            if local_acquire:
                self.release()
        logger.addinfo('@ models - donation - insert_request_attachment(-)')
        return result

    def get_applications(self, data):
        logger.addinfo('@ models - donation - get_applications(+)')
        result = dict()
        try:
            self.acquire()
            if data['header_id']:
                query = self.sql_file['application_headers_query']
            else:
                query = self.sql_file['application_summary_query']
            if data['status'] == 'O':
                # To get waybill details
                waybill_invoice_query = self.sql_file['waybill_invoice_query']
                waybill_query = ', (' + waybill_invoice_query.format('DISTINCT wnd.delivery_id')
                waybill_query += ') waybill'

                # To get invoice number details
                waybill_query += ', (' + waybill_invoice_query.format('cta.trx_number')
                waybill_query += ') invoice'
                if data['year']:
                    year_cond = "AND to_char(h.created_date, 'YYYY') = '" + str(data['year']) + "'"
                else:
                    year_cond = ''
                query = query.format(waybill=waybill_query,
                                     year_cond=year_cond,
                                     waiting_for='')
            else:
                waiting_query = self.sql_file['waiting_for_query']
                query = query.format(waybill='', year_cond='',
                                     waiting_for=waiting_query)
            if data['header_id']:
                self.cursor.execute(query, p_header_id=data['header_id'],
                                    p_org_id=data['org'], p_assoc_id=data['assoc_id'],
                                    p_status=data['status'])
            else:
                self.cursor.execute(query, p_header_id=data['header_id'],
                                    p_org_id=data['org'], p_assoc_id=data['assoc_id'],
                                    p_status=data['status'], p_request_type=data['request_type'],
                                    p_receipt=data['receipt'],
                                    p_org_type=data.get('org_type'))
            header = Code_util.iterate_data(self.cursor, convert_data=False)
            if data['header_id']:
                query = self.sql_file['application_lines_query']
                self.cursor.execute(query, p_header_id=data['header_id'])
                lines = Code_util.iterate_data(self.cursor, convert_data=False)

                query = self.sql_file['application_attachments_query']
                self.cursor.execute(query, p_header_id=data['header_id'])
                attachments = Code_util.iterate_data(self.cursor, convert_data=False)

                header[0]['lines'] = lines
                header[0]['attachments'] = attachments
                result['result'] = header
                result['status'] = 'OK'
            else:
                for i in range(len(header)):
                    header[i]['shelter_agreement_data'] = Donation.get_shelter_agreement_data(
                        header[i]['shelter_agreement_data'])
                result['status'] = 'OK'
                result['result'] = header
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_applications """ + str(e))
            raise e
        logger.addinfo('@ models - donation - get_applications(-)')
        return result

    def add_address(self, req_data):
        logger.addinfo('@ models - donation - add_address(+)')
        result = dict()
        attribute_names = self.sql_file['address_attributes'].split(',')
        try:
            missing_keys = ''
            for i in range(len(attribute_names)):
                if attribute_names[i].strip() not in req_data:
                    missing_keys += attribute_names[i] + ','

            if missing_keys:
                missing_keys = missing_keys[:-1]
                result['status'] = 'ERROR'
                result['msg'] = 'Missing ' + missing_keys
                result['msg'] += ' parameter(s)'
                return result

            self.acquire()
            msg_data = self.cursor.var(cx_Oracle.STRING)
            return_status = self.cursor.var(cx_Oracle.STRING)
            party_site_id = self.cursor.var(cx_Oracle.NUMBER)
            price_list_id = self.cursor.var(cx_Oracle.NUMBER)
            self.cursor.execute("""
            begin
                qpex_customer_pkg.create_ship_to_address (
                    :p_org_type,
                    :p_project_type,
                    :p_address1,
                    :p_address2,
                    :p_address3,
                    :p_assoc_name,
                    :p_city,
                    :p_postal_town,
                    :p_postal_code,
                    :p_country,
                    :p_org_id,
                    :p_carrier_note,
                    :p_phone_number,
                    :x_msg_data,
                    :x_return_status,
                    :x_party_site_id,
                    :x_price_list_id
                );
                commit;
            end; """, p_org_type=req_data['org_type'],
                                p_project_type=req_data['request_type'],
                                p_address1=req_data['address1'],
                                p_address2=req_data['address2'],
                                p_address3=req_data['address3'],
                                p_assoc_name=req_data['assoc_name'],
                                p_city=req_data['city'],
                                p_postal_town=req_data['town'],
                                p_postal_code=req_data['postal_code'],
                                p_country=req_data['country'],
                                p_org_id=req_data['org_id'],
                                p_carrier_note=req_data['carrier_note'],
                                p_phone_number=req_data['phone_number'],
                                x_msg_data=msg_data,
                                x_return_status=return_status,
                                x_party_site_id=party_site_id,
                                x_price_list_id=price_list_id)
            if return_status.getvalue() == 'S':
                req_data['party_site_id'] = party_site_id.getvalue()
                req_data['price_list_id'] = price_list_id.getvalue()
                result = self.create_quote(req_data)
                if result['status'] != 'OK':
                    msg = result['msg']
                    result['msg'] = 'Address created but '
                    result['msg'] += 'failed to create Quote'
                    result['msg'] += ' - ' + str(msg)
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to add address - '
                result['msg'] += str(return_status.getvalue())
                logger.findaylog("""@ models - donation - add_address - {}""".format(
                    result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                add_address """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - add_address(+)')
        return result

    def create_quote(self, req_data):
        logger.addinfo('@ models - donation - create_quote(+)')
        result = dict()
        try:
            status_code = self.cursor.var(cx_Oracle.STRING)
            quote_header_id = self.cursor.var(cx_Oracle.NUMBER)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.create_quote (
                    :x_quote_header_id,
                    :p_request_id,
                    :p_created_user_id,
                    :p_party_site_id,
                    :p_organization_id,
                    :p_quote_name,
                    :p_dog_meals,
                    :p_cat_meals,
                    :p_carrier_note,
                    :p_price_list_id,
                    :x_status_code
                );
            end; """, x_quote_header_id=quote_header_id,
                                p_request_id=req_data['request_id'],
                                p_created_user_id=req_data['user_id'],
                                p_party_site_id=req_data['party_site_id'],
                                p_organization_id=req_data['org_id'],
                                p_quote_name=req_data['quote_name'],
                                p_dog_meals=req_data['dog_meals'],
                                p_cat_meals=req_data['cat_meals'],
                                p_carrier_note=req_data['carrier_note'],
                                p_price_list_id=req_data['price_list_id'],
                                x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Quote created successfully'
                result['quote_header_id'] = quote_header_id.getvalue()
            else:
                result['status'] = 'ERROR'
                result['msg'] = status_code.getvalue()
                logger.findaylog("""@ models - donation - create_quote - {}""".format(
                    result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                create_quote """ + str(e))
            raise e
        logger.addinfo('@ models - donation - create_quote(+)')
        return result

    def adoptions(self, jsond):
        unique_code_count = ''
        result = {'status': '', 'msg': ''}
        with OracleConnectionManager() as conn:
            missing_flag, result = self.check_params(jsond, 'adoption_attributes')
            if missing_flag:
                year = str(datetime.now().strftime('%y'))
                if jsond['pet_type'] == 'DOG':
                    pet_type = 'D'
                else:
                    pet_type = 'C'

                # Get respective request_header_id from application_id
                query = self.sql_file['get_request_header_id']
                conn.execute(query,
                             p_application_no=jsond['application_id'])
                request_headers = conn.get_single_result(convert_data=False)
                request_header_id = request_headers['request_header_id']
                org_id = str(request_headers['org_id'])

                if len(org_id) != 4:
                    for _ in range(4 - len(org_id)):
                        org_id = '0' + org_id

                # Get count of pets requested in current year
                query = self.sql_file['get_pet_count']
                pet_code = '%' + pet_type + str(year) + '%'
                conn.execute(query, p_code=pet_code)
                count = conn.get_single_result()['pet_count'] + 1

                # To generate unique_code
                unique_code_count += str(count)
                if len(unique_code_count) != 4:
                    for _ in range(4 - len(unique_code_count)):
                        unique_code_count = '0' + unique_code_count

                chars = string.ascii_uppercase + string.digits
                unique_random_code = ''.join(random.choice(chars)
                                             for _ in range(4))
                unique_code = org_id + pet_type + year
                unique_code += unique_code_count + unique_random_code

                adoption_id = conn.set_output_param('NUMBER')
                conn.execute("""
                begin
                    qpex_donation_pkg.insert_adoption_line(
                        :p_adoption_id,
                        :p_request_header_id,
                        :p_pet_type,
                        :p_no_of_pets,
                        :p_no_of_qty,
                        :p_unique_code,
                        :p_is_coupon_generated,
                        :p_created_by,
                        :p_recent_updated_user_id,
                        :p_status_code
                    );
                end; """, output_key='p_status_code',
                             p_adoption_id=adoption_id,
                             p_request_header_id=request_header_id,
                             p_pet_type=jsond['pet_type'],
                             p_no_of_pets=1,
                             p_no_of_qty=jsond['quantity'],
                             p_unique_code=unique_code,
                             p_is_coupon_generated='N',
                             p_created_by=jsond['user_id'],
                             p_recent_updated_user_id=-1)
                conn.get_output_param()
                result['msg'] = 'Adopted successfully'
                result['adoption_id'] = int(adoption_id.getvalue())
                result['unique_code'] = unique_code
                result['status'] = 'OK'
        return result

    # Get shops having given country_code and cities
    def get_shops(self, search_details):
        logger.addinfo('@ models - donation - get_shops(+)')
        result = {'status': '', 'result': ''}
        try:
            self.acquire()
            a = []
            a.append(search_details)
            cities = StoreLocator().get_urls(a, [], True)
            if len(cities) > 0:
                cities = ' OR s.city='.join("'{0}'".format(w) for w in cities)
                query = self.sql_file['get_shops']
                query = query.replace(':p_shop_city', cities)
                self.cursor.execute(query,
                                    p_country_code=search_details["country"]
                                    )
                data = Code_util.iterate_data(self.cursor, convert_data=False)
                result['status'] = 'OK'
                result['result'] = data
            else:
                result['status'] = 'ERROR'
                result['result'] = {"msg": """Given Details are not found.
                                              Please try again!!"""}
                logger.findaylog("""@ models - donation - get_shops -
                Given Details are not found.Please try again!! """)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_shops """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - get_shops(-)')
        return result

    # Get associates having given country_code
    def get_org_associations(self, details):
        logger.addinfo('@ models - donation - get_associations(+)')
        result = {'status': '', 'result': ''}
        try:
            self.acquire()
            if not details.get('country'):
                raise KeyError('country is not defined')
            query = self.sql_file['get_associations']
            self.cursor.execute(query, p_country_code=details["country"],
                                p_org_address=details["address"],
                                p_org_zip=details["zip_code"],
                                p_org_city=details["city"])
            data = Code_util.iterate_data(self.cursor, convert_data=False)
            result['status'] = 'OK'
            result['result'] = data
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_associations """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - get_associations(-)')
        return result

    @staticmethod
    def get_random_sequence(length):
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(length))

    # Link application to agent
    def link_agent_details(self, jsond):
        logger.addinfo('@ models - donation - link_agent_details(+)')
        result = {}
        try:
            self.acquire()
            missing_keys = ''
            attribute_names = ['header_id', 'user_id']
            for i in range(len(attribute_names)):
                if attribute_names[i] not in jsond:
                    missing_keys += attribute_names[i] + ','

            if missing_keys:
                missing_keys = missing_keys[:-1]
                result['msg'] = 'Missing ' + missing_keys
                result['msg'] += ' parameter(s)'
                result['status'] = 'ERROR'
            else:
                status_code = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute("""
                begin
                    qpex_donation_pkg.link_agent (
                        :p_header_id,
                        :p_user_id,
                        :p_status_code
                    );
                end; """, p_header_id=jsond['header_id'],
                                    p_user_id=jsond['user_id'],
                                    p_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    result['msg'] = 'Agent details linked successfully'
                    result['status'] = 'OK'
                else:
                    result['msg'] = 'Failed to link agent details - '
                    result['msg'] += str(status_code.getvalue())
                    result['status'] = 'ERROR'
                    logger.findaylog("""@ models - donation - link_agent_details -
                        {}""".format(result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                link_agent_details """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - donation - link_agent_details(-)')
        return result

    def coupon_burn(self, req_data):
        logger.addinfo('@ models - donation - coupon_burn(+)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.coupon_burn(
                    :p_coupon_code,
                    :p_shop_id,
                    :p_status_code
                );
            end; """, p_coupon_code=req_data['coupon_code'],
                                p_shop_id=req_data['shop_id'],
                                p_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result['msg'] = 'Coupon applied successfully'
                result['status'] = 'OK'
            else:
                result['msg'] = status_code.getvalue()
                result['status'] = 'ERROR'
                logger.findaylog("""@ models - donation - coupon_burn - {}""".format(
                    result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                coupon_burn """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - donation - coupon_burn(-)')
        return result

    # Update application request_status in headers table
    def application_status(self, jsond):
        approver_id = None
        with OracleConnectionManager() as conn:
            req = dict()
            req['appl_no'] = jsond['appl_no']
            req['comments'] = jsond['comments']
            req['user'] = jsond['user']
            req['inform_user'] = jsond['inform_user']
            req['user_msg'] = jsond['user_msg']
            req['wf_name'] = jsond['wf_name']
            if jsond['status'] == 'A':
                query = self.sql_file['notification_content_query']
                conn.execute(query, p_appl_no=jsond['appl_no'])
                data = conn.get_single_result(convert_data=False)
                raw_content = data['notification_content'].read()
                try:
                    content = ujson.loads(raw_content)
                except ValueError:
                    content = ast.literal_eval(raw_content)
                if content['request_type'] == 'A':
                    content['adoptme_kits'] = jsond['lines']
                else:
                    content['lines'] = jsond['lines']
                content['application_no'] = Donation.change_application_no(
                    content['application_no'])
                req['content'] = ujson.dumps(content)
                approver_id = self.approve_workflow(req)
                content, jsond = self.send_details_based_on_approver(approver_id,
                                                                     content,
                                                                     jsond)
            elif jsond['status'] == 'R':
                self.reject_workflow(req)

            result = self.update_application_status(jsond, approver_id)
        return result

    def send_details_based_on_approver(self, approver_id, content, jsond):
        if approver_id:
            name, email = self.get_approver_details(approver_id)
            # prepare the request object for approval
            # on clicking the link in mail template this object will be decoded in frontend
            mail_country, mail_language = get_country_and_language(content.get('country'),
                                                                   content.get('language'))
            mail_data = deepcopy(jsond)
            mail_data['user_id'] = int(approver_id)
            mail_data['user'] = name
            mail_data['org_name'] = content.get('org_name')
            mail_data['address'] = content.get('address')
            mail_data['city'] = content.get('city')
            mail_data['country'] = mail_country
            mail_data['language'] = mail_language
            mail_data['zip'] = content.get('zip')
            mail_data['phone'] = content.get('phone')
            mail_data['contact_name'] = content.get('user_name')
            mail_data['contact_email'] = content.get('user_email')
            content['approve_link'] = base64.b64encode(
                str(ujson.dumps(mail_data)).encode()).decode('utf-8')
            # prepare the request object for rejection
            mail_data['status'] = 'R'
            content['reject_link'] = base64.b64encode(
                str(ujson.dumps(mail_data)).encode()).decode('utf-8')
            params = [{
                'key': 'mail_template',
                'value': get_application_template(content)
            }]
            content['params'] = params
            jsond['status'] = 'UA'
            content['to_name'] = name
            content['to_email'] = email
            mail_status = CommonUtils.send_mail(content)
            if mail_status != 'SUCCESS':
                logger.findaylog(""" @ models - donation - send_next_approver_email -
                        {}""".format(content))
        else:
            """
            Send email to association informing that the
            application has been approved & include receipt PDF as
            the attachment
            """
            if content['country'] == 'IT':
                path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
                path += '/static/'
                pdf_file = open(path + 'ricevuta_italian.pdf', 'rb')
                base64_file_data = base64.b64encode(pdf_file.read())
                if content['request_type'] == 'A':
                    template_id = 766052
                else:
                    template_id = 766044

                attachments = [
                    {
                        'file_type': 'application/pdf',
                        'file_name': 'Ricevuta.pdf',
                        'file_data': base64_file_data
                    }
                ]
                self.send_approver_email_to_user(content, template_id, attachments)
            elif content['country'] == 'FR' and content['request_type'] == 'A':
                template_id = 1067736
                self.send_approver_email_to_user(content, template_id)
        return content, jsond

    @staticmethod
    def change_application_no(application_no):
        if 'BE_FR' in application_no:
            application_no.replace('BE_FR', 'BE')
        elif 'BE_NL' in application_no:
            application_no.replace('BE_NL', 'BE')
        return application_no

    def update_application_status(self, jsond, approver_id):
        # If an application is cancelled just update the application status
        result = dict()
        with OracleConnectionManager() as conn:
            conn.execute("""
                        begin
                            qpex_donation_pkg.update_application_status(
                                :p_header_id,
                                :p_status,
                                :p_updated_by,
                                :p_address_verified,
                                :p_verified_by,
                                :p_comments,
                                :p_status_code
                            );
                        end; """, output_key='p_status_code',
                         p_header_id=jsond['header_id'],
                         p_status=jsond['status'],
                         p_updated_by=jsond['user_id'],
                         p_address_verified=jsond['address_verified'],
                         p_verified_by=jsond['user'],
                         p_comments=jsond['comments'])
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Status updated successfully'
                if approver_id:
                    result['approver_id'] = approver_id
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to update application status - '
                result['msg'] += str(status_code)
        return result

    def send_approver_email_to_user(self, content, template_id, attachments=[]):
        logger.addinfo('@ models - donation - send_approver_email_to_user(+)')
        try:
            subject = self.strings['dd_adoptme_notify_approval_' + content['country'].lower()]
            mail_data = {
                'sender': {
                    'email': self.strings['dd_sender_email_' + content['country'].lower()],
                    'name': self.strings['dd_sender_name_' + content['country'].lower()]
                },
                'template_id': template_id,
                'subject': subject,
                'to_email': content['user_email'],
                'to_name': content.get('user_name').capitalize() if content.get(
                    'user_name') else '',
                'params': [
                    {
                        'key': 'org_name',
                        'value': content['org_name']
                    }
                ]
            }

            if len(attachments) > 0:
                mail_data['attachments'] = attachments
            status = CommonUtils.send_mail(mail_data)
            if status != 'SUCCESS':
                logger.findaylog("""@ models - donation -
                        send_approver_email_to_user - {}""".format(status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                        send_approver_email_to_user """ + str(e))
            raise e
        logger.addinfo('@ models - donation - send_approver_email_to_user(-)')
        return status

    # Send email for shop registration
    def send_email(self, email, user_name):
        logger.addinfo('@ models - donation - send_email(+)')
        try:
            strings = db_util.get_strings()
            data = {
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name']
                },
                'subject': strings['shop_registration'],
                'template_id': 341470,
                'params': [{
                    'key': 'user_name',
                    'value': user_name
                }],
                'to_email': email
            }
            result = CommonUtils.send_mail(data)
            if result != 'SUCCESS':
                logger.findaylog("""@ models - donation -
                                send_email - {}""".format(data))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                send_email """ + str(e))
            raise e
        logger.addinfo('@ models - donation - send_email(-)')

    def download_document(self, header_id, doc_id):
        logger.addinfo('@ models - donation - download_document(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['application_doc_download']
            self.cursor.execute(query, p_header_id=header_id,
                                p_doc_id=doc_id)
            result['status'] = 'OK'
            result['result'] = self.get_file_data()
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                download_document """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - download_document(+)')
        return result

    def send_notification(self, mail_data):
        """
        Notes:
            https://dev.mailjet.com/guides/?_ga=2.228773596.1587008746.1554102366-553638517
            .1551794573#send-api-v3-1
        """
        logger.addinfo('@ models - donation - send_notification(+)')
        try:
            attachments = []
            for attachment in mail_data['attachments']:
                attachments.append({
                    'ContentType': attachment['file_type'],
                    'Filename': attachment['file_name'],
                    'Base64Content': attachment['file_data']
                })

            params = {}
            for param in mail_data['params']:
                key, value = param['key'], param['value']
                params[key] = value

            if 'sender' in mail_data:
                from_email = mail_data['sender']['email']
                from_name = mail_data['sender']['name']
            else:
                from_email = self.sender_email
                from_name = self.sender_name

            mail_jet = Client(auth=(self.mj_api_key, self.mj_api_secret), version='v3.1')

            data = {
                'Messages': [
                    {
                        'From': {
                            'Email': from_email,
                            'Name': from_name
                        },
                        'Subject': mail_data['subject'],
                        'TemplateID': mail_data['template_id'],
                        'TemplateLanguage': True,
                        'TemplateErrorReporting': {
                            'Email': self.strings['mj_error_report_mail'],
                            'Name': self.strings['mj_error_report_name']
                        },
                        'Variables': params,
                        'To': [
                            {
                                'Email': mail_data['email'],
                                'Name': mail_data['name']
                            }
                        ]
                    }
                ]
            }

            if len(attachments) > 0:
                data['Messages'][0]['Attachments'] = attachments

            result = mail_jet.send.create(data=data)
            if result.status_code != 200:
                status = 'Failure - Failed to send email'
            else:
                status = 'OK'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                send_notification """ + str(error))
            raise error
        logger.addinfo('@ models - donation - send_notification(-)')
        return status

    def update_application(self, req_data):
        logger.addinfo('@ models - donation - update_application(+)')
        result = dict()
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            if req_data['request_line_id']:
                self.cursor.execute("""
                begin
                    qpex_donation_pkg.update_request_line(
                        :p_request_line_id,
                        :p_request_header_id,
                        :p_no_of_pets,
                        :p_no_of_qty,
                        :p_updated_by,
                        :x_status_code
                    );
                end; """, p_request_line_id=req_data['request_line_id'],
                                    p_request_header_id=req_data['header_id'],
                                    p_no_of_pets=req_data['no_of_pets'],
                                    p_no_of_qty=req_data['no_of_qty'],
                                    p_updated_by=req_data['user_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
            else:
                result = self.insert_request_line(req_data)
                if result['status'] == 'OK':
                    status = 'SUCCESS'
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Data updated successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Error updating data - ' + status
                logger.findaylog("""@ models - donation -
                                update_application - {} """.format(status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                update_application """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - update_application(+)')
        return result

    def delete_document(self, attachment_id, header_id, usr_id):
        logger.addinfo('@ models - donation - delete_document(+)')
        result = dict()
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.delete_request_attachment(
                    :p_request_header_id,
                    :p_atthmt_id,
                    :p_user_id,
                    :x_status_code
                );
            end; """, p_request_header_id=header_id,
                                p_atthmt_id=attachment_id,
                                p_user_id=usr_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Attachment deleted successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to delete attachment - ' + str(status)
                logger.findaylog("""@ models - donation -
                                delete_document - {} """.format(status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                delete_document(+)""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - delete_document(+)')
        return result

    def get_lookup(self, lookup_type):
        logger.addinfo('@ models - donation - get_lookup(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['document_types_query']
            self.cursor.execute(query, p_lookup_type=lookup_type)
            data = Code_util.iterate_data(self.cursor, convert_data=False)
            result['status'] = 'OK'
            result['result'] = data
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_lookup """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_lookup(+)')
        return result

    def update_request_attachment(self, req_data):
        logger.addinfo('@ models - donation - update_request_attachment(+)')
        result = dict()
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.update_request_attachment(
                    :p_request_header_id,
                    :p_atthmt_id,
                    :p_document_type,
                    :p_verified,
                    :p_verified_by,
                    :p_updated_by,
                    :x_status_code
                );
            end; """, p_request_header_id=req_data['header_id'],
                                p_atthmt_id=req_data['attachment_id'],
                                p_document_type=req_data['document_type'],
                                p_verified=req_data['verified_flag'],
                                p_verified_by=req_data['verified_by'],
                                p_updated_by=req_data['updated_by'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Document updated successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to update document - ' + status
                logger.findaylog("""@ models - donation -
                                update_request_attachment - {} """.format(status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                update_request_attachment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - update_request_attachment(+)')
        return result

    def get_application_log(self, header_id):
        logger.addinfo('@ models - donation - get_application_log(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['application_audit_log']
            self.cursor.execute(query, p_request_header_id=header_id)
            data = Code_util.iterate_data(self.cursor, convert_data=False)
            result['status'] = 'OK'
            result['result'] = data
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_application_log """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_application_log(+)')
        return result

    def get_burned_coupons(self, shop_id):
        logger.addinfo('@ models - donation - get_burned_coupons(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['burned_coupons_query']
            self.cursor.execute(query, p_shop_id=shop_id)
            result['result'] = Code_util.iterate_data(self.cursor, convert_data=False)
            result['status'] = 'OK'
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_burned_coupons """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_burned_coupons(+)')
        return result

    def update_password(self, req_data):
        logger.addinfo('@ models - donation - update_password(+)')
        result = dict()
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            user_name = self.cursor.var(cx_Oracle.STRING)
            if req_data['change_flag'] == 'Y':
                password = Donation.get_random_sequence(10).lower()
            else:
                password = req_data['password']
            hash_password = auth_util.encrypt_legacy(password)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.update_password(
                    :p_user_email,
                    :p_password,
                    :p_encrypted_password,
                    :p_change_flag,
                    :x_user_name,
                    :x_status_code
                );
            end; """, p_user_email=req_data['user_email'],
                                p_password=password,
                                p_encrypted_password=hash_password,
                                p_change_flag=req_data['change_flag'],
                                x_user_name=user_name,
                                x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Password changed successfully'
                if req_data['change_flag'] == 'Y':
                    mail_data = {
                        'params': [
                            {
                                'key': 'user_name',
                                'value': user_name.getvalue()
                            },
                            {
                                'key': 'password',
                                'value': password
                            }
                        ],
                        'to_email': req_data['user_email'],
                        'to_name': user_name.getvalue(),
                        'template_id': 357022,
                        'attachments': [],
                        'subject': self.strings['dd_forgot_passwd_sub']
                    }
                    CommonUtils.send_mail(mail_data)
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to update password - '
                result['msg'] += str(status_code.getvalue())
                logger.findaylog("""@ models - donation - update_password - {} """.format(
                    status_code.getvalue()))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                update_password """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - update_password(-)')
        return result

    def get_association(self, assoc_id, almo_org_id):
        logger.addinfo('@ models - donation - get_association(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['organization_details_query']
            self.cursor.execute(query, p_org_id=assoc_id,
                                p_org_type=None,
                                p_almo_org_id=almo_org_id)
            data = Code_util.iterate_data(self.cursor, convert_data=False, is_json_check=True)
            result['status'] = 'OK'
            result['result'] = data
            if assoc_id:
                query = self.sql_file['organization_users_query']
                self.cursor.execute(query, p_org_id=assoc_id,
                                    p_user_id=None)
                users = Code_util.iterate_data(self.cursor, convert_data=False)
                cognito_obj = Cognito()
                for user in users:
                    obj = cognito_obj.get_users_list({'email': user['user_email']})
                    user['resend_flag'] = False if len(obj) == 0 else True
                result['result'][0]['users'] = users

                query = self.sql_file['association_attachments_query']
                self.cursor.execute(query, p_org_id=assoc_id)
                attachments = Code_util.iterate_data(self.cursor, convert_data=False)
                result['result'][0]['documents'] = attachments
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_association """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_association(-)')
        return result

    def update_org_status(self, data):
        logger.addinfo('@ models - donation - update_org_status(+)')
        result = dict()
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                            declare\
                                l_org_id qpex_donation_pkg.lm_org_record_type_cover;\

                                type t_org_table is table of NUMBER
                                      index by binary_integer;\
                                p_orgs t_org_table := :p_org_id;\
                            begin\
                                for i in 1..p_orgs.count
                                LOOP
                                    l_org_id(i).org_id := p_orgs(i);\
                                END LOOP;\
                                qpex_donation_pkg.update_organization_status(
                                    l_org_id,
                                    :p_user_id,
                                    :p_status,
                                    :x_status_code
                                );
                            end; """, p_org_id=data['org_id'],
                                p_user_id=data['user_id'],
                                p_status=data['status'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Association status updated successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update association status - ' + str(status)
                logger.findaylog("""@ models - donation - update_org_status - {} """.format(
                    status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                update_org_status """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - update_org_status(-)')
        return result

    def associations_merge(self, data):
        logger.addinfo('@ models - donation - associations_merge(+)')
        result = dict()
        only_org_ids = []
        org_user_ids = []
        try:
            for org in data['org_ids']:
                only_org_ids.append(org['org_id'])
                org_user_ids.append(org['user_id'])
            self.acquire()
            if data['primary_org_id'] in only_org_ids:
                only_org_ids.remove(data['primary_org_id'])
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                            declare\
                                l_org_id qpex_donation_pkg.lm_org_record_type_cover;\
                                l_org_user_id qpex_donation_pkg.lm_org_user_record_type_cover;\

                                type t_org_table is table of NUMBER
                                      index by binary_integer;\
                                p_orgs t_org_table := :p_org_id;\

                                type t_org_user_table is table of NUMBER
                                      index by binary_integer;\
                                p_org_users t_org_user_table := :p_org_user_id;
                            begin\
                                for i in 1..p_orgs.count
                                LOOP
                                    l_org_id(i).org_id := p_orgs(i);\
                                END LOOP;\
                                for i in 1..p_org_users.count
                                LOOP
                                    l_org_user_id(i).user_id := p_org_users(i);\
                                END LOOP;\
                                qpex_donation_pkg.merge_organizations(
                                    l_org_id,
                                    l_org_user_id,
                                    :p_primary_org_id,
                                    :p_user_id,
                                    :x_status_code
                                );
                            end; """, p_org_id=only_org_ids,
                                p_org_user_id=org_user_ids,
                                p_primary_org_id=data['primary_org_id'],
                                p_user_id=data['user_id'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                cognito_obj = Cognito()
                result['msg'] = 'Association merged successfully. '
                for user in data['org_ids']:
                    cognito_result = cognito_obj.update_user_attributes({
                        'user_name': user['email'],
                        'attributes_to_change': [
                            {
                                'Name': 'custom:assoc_id',
                                'Value': str(data['primary_org_id'])
                            }
                        ]
                    })
                    if cognito_result['status'] == 'ERROR':
                        result['msg'] += cognito_result['msg']
                    result['status'] = 0
            else:
                result['status'] = 1
                result['msg'] = 'Failed to merge association - ' + str(status)
                logger.findaylog("""@ models - donation - associations_merge - {} """.format(
                    status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                associations_merge """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - associations_merge(-)')
        return result

    def update_user(self, data):
        result = dict()
        with OracleConnectionManager() as conn:
            user_id = data['updated_user_id']
            conn.execute("""
            begin
                qpex_donation_pkg.update_user(
                    :p_user_id,
                    :p_org_id,
                    :p_first_name,
                    :p_last_name,
                    :p_user_email,
                    :p_user_telephone,
                    :p_address,
                    :p_subscribe_to_advs,
                    :p_cust_acct_site_id,
                    :p_approval_status,
                    :p_ui_language,
                    :p_recent_updated_user_id,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         p_user_id=data['user_id'],
                         p_org_id=data['org_id'],
                         p_first_name=data['first_name'],
                         p_last_name=data['last_name'],
                         p_user_email=data['user_email'],
                         p_user_telephone=data['user_telephone'],
                         p_address=data['address'],
                         p_subscribe_to_advs=data['subscribe_to_advs'],
                         p_cust_acct_site_id=data['cust_acct_site_id'],
                         p_approval_status=data['approval_status'],
                         p_ui_language=data['ui_language'],
                         p_recent_updated_user_id=user_id)
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'User details updated successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to update user details - '
                result['msg'] += str(status_code)
        return result

    def delete_user(self, user_id, org_id):
        result = dict()
        with OracleConnectionManager() as conn:
            email_address = None
            query = self.sql_file['get_contact_email_address']
            conn.execute(query, p_user_id=user_id)
            email_result = conn.get_single_result(convert_data=False)
            if email_result:
                email_address = email_result.get('user_email')
            status_code = conn.cursor.var(cx_Oracle.STRING)
            conn.execute("""
            begin
                qpex_donation_pkg.delete_user(
                    :p_user_id,
                    :p_org_id,
                    :x_status_code
                );
            end; """, p_user_id=user_id,
                         p_org_id=org_id,
                         x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'User deleted successfully'
                if email_address:
                    cognito_obj = Cognito()
                    cognito_obj.delete_user(email_address)
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to delete user - ' + str(status)
                logger.findaylog("""@ models - donation - delete_user - {} """.format(
                    status))
        return result

    def add_note(self, data):
        logger.addinfo('@ models - donation - add_note(+)')
        result = dict()
        try:
            self.acquire()
            note_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.add_note(
                    :x_note_id,
                    :p_org_id,
                    :p_notes,
                    :p_user_id,
                    :x_status_code
                );
            end; """, x_note_id=note_id,
                                p_org_id=data['org_id'],
                                p_notes=data['notes'],
                                p_user_id=data['user_id'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Note(s) added successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to add note - ' + str(status)
                logger.findaylog("""@ models - donation - add note - {} """.format(
                    status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                add_note """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - add_note(-)')
        return result

    def get_notes(self, org_id):
        logger.addinfo('@ models - donation - get_notes(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['association_notes_query']
            self.cursor.execute(query, p_org_id=org_id)
            data = Code_util.iterate_data(self.cursor, convert_data=False)
            result['status'] = 'OK'
            result['result'] = data
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                get_notes """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_notes(-)')
        return result

    def upload_association_doc(self, data):
        logger.addinfo('@ models - donation - upload_association_doc(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                local_acquire = True
                self.acquire()
            attachment_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_file_data=cx_Oracle.BLOB)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.insert_org_attachment(
                    :x_atthmt_id,
                    :p_org_id,
                    :p_file_name,
                    :p_file_type,
                    :p_file_data,
                    :p_document_type,
                    :p_purpose,
                    :p_created_by,
                    :x_status_code
                );
            end; """, x_atthmt_id=attachment_id,
                                p_org_id=data.get('org_id'),
                                p_file_name=data.get('file_name'),
                                p_file_type=data.get('file_type'),
                                p_file_data=data.get('file_data'),
                                p_document_type=data.get('document_type'),
                                p_purpose=data.get('purpose'),
                                p_created_by=data.get('created_by'),
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['attachment_id'] = attachment_id.getvalue()
                result['msg'] = 'Document uploaded successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to upload document - ' + str(status)
                logger.findaylog("""@ models - donation - upload_association_doc - {} """.format(
                    status))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - donation -
                upload_association_doc """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                if local_acquire:
                    self.release()
        logger.addinfo('@ models - donation - upload_association_doc(-)')
        return result

    def delete_association_doc(self, atthmt_id, org_id):
        logger.addinfo('@ models - donation - delete_association_doc(+)')
        result = dict()
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.delete_org_attachment(
                    :p_org_id,
                    :p_atthmt_id,
                    :x_status_code
                );
            end; """, p_org_id=org_id,
                                p_atthmt_id=atthmt_id,
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Document deleted successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to delete document - ' + str(status)
                logger.findaylog("""@ models - donation - delete_association_doc - {} """.format(
                    status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                delete_association_doc """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - delete_association_doc(-)')
        return result

    def update_store(self, jsond):
        logger.addinfo('@ models - donation - update_store(+)')
        result = {'msg': '', 'status': ''}
        try:
            self.acquire()
            return_status = self.cursor.var(cx_Oracle.STRING)
            return_message = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                begin
                    qpex_donation_pkg.update_store(:p_user_id,
                    :p_address,
                    :x_return_status,
                    :x_return_message);
                end;""", p_user_id=jsond['user_id'],
                                p_address=jsond['address'],
                                x_return_status=return_status,
                                x_return_message=return_message)
            if return_status.getvalue() == 'S':
                result['msg'] = 'Address updated successfully'
                result['status'] = 'OK'
            else:
                result['msg'] = return_message.getvalue()
                result['status'] = 'ERROR'
                logger.findaylog("""@ models - donation - update_store - {} """.format(
                    result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                update_store """ + str(e))
            raise e
        finally:
            if return_status.getvalue() == 'S':
                self.connection.commit()
            self.release()
        logger.addinfo('@ models - donation - update_store(-)')
        return result

    def update_organization(self, data):
        logger.addinfo('@ models - donation - update_organization(+)')
        result = {}
        user_id = data['user_id']
        data['known_as'] = data.get('known_as', '')
        data['adopt_me'] = data.get('adopt_me', '')
        if user_id is None or user_id == "":
            user_id = -1
        if not data.get('org_id'):
            raise KeyError('org_id is not defined')
        try:
            self.acquire()
            query = self.sql_file['organization_details_query']
            self.cursor.execute(query, p_org_id=data.get('org_id'),
                                p_org_type=data.get('org_type'),
                                p_almo_org_id=data.get('almo_org_id'))
            org_details = Code_util.iterate_data(self.cursor, convert_data=False)
            if len(org_details) > 0:
                zip_code = data['zip_code'].lower()
                org_zip = ''
                org_city = ''
                org_address = ''
                org_country = ''

                if org_details[0]['address']:
                    org_address = org_details[0]['address']
                if org_details[0]['city']:
                    org_city = org_details[0]['city']
                if org_details[0]['zip']:
                    org_zip = org_details[0]['zip'].lower()
                if org_details[0]['country']:
                    org_country = org_details[0]['country']

                if not (org_address.lower() ==
                        data.get('address').lower() and
                        org_zip.lower() == zip_code
                        and org_city.lower() == data.get('city').lower() and
                        org_country == data.get('country')) or \
                        org_details[0]['additional_info_1'] is None:
                    if data.get('org_type') == "association":
                        data = self.find_store_details(data)
                if 'lat' not in data:
                    data['lat'] = org_details[0]['additional_info_1']
                if 'lng' not in data:
                    data['lng'] = org_details[0]['additional_info_2']

                instagram_url = data.get('instagram_url', '')
                assoc_type = data.get('assoc_type', '')
                supported_activity = data.get('supported_activity')

                if supported_activity and isinstance(supported_activity, dict):
                    supported_activity = ujson.dumps(supported_activity)

                status_code = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute("""
                    begin
                        qpex_donation_pkg.update_organization(
                            :p_org_id,
                            :p_org_name,
                            :p_telephone,
                            :p_address,
                            :p_city,
                            :p_province,
                            :p_zip,
                            :p_country,
                            :p_website_url,
                            :p_facebook_page,
                            :p_instagram_url,
                            :p_recent_updated_user_id,
                            :p_latitude,
                            :p_longitude,
                            :p_assoc_type,
                            :p_adopt_me,
                            :p_known_as,
                            :p_supported_activity,
                            :p_no_of_cat_sterilizations,
                            :p_no_of_dog_sterilizations,
                            :p_sterilization_adoption_act,
                            :p_shelter_activities,
                            :x_status_code
                        );
                    end; """, p_org_id=data['org_id'],
                                    p_org_name=data['org_name'],
                                    p_telephone=data['telephone'],
                                    p_address=data['address'],
                                    p_city=data['city'],
                                    p_province=data['province'],
                                    p_zip=str(data['zip_code']),
                                    p_country=data['country'],
                                    p_website_url=data['website_url'],
                                    p_facebook_page=data['facebook_page'],
                                    p_instagram_url=instagram_url,
                                    p_recent_updated_user_id=user_id,
                                    p_latitude=data['lat'],
                                    p_longitude=data['lng'],
                                    p_assoc_type=assoc_type,
                                    p_adopt_me=data['adopt_me'],
                                    p_known_as=data['known_as'],
                                    p_supported_activity=supported_activity,
                                    p_no_of_cat_sterilizations=data['no_of_cat_sterilizations'],
                                    p_no_of_dog_sterilizations=data['no_of_dog_sterilizations'],
                                    p_sterilization_adoption_act=data['sterilization_adoption_act'],
                                    p_shelter_activities=data['shelter_activities'],
                                    x_status_code=status_code)

                if status_code.getvalue() == 'SUCCESS':
                    result['status'] = 'OK'
                    result['msg'] = 'Organization details updated successfully'
                else:
                    result['status'] = 'ERROR'
                    result['msg'] = 'Failed to update Organization details - '
                    result['msg'] += str(status_code.getvalue())
                    logger.findaylog("""@ models - donation - update_organization - {} """.format(
                        status_code.getvalue()))
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Organization details are not found'
                logger.findaylog("""@ models - donation - update_organization - {} """.format(
                    result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                update_organization """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - update_organization(-)')
        return result

    def find_store_details(self, jsond, *args):
        geocode_url = self.sql_file['geocode_url']
        formatted_address = ''
        if jsond['address']:
            formatted_address += jsond['address']
        if jsond['city']:
            formatted_address += ',' + jsond['city']
        if jsond['country']:
            formatted_address += ',' + jsond['country']
        if jsond['zip_code']:
            formatted_address += ',' + str(jsond['zip_code'])
        end_point = geocode_url
        end_point += "&address=" + urllib.parse.quote(formatted_address)
        end_point += "&key=" + self.api_key
        result = urllib.request.urlopen(end_point).read().decode('utf-8')
        result = result.replace('\n', '')
        result = ujson.loads(result)
        if result['status'] == 'OK':
            results = result['results'][0]
            jsond['lat'] = results['geometry']['location']['lat']
            jsond['lng'] = results['geometry']['location']['lng']
        else:
            jsond['lat'] = None
            jsond['lng'] = None
        return jsond

    def start_lovefood_flow(self, application_no, req_data):
        logger.addinfo('@ models - donation - start_lovefood_flow(+)')
        approver_id = None
        try:
            self.acquire()
            x_approver_id = self.cursor.var(cx_Oracle.NUMBER)
            status = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_notification_content=cx_Oracle.BLOB)
            content = ujson.dumps(req_data, escape_forward_slashes=False)
            self.cursor.execute("""
            begin
                qpex_workflow_pkg.process_workflow(
                    :x_approver_id,
                    :p_wf_key,
                    :p_workflow_id,
                    :p_workflow_name,
                    :p_comments,
                    :p_notification_content,
                    :x_status_code
                );
            end; """, x_approver_id=x_approver_id,
                                p_wf_key=application_no,
                                p_workflow_id=None,
                                p_workflow_name=req_data.get('wf_name'),
                                p_comments=None,
                                p_notification_content=content,
                                x_status_code=status)
            if status.getvalue() == 'S':
                approver_id = x_approver_id.getvalue()
            else:
                logger.findaylog("""@ models - donation - start_lovefood_flow - {} """.format(
                    status.getvalue()))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                start_lovefood_flow """ + str(error))
        finally:
            self.release()
        logger.addinfo('@ models - donation - start_lovefood_flow(-)')
        return approver_id

    def get_approver_details(self, approver_id):
        logger.addinfo('@ models - donation - get_approver_details(+)')
        name = email = None
        try:
            self.acquire()
            query = self.sql_file['approver_details_query']
            data = self.cursor.execute(query, p_user_id=approver_id).fetchone()
            if data:
                name = data[1]
                email = data[2]
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_approver_details """ + str(error))
        finally:
            self.release()
        logger.addinfo('@ models - donation - get_approver_details(-)')
        return name, email

    def approve_workflow(self, req):
        logger.addinfo('@ models - donation - approve_workflow(+)')
        approver_id = None
        try:
            self.acquire()
            x_next_approver = self.cursor.var(cx_Oracle.NUMBER)
            status = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_notification_content=cx_Oracle.BLOB)
            self.cursor.execute("""
            begin
                qpex_workflow_pkg.approve_workflow(
                    :p_wf_key,
                    :p_workflow_name,
                    :p_comments,
                    :p_notification_content,
                    :x_next_approver,
                    :x_status_code
                );
            end; """, p_wf_key=req['appl_no'],
                                p_workflow_name=req['wf_name'],
                                p_comments=req['comments'],
                                p_notification_content=req['content'],
                                x_next_approver=x_next_approver,
                                x_status_code=status)
            if status.getvalue() == 'S':
                approver_id = x_next_approver.getvalue()
            else:
                logger.findaylog("""@ models - donation - approve_workflow - {} """.format(
                    status.getvalue()))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                approve_workflow """ + str(error))
        finally:
            self.release()
        logger.addinfo('@ models - donation - approve_workflow(-)')
        return approver_id

    def reject_workflow(self, req):
        logger.addinfo('@ models - donation - reject_workflow(+)')
        try:
            self.acquire()
            status = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_workflow_pkg.reject_workflow(
                    :p_wf_key,
                    :p_workflow_name,
                    :p_comments,
                    :x_status_code
                );
            end; """, p_wf_key=req['appl_no'],
                                p_workflow_name=req['wf_name'],
                                p_comments=req['comments'],
                                x_status_code=status)
            if status.getvalue() == 'S':
                query = self.sql_file['workflow_users_status_query']
                result = self.cursor.execute(query, p_wf_key=req['appl_no'],
                                             p_status='A').fetchall()
                recipients = []
                for row in result:
                    recipients.append({'Name': row[1], 'Email': row[2]})
                subject = 'Love Food application no. ' + req['appl_no']
                subject += ' is rejected by ' + req['user']
                data = {
                    'subject': subject,
                    'template_id': 158024,
                    'params': [{
                        'key': 'message',
                        'value': req['comments']
                    }],
                    'recipients': recipients
                }
                result = CommonUtils.send_mail(data)
                if result != 'SUCCESS':
                    logger.findaylog(("""models - donation - reject_workflow -
                                        - {}""").format(data))

                if req['inform_user'] == 'Y':
                    with OracleConnectionManager() as conn:
                        query = self.sql_file['association_contact_query']
                        conn.execute(query, p_wf_key=req['appl_no'])
                        result = conn.get_single_result(convert_data=False)
                    subject = 'Almo Nature: Love Food application no. '
                    subject += req['appl_no'] + ' is rejected'
                    msg_body = 'Your application on behalf of <b>'
                    msg_body += result['org_name'] + '</b> is rejected. Please find the'
                    msg_body += ' reason for the rejection below:'
                    msg_body += '<br><br>' + req['user_msg']
                    to_user_name = result['user_name'] if result.get('user_name') else result.get(
                        'first_name', '')
                    data = {
                        'subject': subject,
                        'template_id': 468969,
                        'params': [{
                            'key': 'message',
                            'value': msg_body
                        }],
                        'to_email': result['user_email'],
                        'to_name': to_user_name
                    }
                    CommonUtils.send_mail(data)
            else:
                logger.findaylog("""@ models - donation - reject_workflow - {} """.format(
                    status.getvalue()))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                reject_workflow """ + str(error))
        finally:
            self.release()
        logger.addinfo('@ models - donation - reject_workflow(-)')

    def update_meals(self, req):
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                qpex_donation_pkg.update_meals(
                    :p_request_id,
                    :p_meals,
                    :p_type,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         p_request_id=req['request_id'],
                         p_meals=req['meals'],
                         p_type=req['type'])
            status = conn.get_output_param(raise_exception=False)
        return status

    def get_meals(self):
        with OracleConnectionManager() as conn:
            query = self.sql_file['donated_meals_query']
            conn.execute(query)
            result = conn.get_result(convert_data=False)
        return result

    def create_application(self, req):
        logger.addinfo('@ models - donation - create_application(+)')
        result = {}
        try:
            res = self.insert_request_header(req)
            self.acquire()
            if res['status'] == 'OK':
                result['application_no'] = res['application_no']
                result['request_id'] = res['request_id']

                x_status_code = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute("""
                begin
                    qpex_donation_pkg.copy_application_attachments(
                        :p_org_id,
                        :p_user_id,
                        :p_header_id,
                        :x_status_code
                    );
                end; """, p_org_id=req['org_id'],
                                    p_user_id=req['user_id'],
                                    p_header_id=res['request_id'],
                                    x_status_code=x_status_code)

                if x_status_code.getvalue() == 'SUCCESS':
                    result['status'] = 'OK'
                    result['msg'] = 'Application submitted successfully'
                    req['application_no'] = res['application_no']
                    req['request_id'] = res['request_id']

                    query = self.sql_file['application_doc_download']
                    self.cursor.execute(query, p_header_id=res['request_id'],
                                        p_doc_id=None)

                    req['attachments'] = self.get_file_data()

                    self.prepare_notification(req)
                else:
                    result['status'] = 'ERROR'
                    result['msg'] = 'Failed to update attachments - '
                    result['msg'] += str(x_status_code.getvalue())
                    logger.findaylog("""@ models - donation - create_application - {}""".format(
                        result['msg']))
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to submit the application'
                logger.findaylog("""@ models - donation -
                                create_application - {}""".format(result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                create_application """ + str(e))
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - create_application(-)')
        return result

    @staticmethod
    def receive_application(req):
        logger.addinfo('@ models - donation - receive_application(+)')
        try:
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/'
            if req['language'] == 'it':
                pdf_file = open(path + 'ricevuta_italian.pdf', 'r')
            elif req['language'] == 'de':
                pdf_file = open(path + 'ricevuta_german.pdf', 'r')
            elif req['language'] == 'fr':
                pdf_file = open(path + 'recu_fiscal_france.pdf', 'r')
            elif req['language'] == 'be_fr':
                pdf_file = open(path + 'ricevuta_belgium_fr.pdf', 'r')
            elif req['language'] == 'be_nl':
                pdf_file = open(path + 'ricevuta_belgium_nl.pdf', 'r')
            else:
                html_file_name = 'dd_application_receive_' + str(req['language']) + '.html'
                pdf_file = Donation.generate_receipt_pdf(path,
                                                         html_file_name, req['application_no'])
            if pdf_file:
                encoded = base64.b64encode(pdf_file.read())
                pdf_file.close()

                # prepare attachment data & save it in database
                if req['language'] == 'nl':
                    file_name = 'ONTVANGSTVERKLARING {}.pdf'
                elif req['language'] == 'it':
                    file_name = 'RicevutaMerce {}.pdf'
                elif req['language'] in ['de', 'fr', 'be_nl', 'be_fr', 'be']:
                    file_name = 'Receipt {}.pdf'
                else:
                    file_name = 'Ricevuta {}.pdf'
                file_name = str(file_name, 'utf-8').format(req['application_no'])

                result = {
                    'status': 'OK',
                    'file_name': file_name,
                    'file_data': encoded
                }
            else:
                result = {
                    'status': 'ERROR',
                    'msg': 'No receipt file found for the language ' + req['language']
                }
                logger.findaylog("""@ models - donation -
                                receive_application - """ + str(result['msg']))

            # attachment = {
            #     'header_id': req['header_id'],
            #     'file_name': file_name,
            #     'file_type': 'application/pdf',
            #     'file_data': encoded,
            #     'document_type': 'RICEVUTA',
            #     'verified_flag': 'Y',
            #     'user_id': -1,
            #     'update_flag': ''
            # }
            # result = self.insert_request_attachment(attachment)
            # if result['status'] == 'OK':
            #     result['msg'] = 'Receipt added successfully'
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                receive_application """ + str(e))
            raise e
        logger.addinfo('@ models - donation - receive_application(-)')
        return result

    def register_pet_parent(self, req):
        req['registration_code'] = self.generate_random_code()
        pdf_name = Donation.generate_pet_parent_pdf(req)
        req['reg_doc'] = pdf_name
        result = self.save_pet_parent_details(req)
        if result['status'] == 'OK':
            result['file_name'] = pdf_name

            # send email to user with link to select a shop
            if req['country'] == 'CA':
                email_result = self.shop_selection_email_to_user(
                    req['email'], result['adoption_id'])
                result['msg'] += email_result.get('msg')
        return result

    @staticmethod
    def get_shelter_agreement_data(shelter_agreement_data):
        value = ""
        try:
            value = ujson.loads(shelter_agreement_data) if shelter_agreement_data else None
        except:
            value = shelter_agreement_data
        return value

    @staticmethod
    def generate_pet_parent_pdf(req):
        logger.addinfo('@ models - donation - generate_pet_parent_pdf(+)')
        path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        path += '/static/'
        if req['country'] == 'DE':
            file_name = 'dd_register_petparent_de.html'
            policy_pdf_name = 'dd_pet_parent_policy_de.pdf'
        elif req['country'] == 'FR':
            file_name = 'dd_register_petparent_fr.html'
            policy_pdf_name = 'dd_pet_parent_policy_fr.pdf'
        else:
            file_name = 'dd_register_petparent.html'
            policy_pdf_name = 'dd_pet_parent_policy.pdf'
        assoc_address = get_ship_address(req['assoc_address'])
        address = get_ship_address(req['address'])
        # generate HTML template with all the data
        template = jinja2.Environment(
            loader=jinja2.FileSystemLoader(path)
        ).get_template(file_name).render(
            name=req['name'],
            place_of_birth=req['place_of_birth'],
            date_of_birth=req['date_of_birth'],
            city=req['city'],
            address=address,
            email=req['email'],
            phone=req['phone'],
            place_date=req['place_date'],
            assoc_name=req['assoc_name'],
            assoc_address=assoc_address,
            assoc_email=req['assoc_email'],
            reg_code=req['registration_code']
        )

        # setting options for PDF file
        options = {
            'page-size': 'A4',
            'zoom': '0.85',
            'encoding': 'UTF-8',
            'quiet': ''
        }

        # copy HTML content to temporary file
        file_name = CommonUtils.generate_random_string(10)
        with io.open('/tmp/' + file_name + '.html', 'w',
                     encoding='utf-8') as fp:
            fp.write(template)
            fp.close()

        # generate PDF file from the temporary HTML file
        pdf_name = '/tmp/Pet Parent - ' + req['name'] + '.pdf'
        pdf_name = pdf_name.encode('ascii', 'ignore')
        pdfkit.from_file('/tmp/' + file_name + '.html',
                         pdf_name,
                         options=options)

        pdf_writer = PdfFileWriter()

        pdf_file = PdfFileReader(open(pdf_name, 'rb'))
        pdf_writer.addPage(pdf_file.getPage(0))

        pdf_file = PdfFileReader(open(path + policy_pdf_name, 'rb'))
        for i in range(pdf_file.numPages):
            pdf_writer.addPage(pdf_file.getPage(i))

        random_seq = CommonUtils.generate_random_string(8)
        pdf_name = 'Registration - ' + random_seq + '.pdf'
        pdf_writer.write(open('/tmp/' + pdf_name, 'wb'))

        logger.addinfo('@ models - donation - generate_pet_parent_pdf(-)')
        return pdf_name

    def save_pet_parent_details(self, req):
        result = {}
        with OracleConnectionManager() as conn:
            x_adoption_id = conn.set_output_param('NUMBER')
            country, language = get_country_and_language(req.get('country'), req.get('language'))
            conn.execute("""
            begin
                qpex_donation_pkg.register_pet_parent(
                    :x_adoption_id,
                    :p_org_id,
                    :p_request_header_id,
                    :p_pet_parent_name,
                    :p_email,
                    :p_phone,
                    :p_address,
                    :p_city,
                    :p_province,
                    :p_country,
                    :p_zip,
                    :p_adoption_date,
                    :p_pet_name,
                    :p_pet_type,
                    :p_pet_size,
                    :p_pet_age,
                    :p_pet_breed,
                    :p_comments,
                    :p_user_id,
                    :p_consent,
                    :p_registration_code,
                    :p_first_name,
                    :p_last_name,
                    :x_status_code
                );
            end; """,
                         output_key='x_status_code',
                         x_adoption_id=x_adoption_id,
                         p_org_id=req['org_id'],
                         p_request_header_id=req['request_header_id'],
                         p_pet_parent_name=req['name'],
                         p_email=req['email'],
                         p_phone=req['phone'],
                         p_address=req['address'],
                         p_city=req['city'],
                         p_province=req['province'],
                         p_country=country,
                         p_zip=req['zip'],
                         p_adoption_date=req['adoption_date'],
                         p_pet_name=req['pet_name'],
                         p_pet_type=req['pet_type'],
                         p_pet_size=req['pet_size'],
                         p_pet_age=req['pet_age'],
                         p_pet_breed=req['pet_breed'],
                         p_comments=req['comments'],
                         p_user_id=req['user_id'],
                         p_consent=req['consent'],
                         p_registration_code=req['registration_code'],
                         p_first_name=req.get('first_name', ''),
                         p_last_name=req.get('last_name', ''))
            status_code = conn.get_output_param(raise_exception=False)
            if country == 'CA' and status_code == 'EMAIL EXISTS':
                result['status'] = 'ERROR'
                result['msg'] = 'More than one adoption is not allowed.'
            elif status_code == 'SUCCESS':
                result['status'] = 'OK'
                result['adoption_id'] = x_adoption_id.getvalue()
                result['msg'] = 'Registration details saved successfully'
                res = {}
                if req.get('generate_coupon') == 'Y':
                    req['adoption_id'] = result['adoption_id']
                    res = self.generate_coupon(req)
                    result['msg'] = res['msg']
                    result['status'] = res['status']
                    if result['status'] == 'OK':
                        result['coupon_code'] = res['coupon_code']
                        result['coupon_path'] = res['coupon_path']

                attachments = req.get('attachments', []) or []
                if 'status' in res and res['status'] == 'OK':
                    attachments.append({
                        'file_name': result['coupon_code'] + '.pdf',
                        'file_type': 'application/pdf',
                        'file_data': res['coupon_data'],
                        'document_type': 'COUPON'
                    })

                for attachment in attachments:
                    attachment['adoption_id'] = result['adoption_id']
                    attachment['user_id'] = req['user_id']
                    attachment['org_id'] = req['org_id']
                    self.add_adoption_attachment(attachment)

                if 'reg_doc' in req:
                    """
                    send email to pet parent with registration document
                    03/OCT/2019 - Sending email to pet parent has to be stopped for new adoptions.
                    """
                    # reg_doc = open('/tmp/' + req['reg_doc'], 'r')
                    # mail_data = {
                    #     'params': [
                    #         {
                    #             'key': 'name',
                    #             'value': req['name']
                    #         },
                    #         {
                    #             'key': 'assoc_name',
                    #             'value': req['assoc_name']
                    #         },
                    #         {
                    #             'key': 'pet_name',
                    #             'value': req['pet_name']
                    #         },
                    #         {
                    #             'key': 'reg_code',
                    #             'value': req['registration_code']
                    #         }
                    #     ],
                    #     'to_name': req['name'],
                    #     'to_email': req['email'],
                    #     'template_id': 732805,
                    #     'subject': '(Almo Nature) Thanks for the Adoption!',
                    #     'attachments': [{
                    #         'file_type': 'application/pdf',
                    #         'file_name': req['reg_doc'],
                    #         'file_data': base64.b64encode(reg_doc.read())
                    #     }]
                    # }
                    # CommonUtils.send_mail(mail_data)

                    Donation.create_register_pet_parent_in_hubspot(req)

            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to save registration details - '
                result['msg'] += str(status_code)
        return result

    @staticmethod
    def create_register_pet_parent_in_hubspot(req):
        # Create Contact in HubSpot
        if req['org_id'] == -1:
            if req['pet_type'].upper() == 'DOG':
                persona = 'persona_9'
            elif req['pet_type'].upper() == 'CAT':
                persona = 'persona_8'
            else:
                persona = 'persona_10'
        else:
            if req['pet_type'].upper() == 'DOG':
                persona = 'persona_13'
            elif req['pet_type'].upper() == 'CAT':
                persona = 'persona_12'
            else:
                persona = 'persona_10'

        if req.get('consent') == 'Y' and req.get('email'):
            props = {
                'email': req['email'],
                'firstname': req['name'],
                'phone': req['phone'],
                'address': req['address'],
                'city': req['city'],
                'zip': req['zip'],
                'province': req['province'],
                'hs_persona': persona,
                'country': req['country'],
                'pet_name': req['pet_name'],
                'pet_type': req['pet_type'],
                'pet_size': req['pet_size'],
                'pet_age': req['pet_age'],
                'pet_breed': req['pet_breed']
            }

            cms_obj = CMS()
            cms_obj.create_contact(props)

    def get_adoption_details(self, adoption_id, org_id=None, registration_code=None, user_org_id=None):
        logger.addinfo('@ models - donation - get_adoption_details(+)')
        try:
            countries = self.sql_file['countries_orgs']
            query = self.sql_file['pet_adoptions_query']
            with OracleConnectionManager() as conn:
                if user_org_id:
                    country_name = ','.join(
                        ["'{}'".format(key) for key, value in countries.items()
                         if value == int(user_org_id)])
                    if not country_name:
                        data = []
                    else:
                        query += ' AND o.country in ({0}) '.format(country_name)
                        query += self.sql_file['order_adoption_query']
                        conn.execute(query, p_adoption_id=adoption_id,
                                     p_org_id=org_id,
                                     p_registration_code=registration_code)
                        data = conn.get_result(convert_data=False)
                else:
                    query += self.sql_file['order_adoption_query']
                    conn.execute(query, p_adoption_id=adoption_id,
                                 p_org_id=org_id,
                                 p_registration_code=registration_code)
                    data = conn.get_result(convert_data=False)
                if adoption_id:
                    query = self.sql_file['adoption_attachments_query']
                    conn.execute(query, p_adoption_id=adoption_id)
                    data[0]['attachments'] = conn.get_result(convert_data=False)
            result = {
                'status': 'OK',
                'result': data
            }
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_adoption_details """ + str(e))
            raise e
        logger.addinfo('@ models - donation - get_adoption_details(-)')
        return result

    def update_pet_parent(self, req):
        result = {}
        with OracleConnectionManager() as conn:
            if 'registered' not in req:
                req['registered'] = 'N'

            country, language = get_country_and_language(req.get('country'), req.get('language'))
            conn.execute("""
            begin
                qpex_donation_pkg.update_pet_parent(
                    :p_adoption_id,
                    :p_org_id,
                    :p_request_header_id,
                    :p_pet_parent_name,
                    :p_email,
                    :p_phone,
                    :p_address,
                    :p_city,
                    :p_province,
                    :p_country,
                    :p_zip,
                    :p_adoption_date,
                    :p_pet_name,
                    :p_pet_type,
                    :p_pet_size,
                    :p_pet_age,
                    :p_pet_breed,
                    :p_comments,
                    :p_user_id,
                    :p_consent,
                    :p_registered,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         p_adoption_id=req['adoption_id'],
                         p_org_id=req['org_id'],
                         p_request_header_id=req['request_header_id'],
                         p_pet_parent_name=req['name'],
                         p_email=req['email'],
                         p_phone=req['phone'],
                         p_address=req['address'],
                         p_city=req['city'],
                         p_province=req['province'],
                         p_country=country,
                         p_zip=req['zip'],
                         p_adoption_date=req['adoption_date'],
                         p_pet_name=req['pet_name'],
                         p_pet_type=req['pet_type'],
                         p_pet_size=req['pet_size'],
                         p_pet_age=req['pet_age'],
                         p_pet_breed=req['pet_breed'],
                         p_comments=req['comments'],
                         p_user_id=req['user_id'],
                         p_consent=req['consent'],
                         p_registered=req['registered'])
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Registration details updated successfully'
                attachments = req.get('attachments', [])
                for attachment in attachments:
                    res = self.add_adoption_attachment(attachment)
                    if res['status'] != 'OK':
                        result['msg'] = res['msg']
                        break

                pdf_name = Donation.generate_pet_parent_pdf(req)
                result['file_name'] = pdf_name
                # if email id is changed and shop is not yet selected resend email with link to select shop for Canada
                if req['email'] != req.get('old_email', '') and not req.get('cafl_application_id') and \
                        req['country'] == 'CA':
                    email_result = self.shop_selection_email_to_user(
                        req['email'], req['adoption_id'])
                    result['msg'] += email_result.get('msg')
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to save registration details - '
                result['msg'] += str(status_code)
        return result

    def add_adoption_attachment(self, req):
        logger.addinfo('@ models - donation - add_adoption_attachment(+)')
        local_acquire = False
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            x_attachment_id = self.cursor.var(cx_Oracle.NUMBER)
            x_status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_file_data=cx_Oracle.BLOB)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.add_adoption_attachment(
                    :x_attachment_id,
                    :p_adoption_id,
                    :p_org_id,
                    :p_file_name,
                    :p_file_type,
                    :p_file_data,
                    :p_document_type,
                    :p_user_id,
                    :x_status_code
                );
            end; """, x_attachment_id=x_attachment_id,
                                p_adoption_id=req['adoption_id'],
                                p_org_id=req['org_id'],
                                p_file_name=req['file_name'],
                                p_file_type=req['file_type'],
                                p_file_data=req['file_data'],
                                p_document_type=req['document_type'],
                                p_user_id=req['user_id'],
                                x_status_code=x_status_code)
            if x_status_code.getvalue() == 'SUCCESS':
                result['status'] = 'OK'
                result['attachment_id'] = x_attachment_id.getvalue()
                result['msg'] = 'Attachment added successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to add attachment - '
                result['msg'] += str(x_status_code.getvalue())
                logger.findaylog("""@ models - donation - add_adoption_attachment -{} """.format(
                    x_status_code.getvalue()))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                add_adoption_attachment """ + str(e))
            raise e
        finally:
            self.connection.commit()
            if local_acquire:
                self.release()
        logger.addinfo('@ models - donation - add_adoption_attachment(-)')
        return result

    def get_report_data(self, jsond):
        logger.addinfo('models - donation - get_report_data(+)')
        try:
            self.acquire()
            dates_query = ''
            org_query = ''
            # Append dates conditions to query
            if jsond['from_date'] and jsond['to_date']:
                dates_query = self.sql_file['donation_transactions_by_date']
                dates_query %= ("'" + jsond['from_date'] + "'", "'" + jsond['to_date'] + "'")
            elif jsond['from_date']:
                dates_query = self.sql_file['donation_transactions_from_date']
                dates_query = dates_query % ("'" + jsond['from_date'] + "'")
            elif jsond['to_date']:
                dates_query = self.sql_file['donation_transactions_to_date']
                dates_query = dates_query % ("'" + jsond['to_date'] + "'")
            if jsond.get('org_type'):
                org_query = self.sql_file['donation_transactions_org_type']
                org_query = org_query.format(p_org_type=jsond['org_type'])
            if 'name' in jsond and 'country' in jsond:
                query = self.sql_file['donation_drilldown_report_query']
                query += dates_query
                query += org_query
                self.cursor.execute(query,
                                    p_name=jsond['name'],
                                    p_country=jsond['country'],
                                    p_year=jsond['year'])
            else:
                query = self.sql_file['donation_consolidate_report_query']
                query += dates_query
                query += org_query
                query += self.sql_file['donation_transactions_groupby_query']
                self.cursor.execute(query,
                                    p_year=jsond['year'])
            result = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - donation -
                            get_report_data """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo(' models - donation - get_report_data(-)')
        return result

    def get_report_province(self, jsond):
        logger.addinfo('models - donation - get_report_province(+)')
        try:
            self.acquire()
            dates_query = ''
            org_query = ''
            # Append dates conditions to query
            if jsond['from_date'] and jsond['to_date']:
                dates_query = self.sql_file['donation_transactions_by_date']
                dates_query %= ("'" + jsond['from_date'] + "'", "'" + jsond['to_date'] + "'")
            elif jsond['from_date']:
                dates_query = self.sql_file['donation_transactions_from_date']
                dates_query = dates_query % ("'" + jsond['from_date'] + "'")
            elif jsond['to_date']:
                dates_query = self.sql_file['donation_transactions_to_date']
                dates_query = dates_query % ("'" + jsond['to_date'] + "'")
            if jsond.get('org_type'):
                org_query = self.sql_file['donation_transactions_org_type']
                org_query = org_query.format(p_org_type=jsond['org_type'])
            if 'name' in jsond and 'country' in jsond and 'province' in jsond:
                query = self.sql_file['donation_drilldown_report_province_query']
                query += dates_query
                query += org_query
                self.cursor.execute(query,
                                    p_name=jsond['name'],
                                    p_country=jsond['country'],
                                    p_year=jsond['year'],
                                    p_province=jsond['province'])
            else:
                query = self.sql_file['donation_consolidate_province_report_query']
                query += dates_query
                query += org_query
                query += self.sql_file['donation_transactions_province_groupby_query']
                self.cursor.execute(query,
                                    p_year=jsond['year'])
            result = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_report_province """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo(' models - donation - get_report_data(-)')
        return result

    def report_by_action(self, jsond):
        logger.addinfo('models - donation - report_by_action(+)')
        try:
            self.acquire()
            is_valid, result = self.check_params(jsond, 'action_report_attributes')
            if is_valid:
                if 'province' in jsond:
                    query = self.sql_file['donation_pet_by_action_province_query']
                    self.cursor.execute(query, p_action=jsond['action'],
                                        p_country=jsond['country'],
                                        p_year=jsond['year'],
                                        p_province=jsond['province'])
                else:
                    query = self.sql_file['donation_pet_by_action_country_query']
                    self.cursor.execute(query, p_action=jsond['action'],
                                        p_country=jsond['country'],
                                        p_year=jsond['year'])
                result = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                report_by_action """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo(' models - donation - get_report_data(-)')
        return result

    def get_applications_count(self, period, org_id):
        logger.addinfo('@ models - donation - get_applications_count(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['applications_period_count_query']
            count = self.cursor.execute(query,
                                        p_org_id=org_id,
                                        p_period=period).fetchone()[0]
            result['status'] = 'OK'
            result['count'] = count
            if count == 0:
                result['msg'] = 'No applications found in the given period'
            else:
                result['msg'] = 'You have already submitted ' + str(count)
                result['msg'] += ' application(s) in the given period. Your'
                result['msg'] += ' application might be rejected'
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                get_applications_count """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_applications_count(-)')
        return result

    def download_assoc_document(self, assoc_id, doc_id):
        logger.addinfo('@ models - donation - download_assoc_document(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['association_doc_download_query']
            self.cursor.execute(query, p_assoc_id=assoc_id,
                                p_doc_id=doc_id)
            result['status'] = 'OK'
            result['result'] = self.get_file_data()
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                download_assoc_document """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - download_assoc_document(-)')
        return result

    def download_adoption_document(self, adoption_id, doc_id=None):
        with OracleConnectionManager() as conn:
            query = self.sql_file['adoption_doc_download_query']
            conn.execute(query, p_adoption_id=adoption_id,
                         p_doc_id=doc_id)
            result = {
                'status': 'OK',
                'result': conn.get_result()
            }
        return result

    def get_shipping_details(self, req):
        logger.addinfo('@ models - donation - get_shipping_details(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['donation_shipping_details_query']
            self.cursor.execute(query, p_org_id=req['org_id'],
                                p_quote_number=req['quote_number'])
            result['status'] = 'OK'
            result['result'] = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_shipping_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_shipping_details(-)')
        return result

    def generate_shipping_document(self, delivery_id, org_id, is_delivery='Y'):
        logger.addinfo('@ models - donation - generate_shipping_document(+)')
        result = {}
        try:
            self.acquire()
            if is_delivery == 'N':
                query = self.sql_file['delivery_query']
                delivery = self.cursor.execute(query, p_header_id=delivery_id,
                                               p_org_id=org_id).fetchone()
                delivery_id = delivery[0]
            query = self.sql_file['shipping_document_query']
            self.cursor.execute(query,
                                p_delivery_id=delivery_id)
            data = Code_util.iterate_data(self.cursor, convert_data=False)
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            if len(data) > 0:
                path += '/static/'
                template = jinja2.Environment(
                    loader=jinja2.FileSystemLoader(path)
                ).get_template('order_ship_document.html').render(
                    shipping_number=data[0]['nr_bolla'],
                    shipping_date=data[0]['data_bolla'],
                    delivery_id=data[0]['delivery_id'],
                    billing_address=data[0]['indirizzo_fatturazione'],
                    shipping_address=data[0]['indirizzo_spedizione'],
                    transportation=data[0]['trasp'],
                    page_notes=data[0]['note_pie_pagina'],
                    goods_appearance=data[0]['aspest'],
                    weight=data[0]['peso'],
                    fob=data[0]['fob'],
                    lines=data
                )

                # setting options for PDF file
                options = {
                    'page-size': 'A4',
                    'zoom': '0.85',
                    'encoding': 'UTF-8',
                    'quiet': ''
                }

                # copy HTML content to temporary file
                file_name = CommonUtils.generate_random_string(10)
                with io.open('/tmp/' + file_name + '.html', 'w',
                             encoding='utf-8') as fp:
                    fp.write(template)
                    fp.close()

                # generate PDF file from the temporary HTML file
                pdf_name = '/tmp/' + file_name + '.pdf'
                pdfkit.from_file('/tmp/' + file_name + '.html',
                                 pdf_name,
                                 options=options)

                pdf_file = open('/tmp/' + file_name + '.pdf', 'rb')
                file_data = base64.b64encode(pdf_file.read())
                pdf_file.close()

                result['status'] = 'OK'
                result['msg'] = 'Shipping document generated successfully'
                result['file_data'] = file_data.decode('utf-8')
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to generate shipping document'
                logger.findaylog("""@ models - donation - generate_shipping_document -{} """.format(
                    result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                generate_shipping_document """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - generate_shipping_document(-)')
        return result

    def search_associations(self, req):
        logger.addinfo('@ models - donation - search_associations(+)')
        result = {}
        latitude = longitude = None
        try:
            self.acquire()
            address = req.get('address', '')
            zip_code = req.get('zip_code', '')
            city = req.get('city', '')
            country = None
            if (not address and not city and not zip_code and req['q'] != 'all'
                    and 'centre' not in req):
                req['q'] = 'all'
                country = req.get('country', '')
            if req['q'] != 'all':
                if 'centre' not in req:
                    end_point = self.sql_file['geocode_url']
                    if req['address']:
                        address = req['address']
                    if req['zip_code']:
                        if address:
                            address += ','
                        address += req['zip_code']
                    if req['city']:
                        if address:
                            address += ','
                        address += req['city']

                    url = end_point + '&address=' + address
                    url += '&components=country:' + req['country']
                    url += '&key=' + self.api_key
                    url = urllib.parse.quote(url)
                    results = urllib.request.urlopen(url).read().decode('utf-8')
                    results = results.replace('\n', '')
                    results = json.loads(results)
                    if results['status'] == 'OK':
                        geometry = results['results'][0]['geometry']
                        location = geometry['location']
                        latitude = location['lat']
                        longitude = location['lng']
                else:
                    latitude = req['centre']['lat']
                    longitude = req['centre']['lng']
                if latitude and longitude:
                    query = self.sql_file['associations_address_query']
                    country = Donation.prepare_association_country_code(req.get('country'))
                    query = query.format(lat=latitude, lng=longitude, country=country)
                    contacts_query = self.sql_file['association_contacts_query']
                    if 'records' in req:
                        query = """
                            select x.* from (
                            select * from ({0}) where to_number(distance) < :p_radius
                            order by distance) x where rownum <= :p_records
                        """.format(query)
                        self.cursor.execute(query, p_latitude=latitude,
                                            p_longitude=longitude,
                                            p_radius=req['radius'],
                                            p_records=req['records'])
                    else:
                        query = """
                            select x.* from ({0}) x
                            where to_number(distance) < :p_radius
                            order by distance
                        """.format(query)

                        self.cursor.execute(query, p_latitude=latitude,
                                            p_longitude=longitude,
                                            p_radius=req['radius'])
                else:
                    result['status'] = 'ERROR'
                    result['msg'] = 'Unable to determine location details for the'
                    result['msg'] += ' given address'
                    if self.is_acquired:
                        self.release()
                    logger.findaylog(
                        """@ models - donation - search_associations -{} """.format(
                            result['msg']))
                    return result
            else:
                country = Donation.prepare_association_country_code(country)
                query = self.sql_file['associations_address_all_query']
                query = query.format(country)
                self.cursor.execute(query)

            associations = Code_util.iterate_data(self.cursor, convert_data=False)

            # get contacts for all associations
            query = self.sql_file['all_associations_contacts_query']
            self.cursor.execute(query)
            contacts = Code_util.iterate_data(self.cursor, convert_data=False)

            data = []
            for association in associations:
                association['contacts'] = []
                association_id = association['association_id']
                source = association['datasource']
                for contact in contacts:
                    c_association_id = contact['association_id']
                    c_source = contact['data_source']

                    if c_association_id == association_id and \
                            c_source == source:
                        association['contacts'].append(contact)
                data.append(association)

            # If there is an error getting location from Google then `result`
            # contains `status`: ERROR
            if 'status' not in result:
                result['status'] = 'OK'
                result['records'] = len(data)
                result['data'] = data
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                search_associations """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - search_associations(-)')
        return result

    def monthly_report(self, org_id, year, org_type):
        logger.addinfo('@ models - donation - monthly_report(+)')
        try:
            self.acquire()
            query = self.sql_file['monthly_report']
            query = query.format(p_org_type=org_type)
            self.cursor.execute(query, p_org_id=org_id,
                                p_year=year)
            report_data = Code_util.iterate_data(self.cursor, convert_data=False)

        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                monthly_report """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - monthly_report(-)')
        return report_data

    def update_association_address(self, req):
        logger.addinfo('@ models - donation - update_association_address(+)')
        try:
            is_valid, result = self.check_params(req, 'update_address_keys')
            if is_valid:
                self.acquire()
                query = self.sql_file['update_address_query']
                self.cursor.execute(query, p_address=req['address'],
                                    p_header_id=req['header_id'],
                                    p_carrier_note=req['carrier_note'])
                if self.cursor.rowcount == 1:
                    result['status'] = 'OK'
                    result['msg'] = 'Address updated successfully'
                else:
                    result['status'] = 'ERROR'
                    result['msg'] = 'Failed to updated the address'
                    logger.findaylog(
                        """@ models - donation - update_association_address -{} """.format(
                            result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                update_association_address """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - update_association_address(+)')
        return result

    def association_details(self, association_id):
        with OracleConnectionManager() as conn:
            query = self.sql_file['association_search_contacts']
            conn.execute(query, p_association_id=association_id)
            report_data = conn.get_result(convert_data=False)
        return report_data

    def association_search(self, req):
        logger.addinfo('models - donation - association_search(+)')
        try:
            self.acquire()
            query = self.sql_file['association_search']
            address_status = req.get('address_status', '')
            if address_status == 'N':
                query += ' and latitude is null'
            if address_status == 'Y':
                query += ' and latitude is not null'
            req['adopt_me'] = req.get('adopt_me', '')
            self.cursor.execute(query,
                                p_association_name=req['association_name'],
                                p_status=req['status'],
                                p_country=req['country'],
                                p_city=req['city'],
                                p_zip_code=req['zip_code'],
                                p_dogs=req['dogs'],
                                p_cats=req['cats'],
                                p_user_verified_flag=req['user_verified_flag'],
                                p_adopt_me=req['adopt_me'])
            associations = Code_util.iterate_data(self.cursor, convert_data=False)

            # get contacts for all associations
            query = self.sql_file['all_associations_contacts_query']
            self.cursor.execute(query)
            contacts = Code_util.iterate_data(self.cursor, convert_data=False)

            result = []
            for association in associations:
                association['contacts'] = []
                association_id = association['association_id']
                source = association['datasource']
                for contact in contacts:
                    c_association_id = contact['association_id']
                    c_source = contact['data_source']

                    if c_association_id == association_id and \
                            c_source == source:
                        association['contacts'].append(contact)
                result.append(association)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                association_search """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo(' models - donation - association_search(-)')
        return result

    def association_names(self):
        logger.addinfo('@ models - donation - association_names(+)')
        try:
            self.acquire()
            query = self.sql_file['get_association_names']
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                association_names """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - association_names(-)')
        return result

    def association_cities(self):
        logger.addinfo('@ models - donation - association_cities(+)')
        try:
            self.acquire()
            query = self.sql_file['get_association_cities']
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                association_cities """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - association_cities(-)')
        return result

    def association_countries(self):
        logger.addinfo('@ models - donation - association_countries(+)')
        try:
            self.acquire()
            query = self.sql_file['get_association_countries']
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                association_countries """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - association_countries(-)')
        return result

    def insert_association(self, data):
        logger.addinfo('@ models - donation - insert_association(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            association_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            contact_ids = self.cursor.var(cx_Oracle.STRING)
            contact_id = []
            contact_type = []
            contact_method = []
            data_source = []
            contact_person_name = []
            status = []
            primary_flag = []
            for i in range(len(data[0]['contact_data'])):
                contact_id.append(data[0]['contact_data'][i]['contact_id'])
                if data[0]['contact_data'][i]['contact_method']:
                    contact_method.append(data[0]['contact_data'][i][
                        'contact_method'])
                else:
                    contact_method.append('')
                data_source.append(data[0]['contact_data'][i][
                    'data_source'])
                if data[0]['contact_data'][i]['contact_person_name']:
                    contact_person_name.append(data[0]['contact_data'][i][
                        'contact_person_name'])
                else:
                    contact_person_name.append('')
                if data[0]['contact_data'][i]['contact_type']:
                    contact_type.append(data[0]['contact_data'][i][
                        'contact_type'])
                else:
                    contact_type.append('')
                if data[0]['contact_data'][i]['status']:
                    status.append(data[0]['contact_data'][i]['status'])
                else:
                    status.append('')
                if data[0]['contact_data'][i]['primary_flag']:
                    primary_flag.append(data[0]['contact_data'][i]['primary_flag'])
                else:
                    primary_flag.append('')

            # Sending NA if no contact data is entered to avoid issues from package
            if len(contact_id) == 0:
                contact_id.append(-1)
                contact_type.append('NA')
                contact_method.append('NA')
                data_source.append('NA')
                contact_person_name.append('NA')
                status.append('NA')
                primary_flag.append('NA')
            self.cursor.execute("""
                        declare\
                            p_contact_details QPEX_DONATION_PKG.association_contact_type_cover;\

                            type number_table_t is table of number
                                index by binary_integer;\
                            type string_table_t is table of varchar2(200)
                                index by binary_integer;\

                            d_contact_id number_table_t := :p_contact_id;
                            d_contact_type string_table_t := :p_contact_type;
                            d_contact_method string_table_t := :p_contact_method;
                            d_data_source string_table_t := :p_contact_data_source;
                            d_contact_person_name string_table_t := :p_contact_person_name;
                            d_status string_table_t := :p_contact_status;
                            d_primary_flag string_table_t := :p_primary_flag;

                        begin
                            for i in 1..d_contact_id.count
                            LOOP
                                p_contact_details(i).contact_id := d_contact_id(i);\
                                p_contact_details(i).contact_type := d_contact_type(i);\
                                p_contact_details(i).contact_method := d_contact_method(i);\
                                p_contact_details(i).data_source := d_data_source(i);\
                                p_contact_details(i).contact_person_name :=
                                d_contact_person_name(i);\
                                p_contact_details(i).status := d_status(i);\
                                p_contact_details(i).primary_flag := d_primary_flag(i);\
                            END LOOP;\

                            QPEX_DONATION_PKG.insert_association(
                            :p_association_id,
                            :p_association_name,
                            :p_status,
                            :p_address_line_1,
                            :p_address_line_2,
                            :p_address_line_3,
                            :p_city,
                            :p_province,
                            :p_zip_code,
                            :p_country,
                            :p_country_code,
                            :p_dogs,
                            :p_cats,
                            :p_website,
                            :p_latitude,
                            :p_longitude,
                            :p_data_source,
                            :p_create_date,
                            :p_created_user_id,
                            :p_recent_update_date,
                            :p_recent_updated_user_id,
                            :p_user_verified_flag,
                            p_contact_details,
                            :x_status_code,
                            :x_association_id,
                            :x_contact_ids
                            );
                        end; """, p_association_id=data[0]['association_id'],
                                p_association_name=data[0]['association_name'],
                                p_status=data[0]['status'],
                                p_address_line_1=data[0]['address_line_1'],
                                p_address_line_2=data[0]['address_line_2'],
                                p_address_line_3=data[0]['address_line_3'],
                                p_city=data[0]['city'],
                                p_province=data[0]['province'],
                                p_zip_code=data[0]['zip_code'],
                                p_country=data[0]['country'],
                                p_country_code=data[0]['country_code'],
                                p_dogs=data[0]['dogs'],
                                p_cats=data[0]['cats'],
                                p_website=data[0]['website'],
                                p_latitude=data[0]['latitude'],
                                p_longitude=data[0]['longitude'],
                                p_data_source=data[0]['datasource'],
                                p_create_date=data[0]['create_date'],
                                p_created_user_id=data[0]['created_user_id'],
                                p_recent_update_date=data[0]['create_date'],
                                p_recent_updated_user_id=data[0]['created_user_id'],
                                p_user_verified_flag=data[0]['user_verified_flag'],
                                p_contact_id=contact_id,
                                p_contact_type=contact_type,
                                p_contact_method=contact_method,
                                p_contact_data_source=data_source,
                                p_contact_person_name=contact_person_name,
                                p_contact_status=status,
                                p_primary_flag=primary_flag,
                                x_status_code=status_code,
                                x_association_id=association_id,
                                x_contact_ids=contact_ids)
            if 'delete_contacts' in data[0] and len(data[0]['delete_contacts']) > 0:
                ids = ','.join(str(data[0]['delete_contacts'][i])
                               for i in range(len(data[0]['delete_contacts'])))
                contacts_status = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute("""
                    declare\
                        p_contact_ids QPEX_DONATION_PKG.delete_contact_type_cover;\

                        type number_table_t is table of number
                            index by binary_integer;\

                        d_contact_ids number_table_t := :p_ids;\

                    begin
                        for i in 1..d_contact_ids.count
                        LOOP
                            p_contact_ids(i).contact_id := d_contact_ids(i);\
                        end loop;\

                        qpex_donation_pkg.delete_contacts(
                            p_contact_ids,
                            :x_status_code
                        );
                    end; """, p_ids=data[0]['delete_contacts'],
                                    x_status_code=contacts_status)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Association Inserted Successfully'
                result['association_id'] = association_id.getvalue()
                result['contact_ids'] = contact_ids.getvalue()
            else:
                result['status'] = 1
                result['msg'] = status
                logger.findaylog("""@ models - donation - insert_association - {} """.format(
                    status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                insert_association """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - insert_association(-)')
        return result

    def delete_associations(self, ids):
        logger.addinfo('@ models - donation - delete_associations(+)')
        try:
            self.acquire()
            associations_ids = ','.join(str(ids[i]) for i in range(len(ids)))
            x_status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                declare\
                    p_association_ids QPEX_DONATION_PKG.delete_association_type_cover;\

                    type number_table_t is table of number
                        index by binary_integer;\

                    d_association_ids number_table_t := :p_ids;\

                begin
                    for i in 1..d_association_ids.count
                    LOOP
                        p_association_ids(i).association_id := d_association_ids(i);\
                    end loop;\

                    qpex_donation_pkg.delete_associations(
                        p_association_ids,
                        :x_status_code
                    );
                end; """, p_ids=ids,
                                x_status_code=x_status_code)
            if x_status_code.getvalue() != 'SUCCESS':
                logger.findaylog("""@ models - donation - delete_associations
                    - {}""".format(x_status_code.getvalue()))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                delete_associations """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - donation - delete_associations(-)')
        return x_status_code.getvalue()

    @staticmethod
    def unicode_encode(data, is_special=False):
        try:
            if data:
                return str(str(data), 'utf-8')
            return ''
        except UnicodeEncodeError:
            if is_special:
                return data
            return str(data)

    @staticmethod
    def encode(data, ignore=False):
        try:
            if data:
                return data.encode('utf-8')
            return ''
        except (UnicodeEncodeError, UnicodeDecodeError):
            try:
                if ignore:
                    return data.decode('ascii', 'ignore')
            except Exception:
                return data
        return data

    def get_coupons(self, shop_id, pet_parent_id=None, countries=None, status=None):
        with OracleConnectionManager() as conn:
            query = self.sql_file['shop_burned_coupons_query']
            if pet_parent_id:
                burned = 'N'
            else:
                burned = 'Y'
            if countries:
                countries = countries.split(',')
                country = ','.join(["'%s'" % c for c in countries])
                query += ' AND qapp.country IN (%s)' % country
            # for getting credit note status when ACN status or all is selected
            if status == 'ACN' or status == 'ALL':
                sql_query_2 = self.sql_file['get_credit_note_status_in_coupon']
                query = query.format(sql_query_2)
            query = query.format('')
            status_filter_query = self.get_coupons_filters(status)
            if status_filter_query:
                query += status_filter_query
            # for count the attachments if the country is not CA for pending and submitted for approval status
            if country != "'CA'" and status == 'P' or status == 'NA':
                attachment_query = self.sql_file['get_pending_submitted_coupons']
                query = attachment_query.format(query, '= 0' if status == 'P' else ' > 0')
            conn.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            conn.execute(query, p_shop_id=shop_id, p_burned=burned,
                         p_pet_parent_id=pet_parent_id)
            result = conn.get_result(convert_data=False)
        return result

    def get_coupons_filters(self, status):
        sql_filter_query = None
        sql_approval_null = self.sql_file['get_coupon_approval_status_null']
        sql_approval_filter = self.sql_file['get_coupon_approval_status_filter']
        sql_credit_note_null = self.sql_file['get_coupon_credit_note_null']
        sql_credit_note_status = self.sql_file['get_coupon_credit_notes_filter']
        # status which are in pending and (submitted for approval- NA)
        if status == 'P' or status == 'NA':
            sql_filter_query = sql_approval_null
        # WCN - Waiting for Credit Note Details
        elif status == 'WCN':
            sql_filter_query = sql_approval_filter
            sql_filter_query += sql_credit_note_null
            sql_filter_query = sql_filter_query.format(approval_status="'A'")
        # ACN - Approved with Credit Notes Details
        elif status == 'ACN':
            sql_filter_query = sql_approval_filter
            sql_filter_query += sql_credit_note_status
            sql_filter_query = sql_filter_query.format(
                approval_status="'A'", credit_note_status="'C'")
        elif status == 'R':
            sql_filter_query = sql_approval_filter
            sql_filter_query = sql_filter_query.format(approval_status="'R'")
        return sql_filter_query

    def validate_coupon(self, req):
        logger.addinfo('@ models - donation - validate_coupon(+)')
        result = {}
        try:
            self.acquire()
            coupon_code = req['coupon_code']
            query = self.sql_file['validate_coupon_query']
            self.cursor.execute(query, p_coupon_code=coupon_code,
                                p_shop_id=req['shop_id'])
            data = Code_util.iterate_data(self.cursor, convert_data=False)
            if len(data) > 0:
                query = self.sql_file['burn_coupon_query']
                self.cursor.execute(query, p_coupon_code=coupon_code,
                                    p_shop_id=req['shop_id'])
                result['status'] = 'OK',
                result['msg'] = 'Coupon ' + str(coupon_code) + ' is valid'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Invalid Coupon'
                logger.findaylog("""@ models - donation -
                                validate_coupon - {}""".format(result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                validate_coupon """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - validate_coupon(-)')
        return result

    def get_adoptme_shops(self):
        logger.addinfo('@ models - donation - get_adoptme_shops(+)')
        try:
            self.acquire()
            query = self.sql_file['adoptme_shops_query']
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                get_adoptme_shops """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_adoptme_shops(-)')
        return result

    def generate_coupon(self, req):
        logger.addinfo('@ models - donation - generate_coupon(+)')
        result = {}
        try:
            self.acquire()
            req['coupon_code'] = self.generate_random_code('coupon')
            x_status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.insert_coupon(
                    :p_association_id,
                    :p_adoption_id,
                    :p_coupon_code,
                    :p_pet_type,
                    :p_pet_size,
                    :p_shop_id,
                    :p_shop_name,
                    :p_shop_address,
                    :p_user_id,
                    :x_status_code
                );
            end; """, p_association_id=req['org_id'],
                                p_adoption_id=req['adoption_id'],
                                p_coupon_code=req['coupon_code'],
                                p_pet_type=req['pet_type'],
                                p_pet_size=req['pet_size'],
                                p_shop_id=req['shop_id'],
                                p_shop_name=req['shop_name'],
                                p_shop_address=req['shop_address'],
                                p_user_id=req['user_id'],
                                x_status_code=x_status_code)
            if x_status_code.getvalue() == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'Coupon generated successfully'
                result['coupon_code'] = req['coupon_code']
                path, data = self.generate_coupon_pdf(req)
                result['coupon_path'], result['coupon_data'] = path, data
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Coupon generation failed. Please try again'
                logger.findaylog("""@ models - donation - generate_coupon -
                    {}""".format(x_status_code.getvalue()))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                generate_coupon """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - generate_coupon(+)')
        return result

    def generate_random_code(self, which=None):
        logger.addinfo('@ models - donation - generate_random_code(+)')
        local_acquire = False
        code = ''
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True

            if which == 'coupon':
                query = self.sql_file['validate_coupon_code_query']
            else:
                query = self.sql_file['validate_registration_code_query']

            is_coupon_unique = False
            while not is_coupon_unique:
                code = ''.join([random.choice(string.ascii_uppercase + string.ascii_lowercase +
                                              string.digits) for _ in range(6)])
                self.cursor.execute(query, p_code=code)
                if self.cursor.rowcount == 0:
                    is_coupon_unique = True
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                generate_random_code """ + str(e))
            raise e
        finally:
            if local_acquire:
                self.release()
        logger.addinfo('@ models - donation - generate_random_code(-)')
        return code

    def generate_coupon_pdf(self, data):
        logger.addinfo('@ models - donation - generate_coupon_pdf(+)')
        encoded_file = ''
        try:
            data['shop_name'] = data.get('shop_name', '')
            coupon_page_one = 'coupon_page_one_'
            coupon_page_two = 'coupon_page_two_'
            if data['country'].lower() in ['be_fr', 'be_nl', 'fr', 'nl', 'ch_fr', 'ca', 'ca_fr']:
                pdf_language = 'fr' if data['country'] == 'ch_fr' else data['country']
                coupon_page_one += pdf_language + '_'
                coupon_page_two += pdf_language + '_' + data['pet_type'].lower() + '.html'
            else:
                if data['pet_type'].lower() == 'cat':
                    if data['pet_age'].lower() == 'kitten':
                        coupon_page_two += 'ck'
                    else:
                        coupon_page_two += 'ca'
                else:
                    if data['pet_age'].lower() == 'puppy':
                        if data['pet_size'].lower() == 'small':
                            coupon_page_two += 'ps'
                        elif data['pet_size'].lower() == 'medium':
                            coupon_page_two += 'pm'
                        else:
                            coupon_page_two += 'pl'
                    else:
                        if data['pet_size'].lower() == 'small':
                            coupon_page_two += 'as'
                        elif data['pet_size'].lower() == 'medium':
                            coupon_page_two += 'am'
                        else:
                            coupon_page_two += 'al'
                coupon_page_two += '.html'
            coupon_page_one += data['pet_type'].lower() + '.html'

            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/'

            template_one = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template(coupon_page_one).render(
                name=data['name']
            )
            # for special characters coming in string format in shop address and shop name
            kwargs = {'code': (data['coupon_code'].split('-'))[0],
                      'address': data['shop_address'],
                      'expiry_date': data['expiry_date'],
                      'shop_name': data['shop_name']}
            coupon_products = self.get_br_coupon_details(data['country'], data['pet_type'],
                                                         data['pet_age'], data['pet_size'])
            if data['country'] in ['be_fr', 'be_nl', 'fr', 'nl', 'ch_fr', 'ca', 'ca_fr']:
                kwargs['product'] = coupon_products
                kwargs['user_name'] = data['user_name']
            kwargs['send_email_address'] = self.strings['dd_sender_email_' + data['country']]

            template_two = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template(coupon_page_two).render(kwargs)

            # setting options for PDF file
            options = {
                'margin-bottom': '0',
                'margin-left': '0',
                'margin-right': '0',
                'margin-top': '0',
                'page-size': 'A4',
                'zoom': '1',
                'encoding': 'UTF-8',
                'quiet': '',
            }

            # copy HTML content to temporary file
            file_name = CommonUtils.generate_random_string(10)
            with io.open(tempfile.gettempdir() + '/' + file_name + '_1.html',
                         'w',
                         encoding='utf-8') as fp:
                fp.write(template_one)

            with io.open(tempfile.gettempdir() + '/' + file_name + '_2.html', 'w',
                         encoding='utf-8') as fp:
                fp.write(template_two)

            # generate PDF file from the temporary HTML file
            pdf_one = tempfile.gettempdir() + '/' + \
                data['coupon_code'] + '_1.pdf'
            pdfkit.from_file(tempfile.gettempdir() +
                             '/' + file_name + '_1.html',
                             pdf_one,
                             options=options)

            pdf_two = tempfile.gettempdir() + '/' + \
                data['coupon_code'] + '_2.pdf'
            pdfkit.from_file(tempfile.gettempdir() + '/' + file_name + '_2.html',
                             pdf_two,
                             options=options)

            pdf_writer = PdfFileWriter()

            pdf_file = PdfFileReader(open(pdf_one, 'rb'))
            pdf_writer.addPage(pdf_file.getPage(0))

            pdf_file = PdfFileReader(open(pdf_two, 'rb'))
            pdf_writer.addPage(pdf_file.getPage(0))

            pdf_writer.write(open(tempfile.gettempdir() +
                             '/' + data['coupon_code'] + '.pdf', 'wb'))

            pdf_file = open(tempfile.gettempdir() +
                            '/' + data['coupon_code'] + '.pdf', 'rb')
            encoded_file = base64.b64encode(pdf_file.read())
            pdf_file.close()
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                generate_coupon_pdf """ + str(e))
        logger.addinfo('@ models - donation - generate_coupon_pdf(+)')
        return encoded_file

    def get_br_coupon_details(self, country, pet_type, pet_age, pet_size):
        try:
            product = {}
            strings = self.get_coupon_details(country)
            if country in ['be_fr', 'be_nl', 'fr', 'nl']:
                if pet_type.lower() == 'dog' and pet_size == 'large' and country != 'nl':
                    pet_size = 'medium'
                product = Donation.get_products_by_pet_type(strings, pet_type, pet_age, pet_size)
                pcs_translate = self.sql_file['pcs_translate']
                bag_translate = self.sql_file['bag_translate']
                carton_translate = self.sql_file['carton_translate']
                for prod in product['info']:
                    req = {'bags': bag_translate[country]['multiple'],
                           'bag': bag_translate[country]['single'],
                           'pcs': pcs_translate[country],
                           'carton': carton_translate[country]}
                    # using three lines to do the replacement of strings
                    rep = dict((re.escape(k), v) for k, v in req.items())
                    pattern = re.compile("|".join(list(rep.keys())))
                    prod['info'] = pattern.sub(lambda m: rep[re.escape(m.group(0))], prod['info'])
            elif country in ['ca', 'ca_fr']:
                product = strings[pet_type.lower()]
            elif country in ['it', 'ch_it', 'ch_fr']:
                product = Donation.get_products_by_pet_type(strings, pet_type, pet_age, pet_size)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                            get_br_coupon_details """ + str(e))
            raise e
        return product

    def upload_coupon_document(self, req):
        logger.addinfo('@ models - donation - upload_coupon_document(+)')
        result = {}
        try:
            self.acquire()
            status = 'SUCCESS'
            msg = 'Credit Requested successfully'
            x_attachment_id = self.cursor.var(cx_Oracle.NUMBER)
            x_status_code = self.cursor.var(cx_Oracle.STRING)
            if req['attachments']:
                self.cursor.setinputsizes(p_file_data=cx_Oracle.BLOB)
            for attachment in req['attachments']:
                self.cursor.execute("""
                begin
                    qpex_donation_pkg.add_coupon_attachment(
                        :x_attachment_id,
                        :p_coupon_code,
                        :p_file_name,
                        :p_file_type,
                        :p_file_data,
                        :p_document_type,
                        :p_user_id,
                        :x_status_code
                    );
                end; """, x_attachment_id=x_attachment_id,
                                    p_coupon_code=attachment['coupon_code'],
                                    p_file_name=attachment['file_name'],
                                    p_file_type=attachment['file_type'],
                                    p_file_data=attachment['file_data'],
                                    p_document_type=attachment['doc_type'],
                                    p_user_id=attachment['user_id'],
                                    x_status_code=x_status_code)

            if req['attachments']:
                status = x_status_code.getvalue()
                msg = 'Attachment added successfully'
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = msg
                # send email to Distributor about credit request
                # only for Canada org and update coupon products
                # in coupons table
                if req.get('org_id') == 141:
                    quantities = [str(p['quantity']) for p in req['products']]
                    query = self.sql_file['update_coupon_products_query']
                    self.cursor.execute(query, p_quantities=':'.join(quantities),
                                        p_coupon_code=req['coupon_code'])
                    Donation.send_coupon_mail_distributor(req)
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to add attachment - '
                result['msg'] += str(x_status_code.getvalue())
                logger.findaylog("""@ models - donation - upload_coupon_document -
                                {}""".format(x_status_code.getvalue()))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                upload_coupon_document """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('@ models - donation - upload_coupon_document(-)')
        return result

    def get_coupon_documents(self, req):
        logger.addinfo('@ models - donation - get_coupon_documents(+)')
        try:
            self.acquire()
            query = self.sql_file['coupon_attachments_query']
            self.cursor.execute(query, p_coupon_code=req['coupon_code'])
            result = Code_util.iterate_data(self.cursor, convert_data=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                get_coupon_documents """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_coupon_documents(-)')
        return result

    def download_coupon_document(self, req):
        logger.addinfo('@ models - donation - download_coupon_document(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['coupon_doc_download_query']
            self.cursor.execute(query, p_doc_id=req['doc_id'])
            result['status'] = 'OK'
            result['result'] = self.get_file_data()
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                download_coupon_document """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - download_coupon_document(-)')
        return result

    def update_coupon_status(self, req):
        logger.addinfo('@ models - donation - update_coupon_status(+)')
        result = {}
        try:
            self.acquire()
            query = self.sql_file['update_coupon_status_query']
            self.cursor.execute(query, p_coupon_code=req['coupon_code'],
                                p_user=req['user'],
                                p_status=req['status'])
            result['status'] = 'OK'
            result['msg'] = 'Status updated successfully'
            if req['status'] == 'A':
                self.connection.commit()
                status = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute("""
                begin
                    qpex_donation_pkg.add_cn_line (
                        :p_cust_account_id,
                        :p_coupon_code,
                        :x_status_code
                    );
                end; """, p_cust_account_id=req['cust_account_id'],
                                    p_coupon_code=req['coupon_code'],
                                    x_status_code=status)
                if status.getvalue() != 'SUCCESS':
                    result['status'] = 'ERROR'
                    result['msg'] = 'Error updating status - ' + str(status.getvalue())
                    logger.findaylog("""@ models - donation - update_coupon_status -
                                    {}""".format(status.getvalue()))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                update_coupon_status """ + str(e))
            raise e
        finally:
            self.connection.commit()
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - update_coupon_status(+)')
        return result

    def create_credit_note(self, req):
        logger.addinfo('@ models - donation - create_credit_note(+)')
        cn_lines = []
        credit_note_id = ''
        result = {}
        payment_receipt_id = 1072
        try:
            self.acquire()
            if not req.get('credit_note_id'):
                query = self.sql_file['validate_coupon_code_query']
                self.cursor.execute(query, p_code=req['coupons'][0]['coupon_code'])
                shop_address = Code_util.iterate_data(self.cursor, convert_data=False)[0][
                    'shop_address']
                if shop_address.upper().find('ITALY') != -1:
                    shop_address = shop_address.upper().replace('ITALY', 'IT')
                query = self.sql_file['cn_customer_details_query']
                self.cursor.execute(query, p_cust_account_id=req['cust_id'],
                                    p_address=shop_address)
                customer = Code_util.iterate_data(self.cursor, convert_data=False)
                # get payment methods based on customer:
                payment_methods = PaymentMethod.get_paymentmethods(req['cust_id']).get(
                    str(customer[0]['billto_site_use_id']))
                for payment in payment_methods:
                    if (payment['primary_flag'] == 'Y' and
                            payment['site_use_id'] == customer[0]['billto_site_use_id']):
                        payment_receipt_id = payment['receipt_method_id']

                # this functionality is added to create cn_lines for cancelled
                # coupons with existing credit notes
                for coupon in req['coupons']:
                    coupon_req = {}
                    if coupon['cn_status'] == 'CANCELLED':
                        coupon_req['cust_account_id'] = req['cust_id']
                        coupon_req['coupon_code'] = coupon['coupon_code']
                        coupon_req['user'] = req['user_description']
                        coupon_req['status'] = 'A'
                        self.update_coupon_status(coupon_req)
                if not self.is_acquired:
                    self.acquire()
                query = self.sql_file['cn_customer_lines_query']
                coupon_codes = ','.join(str(req['coupons'][i]['coupon_code'])
                                        for i in range(len(req['coupons'])))
                query = query.format(coupon_codes)
                self.cursor.execute(query, p_cust_account_id=req['cust_id'])
                lines = Code_util.iterate_data(self.cursor, convert_data=False)

                total = 0
                for line in lines:
                    total += line['amount']
                    cn_lines.append({
                        'quantity': line['quantity'],
                        'price': float(line['price']),
                        'extended_amount': float(line['amount']),
                        'org_id': 82,
                        'last_update_date': req['date'],
                        'last_updated_by': req['user_id'],
                        'creation_date': req['date'],
                        'created_by': req['user_id'],
                        'ATTRIBUTE1': line['item_code'],
                        'ATTRIBUTE2': str(line['inventory_item_id']),
                        'ATTRIBUTE3': line['item_description'],
                        'ATTRIBUTE4': '',
                        'ATTRIBUTE5': ''
                    })

                cn_header = {
                    'customer_trx_id': -100,
                    'org_id': 82,
                    'last_update_date': req['date'],
                    'last_updated_by': req['user_id'],
                    'creation_date': req['date'],
                    'created_by': req['user_id'],
                    'ATTRIBUTE1': 1005,
                    'ATTRIBUTE2': req['cust_id'],
                    'ATTRIBUTE3': customer[0]['billto_site_use_id'],
                    'ATTRIBUTE4': customer[0]['shipto_site_use_id'],
                    'ATTRIBUTE5': 'EUR',
                    'ATTRIBUTE6': 'KIT ADOPT ME',
                    'cm_reason_code': 'KIT ADOPT ME',
                    'ATTRIBUTE8': 'N/A',
                    'ATTRIBUTE9': 'N',
                    'ATTRIBUTE10': payment_receipt_id,
                    'ATTRIBUTE11': 'N',
                    'ATTRIBUTE12': 'N',
                    'ATTRIBUTE13': '',
                    'COMMENTS': 'RIMBORSO COUPONS ({}) KIT ADOPTME MESE DI'.format(coupon_codes),
                    'internal_comment': 'RIMBORSO COUPONS ({}) KIT ADOPTME MESE DI'.format(
                        coupon_codes),
                    'total_amount': total,
                    'files': [],
                    'status': 'DRAFT'
                }

                result = CreditNote.insertCreditNote(cn_header, cn_lines)
                if result['status'] == 0:
                    credit_note_id = result['header_id']
            else:
                credit_note_id = req['credit_note_id']

            if credit_note_id:
                status = self.cursor.var(cx_Oracle.STRING)
                for coupon_code in req['coupons']:
                    self.cursor.execute("""
                    begin
                        qpex_donation_pkg.update_cn_status (
                            :p_cust_account_id,
                            :p_coupon_code,
                            :p_header_id,
                            :x_status_code
                        );
                    end; """, p_cust_account_id=req['cust_id'],
                                        p_coupon_code=coupon_code['coupon_code'],
                                        p_header_id=credit_note_id,
                                        x_status_code=status)
                    if status.getvalue() == 'SUCCESS' and 'credit_note_id' in req:
                        result['status'] = 0
            if result['status'] == 0 and 'credit_note_id' in req:
                result['msg'] = 'Credit Note # is updated successfully'

        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                create_credit_note """ + str(e))
            raise e
        finally:
            self.connection.commit()
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - create_credit_note(-)')
        return result

    def send_email_receipt(self, req):
        logger.addinfo('@ models - donation - send_email_receipt(+)')
        try:
            self.acquire()
            recipients = req['recipients']
            query = self.sql_file['get_user_email']
            result = {}
            for i in range(len(recipients)):
                ricevuta = self.receive_application({
                    'language': req['language'],
                    'application_no': recipients[i]['application_no']
                })
                mail_data = {}
                self.cursor.execute(query, p_org_id=recipients[i]['org_id'])
                recipient_data = Code_util.iterate_data(self.cursor, convert_data=False)
                country = Donation.email_template_selection(recipient_data[0])
                mail_data['sender'] = {
                    'email': self.strings['dd_sender_email_' + country],
                    'name': self.strings['dd_sender_name_' + country]
                }
                mail_data['to_name'] = recipient_data[0]['user_name']
                mail_data['to_email'] = recipient_data[0]['user_email']
                mail_data['subject'] = req['subject'] + ' #' + recipients[i]['application_no']
                mail_data['attachments'] = []
                mail_data['attachments'].append({
                    'file_type': 'application/pdf',
                    'file_name': ricevuta['file_name'],
                    'file_data': ricevuta['file_data']
                })
                mail_data['template_id'] = 735647
                mail_data['params'] = [
                    {
                        'key': 'application_no',
                        'value': recipients[i]['application_no']
                    },
                    {
                        'key': 'body',
                        'value': req['body'].replace('\n', '<br>')
                    },
                    {
                        'key': 'user_name',
                        'value': recipient_data[0]['user_name'] or ''
                    },
                    {
                        'key': 'greeting',
                        'value': req['greeting']
                    },
                    {
                        'key': 'request_text_1',
                        'value': req['request_text_1']
                    },
                    {
                        'key': 'request_text_2',
                        'value': req['request_text_2']
                    },
                    {
                        'key': 'request_text_3',
                        'value': req['request_text_3']
                    },
                    {
                        'key': 'rights_text',
                        'value': req['rights_text']
                    },
                    {
                        'key': 'mailing_text',
                        'value': req['mailing_text']
                    }]
                result_status = CommonUtils.send_mail(mail_data)
            if result_status != 'SUCCESS':
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to send email'
                logger.findaylog("""@ models - donation - send_email_receipt -
                            {}""".format(result_status))
            else:
                result['status'] = 'SUCCESS'
                result['msg'] = 'Email sent to all recipients'
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                send_email_receipt """ + str(e))
            raise e
        finally:
            self.connection.commit()
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - send_email_receipt(-)')
        return result

    def get_donation_metrics(self, aggregate='N'):
        with OracleConnectionManager() as conn:
            if aggregate == 'Y':
                query = self.sql_file['donation_metrics_aggregate_query']
                conn.execute(query)
                result = conn.get_single_result(convert_data=False)
            else:
                query = self.sql_file['donation_desk_pets_metrics_query']
                conn.execute(query)
                pets_metrics = conn.get_result(convert_data=False)
                query = self.sql_file['donation_desk_shelters_metrics_query']
                conn.execute(query)
                shelters_metrics = conn.get_result(convert_data=False)
                result = []
                # merge pets and shelters data
                for i in range(len(pets_metrics)):
                    for j in range(len(shelters_metrics)):
                        if pets_metrics[i]['year'] == shelters_metrics[j]['year']:
                            result.append(
                                {key: value
                                 for (key, value) in (list(pets_metrics[i].items()) + list(shelters_metrics[j].items()))})
        return result

    def insert_acaifl_pet_parent(self, req):
        result = {}
        with OracleConnectionManager() as conn:
            # Pet Breed, Pet Bio, Province and State are not mandatory
            req['last_name'] = req['last_name'].replace('\\', '')
            req['first_name'] = req['first_name'].replace('\\', '')
            req['association_name'] = req['association_name'].replace('\\', '')
            req['address'] = req['address'].replace('\\', '')
            req['pet_name'] = req['pet_name'].replace('\\', '')
            req['pet_breed'] = req.get('pet_breed', '')
            req['pet_bio'] = req.get('pet_bio', '')
            req['province'] = req.get('province', '')
            req['state'] = req.get('state', '')
            pet_parent_id = conn.set_output_param('NUMBER')
            is_online = False if req.get('shop_type') == 'offline' else True
            req['country'], req['language'] = get_country_and_language(
                req.get('country'), req.get('language'))
            conn.execute("""
            begin
                qpex_donation_pkg.insert_acaifl_pet_parent(
                    :x_pet_parent_id,
                    :p_first_name,
                    :p_last_name,
                    :p_email,
                    :p_telephone,
                    :p_address,
                    :p_city,
                    :p_province,
                    :p_state,
                    :p_country,
                    :p_postal_code,
                    :p_created_by,
                    :p_contact_customer,
                    :p_contact_by,
                    :p_language,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         x_pet_parent_id=pet_parent_id,
                         p_first_name=req.get('first_name'),
                         p_last_name=req.get('last_name'),
                         p_email=req.get('email'),
                         p_telephone=req.get('telephone'),
                         p_address=req.get('address'),
                         p_city=req.get('city'),
                         p_province=req.get('province'),
                         p_state=req.get('state'),
                         p_country=req.get('country'),
                         p_postal_code=req.get('postal_code'),
                         p_created_by=req.get('user_id', -1),
                         p_contact_customer=req.get('contact_customer', 'N'),
                         p_contact_by=req.get('contact_by', ''),
                         p_language=req.get('language'))
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                req['pet_parent_id'] = int(pet_parent_id.getvalue())
                result = {
                    'status': 0,
                    'msg': 'Pet parent details saved successfully',
                    'pet_parent_id': int(pet_parent_id.getvalue())
                }
                msg, pet_id = self.pet_parent_related_details(req, is_online)
                result['msg'] += msg
                result['pet_id'] = pet_id
                if req.get('adoption_id'):
                    Donation.update_adoption(result['pet_parent_id'], req['adoption_id'])
            elif status_code == 'EMAIL EXISTS':
                data = self.sql_file['translations']
                translation_keys = data.get(req['country']) or data['US']
                if req['country'] != 'NL':
                    msg = translation_keys['EMAIL_EXISTS']
                else:
                    msg = translation_keys['EMAIL_EXISTS'].format(req['email'])
                result = {
                    'status': 'exists',
                    'msg': msg
                }
            elif status_code == 'MAX LIMIT':
                result = {
                    'status': 'max_limit',
                    'msg': 'Max limit for coupons exceeded for this Email'
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Error inserting pet parent details - ' + str(status_code)
                }
        return result

    def pet_parent_related_details(self, req, is_online):
        msg = ''
        pet_id = ''
        status = self.insert_acaifl_pet_details(req)
        if 'pet_id' not in status:
            msg += '. ' + status.get('msg', '')
        else:
            pet_id = status['pet_id']
            req['pet_id'] = status['pet_id']
            attachments = req.get('attachments', [])
            for attachment in attachments:
                attachment['user_id'] = req.get('user_id', -1)
                attachment['reference_id'] = req['pet_parent_id']
                status = self.insert_acaifl_attachments(attachment)
                if 'file_id' not in status:
                    msg += ' ' + status.get('msg', '')

            status = self.insert_acaifl_coupons(req, is_online)
            if 'coupon_id' not in status:
                msg += ' ' + status.get('msg', '')
        msg += self.save_pet_parent_in_hubspot(req, is_online)
        return msg, pet_id

    def save_pet_parent_in_hubspot(self, req, is_online):
        msg = ''
        # Save pet parent details in HubSpot
        if req.get('pet_type') == 'CAT':
            # Cat Adopter
            persona = 'persona_12'
        elif req.get('pet_type') == 'DOG':
            # Dog Adopter
            persona = 'persona_13'
        else:
            # Pet Adopter
            persona = 'persona_11'

        props = {
            'email': req.get('email', ''),
            'firstname': req.get('first_name', ''),
            'lastname': req.get('last_name', ''),
            'hs_persona': persona,
            'phone': req.get('telephone', ''),
            'address': req.get('address', ''),
            'city': req.get('city', ''),
            'province': req.get('province', ''),
            'state': req.get('state', ''),
            'country': Donation.email_template_selection(req),
            'zip': req.get('postal_code', ''),
            'pet_name': req.get('pet_name', ''),
            'pet_breed': req.get('pet_breed', ''),
            'pet_age': req.get('pet_age', ''),
            'pet_size': req.get('pet_size', ''),
            'pet_type': req.get('pet_type', ''),
            'workflow_trigger': 'adopt_me_canada_2022_register_offline'
            # 'workflow_trigger': 'caifl_pet_parent_register_online' if is_online else
            # 'caifl_pet_parent_register_offline'
        }
        obj = CMS()
        status = obj.create_contact(props)
        if 'status' in status:
            msg = '. Unable to create HubSpot contact for Pet Parent'
            logger.findaylog("""@ models - donation - insert_acaifl_pet_parent -
                    {} - {}""".format(msg, props))
        msg += self.send_pet_parent_approver_details(req, is_online)
        return msg

    def send_pet_parent_approver_details(self, req, is_online):
        msg = ''
        with OracleConnectionManager() as conn:
            query = self.sql_file['cafl_notification_users']
            workflow_name = 'QPEX_CAFL_{}'.format(req.get('country'))
            conn.execute(query, p_workflow=workflow_name)
            users = conn.get_result()
        if is_online:
            online_shop = 'online'
        else:
            online_shop = req.get('shop_name', '')

        # send email to all approvers
        if users:
            recipients = []
            for user in users:
                recipients.append({
                    'Email': user['email_address'],
                    'Name': user['full_name']
                })
            subject = self.sql_file['coupon_approver_notify_subject']
            subject = subject.format(int(req['pet_parent_id']))
            mail_data = {
                'recipients': recipients,
                'template_id': 891835,
                'subject': subject,
                'params': [
                    {
                        'key': 'pet_parent',
                        'value': ' '.join([req.get('first_name', ''),
                                           req.get('last_name', '')])
                    },
                    {
                        'key': 'request_id',
                        'value': req['pet_parent_id']
                    },
                    {
                        'key': 'pet_name',
                        'value': req.get('pet_name', '')
                    },
                    {
                        'key': 'pet_age',
                        'value': req.get('pet_age', '')
                    },
                    {
                        'key': 'pet_size',
                        'value': req.get('pet_size', '')
                    },
                    {
                        'key': 'pet_type',
                        'value': req.get('pet_type', '')
                    },
                    {
                        'key': 'phone',
                        'value': req.get('telephone', '')
                    },
                    {
                        'key': 'address',
                        'value': req.get('address', '')
                    },
                    {
                        'key': 'online_shop',
                        'value': online_shop
                    },
                    {
                        'key': 'email_address',
                        'value': req.get('email', '')
                    },
                    {
                        'key': 'association_name',
                        'value': req.get('association_name', '').replace('\\', '')
                    },
                    {
                        'key': 'contact_by',
                        'value': req.get('contact_by', '')
                    }
                ]
            }
            status = CommonUtils.send_mail(mail_data)
            if status != 'SUCCESS':
                msg = '. Failed to send email to approver'
                logger.findaylog("""@ models - donation - insert_acaifl_pet_parent -
                                                    {} - {}""".format(msg, mail_data))
        else:
            msg += 'No approval users'
        return msg

    def update_acaifl_pet_parent(self, req):
        with OracleConnectionManager() as conn:
            country, language = get_country_and_language(req.get('country'), req.get('language'))
            conn.execute("""
            begin
                qpex_donation_pkg.update_acaifl_pet_parent (
                    :p_pet_parent_id,
                    :p_first_name,
                    :p_last_name,
                    :p_email,
                    :p_telephone,
                    :p_address,
                    :p_city,
                    :p_province,
                    :p_state,
                    :p_country,
                    :p_postal_code,
                    :p_user_id,
                    :p_language,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         p_pet_parent_id=req['pet_parent_id'],
                         p_first_name=req['first_name'],
                         p_last_name=req['last_name'],
                         p_email=req['email'],
                         p_telephone=req['telephone'],
                         p_address=req['address'],
                         p_city=req['city'],
                         p_province=req['province'],
                         p_state=req['state'],
                         p_country=country,
                         p_postal_code=req['postal_code'],
                         p_user_id=req['user_id'],
                         p_language=language)
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Pet parent details updated successfully'
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Error updating pet parent details - ' + str(status_code)
                }
        return result

    def insert_acaifl_pet_details(self, req):
        result = {}
        with OracleConnectionManager() as conn:
            pet_id = conn.set_output_param('NUMBER')
            conn.execute("""
            begin
                qpex_donation_pkg.insert_acaifl_pet_details (
                    :x_pet_id,
                    :p_pet_parent_id,
                    :p_pet_name,
                    :p_pet_breed,
                    :p_pet_age,
                    :p_pet_size,
                    :p_pet_type,
                    :p_pet_bio,
                    :p_pet_dob,
                    :p_pet_gender,
                    :p_is_adopted,
                    :p_adoption_date,
                    :p_created_by,
                    :p_association_id,
                    :p_association_name,
                    :p_town,
                    :p_association_city,
                    :p_association_phone,
                    :p_association_province,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         x_pet_id=pet_id,
                         p_pet_parent_id=req['pet_parent_id'],
                         p_pet_name=req.get('pet_name'),
                         p_pet_breed=req.get('pet_breed'),
                         p_pet_age=req.get('pet_age'),
                         p_pet_size=req.get('pet_size'),
                         p_pet_type=req.get('pet_type'),
                         p_pet_bio=req.get('pet_bio'),
                         p_pet_dob=req.get('pet_dob'),
                         p_pet_gender=req.get('pet_gender'),
                         p_is_adopted=req.get('is_adopted'),
                         p_adoption_date=req.get('adoption_date'),
                         p_created_by=req.get('user_id', -1),
                         p_association_id=req.get('association_id', ''),
                         p_association_name=req.get('association_name', ''),
                         p_association_city=req.get('association_city', ''),
                         p_association_province=req.get('association_province', ''),
                         p_association_phone=req.get('association_phone', ''),
                         p_town=req.get('town'))
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Pet details saved successfully',
                    'pet_id': int(pet_id.getvalue())
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Error saving pet details - ' + str(status_code)
                }
        return result

    def insert_acaifl_attachments(self, req):
        file_data = None
        data_array = []
        result = {}
        with OracleConnectionManager() as conn:
            file_id = conn.set_output_param('NUMBER')
            # To remove base64 text from file_data
            file_data = req.get('file_data', '')
            if file_data.find('base64,') != -1:
                data_array = file_data.split('base64,')
                file_data = data_array[1]
            conn.cursor.setinputsizes(p_file_data=cx_Oracle.BLOB)
            conn.execute("""
            begin
                qpex_donation_pkg.insert_acaifl_attachments (
                    :x_file_id,
                    :p_reference_id,
                    :p_reference_type,
                    :p_attachment_type,
                    :p_fie_type,
                    :p_file_data,
                    :p_file_name,
                    :p_created_by,
                    :x_status_code
                );
            end; """, output_key='x_status_code', x_file_id=file_id,
                         p_reference_id=req.get('reference_id'),
                         p_reference_type=req.get('reference_type'),
                         p_attachment_type=req.get('attachment_type'),
                         p_fie_type=req.get('file_type'),
                         p_file_data=file_data,
                         p_file_name=req.get('file_name'),
                         p_created_by=req.get('user_id', -1))
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Attachment saved successfully',
                    'file_id': int(file_id.getvalue())
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Error saving attachment - ' + str(status_code)
                }
        return result

    def update_acaifl_pet_details(self, req):
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                qpex_donation_pkg.update_acaifl_pet_details (
                    :p_pet_id,
                    :p_pet_parent_id,
                    :p_pet_name,
                    :p_pet_breed,
                    :p_pet_age,
                    :p_pet_size,
                    :p_pet_type,
                    :p_pet_bio,
                    :p_pet_dob,
                    :p_pet_gender,
                    :p_is_adopted,
                    :p_adoption_date,
                    :p_user_id,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         p_pet_id=req['pet_id'],
                         p_pet_parent_id=req['pet_parent_id'],
                         p_pet_name=req['pet_name'],
                         p_pet_breed=req['pet_breed'],
                         p_pet_age=req['pet_age'],
                         p_pet_size=req['pet_size'],
                         p_pet_type=req['pet_type'],
                         p_pet_bio=req['pet_bio'],
                         p_pet_dob=req.get('pet_dob'),
                         p_pet_gender=req.get('pet_gender'),
                         p_is_adopted=req['is_adopted'],
                         p_adoption_date=req['adoption_date'],
                         p_user_id=req['user_id'])
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Pet details updated successfully'
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Error updating pet details - ' + str(status_code)
                }
        return result

    def insert_acaifl_coupons(self, req, is_online):
        result = {}
        with OracleConnectionManager() as conn:
            coupon_id = conn.set_output_param('NUMBER')
            coupon_code = ''

            """
            shop_type property in the request object defines the type of registration
            """
            if is_online:
                # get online shop coupon
                req['shop_id'] = ''
                req['shop_name'] = ''
                req['shop_address'] = ''

                coupon_code, req['shop_name'], req['shop_address'] = self.assign_coupon_code(req)
            else:
                coupon_code = self.generate_random_code('coupon')
            conn.execute("""
            begin
                qpex_donation_pkg.insert_acaifl_coupons (
                    :x_coupon_id,
                    :p_pet_parent_id,
                    :p_pet_id,
                    :p_coupon_code,
                    :p_shop_id,
                    :p_shop_name,
                    :p_shop_address,
                    :p_created_by,
                    :x_status_code
                );
            end; """, output_key='x_status_code',
                         x_coupon_id=coupon_id,
                         p_pet_parent_id=req.get('pet_parent_id'),
                         p_pet_id=req.get('pet_id'),
                         p_coupon_code=coupon_code,
                         p_shop_id=req.get('shop_id'),
                         p_shop_name=req.get('shop_name'),
                         p_shop_address=req.get('shop_address'),
                         p_created_by=req.get('user_id', -1))
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Coupon generated successfully',
                    'coupon_code': coupon_code,
                    'coupon_id': coupon_id
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Error generating the coupon - ' + str(status_code)
                }
        return result

    def update_online_coupon_cell(self, email, status, row_id=False):
        pob = POB()
        online_coupon_tbl_schema = pob.get_table_schema(self.online_coupons_tbl, True)
        if not row_id:
            query = Donation.get_query(email)
            table_row = pob.get_table_data(self.online_coupons_tbl, query=query, include_id=True)
            if len(table_row) > 0:
                row_id = table_row[0]['rowid']
                pob.update_cell_value(self.online_coupons_tbl, online_coupon_tbl_schema, {
                    'rowid': row_id,
                    'assigned_email': email,
                    'status': status,
                    'approved_date': str(datetime.now())
                })
        else:
            failed_attrs = pob.update_cell_value(self.online_coupons_tbl, online_coupon_tbl_schema,
                                                 {
                                                     'rowid': row_id,
                                                     'assigned_email': email,
                                                     'status': status,
                                                     'assigned_date': str(datetime.now())
                                                 })
            if failed_attrs:
                logger.findaylog(""" @ models - donation - insert_acaifl_coupons -
                        update_online_coupon_cell - {}""".format({
                    'email': email,
                    'status': status,
                    'failed_attrs': failed_attrs
                }))
        pob.publish_table(self.online_coupons_tbl)

    def get_pet_parent_details(self, req):
        parent_id = None
        country_codes = None
        # get pet parent details for req if req is type int
        if req and type(req) == int:
            parent_id = req
        elif req:
            countries = req.get('countries', [])
            country_codes = ','.join("'" + str(countries[i]) + "'"
                                     for i in range(len(countries)))
        with OracleConnectionManager() as conn:
            query = self.sql_file['pet_parent_query']
            cancel_condition_query = self.sql_file['get_pet_parent_summary_without_cancel']
            query = query + cancel_condition_query

            # Get cafl applications for requested countries
            if country_codes:
                query += ' and country in ({0})'
                query = query.format(country_codes)

            conn.execute(query, p_pet_parent_id=parent_id)
            result = conn.get_result(convert_data=False)
            if parent_id and result:
                query = self.sql_file['pet_details_query']
                conn.execute(query, p_parent_id=parent_id)
                result[0]['pets'] = conn.get_result(convert_data=False)

                query = self.sql_file['pet_attachments_query']
                conn.execute(query, p_reference_id=parent_id,
                             p_reference_type='PET')
                result[0]['files'] = conn.get_result(convert_data=False)
                # send the coupon pdf link for offline shops
                if result[0].get('shop_id') or result[0]['country'].lower() == 'fr':
                    coupon_pdf = Donation.parse_contact_properties(result[0]['email'])
                    result[0]['h_coupon_pdf'] = coupon_pdf.get('file')
                    if result[0]['country'].lower() == 'ca':
                        result[0]['h_coupon_pdf_additional'] = coupon_pdf.get(
                            'coupon_pdf_additional')
            elif parent_id and not result:
                result = {'status': 1, 'msg': 'Pet Parent details are not found'}

        return result

    @staticmethod
    def update_pdf_links(pdf_json):
        with OracleConnectionManager() as conn:
            conn.execute("""
                begin
                    qpex_donation_pkg.update_pdf_links(
                        :p_pet_parent_id,
                        :p_coupon_pdf,
                        :p_coupon_pdf_additional,
                        :x_status_code
                    );
                end;
            """, output_key='x_status_code',
                         p_pet_parent_id=pdf_json['pet_parent_id'],
                         p_coupon_pdf=pdf_json['coupon_pdf'],
                         p_coupon_pdf_additional=pdf_json['coupon_pdf_additional'])

    def change_ca_coupon_status(self, req):
        result = {
            'status': 0,
            'msg': 'Coupon status updated successfully'
        }
        with OracleConnectionManager() as conn:

            conn.execute("""
            begin
                qpex_donation_pkg.change_coupon_status (
                    :p_pet_parent_id,
                    :p_is_approved,
                    :p_approved_by,
                    :p_comments,
                    :p_user_id,
                    :x_status_code
                );
            end; """, output_key='x_status_code', p_pet_parent_id=req['pet_parent_id'],
                         p_is_approved=req['is_approved'],
                         p_approved_by=req['approved_by'],
                         p_comments=req['comments'],
                         p_user_id=req['user_id'])
            conn.get_output_param(raise_exception=True)
            # get pet parent name & email address
            query = self.sql_file['pet_parent_query']
            conn.execute(query, p_pet_parent_id=req['pet_parent_id'])
            data = conn.get_result()
            if not data:
                return {'status': 1,  'msg': 'No pet parent details found'}
            name, email = data[0]['first_name'], data[0]['email']
            shop_id = data[0]['shop_id']
            data[0]['country'], data[0]['language'] = get_country_and_language(
                data[0].get('country'), data[0].get('language')
            )
            country = Donation.email_template_selection(data[0]).lower()
            props = {
                'email': email
            }
            # if the request is approved send coupon to user
            # otherwise send email saying that the request is rejected
            if req['is_approved'] == 'N':
                props['workflow_trigger'] = 'adopt_me_canada_2022_rejected'
            else:
                query = self.sql_file['pet_details_query']
                conn.execute(query, p_parent_id=req['pet_parent_id'])
                pet_details = conn.get_result()
                if pet_details and len(pet_details):
                    pet_details[0]['email'] = email
                # in case of offline shop generate coupon PDF and send in email
                coupon_data = {
                    'pet_type': pet_details[0]['pet_type'],
                    'pet_age': pet_details[0]['pet_age'],
                    'pet_size': pet_details[0]['pet_size'],
                    'name': name,
                    'coupon_code': data[0]['coupon_code'],
                    'shop_address': data[0]['shop_address'],
                    'expiry_date': data[0]['expiry_date'],
                    'shop_name': data[0]['shop_name'],
                    'user_name': ' '.join(
                        [data[0]['first_name'], data[0]['last_name']]),
                    'country': country
                }
                self.generate_coupon_pdf(coupon_data)
                file_name = data[0]['coupon_code'] + '.pdf'
                status = Donation.upload_file(
                    tempfile.gettempdir() + '/' + file_name, self.COUPONS_FOLDER)
                if 'url' not in status:
                    result['msg'] += self.FAILED_HUBSPOT_UPLOAD
                else:
                    props['file'] = status['url']
                coupon_data['country'] = 'ca_fr'
                coupon_data['coupon_code'] = coupon_data['coupon_code'] + '-FR'
                self.generate_coupon_pdf(coupon_data)
                additional_coupon_file_name = data[0]['coupon_code'] + \
                    '-FR' + '.pdf'
                status = Donation.upload_file(
                    tempfile.gettempdir() + '/' + additional_coupon_file_name, self.COUPONS_FOLDER)
                if 'url' not in status:
                    result['msg'] += '. Failed to upload FR coupon file to HubSpot'
                else:
                    props['coupon_pdf_additional'] = status['url']
                coupon_data['country'] = 'ca'
                props['workflow_trigger'] = 'adopt_me_canada_2022_approved'
                result['msg'] += self.send_email_to_shop(req.get('cc', ''),
                                                         shop_id, coupon_data, data[0]['language'])

            # update contact property 'workflow_trigger' in HubSpot
            # to automatically send email to pet parent
            cms = CMS()
            status = cms.create_contact(props)
            if 'status' in status:
                result['msg'] += '. Failed to send email to user'
                logger.findaylog("""@ models - donation - change_ca_coupon_status -
                            {} - {}""".format(result['msg'], props))
            if req['is_approved'] == 'Y':
                self.validate_file_property(email, req['pet_parent_id'],
                                            data[0]['contact_by'], data[0]['country'])
        return result

    def change_coupon_status(self, req):
        logger.addinfo('@ models - donation - change_coupon_status(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                qpex_donation_pkg.change_coupon_status (
                    :p_pet_parent_id,
                    :p_is_approved,
                    :p_approved_by,
                    :p_comments,
                    :p_user_id,
                    :x_status_code
                );
            end; """, p_pet_parent_id=req['pet_parent_id'],
                                p_is_approved=req['is_approved'],
                                p_approved_by=req['approved_by'],
                                p_comments=req['comments'],
                                p_user_id=req['user_id'],
                                x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Coupon status updated successfully'
                }

                # get pet parent name & email address
                query = self.sql_file['pet_parent_query']
                self.cursor.execute(query, p_pet_parent_id=req['pet_parent_id'])
                data = Code_util.iterate_data(self.cursor, convert_data=False)
                if data:
                    name, email = data[0]['first_name'], data[0]['email']
                    shop_id = data[0]['shop_id']
                    data[0]['country'], data[0]['language'] = get_country_and_language(
                        data[0].get('country'), data[0].get('language')
                    )
                    country = Donation.email_template_selection(data[0]).lower()
                    contact_customer = data[0].get('contact_customer', 'N')

                    props = {
                        'email': email
                    }

                    # if the request is approved send coupon to user
                    # otherwise send email saying that the request is rejected
                    if req['is_approved'] == 'N':
                        props['workflow_trigger'] = 'caifl_coupon_rejected'
                        if not shop_id:
                            # Update HubDB for Online Coupon
                            self.update_online_coupon_cell(email, 'rejected')
                    else:
                        """
                        If country is FR and shop_id is null
                        consider it as offline registration if contact_customer is Y .
                        consider it as online registration if contact_customer is N .
                        """
                        query = self.sql_file['pet_details_query']
                        self.cursor.execute(query, p_parent_id=req['pet_parent_id'])
                        pet_details = Code_util.iterate_data(self.cursor, convert_data=False)
                        if pet_details and len(pet_details):
                            pet_details[0]['email'] = email

                        # shop_id is null for online shops / coupons
                        if not shop_id and (country != 'fr' or (country == 'fr' and contact_customer == 'N')):
                            # check if the pet details have been changed before approval
                            # if they were changed, the previous coupon assigned to the applicant
                            # is cleared
                            # and a new coupon is assigned based on the updated pet details
                            coupon_result = self.check_online_coupon_conditions(pet_details[0])
                            if coupon_result.get('status') == 0 and coupon_result.get(
                                    'store_name') \
                                    and coupon_result.get('coupon_link') and coupon_result.get(
                                    'coupon_code'):
                                props['store_name'] = coupon_result['store_name']
                                props['store_url'] = coupon_result['coupon_link']
                                props['coupon_code'] = coupon_result['coupon_code']
                            else:
                                pob = POB()
                                # Get Store_name, store_link & Coupon_code for assigned_email
                                query = Donation.get_query(email)
                                coupon_store_data = pob.get_table_data(self.online_coupons_tbl,
                                                                       query=query, include_id=True)
                                # Send Store_name, store_link & Coupon_code in email
                                if len(coupon_store_data) > 0:
                                    props['store_name'] = coupon_store_data[0]['store_name']
                                    props['store_url'] = coupon_store_data[0]['store_link']
                                    props['coupon_code'] = coupon_store_data[0]['coupon_code']

                            props['workflow_trigger'] = 'caifl_online_coupon'
                            self.update_online_coupon_cell(email, 'approved')
                        else:
                            # in case of offline shop generate coupon PDF and send in email

                            coupon_data = {
                                'pet_type': pet_details[0]['pet_type'],
                                'pet_age': pet_details[0]['pet_age'],
                                'pet_size': pet_details[0]['pet_size'],
                                'name': name,
                                'coupon_code': data[0]['coupon_code'],
                                'shop_address': data[0]['shop_address'],
                                'expiry_date': data[0]['expiry_date'],
                                'shop_name': data[0]['shop_name'].replace('\\', ''),
                                'user_name': ' '.join(
                                    [data[0]['first_name'], data[0]['last_name']]),
                                'country': country
                            }

                            self.generate_coupon_pdf(coupon_data)
                            file_name = data[0]['coupon_code'] + '.pdf'
                            file_path = self.COUPONS_FOLDER
                            status = Donation.upload_file('/tmp/' + file_name, file_path)
                            if 'url' not in status:
                                result['msg'] += self.FAILED_HUBSPOT_UPLOAD
                            else:
                                props['file'] = status['url']
                            if coupon_data['country'] == 'ca':
                                coupon_data['country'] = 'ca_fr'
                                coupon_data['coupon_code'] = coupon_data['coupon_code'] + '-FR'
                                self.generate_coupon_pdf(coupon_data)
                                additional_coupon_file_name = data[0]['coupon_code'] + \
                                    '-FR' + '.pdf'
                                status = Donation.upload_file(
                                    '/tmp/' + additional_coupon_file_name, file_path)
                                if 'url' not in status:
                                    result['msg'] += '. Failed to upload FR coupon file to HubSpot'
                                else:
                                    props['coupon_pdf_additional'] = status['url']
                                coupon_data['country'] = 'ca'

                            # if country is FR and user wants to be contacted by AFD team change
                            # workflow
                            if country == 'fr' and contact_customer == 'Y':
                                props['workflow_trigger'] = 'caifl_fr_adf_offline_coupon_approved'

                                full_name = ' '.join([data[0].get('first_name', ''),
                                                      data[0].get('last_name', '')])
                                subject = str(self.sql_file['coupon_approved_subject_for_afd'],
                                              'utf-8')
                                subject = subject.format(full_name, int(req['pet_parent_id']))
                                mail_data = {
                                    'recipients': self.strings['afd_distributor'],
                                    'template_id': 1111467,
                                    'subject': subject,
                                    'params': [
                                        {
                                            'key': 'pet_parent',
                                            'value': full_name
                                        },
                                        {
                                            'key': 'adopted_date',
                                            'value': pet_details[0]['adoption_date']
                                        },
                                        {
                                            'key': 'pet_name',
                                            'value': pet_details[0]['pet_name']
                                        },
                                        {
                                            'key': 'pet_age',
                                            'value': pet_details[0]['pet_age']
                                        },
                                        {
                                            'key': 'pet_size',
                                            'value': pet_details[0]['pet_size'] or '-'
                                        },
                                        {
                                            'key': 'pet_type',
                                            'value': pet_details[0]['pet_type']
                                        },
                                        {
                                            'key': 'phone',
                                            'value': data[0]['telephone']
                                        },
                                        {
                                            'key': 'address',
                                            'value': data[0]['address'] +
                                            ', ' + data[0]['postal_code']
                                        },
                                        {
                                            'key': 'association_name',
                                            'value': pet_details[0]['association_name'].replace(
                                                '\\', '')
                                        },
                                        {
                                            'key': 'email_address',
                                            'value': data[0]['email']
                                        },
                                        {
                                            'key': 'contact_by',
                                            'value': data[0]['contact_by']
                                        },
                                        {
                                            'key': 'pdf_link',
                                            'value': props['file'] or ''
                                        },
                                        {
                                            'key': 'city',
                                            'value': data[0]['city'] or ''
                                        }
                                    ]
                                }
                                email_status = CommonUtils.send_mail(mail_data)
                                if email_status != 'SUCCESS':
                                    result['msg'] += '. ' + email_status + ''
                                else:
                                    result['msg'] += ' and sent email to AFD distrubutors'
                            else:
                                props['workflow_trigger'] = 'caifl_offline_coupon'
                        if shop_id and (data[0]['country'] == 'CA' or
                                        (data[0]['country'] == 'IT' and req.get('send_email_to_shop') == 'Y')):
                            result['msg'] += self.send_email_to_shop(req.get('cc', ''),
                                                                     shop_id, coupon_data, data[0]['language'])

                    # update contact property 'workflow_trigger' in HubSpot
                    # to automatically send email to pet parent
                    cms = CMS()
                    status = cms.create_contact(props)
                    if 'status' in status:
                        result['msg'] += '. Failed to send email to user'
                        logger.findaylog("""@ models - donation - change_coupon_status -
                                    {} - {}""".format(result['msg'], props))

                    # if it is offline application approval check file property value after approval
                    if req['is_approved'] == 'Y' and (shop_id or (country == 'fr' and contact_customer == 'Y')):
                        self.validate_file_property(email, req['pet_parent_id'],
                                                    data[0]['contact_by'], data[0]['country'])
            else:
                result = {
                    'status': 1,
                    'msg': 'Error updating coupon status - ' + str(status_code.getvalue())
                }
                logger.findaylog("""@ models - donation - change_coupon_status -
                         {}""".format(result['msg']))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                change_coupon_status """ + str(e))
            raise e
        logger.addinfo('@ models - donation - change_coupon_status(-)')
        return result

    @staticmethod
    def is_base64(data):
        if not (base64.b64encode(base64.b64decode(data)) == data):
            encoded_string = (base64.b64encode(data))
        else:
            encoded_string = (data)

        return encoded_string

    def get_acaifl_attachment(self, file_id):
        logger.addinfo('@ models - donation - get_acaifl_attachment(+)')
        try:
            common_utils_obj = CommonUtils()
            result = common_utils_obj.get_attachment_data('file_data',
                                                          'qpex_acaifl_attachments',
                                                          'file_id',
                                                          file_id)
            if result:
                result = {'file_data': Donation.is_base64(result).decode('utf-8')}
            else:
                result = {
                    'status': 1,
                    'msg': 'File with ID {0} not found'.format(file_id)
                }
                logger.findaylog("""@ models - donation - get_acaifl_attachment -
                         {}""".format(result['msg']), send_email=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                    get_acaifl_attachment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - donation - get_acaifl_attachment(-)')
        return result

    def create_lovefood_application(self, req):
        logger.addinfo('@ models - donation - create_lovefood_application(+)')
        try:
            self.acquire()
            request_id = self.cursor.var(cx_Oracle.NUMBER)
            application_no = self.cursor.var(cx_Oracle.STRING)
            status_code = self.cursor.var(cx_Oracle.STRING)
            req['country'], req['language'] = get_country_and_language(
                req.get('country'), req.get('language'))
            self.cursor.execute("""
                begin
                    qpex_donation_pkg.create_lovefood_application(
                        :p_org_id,
                        :p_request_id,
                        :p_request_type,
                        :p_is_copy,
                        :p_created_by,
                        :x_request_header_id,
                        :x_application_no,
                        :x_status_code
                    );
                end; """, p_org_id=req['org_id'],
                                p_request_id=req['request_header_id'],
                                p_request_type=req['request_type'],
                                p_is_copy=req['is_copy'],
                                p_created_by=req['user_id'],
                                x_request_header_id=request_id,
                                x_application_no=application_no,
                                x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                req['application_no'] = application_no.getvalue()
                req['request_id'] = request_id.getvalue()
                req['request_header_id'] = req['request_id']
                req['appl_count'] = 2
                if req['is_copy'] == 'Y':
                    msg = 'Application copied successfully'
                else:
                    request_types = {
                        'A': 'AdoptMe',
                        'L': 'LoveFood',
                        'H': 'Humans & Wild Life',
                        'LB': 'LoveFood Bank'
                    }
                    msg = '{} application created successfully' \
                        .format(request_types.get(req['request_type']))
                result = {
                    'status': 0,
                    'msg': msg,
                    'request_id': req['request_id'],
                    'application_no': req['application_no']
                }

                self.prepare_notification(req, notify_user=False)
            else:
                result = {
                    'status': 1,
                    'msg': 'Error creating LoveFood application - ' + str(status_code.getvalue())
                }
                logger.findaylog("""@ models - donation - create_lovefood_application -
                                        {}""".format(result['msg']))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - donation -
                create_lovefood_application """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - donation - create_lovefood_application(-)')
        return result

    def manage_campaign_coupons(self, req):
        logger.addinfo('@ models - donation - manage_campaign_coupons(+)')
        try:
            table_id = self.campaign_coupons_tbl
            country = req['country']
            offer_type = req['offer_type']
            query = '&country={0}&offer_type={1}&status__is_null=true'
            query = query.format(country, offer_type)

            try:
                pob = POB()
                data = pob.get_table_data(table_id, query=query, include_id=True)

                if 'status' not in data and len(data) > 0:
                    coupon_data = data[0]
                    coupon_link = coupon_data['coupon_link']
                    coupon_row_id = coupon_data['rowid']

                    query = '&hs_id={0}'.format(coupon_row_id)
                    row_data = pob.get_table_data(table_id, query=query, include_id=True)
                    if 'status' not in row_data and len(row_data) > 0:
                        if not row_data[0]['status'] and \
                                not row_data[0]['user_email']:
                            schema = pob.get_table_schema(table_id, raw_data=True)

                            pob.update_cell_value(table_id, schema, {
                                'rowid': coupon_row_id,
                                'user_email': req['email'],
                                'status': 'email_sent',
                                'modified_date': str(datetime.now())
                            })

                            pob.publish_table(table_id)

                            props = {
                                'firstname': req['first_name'],
                                'lastname': req['last_name'],
                                'email': req['email'],
                                'coupon_code': coupon_link,
                                'coupon_type': 'online',
                                'campaign_name': 'IT-HOLISTIC-' + req['offer_type'],
                                'country': country,
                                'hs_persona': 'persona_49',
                                'campaign_coupon_error': '',
                                'workflow_trigger': 'it_campaign_online_coupon'
                            }

                            # Send pet_type property to hubspot only if request has pet_type details
                            if 'pet_type' in req:
                                props['pet_type'] = req['pet_type']

                            cms = CMS()
                            cms.create_contact(props)

                            result = {
                                'status': 1,
                                'msg': 'User data saved successfully!'
                            }
                        else:
                            self.manage_campaign_coupons(req)
                    else:
                        result = Donation.handle_coupon_error(req)
                else:
                    result = Donation.handle_coupon_error(req)

            except IndexError:
                result = Donation.handle_coupon_error(req)

        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - donation -
                    manage_campaign_coupons """ + str(e))
            raise e
        logger.addinfo('@ models - donation - manage_campaign_coupons(-)')
        return result

    def delete_cafl_attachment(self, file_id):
        logger.addinfo('@ models - donation - delete_cafl_attachment(+)')
        result = dict()
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_donation_pkg.delete_cafl_attachment(
                        :p_file_id,
                        :x_status_code
                    );
                end; """, p_file_id=file_id,
                             x_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    result['status'] = 0
                    result['msg'] = 'Attachment deleted successfully'
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to delete attachment - ' + str(status)
                    logger.findaylog("""@ models - donation - delete_cafl_attachment -
                             {}""".format(result['msg']), send_email=False)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION - models - donation -
                delete_cafl_attachment(+)""" + str(e))
            raise e
        logger.addinfo('@ models - donation - delete_cafl_attachment(+)')
        return result

    def acaifl_update_association(self, req):
        logger.addinfo('@ models - donation - acaifl_update_association(+)')
        result = dict()
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_donation_pkg.update_acaifl_association(
                        :p_association_id,
                        :p_association_name,
                        :p_pet_id,
                        :x_status_code
                    );
                end; """, p_association_id=req['association_id'],
                             p_association_name=req['association_name'],
                             p_pet_id=req['pet_id'],
                             x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    result['msg'] = 'Association updated successfully'
                    result['status'] = 0
                else:
                    result['msg'] = 'Failed to update association'
                    result['status'] = 1
                    logger.findaylog("""@ models - donation - acaifl_update_association -
                            {}""".format(status_code.getvalue()))
        except Exception as e:
            logger.findaylog(""" @EXCEPTION models - donation -
                    acaifl_update_association """ + str(e))
            raise e
        logger.addinfo('@ models - donation - acaifl_update_association(+)')
        return result

    def delete_adoption(self, adoption_id):
        logger.addinfo('models - donation - delete_adoption(+)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_donation_pkg.delete_adoption(
                            :p_adoption_id,
                            :x_status_code
                    );
                end;""", p_adoption_id=adoption_id,
                             x_status_code=status_code)
                status = status_code.getvalue()
            if status == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Adoption deleted successfully'
                }
            else:
                result = {
                    'status': 1,
                    'msg': status
                }
                logger.findaylog("""@ models - donation - delete_adoption -
                                            {}""".format(status))
        except Exception as e:
            logger.findaylog(""" EXCEPTION - models - donation -
                                delete_adoption """ + str(e))
            raise e
        logger.addinfo('models - donation - delete_adoption(-)')
        return result

    @staticmethod
    def handle_coupon_error(req):
        props = {
            'firstname': req['first_name'],
            'lastname': req['last_name'],
            'email': req['email'],
            'country': req['country'],
            'hs_persona': 'persona_49',
            'campaign_coupon_error': 'email_sending_failed',
            'campaign_name': 'IT-HOLISTIC-' + req['offer_type']
        }

        cms = CMS()
        cms.create_contact(props)

        err_message = 'Failed to retrieve coupon data from DB, ' \
            'contact created in HubSpot with property ' \
            'campaign_coupon_error as email_sending_failed'
        logger.findaylog("""@ models - donation - manage_campaign_coupons -
                 {} - {}""".format(err_message, req))
        result = {
            'status': 0,
            'msg': 'Unable to fetch coupons, please try again later.'
        }

        return result

    def assign_coupon_code(self, req, retries=0):
        coupon_code = ''
        shop_name = ''
        shop_address = ''
        pob = POB()

        # build query to get coupons data for user country and selected pet details
        query = Donation.build_query(req)

        online_coupon_tbl_data = pob.get_table_data(self.online_coupons_tbl,
                                                    query=query, include_id=True)
        if len(online_coupon_tbl_data) > 0:
            coupon_data = online_coupon_tbl_data[0]
            if 'coupon_code' in coupon_data:
                coupon_code = coupon_data['coupon_code']
                shop_name = coupon_data['store_name']
                shop_address = coupon_data['store_link']
                self.update_online_coupon_cell(req['email'], 'assigned',
                                               row_id=coupon_data['rowid'])

                # Check coupons count and send email if coupons are completed for any combination
                self.check_coupons_count(req, len(online_coupon_tbl_data))

                # check if coupon is assigned to user email.
                # If coupon is not assigned wait for 1 second
                # and try to reassign up to max 5 attempts
                query = Donation.get_query(req['email'])
                table_row = pob.get_table_data(self.online_coupons_tbl, query=query,
                                               include_id=True)
                if not len(table_row):
                    retries += 1
                    if retries < 5:
                        rand_wait = random.randrange(1, 100) / 100.0
                        time.sleep(rand_wait)
                        self.assign_coupon_code(req, retries)
        return coupon_code, shop_name, shop_address

    def check_coupons_count(self, req, coupons_count):
        if coupons_count == 1:
            email_data = {
                'recipients': [
                    {
                        'Email': 'saikrishna@finday.com',
                        'Name': 'Saikrishna'
                    },
                    {
                        'Email': 'pardhu@finday.com',
                        'Name': 'Pardhu'
                    }
                ],
                'subject': self.strings['notify_coupons'],
                'template_id': 1140464,
                'params': [
                    {
                        'key': 'country',
                        'value': req.get('country', 'IT').upper()
                    },
                    {
                        'key': 'pet_type',
                        'value': req.get('pet_type', '').upper()
                    },
                    {
                        'key': 'pet_age',
                        'value': req.get('pet_age', '').upper()
                    },
                    {
                        'key': 'pet_size',
                        'value': req.get('pet_size', '').upper()
                    }
                ]
            }
            CommonUtils.send_mail(email_data)

    def get_products_lov(self):
        """
        To get all product details from view table
        :return:{'status': '' ,'products':''}
        """
        logger.addinfo('@ models - donation - get_products_lov(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_list_of_all_products']
                conn.execute(query)
                products = conn.get_result(convert_data=False)
            result = {
                'status': 0,
                'products': products
            }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_products_lov""" + str(error))
            raise error
        logger.addinfo('@ models - donation - get_products_lov(+)')
        return result

    def get_price_list_products(self, list_header_id):
        """
        To get products details from a specific price list
        :return:{'status': '' ,'products':''}
        """
        logger.addinfo('@ models - donation - get_price_list_products(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_price_list_products']
                conn.execute(query, p_list_header_id=list_header_id)
                products = conn.get_result()
            result = {
                'status': 0,
                'products': products
            }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                get_price_list_products""" + str(error))
            raise error
        logger.addinfo('@ models - donation - get_price_list_products(+)')
        return result

    def get_donation_product_mapping(self, is_active):
        """
        For getting all the products that are mapped for the donation applications
        :param is_active: string
        :return: {'status':'', 'products_map':''}
        """
        logger.addinfo('@ models - donation - get_donation_product_mapping(-)')
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_donation_product_mapping']
                conn.execute(query, p_is_active=is_active)
                donation_products = conn.get_result()
            result = {'status': 0, 'products_map': donation_products}
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                            get_donation_product_mapping""" + str(error))
            raise error
        logger.addinfo('@ models - donation - get_donation_product_mapping(+)')
        return result

    def regenerate_offline_coupon(self, coupon_data):
        """
            For regenerating and assigning the coupon for offline CAFL pet parent applications
            :param coupon_data: object with required coupon details
            :return: {'status':'', 'msg':''}
        """
        logger.addinfo('@ models - donation - regenerate_offline_coupon(-)')
        result = {'status': 1}
        try:
            self.generate_coupon_pdf(coupon_data)
            file_name = coupon_data.get('coupon_code') + '.pdf'
            email = coupon_data.get('email')
            # upload the file to HubSpot and add the URL to
            # contact property
            pob = POB()
            status = pob.upload_file('/tmp/' + file_name, self.COUPONS_FOLDER)
            if 'url' not in status:
                result['msg'] += self.FAILED_HUBSPOT_UPLOAD
            else:
                if coupon_data['country'] == 'ca_fr':
                    result_pdf_property = 'coupon_pdf_additional'
                    contact_pdf_property = 'coupon_pdf_additional'
                else:
                    result_pdf_property = 'coupon_pdf'
                    contact_pdf_property = 'file'
                result[result_pdf_property] = status['url']
                result['status'] = 0
                cms_obj = CMS()
                # check if the contact property 'file' already exists
                # if it does, there is no need to update it, as the HubSpot path
                # where the pdf is saved is generated based on the coupon code, which remains the
                # same
                file_url_exists = Donation.parse_contact_properties(email)
                file_url_exists = file_url_exists.get('file')
                if not file_url_exists:
                    contact_props = {
                        'email': email
                    }
                    contact_props[contact_pdf_property] = status['url']
                    contact_status = cms_obj.create_contact(contact_props)
                    if 'status' in contact_status and contact_status.get('status') == 'error':
                        result['msg'] = 'Coupon pdf uploaded to HubSpot'
                        result['msg'] += ' but failed to update contact property'

                if result['status'] == 0:
                    result['msg'] = 'Coupon regenerated successfully'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                                    regenerate_offline_coupon""" + str(error))
            raise error
        logger.addinfo('@ models - donation - regenerate_offline_coupon(+)')
        return result

    def regenerate_online_coupon(self, coupon_data):
        """
            For regenerating and assigning the coupon for online CAFL pet parent applications
            :param coupon_data: object with required coupon details
            :return: {'status':'', 'msg':''}
        """
        logger.addinfo('@ models - donation - regenerate_offline_coupon(-)')
        result = {'status': 1}
        try:
            with OracleConnectionManager() as conn:
                email = coupon_data.get('email')
                cms_obj = CMS()
                pob = POB()
                failed_attrs = []
                if coupon_data.get('row_id'):
                    online_coupon_tbl_schema = pob.get_table_schema(self.online_coupons_tbl, True)
                    # clear the existing coupon mapping for the contact in HubDB
                    failed_attrs = pob.update_cell_value(self.online_coupons_tbl,
                                                         online_coupon_tbl_schema, {
                                                             'rowid': coupon_data.get('row_id'),
                                                             'assigned_email': '',
                                                             'assigned_date': '',
                                                             'status': '',
                                                             'approved_date': ''
                                                         })

                # assign a new coupon to the contact in HubSpot based on the pet details
                coupon_code, shop_name, shop_address = self.assign_coupon_code(coupon_data)
                query = self.sql_file['update_coupon_code']
                # update the newly generated coupon details
                # in the coupon details table of the database too
                conn.execute(query, p_coupon_code=coupon_code, p_shop_name=shop_name,
                             p_shop_address=shop_address,
                             p_pet_parent_id=coupon_data.get('pet_parent_id'),
                             p_pet_id=coupon_data.get('pet_id'))
                contact_props = {
                    'email': email,
                    'coupon_code': coupon_code,
                    'store_url': shop_address,
                    'store_name': shop_name
                }
                # update the contact properties
                contact_status = cms_obj.create_contact(contact_props)

                # change the status of the newly assigned coupon to approved
                # this is done because the user will receive a mail with the coupon details
                # after regeneration. Similar to a user receiving the coupon email on approval
                self.update_online_coupon_cell(email, 'approved')

                if len(failed_attrs) == 0:
                    if conn.cursor.rowcount == 1:
                        result['status'] = 0
                        result['msg'] = 'Coupon regenerated successfully'
                    else:
                        result['msg'] = 'Coupon link updated in HubSpot ' \
                            + 'but failed to updated coupon details in the database'
                        logger.findaylog("""@ models - donation - regenerate_online_coupon -
                                         {}""".format(result['msg']))
                elif conn.cursor.rowcount == 0:
                    result['msg'] = 'Coupon regenerated and reassigned successfully ' \
                        + 'but previously assigned coupon is not reset in HubSpot'
                    logger.findaylog("""@ models - donation - regenerate_online_coupon -
                                    {}""".format(result['msg']))
                    result['previous_coupon_row_id'] = coupon_data.get('row_id')
                if 'status' in contact_status and contact_status.get('status') == 'ERROR':
                    result['status'] = 1
                    result['msg'] += '. Failed to update contact properties for online coupon.'
                    logger.findaylog("""@ models - donation - regenerate_online_coupon -
                                                             {}""".format(result['msg']))
                else:
                    result['coupon_link'] = shop_address
                    result['coupon_code'] = coupon_code
                    result['store_name'] = shop_name
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                                    regenerate_online_coupon""" + str(error))
            raise error
        logger.addinfo('@ models - donation - regenerate_online_coupon(+)')
        return result

    def resend_coupon_mail(self, data):
        """
            For resending the coupon emails for online/offline CAFL pet parent applications
            :param data: {'shop_type':'', 'pet_parent_id':'', 'contact_by':''}
            :return: {'status':'', 'msg':''}
        """
        logger.addinfo('@ models - donation - resend_coupon_mail(+)')
        result = {'status': 0}
        try:
            with OracleConnectionManager() as conn:
                # fetch the pet parent details
                query = self.sql_file['pet_parent_query']
                conn.execute(query, p_pet_parent_id=data['pet_parent_id'])
                pet_parent_data = conn.get_result(convert_data=False)
                pet_parent_data = pet_parent_data[0] if len(pet_parent_data) else {}

                pet_parent_data['country'], pet_parent_data['language'] = get_country_and_language(
                    pet_parent_data.get('country'),
                    pet_parent_data.get('language'))

                country = Donation.email_template_selection(pet_parent_data)
                email = pet_parent_data.get('email')
                # fetch the pet details
                query = self.sql_file['pet_details_query']
                conn.execute(query, p_parent_id=data['pet_parent_id'])
                pet_details = conn.get_result(convert_data=False)
                pet_details = pet_details[0] if len(pet_details) else {}
                pet_details['country'] = pet_parent_data.get('country')
                # applications without 'shop_id' or belonging to France are considered offline
                if data['shop_type'] == 'OFFLINE' \
                        and (pet_parent_data.get('shop_id') or country.lower() == 'fr'):
                    coupon_data = {
                        'pet_type': pet_details.get('pet_type'),
                        'pet_age': pet_details.get('pet_age'),
                        'pet_size': pet_details.get('pet_size'),
                        'name': pet_parent_data.get('first_name'),
                        'coupon_code': pet_parent_data.get('coupon_code'),
                        'shop_address': pet_parent_data.get('shop_address'),
                        'expiry_date': pet_parent_data.get('expiry_date'),
                        'shop_name': pet_parent_data.get('shop_name'),
                        'user_name': ' '.join(
                            [pet_parent_data.get('first_name'), pet_parent_data.get('last_name')]),
                        'country': country.lower(),
                        'email': email
                    }
                    result = self.regenerate_offline_coupon(coupon_data)

                    if coupon_data['country'].lower() == 'ca':
                        coupon_data['country'] = 'ca_fr'
                        coupon_data['coupon_code'] = coupon_data['coupon_code'] + '-FR'
                        ca_result = self.regenerate_offline_coupon(coupon_data)
                        result['coupon_pdf_additional'] = ca_result['coupon_pdf_additional']
                        coupon_data['country'] = 'ca'
                elif not pet_parent_data.get('shop_id'):
                    pet_details['email'] = email
                    result = self.check_online_coupon_conditions(pet_details)

                if result['status'] == 0:
                    cms_obj = CMS()
                    contact_props = {
                        'email': email,
                        'file': result.get('coupon_pdf') or '',
                        'coupon_pdf_additional': result.get('coupon_pdf_additional') or ''
                    }
                    cms_obj.create_contact(contact_props)
                    workflow_id = Donation.get_cafl_workflow_id(
                        data.get('shop_type'), data.get('contact_by'))
                    enroll_status = cms_obj.enroll_into_workflow(workflow_id, email)
                    enroll_result = Donation.get_workflow_result(enroll_status, result, data)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                    resend_coupon_mail """ + str(error))
            raise error
        logger.addinfo('@ models - donation - resend_coupon_mail(-)')
        return enroll_result

    @staticmethod
    def get_workflow_result(enroll_status, result, data):
        if enroll_status.get('status') == 'error':
            result['status'] = 1
            result['msg'] += ' but error occured while enrolling into the workflow: ' \
                             + enroll_status['message']
            logger.findaylog("""@ models - donation - resend_coupon_mail -
                                                     {}""".format(result['msg']))
        else:
            result['msg'] += ' and coupon mail sent to the user'
            json = {
                'pet_parent_id': data['pet_parent_id'],
                'coupon_pdf': result.get('coupon_pdf') or '',
                'coupon_pdf_additional': result.get('coupon_pdf_additional') or ''
            }
            Donation.update_pdf_links(json)
        return result

    def check_online_coupon_conditions(self, pet_details):
        """
            Check if the coupon has to be regenerated or if only the contact properties
            have to updated with the coupon details
            :param pet_details: {"email":"", "pet_type":"", "pet_size":"",
            "pet_age":""}
            :return: {"status":"", "msg":""}
        """
        logger.addinfo('@ models - donation - check_online_coupon_conditions(-)')
        result = {'status': 0}
        try:
            pob = POB()
            email = pet_details.get('email')
            # get the existing coupon assigned to the contact/pet parent from HubSpot
            query = Donation.get_query(email)
            coupon_store_data = pob.get_table_data(self.online_coupons_tbl,
                                                   query=query, include_id=True)
            coupon_store_data = coupon_store_data[0] if len(coupon_store_data) else None

            # cats will not have pet size so assign an empty value
            if not pet_details.get('pet_size'):
                pet_details['pet_size'] = ''
            if coupon_store_data and not coupon_store_data.get('pet_size'):
                coupon_store_data['pet_size'] = ''

            # check if the pet details in database and HubSpot coupons table are same
            if coupon_store_data and pet_details.get('pet_type').lower() == coupon_store_data.get(
                'pet_type').lower() \
                and pet_details.get('pet_size').lower() == coupon_store_data.get(
                    'pet_size').lower() \
                and pet_details.get('pet_age').lower() == coupon_store_data.get(
                    'pet_age').lower():

                result['msg'] = 'Request was successful'
                # check if the coupon details are assigned to the contact, if not update them
                contact_status = Donation.assign_coupon_to_contact(email, coupon_store_data)
                if 'status' in contact_status:
                    result['status'] = 1
                    result['msg'] = 'Failed to send coupon email as '
                    result['msg'] += 'contact properties could not be updated'
                else:
                    result['coupon_link'] = coupon_store_data.get('store_link')
                    result['coupon_code'] = coupon_store_data.get('coupon_code')
                    result['store_name'] = coupon_store_data.get('store_name')
            else:
                # regenerate and re-assign coupon only if pet details have been changed
                pet_details['row_id'] = coupon_store_data.get(
                    'rowid') if coupon_store_data else None
                pet_details['email'] = email
                result = self.regenerate_online_coupon(pet_details)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                            check_online_coupon_conditions""" + str(error))
            raise error
        logger.addinfo('@ models - donation - check_online_coupon_conditions(+)')
        return result

    @staticmethod
    def assign_coupon_to_contact(email, assigned_coupon_data):
        logger.addinfo('@ models - donation - assign_coupon_to_contact(-)')
        result = {}
        try:
            contact_properties = Donation.parse_contact_properties(email)
            # if the coupon is assigned to the user in coupons table
            # but the contact properties were not updated, update them
            if not contact_properties.get('coupon_code') or not contact_properties.get(
                    'store_url') or not contact_properties.get('store_name'):
                contact_props = {'coupon_code': assigned_coupon_data.get('coupon_code'),
                                 'store_name': assigned_coupon_data.get('store_name'),
                                 'store_url': assigned_coupon_data.get('store_link'),
                                 'email': email}
                cms_obj = CMS()
                result = cms_obj.create_contact(contact_props)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                        assign_coupon_to_contact""" + str(error))
            raise error
        logger.addinfo('@ models - donation - assign_coupon_to_contact(+)')
        return result

    @staticmethod
    def insert_product_map(method, request_data):
        """
        For inserting a new row in donation product mapping or
        updating product status
        :param method: POST/PUT
        :param request_data: {"item_code":"","inventory_item_id": "",
            "pet_type":"","pet_size":"","qty_per_pet":"", "donation_type":"",
            "created_by":"", "is_active":"", "price_list_id":""}
        :return: {"status":"", "msg":""}
        """
        logger.addinfo('@ models - donation - insert_product_map(-)')
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                BEGIN
                    QPEX_DONATION_PKG.update_donation_product_map(
                    :p_item_code,
                    :p_inventory_item_id,
                    :p_pet_type,
                    :p_pet_size,
                    :p_qty_per_pet,
                    :p_created_by,
                    :p_donation_type,
                    :p_is_active,
                    :p_price_list_id,
                    :p_weight_per_meal,
                    :p_no_of_meals,
                    :p_no_of_days,
                    :x_status_code
                    );
                END;""", p_item_code=request_data['item_code'],
                             p_inventory_item_id=request_data['inventory_item_id'],
                             p_pet_type=request_data['pet_type'],
                             p_pet_size=request_data.get('pet_size', ''),
                             p_qty_per_pet=request_data.get('qty_per_pet', 1),
                             p_created_by=request_data.get('created_by', -1),
                             p_donation_type=request_data['donation_type'],
                             p_is_active=request_data.get('is_active', 'Y'),
                             p_price_list_id=request_data.get('price_list_id'),
                             p_weight_per_meal=request_data.get('weight_per_meal'),
                             p_no_of_meals=request_data.get('no_of_meals'),
                             p_no_of_days=request_data.get('no_of_days'),
                             x_status_code=status_code
                             )
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Product Mapping {0} successfully'.format(
                              'inserted' if method == 'POST' else 'updated')}
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Failed to {0} product map'.format(
                              'insert' if method == 'POST' else 'updated')}
                logger.findaylog("""@ models - donation - insert_product_map -
                        {} - {}""".format(result['msg'], status_code.getvalue()))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                    insert_product_map""" + str(error))
            raise error
        logger.addinfo('@ models - donation - insert_product_map(+)')
        return result

    @staticmethod
    def get_query(email):
        return '&assigned_email=' + urllib.parse.quote(email)

    @staticmethod
    def build_query(req):
        query = '&status__is_null=true&pet_type='
        if req.get('pet_type', '').lower() == 'cat':
            query += 'CAT&pet_age='
            if req.get('pet_age', '').lower() == 'kitten':
                query += 'KITTEN'
            else:
                query += 'ADULT'
        else:
            query += 'DOG&pet_age='
            if req.get('pet_age', '').lower() == 'puppy':
                query += 'PUPPY'
            else:
                query += 'ADULT'
            query += '&pet_size=' + req.get('pet_size', '').upper()
        query += '&language=' + req.get('country', 'IT').upper()
        return query

    def restart_workflow(self, req):
        logger.addinfo('@ models - donation - restart_workflow(+)')
        try:
            with OracleConnectionManager() as connection:
                query = self.sql_file['donation_notification_query']
                connection.cursor.execute(query, p_header_id=req['header_id'],
                                          p_org_id=req['org_id'])
                result = connection.get_result(convert_data=False)
                if result:
                    status = connection.cursor.var(cx_Oracle.STRING)
                    connection.execute('''
                    begin
                        qpex_donation_pkg.restart_workflow(
                            :p_header_id,
                            :p_workflow_name,
                            :x_status_code
                        );
                    end; ''', p_header_id=req['header_id'],
                                       p_workflow_name=req['wf_name'],
                                       x_status_code=status)
                    if status.getvalue() == 'SUCCESS':
                        result[0]['wf_name'] = req['wf_name']
                        self.prepare_notification(result[0], notify_user=False)
                        result = {
                            'status': Status.OK.value,
                            'msg': 'Workflow restarted successfully'
                        }
                    else:
                        result = {
                            'status': Status.ERROR.value,
                            'msg': 'Failed to restart workflow => {}'.format(
                                str(status.getvalue()))
                        }
                        logger.findaylog("""@ models - donation - restart_workflow -
                                {}""".format(result['msg']))
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - donation -
                restart_workflow ''' + str(error))
            raise error
        logger.addinfo('@ models - donation - restart_workflow(-)')
        return result

    def acaifl_update_contact_email(self, req):
        logger.addinfo('@ models - donation - acaifl_update_contact_email(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                # get the contact id of the user
                contact_id = Donation.parse_contact_properties(req['email'])
                contact_id = contact_id.get('contact_id')
                if contact_id:
                    status_code = conn.cursor.var(cx_Oracle.STRING)
                    # update the email for pet parent in database
                    conn.execute("""
                    begin
                        qpex_donation_pkg.update_acaifl_email_address(
                            :p_pet_parent_id,
                            :p_email,
                            :p_recent_update_user_id,
                            :x_status_code
                        );
                    end; """, p_pet_parent_id=req['pet_parent_id'],
                                 p_email=req['new_email'],
                                 p_recent_update_user_id=req['recent_update_user_id'],
                                 x_status_code=status_code)
                    contact_props = {
                        'email': req['new_email']
                    }
                    # update the contacts email in HubSpot
                    cms_obj = CMS()
                    contact_status = cms_obj.create_contact(contact_props, contact_id)
                    if status_code.getvalue() == 'SUCCESS':
                        result['msg'] = 'Email address updated successfully'
                        if 'status' not in contact_status and req['shop_type'] == 'ONLINE':
                            self.update_email_in_coupons_table(req)
                            result['status'] = 0
                        elif 'status' not in contact_status and req['shop_type'] == 'OFFLINE':
                            result['status'] = 0
                        else:
                            result['msg'] = 'Email address updated in database '
                            result['msg'] += 'but failed to update contact property'
                            result['status'] = 1
                    elif 'status' not in contact_status:
                        result['msg'] = 'Contact property is updated '
                        result['msg'] += 'but failed to update email in database'
                        result['status'] = 1
                    else:
                        result['msg'] = 'Failed to update email address'
                        result['status'] = 1
                else:
                    result['msg'] = 'Contact not found in HubSpot'
                    result['status'] = 1
            if result['status'] == 1:
                logger.findaylog("""@ models - donation - acaifl_update_contact_email -
                            {}""".format(result['msg']))
        except Exception as e:
            logger.findaylog(""" @EXCEPTION models - donation -
                        acaifl_update_contact_email """ + str(e))
            raise e
        logger.addinfo('@ models - donation - acaifl_update_contact_email(+)')
        return result

    def update_email_in_coupons_table(self, req):
        logger.addinfo('@ models - donation - update_email_in_coupons_table(+)')
        try:
            pob = POB()
            online_coupon_tbl_schema = pob.get_table_schema(self.online_coupons_tbl, True)
            query = Donation.get_query(req['email'])
            # update the email in online coupons table too
            table_row = pob.get_table_data(self.online_coupons_tbl, query=query, include_id=True)
            if len(table_row) > 0:
                row_id = table_row[0]['rowid']
                pob.update_cell_value(self.online_coupons_tbl, online_coupon_tbl_schema, {
                    'rowid': row_id,
                    'assigned_email': req['new_email']
                })
                pob.publish_table(self.online_coupons_tbl)
        except Exception as e:
            logger.findaylog(""" @EXCEPTION models - donation -
                        update_email_in_coupons_table """ + str(e))
            raise e
        logger.addinfo('@ models - donation - update_email_in_coupons_table(+)')

    # If file property is not updated, update and resend email to user
    def validate_file_property(self, email, pet_parent_id, contact_by, country, no_of_attempts=0):
        coupon_data = Donation.parse_contact_properties(email)
        if not coupon_data.get('file') or (country == 'CA' and not coupon_data.get('coupon_pdf_additional')):
            no_of_attempts += 1
            self.resend_coupon_mail(
                {
                    'shop_type': 'OFFLINE',
                    'pet_parent_id': pet_parent_id,
                    'contact_by': contact_by
                }
            )
            if no_of_attempts < 5:
                self.validate_file_property(
                    email, pet_parent_id, contact_by, country, no_of_attempts)
        else:
            json = {
                'pet_parent_id': pet_parent_id,
                'coupon_pdf': coupon_data.get('file', ''),
                'coupon_pdf_additional': coupon_data.get('coupon_pdf_additional', '')
            }
            Donation.update_pdf_links(json)

    def change_application_status_from_mail(self, data):
        """
        Approve/Reject an application from donation emails
        Note: This option is not available for first approvers as they have to
        verify the shipping address before approving applications

        """
        logger.addinfo('@ models - donation - change_application_status_from_mail(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_current_donation_approver']
                conn.execute(query, p_application_no=data.get('appl_no'),
                             p_workflow_name=data.get('wf_name'))
                current_approver_id = conn.get_result(convert_data=False)

                # check if the current approver for the application is same as the user who is
                # performing approve/reject actions. If yes perform approve/reject actions
                if len(current_approver_id) \
                        and current_approver_id[0].get('current_approver') == data.get('user_id'):
                    result = self.application_status(data)
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to ' + (
                        'approve' if data['status'] == 'A' else 'reject')
                    result['msg'] += ' the application as ' + data[
                        'user'] + ' is not the current approver'
                    logger.findaylog(""" models - donation - change_application_status_from_mail
                    - {}""".format(result['msg']))
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - donation -
                           change_application_status_from_mail ''' + str(error))
            raise error
        logger.addinfo('@ models - donation - change_application_status_from_mail(-)')
        return result

    def get_sales_agents(self, jsond):
        site_id = None
        sales_agents_data = []
        query = self.sql_file['get_shop_site_id']
        with OracleConnectionManager() as conn:
            # get site_id from shop name, address and customer_id
            conn.execute(query, p_shop_name=jsond['shop_name'],
                         p_address=jsond['address'].split(',')[0],
                         p_shop_id=jsond['customer_id'])
            shop_details = conn.get_single_result()
            query = self.sql_file['get_sales_agents']
            if shop_details:
                site_id = shop_details['site_id']
                conn.execute(query, p_site_id=site_id,
                             p_city='')
                sales_agents_data = conn.get_result()
            # Get the sales agent by city if site_id is not mapped to any sales agent or shop has no site_id
            if not len(sales_agents_data) or not site_id:
                conn.execute(query, p_city=jsond['city'],
                             p_site_id=None)
                sales_agents_data = conn.get_result()
                filtered_by = 'city'
            else:
                filtered_by = 'shop_id'

            sales_rep_ids = ','.join(["'" + str(agent['salesrep_id']) +
                                      "'" for agent in sales_agents_data])
            sales_rep_ids = sales_rep_ids or 'p.reference_value'

            # get sales agents email and related back office emails
            query = self.sql_file['get_sales_back_office_emails']
            conn.execute(query % sales_rep_ids)
            sales_back_office = conn.get_result()
            result = {
                'filtered_by': filtered_by,
                'sales_back_office': sales_back_office,
                'shop_email': '',
                'shop_user_name': ''
            }
            # get shop email
            query = self.sql_file['get_shop_email']
            conn.execute(query, p_shop_id=jsond['customer_id'])
            shop_user = conn.get_single_result()
            if shop_user:
                result['shop_email'] = shop_user['email_address']
                result['shop_user_name'] = shop_user['user_description']
        return result

    @staticmethod
    def acaifl_update_shop_address(req):
        logger.addinfo('@ models - donation - acaifl_update_shop_address(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_donation_pkg.update_acaifl_shop_address(
                        :p_coupon_code,
                        :p_pet_parent_id,
                        :p_shop_id,
                        :p_shop_name,
                        :p_shop_address,
                        :p_recent_update_user_id,
                        :x_status_code
                    );
                end; """, p_coupon_code=req['coupon_code'],
                             p_pet_parent_id=req['pet_parent_id'],
                             p_shop_id=req['shop_id'],
                             p_shop_name=req['shop_name'],
                             p_shop_address=req['shop_address'],
                             p_recent_update_user_id=req['recent_update_user_id'],
                             x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    result['msg'] = 'Shop Address updated successfully'
                    result['status'] = 0
                else:
                    result['msg'] = 'Failed to update Shop Address'
                    result['status'] = 1
                    logger.findaylog("""@ models - donation - acaifl_update_shop_address -
                                {}""".format(status_code.getvalue()))
        except Exception as e:
            logger.findaylog(""" @EXCEPTION models - donation -
                        acaifl_update_shop_address """ + str(e))
            raise e
        logger.addinfo('@ models - donation - acaifl_update_shop_address(+)')
        return result

    @staticmethod
    def acaifl_update_pet_details(req):
        logger.addinfo('@ models - donation - acaifl_update_pet_details(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_donation_pkg.update_acaifl_pet_details(
                        :p_pet_id,
                        :p_pet_name,
                        :p_pet_age,
                        :p_pet_size,
                        :p_pet_type,
                        :p_pet_dob,
                        :p_pet_gender,
                        :p_association_id,
                        :p_association_name,
                        :p_town,
                        :p_association_city,
                        :p_association_phone,
                        :p_association_province,
                        :p_recent_update_user_id,
                        :x_status_code
                    );
                end; """, p_pet_id=req['pet_id'],
                             p_pet_name=req['pet_name'],
                             p_pet_age=req['pet_age'],
                             p_pet_size=req['pet_size'],
                             p_pet_type=req['pet_type'],
                             p_pet_dob=req['pet_dob'],
                             p_pet_gender=req['pet_gender'],
                             p_association_id=req['association_id'],
                             p_association_name=req['association_name'],
                             p_town=req.get('town'),
                             p_association_city=req.get('association_city'),
                             p_association_phone=req.get('association_phone'),
                             p_association_province=req.get('association_province'),
                             p_recent_update_user_id=req['recent_update_user_id'],
                             x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    result['msg'] = 'Pet Details updated successfully'
                    result['status'] = 0
                else:
                    result['msg'] = 'Failed to update Pet Details'
                    result['status'] = 1

                    logger.findaylog("""@ models - donation - acaifl_update_pet_details -
                            {}""".format(status_code.getvalue()))
        except Exception as e:
            logger.findaylog(""" @EXCEPTION models - donation -
                        acaifl_update_pet_details """ + str(e))
            raise e
        logger.addinfo('@ models - donation - acaifl_update_pet_details(+)')
        return result

    @staticmethod
    def acaifl_delete_db_user(req):
        logger.addinfo('@ models - donation - acaifl_delete_db_user(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_donation_pkg.delete_acaifl_pet_parent(
                        :p_pet_parent_id,
                        :p_email,
                        :p_user_id,
                        :x_status_code
                    );
                end; """, p_pet_parent_id=req['pet_parent_id'],
                             p_email=req['email'],
                             p_user_id=req['user_id'],
                             x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    result['msg'] = 'Pet Parent deleted successfully'
                    result['status'] = 0

                    # To set workflow value to empty
                    props = {
                        'email': req['email'],
                        'workflow_trigger': ''
                    }
                    cms_obj = CMS()
                    cms_obj.create_contact(props)
                else:
                    result['msg'] = 'Failed to delete Pet Parent'
                    result['status'] = 1
                    logger.findaylog("""@ models - donation - acaifl_delete_db_user -
                            {}""".format(status_code.getvalue()))
        except Exception as e:
            logger.findaylog(""" @EXCEPTION models - donation -
                        acaifl_update_pet_details """ + str(e))
            raise e
        logger.addinfo('@ models - donation - acaifl_delete_db_user(+)')
        return result

    @staticmethod
    def generate_receipt_pdf(path, html_file_name, application_no):
        """
        Generate the receipt pdf which can be downloaded from the website
        by associations to fill and upload it back
        """
        logger.addinfo('@ models - donation - generate_receipt_pdf(+)')
        pdf_file = None
        try:
            if os.path.exists(path + html_file_name):
                # generate HTML template with all the data
                template = jinja2.Environment(
                    loader=jinja2.FileSystemLoader(path)
                ).get_template(html_file_name).render(
                    application_no=application_no
                )

                # setting options for PDF file
                options = {
                    'page-size': 'A4',
                    'zoom': '1',
                    'encoding': 'UTF-8',
                    'quiet': '',
                    'dpi': 700
                }

                # copy HTML content to temporary file
                file_name = CommonUtils.generate_random_string(10)
                with io.open('/tmp/' + file_name + '.html', 'w',
                             encoding='utf-8') as fp:
                    fp.write(template)
                    fp.close()

                # generate PDF file from the temporary HTML file
                pdfkit.from_file('/tmp/' + file_name + '.html',
                                 '/tmp/' + file_name + '.pdf', options=options)

                pdf_file = open('/tmp/' + file_name + '.pdf', 'r')
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - donation -
                generate_receipt_pdf ''' + str(error))
            raise error
        logger.addinfo('@ models - donation - generate_receipt_pdf(-)')
        return pdf_file

    @staticmethod
    def parse_contact_properties(email):
        """
        Get HubSpot contact properties for the email.

        """
        logger.addinfo('@ models - donation - parse_contact_properties(+)')
        result = {}
        try:
            if email:
                cms_obj = CMS()
                contact_data = cms_obj.check_contact_details(email)
                if 'status' in contact_data and contact_data['status'] != 'ERROR':
                    contact_data = contact_data.get('details')
                    contact_properties = contact_data.get('properties')
                    result['contact_id'] = contact_data.get('vid')
                    for key, value in contact_properties.items():
                        result[key] = value.get('value')
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - cms -
                parse_contact_properties ''' + str(error))
            raise error
        logger.addinfo('@ models - donation - parse_contact_properties(-)')
        return result

    @staticmethod
    def validate_url(url):
        logger.addinfo('@ models - donation - validate_url(-)')
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, "
                              "like Gecko) Chrome/41.0.2228.0 Safari/537.3"
            }
            result = requests.get(url=url, headers=headers)
            if result.status_code == 200:
                final = {'status': Status.OK.value, 'msg': 'Url found'}
            else:
                final = {'status': Status.ERROR.value, 'msg': 'Url not found'}
        except requests.exceptions.ConnectionError as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                validate_url - connectionError """ + str(error))
            return {'status': 1, 'msg': 'Connection Timed out'}
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                validate_url """ + str(error))
            raise error
        logger.addinfo('@ models - donation - validate_url(+)')
        return final

    @staticmethod
    def prepare_association_country_code(country):
        """
        If country is passed as BE then consider the associations
        created under the country code BE, BE_FR and BE_NL
        """
        if country in ['BE_FR', 'BE_NL', 'BE']:
            country = ','.join(["'BE_FR'", "'BE_NL'", "'BE'"])
        elif not country:
            country = 'country'
        else:
            country = "'" + country + "'"
        return country

    def send_email_to_shop(self, cc, shop_id, coupon_data, language):
        try:
            address = coupon_data['shop_address'].split(',')[0]
            shop_name = coupon_data['shop_name']
            msg = ''

            # get pet food details
            products = self.get_br_coupon_details(coupon_data['country'], coupon_data['pet_type'],
                                                  coupon_data['pet_age'], coupon_data['pet_size'])
            # get translations and language
            if not language:
                ui_language = 'EN'
            else:
                ui_language = language
            translation_file = sql_util.get_translation_sql(ui_language)
            template_id = 1393584 if coupon_data['country'] in ['ca', 'ca_fr'] else 1393576

            # get shop details
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_shop_email']
                conn.execute(query, p_shop_id=shop_id)
                data = conn.get_single_result(convert_data=False)
            if not data:
                return ' No data found to send email to shop user'
            email = [{'Email': data['email_address'], 'Name': ''}]
            shop_name = coupon_data['shop_name']
            address = coupon_data['shop_address']
            if coupon_data['country'] in ['ca', 'ca_fr']:
                params = [
                    {
                        'key': 'user_name',
                        'value': coupon_data['user_name']
                    },
                    {
                        'key': 'shop_name',
                        'value': shop_name
                    },
                    {
                        'key': 'shop_address',
                        'value': address
                    },
                    {
                        'key': 'pet_type',
                        'value': coupon_data['pet_type'].lower()
                    }
                ]
            else:
                params = [
                    {
                        'key': 'greetings',
                        'value': translation_file['offline_shop_template_greetings']
                    },
                    {
                        'key': 'body',
                        'value': translation_file['offline_shop_template_body']
                    },
                    {
                        'key': 'site_in',
                        'value': translation_file['offline_shop_template_site_in']
                    },
                    {
                        'key': 'shop_name',
                        'value': shop_name
                    },
                    {
                        'key': 'address',
                        'value': address
                    },
                    {
                        'key': 'food_details',
                        'value': products['info']
                    },
                    {
                        'key': 'free_food',
                        'value': translation_file['offline_shop_template_free_food']
                    },
                    {
                        'key': 'profits',
                        'value': translation_file['offline_shop_template_profits']
                    },
                    {
                        'key': 'transparency',
                        'value': translation_file['offline_shop_template_transparency']
                    },
                    {
                        'key': 'slogan',
                        'value': translation_file['offline_shop_template_slogan']
                    },
                    {
                        'key': 'click_here',
                        'value': translation_file['offline_shop_template_click_here']
                    },
                    {
                        'key': 'url',
                        'value': translation_file['offline_shop_template_url']
                    },
                    {
                        'key': 'product_note',
                        'value': translation_file['offline_products_note']
                    }
                ]
            mail_data = {
                'recipients': email,
                'template_id': template_id,
                'subject': translation_file['offline_shop_template_subject'],
                'params': params
            }
            if os.environ.get('FINAPI_SERVER') == 'dev':
                mail_data['cc'] = 'sreelekha@finday.com'
            else:
                mail_data['cc'] = 'christian.nourry@almonature.com'
            if cc:
                mail_data['cc'] = mail_data['cc'] + ',' + cc
            email_status = CommonUtils.send_mail(mail_data)
            if email_status != 'SUCCESS':
                msg = ' failed to sent email to shop user'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - donation -
                        send_email_to_shop """ + str(error))
            raise error
        return msg

    @staticmethod
    def get_workflow_name(wf_name, country, language):
        if country == language:
            wf_name += country
        else:
            wf_name += country + '_' + language
        return wf_name

    @staticmethod
    def notify_association_registration(recipients, req):
        subject = '[' + req.get('receiver') + '] [Companion Animal] New organization '
        subject += req['association_name'] + ' has registered'
        data = {
            'subject': subject,
            'template_id': 1393577,
            'params': [
                {
                    'key': 'association_name',
                    'value': req['association_name']
                },
                {
                    'key': 'address',
                    'value': req['address']
                },
                {
                    'key': 'city',
                    'value': req['city']
                },
                {
                    'key': 'province',
                    'value': req['province']
                },
                {
                    'key': 'zip',
                    'value': req['zip']
                },
                {
                    'key': 'country',
                    'value': req['country']
                },

                {
                    'key': 'user_email',
                    'value': req['user_email']
                },
                {
                    'key': 'phone',
                    'value': req['telephone']
                },
                {
                    'key': 'user_name',
                    'value': req['user_name']
                },
                {
                    'key': 'registered_date',
                    'value': str(datetime.now().strftime('%y-%m-%d'))
                },
                {
                    'key': 'receiver',
                    'value': req.get('receiver')
                }
            ],
            'recipients': recipients
        }
        result = CommonUtils.send_mail(data)

        if result != 'SUCCESS':
            logger.findaylog(""" @ models - donation - notify_association_registration - Failed to send
                        mail to approvers """)

    @staticmethod
    def update_association(req):
        with OracleConnectionManager() as conn:
            conn.execute("""
                begin
                    qpex_donation_pkg.update_association(
                        :p_org_id,
                        :p_cat_sterilizations,
                        :p_dog_sterilizations,
                        :p_sterilization_adoption_act,
                        :p_shelter_activity,
                        :x_status_code
                    );
                end;""", output_key='x_status_code',
                         p_org_id=req['org_id'],
                         p_cat_sterilizations=req.get('no_of_cat_sterilizations'),
                         p_dog_sterilizations=req.get('no_of_dog_sterilizations'),
                         p_sterilization_adoption_act=req.get('sterilization_adoption_activity'),
                         p_shelter_activity=req.get('shelter_activity'))
            status = conn.get_output_param(raise_exception=False)
            if status == 'SUCCESS':
                response = {
                    'status': 'OK',
                    'msg': 'Association updated successfully'
                }
            else:
                response = {
                    'status': 'ERROR',
                    'msg': 'Failed to update association - {}'.format(status)
                }
        return response

    def get_donation_hw_metrics(self, aggregate='N'):
        with OracleConnectionManager() as conn:
            if aggregate == 'Y':
                query = self.sql_file['donation_metrics_hw_aggregate_query']
                conn.execute(query)
                result = conn.get_single_result(convert_data=False)
            else:
                query = self.sql_file['donation_desk_pets_metrics_hw_query']
                conn.execute(query)
                result = conn.get_result(convert_data=False)
        return result

    def get_coupon_details(self, country):
        if country == 'nl':
            strings = self.sql_file['coupon_nl_details']
        elif country == 'ch_fr':
            strings = self.sql_file['coupon_ch_fr_details']
        elif country in ['it', 'ch_it']:
            strings = self.sql_file['coupon_it_details']
        elif country == 'ca':
            strings = self.sql_file['coupon_ca_details']
        elif country == 'ca_fr':
            strings = self.sql_file['coupon_ca_fr_details']
        else:
            strings = self.sql_file['coupon_be_details']
        return strings

    def validate_token(self, token):
        s = Serializer(self.token_secret_key)
        data = s.loads(token)
        if 'id' in data:
            result = self.get_adoption_details(adoption_id=data.get('id'))
            if result.get('result') and result['result'][0]['cafl_application_id']:
                with OracleConnectionManager() as conn:
                    query = self.sql_file['get_shop_details']
                    conn.execute(query,
                                 p_pet_parent_id=result['result'][0]['cafl_application_id'])
                    shop_details = conn.get_result()
                    result['result'][0]['shop_details'] = shop_details
        else:
            result = {
                'msg': 'Token is invalid or expired',
                'status': 1
            }
        return result

    """
        Create application from adoption details after user selects pet food shop
    """

    def create_cafl_application(self, jsond):
        adoption_result = self.get_adoption_details(jsond['adoption_id']).get('result')
        if adoption_result:
            adoption_details = adoption_result[0]
        else:
            return {
                'status': 1,
                'msg': 'Not found adoption details'
            }
        cafl_json = {
            'first_name': adoption_details.get('first_name') or '',
            'last_name': adoption_details.get('last_name') or '',
            'email': adoption_details['email'],
            'telephone': adoption_details['phone'],
            'address': adoption_details['address'] or '',
            'city': adoption_details['city'] or '',
            'province': adoption_details['province'] or '',
            'state': '',
            'country': adoption_details['country'],
            'postal_code': adoption_details['zip'],
            'pet_name': adoption_details['pet_name'] or '',
            'pet_breed': '',
            'pet_age': (adoption_details.get('pet_age') or '').lower(),
            'pet_size': (adoption_details.get('pet_size') or '').lower(),
            'pet_type': (adoption_details.get('pet_type') or '').lower(),
            'pet_bio': '',
            'is_adopted': 'Y',
            'adoption_date': adoption_details['adoption_date'] or '',
            'user_id': -1,
            'association_id': adoption_details['org_id'],
            'association_name': adoption_details['org_name'],
            'shop_type': 'offline',
            'shop_id': jsond['shop_id'],
            'shop_name': jsond['shop_name'],
            'shop_address': jsond['shop_address'],
            'attachments': [],
            'contact_customer': 'N',
            'adoption_id': jsond['adoption_id']
        }
        adoption_documents = self.download_adoption_document(jsond['adoption_id'])['result']
        cafl_json['attachments'] = Donation.get_cafl_attachments(adoption_documents)
        cafl_result = self.insert_acaifl_pet_parent(cafl_json)
        if cafl_result['status'] == 0:
            result = {
                'status': 0,
                'msg': 'Application created successfully',
                'application_id': cafl_result['pet_parent_id']
            }
        else:
            result = {
                'status': 1,
                'msg': cafl_result.get('msg', 'Failed to create application')
            }
        return result

    @staticmethod
    def get_cafl_attachments(adoption_documents):
        attachments = []
        for i in range(len(adoption_documents)):
            if adoption_documents[i]['document_type'] == 'ADOPTION_FORM':
                attachments.append({
                    'reference_type': 'PET',
                    'attachment_type': 'ADOPTION_CERTIFICATE',
                    'file_data': adoption_documents[i]['file_data'],
                    'file_name': adoption_documents[i]['file_name'],
                    'file_type': adoption_documents[i]['file_type']
                })
            if adoption_documents[i]['document_type'] == 'PHOTOS':
                attachments.append({
                    'reference_type': 'PET',
                    'attachment_type': 'IMAGE',
                    'file_data': adoption_documents[i]['file_data'],
                    'file_name': adoption_documents[i]['file_name'],
                    'file_type': adoption_documents[i]['file_type']
                })
        return attachments

    @staticmethod
    def update_adoption(pet_parent_id, adoption_id):
        with OracleConnectionManager() as conn:
            conn.execute("""
                begin
                    qpex_donation_pkg.update_adoption (
                        :p_adoption_id,
                        :p_pet_parent_id,
                        :x_status_code
                    );
                end;
            """, output_key='x_status_code',
                         p_adoption_id=int(adoption_id),
                         p_pet_parent_id=int(pet_parent_id))

    def shop_selection_email_to_user(self, email, adoption_id):
        props = {
            'email': email,
            'workflow_trigger': 'cafl_send_shop_selection_email',
            'country': 'CA',
            'custom_token_link': 'https://www.almonature.com/en_CA/companion-animal-for-life/form/?token=' +
                                 Donation.prepare_token(str(adoption_id))
        }
        cms = CMS()
        status = cms.create_contact(props)
        if 'status' in status:
            return {
                'status': 1,
                'msg': ' Failed to send email to user'
            }
        return {
            'status': 0,
            'msg': ' Email sent to user'
        }

    # upload the file to HubSpot and add the URL to
    # contact property
    @staticmethod
    def upload_file(file_name, file_path):
        pob = POB()
        return pob.upload_file(file_name, file_path)

    @staticmethod
    def prepare_token(adoption_id):
        cognito = Cognito()
        return cognito.prepare_token(adoption_id, 864000)

    @staticmethod
    def get_products_by_pet_type(strings, pet_type, pet_age, pet_size):
        if pet_type.lower() == 'cat':
            product = strings[pet_type.lower()][pet_age.lower()]
        else:
            product = strings[pet_type.lower()][pet_age.lower()][pet_size.lower()]
        return product

    @staticmethod
    def get_cafl_workflow_id(shop_type, contact_by):
        if shop_type == 'OFFLINE' and contact_by:
            workflow_id = 8284648
        elif shop_type == 'ONLINE':
            workflow_id = 6512902
        else:
            workflow_id = 6512922
        return workflow_id

    @staticmethod
    def send_coupon_mail_distributor(req):
        subject = 'Credit request from %s for coupon %s' % (req['shop_name'], req['coupon_code'])
        recipient_email = ''
        if req['shop_address'].find('QC') != -1:
            recipient_email = 'admin@gastronomeanimal.com'
        elif req['shop_address'].find('ON') != -1:
            recipient_email = 'HeatherM@manchesterpet.ca'
        elif req['shop_address'].find('AB') != -1:
            recipient_email = 'creditsdept@anipet.com'
        else:
            recipient_email = 'engineers@finday.com'
        data = {
            'subject': subject,
            'template_id': 1803254,
            'params': [
                {
                    'key': 'shop_name',
                    'value': req['shop_name']
                },
                {
                    'key': 'shop_address',
                    'value': req['shop_address']
                },
                {
                    'key': 'coupon_code',
                    'value': req['coupon_code']
                },
                {
                    'key': 'lines',
                    'value': req['products']
                },
                {
                    'key': 'quantity',
                    'value': req['quantity']
                }
            ],
            'attachments': req['attachments'],
            'recipients': [
                {
                    'Email': recipient_email
                }
            ],
            'cc': 'christian.nourry@almonature.com'
        }
        result = CommonUtils.send_mail(data)
        if result != 'SUCCESS':
            logger.findaylog('@ models - donation - send_coupon_mail_distributor')

    def application_org_change(self, jsond):
        with OracleConnectionManager() as conn:
            query = self.sql_file['update_application_org']
            conn.execute(query, p_org_id=jsond['org_id'], p_header_id=jsond['application_id'])
            if conn.cursor.rowcount == 1:
                return {'status': 0, 'msg': 'Organization is updated'}
        return {'status': 1, 'msg': 'Failed to update organization'}


def get_country_and_language(country, language):
    new_language = None
    if country and '_' in country:
        word = country.split('_')
        country = word[0]
        new_language = word[1]
    if not language:
        language = new_language if new_language else country
    return country, language


def get_ship_address(ship_address):
    if ship_address:
        ship_address_split = ship_address.rsplit('@@', 1)
        if len(ship_address_split) > 1:
            country = ship_address_split[-1].split('_')[0]
            ship_address = '@@'.join([ship_address_split[0], country])
    return ship_address


def get_application_template(data):
    logger.addinfo('@ models - donation - get_application_template(+)')
    try:
        country, language = get_country_and_language(data.get('country'), data.get('language'))

        try:
            if data.get('request_type') == 'A':
                lines = data['adoptme_kits']
            else:
                lines = data['lines']
        except KeyError:
            lines = data.get('lines', [])

        application_no = data.get('application_no')
        if application_no and not isinstance(application_no, str):
            application_no = str(application_no, 'utf-8')
        path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        path += '/static/'
        template = jinja2.Environment(
            loader=jinja2.FileSystemLoader(path)
        ).get_template('dd_application_notify.html').render(
            user_name=data.get('user_name'),
            user_email=data.get('user_email'),
            org_name=data.get('org_name'),
            need_desc=data.get('need_desc'),
            application_no=application_no,
            address=data.get('address'),
            city=data.get('city'),
            country=country,
            zip=data.get('zip'),
            phone=data.get('phone'),
            lines=lines,
            request_type=data.get('request_type'),
            request_id=str(int(data['request_id'])),
            approve_link=data.get('approve_link'),
            reject_link=data.get('reject_link')
        )
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - models - donation -
            get_application_template """ + str(error))
        raise error
    logger.addinfo('@ models - donation - get_application_template(-)')
    return template


def add_contact(email_id):
    logger.addinfo('@ models - donation - add_contact(+)')
    contacts = []
    try:
        list_id = 1791165
        contact = {
            'email': email_id,
            'name': '',
            'list_id': list_id,
            'action': 'addnoforce',
            'properties': []
        }
        contacts.append(contact)
        contacts_obj = Contacts()
        contacts_obj.add_contact(contacts)
    except Exception as error:
        logger.findaylog("""@ EXCEPTION - models - donation -
            add_contact """ + str(error))
        raise error
    logger.addinfo('@ models - donation - add_contact(-)')
