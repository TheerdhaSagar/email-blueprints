import time
from finapi.utils import db_util
from finapi.utils.logdata import logger
from collections import OrderedDict
import cx_Oracle
import paramiko
import os
from simplexml import dumps
from xml.etree import ElementTree as ET
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil
from finapi.sql import sql_util


@LogUtil.class_module_logs('payments')
class Payments:

    def __init__(self, **kwargs):
        filename = os.path.basename(os.path.dirname(__file__))
        self.sql_file = sql_util.get_sql(filename)
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    def get_payment_details(self):
        with OracleConnectionManager() as conn:
            query = self.sql_file['payments_details']
            conn.execute(query, p_type='payer')
            payer_details = conn.get_result()
            payee_details = self.get_payee_details(conn)
        final = {
            'payer_details': payer_details,
            'payee_details': payee_details
        }
        return final

    def get_payee_details(self, conn):
        query = self.sql_file['payments_details']
        conn.execute(query, p_type='payee')
        payee_details = conn.get_result()
        return payee_details

    def xml_conversion(self, json):
        with OracleConnectionManager() as conn:
            message_seq = conn.set_output_param('NUMBER')
            conn.execute("""
                begin
                    qpex_payments_pkg.get_xml_message_sequence (
                        :x_sequence,
                        :x_status_code
                    );
                end;""", output_key='x_status_code',
                         x_sequence=message_seq)
            conn.get_output_param()
            message_id = int(message_seq.getvalue())
            payer_details = json['payer']
            payee_details = json['payee']
            country_code = json['payer']['address_line3']
            initg_pty = OrderedDict()
            customer_credit_transfer = OrderedDict()
            grp_hdr = OrderedDict()
            pmt_inf = OrderedDict()
            nb_of_txs = len(payee_details)
            cre_dt_tm = payer_details['creation_date_time']
            msg_id = message_id
            nm = payer_details["account_name"]
            othr = {"Id": "ABC67163001"}
            org_id = {"Othr": othr}
            org_id = {'OrgId': org_id}
            if country_code != 'CH':
                initg_pty["Nm"] = nm
            initg_pty["Id"] = org_id
            grp_hdr["MsgId"] = msg_id
            grp_hdr["CreDtTm"] = cre_dt_tm
            grp_hdr["NbOfTxs"] = nb_of_txs
            grp_hdr["CtrlSum"] = payer_details['totalAmount']
            grp_hdr["InitgPty"] = initg_pty
            pmt_inf["PmtInfId"] = msg_id
            pmt_inf["PmtMtd"] = "TRF"
            pmt_inf["PmtTpInf"] = Payments.build_pmt_tp_inf(country_code)
            pmt_inf["ReqdExctnDt"] = payer_details["exctn_date"]
            dbtr = OrderedDict()
            dbtr["Nm"] = nm
            dbtr["PstlAdr"] = Payments.build_pstl_adr(country_code, payer_details)
            dbtr_acct = {}
            iban_id = {"IBAN": payer_details["iban"]}
            dbtr_acct["Id"] = iban_id
            pmt_inf['Dbtr'] = dbtr
            fin_instn_id = OrderedDict()
            fin_instn_id['BIC'] = payer_details["bic_code"]
            if country_code == 'CH':
                pstl_adr = {"Ctry": payer_details["address_line3"]}
                fin_instn_id['PstlAdr'] = pstl_adr
            dbtr_agt = {'FinInstnId': fin_instn_id}
            pmt_inf["DbtrAcct"] = dbtr_acct
            pmt_inf["DbtrAgt"] = dbtr_agt
            if country_code != 'CH':
                pmt_inf["ChrgBr"] = "SLEV"
            temp_cdtr_trf_tx_inf = []
            for i in range(0, len(payee_details)):
                pmt_id = OrderedDict()
                pmt_id["InstrId"] = payee_details[i]["id"]
                pmt_id["EndToEndId"] = payee_details[i]["id"]
                cdt_tr_tx_inf = OrderedDict()
                amt = {}
                instd_amt = {"Ccy": payee_details[i]["default_currency_code"],
                             "text": payee_details[i]["formatted_amount"]}
                amt["InstdAmt"] = instd_amt
                cdtr_agt = {"FinInstnId": Payments.build_fin_instn_id(
                    country_code, payee_details[i])}
                cdtr = OrderedDict()
                cdtr["Nm"] = payee_details[i]["account_name"]
                p_pstl_adr = {"Ctry": payee_details[i]["address_line3"]}
                if country_code != 'CH':
                    temp_address = payee_details[i]["address_line1"]
                    p_pstl_adr["AdrLine"] = temp_address
                cdtr["PstlAdr"] = p_pstl_adr
                cdtr_acct = {}
                cdtr_acct_id = {"IBAN": payee_details[i]["iban"]}
                cdtr_acct["Id"] = cdtr_acct_id
                rmt_inf = {"Ustrd": payee_details[i]["description"]}
                cdt_tr_tx_inf["PmtId"] = pmt_id
                cdt_tr_tx_inf["Amt"] = amt
                cdt_tr_tx_inf["CdtrAgt"] = cdtr_agt
                cdt_tr_tx_inf["Cdtr"] = cdtr
                cdt_tr_tx_inf["CdtrAcct"] = cdtr_acct
                cdt_tr_tx_inf["RmtInf"] = rmt_inf
                temp_cdtr_trf_tx_inf.append(cdt_tr_tx_inf)
            pmt_inf["CdtTrfTxInf"] = temp_cdtr_trf_tx_inf
            customer_credit_transfer["GrpHdr"] = grp_hdr
            customer_credit_transfer["PmtInf"] = pmt_inf
            document = {'CstmrCdtTrfInitn': customer_credit_transfer}
            final = {'Document': document}
            lang = ET.fromstring(dumps(final))
            for neighbor in lang.iter('Document'):
                neighbor.set('xmlns',
                             "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03")
                neighbor.set('xmlns:xsi',
                             "http://www.w3.org/2001/XMLSchema-instance")
            texts = []
            currencies = []
            file_name = self.get_payment_filename(
                None, json['payer']['payment_format'], None)
            for neighbor in lang.iter('text'):
                texts.append(neighbor.text)
            for neighbor in lang.iter('Ccy'):
                currencies.append(neighbor.text)
            for neighbor in lang.iter('InstdAmt'):
                children = neighbor.getchildren()
                neighbor.clear()
                neighbor.text = children[1].text
                neighbor.set('Ccy', children[0].text)
            temp = ET.tostring(lang)
            str_final = "<?xml version='1.0' encoding='UTF-8'?>%s" % temp.decode('utf-8')
            str_final = str_final.replace('<TTR>', '')
            str_final = str_final.replace('</TTR>', '')

            file = open('/tmp/%s.xml' % file_name, 'w')
            file.write(str_final)
            file.close()

            Payments.write_payments_file(file_name, country_code)

            upload_status = Payments.upload_payment_files(file_name)
            response = {}
            if upload_status == 'success':
                response['status'] = 0
                response['msg'] = 'Payment files generated successfully'
            else:
                response['status'] = 1
                response['msg'] = 'Failed to upload payment files to server'
                logger.findaylog(response['msg'])

            response['document'] = str_final
            response['file_name'] = file_name
        return response

    @staticmethod
    def write_payments_file(file_name, country_code):
        strings = db_util.get_strings()
        file = open('/tmp/' + file_name + '.par', 'w')
        if country_code == 'IT':
            file.write(strings['payments_it_par'])
        elif country_code == 'NL':
            file.write(strings['payments_nl_par'])
        elif country_code == 'CH':
            file.write(strings['payments_ch_par'])
        else:
            file.write(strings['payments_non_it_par'])
        file.close()

    @staticmethod
    def build_svc_lvl(country_code):
        svc_lvl = {}
        if country_code == 'CH':
            svc_lvl["Cd"] = "NURG"
        else:
            svc_lvl["Cd"] = "SEPA"
        return svc_lvl

    @staticmethod
    def build_pmt_tp_inf(country_code):
        pmt_tp_inf = OrderedDict()
        pmt_tp_inf["SvcLvl"] = Payments.build_svc_lvl(country_code)
        if country_code == 'CH':
            lcl_instrm = {"Prtry": "CH02"}
            pmt_tp_inf["LclInstrm"] = lcl_instrm
        return pmt_tp_inf

    @staticmethod
    def build_pstl_adr(country_code, payer_details):
        pstl_adr = OrderedDict()
        pstl_adr["Ctry"] = payer_details["address_line3"]
        if country_code != 'CH':
            pstl_adr["AdrLine"] = [{"TTR": payer_details["address_line1"]},
                                   {"TTR": payer_details["address_line2"]}]
        return pstl_adr

    @staticmethod
    def build_fin_instn_id(country_code, payee_details):
        fin_instn_id = OrderedDict()
        if country_code != 'CH':
            fin_instn_id["BIC"] = payee_details["bic_code"]
        else:
            clr_sys_mmb_id = {}
            pstl_adr = {"Ctry": payee_details["address_line3"]}
            clr_sys_mmb_id["MmbId"] = payee_details["bank_identifier"]
            fin_instn_id["ClrSysMmbId"] = clr_sys_mmb_id
            fin_instn_id["PstlAdr"] = pstl_adr
        return fin_instn_id

    def create_transaction(self, jsond):
        logger.addinfo(time.ctime())
        payer_details = jsond['payer']
        payee_details = jsond['payee']
        amount_array = []
        description_array = []
        payee_id_array = []
        for i in range(len(payee_details)):
            amount_array.append(payee_details[i].get('amount'))
            description_array.append(payee_details[i].get('description'))
            payee_id_array.append(payee_details[i].get('id'))
        with OracleConnectionManager() as conn:
            transaction_id = conn.set_output_param('NUMBER')
            conn.execute("""
            begin
                qpex_payments_pkg.create_transaction(
                    :x_transaction_id,
                    :p_payer_id,
                    :p_exctn_date,
                    :p_transaction_name,
                    :p_payment_type,
                    :p_payment_format,
                    :p_creation_date_time,
                    :p_payment_amounts,
                    :p_descriptions,
                    :p_payee_id,
                    :x_status_code
                );
            end;""", output_key='x_status_code',
                         x_transaction_id=transaction_id,
                         p_payer_id=payer_details.get('id'),
                         p_exctn_date=payer_details.get('exctn_date'),
                         p_transaction_name=payer_details.get('transaction_name'),
                         p_payment_type=payer_details.get('payment_type'),
                         p_payment_format=payer_details.get('payment_format'),
                         p_creation_date_time=payer_details.get('creation_date_time'),
                         p_payment_amounts=conn.cursor.arrayvar(cx_Oracle.NUMBER, amount_array),
                         p_descriptions=conn.cursor.arrayvar(cx_Oracle.STRING, description_array),
                         p_payee_id=conn.cursor.arrayvar(cx_Oracle.NUMBER, payee_id_array))
            result = conn.get_output_param()
            if result == 'SUCCESS':
                # GB - country_code for UK
                if jsond['payer']['address_line3'] == 'GB':
                    response = Payments.xml_file_for_uk(transaction_id.getvalue())
                    response['msg'] = 'Payment done successfully. %s' % response['msg']
                else:
                    response = self.xml_conversion(jsond)
            else:
                response = {'status': 1, 'msg': result}
        return response

    def transaction_details(self, id):
        result = {}
        with OracleConnectionManager() as conn:
            query = self.sql_file['payer_transaction_details_query']
            conn.execute(query, p_transaction_id=id)
            payer_transaction_details = conn.get_result()
        payee_transaction_details = self.get_payee_trans_details(id)
        if payer_transaction_details:
            result = {'payer': payer_transaction_details[0], 'payee': payee_transaction_details}
        return result

    def get_transactions(self, payer_id):
        with OracleConnectionManager() as conn:
            if payer_id:
                query = self.sql_file['get_payer_transaction_query']
            else:
                query = self.sql_file['payment_transactions_query']
            conn.execute(query, p_payer_id=payer_id)
            transactions = conn.get_result()
        result = []

        # skip if payer_name or payee_name is none when payer_id is not None
        for i in range(len(transactions)):
            if not (payer_id and (not transactions[i].get('payer_name') or not transactions[i].get('payee_name'))):
                result.append(transactions[i])
        return result

    def get_payer_payee_trans(self, payer_id, payee_id):
        with OracleConnectionManager() as conn:
            query = self.sql_file['payer_payee_transactions']
            conn.execute(query, p_payer_id=payer_id, p_payee_id=payee_id)
            brands_list = conn.get_result()
        return brands_list

    def get_transaction_details(self):
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_transaction_details_query']
            conn.execute(query)
            transactions = conn.get_result()
        result = []

        # skip the record if payee_name is none
        for i in range(len(transactions)):
            if transactions[i].get('payee_name'):
                result.append(transactions[i])
        return result

    def get_payee_transactions(self, payee_id):
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_payee_transaction_query']
            conn.execute(query, p_payee_id=payee_id)
            transactions = conn.get_result()
        result = []

        # skip the record if payer_name is none
        for i in range(len(transactions)):
            if transactions[i].get('payer_name'):
                result.append(transactions[i])
        return result

    def get_payment_filename(self, sequence, payment_format, lang):
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_payment_description']
            conn.execute(query, P_FORMAT=payment_format,
                         P_LANGUAGE=lang)
            data = conn.get_single_result()
            file_name = data['description']
            query = self.sql_file['payments_file_name']
            conn.execute(query, P_SEQUENCE=sequence)
            data = conn.get_single_result()
            file_name += data['file_name']
        return file_name

    def sepa_formats(self, lang):
        with OracleConnectionManager() as conn:
            query = self.sql_file['sepa_formats_lov']
            conn.execute(query, p_language=lang)
            result = conn.get_result()
        return result

    def get_payee_trans_details(self, id):
        with OracleConnectionManager() as conn:
            query = self.sql_file['payee_transaction_details_query']
            conn.execute(query, p_transaction_id=id)
            brands_list = conn.get_result()
        return brands_list

    @staticmethod
    def create_account(jsond):
        with OracleConnectionManager() as conn:
            payment_id = conn.set_output_param('NUMBER')
            conn.execute("""
                begin
                    qpex_payments_pkg.create_account (
                        :x_payment_id,
                        :p_bank_name,
                        :p_account_name,
                        :p_account_number,
                        :p_type,
                        :p_address_line1,
                        :p_address_line2,
                        :p_address_line3,
                        :p_bic_code,
                        :p_iban,
                        :p_currency_code,
                        :p_created_by,
                        :p_last_updated_by,
                        :p_additional_info_1,
                        :x_status_code
                    );
                end;""", output_key='x_status_code',
                         x_payment_id=payment_id,
                         p_bank_name=jsond.get('bank_name'),
                         p_account_name=jsond.get('account_name'),
                         p_account_number=jsond.get('account_number'),
                         p_type=jsond.get('type'),
                         p_address_line1=jsond.get('address_line1'),
                         p_address_line2=jsond.get('address_line2'),
                         p_address_line3=jsond.get('address_line3'),
                         p_bic_code=jsond.get('bic_code'),
                         p_iban=jsond.get('iban'),
                         p_currency_code=jsond.get('default_currency_code'),
                         p_created_by=jsond.get('created_by'),
                         p_last_updated_by=jsond.get('last_updated_by'),
                         p_additional_info_1=jsond.get('addition_info1'))
            result = conn.get_output_param()
        return result

    @staticmethod
    def delete_account(payment_id):
        with OracleConnectionManager() as conn:
            conn.execute("""
                begin
                    qpex_payments_pkg.delete_account (
                        :p_payment_id,
                        :x_status_code
                    );
                end;""", output_key='x_status_code',
                         p_payment_id=payment_id)
            result = conn.get_output_param()
        return result

    @staticmethod
    def update_account(jsond):
        with OracleConnectionManager() as conn:
            conn.execute("""
                        begin
                            qpex_payments_pkg.update_account (
                                :p_payment_id,
                                :p_bank_name,
                                :p_account_name,
                                :p_account_number,
                                :p_type,
                                :p_address_line1,
                                :p_address_line2,
                                :p_address_line3,
                                :p_bic_code,
                                :p_iban,
                                :p_currency_code,
                                :p_last_updated_by,
                                :p_additional_info_1,
                                :x_status_code
                            );
                        end;""", output_key='x_status_code',
                         p_payment_id=jsond.get('payment_id'),
                         p_bank_name=jsond.get('bank_name'),
                         p_account_name=jsond.get('account_name'),
                         p_account_number=jsond.get('account_number'),
                         p_type=jsond.get('type'),
                         p_address_line1=jsond.get('address_line1'),
                         p_address_line2=jsond.get('address_line2'),
                         p_address_line3=jsond.get('address_line3'),
                         p_bic_code=jsond.get('bic_code'),
                         p_iban=jsond.get('iban'),
                         p_currency_code=jsond.get('default_currency_code'),
                         p_last_updated_by=jsond.get('last_updated_by'),
                         p_additional_info_1=jsond.get('addition_info1'))
            result = conn.get_output_param()
        return result

    @staticmethod
    def deactivate_accounts(req):
        result = {'status': 0, 'msg': 'Account(s) deactivated successfully'}
        with OracleConnectionManager() as conn:
            conn.execute('''
            begin
                qpex_payments_pkg.deactivate_accounts(
                    :p_account_ids,
                    :x_status_code
                );
            end; ''', output_key='x_status_code',
                         p_account_ids=req['account_ids'])
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result['status'] = 1
                result['msg'] = 'Failed to deactivate accounts %s' % status
        return result

    @staticmethod
    def xml_file_for_uk(batch_id):
        with OracleConnectionManager() as conn:
            return_status = conn.set_output_param('STRING')
            return_message = conn.set_output_param('STRING')
            conn.execute("""
                begin
                apps.qpex_uk_bacs_pkg.create_file(
                :p_batch_id, :x_return_status,
                :x_return_msg);
                end;""", p_batch_id=batch_id,
                         x_return_status=return_status,
                         x_return_msg=return_message)
            result = {}
            if not return_status.getvalue() and not return_message.getvalue():
                result['status'] = 0
                result['msg'] = 'File uploaded in server'
            else:
                result['status'] = 1
                result['msg'] = return_message.getvalue()
                logger.findaylog(result['msg'])
        return result

    @staticmethod
    def create_journal(batch_id):
        with OracleConnectionManager() as conn:
            conn.execute("""
            begin
                qpex_payments_pkg.create_journal_entry(
                    :p_batch_id,
                    :p_status_code
                );
            end; """, output_key='p_status_code',
                         p_batch_id=batch_id)
            result = conn.get_output_param()
        return result

    @staticmethod
    def upload_payment_files(file_name):
        client = None
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            host = os.environ['PAYMENTS_SFTP_HOST']
            username = os.environ['PAYMENTS_SFTP_USER']
            password = os.environ['PAYMENTS_SFTP_PASS']
            path = os.environ['PAYMENTS_SFTP_PATH']
            client.connect(host, username=username, password=password)
            sftp = client.open_sftp()
            local_path_xml = '/tmp/' + file_name + '.xml'
            local_path_par = '/tmp/' + file_name + '.par'
            remote_path_xml = path + file_name + '.xml'
            remote_path_par = path + file_name + '.par'
            sftp.put(local_path_xml, remote_path_xml)
            sftp.put(local_path_par, remote_path_par)
            sftp.close()
            status = 'success'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - payments -
                 upload_payment_files """ + str(error))
            raise error
        finally:
            if client:
                client.close()
        return status
