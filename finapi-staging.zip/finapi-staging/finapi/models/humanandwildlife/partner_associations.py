import os
import ujson
from finapi.utils.constants import Status
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil
from finapi.models.humanandwildlife.associations import HWAssociation


@LogUtil.class_module_logs('hw_partner_associations')
class HWPartnerAssociations:
    def __init__(self):
        filename = os.path.basename(os.path.dirname(__file__))
        self.sql_file = sql_util.get_sql(filename)

    def insert_or_update_partner_associations(self, partner_details):
        """
        add or update partner associations details
        :param partner_details:
        :return: {"status": "", "msg":""}
        """
        result = {}
        partner_flag = False
        address_id = ''
        with OracleConnectionManager() as conn:
            if partner_details.get('address'):
                # create or update address
                assoc_obj = HWAssociation()
                address = partner_details['address'][0]
                address['created_by'] = partner_details['created_by']
                address_result = assoc_obj.update_association_locations(address)
                if address_result['status'] == 0:
                    address_id = address_result['address_id']
            partner_association_id = conn.set_output_param('NUMBER')
            if partner_details.get('partner_association_id'):
                partner_association_id.setvalue(0, partner_details.get('partner_association_id'))
                partner_flag = True

            if not partner_details.get('org_id'):
                country_code = partner_details['address'][0]['country']
                partner_details['org_id'] = self.sql_file['countries_orgs'][
                                                    country_code]

            primary_certificates = HWPartnerAssociations.json_to_string(partner_details.get(
                                                                         'primary_certifications'))
            biodiversity_impact = HWPartnerAssociations.json_to_string(partner_details.get(
                                                                        'biodiversity_impact'))
            product_types = HWPartnerAssociations.json_to_string(partner_details.get(
                                                                    'product_types'))

            primary_sales = HWPartnerAssociations.json_to_string(partner_details.get(
                                                                        'primary_sales'))
            conn.execute("""
                BEGIN
                    qpex_humanwildlife_pkg.manage_partner_associations(
                    :p_partner_association_id,
                    :p_association_id,
                    :p_partner_association_name,
                    :p_status,
                    :p_address_id,
                    :p_website_url,
                    :p_facebook_url,
                    :p_instagram_url,
                    :p_product_types,
                    :p_primary_sales,
                    :p_primary_certifications,
                    :p_biodiversity_impact,
                    :p_no_of_livestock,
                    :p_org_id,
                    :p_created_by,
                    :x_status_code);
                END; """,
                         output_key='x_status_code',
                         p_partner_association_id=partner_association_id,
                         p_association_id=partner_details['association_id'],
                         p_partner_association_name=partner_details.get('partner_association_name'),
                         p_status=partner_details.get('status', 'I'),
                         p_address_id=address_id,
                         p_website_url=partner_details.get('website_url'),
                         p_facebook_url=partner_details.get('facebook_url'),
                         p_instagram_url=partner_details.get('instagram_url'),
                         p_product_types=product_types,
                         p_primary_sales=primary_sales,
                         p_primary_certifications=primary_certificates,
                         p_biodiversity_impact=biodiversity_impact,
                         p_no_of_livestock=partner_details.get('no_of_livestock'),
                         p_org_id=partner_details.get('org_id'),
                         p_created_by=partner_details.get('created_by', -1)
                         )
            status_code = conn.get_output_param()
            if status_code == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': '{} partner association successfully'.format(
                            'Updated' if partner_flag else 'Added'),
                          'partner_association_id': int(partner_association_id.getvalue())
                          }
                if not partner_flag:
                    partner_details['partner_association_id'] = result['partner_association_id']
                    pet_error, food_error = HWPartnerAssociations.insert_partner_related_details(
                                                                                    partner_details)
                    result['pet_error'] = pet_error
                    result['food_error'] = food_error
        return result

    @staticmethod
    def insert_partner_related_details(jsond):
        """
        for inserting pet details and food donation details while creating partner associations
        :param jsond: object
        """
        pet_error = []
        food_error = []
        if jsond.get('pet_details'):
            for pet in jsond.get('pet_details'):
                pet['created_by'] = jsond['created_by']
                pet['partner_association_id'] = jsond['partner_association_id']
                pet_status = HWPartnerAssociations.insert_or_update_pet_details(pet)
                if pet_status['status'] == 1:
                    pet['error_msg'] = pet_status['msg']
                    pet_error.append(pet)
        if jsond.get('donation_details'):
            for food_donate in jsond.get('donation_details'):
                food_donate['created_by'] = jsond['created_by']
                food_donate['partner_association_id'] = jsond['partner_association_id']
                food_status = HWPartnerAssociations.insert_or_update_partner_donations(food_donate)
                if food_status['status'] == 1:
                    food_donate['error_msg'] = food_status['msg']
                    food_error.append(food_donate)
        return pet_error, food_error

    @staticmethod
    def insert_or_update_pet_details(pet_details):
        """
        For inserting or updating pet details of the partner association
        :param pet_details: json object
        :return: {'status': "", "msg":""}
        """
        with OracleConnectionManager() as conn:
            pet_id = conn.set_output_param('NUMBER')
            pet_flag = False
            if pet_details.get('pet_id'):
                pet_id.setvalue(0, pet_details.get('pet_id'))
                pet_flag = True
            conn.execute("""
                BEGIN
                    qpex_humanwildlife_pkg.manage_partner_pet_details(
                    :p_pet_id,
                    :p_partner_association_id,
                    :p_pet_name,
                    :p_pet_race,
                    :p_pet_age,
                    :p_training_received,
                    :p_health_rating,
                    :p_work_attitude_rating,
                    :p_tourist_attitude_rating,
                    :p_created_by,
                    :x_status_code);
                END;""",
                         output_key='x_status_code',
                         p_pet_id=pet_id,
                         p_partner_association_id=pet_details.get('partner_association_id'),
                         p_pet_name=pet_details.get('pet_name'),
                         p_pet_race=pet_details.get('pet_race'),
                         p_pet_age=pet_details.get('pet_age'),
                         p_training_received=pet_details.get('training_received'),
                         p_health_rating=pet_details.get('health_rating'),
                         p_work_attitude_rating=pet_details.get('work_attitude_rating'),
                         p_tourist_attitude_rating=pet_details.get('tourist_attitude_rating'),
                         p_created_by=pet_details.get('created_by', -1))
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Pet Details {} successfully'.format('updated' if pet_flag
                                                                      else 'added'),
                          'pet_id': int(pet_id.getvalue())
                          }
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Failed to {} pet details'.format('update' if pet_flag else 'add'),
                          'pet_id': int(pet_id.getvalue())}
        return result

    @staticmethod
    def insert_or_update_partner_donations(donation_details):
        """
        For inserting or updating food donation details of the partner association
        :param donation_details: json object
        :return: {'status': "", "msg":""}
        """
        with OracleConnectionManager() as conn:
            partner_donation_id = conn.set_output_param('NUMBER')
            food_flag = True
            if donation_details.get('partner_donation_id'):
                partner_donation_id.setvalue(0, donation_details.get('partner_donation_id'))
                food_flag = False
            conn.execute("""
                BEGIN
                    qpex_humanwildlife_pkg.manage_partner_donations(
                    :p_partner_donation_id,
                    :p_partner_association_id,
                    :p_donation_date,
                    :p_quantity,
                    :p_created_by,
                    :x_status_code);
                END;""",
                         output_key='x_status_code',
                         p_partner_donation_id=partner_donation_id,
                         p_partner_association_id=donation_details.get('partner_association_id'),
                         p_donation_date=donation_details.get('donation_date'),
                         p_quantity=donation_details.get('quantity'),
                         p_created_by=donation_details.get('created_by', -1))
            status_code = conn.get_output_param(raise_exception=False)
            if status_code == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Food donation details {} successfully'.format('added' if food_flag
                                                                                else 'updated'),
                          'partner_donation_id': int(partner_donation_id.getvalue())
                          }
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Failed to {} food donation details'.format('add' if food_flag
                                                                             else 'update'),
                          'partner_donation_id': int(partner_donation_id.getvalue())
                          }
        return result

    def get_partner_association_details(self, org_id, assoc_id, partner_assoc_id):
        """
        Get partner association details based on id and org
        :param org_id: number
        :param assoc_id: number
        :param partner_assoc_id: number
        :return: {'status': '', 'partner_details': []}
        """
        with OracleConnectionManager() as conn:
            if partner_assoc_id:
                query = self.sql_file['partner_association_details']
                conn.execute(query, p_partner_association_id=partner_assoc_id)

            else:
                query = self.sql_file['partner_association_summary']
                conn.execute(query, p_assoc_id=assoc_id, p_org_id=org_id)

            partner_details = conn.get_result(convert_data=True, is_json_check=True)
        return {'status': Status.OK.value, 'partner_details': partner_details}

    @staticmethod
    def delete_partner_donations(donation_id):
        with OracleConnectionManager() as conn:
            conn.execute("""
                        BEGIN
                            qpex_humanwildlife_pkg.delete_partner_donations(
                            :p_partner_donation_id,
                            :x_status_code
                            );
                        END;
                        """, output_key='x_status_code', p_partner_donation_id=donation_id)
            conn.get_output_param()
        return {'status': Status.OK.value, 'msg': 'Food Donation deleted successfully'}

    @staticmethod
    def delete_partner_pet_details(pet_id):
        with OracleConnectionManager() as conn:
            conn.execute("""
                            BEGIN
                                qpex_humanwildlife_pkg.delete_partner_pet_details(
                                :p_pet_id,
                                :x_status_code
                                );
                            END;
                            """, output_key='x_status_code', p_pet_id=pet_id)
            conn.get_output_param()
        return {'status': Status.OK.value, 'msg': 'Pet details deleted successfully'}

    @staticmethod
    def json_to_string(value):
        """
            change json to string
        """
        try:
            json_string = ujson.dumps(value)
        except ValueError:
            return value
        return json_string
