import os
import ujson
import urllib.request, urllib.parse, urllib.error

import cx_Oracle

from finapi.models.humanandwildlife.applications import HWApplications
from finapi.utils.common_utils import CommonUtils
from finapi.utils.constants import Status
from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil
from finapi.models.humanandwildlife.contacts import HWContacts
from finapi.models.humanandwildlife.invitations import HWInvitations


@LogUtil.class_module_logs('hw_associations')
class HWAssociation:

    def __init__(self):
        filename = os.path.basename(os.path.dirname(__file__))
        self.sql_file = sql_util.get_sql(filename)
        self.strings = db_util.get_strings()
        self.api_key = os.environ['MAP_API_KEY']

    def insert_or_update_association(self, assoc_details):
        """
        add or update an association
        :param assoc_details: {"association_name":"","status":"", "type":"",
        "sub_type":"",
        "website_url": "", "facebook_url":"", "instagram_url": "",
        "supported_activities":"",
        "no_of_partners":"","no_of_dogs": "", "country_code": "", "org_id":"",
        "created_by":"",
        "project_proposal":""}
        :return:{"status":"", "msg":""}
        """
        with OracleConnectionManager() as conn:
            invitation_obj = HWInvitations()
            org_id = invitation_obj.get_org_details(assoc_details['country'],
                                                    assoc_details.get('org_id'))
            assoc_flag = False
            status_code = conn.cursor.var(cx_Oracle.STRING)
            association_id = conn.cursor.var(cx_Oracle.NUMBER)
            if assoc_details.get('association_id'):
                association_id.setvalue(0, assoc_details.get('association_id'))
                assoc_flag = True
            conn.execute("""
            BEGIN
                qpex_humanwildlife_pkg.manage_association (
                :p_association_id,
                :p_association_name,
                :p_status,
                :p_type,
                :p_sub_type,
                :p_website_url,
                :p_facebook_url,
                :p_instagram_url,
                :p_supported_activities,
                :p_no_of_partners,
                :p_no_of_dogs,
                :p_country_code,
                :p_org_id,
                :p_created_by,
                :p_project_proposal,
                :x_status_code
                );
                END;
            """, p_association_id=association_id,
                         p_association_name=assoc_details['association_name'],
                         p_status=assoc_details.get('status', 'C'),
                         p_type=assoc_details.get('type'),
                         p_sub_type=assoc_details.get('sub_type'),
                         p_website_url=assoc_details.get('website_url'),
                         p_facebook_url=assoc_details.get('facebook_url'),
                         p_instagram_url=assoc_details.get('instagram_url'),
                         p_supported_activities=assoc_details.get('supported_activities'),
                         p_no_of_partners=assoc_details.get('no_of_partners'),
                         p_no_of_dogs=assoc_details.get('no_of_dogs'),
                         p_country_code=assoc_details.get('country_code'),
                         p_org_id=org_id,
                         p_created_by=assoc_details.get('created_by'),
                         p_project_proposal=assoc_details.get('project_proposal'),
                         x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': '{} association successfully.'.format(
                              'Added' if not assoc_flag else 'Updated'),
                          'association_id': int(association_id.getvalue())}
                if not assoc_flag:
                    assoc_details['association_id'] = result['association_id']
                    assoc_details['status'] = 'A'
                    contact_result = HWAssociation.insert_association_contacts(assoc_details)

                    result['msg'] += contact_result

                rec_result = self.update_assoc_related_details(assoc_details,
                                                               result['association_id'])
                result['msg'] += rec_result

            else:
                result = {'status': Status.OK.value,
                          'msg': 'Failed association - {}'.format(status_code.getvalue())
                          }
        return result

    @staticmethod
    def insert_association_contacts(assoc_details):
        """
        create contact and send invitation if the user is creating new association
        :param assoc_details: json object
        :return:
        """
        result = ' '
        contact_obj = HWContacts()
        contact_result = contact_obj.insert_or_update_contacts(assoc_details)
        if contact_result['status'] == 1:
            result += 'Failed to create a contact.'
        else:
            assoc_details['contact_id'] = contact_result['contact_id']
            invitation_obj = HWInvitations()
            invitation_result = invitation_obj.insert_invitation_details(assoc_details)
            if invitation_result['status'] == 1:
                result = 'Failed to invite.'
        return result

    def update_assoc_related_details(self, assoc_details, association_id):
        """
        Update association related queries
        :param assoc_details: json object
        :param association_id: association_id
        :return:
        """
        result = ' '
        if assoc_details.get('attachments'):
            for attachment in assoc_details['attachments']:
                attachment['association_id'] = association_id
                attachment['created_by'] = assoc_details['created_by']
                HWAssociation.insert_association_documents(attachment)
        if assoc_details.get('addresses'):
            for address in assoc_details['addresses']:
                address['created_by'] = assoc_details['created_by']
                loc_result = self.update_association_locations(address)
                if loc_result['status'] == 1:
                    result += loc_result['msg'] + '.'
        return result

    def update_association_locations(self, address):
        """
        Add or update association locations for shipping and association
        :param address: {"location_id":"", "address":"", "address_1":"", "city":"", "province":"",
        "zip": "", "country":"", "association_id":"", "address_type":"", "address_id":"",
        "status":"", "created_by":""}
        :return: {"status":"", "msg":""}
        """
        with OracleConnectionManager() as conn:
            if address.get('lat') and address.get('lng'):
                lat = address['lat']
                lng = address['lng']
            else:
                lat, lng = self.get_geolocation(address)
            location_id = conn.set_output_param('NUMBER')
            address_id = conn.set_output_param('NUMBER')
            location_flag = True
            if address.get('location_id'):
                location_flag = False
                location_id.setvalue(0, address.get('location_id'))
            if address.get('address_id'):
                address_id.setvalue(0, address.get('address_id'))
            conn.execute("""
                        begin
                         qpex_humanwildlife_pkg.manage_association_locations (
                         :p_location_id,
                         :p_address_line_1,
                         :p_address_line_2,
                         :p_city,
                         :p_province,
                         :p_zip,
                         :p_country,
                         :p_lat,
                         :p_lng,
                         :p_type,
                         :p_status,
                         :p_address_id,
                         :p_created_by,
                         :x_status_code
                         );
                        end;
                """, output_key='x_status_code',
                         p_location_id=location_id,
                         p_address_line_1=address.get('address_line_1'),
                         p_address_line_2=address.get('address_line_2'),
                         p_city=address.get('city'),
                         p_province=address.get('province'),
                         p_zip=address.get('zip'),
                         p_country=address.get('country'),
                         p_lat=lat,
                         p_lng=lng,
                         p_type=address.get('address_type'),
                         p_status=address.get('status', 'A'),
                         p_address_id=address_id,
                         p_created_by=address.get('created_by'))
        status_code = conn.get_output_param(raise_exception=False)
        if status_code == 'SUCCESS':
            result = {'status': Status.OK.value,
                      'msg': 'Address {} successfully'.format(
                          'added' if location_flag else 'updated'),
                      'address_id': int(address_id.getvalue())}
        else:
            result = {'status': Status.ERROR.value,
                      'msg': 'Failed to {0} address - {1}'.format(
                          'added' if location_flag else 'updated',
                          status_code)}
        return result

    @staticmethod
    def insert_association_documents(attachments):
        """
        To add related attachments of associations
        :param attachments: {"file_type":"","file_data":"", "document_type":"",
        "association_id":"", "attachment_id":"", "created_by":""}
        :return: {"status":"", "msg":""}
        """
        result = {}
        with OracleConnectionManager() as conn:
            attachment_id = conn.cursor.var(cx_Oracle.NUMBER)
            status_code = conn.cursor.var(cx_Oracle.STRING)
            conn.cursor.setinputsizes(p_file_data=cx_Oracle.BLOB)
            attachment_flag = True
            if attachments.get('attachment_id'):
                attachment_flag = False
                attachment_id.setvalue(0, attachments.get('attachment_id'))
            else:
                if not attachments.get('association_id'):
                    return
            conn.execute("""
                            begin
                                qpex_humanwildlife_pkg.insert_documents(
                                :p_association_id,
                                :p_file_type,
                                :p_file_name,
                                :p_file_data,
                                :p_document_type,
                                :p_created_by,
                                :x_attachment_id,
                                :x_status_code
                                );
                            end;
                            """, p_association_id=attachments.get('association_id'),
                         p_file_type=attachments.get('file_type'),
                         p_file_name=attachments.get('file_name'),
                         p_file_data=attachments.get('file_data'),
                         p_document_type=attachments['document_type'],
                         p_created_by=attachments['created_by'],
                         x_attachment_id=attachment_id,
                         x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result['status'] = Status.OK.value
                result['attachment_id'] = int(attachment_id.getvalue())
                result['msg'] = 'Attachment {} successfully'.format(
                    'added' if attachment_flag else 'updated')
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = status_code.getvalue()
        return result

    @staticmethod
    def delete_association_documents(attachment_id):
        """
        Delete association documents from associations
        :param attachment_id: NUMBER
        :return:{"status":"", "msg":""}
        """
        if attachment_id:
            return {'status': Status.ERROR.value, 'msg': 'Attachment Id not found'}
        with OracleConnectionManager() as conn:
            status_code = conn.cursor.var(cx_Oracle.STRING)
            conn.execute("""
                    begin
                        qpex_humanwildlife_pkg.delete_documents(
                            :p_attachment_id,
                            :x_status_code
                            );
                    end;""", p_attachment_id=attachment_id,
                         x_status_code=status_code)
        if status_code.getvalue() == 'SUCCESS':
            result = {'status': Status.OK.value,
                      'msg': 'Deleted document successfully'}
        else:
            result = {'status': Status.ERROR.value,
                      'msg': 'Failed to delete document'}
        return result

    def update_project_proposal(self, proposal):
        """
        To update project proposal of association
        :param proposal:{"project_proposal":"", "association_id":""}
        :return:{"status":"", "msg":""}
        """
        with OracleConnectionManager() as conn:
            query = self.sql_file['update_assoc_proposal']
            conn.execute(query, p_project_proposal=proposal['project_proposal'],
                         p_association_id=proposal['association_id'])
            if conn.cursor.rowcount == 1:
                result = {'status': Status.OK.value,
                          'msg': 'Project Proposal updated successfully'}
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Project Proposal update has failed'}

        return result

    def get_association_details(self, jsond):
        """
        Get association details based on user_id
        :param jsond
        :return: {"status": "", "association":[]}
        """
        result = {'status': Status.OK.value}
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_association_details']
            conn.execute(query, p_contact_user_id=jsond['user_id'],
                         p_org_id=jsond['org_id'],
                         p_association_id=jsond['association_id'],
                         p_status=jsond['status'])
            result['association'] = conn.get_result()
        return result

    @staticmethod
    def get_document_details(attachment_id):
        """
        Get Document file data from db
        :param attachment_id: number
        :return: {"file_data":""}
        """
        result = {}
        common_obj = CommonUtils()
        file_data = common_obj.get_attachment_data('file_data', 'qpex_hw_documents',
                                                   'attachment_id',
                                                   attachment_id)
        if file_data is None:
            result = {'status': Status.ERROR.value, 'msg': 'No Data Found'}
        else:
            result['status'] = Status.OK.value
            result['file_data'] = file_data
        return result

    def get_geolocation(self, req):
        """
        Get GEO LOCATION of an address
        :return: lat & lng
        """
        geocode_url = self.strings['geocode_url']
        formatted_address = ''
        if req.get('address_line_1'):
            formatted_address += req['address_line_1']
        if req.get('city'):
            formatted_address += ',' + req['city']
        if req.get('country'):
            formatted_address += ',' + req['country']
        if req.get('zip'):
            formatted_address += ',' + str(req['zip'])
        end_point = geocode_url
        end_point += "&address=" + formatted_address
        end_point += "&key=" + self.api_key
        result = urllib.request.urlopen(end_point.encode('utf-8')).read()
        result = result.replace('\n', '')
        result = ujson.loads(result)
        lat = None
        lng = None
        if result['status'] == 'OK':
            results = result['results'][0]
            lat = results['geometry']['location']['lat']
            lng = results['geometry']['location']['lng']
        return lat, lng

    def update_association_status(self, jsond):
        """
        For updating the association details if it approved or rejected
        and creating a new application
        :param jsond: {"status":"", "association_id":"",
                        "updated_by":""}
        :return:
        """
        with OracleConnectionManager() as conn:
            status_code = conn.cursor.var(cx_Oracle.STRING)
            conn.execute("""
                        BEGIN
                            qpex_humanwildlife_pkg.update_association_status(
                            :p_status,
                            :p_association_id,
                            :p_updated_by,
                            :x_status_code
                            );
                        END;
            """, p_status=jsond['status'],
                         p_association_id=jsond['association_id'],
                         p_updated_by=jsond['updated_by'],
                         x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': "Association {} successfully.".format(
                              'approved' if jsond['status'] == 'A' else 'rejected')}
                if jsond['status'] == 'A':
                    assoc_json = {'org_id': None,
                                  'association_id': jsond['association_id'],
                                  'user_id': None,
                                  'status': None
                                  }
                    assoc_details = self.get_association_details(assoc_json)
                    appl_json = HWApplications.application_json(assoc_details['association'][0],
                                                                jsond['updated_by'])
                    application_obj = HWApplications()
                    appl_result = application_obj.save_application(appl_json)
                    result['msg'] = appl_result['msg']
                    result['request_id'] = appl_result['request_id']
                    result['application_no'] = appl_result['application_no']
            else:
                result = {'status': Status.ERROR.value,
                          'msg': status_code.getvalue()
                          }
        return result
