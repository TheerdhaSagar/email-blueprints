import os
import cx_Oracle

from finapi.models.cms.cms import CMS
from finapi.utils.constants import Status
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil
from finapi.utils import auth_util


@LogUtil.class_module_logs('hw_invitations')
class HWInvitations:

    def __init__(self):
        filename = os.path.basename(os.path.dirname(__file__))
        self.sql_file = sql_util.get_sql(filename)

    def get_invitation_details(self, invite_id=None, org_id=None, invite_status=None):
        """
        To fetch all the invitation details from DB
        :param invite_id: number
        :param org_id: number
        :param invite_status: string
        :return: {"status":"", "invitations": []}
        """
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_invitation_details']
            conn.execute(query, p_invitation_id=invite_id, p_org_id=org_id,
                         p_status=invite_status)
            result = conn.get_result()
        response = {'status': Status.OK.value, 'invitations': result}
        return response

    def insert_invitation_details(self, invitation):
        """
        To insert the invitation details into DB
        :param invitation:
        {"invitation_key": "", "association_name": "", "status":"",
         "contact_id":"", "sender_id":"", "subject":"", "message":"",
         "country":"", "org_id":"", "created_by":""}
        :return: {"status":"", "msg":"", "invitation_id": ""}
        """
        org_id = self.get_org_details(invitation['country'], invitation.get('org_id'))
        with OracleConnectionManager() as conn:
            conn.cursor.setinputsizes(p_message=cx_Oracle.NCLOB)
            status_code = conn.cursor.var(cx_Oracle.STRING)
            invitation_id = conn.cursor.var(cx_Oracle.NUMBER)
            conn.execute("""
                        begin
                            qpex_humanwildlife_pkg.insert_invitations (
                            :p_invitation_key,
                            :p_association_id,
                            :p_association_name,
                            :p_status,
                            :p_contact_id,
                            :p_sender_id,
                            :p_subject,
                            :p_message,
                            :p_country,
                            :p_org_id,
                            :p_created_id,
                            :x_invitation_id,
                            :x_status_code
                            );
                        end;""",
                         p_invitation_key=invitation.get('invitation_key'),
                         p_association_id=invitation.get('association_id'),
                         p_association_name=invitation.get('association_name'),
                         p_status=invitation.get('invite_status', 'C'),
                         p_contact_id=invitation['contact_id'],
                         p_sender_id=invitation.get('sender_id', -1),
                         p_subject=invitation.get('subject'),
                         p_message=invitation.get('message'),
                         p_country=invitation['country'],
                         p_org_id=org_id,
                         p_created_id=invitation.get('created_by', -1),
                         x_invitation_id=invitation_id,
                         x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Added invitation successfully',
                          'invitation_id': int(invitation_id.getvalue())
                          }
                invitation['invitation_id'] = int(invitation_id.getvalue())
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Failed to add the invitation - {}'.format(status_code.getvalue()),
                          'invitation_id': -1
                          }
        return result

    def update_invitation_details(self, invitation):
        """
        To update or resend the invitation details into DB
        :param invitation:
        {"invitation_key": "", "association_name": "", "status":"",
         "contact_id":"", "sender_id":"", "subject":"", "message":"",
         "country":"", "org_id":"", "created_by":""}
        :return: {"status":"", "msg":"", "invitation_id": ""}
        """
        org_id = self.get_org_details(invitation['country'], invitation.get('org_id'))
        with OracleConnectionManager() as conn:
            conn.cursor.setinputsizes(p_message=cx_Oracle.NCLOB)
            status_code = conn.cursor.var(cx_Oracle.STRING)
            conn.execute("""
                        begin
                            qpex_humanwildlife_pkg.update_invitations (
                            :p_invitation_id,
                            :p_invitation_key,
                            :p_association_id,
                            :p_association_name,
                            :p_status,
                            :p_contact_id,
                            :p_sender_id,
                            :p_subject,
                            :p_message,
                            :p_country,
                            :p_org_id,
                            :p_created_id,
                            :x_status_code
                            );
                        end;""",
                         p_invitation_id=invitation['invitation_id'],
                         p_invitation_key=invitation.get('invitation_key'),
                         p_association_id=invitation.get('association_id'),
                         p_association_name=invitation.get('association_name'),
                         p_status=invitation.get('invite_status', 'C'),
                         p_contact_id=invitation['contact_id'],
                         p_sender_id=invitation.get('sender_id', -1),
                         p_subject=invitation.get('subject'),
                         p_message=invitation.get('message'),
                         p_country=invitation['country'],
                         p_org_id=org_id,
                         p_created_id=invitation.get('created_by', -1),
                         x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Updated invitation successfully.',
                          }
                if invitation.get('invite_status') == 'I':
                    mail_status = self.send_invitation_email(invitation)
                    result['msg'] += mail_status
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Failed to update the invitation - {}'.format(
                              status_code.getvalue()),
                          'invitation_id': -1
                          }
        return result

    def send_invitation_email(self, invitation):
        """
        Send Invitation to the user for registering in cruscott
        :param invitation:{"invitation_key": "", "association_name": "", "status":"",
         "contact_id":"", "sender_id":"", "subject":"", "message":"",
         "country":"", "org_id":"", "created_by":"", "invitation_id":""}
        :return: {"status":""}
        """
        email_address = invitation.get('email')
        if not invitation.get('email'):
            with OracleConnectionManager() as conn:
                query = self.sql_file['get_contact_details']
                conn.execute(query, p_contact_id=invitation['contact_id'])
                email_address = conn.get_single_result()['email']
        props = {
            'email': email_address,
            'email_subject': invitation['subject'],
            'email_message': invitation['message'],
            'email_workflow_trigger': 'send_email'
        }
        cms = CMS()
        cms_status = cms.create_contact(props)
        if cms_status.get('status') == 'ERROR':
            status = 'Failed to send email'
        else:
            status = 'Mail is sent'
        return status

    def get_org_details(self, country, org):
        countries = self.sql_file['countries_orgs']
        org_id = org if org else countries.get(country)
        return org_id

    def register_user(self, jsond):
        encrypted_password = auth_util.encrypt_legacy(jsond['password'])
        with OracleConnectionManager() as conn:
            status_code = conn.cursor.var(cx_Oracle.STRING)
            conn.execute("""
            begin
                qpex_humanwildlife_pkg.register_user(
                    :p_invite_id,
                    :p_user_name,
                    :p_password,
                    :p_encrypted_password,
                    :p_org_id,
                    :x_status_code
                );
            end; """, p_invite_id=jsond['invite_id'],
                         p_user_name=jsond['user_name'],
                         p_password=jsond['password'],
                         p_encrypted_password=encrypted_password,
                         p_org_id=jsond['org_id'],
                         x_status_code=status_code)
        return status_code.getvalue()
