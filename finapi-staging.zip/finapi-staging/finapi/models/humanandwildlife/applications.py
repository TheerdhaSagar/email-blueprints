import os
import cx_Oracle

from finapi.models.donation.donation import Donation
from finapi.utils.common_utils import CommonUtils
from finapi.utils.constants import Status
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('hw_applications')
class HWApplications:

    def __init__(self):
        filename = os.path.basename(os.path.dirname(__file__))
        self.sql_file = sql_util.get_sql(filename)
        self.donation_file = sql_util.get_sql('donation')
        self.donation_obj = Donation()

    def get_applications(self, data):
        """
        To get a single HW application details or
        summary of all HW applications
        :param data:{
                   "header_id":"",
                   "org":"",
                   "assoc_id":"",
                   "status":"",
                   "receipt":"",
                   "request_type":"",
                   "year":""
                }
        :return: {"status":"", "result":""}
        """
        result = dict()
        with OracleConnectionManager() as conn:
            if data['header_id']:
                query = self.sql_file['application_header_query']
            else:
                query = self.sql_file['application_summary_query']
            if data['status'] == 'O':
                # To get waybill details
                waybill_invoice_query = self.donation_file['waybill_invoice_query']
                waybill_query = ', (' + waybill_invoice_query.format('DISTINCT wnd.delivery_id')
                waybill_query += ') waybill'

                # To get invoice number details
                waybill_query += ', (' + waybill_invoice_query.format('cta.trx_number')
                waybill_query += ') invoice'
                if data['year']:
                    year_cond = "AND to_char(h.created_date, 'YYYY') = '" + str(
                        data['year']) + "'"
                else:
                    year_cond = ''
                query = query.format(waybill=waybill_query,
                                     year_cond=year_cond,
                                     waiting_for='')
            else:
                waiting_query = self.donation_file['waiting_for_query']
                query = query.format(waybill='', year_cond='',
                                     waiting_for=waiting_query)
            if data['header_id']:
                conn.execute(query, p_header_id=data['header_id'],
                             p_org_id=data['org'], p_assoc_id=data['assoc_id'],
                             p_status=data['status'])
            else:
                conn.execute(query, p_header_id=data['header_id'],
                             p_org_id=data['org'], p_assoc_id=data['assoc_id'],
                             p_status=data['status'],
                             p_request_type=data['request_type'],
                             p_receipt=data['receipt'])
            header = conn.get_result()
            if data['header_id']:
                query = self.donation_file['application_lines_query']
                conn.execute(query, p_header_id=data['header_id'])
                lines = conn.get_result()

                query = self.sql_file['application_attachments_query']
                conn.execute(query, p_header_id=data['header_id'])
                attachments = conn.get_result()

                address_query = self.sql_file['get_association_address']
                conn.execute(address_query, p_association_id=header[0]['org_id'])
                addresses = conn.get_result()

                header[0]['lines'] = lines
                header[0]['attachments'] = attachments
                header[0]['addresses'] = addresses

            result['status'] = Status.OK.value
            result['result'] = header
        return result

    def save_application(self, req_data):
        """
        Save  HW Application in db
        :param req_data: refer application_json def
        :return:
        """
        with OracleConnectionManager() as conn:
            # get count of no. of applications submitted by association
            query = self.donation_file['assoc_application_count_query'] + \
                    self.sql_file['application_hw_count']
            conn.execute(query, p_org_id=req_data['org_id'])
            count = conn.cursor.fetchone()[0]
        if count > 0:
            req_data['mail_template_id'] = self.get_application_template_id(
                req_data.get('country').upper())
        result = self.insert_application_header(req_data)

        if result['status'] == 0:
            result['msg'] = 'Application saved successfully'
            req_data['request_id'] = result.get('request_id')
            req_data['application_no'] = result.get('application_no')
            req_data['appl_count'] = count
            self.donation_obj.prepare_notification(req_data)
        return result

    @staticmethod
    def get_application_template_id(country):
        template_id = 823641
        if country == 'IT':
            template_id = 838774
        elif country == 'FR' or country == 'BE_FR':
            template_id = 838789
        elif country == 'NL' or country == 'BE_NL':
            template_id = 838782
        elif country == 'DE':
            template_id = 838780
        return template_id

    def insert_application_header(self, req_data):
        """
        To create H&W applications in donation application table
        :param req_data:
        :return:
        """
        result = dict()
        with OracleConnectionManager() as conn:
            header_id = conn.cursor.var(cx_Oracle.NUMBER)
            status_code = conn.cursor.var(cx_Oracle.STRING)
            application_no = conn.cursor.var(cx_Oracle.STRING)
            random_seq = Donation.get_random_sequence(4)
            conn.execute("""
                    begin
                        qpex_humanwildlife_pkg.insert_request_header(
                            :x_request_header_id,
                            :p_org_id,
                            :p_random_seq,
                            :p_request_type,
                            :p_created_by,
                            :p_ship_address,
                            :p_contact_name,
                            :p_contact_phone,
                            :p_carrier_note,
                            :p_message,
                            :p_volunteers,
                            :p_operators,
                            :p_adoptions_dog,
                            :p_adoptions_cat,
                            :p_events,
                            :p_events_outside,
                            :p_shelter_type,
                            :p_workflow_name,
                            :x_application_no,
                            :x_status_code
                        );
                    end; """, x_request_header_id=header_id,
                         p_org_id=req_data.get('org_id'),
                         p_random_seq=random_seq,
                         p_request_type=req_data.get('request_type', 'H'),
                         p_created_by=req_data.get('user_id'),
                         p_ship_address=req_data.get('ship_address'),
                         p_contact_name=req_data.get('contact_name'),
                         p_contact_phone=req_data.get('contact_phone'),
                         p_carrier_note=req_data.get('carrier_note'),
                         p_message=req_data.get('need_desc'),
                         p_volunteers=req_data.get('volunteers'),
                         p_operators=req_data.get('operators'),
                         p_adoptions_dog=req_data.get('adoptions_dog'),
                         p_adoptions_cat=req_data.get('adoptions_cat', 0),
                         p_events=req_data.get('events'),
                         p_events_outside=req_data.get('events_outside'),
                         p_shelter_type=req_data.get('shelter_type'),
                         p_workflow_name=req_data.get('wf_name'),
                         x_application_no=application_no,
                         x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result['status'] = Status.OK.value
                result['request_id'] = int(header_id.getvalue())
                result['application_no'] = application_no.getvalue()
                attachments = req_data.get('attachments', [])
                lines = req_data.get('lines', [])

                for line in lines:
                    line['header_id'] = result['request_id']
                    line['user_id'] = req_data.get('user_id')
                    line_result = self.donation_obj.insert_request_line(line)
                    if line_result['status'] == 'ERROR':
                        result['msg'] = line_result['msg']
                        result['status'] = line_result['status']

                for attachment in attachments:
                    attachment['header_id'] = result['request_id']
                    attachment['user_id'] = req_data.get('user_id')
                    attachment['update_flag'] = 'N'
                    attachment['verified_flag'] = 'N'
                    attach_result = self.donation_obj.insert_request_attachment(attachment)
                    if attach_result['status'] == 'ERROR':
                        result['msg'] = attach_result['msg']
                        result['status'] = attach_result['status']
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = status_code.getvalue()
        return result

    def create_hw_copy_application(self, req):
        """
        Copy HW application again
        :param req:
        :return:
        """
        with OracleConnectionManager() as conn:
            request_id = conn.cursor.var(cx_Oracle.NUMBER)
            application_no = conn.cursor.var(cx_Oracle.STRING)
            status_code = conn.cursor.var(cx_Oracle.STRING)
            conn.execute("""
                begin
                    qpex_humanwildlife_pkg.create_hw_application(
                        :p_org_id,
                        :p_request_id,
                        :p_request_type,
                        :p_is_copy,
                        :p_created_by,
                        :x_request_header_id,
                        :x_application_no,
                        :x_status_code
                    );
                end; """, p_org_id=req['org_id'],
                         p_request_id=req['request_header_id'],
                         p_request_type=req['request_type'],
                         p_is_copy=req['is_copy'],
                         p_created_by=req['user_id'],
                         x_request_header_id=request_id,
                         x_application_no=application_no,
                         x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                req['application_no'] = application_no.getvalue()
                req['request_id'] = request_id.getvalue()
                req['request_header_id'] = req['request_id']

                if req['is_copy'] == 'Y':
                    msg = 'Application copied successfully'
                else:
                    msg = '{} application created successfully' \
                        .format('Humans & Wild Life')
                result = {
                    'status': Status.OK.value,
                    'msg': msg,
                    'request_id': req['request_id'],
                    'application_no': req['application_no']
                }

                self.donation_obj.prepare_notification(req, notify_user=False)
            else:
                result = {
                    'status': Status.ERROR.value,
                    'msg': 'Error creating HW application - ' + str(status_code.getvalue())
                }

        return result

    def add_address(self, req_data):
        """
        Adding shipping address for quote creation
        :param req_data:
        :return:
        """
        result = dict()
        attribute_names = self.donation_file['address_attributes'].split(',')
        missing_keys = ''
        for i in range(len(attribute_names)):
            if attribute_names[i].strip() not in req_data:
                missing_keys += attribute_names[i] + ','

        if missing_keys:
            missing_keys = missing_keys[:-1]
            result['status'] = Status.ERROR.value
            result['msg'] = 'Missing ' + missing_keys
            result['msg'] += ' parameter(s)'
            return result

        with OracleConnectionManager() as conn:
            msg_data = conn.cursor.var(cx_Oracle.STRING)
            return_status = conn.cursor.var(cx_Oracle.STRING)
            party_site_id = conn.cursor.var(cx_Oracle.NUMBER)
            price_list_id = conn.cursor.var(cx_Oracle.NUMBER)
            conn.execute("""
            begin
                qpex_customer_pkg.create_ship_to_address (
                    :p_org_type,
                    :p_project_type,
                    :p_address1,
                    :p_address2,
                    :p_address3,
                    :p_assoc_name,
                    :p_city,
                    :p_postal_town,
                    :p_postal_code,
                    :p_country,
                    :p_org_id,
                    :p_carrier_note,
                    :p_phone_number,
                    :x_msg_data,
                    :x_return_status,
                    :x_party_site_id,
                    :x_price_list_id
                );
                commit;
            end; """, p_org_type=req_data['org_type'],
                         p_project_type=req_data['request_type'],
                         p_address1=req_data['address1'],
                         p_address2=req_data['address2'],
                         p_address3=req_data['address3'],
                         p_assoc_name=req_data['assoc_name'],
                         p_city=req_data['city'],
                         p_postal_town=req_data['town'],
                         p_postal_code=req_data['postal_code'],
                         p_country=req_data['country'],
                         p_org_id=req_data['org_id'],
                         p_carrier_note=req_data['carrier_note'],
                         p_phone_number=req_data['phone_number'],
                         x_msg_data=msg_data,
                         x_return_status=return_status,
                         x_party_site_id=party_site_id,
                         x_price_list_id=price_list_id)
        if return_status.getvalue() == 'S':
            req_data['party_site_id'] = party_site_id.getvalue()
            req_data['price_list_id'] = price_list_id.getvalue()
            result = HWApplications.create_quote(req_data)
            if result['status'] != 0:
                msg = result['msg']
                result['msg'] = 'Address created but '
                result['msg'] += 'failed to create Quote'
                result['msg'] += ' - ' + str(msg)
        else:
            result['status'] = Status.ERROR.value
            result['msg'] = 'Failed to add address - '
            result['msg'] += str(return_status.getvalue())
        return result

    @staticmethod
    def create_quote(req_data):
        """
        Create quote for HW applications
        :param req_data:
        :return:
        """
        result = dict()
        with OracleConnectionManager() as conn:
            status_code = conn.cursor.var(cx_Oracle.STRING)
            quote_header_id = conn.cursor.var(cx_Oracle.NUMBER)
            conn.cursor.execute("""
            begin
                qpex_humanwildlife_pkg.create_quote (
                    :x_quote_header_id,
                    :p_request_id,
                    :p_created_user_id,
                    :p_party_site_id,
                    :p_organization_id,
                    :p_quote_name,
                    :p_dog_meals,
                    :p_cat_meals,
                    :p_carrier_note,
                    :p_price_list_id,
                    :x_status_code
                );
            end; """, x_quote_header_id=quote_header_id,
                                p_request_id=req_data['request_id'],
                                p_created_user_id=req_data['user_id'],
                                p_party_site_id=req_data['party_site_id'],
                                p_organization_id=req_data['org_id'],
                                p_quote_name=req_data['quote_name'],
                                p_dog_meals=req_data['dog_meals'],
                                p_cat_meals=req_data['cat_meals'],
                                p_carrier_note=req_data['carrier_note'],
                                p_price_list_id=req_data['price_list_id'],
                                x_status_code=status_code)
        if status_code.getvalue() == 'SUCCESS':
            result['status'] = Status.OK.value
            result['msg'] = 'Quote created successfully'
            result['quote_header_id'] = quote_header_id.getvalue()
        else:
            result['status'] = Status.ERROR.value
            result['msg'] = status_code.getvalue()
        return result

    @staticmethod
    def application_json(assoc_details, created_by):
        """
        create application create json
        :param assoc_details:
        :param created_by:
        :return:
        """
        contact_details = list([x for x in assoc_details[
            'contacts'] if x['primary_flag'] == 'Y'])[0]
        str_validator = lambda s: s or ''
        common_obj = CommonUtils()
        user_details = common_obj.get_user_details_based_on_id(created_by)
        application_json = {
            'user_id': created_by,
            'org_id': assoc_details['association_id'],
            'org_name': assoc_details['association_name'],
            'phone': contact_details['phone'],
            'address': '',
            'province': '',
            'city': '',
            'country': assoc_details['country_code'],
            'zip': '',
            'contact_phone': contact_details['phone'],
            'carrier_note': '',
            'request_type': 'H',
            'ship_address': '',
            'user_email': contact_details['email'],
            'need_desc': '',
            'assoc_type': assoc_details['type'],
            'shelter_type': assoc_details['sub_type'],
            'volunteers': '',
            'operators': '',
            'events': '',
            'events_outside': '',
            'adoptions_dog': assoc_details['no_of_dogs'],
            'adoptions_cat': '',
            'adoptions-addressed': '',
            'lines': [
                {
                    'pet_type': 'DOG',
                    'no_of_pets': assoc_details['no_of_dogs'],
                    'no_of_qty': '',
                    'pet_size': ''
                }
            ],
            'attachments': [],
            'consent_projects': 'Y',
            'consent_profiling': 'Y',
            'consent_foundation': 'Y',
            'wf_name': 'QPEX_DDESK_HW_IT',
            'contact_name': ' '.join([str_validator(contact_details['first_name']),
                                      str_validator(contact_details['last_name'])]),
            'user_name': user_details['user_description']
        }
        return application_json
