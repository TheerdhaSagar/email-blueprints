import os
import cx_Oracle

from finapi.models.cms.cms import CMS
from finapi.utils.constants import Status
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('hw_contacts')
class HWContacts:

    def __init__(self):
        filename = os.path.basename(os.path.dirname(__file__))
        self.sql_file = sql_util.get_sql(filename)

    def insert_or_update_contacts(self, contact_details):
        """
        To insert or update the contact details based on given details
        :param contact_details:
            {"first_name": "", "last_name":"", "association_id":"",
            "email":"", "phone":"","primary_flag":"","status":"" }
        :return:{"status":"", "msg":"", "contact_id":""}
        """
        with OracleConnectionManager() as conn:

            hubspot_contact = True
            status_code = conn.cursor.var(cx_Oracle.STRING)
            contact_id = conn.cursor.var(cx_Oracle.NUMBER)
            if contact_details.get('contact_id'):
                hubspot_contact = False
                contact_id.setvalue(0, contact_details['contact_id'])
            else:
                query = self.sql_file['check_email_address']
                conn.execute(query, p_email_address=contact_details['email'])
                email_result = conn.get_single_result()['email_count']
                if email_result > 0:
                    return {'status': Status.ERROR.value,
                            'msg': 'Email Address already exists'}
            conn.execute("""
                        begin
                        qpex_humanwildlife_pkg.manage_contacts(
                            :p_contact_id,
                            :p_contact_user_id,
                            :p_first_name,
                            :p_last_name,
                            :p_association_id,
                            :p_email,
                            :p_phone,
                            :p_status,
                            :p_primary_flag,
                            :p_created_id,
                            :x_status_code
                        );
                        end;""",
                         p_contact_id=contact_id,
                         p_contact_user_id=contact_details.get('contact_user_id'),
                         p_first_name=contact_details['first_name'],
                         p_last_name=contact_details.get('last_name'),
                         p_association_id=contact_details.get('association_id'),
                         p_email=contact_details['email'],
                         p_phone=contact_details.get('phone'),
                         p_status=contact_details.get('status', 'A'),
                         p_primary_flag=contact_details.get('primary_flag', 'Y'),
                         p_created_id=contact_details.get('created_by', -1),
                         x_status_code=status_code
                         )
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Contact {} successfully.'.format(
                              'created' if hubspot_contact else 'updated'),
                          'contact_id': int(contact_id.getvalue()),
                          'contact_count': self.insert_invitation_check(conn, contact_details)
                          }

                if result['contact_count'] > 1:
                    hubspot_contact = False
                if hubspot_contact:
                    contact_result = HWContacts.create_hubspot_contact(contact_details)
                    result['msg'] += contact_result
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Failed to {1} contact - {0}'.format(
                              status_code.getvalue(),
                              'create' if hubspot_contact else 'update'),
                          'contact_id': -1
                          }
        return result

    def insert_invitation_check(self, conn, contact_details):
        contact_count = 0
        if contact_details.get('association_id'):
            contacts_query = self.sql_file['association_contact_count']
            conn.execute(contacts_query,
                         p_association_id=contact_details.get('association_id'))
            contact_count = conn.get_single_result()['contact_count']
        return contact_count

    @staticmethod
    def delete_contact_details(contact_id):
        """
        Delete a contact from DB
        :param contact_id: number
        :return:
        """
        with OracleConnectionManager() as conn:
            status_code = conn.cursor.var(cx_Oracle.STRING)
            conn.execute("""
                        BEGIN
                            qpex_humanwildlife_pkg.delete_contacts(
                            :p_contact_id,
                            :x_status_code
                            );
                        END;""", p_contact_id=contact_id,
                         x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                result = {'status': Status.OK.value,
                          'msg': 'Deleted contacted Id - {} successfully'.format(contact_id)}
            else:
                result = {'status': Status.ERROR.value,
                          'msg': 'Failed to delete contact- {}'.format(status_code.getvalue())}
        return result

    @staticmethod
    def create_hubspot_contact(contact_details):
        """
        Create hubspot contact
        :param contact_details: json object
        :return:
        """
        props = {
            'email': contact_details.get('email'),
            'firstname': contact_details.get('first_name'),
            'lastname': contact_details.get('last_name'),
            'hs_persona': 'persona_2',  # Dog Association Persona
            'company': contact_details.get('association_name'),
            'country': contact_details.get('country')
        }

        cms_obj = CMS()
        contact_result = cms_obj.create_contact(props)
        if contact_result.get('status') == 'ERROR':
            status = 'Failed to create contact in hubspot'
        else:
            status = 'Hubspot contact is created successfully'
        return status
