import os
import base64
import json
import re
import urllib.request
import urllib.parse
import urllib.error
import tempfile

from copy import deepcopy
from datetime import datetime
from math import radians, sin, cos, acos

import requests
import cx_Oracle
import xlrd
import ujson

from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.log_util import LogUtil
from finapi.utils.code_util import Code_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.models.reports.report import Report
from finapi.models.cms.cms import CMS


@LogUtil.class_module_logs('storelocator')
class StoreLocator(object):
    countries_list = {'AL': 'Albania', 'AT': 'Austria', 'BE': 'Belgium',
                      'CA': 'Canada', 'HR': 'Croatia', 'CY': 'Cyprus',
                      'CZ': 'Czech Republic', 'FI': 'Finland',
                      'FR': 'France', 'DE': 'Germany', 'GR': 'Greece',
                      'HK': 'Hong Kong', 'IL': 'Israel', 'IT': 'Italy',
                      'JP': 'Japan', 'LV': 'Latvia', 'LI': 'Liechtenstein',
                      'LT': 'Lithuania', 'MT': 'Malta',
                      'NL': 'Netherlands', 'NO': 'Norway',
                      'PL': 'Poland', 'PT': 'Portugal', 'RO': 'Romania',
                      'RU': 'Russia', 'SM': 'San Marino',
                      'SG': 'Singapore', 'SI': 'Slovenia',
                      'KR': 'South Korea', 'ES': 'Spain',
                      'SE': 'Sweden', 'CH': 'Switzerland', 'TW': 'Taiwan',
                      'TH': 'Thailand', 'TR': 'Turkey',
                      'AE': 'United Arab Emirates',
                      'UK': 'United Kingdom', 'US': 'United States',
                      'GB': 'Great Britain', 'MC': 'Monaco'}

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.api_key = os.environ['MAP_API_KEY']
        self.api_url = os.environ['GATEWAY_URL']
        self.connection = None
        self.cursor = None
        self.session = requests.Session()
        self.session.trust_env = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def read_file(self, req):
        result = {}
        try:
            self.acquire()
            file_decode = base64.b64decode(req['base64'])
            with tempfile.NamedTemporaryFile(suffix='.xls') as file_path:
                file_path.write(file_decode)
                file_path.seek(0)
                book = xlrd.open_workbook(file_path.name)
            result = self.get_sheet_data(book)
            if result['data']:
                result['category_id'] = req['category_id']
        finally:
            self.release()
        return result

    @staticmethod
    def format_column_name(column_name):
        formatted_column_name = re.sub(r'[^a-zA-Z0-9 ]', r'', column_name)
        formatted_column_name = formatted_column_name.strip()
        formatted_column_name = " ".join(formatted_column_name.split(" "))
        formatted_column_name = formatted_column_name.replace(
            " ", "_").lower()
        return formatted_column_name

    @staticmethod
    def get_sheet_columns(data):
        columns = []
        column_types = []
        for column_index in range(data.ncols):
            column = data.cell_value(0, column_index)
            if column:
                columns.append(StoreLocator.format_column_name(column))
                column_types.append(data.cell_type(1, column_index))
        return columns, column_types

    def parse_sheet_data(self, columns, data, datemode):
        sheet_data = []
        for row_index in range(1, data.nrows):
            row_data = {}
            row_values = data.row_values(row_index)
            for column_index, column_name in enumerate(columns):
                if column_name == 'zip_code':
                    zip_code = str(row_values[column_index]) or ''
                    row_data[column_name] = zip_code.split('.')[0]
                elif isinstance(row_values[column_index], str):
                    row_data[column_name] = self.encode_value(row_values[column_index])
                else:
                    row_data[column_name] = StoreLocator.parse_cell_date(
                        cell_type=data.cell_type(row_index, column_index),
                        value=row_values[column_index],
                        datemode=datemode
                    )
            sheet_data.append(row_data)
        return sheet_data

    def get_sheet_data(self, book):
        result = {}
        msg = ''
        sheet_names = book.sheet_names()
        data = book.sheet_by_name(sheet_names[0])
        if data.nrows < 2:
            return {'status': 1, 'msg': 'Uploaded sheet has no data'}

        cols, _ = StoreLocator.get_sheet_columns(data)
        store_columns = self.sql_file['store_upload_columns']
        store_column_map = self.sql_file['store_upload_column_map']
        required_columns = self.sql_file['store_upload_required_columns']

        result['mapped_columns'] = []

        for column in store_columns:
            result['mapped_columns'].append({
                'column_name': column if column in cols else '',
                'oracle_column_name': column
            })
            if column not in cols and column in required_columns:
                msg += '%s, ' % store_column_map[column]

        if len(cols) < len(required_columns):
            msg = 'Missing mandatory column(s) %s. Please check by downloading '\
                'sample file' % msg[:-2]
            return {'status': 1, 'msg': msg}

        result['data'] = self.parse_sheet_data(cols, data, book.datemode)
        result['oracle_columns'] = store_columns
        result['sheet_columns'] = cols
        return result

    def get_country_name(self, country):
        for country_code, country_name in list(self.countries_list.items()):
            if country_code.lower() == country.lower() or\
                    country_name.lower() == country.lower():
                return (country_code, country_name)
        return None

    def get_updated_stores(self, req):
        stores = req.get('data', [])
        if not stores:
            return stores
        country = self.get_country_name(stores[0]['country'])
        for store in stores:
            store['storelocator_flag'] = req.get('storelocator_flag')
            store['shop_campaigns'] = req.get('shop_campaigns')
            store['home_delivery_flag'] = req.get('home_delivery')
            store['category_id'] = req.get('category_id', [])
            store['user_verified_flag'] = 'N'
            store['store_active'] = req.get('store_active', 'Y')
            if country:
                store['country_code'] = country[0]
                store['country_name'] = country[1]
        return stores

    def insert_stores(self, req):
        result = {'status': 0, 'msg': 'Stores added successfully'}
        data = self.get_updated_stores(req)
        category_ids = req.get('category_id', [])
        if not category_ids:
            category_ids = [-1]
        stores = {}
        for key in list(data[0].keys()):
            stores.update({key: [store[key] for store in data]})
        with OracleConnectionManager() as conn:
            conn.execute(self.sql_file['store_insert_pkg_call'],
                         output_key='x_status_code',
                         p_storelocator_flag=req.get('storelocator_flag'),
                         p_campaigns=req.get('shop_campaigns', []) or [''],
                         p_home_delivery_flag=req.get('home_delivery'),
                         p_store_type=req.get('store_type'),
                         p_user_id=req.get('user_id'),
                         p_shop_name=stores['shop_name'],
                         p_address=stores['address'],
                         p_city=stores['city'],
                         p_province=stores['province'],
                         p_zip_code=stores['zip_code'],
                         p_country_code=stores['country_code'],
                         p_country_name=stores['country_name'],
                         p_phone=stores['phone'],
                         p_fax=stores['fax'],
                         p_email=stores['email'],
                         p_vat=stores['vat'],
                         p_start_date=stores['start_date'],
                         p_end_date=stores['end_date'],
                         p_category_ids=category_ids)
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result['status'] = 1
                result['msg'] = 'Failed to load stores. %s' % status
                return result

        country_code = data[0]['country_code']
        result = self.update_store_location(country_code)
        if result.get('status') != 0:
            return result

        with OracleConnectionManager() as conn:
            query = self.sql_file['uploaded_shops_query']
            conn.execute(query, p_country_code=country_code,
                         p_user_id=req.get('user_id'))
            store_data = conn.get_result()
            for store in store_data:
                store['category_id'] = category_ids
            result['data'] = store_data
        return result

    @ staticmethod
    def parse_cell_date(cell_type, value, datemode):
        if cell_type == xlrd.XL_CELL_DATE:
            value = datetime(*xlrd.xldate_as_tuple(value, datemode))
            return value.strftime('%d-%b-%Y')
        return str(value) if value else ''

    def get_geocode_url(self, data):
        geocode_url = self.sql_file['geocode_url']
        try:
            address = self.decode_value(data.get('address', ''), False)
            if data.get('city'):
                address += ',%s' % self.decode_value(data['city'], False)
            if data.get('province'):
                address += ',%s' % self.decode_value(data['province'], False)
            if data.get('country'):
                address += ',%s' % data['country']
            if data.get('zip_code'):
                address += ',%s' % data['zip_code']
            if address:
                return '%s&address=%s&key=%s' % (geocode_url, urllib.parse.quote(address), self.api_key)
        except Exception:
            pass
        return None

    def get_location_data(self, data):
        location = {}
        try:
            geocode_url = self.get_geocode_url(data)
            if not geocode_url:
                return location

            response = urllib.request.urlopen(geocode_url).read().decode('utf-8')
            if not response:
                return location

            response = ujson.loads(response)
            if response.get('status') != 'OK':
                return location

            results = response.get('results')
            if results:
                location = results[0]
        except Exception:
            pass
        return location

    @ staticmethod
    def get_geo_location(location):
        geometry = location.get('geometry')
        if geometry and geometry.get('location'):
            return geometry.get('location')
        return None

    @ staticmethod
    def get_address_component(location, component_type):
        components = location.get('address_components', [])
        for component in components:
            types = component.get('types', [])
            if component_type in types:
                return component
        return None

    def update_store_location(self, country_code, all_stores=False):
        result = {'status': 0, 'msg': 'Stores loaded successfully'}
        data = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['store_without_location_query']
            if not all_stores:
                query += self.sql_file['store_without_location_day_condition']
            conn.cursor.execute(query, p_country_code=country_code)
            data = conn.get_result()
        batch_data = []
        for row in data:
            location = self.get_location_data(row)
            geo_location = self.get_geo_location(location)
            if geo_location:
                row['lat'] = geo_location.get('lat', -1)
                row['lng'] = geo_location.get('lng', -1)
                batch_data.append(row)

            if batch_data and len(batch_data) % 100 == 0:
                result = self.update_store_location_in_db(batch_data)
                batch_data = []
        if batch_data:
            result = self.update_store_location_in_db(batch_data)
        return result

    def update_store_location_in_db(self, data):
        result = {'status': 0, 'msg': 'Location data updated for shops'}
        stores = {}
        for key in list(data[0].keys()):
            stores.update({key: [row.get(key) for row in data]})

        with OracleConnectionManager() as conn:
            conn.execute(self.sql_file['store_location_update_pkg_call'],
                         output_key='x_status_code',
                         p_shop_id=stores['shop_id'],
                         p_lat=stores['lat'],
                         p_lng=stores['lng'])
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result['status'] = 1
                result['msg'] = 'Failed to update location data %s' % status
        return result

    def get_sequence(self):
        query = self.sql_file['store_locator_sequence']
        data = self.cursor.execute(query).fetchone()
        shop_id = int(data[0])
        return shop_id

    def update(self, jsond):
        status = 'success'
        shop_id = ''
        try:
            self.acquire()
            query = self.sql_file['store_locator_update']
            category_id_query = self.sql_file['update_category_ids']
            category_ids = []
            for i in range(len(jsond)):
                self.cursor.setinputsizes(p_address=cx_Oracle.NCHAR)
                self.cursor.setinputsizes(p_city=cx_Oracle.NCHAR)
                self.cursor.setinputsizes(p_prov=cx_Oracle.NCHAR)
                self.cursor.setinputsizes(p_shop_name=cx_Oracle.NCHAR)
                self.cursor.execute(query, p_shop_name=jsond[i]['shop_name'],
                                    p_address=jsond[i]['address'],
                                    p_city=jsond[i]['city'],
                                    p_prov=jsond[i]['province'],
                                    p_zip_code=jsond[i]['zip_code'],
                                    p_country_code=jsond[i]['country_code'],
                                    p_country_name=jsond[i]['country_name'],
                                    p_tel=jsond[i]['phone'],
                                    p_fax=jsond[i]['fax'],
                                    p_email=jsond[i]['email'],
                                    p_lat=jsond[i]['lat'],
                                    p_lng=jsond[i]['lng'],
                                    p_verified_by_google=jsond[i][
                                        'verified_by_google'],
                                    p_shop_id=jsond[i]['shop_id'],
                                    p_vat=jsond[i]['vat'],
                                    p_lat_updated_by=jsond[i][
                                        'last_updated_by'],
                                    p_user_verified_flag=jsond[i][
                                        'user_verified_flag'],
                                    p_storelocator_flag=jsond[i][
                                        'storelocator_flag'],
                                    p_home_delivery=jsond[i]['home_delivery_flag'],
                                    p_shop_campaigns=jsond[i]['shop_campaigns'],
                                    p_store_active=jsond[i].get('store_active', 'Y'))
                if self.cursor.rowcount != 1:
                    status = 'error'
                else:
                    if 'delete_brands' in jsond[i] and len(
                            jsond[i]['delete_brands']) > 0:
                        self.delete_brands(
                            {'category_ids': jsond[i]['delete_brands'],
                             'shop_id': jsond[i]['shop_id']})
                    status = 'success'
                    shop_id = jsond[i]['shop_id']
                    category_ids = []
                    for j in range(len(jsond[i]['category_id'])):
                        category_ids.append({
                            'shop_id': jsond[i]['shop_id'],
                            'category_id': int(jsond[i]['category_id'][j]),
                            'last_updated_by': jsond[i]['last_updated_by'],
                            'created_by': jsond[i]['created_by']
                        })
                    if len(category_ids) > 0:
                        self.cursor.executemany(
                            category_id_query, category_ids)
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return {'status': status, 'shop_id': shop_id}

    # encode and return value
    def encode_value(self, value):
        if value:
            value = value.strip()
        return value

    def save(self, jsond):
        status = 'error'
        try:
            self.acquire()
            shop_id = jsond[0]['shop_id']
            category_ids = []
            for i in range(len(jsond)):
                for j in range(len(jsond[i]['category_id'])):
                    category_ids.append(
                        {'shop_id': jsond[i]['shop_id'],
                         'category_id': int(jsond[i]['category_id'][j]),
                         'created_by': jsond[i]['created_by'],
                         'last_updated_by': jsond[i]['last_updated_by']})
                del jsond[i]['category_id']
            if len(jsond) > 0:
                field_string = "("
                parameter_string = "("
                for key, value in jsond[0].items():
                    field_string += str(key) + ','
                    parameter_string += ':' + str(key) + ','
                field_string = field_string[:-1]
                parameter_string = parameter_string[:-1]
                field_string += ")"
                parameter_string += ")"
                self.cursor.setinputsizes(city=cx_Oracle.NCHAR,
                                          shop_name=cx_Oracle.NCHAR,
                                          province=cx_Oracle.NCHAR,
                                          address=cx_Oracle.NCHAR)
                self.cursor.prepare(""" insert into qpex_store_locator """ +
                                    field_string + """ values """ +
                                    parameter_string)
                self.cursor.executemany(None, jsond)
                status = 'success'
                if self.cursor.rowcount == len(jsond):
                    query = self.sql_file['insert_category_ids']
                    self.cursor.executemany(query, category_ids)
                else:
                    status = 'error'
        finally:
            if status == 'success':
                self.connection.commit()
            self.release()
        return {'status': status, 'shop_id': shop_id}

    def iteritems(self, line):
        row_data = []
        for _, value in line.items():
            value = self.encode_value(value)
            row_data.append(value)
        row_data = tuple(row_data)
        return row_data

    def search(self, jsond):
        latitude = None
        longitude = None
        brand_condition = ''
        address = ''
        city = ''
        shop_campaign_condition = ''
        home_delivery = ''
        try:
            # For filtering the shops participating in a specific campaign
            if jsond.get('shop_campaigns'):
                if isinstance(jsond.get('shop_campaigns'), list):
                    store_campaign = ','.join('\'' + str(shop) + '\''
                                              for shop in jsond.get('shop_campaigns'))
                else:
                    store_campaign = '\'{}\''.format(jsond.get('shop_campaigns'))
                shop_campaign_condition = " AND shop_campaigns in ({0})".format(store_campaign)
            # filter home delivery
            if jsond.get('home_delivery'):
                home_delivery = " AND home_delivery_flag = '{}' ".format(jsond['home_delivery'])
            store_active_condition = " AND store_active = 'Y' "

            # Get category_id for selected brand_code
            adoptme = jsond.get('adoptme', '')
            if adoptme == 'Y':
                jsond['storelocator_flag'] = ['A', 'C']
            if 'brand_code' in jsond:
                brands = self.brand_codes()
                jsond['category_id'] = []
                if 'show_brand' in jsond and jsond['show_brand'] == 'Y':
                    pet_type = 'CAT' if jsond['brand_code'].find('CAT') != -1 else 'DOG'
                    self.acquire()
                    query = self.sql_file['store_brand_mapping_query']
                    self.cursor.execute(query, p_mapping=jsond['brand_code'],
                                        p_animal=pet_type)
                    mapping = Code_util.iterate_data(self.cursor)
                    self.release()
                    for i in range(len(brands)):
                        for row in mapping:
                            if row['brand'] == brands[i]['brand_code']:
                                jsond['category_id'].append(
                                    int(brands[i]['category_id']))
                                break
                else:
                    for i in range(len(brands)):
                        if jsond['brand_code'] == brands[i]['brand_code']:
                            jsond['category_id'].append(
                                int(brands[i]['category_id']))
                            break
            self.acquire()
            if len(jsond['category_id']) > 0:
                ids = jsond['category_id']
                id_string = ','.join([str(ids[i])
                                      for i in range(len(ids))])
                brand_condition = " s.shop_id = b.shop_id"
                brand_condition += " AND b.category_id in ("
                brand_condition += id_string + ')'

            # Key and url for geo coder request
            end_point = self.sql_file['geocode_url']
            if 'brand_code' in jsond:
                if 'centre' not in jsond:
                    if jsond['address']:
                        address = jsond['address']
                    if jsond['zip_code']:
                        if address:
                            address += ','
                        address += jsond['zip_code']
                    if jsond['city']:
                        if address:
                            address += ','
                        address += jsond['city']
                    url = end_point + '&address=' + address
                    url += '&components=country:' + jsond['country_code']
                    url += "&key=" + self.api_key

                    # Get latitude & longitude for user entered address
                    results = urllib.request.urlopen(url.encode('utf-8')).read()
                    results = results.replace('\n', '')
                    results = json.loads(results)

                    if results['status'] == 'OK':
                        geometry = results['results'][0]['geometry']
                        location = geometry['location']
                        latitude = location['lat']
                        longitude = location['lng']
                else:
                    latitude = jsond['address']['lat']
                    longitude = jsond['address']['lng']

                if latitude and longitude:
                    query = self.sql_file['website_store_finder']

                    if len(jsond['category_id']) > 0:
                        query += ', qpex_store_brands b'
                        query += ' WHERE' + brand_condition
                        query += " and verified_by_google = 'Y'"
                    else:
                        query += " WHERE verified_by_google = 'Y'"
                    query += self.sql_file['stores_date_condition']
                    query += shop_campaign_condition
                    query += home_delivery
                    query += store_active_condition
                    if 'centre' in jsond:
                        query += " AND country_code = '{country}'"
                        query = query.format(country=jsond['country_code'])
                        if jsond.get('storelocator_flag', []):
                            query += self.sql_file['store_finder_flag_condition']
                            query = query.format(flag=','.join("'" + str(s) + "'"
                                                               for s in jsond['storelocator_flag']))
                        query += self.sql_file['stores_centre_where_condition']
                    query = 'select * from (' + query
                    if 'centre' in jsond:
                        query += ')'
                        query = query.format(lat=jsond['centre']['lat'],
                                             lng=jsond['centre']['lng'])
                    else:
                        query += ') where distance < :p_radius'
                    query += ' ORDER BY distance'
                    if 'records' in jsond:
                        query = 'select * from (' + query
                        query += ') where rownum <= :p_records'
                        self.cursor.execute(query, p_latitude=latitude,
                                            p_longitude=longitude,
                                            p_radius=jsond['radius'],
                                            p_records=jsond['records'])
                    else:
                        self.cursor.execute(query, p_latitude=latitude,
                                            p_longitude=longitude,
                                            p_radius=jsond['radius'])
            if 'brand_code' not in jsond or not latitude or not longitude:
                query = self.sql_file['store_finder']
                query_params = {'p_country': jsond['country_code'],
                                'p_shop_name': jsond['shop_name'],
                                'p_verified_by_google': jsond['verified_by_google']
                                }
                if jsond['address']:
                    address_array = jsond['address'].lower().split(' ')
                    address = '%'.join(address_array)
                    address = "%" + address + "%"
                if jsond['city']:
                    city_array = jsond['city'].lower().split(' ')
                    city = '%'.join(city_array)
                    city = "%" + city + "%"

                if 'verified_by_google' not in jsond:
                    jsond['verified_by_google'] = 'Y'
                if 'shop_name' not in jsond:
                    jsond['shop_name'] = ''

                if len(jsond['category_id']) > 0:
                    query += ', qpex_store_brands b'
                query += self.sql_file['store_finder_country_condition']
                if address or city or jsond['zip_code']:
                    query += self.sql_file['store_finder_city_condition']
                    query_params['p_city'] = city
                    query_params['p_zip_code'] = jsond['zip_code']
                    query_params['p_address'] = address
                query += self.sql_file['store_finder_shop_condition']
                if jsond.get('storelocator_flag', []):
                    query += self.sql_file['store_finder_flag_condition']
                    query = query.format(flag=','.join("'" + str(s) + "'"
                                                       for s in jsond['storelocator_flag']))
                # query += self.sql_file['store_finder_conidtions']
                query += shop_campaign_condition
                query += home_delivery
                query += store_active_condition
                if len(jsond['category_id']) > 0:
                    query += ' AND' + brand_condition
                query += 'ORDER BY shop_id'
                self.cursor.execute(query, query_params)
            stores = Code_util.iterate_data(self.cursor)
            if 'brand_code' in jsond and latitude == '' and longitude == '':
                temp_stores = deepcopy(stores)
                stores = []
                for i in range(len(temp_stores)):
                    store = {}
                    store['province'] = temp_stores[i]['province']
                    store['city'] = temp_stores[i]['city']
                    store['zip'] = temp_stores[i]['zip_code']
                    store['distance'] = 0
                    store['company'] = temp_stores[i]['shop_name']
                    store['longitude'] = temp_stores[i]['lng']
                    store['nation'] = temp_stores[i]['country_code']
                    store['phone'] = temp_stores[i]['phone']
                    store['shop_id'] = temp_stores[i]['shop_id']
                    store['address'] = temp_stores[i]['address']
                    store['latitude'] = temp_stores[i]['lat']
                    store['email'] = temp_stores[i]['email']
                    stores.append(store)
            if 'brand_code' in jsond:
                return_obj = {'stores': stores, 'totalFound': len(stores)}
            else:
                return_obj = stores
        finally:
            self.release()
        return return_obj

    def delete(self, shop_ids):
        try:
            self.acquire()
            query = self.sql_file['store_locator_delete']
            shop_ids_string = ','.join([str(shop_ids[i])
                                        for i in range(len(shop_ids))])
            query = query % (shop_ids_string)
            self.cursor.execute(query)
            query = self.sql_file['delete_category_ids']
            query = query % (shop_ids_string)
            self.cursor.execute(query)
        finally:
            self.connection.commit()
            self.release()
        return 'success'

    # get all data in qpex_store_locator table
    def get_data(self):
        try:
            self.acquire()
            query = self.sql_file['store_locator_data']
            self.cursor.execute(query)
            result = self.enumerate_data()
        finally:
            self.release()
        return result

    # enumerate data returned from query
    def enumerate_data(self):
        data = []
        field_names = [a[0].lower() for a in self.cursor.description]
        for row in self.cursor:
            obj = {}
            for index, field in enumerate(field_names):
                obj[field] = row[index]
            data.append(obj)
        return data

    # get brand_codes
    def brand_codes(self):
        try:
            self.acquire()
            query = self.sql_file['store_locator_brands']
            self.cursor.execute(query)
            brand_codes = self.enumerate_data()
        finally:
            self.release()
        return brand_codes

    def get_stores(self, jsond):
        try:
            self.acquire()
            query = self.sql_file['get_stores']
            shops = []
            for shop in jsond:
                shop = shop.replace("'", "''")
                shops.append(shop)
            query = query % (','.join(["'" + s + "'" for s in shops]))
            self.cursor.execute(query)
            stores = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        return stores

    def check_db_duplicates(self, jsond, donation_desk, is_uploading):
        all_stores = []
        delete_stores = []
        self.acquire()
        shops = []
        query = self.sql_file['shop_category_ids']
        for i in range(len(jsond)):
            shops.append(jsond[i]['shop_name'].replace("'", "''"))
        shop_names = ','.join(["'" + shops[s].lower() + "'"
                               for s in range(len(shops))])
        query = query % (shop_names, shop_names)
        self.cursor.execute(query)
        stores = Code_util.iterate_data(self.cursor)
        for i in range(len(jsond)):
            line_address = self.decode_value(
                jsond[i]['address'], True)
            line_shop_name = self.decode_value(
                jsond[i]['shop_name'], True)
            if jsond[i]['zip_code']:
                line_zip = self.decode_value(
                    str(jsond[i]['zip_code']), True)
            else:
                line_zip = ''
            for j in range(len(stores)):

                # check store in db comparing with shop name and address
                store_address = self.decode_value(
                    stores[j]['address'], True)
                store_shop_name = self.decode_value(
                    stores[j]['shop_name'], True)
                if stores[j]['zip_code']:
                    store_zip = self.decode_value(
                        str(stores[j]['zip_code']), True)
                else:
                    store_zip = ''
                if (line_shop_name == store_shop_name is not None) and (
                        line_address == store_address is not None) and (
                        line_zip == store_zip is not None):

                    """ Append duplicate store category ids to
                    currently updating store"""
                    line_category_ids = deepcopy(
                        jsond[i]['category_id'])
                    store_categoy_ids = []
                    temp_category_id = []
                    if stores[j]['category_id']:
                        store_categoy_ids = stores[j][
                            'category_id'].split(',')
                        # Remove duplicate category ids
                        for k in range(len(store_categoy_ids)):
                            if int(store_categoy_ids[k]
                                   ) not in temp_category_id:
                                temp_category_id.append(
                                    int(store_categoy_ids[k]))
                    store_categoy_ids = temp_category_id
                    for k in range(len(store_categoy_ids)):
                        if int(store_categoy_ids[k]
                               ) not in line_category_ids:
                            if ('delete_brands' not in jsond[i]) or (
                                'delete_brands' in jsond[i] and len(
                                    jsond[i]['delete_brands']) == 0) or (
                                    'delete_brands' in jsond[i] and len(
                                    jsond[i]['delete_brands']) > 0 and int(
                                    store_categoy_ids[k]) not in jsond[i][
                                        'delete_brands']):
                                line_category_ids.append(
                                    int(store_categoy_ids[k]))
                    jsond[i]['category_id'] = deepcopy(line_category_ids)

                    """ if store uploaded already exists and user_verified_flag
                    is already set insert the old lat & lng values.
                    Allow to update lat & lng if user is editing manually
                    even if user_verified_flag is set"""
                    if is_uploading and (
                            stores[j]['user_verified_flag'] == 'Y'):
                        jsond[i]['lat'] = stores[j]['lat']
                        jsond[i]['lng'] = stores[j]['lng']
                        jsond[i]['user_verified_flag'] = 'Y'
                    if stores[j]['verified_by_google'] == 'Y':
                        jsond[i]['verified_by_google'] = stores[
                            j]['verified_by_google']
                        jsond[i][
                            'country_code'] = stores[j]['country_code']
                        jsond[i][
                            'country_name'] = stores[j]['country_name']

                    # If updating existing store
                    if 'shop_id' in jsond[i]:

                        # Stores with diff shop_ids having same address
                        if jsond[i]['shop_id'] != stores[j]['shop_id']:
                            """ Keep currently updating store
                            and delete the other store"""
                            delete_stores.append(stores[j]['shop_id'])
                            break
                    else:
                        jsond[i]['shop_id'] = stores[j]['shop_id']
            all_stores.append(jsond[i])
        self.release()
        if is_uploading:
            result = self.get_urls(
                all_stores, delete_stores, donation_desk)
        else:
            result = self.insert(all_stores, delete_stores, is_uploading)
        return result

    def insert(self, jsond, delete_stores, is_uploading):
        update_stores = []
        insert_stores = []
        save_status = {'status': 'success'}
        update_status = {'status': 'success'}
        status = 'success'
        result = {}
        try:
            self.acquire()
            for i in range(len(jsond)):
                if 'shop_id' not in jsond[i]:
                    jsond[i]['shop_id'] = self.get_sequence()
                    insert_stores.append(jsond[i])
                else:
                    update_stores.append(jsond[i])
            temp_stores = deepcopy(jsond)
            update_customer_arr = [{'store_locator': store['storelocator_flag'],
                                    'store_campaign': store['shop_campaigns'],
                                    'cust_account_id': store['customer_id'],
                                    'site_id': store['site_id'],
                                    'home_delivery': store['home_delivery_flag']}
                                   for store in jsond if store.get('site_id')]
            if len(insert_stores) > 0:
                save_status = self.save(insert_stores)
            if len(update_stores) > 0:
                update_status = self.update(update_stores)
            if len(delete_stores) > 0:
                self.delete(delete_stores)
            if len(update_customer_arr) > 0:
                self.update_customer_list_details(update_customer_arr)
            status = 'success'
            if update_status['status'] == 'error' or (
                    save_status['status'] == 'error'):
                status = 'error'
        finally:
            if self.is_acquired:
                self.release()
        result = {}
        if is_uploading and status == 'success':
            result['status'] = 0
            result['data'] = temp_stores
        elif status == 'error':
            result['status'] = 1
            result['msg'] = 'Failed to upload'
        elif not is_uploading and len(insert_stores) > 0:
            result['status'] = 0
            result['msg'] = 'Store added successfully'
            result['shop_id'] = save_status['shop_id']
        else:
            result['status'] = 0
            result['msg'] = 'Store updated successfully'
        return result

    def get_links(self, url):
        try:
            if url:
                return urllib.request.urlopen(url).read()
        except Exception:
            return ''

    def get_urls(self, file_data, delete_stores, donation_desk):
        formatted_address = ''
        endPoint = self.sql_file['geocode_url']
        urls = []
        geocode_url = ''
        for i in range(len(file_data)):
            geocode_url = ''
            formatted_address = ''

            if file_data[i]['address']:
                formatted_address = file_data[i]['address']
            if file_data[i]['city']:
                formatted_address += ',' + file_data[i]['city']

            if donation_desk is None:
                if file_data[i]['province']:
                    formatted_address += ',' + file_data[i]['province']
            if file_data[i]['country']:
                formatted_address += ',' + file_data[i]['country']
            if file_data[i]['zip_code']:
                formatted_address += ',' + file_data[i]['zip_code']

            if formatted_address:
                geocode_url = endPoint
                if formatted_address:
                    geocode_url += '&address='
                    geocode_url += urllib.parse.quote(formatted_address)

                geocode_url += "&key=" + self.api_key
            urls.append(geocode_url)

        if donation_desk is not None:
            stores = self.find_cities(urls)
        else:
            stores = self.get_lat_lng(file_data, urls, delete_stores)
        return stores

    def get_location(self, url, i):
        result = urllib.request.urlopen(url).read()
        result = ujson.loads(result)
        return result

    def get_lat_lng(self, file_data, urls, delete_stores):
        # address types in obtained result
        address_fields = ['locality', 'administrative_level_2',
                          'country', 'postal_code']

        # column names to be associated with respective address types
        address_columns = ['city', 'province', 'country', 'zip_code']
        stores = []
        for i in range(len(file_data)):
            results = ''

            if 'lat' in file_data[i] and 'lng' in file_data[i]:
                results = -1
            else:
                results = self.get_location(urls[i], i)

            if results == -1 or (
                    results and results['status'] == 'OK'):
                if results != -1:
                    file_data[i]['country_name'] = ''
                    file_data[i]['country_code'] = ''
                    geocode_result = results[
                        'results'][0]
                    file_data[i]['lat'] = geocode_result[
                        'geometry']['location']['lat']
                    file_data[i]['lng'] = geocode_result[
                        'geometry']['location']['lng']
                    if file_data[i]['address'] is None or (
                            file_data[i]['address'] == ''):
                        file_data[i]['address'] = geocode_result[
                            'formatted_address']
                    file_data[i]['verified_by_google'] = 'Y'
                    address_components = geocode_result[
                        'address_components']
                    for j in range(len(address_components)):
                        for k in range(len(address_fields)):
                            component_value = file_data[i][
                                address_columns[k]]
                            if component_value:
                                component_value = component_value.replace(
                                    '  ', ' ')
                            if address_fields[k] in address_components[
                                    j]['types']:
                                if address_fields[k] == 'country':
                                    file_data[i]['country_code'
                                                 ] = address_components[
                                        j]['short_name']
                                    file_data[i]['country_name'
                                                 ] = address_components[
                                        j]['long_name']
                                elif (
                                        (component_value is None) or (
                                            component_value == '')):
                                    value = address_components[j][
                                        'long_name']
                                    file_data[i][
                                        address_columns[k]] = value
            else:
                file_data[i]['lat'] = None
                file_data[i]['lng'] = None
                file_data[i]['country_name'] = ''
                file_data[i]['country_code'] = ''
                if file_data[i]['country']:
                    for code, value in self.countries_list.items():
                        if value.lower() == file_data[i][
                                'country'].lower():
                            file_data[i]['country_name'] = value
                            file_data[i]['country_code'] = code
                        elif code.lower() == file_data[i][
                                'country'].lower():
                            file_data[i]['country_name'] = value
                            file_data[i]['country_code'] = code
                    if not file_data[i]['country_code']:
                        if len(file_data[i]['country']) == 2:
                            file_data[i][
                                'country_code'] = file_data[i]['country']
                        file_data[i][
                            'country_name'] = file_data[i]['country']
                file_data[i]['verified_by_google'] = 'N'
        # to check duplicates in uploaded
            stores.append(self.format_line(file_data[i]))
        result = self.insert(stores, delete_stores, True)
        return result

    def check_duplicate(self, file_data, jsond, donation_desk=None):
        stores = []
        category_id = jsond['category_id']
        user_id = jsond['user_id']
        storelocator_flag = jsond['storelocator_flag']
        shop_campaigns = jsond['shop_campaigns']
        home_delivery = jsond['home_delivery']
        store_active = jsond.get('store_active', 'Y')
        for i in range(len(file_data)):
            if donation_desk is None:
                file_data[i]['storelocator_flag'] = storelocator_flag
                file_data[i]['shop_campaigns'] = shop_campaigns
                file_data[i]['home_delivery_flag'] = home_delivery
                file_data[i]['store_active'] = store_active
                file_data[i]['category_id'] = category_id
                file_data[i]['last_updated_by'] = user_id
                file_data[i]['created_by'] = user_id
                file_data[i]['user_verified_flag'] = 'N'
                file_data[i]['address'] = self.decode_value(
                    file_data[i]['address'], False)
                file_data[i]['city'] = self.decode_value(
                    file_data[i]['city'], False)
                file_data[i]['zip_code'] = self.decode_value(
                    file_data[i]['zip_code'], False)
                file_data[i]['province'] = self.decode_value(
                    file_data[i]['province'], False)
                file_data[i]['country'] = self.decode_value(
                    file_data[i]['country'], False)
            duplicate = -1
            line_shop_name = self.decode_value(
                file_data[i]['shop_name'], True)
            line_address = self.decode_value(
                file_data[i]['address'], True)
            line_city = self.decode_value(
                file_data[i]['city'], True)
            if file_data[i]['zip_code']:
                line_zip = self.decode_value(
                    str(file_data[i]['zip_code']), True)
            else:
                line_zip = ''
            line_country = self.decode_value(
                file_data[i]['country'], True)
            category_id = file_data[i]['category_id']
            for j in range(len(stores)):

                store_shop_name = self.decode_value(
                    stores[j]['shop_name'], True)
                store_address = self.decode_value(
                    stores[j]['address'], True)
                store_city = self.decode_value(
                    stores[j]['city'], True)
                if stores[j]['zip_code']:
                    store_zip = self.decode_value(
                        str(stores[j]['zip_code']), True)
                else:
                    store_zip = ''
                store_country = self.decode_value(
                    stores[j]['country'], True)

                if file_data[i]['shop_name'] and file_data[i][
                    'address'] and (
                        line_shop_name == store_shop_name) and (
                        line_address == store_address) and (
                        line_city == store_city) and (
                        line_zip == store_zip) and (
                        line_country == store_country
                ):
                    duplicate = j
                    break
            if duplicate == -1:
                # insert if line is not duplicate
                stores.append(file_data[i])
            else:
                # combine brand codes & category_ids of duplicate lines
                store_categoy_id = stores[duplicate]['category_id']
                # append brand codes of current line to duplicate line
                for k in range(len(category_id)):
                    if category_id[k] not in store_categoy_id:
                        store_categoy_id.append(category_id[k])
                stores[duplicate]['category_id'] = store_categoy_id
                stores[duplicate]['storelocator_flag'] = storelocator_flag
                stores[duplicate]['shop_campaigns'] = shop_campaigns
                stores[duplicate]['home_delivery_flag'] = home_delivery
                stores[duplicate]['store_active'] = store_active
        result = self.check_db_duplicates(
            stores, donation_desk, True)
        return result

    # format line to insert
    def format_line(self, jsond):
        line = {}
        line['shop_name'] = jsond['shop_name']
        line['created_by'] = jsond['created_by']
        line['last_updated_by'] = jsond['last_updated_by']
        line['user_verified_flag'] = jsond['user_verified_flag']
        line['start_date'] = jsond.get('start_date', None)
        line['end_date'] = jsond.get('end_date', None)
        if 'shop_id' in jsond:
            line['shop_id'] = jsond['shop_id']
        if type(jsond['address']) == str:
            line['address'] = jsond['address'].decode('utf-8')
        else:
            line['address'] = jsond['address']
        if jsond['city']:
            line['city'] = jsond['city']
        else:
            line['city'] = None
        if jsond['province']:
            line['province'] = jsond['province']
        else:
            line['province'] = None
        if jsond['zip_code']:
            line['zip_code'] = jsond['zip_code']
        else:
            line['zip_code'] = None
        if jsond['country_code']:
            line['country_code'] = jsond['country_code']
        else:
            line['country_code'] = None
        if jsond['country_name']:
            line['country_name'] = jsond['country_name']
        else:
            line['country_name'] = None
        if 'email' in jsond and jsond['email']:
            line['email'] = jsond['email']
        else:
            line['email'] = None
        if 'vat' in jsond and jsond['vat']:
            line['vat'] = jsond['vat']
        else:
            line['vat'] = None
        if 'fax' in jsond and jsond['fax']:
            line['fax'] = jsond['fax']
        else:
            line['fax'] = None
        if 'phone' in jsond and jsond['phone']:
            line['phone'] = jsond['phone']
        else:
            line['phone'] = None
        if jsond['lat']:
            line['lat'] = jsond['lat']
        else:
            line['lat'] = None
        if jsond['lng']:
            line['lng'] = jsond['lng']
        else:
            line['lng'] = None
        if jsond['category_id']:
            line['category_id'] = jsond['category_id']
        else:
            line['category_id'] = []
        line['verified_by_google'] = jsond['verified_by_google']
        line['storelocator_flag'] = jsond['storelocator_flag']
        line['home_delivery_flag'] = jsond['home_delivery_flag']
        line['store_active'] = jsond['store_active']
        line['shop_campaigns'] = jsond['shop_campaigns']
        return line

    def decode_value(self, value, to_lower):
        if type(value) == str:
            value = value.encode('utf-8')
        if value:
            if to_lower:
                value = value.replace(" ", "")
                value = value.lower()
            else:
                value = str(value).strip()
        return value

    def search_by_shop_name(self, jsond):
        words_in_shop = []
        try:
            self.acquire()
            query = self.sql_file['search_by_shop_name']
            words_in_shop = jsond['shop_name'].split(' ')
            for i in range(len(words_in_shop)):
                if i != 0:
                    query = query + ' and ('
                if i == 0:
                    query = query + '('
                query = query + 'lower(shop_name) like ' + "'" + '% '
                query = query + words_in_shop[i].lower().replace(
                    "'", "''")
                query = query + "' or lower(shop_name) like '"
                query = query + words_in_shop[i].lower().replace("'", "''")
                query = query + " %' or lower(shop_name) like '% "
                query = query + words_in_shop[i].lower().replace("'", "''")
                query = query + " %' or lower(shop_name) like '"
                query = query + words_in_shop[i].lower().replace("'", "''")
                query = query + "'"
                query = query + ')'
            query = query + ' order by shop_id'
            self.cursor.execute(query, p_address=jsond['address'])
            stores = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        return stores

    def delete_brands(self, jsond):
        try:
            category_ids = jsond['category_ids']
            query = self.sql_file['delete_brands']
            query = query % (','.join([str(category_ids[i])
                                       for i in range(len(category_ids))]))
            self.cursor.execute(query, p_shop_id=jsond['shop_id'])
        finally:
            self.connection.commit()
        return 'success'

    # Existing shop names from store locator table
    def shops_lov(self):
        try:
            self.acquire()
            query = self.sql_file['shop_name_lov']
            self.cursor.execute(query)
            shops = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        return shops

    # Existing cities list from store locator table
    def city_lov(self):
        try:
            self.acquire()
            query = self.sql_file['city_lov']
            self.cursor.execute(query)
            cities = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        return cities

    # Existing countries list from store locator table
    def country_lov(self):
        try:
            self.acquire()
            query = self.sql_file['country_lov']
            self.cursor.execute(query)
            countries = Code_util.iterate_data(self.cursor)
        finally:
            self.release()
        return countries

    def find_cities(self, urls):
        cities = []
        for x in range(len(urls)):
            address_result = self.get_location(urls[x], x)
            # address_result = ujson.loads(address_result_list[x])
            if address_result["status"] == "OK":
                for y in range(len(address_result["results"])):
                    address_components = address_result["results"][y][
                        "address_components"]
                    for z in range(len(address_components)):
                        if "locality" in address_components[z][
                            "types"] or "administrative_area_level_3" in \
                                address_components[z]["types"]:
                            if address_components[z][
                                "long_name"].upper() \
                                    not in cities:
                                cities.append(address_components[z][
                                    "long_name"].upper())
        stores = cities
        return stores

    def get_stores_by_country(self, country):
        query = self.sql_file['stores_by_country_query']
        self.acquire()
        self.cursor.execute(query, p_country=country)
        stores = Code_util.iterate_data(self.cursor)
        return stores

    def get_all_stores(self, req):
        result = self.get_stores_by_country(req['country_code'])

        # If adoptme flag is in request then filter only stores with storelocator_flag A or C
        data = StoreLocator.check_adoptme_and_filter_stores(result, req.get('adoptme'))

        # If lan and lng are available in the request then calculate distance
        # between address in the request and store address
        data = StoreLocator.check_address_and_add_distance(data, req.get('address'))

        response = {
            'totalFound': len(data),
            'stores': data
        }
        return response

    @staticmethod
    def check_adoptme_and_filter_stores(stores, adoptme):
        if adoptme == 'Y':
            data = []
            for row in stores:
                if row.get('storelocator_flag', '') in ['A', 'C']:
                    data.append(row)
        else:
            data = stores
        return data

    @staticmethod
    def check_address_and_add_distance(stores, address):
        data = stores
        if address and address.get('lat') and address.get('lng'):
            for index, _ in enumerate(data):
                distance = StoreLocator.calculate_distance(
                    address.get('lat'), address.get('lng'),
                    data[index]['latitude'], data[index]['longitude'])
                if distance:
                    data[index]['distance'] = round(distance, 2)
            data = sorted(data, key=lambda store: store.get('distance'))
        return data

    @staticmethod
    def calculate_distance(lat1, lng1, lat2, lng2):
        dist = 0
        # Check if lat and lng are available as float
        if isinstance(lat1, float) and isinstance(lng1, float) and isinstance(
                lat2, float) and isinstance(lng2, float):
            lat1 = radians(lat1)
            lng1 = radians(lng1)
            lat2 = radians(lat2)
            lng2 = radians(lng2)

            # 6371.01 is radius of earth
            # Reference: https://www.movable-type.co.uk/scripts/latlong.html
            dist = 6371.01 * acos(sin(lat1) * sin(lat2) + cos(lat1) * cos(lat2) * cos(lng1 - lng2))
        return dist

    def update_customer_list_details(self, customer_arr):
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_customer_list_details']
            for customer in customer_arr:
                conn.execute(query, p_cust_account_id=customer['cust_account_id'],
                             p_site_id=customer['site_id'])
                result = conn.get_single_result()
                if result:
                    customer['customer_number'] = result['customer_number']
                    customer['group_name'] = result['group_name']
                    customer['primary_salesrep_id'] = result['primary_salesrep_id']
                    customer['org_id'] = result['org_id']
        reports_obj = Report()
        response = reports_obj.update_store_locator_campaign(customer_arr)
        return response

    @staticmethod
    def get_store_update_data(data):
        stores = {'campaigns': [], 'brands': []}
        for key in list(data[0].keys()):
            if key not in ['campaigns', 'brands']:
                stores.update({key: [row[key] or '' for row in data if row.get('deleted') != 'Y']})
        for row in data:
            if row.get('deleted') != 'Y':
                stores['campaigns'].extend(row['campaigns'])
                stores['campaigns'].append('-')
                stores['brands'].extend(row['brands'])
                stores['brands'].append(-1)
        return stores

    def update_stores(self, req):
        result = {}
        stores = StoreLocator.get_store_update_data(req.get('stores', []))
        if stores.get('shop_id'):
            with OracleConnectionManager() as conn:
                conn.execute(self.sql_file['store_flag_update_pkg_call'],
                             output_key='x_status_code',
                             p_shop_id=stores['shop_id'],
                             p_store_active=stores['store_active'],
                             p_storelocator_flag=stores['storelocator_flag'],
                             p_partner_flag=stores['partner'],
                             p_home_delivery_flag=stores['home_delivery_flag'],
                             p_verified_by_google=stores['verified_by_google'],
                             p_verified_by_user=stores['user_verified_flag'],
                             p_store_type=stores['store_type'],
                             p_brands=stores['brands'],
                             p_campaigns=stores['campaigns'],
                             p_user_id=req.get('user_id'))
                status = conn.get_output_param(raise_exception=False)
                if status != 'SUCCESS':
                    result['status'] = 1
                    result['msg'] = 'Failed to update stores - %s' % str(status)
                    return result
        return self.delete_stores(req)

    def delete_stores(self, req):
        result = {'status': 0, 'msg': 'Stores updated successfully'}
        stores = [store['shop_id'] for store in req.get('stores') if store.get('deleted') == 'Y']
        if stores:
            with OracleConnectionManager() as conn:
                conn.execute(self.sql_file['delete_stores_pkg_call'],
                             output_key='x_status_code',
                             p_stores=stores)
                status = conn.get_output_param(raise_exception=False)
                if status != 'SUCCESS':
                    result['status'] = 1
                    result['msg'] = 'Stores updated successfully but failed '\
                        'to delete stores - %s' % str(status)
        return result

    @staticmethod
    def build_index_map(data, key):
        return dict([(str(row[key]), index) for index, row in enumerate(data)])

    @staticmethod
    def build_in_clause(data):
        return '(' + ','.join(["('x', '%s')" % value for value in data]) + ')'

    def get_store_info(self, store_ids, info_type):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['store_{}_query'.format(info_type)]
            query += StoreLocator.build_in_clause(store_ids)
            conn.cursor.execute(query)
            result = conn.get_result()
        return result

    def get_stores_condition(self, condition_type, data):
        query = self.sql_file['store_{}_condition'.format(condition_type)]
        query %= StoreLocator.build_in_clause(data)
        return query

    def store_search(self, req):
        stores = []
        store_flags = req.get('storelocator_flag') or ['Y', 'C', 'A']
        with OracleConnectionManager() as conn:
            query = self.sql_file['store_search_query']
            query %= "','".join(store_flags)
            if req.get('campaigns'):
                query += self.get_stores_condition('campaigns', req['campaigns'])
            if req.get('brands'):
                query += self.get_stores_condition('brands', req['brands'])
            query += self.sql_file['oracle_store_condition'][req.get('oracle_store', 'A')]

            conn.execute(query, p_country_code=req.get('country_code'),
                         p_city=req.get('city'),
                         p_zip_code=req.get('zip_code'),
                         p_shop_name=req.get('shop_name'),
                         p_verified_by_google=req.get('verified_by_google', 'Y'))

            stores = conn.get_result()
            store_ids = [str(store['shop_id']) for store in stores]

            if not store_ids:
                return stores

            store_id_map = StoreLocator.build_index_map(stores, 'shop_id')
            for store in stores:
                store['brands'] = []
                store['campaigns'] = []

            brands = self.get_store_info(store_ids, 'brands')
            for brand in brands:
                index = store_id_map.get(str(brand['shop_id']))
                stores[index]['brands'].append(brand)

            campaigns = self.get_store_info(store_ids, 'campaigns')
            for campaign in campaigns:
                index = store_id_map.get(str(campaign['shop_id']))
                stores[index]['campaigns'].append(campaign)

        return stores

    def get_store_products(self):
        products = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['store_products_query']
            conn.execute(query)
            products = conn.get_result()
        return products

    def get_stores_data(self, country):
        stores = []
        for oracle_store in ['Y', 'N']:
            req = {
                'country_code': str(country).upper(),
                'oracle_store': oracle_store,
                'storelocator_flag': ['Y', 'C', 'A']
            }
            stores.extend(self.store_search(req))

        store_id_map = StoreLocator.build_index_map(stores, 'shop_id')
        for store in stores:
            store['products'] = []

        result = self.get_store_products()
        cms = CMS()
        req = {
            'language': country,
            'no_cache': True
        }
        data = cms.get_recipes(req, True)
        products_map = StoreLocator.build_index_map(data, 'item_code')
        for row in result:
            store_index = store_id_map.get(str(row['shop_id']))
            item_index = products_map.get(row['ordered_item'])
            if store_index is not None and item_index is not None:
                product = data[item_index]
                advantages = []
                weights = []
                for advantage in product.get('advantages', []):
                    advantages.append(advantage['advantage_header'])
                for weight in product.get('weight', []):
                    weights.append('%s %s' % (weight['weight'],
                                              weight['weight_uom']))
                stores[store_index]['store_type'] = row['store_type']
                stores[store_index]['products'].append({
                    'animal': product.get('animal').title(),
                    'item_code': product['item_code'],
                    'recipe': product.get('recipe'),
                    'food_type': product.get('food_type').title(),
                    'brand': product.get('brand_name_new'),
                    'card_image': product.get('card_image_main'),
                    'segment': product.get('segment_range_new'),
                    'family_product': product.get('family_product'),
                    'advantages': advantages,
                    'weights': weights
                })
        return stores

    def update_store_address(self, req):
        result = {'status': 0, 'msg': 'Store updated successfully'}
        with OracleConnectionManager() as conn:
            conn.execute(self.sql_file['update_store_pkg_call'],
                         output_key='x_status_code',
                         p_shop_id=req.get('shop_id', -1),
                         p_shop_name=req.get('shop_name'),
                         p_address=req.get('address'),
                         p_city=req.get('city'),
                         p_country=req.get('country') or req.get('country_name'),
                         p_country_code=req.get('country_code'),
                         p_province=req.get('province'),
                         p_zip_code=req.get('zip_code'),
                         p_lat=req.get('latitude') or req.get('lat'),
                         p_lng=req.get('longitude') or req.get('lng'),
                         p_email=req.get('email'),
                         p_fax=req.get('fax'),
                         p_phone=req.get('phone'),
                         p_vat=req.get('vat'),
                         p_verified_by_google=req.get('verified_by_google'),
                         p_verified_by_user=req.get('user_verified_flag'),
                         p_user_id=req.get('user_id'))
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result['status'] = 1
                result['msg'] = 'Failed to update store - %s' % str(status)
        return result
