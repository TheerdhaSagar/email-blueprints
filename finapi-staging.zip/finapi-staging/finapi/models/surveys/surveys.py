

from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils import auth_util
import time
import cx_Oracle
from mailjet_rest import Client
import os


class Surveys:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_surveys(jsond):
        logger.addinfo('@ models - analytics - get_surveys(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['survey_query_details']
            cur.execute(query, p_user_id=jsond['user_id'],
                        p_creation_date=jsond['creation_date'])
        except Exception as error:
            logger.findaylog("""@ 30 EXCEPTION - models - surveys -
                 get_surveys """ + str(error.message))
            raise error
        else:
            survey_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = Surveys()
                for index, field in enumerate(field_names):
                    if field == 'survey_image' and row[index] is not None:
                        setattr(result, field, row[index].read())
                    else:
                        setattr(result, field, row[index])
                survey_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - surveys - get_surveys(-)')
        return survey_list

    @staticmethod
    def get_question_details(id):
        logger.addinfo('@ models - analytics - get_question_details(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['question_details_query']
            cur.execute(query, p_question_id=id)
        except Exception as error:
            logger.findaylog("""@ 62 EXCEPTION - models - surveys -
                 get_question_details """ + str(error.message))
            raise error
        else:
            survey_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                survey_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - surveys - get_question_details(-)')
        return survey_list

    @staticmethod
    def get_question_types():
        logger.addinfo('@ models - analytics - get_question_types(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['question_types_query']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 92 EXCEPTION - models - surveys -
                 get_question_details """ + str(error.message))
            raise error
        else:
            survey_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                survey_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - surveys - get_question_types(-)')
        return survey_list

    @staticmethod
    def survey_result(survey_id):
        logger.addinfo('@ models - survey - survey_result(+)')
        connection = None
        cursor = None
        survey_details = []
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['surveys_query']
            cursor.execute(query, p_survey_id=survey_id)
            survey_details = Surveys.show_questions(survey_id)
        except Exception as error:
            logger.findaylog("""@ 123 EXCEPTION - models - surveys -
                 survey_result """ + str(error.message))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                header = Surveys()
                for index, field in enumerate(fieldnames):
                    if field == 'survey_image' and row[index] is not None:
                        setattr(header, field, row[index].read())
                    else:
                        setattr(header, field, row[index])
                setattr(header, "questions", survey_details)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - survey - survey_result(-)')
        return header

    @staticmethod
    def show_questions(header_id):
        logger.addinfo('@ models - surveys - show_questions(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['survey_questions']
            cursor.execute(query, p_survey_id=header_id)
            questions = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                choices = []
                question = Surveys()
                for index, fn in enumerate(fieldnames):
                    if fn.startswith('question_number'):
                        choices = Surveys.show_choices(row[index], header_id)
                        if len(choices) > 0:
                            setattr(question, 'choices', choices)
                            setattr(question, fn, row[index])
                        else:
                            setattr(question, fn, row[index])
                    else:
                        setattr(question, fn, row[index])
                questions.append(question)
        except Exception as error:
            logger.findaylog("""@ 169 EXCEPTION - models - surveys -
                 show_questions """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - show_questions(-)')
        return questions

    @staticmethod
    def survey_answers(survey_id):
        logger.addinfo('@ models - surveys - survey_answers(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['survey_answers']
            cursor.execute(query, p_survey_id=survey_id)
            survey_answer_details = []
        except Exception as error:
            logger.findaylog("""@ 191 EXCEPTION - models - surveys -
                 survey_answers """ + str(error.message))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                answer = Surveys()
                for index, fn in enumerate(fieldnames):
                    setattr(answer, fn, row[index])
                survey_answer_details.append(answer)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - survey_answers(-)')
        return survey_answer_details

    # generate HeaderId
    @staticmethod
    def head_id():
        logger.addinfo("@ models - surveys - head_id(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['survey_sequence']
            data = cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 221 EXCEPTION - models - surveys -
                 head_id """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - surveys - head_id(-)")
        return header_id

    @staticmethod
    def insert_survey(json, header_id):
        logger.addinfo('@ models - surveys - insert_survey(+)')
        result = 'success'
        tmp_file = ''
        flag = 0
        con = None
        cur = None
        con = db_util.get_connection()
        if 'questions' in json:
            questions = json['questions']
            del json['questions']
            result = Surveys.insert_questions(questions, header_id, con)
        if result == "success":
            try:
                return_data = {}
                sql_file = db_util.getSqlData()
                cur = con.cursor()
                if 'base64' in json:
                    tmp_file = json['base64']
                    del json['base64']
                row_data = []
                query = sql_file['survey_insert_query1']
                my_data = []
                for key, value in json.items():
                    my_data.append(value)
                    my_new_tuple = tuple(my_data)
                row_data.append(my_new_tuple)
                for key, value in json.items():
                    query += str(key)
                    query += ','
                query = query[:-1]
                query += sql_file["survey_insert_query2"]
                query += str(header_id) + ","
                sql_args = ""
                for idx, key in enumerate(json.items()):
                    sql_args += ":" + str(idx) + ","
                sql_args = sql_args[:-1]
                query += sql_args + ")"
                cur.executemany(query, row_data)
                cur.setinputsizes(p_filedata=cx_Oracle.BLOB)
                if tmp_file:
                    update_query = sql_file['survey_image_update']
                    cur.execute(update_query, p_filedata=tmp_file,
                                p_survey_id=header_id)
                return_data['req_id'] = header_id
                return_data['status'] = 0
                return_data['result'] = "success"
                return_data['msg'] = "Survey created suceesfully"
            except Exception as error:
                flag = 1
                logger.addinfo(time.ctime())
                logger.findaylog("""@ 281 EXCEPTION - models - surveys -
                        insert_survey """ + str(error.message))
                raise error
            finally:
                if flag == 0:
                    con.commit()
                cur.close()
                db_util.release_connection(con)
            logger.addinfo(time.ctime())
            logger.addinfo('@ models - surveys - insert_survey(-)')
            return return_data
        else:
            return_data = {}
            return_data['result'] = "fails"
            return_data['status'] = 1
            return_data['msg'] = "Error in creating Survey Questions"
            logger.addinfo(time.ctime())
            logger.addinfo('@ models - surveys - insert_survey(-)')
            return return_data

    @staticmethod
    def insert_questions(question_list, survey_id, connection):
        logger.addinfo('@ models - surveys - insert_questions(+)')
        logger.addinfo(time.ctime())
        cursor = None
        try:
            cursor = connection.cursor()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            for cn_line in question_list:
                if 'choices' in cn_line:
                    Surveys.insert_choices(cn_line['choices'],
                                           cn_line['question_number'],
                                           survey_id, connection)
                    del cn_line['choices']
                cn_line['survey_id'] = survey_id
                temp_line = cn_line
                values = ""
                values = tuple(str(val) for key, val in cn_line.items())
                row_list.append(values)
            if question_list:
                dict_val = temp_line
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    if key.startswith('image_choice'):
                        paramater_strng += ":"+str(indx_value)+','
                        cursor.setinputsizes(indx_value=cx_Oracle.BLOB)
                    else:
                        paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            cursor.prepare("""insert into
            qpex_survey_questions """ + fieldname_strng+"""
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
        except Exception as error:
            db_util.release_connection(connection)
            logger.addinfo(time.ctime())
            logger.findaylog("""@ 348 EXCEPTION - expenses - surveys -
                 insert_questions """ + str(error.message))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
        logger.addinfo(time.ctime())
        logger.addinfo('@ models - surveys - insert_questions(-)')
        return "success"

    @staticmethod
    def delete_question(s_id, qns):
        logger.addinfo("@ models - surveys - delete_question(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query_temp = sql_file['question_delete_query']
            query = query_temp % (',' . join([":" + str(i)
                                  for i in range(len(qns))]), s_id)
            cursor.execute(query, qns)
        except Exception as error:
            logger.findaylog("""@ 371 EXCEPTION - models - surveys -
                 delete_question """ + str(error.message))
            raise error
        finally:
            result = Surveys.delete_choices(s_id, qns, connection)
            cursor.close()
            if result == 'success':
                connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - surveys - delete_question(-)")
        final = {}
        final['status'] = 0
        final['msg'] = 'Question deleted successfully'
        return final

    @staticmethod
    def delete_survey(survey_id):
        logger.addinfo("@ models - surveys - delete_survey(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['survey_delete_query1']
            cursor.execute(query, p_survey_id=survey_id)
            query1 = sql_file['survey_delete_query2']
            cursor.execute(query1, p_survey_id=survey_id)
        except Exception as error:
            logger.findaylog("""@ 398 EXCEPTION - models - surveys -
                 delete_survey """ + str(error.message))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - surveys - delete_survey(-)")
        final = {}
        final['status'] = 0
        final['msg'] = 'Survey # ' + str(survey_id) + ' deleted successfully'
        return final

    @staticmethod
    def update_survey(jsond):
        logger.addinfo('@ models - surveys - update_survey(+)')
        con = None
        cur = None
        flag = 0
        con = db_util.get_connection()
        survey_id = jsond['survey_id']
        questions = jsond['questions']
        base64 = jsond['base64']
        del jsond['base64']
        del jsond['questions']
        new_lines = []
        update_lines = []
        for i in questions:
            if 'created_by' not in i:
                update_lines.append(i)
            else:
                new_lines.append(i)
        Surveys.question_update(update_lines, survey_id, con)
        Surveys.insert_questions(new_lines, survey_id, con)
        try:
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            sql_data = 'update qpex_survey_table set '
            for key, value in jsond.items():
                sql_data += str(key)+'='
                if isinstance(value, str):
                    sql_data += "'"
                if value is not None:
                    sql_data += str(value)
                if isinstance(value, str):
                    sql_data += "'"
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += "where survey_id =" + "'" + str(survey_id) + "'"
            cur.execute(sql_data)
            cur.setinputsizes(p_filedata=cx_Oracle.BLOB)
            update_query = sql_file['survey_image_update']
            cur.execute(update_query, p_filedata=base64,
                        p_survey_id=survey_id)
        except Exception as error:
            flag = 1
            logger.findaylog("""@ 427 EXCEPTION - models - surveys -
                 update_survey """ + str(error.message))
            raise error
        finally:
            if flag == 0:
                con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - surveys - update_survey(-)')
        return 'success'

    @staticmethod
    def question_update(val_list, survey_id, con):
        logger.addinfo('@ models - surveys - question_update(+)')
        cur = None
        question_id = ''
        try:
            cur = con.cursor()
            for line in val_list:
                choices = []
                new_choices = []
                edit_choices = []
                if 'choices' in line:
                    choices = line['choices']
                    del line['choices']
                if 'deleted_choices' in line:
                    del_choices = line['deleted_choices']
                    del line['deleted_choices']
                    if len(del_choices) > 0:
                        sql_file = db_util.getSqlData()
                        q_temp = sql_file['choices_delete_query']
                        query = q_temp % (',' . join([":" + str(i)
                                          for i in range(len(del_choices))]))
                        cur.execute(query, del_choices)
                sql_data = "update qpex_survey_questions set "
                for key, value in line.items():
                    if key == 'question_number':
                        question_id = str(value)
                    sql_data += str(key)+"="
                    if isinstance(value, str):
                        sql_data += "'"
                    if value is not None:
                        tmp = str(value)
                        if "'" in tmp:
                            t_value = tmp.replace("'", "''")
                            sql_data += t_value
                        else:
                            sql_data += tmp
                    if isinstance(value, str):
                        sql_data += "'"
                    sql_data += ","
                sql_data = sql_data[:-1]
                sql_data += " where question_number ="
                sql_data += question_id
                sql_data += " and survey_id ="
                sql_data += str(survey_id)
                cur.execute(sql_data)
                sql_data = ""
                if len(choices) > 0:
                    for i in range(0, len(choices)):
                        if 'choice_id' in choices[i]:
                            edit_choices.append(choices[i])
                        else:
                            new_choices.append(choices[i])
                    if len(new_choices) > 0:
                        Surveys.insert_choices(new_choices, question_id,
                                               survey_id, con)
                    if len(edit_choices) > 0:
                        Surveys.update_choices(edit_choices, con)
        except Exception as error:
            logger.findaylog("""@ 524 EXCEPTION - models - surveys -
                 question_update """ + str(error.message))
            db_util.release_connection(con)
            raise error
        finally:
            cur.close()
        logger.addinfo('@ models - surveys - question_update(-)')
        return 'success'

    @staticmethod
    def insert_answers(jsond):
        logger.addinfo('@ models - surveys - insert_answers(+)')
        logger.addinfo(time.ctime())
        connection = None
        cursor = None
        flag = 0
        total_list = []
        ids_list = []
        for j in jsond:
            questions = j['questions']
            survey_id = j['survey_id']
            ids_list.append(survey_id)
            for i in questions:
                i['survey_id'] = j['survey_id']
                if 'first_name' in j:
                    i['first_name'] = j['first_name']
                if 'last_name' in j:
                    i['last_name'] = j['last_name']
                if 'phone' in j:
                    i['phone'] = j['phone']
                if 'email_address' in j:
                    i['email_address'] = j['email_address']
                i['created_by'] = j['created_by']
                i['creation_date'] = j['creation_date']
            total_list.append(questions)
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            for j in range(0, len(total_list)):
                fieldname_strng = ""
                paramater_strng = ""
                row_list = []
                for cn_line in total_list[j]:
                    temp_line = cn_line
                    values = ""
                    values = tuple(str(v) for k, v in cn_line.items())
                    row_list.append(values)
                if total_list[j]:
                    dict_val = temp_line
                    fieldname_strng += "("
                    indx_value = 1
                    paramater_strng += "("
                    for key, value in dict_val.items():
                        fieldname_strng += str(key)+','
                        paramater_strng += ":"+str(indx_value)+','
                        indx_value = indx_value+1
                    fieldname_strng = fieldname_strng[:-1]
                    paramater_strng = paramater_strng[:-1]
                    fieldname_strng += ")"
                    paramater_strng += ")"
                cursor.prepare("""insert into
                qpex_responses """ + fieldname_strng+"""
                values""" + paramater_strng)
                cursor.executemany(None, row_list)
        except Exception as error:
            flag = 1
            logger.addinfo(time.ctime())
            logger.findaylog("""@ 593 EXCEPTION - expenses - surveys -
                 insert_answers """ + str(error.message))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            if flag == 0:
                Surveys.update_response(ids_list, connection)
                connection.commit()
            db_util.release_connection(connection)
        logger.addinfo(time.ctime())
        logger.addinfo('@ models - surveys - insert_answers(-)')
        final = {}
        final['status'] = 0
        final['msg'] = 'Responses submitted successfully'
        return final

    @staticmethod
    def get_questions(user_id):
        logger.addinfo('@ models - analytics - get_questions(+)')
        con = None
        cur = None
        result = {}
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['questions_query']
            cur.execute(query, P_USER_ID=user_id)
        except Exception as error:
            logger.findaylog("""@ 622 EXCEPTION - models - surveys -
                 get_questions """ + str(error.message))
            raise error
        else:
            question_list = []
            survey_ids = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                question = {}
                for index, field in enumerate(field_names):
                    question[field] = row[index]
                survey_ids.append(question['survey_id'])
                question_list.append(question)
            result['questions'] = question_list
            result['choices'] = Surveys.get_all_choices(survey_ids)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - surveys - get_questions(-)')
        return result

    @staticmethod
    def update_response(list, connection):
        logger.addinfo("@ models - surveys - update_response(+)")
        cursor = None
        try:
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            for i in list:
                get_query = sql_file['get_response_query']
                tmp_count = cursor.execute(get_query, p_survey_id=i)
                tmp = tmp_count.fetchone()
                query = sql_file['survey_response_count']
                cursor.execute(query, p_count=tmp[0] + 1, p_survey_id=i)
        except Exception as error:
            db_util.release_connection(connection)
            logger.findaylog("""@ 677 EXCEPTION - models - surveys -
                 update_response """ + str(error.message))
            raise error
        finally:
            cursor.close()
        logger.addinfo("@ models - surveys - update_response(-)")
        return 'success'

    @staticmethod
    def incomplete_surveys(count, survey_id):
        logger.addinfo("@ models - surveys - incomplete_surveys(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['survey_incomplete_update']
            cursor.execute(query, p_count=count, p_survey_id=survey_id)
        except Exception as error:
            logger.findaylog("""@ 684 EXCEPTION - models - surveys -
                 incomplete_surveys """ + str(error.message))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - surveys - incomplete_surveys(-)")
        return 'success'

    @staticmethod
    def get_vesrion(app_name):
        logger.addinfo('@ models - surveys - get_vesrion(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['mobile_version_query']
            cursor.execute(query, p_app_name=app_name)
        except Exception as error:
            logger.findaylog("""@ 665 EXCEPTION - models - surveys -
                 get_vesrion """ + str(error.message))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                version = Surveys()
                for index, fn in enumerate(fieldnames):
                    setattr(version, fn, row[index])
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_vesrion(-)')
        return version

    @staticmethod
    def key_values(choices, keys):
        logger.addinfo("@ models - surveys - key_values(+)")
        connection = None
        cursor = None
        final_list = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            for i in range(0, len(keys)):
                final_dict = {}
                sample_keys = []
                query = sql_file['key_word_query']
                cursor.execute(query, p_key_word=keys[i])
                for row in cursor:
                    sample_keys.append(row[0])
                final_dict[choices[i]] = sample_keys
                final_list.append(final_dict)
        except Exception as error:
            logger.findaylog("""@ 585 EXCEPTION - models - surveys -
                 key_values """ + str(error.message))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - surveys - key_values(-)")
        return final_list

    # generate HeaderId
    @staticmethod
    def user_id():
        logger.addinfo("@ models - surveys - user_id(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['survey_user_sequence']
            data = cursor.execute(query).fetchone()
            user_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 712 EXCEPTION - models - surveys -
                 user_id """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - surveys - user_id(-)")
        return user_id

    @staticmethod
    def insert_response(question_list):
        logger.addinfo('@ models - surveys - insert_answers(+)')
        logger.addinfo(time.ctime())
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            dup = []
            for cn_line in question_list:
                length = len(cn_line['answers'])
                answers = cn_line['answers']
                del cn_line['answers']
                final = {}
                for i in range(0, 20):
                    if i < length:
                        final['answer' + str(i+1)] = answers[i]
                    else:
                        final['answer' + str(i+1)] = ''
                cn_line.update(final)
                dup.append(cn_line)
            for cn_line in question_list:
                temp_line = cn_line
                values = ""
                values = tuple(str(val) for key, val in cn_line.items())
                row_list.append(values)
            if question_list:
                dict_val = temp_line
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            cursor.prepare("""insert into
            qpex_responses """ + fieldname_strng+"""
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
            connection.commit()
        except Exception as error:
            logger.addinfo(time.ctime())
            logger.findaylog("""@ 525 EXCEPTION - expenses - surveys -
                 insert_answers """ + str(error.message))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            db_util.release_connection(connection)
        logger.addinfo(time.ctime())
        logger.addinfo('@ models - surveys - insert_answers(-)')
        return "success"

    @staticmethod
    def insert_user(json, user_id):
        logger.addinfo('@ models - surveys - insert_user(+)')
        con = None
        cur = None
        try:
            return_data = {}
            con = db_util.get_connection()
            sql_file = db_util.getSqlData()
            cur = con.cursor()
            row_data = []
            query = sql_file['user_insert_query1']
            my_data = []
            encrypted_password = hashPassword(json['password'])
            json['encrypted_password'] = encrypted_password
            for key, value in json.items():
                my_data.append(value)
                my_new_tuple = tuple(my_data)
            row_data.append(my_new_tuple)
            for key, value in json.items():
                query += str(key)
                query += ','
            query = query[:-1]
            query += sql_file["user_insert_query2"]
            query += str(user_id) + ","
            sql_args = ""
            for idx, key in enumerate(json.items()):
                sql_args += ":" + str(idx) + ","
            sql_args = sql_args[:-1]
            query += sql_args + ")"
            cur.executemany(query, row_data)
            return_data['req_id'] = user_id
            return_data['status'] = 0
            return_data['result'] = "success"
            return_data['msg'] = "User created suceesfully"
        except Exception as error:
            logger.addinfo(time.ctime())
            logger.findaylog("""@ 923 EXCEPTION - models - surveys -
                    insert_user """ + str(error.message))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo(time.ctime())
        logger.addinfo('@ models - surveys - insert_user(-)')
        return return_data

    @staticmethod
    def send_mail(user_name, email_address):
        logger.findaylog('@models - surveys - send_mail(+)')
        connection = None
        cursor = None
        try:
            status = ''
            connection = db_util.get_connection()
            cursor = connection.cursor()
            strings = db_util.get_strings()
            api_key = os.environ['MJ_APIKEY_PUBLIC']
            api_secret = os.environ['MJ_APIKEY_PRIVATE']
            mailjet = Client(auth=(api_key, api_secret))
            data = {
                    'FromEmail': strings['sender_email'],
                    'FromName': strings['sender_name'],
                    'Subject': strings['create_survey_user'],
                    'MJ-TemplateID': 107447,
                    'MJ-TemplateLanguage': True,
                    'MJ-TemplateErrorReporting': 'saikrishna@finday.com',
                    'Vars': {
                        "user_name": user_name
                    },
                    'Recipients': [
                        {
                            'Email': email_address
                        }
                    ]
                }
            result = mailjet.send.create(data=data)
            if result.status_code != 200:
                status = 'Failure - Failed to send email'
            else:
                status = 'success'
        except Exception as error:
            logger.findaylog("""@ 801 EXCEPTION - models - surveys -
                send_mail """ + str(error.message))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.findaylog('@models - surveys - send_mail(-)')
        return status

    @staticmethod
    def get_version(app_name):
        logger.addinfo('@ models - surveys - get_version(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['mobile_version_query']
            cursor.execute(query, p_app_name=app_name)
        except Exception as error:
            logger.findaylog("""@ 1013 EXCEPTION - models - surveys -
                 get_version """ + str(error.message))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                version = Surveys()
                for index, fn in enumerate(fieldnames):
                    setattr(version, fn, row[index])
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_version(-)')
        return version

    @staticmethod
    def login(user_name, password):
        logger.addinfo('@ models - surveys - login(+)')
        connection = None
        cursor = None
        tmp_password = ''
        status = ''
        user_id = ''
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['survey_login_query']
            cursor.execute(query, p_user_name=user_name)
        except Exception as error:
            logger.findaylog("""@ 1013 EXCEPTION - models - surveys -
                 get_version """ + str(error.message))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                for index, fn in enumerate(fieldnames):
                    if fn == 'password':
                        tmp_password = row[index]
                    if fn == 'approved':
                        status = row[index]
                    if fn == 'user_id':
                        user_id = row[index]
        finally:
            cursor.close()
            db_util.release_connection(connection)
            logger.addinfo('@ models - surveys - login(-)')
            if password == tmp_password and status == 'Y':
                return user_id
            else:
                return 'fails'

    @staticmethod
    def validate_email(email_address):
        logger.addinfo('@ models - surveys - get_version(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['valid_contact_query']
            cursor.execute(query, p_email=email_address)
            data = cursor.fetchall()
        except Exception as error:
            logger.findaylog("""@ 1078 EXCEPTION - models - surveys -
                 get_version """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_version(-)')
        if len(data) > 0:
            return 'success'
        else:
            return 'fails'

    @staticmethod
    def insert_choices(choices, question_number, survey_id, connection):
        logger.addinfo('@ models - surveys - insert_choices(+)')
        logger.addinfo(time.ctime())
        sql_file = db_util.getSqlData()
        cursor = None
        try:
            cursor = connection.cursor()
            fieldname_strng = ""
            parameter_strng = ""
            pro_data = []
            for line in choices:
                query = sql_file['question_choice_sequence']
                data = cursor.execute(query).fetchone()
                if type(line) is dict:
                    if "'" in line['choice']:
                        line['choice'] = line['choice'].replace("'", "''")
                    query = sql_file['choice_insert_query']
                    cursor.setinputsizes(p_filedata=cx_Oracle.BLOB)
                    attachmentQuery = query % (int(survey_id),
                                               int(question_number),
                                               data[0], line['choice'],
                                               line['end_survey'])
                    cursor.setinputsizes(blobData=cx_Oracle.BLOB)
                    cursor.execute(attachmentQuery,
                                   {'blobData': line['image_choice']})
                if 'end_survey' in line:
                    del line['end_survey']
                if 'image_choice' in line:
                    del line['image_choice']
                if 'choice' in line:
                    del line['choice']
                line['choice_id'] = data[0]
                line['survey_id'] = int(survey_id)
                line['question_number'] = question_number
                if ('next_question_number' in line and
                        line['next_question_number'] == ''):
                    line['next_question_number'] = None
                values = ""
                values = tuple(val for key, val in line.items())
                pro_data.append(values)
            if choices:
                dict_val = choices[0]
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"
            cursor.prepare("""insert into
            qpex_question_conditions  """ + fieldname_strng+"""
            values""" + parameter_strng)
            cursor.executemany(None, pro_data)
        except Exception as error:
            db_util.release_connection(connection)
            logger.addinfo(time.ctime())
            logger.findaylog("""@ 1073 EXCEPTION - expenses - surveys -
                 insert_choices """ + str(error.message))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
        logger.addinfo(time.ctime())
        logger.addinfo('@ models - surveys - insert_choices(-)')
        return "success"

    @staticmethod
    def show_choices(question_number, survey_id):
        logger.addinfo('@ models - surveys - show_choices(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['question_choices']
            cursor.execute(query, p_survey_id=survey_id,
                           p_question_num=question_number)
            questions = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                question = Surveys()
                for index, fn in enumerate(fieldnames):
                    if fn == 'image_choice' and row[index] is not None:
                        setattr(question, fn, row[index].read())
                    else:
                        setattr(question, fn, row[index])
                questions.append(question)
        except Exception as error:
            logger.findaylog("""@ 157 EXCEPTION - models - surveys -
                 show_choices """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - show_choices(-)')
        return questions

    @staticmethod
    def update_choices(val_list, con):
        logger.addinfo('@ models - surveys - update_choices(+)')
        cur = None
        flag = 0
        next_question = ''
        sql_file = db_util.getSqlData()
        try:
            cur = con.cursor()
            for line in val_list:
                if 'image_choice' in line:
                    flag = 1
                    image_choice = line['image_choice']
                    del line['image_choice']
                if 'next_question_number' in line:
                    next_question = line['next_question_number']
                    del line['next_question_number']
                choice_id = line['choice_id']
                cur.setinputsizes(p_filedata=cx_Oracle.BLOB)
                sql_data = "update qpex_question_choices set "
                for key, value in line.items():
                    if key == 'choice_id':
                        choice_id = str(value)
                    sql_data += str(key)+"="
                    if isinstance(value, str):
                        sql_data += "'"
                    if value is not None:
                        tmp = str(value)
                        if "'" in tmp:
                            t_value = tmp.replace("'", "''")
                            sql_data += t_value
                        else:
                            sql_data += tmp
                    if isinstance(value, str):
                        sql_data += "'"
                    sql_data += ","
                sql_data = sql_data[:-1]
                sql_data += " where choice_id ="
                sql_data += choice_id
                cur.setinputsizes(p_filedata=cx_Oracle.BLOB)
                if flag == 1:
                    update_query = sql_file['image_choice_update']
                    cur.execute(update_query, p_filedata=image_choice,
                                p_choice_id=choice_id)
                if next_question != '' or next_question is not None:
                    condtion_update = sql_file['update_conditions']
                    cur.execute(condtion_update, p_next_question=next_question,
                                p_choice_id=choice_id)
                cur.execute(sql_data)
                sql_data = ""
        except Exception as error:
            logger.findaylog("""@ 498 EXCEPTION - models - surveys -
                 update_choices """ + str(error.message))
            db_util.release_connection(con)
            raise error
        finally:
            cur.close()
        logger.addinfo('@ models - surveys - update_choices(-)')
        return 'success'

    @staticmethod
    def delete_choices(s_id, qns, connection):
        logger.addinfo("@ models - surveys - delete_choices(+)")
        cursor = None
        try:
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query_temp = sql_file['choice_delete_query']
            query = query_temp % (',' . join([":" + str(i)
                                  for i in range(len(qns))]), s_id)
            cursor.execute(query, qns)
        except Exception as error:
            db_util.release_connection(connection)
            logger.findaylog("""@ 371 EXCEPTION - models - surveys -
                 delete_question """ + str(error.message))
            raise error
        finally:
            cursor.close()
        logger.addinfo("@ models - surveys - delete_question(-)")
        return 'success'

    @staticmethod
    def get_question_data(survey_id, user_id):
        logger.addinfo('@ models - surveys - get_question_data(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['question_analytics_query']
            cursor.execute(query, p_user_id=user_id,
                           p_survey_id=survey_id)
            questions = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                question = Surveys()
                for index, fn in enumerate(fieldnames):
                        setattr(question, fn, row[index])
                questions.append(question)
        except Exception as error:
            logger.findaylog("""@ 1217 EXCEPTION - models - surveys -
                 get_question_data """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_question_data(-)')
        return questions

    @staticmethod
    def get_choice_data(jsond):
        logger.addinfo('@ models - surveys - get_choice_data(+)')
        connection = db_util.get_connection()
        if jsond['question_type'] == 'Text - Multi Line':
            result = Surveys.get_text_responses(jsond, connection)
            db_util.release_connection(connection)
            return result
        try:
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['choice_analytics_query']
            cursor.execute(query, p_user_id=jsond['user_id'],
                           p_survey_id=jsond['survey_id'],
                           p_question_number=jsond['question_number'])
            questions = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                question = Surveys()
                for index, fn in enumerate(fieldnames):
                    if fn == 'choice_id':
                        query = sql_file['image_choice_query']
                        cur = connection.cursor()
                        res = cur.execute(query,
                                          p_choice_id=row[index]).fetchone()
                        setattr(question, 'image_choice', res[0].read())
                        setattr(question, 'choice_id', row[index])
                        cur.close
                    else:
                        setattr(question, fn, row[index])
                questions.append(question)
        except Exception as error:
            logger.findaylog("""@ 157 EXCEPTION - models - surveys -
                 get_choice_data """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_choice_data(-)')
        return questions

    @staticmethod
    def get_user_data(jsond):
        logger.addinfo('@ models - surveys - get_user_data(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['user_analytics_query']
            cursor.execute(query, p_survey_id=jsond['survey_id'],
                           p_question_number=jsond['question_number'],
                           p_user_id=jsond['user_id'])
            questions = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                question = Surveys()
                for index, fn in enumerate(fieldnames):
                        setattr(question, fn, row[index])
                questions.append(question)
        except Exception as error:
            logger.findaylog("""@ 1278 EXCEPTION - models - surveys -
                 get_user_data """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_user_data(-)')
        return questions

    @staticmethod
    def get_survey_data(jsond):
        logger.addinfo('@ models - surveys - get_survey_data(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['survey_analytics_query']
            cursor.execute(query, p_survey_id=jsond['survey_id'],
                           p_user_id=jsond['user_id'],
                           p_created_date=jsond['creation_date'])
            questions = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                question = Surveys()
                for index, fn in enumerate(fieldnames):
                        setattr(question, fn, row[index])
                questions.append(question)
        except Exception as error:
            logger.findaylog("""@ 1308 EXCEPTION - models - surveys -
                 get_survey_data """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_survey_data(-)')
        return questions

    @staticmethod
    def get_users():
        logger.addinfo('@ models - surveys - get_users(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_survey_user_details']
            cursor.execute(query)
            questions = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                question = Surveys()
                for index, fn in enumerate(fieldnames):
                        setattr(question, fn, row[index])
                questions.append(question)
        except Exception as error:
            logger.findaylog("""@ 1350 EXCEPTION - models - surveys -
                 get_users """ + str(error.message))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_users(-)')
        return questions

    @staticmethod
    def get_text_responses(jsond, connection):
        logger.addinfo('@ models - surveys - get_choice_data(+)')
        cursor = None
        questions = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['text_analytics_query']
            cursor.execute(query, p_user_id=jsond['user_id'],
                           p_survey_id=jsond['survey_id'],
                           p_question_number=jsond['question_number'])
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                for index, fn in enumerate(fieldnames):
                    questions.append(row[index])
        except Exception as error:
            db_util.release_connection(connection)
            logger.findaylog("""@ 157 EXCEPTION - models - surveys -
                 get_choice_data """ + str(error.message))
            raise error
        finally:
            cursor.close()
        logger.addinfo('@ models - surveys - get_choice_data(-)')
        return questions

    @staticmethod
    def get_all_choices(survey_ids):
        logger.addinfo('@ models - surveys - get_all_choices(+)')
        connection = None
        cursor = None
        choices = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['all_question_choices']
            query = query % (',' . join([str(survey_ids[i])
                             for i in range(len(survey_ids))]))
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1397 EXCEPTION - models - surveys -
                get_all_choices """ + str(error.message))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                choice = {}
                for index, fn in enumerate(fieldnames):
                    if fn == 'image_choice' and row[index]:
                        choice[fn] = row[index].read()
                    else:
                        choice[fn] = row[index]
                choices.append(choice)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - surveys - get_all_choices(-)')
        return choices


def hashPassword(password):
    return auth_util.encrypt(password)
