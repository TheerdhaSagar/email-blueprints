from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.logdata import logger


class PoRegister:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def get_data(self):
        field_names = [a[0].lower() for a in self.cursor.description]
        data = []
        for row in self.cursor:
            obj = {}
            for index, field in enumerate(field_names):
                obj[field] = row[index]
            data.append(obj)
        return data

    def get_po_details(self, vendor_id, org_id, receive='N'):
        logger.addinfo('@ models - poregister - get_po_details(+)')
        try:
            self.acquire()
            self.cursor.arraysize = 256
            query = self.sql_file['po_details_query']
            if vendor_id:
                query += ' where vendor_id=:p_vendor_id '
                query += ' and org_id = NVL(:p_org_id, org_id)'
                query += " and authorization_status <> 'INCOMPLETE'"
                # if receive is 'Y' then show only those PO's which
                # needs to be received
                if receive == 'Y':
                    query = "SELECT * FROM ({0}) WHERE receive = 'Y'".format(query)
                self.cursor.execute(query, p_vendor_id=vendor_id,
                                    p_org_id=org_id)
            else:
                query += ' where CREATION_DATE > TRUNC(sysdate-240)'
                query += ' and org_id = NVL(:p_org_id, org_id)'
                query += " and authorization_status <> 'INCOMPLETE'"
                query += ' AND NOT EXISTS (select 1 from po_lines_all l where\
                        l.po_header_id = h.po_header_id and l.item_id is not null)'
                if receive == 'Y':
                    query = "SELECT * FROM ({0}) WHERE receive = 'Y'".format(query)
                self.cursor.execute(query, p_org_id=org_id)
            result = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - poregister -
                 get_po_details """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - poregister - get_po_details(-)')
        return result

    def get_recent_pos(self, vendor_id, org_id):
        logger.addinfo('@ models - poregister - get_recent_pos(+)')
        try:
            self.acquire()
            self.cursor.arraysize = 256
            query = 'SELECT * FROM ('
            query += self.sql_file['po_details_query']
            query += " WHERE authorization_status <> 'INCOMPLETE'"
            query += ' AND (QUANTITY_BILLED < QUANTITY_RECEIVED'
            query += ' OR QUANTITY_BILLED = 0)'
            if vendor_id:
                query += ' AND vendor_id = :p_vendor_id'
            if org_id:
                query += ' and org_id = :p_org_id'
            query += ' order by  PO_HEADER_ID desc) WHERE rownum < 6'
            if vendor_id and org_id:
                self.cursor.execute(query, p_vendor_id=vendor_id,
                                    p_org_id=org_id)
            elif vendor_id:
                self.cursor.execute(query, p_vendor_id=vendor_id)
            else:
                self.cursor.execute(query, p_org_id=org_id)
            result = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - poregister -
                 get_recent_pos """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - poregister - get_recent_pos(-)')
        return result

    def get_recent_all(self):
        logger.addinfo('@ models - poregister - get_recent_all(+)')
        try:
            self.acquire()
            self.cursor.arraysize = 256
            query = self.sql_file['po_details_query']
            query += ' where CREATION_DATE > TRUNC(sysdate-180)'
            query += " and authorization_status <> 'INCOMPLETE'"
            query += ' AND QUANTITY_BILLED < QUANTITY_RECEIVED'
            query += ' order by  PO_HEADER_ID desc'
            self.cursor.execute(query)
            result = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - poregister -
                 get_recent_all """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - poregister - get_recent_all(-)')
        return result

    def get_po_nos(self, vendor_id, site_id):
        logger.addinfo('@ models - poregister - get_po_nos(+)')
        try:
            self.acquire()
            query = self.sql_file['po_number_query']
            self.cursor.execute(query, p_vendor_id=vendor_id,
                                p_vendor_site_id=site_id)
            result = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - poregister -
                 get_po_nos """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - poregister - get_po_nos(-)')
        return result

    def get_not_received(self, vendor_id, site_id):
        logger.addinfo('@ models - poregister - get_not_received(+)')
        try:
            self.acquire()
            query = self.sql_file['po_details_query']
            query += ' WHERE vendor_id = :p_vendor_id'
            query += ' AND vendor_site_id = :p_vendor_site_id'
            query += ' AND quantity_received < quantity'
            query += ' ORDER BY po_header_id DESC'
            self.cursor.execute(query, p_vendor_id=vendor_id,
                                p_vendor_site_id=site_id)
            result = self.get_data()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - poregister -
                 get_not_received """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - poregister - get_not_received(-)')
        return result
