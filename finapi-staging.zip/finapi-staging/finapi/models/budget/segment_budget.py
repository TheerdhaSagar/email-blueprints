import os
import xlsxwriter
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil
from finapi.utils.constants import Status
from finapi.models.outofdoor.uploadfile import UploadOutofDoorFiles


@LogUtil.class_module_logs('segment_budget')
class SegmentBudget(object):
    def __init__(self):
        folder_name = os.path.basename(os.path.dirname(os.path.realpath(__file__)))
        self.sql_file = sql_util.get_sql(folder_name.lower())

    def get_unique_segments(self):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_unique_segments']
            conn.execute(query)
            result = conn.get_result()
        return {'status': Status.OK.value, 'segments': result}

    @staticmethod
    def get_lower_case(value):
        if isinstance(value, str):
            return value.replace(' ', '').lower()
        return value

    def read_segment_file(self, jsond):
        mapped = []
        upload_obj = UploadOutofDoorFiles(jsond)
        upload_obj.sheet = upload_obj.get_workbook(upload_obj.get_sheets_list()[0])
        upload_obj.row_index, column_names = upload_obj.get_column_names()
        if (SegmentBudget.get_lower_case(column_names[0]['column_name'])
                not in ['segmentname', 'saleschannel', 'budget%']):
            upload_obj.row_index = upload_obj.row_index - 1
        for column in column_names:
            if column.get('column_type') in [2, 5] or \
                    (SegmentBudget.get_lower_case(column['column_name']) ==
                     SegmentBudget.get_lower_case('Budget%')):
                key = 'sales_price'
            elif column['column_index'] == 1 and \
                    SegmentBudget.get_lower_case(column['column_name']) != 'saleschannel':
                key = 'sales_channel'
                column['column_name'] = 'Sales Channel'
            elif column['column_index'] == 0 and \
                    SegmentBudget.get_lower_case(column['column_name']) != 'segmentname':
                key = 'segment_name'
                column['column_name'] = 'Segment Name'
            else:
                key = column['column_name'].replace(' ', '_').lower()
            mapped.append(
                {'oracle_name': key, 'column_name': column['column_name'],
                 'column_index': column['column_index']})
        upload_obj.columns = mapped
        rows = upload_obj.get_rows_data(upload_obj.row_index, 0)

        segment_distinct_list = list({data['segment_name']
                                      for data in rows if data['segment_name']})
        segment_list = self.get_unique_segments()['segments']
        not_found_list = []
        for var in segment_distinct_list:
            if not any(SegmentBudget.get_lower_case(var) ==
                       SegmentBudget.get_lower_case(segment['segments'])
                       for segment in segment_list):
                not_found_list.append(var)
        if not_found_list:
            return {'status': 1,
                    'msg': 'Segment Names not found in DB:' + ', '.join(not_found_list)}
        return SegmentBudget.map_columns_in_segments(jsond, rows)

    @staticmethod
    def map_columns_in_segments(jsond, excel_data):
        budget_output_id = ''
        segments = []
        sales_prices = []
        sales_channels = []
        sales_channels = list(
            {sales.strip() for data in excel_data for sales in data['sales_channel'].split(',')})
        indexes = [1]
        for sales in sales_channels:
            for data in excel_data:
                if data['segment_name'] and sales in data['sales_channel']:
                    sales_prices.append(data['sales_price'])
                    segments.append(data['segment_name'])
            indexes.append(len(segments) + 1)
        with OracleConnectionManager() as conn:
            budget_id = conn.set_output_param('NUMBER')

            conn.execute("""
                    BEGIN
                        qpex_budget_pkg.insert_segment_budget(
                            :p_budget_id,
                            :p_budget_name,
                            :p_start_date,
                            :p_end_date,
                            :p_segment_count,
                            :p_sales_channels,
                            :p_segment_name,
                            :p_sales_price,
                            :p_created_by,
                            :x_status_code
                        );
                    end;
                    """, output_key='x_status_code',
                         p_budget_id=budget_id,
                         p_budget_name=jsond['budget_name'],
                         p_start_date=jsond['start_date'],
                         p_end_date=jsond['end_date'],
                         p_segment_count=indexes,
                         p_sales_channels=sales_channels,
                         p_segment_name=segments,
                         p_sales_price=sales_prices,
                         p_created_by=jsond['created_by'])
            conn.get_output_param(raise_exception=True, send_email=True)
            budget_output_id = budget_id.getvalue()
        return {'status': Status.OK.value, 'msg': 'Budget Added Successfully',
                'budget_id': budget_output_id}

    def get_segment_budget_summary(self):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_segments_budget_summary']
            conn.execute(query)
            result = conn.get_result()
        return {'status': Status.OK.value, 'summary': result}

    def get_segment_budget_lines(self, budget_id):
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_segment_budget_lines']
            conn.execute(query, p_budget_id=budget_id)
            result = conn.get_result()
        return {'status': Status.OK.value, 'summary': result}

    @staticmethod
    def insert_segment_line(jsond):
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                qpex_budget_pkg.insert_segment_line(
                    :p_budget_id,
                    :p_sales_price,
                    :p_sales_group,
                    :p_segment_name,
                    :p_created_by,
                    TRUE,
                    :x_status_code
                );
            END;
            """, output_key='x_status_code',
                         p_budget_id=jsond['budget_id'],
                         p_sales_price=jsond['sales_price'],
                         p_sales_group=jsond['sales_channel'],
                         p_segment_name=jsond['segment_name'],
                         p_created_by=jsond['created_by'])
            conn.get_output_param(raise_exception=True, send_email=True)
        return {'status': Status.OK.value, 'msg': 'Inserted Successfully'}

    @staticmethod
    def update_segment_line(jsond):
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                qpex_budget_pkg.update_segment_line(
                    :p_budget_id,
                    :p_segment_num,
                    :p_sales_price,
                    :p_created_by,
                    :x_status_code
                );
            END;
            """, output_key='x_status_code',
                         p_budget_id=jsond['budget_id'],
                         p_sales_price=jsond['sales_price'],
                         p_segment_num=jsond['segment_num'],
                         p_created_by=jsond['created_by'])
            conn.get_output_param(raise_exception=True, send_email=True)
        return {'status': Status.OK.value, 'msg': 'Updated Successfully'}

    @staticmethod
    def delete_segment_budget_header(header_id):
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                qpex_budget_pkg.delete_segment_header(
                    :p_budget_id,
                    :x_status_code
                );
            END;
            """, output_key='x_status_code',
                         p_budget_id=header_id)
            conn.get_output_param(raise_exception=True, send_email=True)
        return {'status': Status.OK.value, 'msg': 'Deleted Header Successfully'}

    @staticmethod
    def delete_segment_budget_lines(header_id, segment_num):
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                qpex_budget_pkg.delete_segment_lines(
                    :p_budget_id,
                    :p_segment_num,
                    :x_status_code
                );
            END;
            """, output_key='x_status_code',
                         p_budget_id=header_id,
                         p_segment_num=segment_num)
            conn.get_output_param(raise_exception=True, send_email=True)
        return {'status': Status.OK.value, 'msg': 'Deleted Line Successfully'}

    def sample_excel_generation(self):
        segment_details = self.get_unique_segments()['segments']
        static_path = os.path.dirname(os.path.dirname(
            os.path.dirname(__file__)
        )) + '/static/'
        file_name = 'segment_budget.xlsx'
        file_path = os.path.join(static_path, (file_name))
        # to remove existing file with the file_name
        if os.path.exists(file_path):
            os.remove(file_path)
        workbook = xlsxwriter.Workbook(file_path, {'constant_memory': True})
        headers = ['Segment Name', 'Sales Channel', 'Budget%']
        bold = workbook.add_format({'bold': True})
        if segment_details:
            worksheet = workbook.add_worksheet('Segments')
            _ = [worksheet.write(0, h_index, header, bold)
                 for h_index, header in enumerate(headers)]
            for v_index, segment in enumerate(segment_details):
                worksheet.write(v_index + 1, 0, segment['segments'])
        workbook.close()
        return {'status': Status.OK.value, 'file_name': file_name}
