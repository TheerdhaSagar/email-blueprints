from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from collections import OrderedDict
import xlrd
import string
import random
import base64
import cx_Oracle


class Budget:
    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()

    def release(self):
        if self.cursor:
            self.cursor.close()
        db_util.release_connection(self.connection)

    def get_headers(self):
        logger.addinfo('models -budget - get_headers(+)')
        try:
            self.acquire()
            query = self.sql_file['get_budget_headers']
            self.cursor.execute(query)
            budget_headers = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 31 EXCEPTION - models - budget -
                             get_headers """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - budget - get_headers(-)')
        return budget_headers

    def read_file(self, jsond):
        logger.addinfo('model - budget - read_file(+)')
        try:

            # Generate temproary file name
            id_size = 9
            chars = string.ascii_uppercase + string.digits
            file_name = ''.join(random.choice(chars) for _ in range(id_size))
            decoded = base64.b64decode(jsond['file_details']['base64'])

            # Create file in tmp folder
            temp_file_name = '/tmp/' + file_name + '.xls'

            # Open file in write mode and write decoded excel content
            text_file = open(temp_file_name, 'wb')
            text_file.write(decoded)
            text_file.close()

            # Open excel
            workbook = xlrd.open_workbook(temp_file_name)
            sheet = workbook.sheet_by_index(0)

            channel_col_names = []
            row_num = 0
            non_empty_channel_col = ''
            for i in range(sheet.ncols):
                channel_col_names.append(sheet.cell_value(row_num, i))
            channel_prices_columns = []
            for i in range(len(channel_col_names)):
                if channel_col_names[i]:
                    channel_prices_columns.append(channel_col_names[i])
                else:
                    non_empty_channel_col = i + 1
            row_num = 2
            col_names = []
            col_types = []
            for i in range(sheet.ncols):
                col_types.append(sheet.cell_type(row_num + 1, i))
                col_names.append(sheet.cell_value(row_num, i).lower())
            for i in range(non_empty_channel_col, len(col_names)):
                col_names[i] = channel_col_names[i]

            """
                Divide into seperate columns
                if single column has multiple channel names
            """
            temp_channel_names = []
            for i in range(len(channel_prices_columns)):
                split_channel_names = channel_prices_columns[i].split('\n')
                for j in range(len(split_channel_names)):
                    temp_channel_names.append(split_channel_names[j])
            channel_prices_columns = temp_channel_names

            data_list = []
            self.acquire()
            for rownum in range(3, sheet.nrows):
                data = OrderedDict()
                r = sheet.row_values(rownum)
                if r[0] == 'Code Ean':
                    continue
                for i in range(0, len(col_names)):
                    value = r[i]
                    if (type(r[i]) == float) and (
                            col_names[i].lower().strip() == 'code ean'
                            or col_names[i].lower().strip() == 'pz ct'
                            or col_names[i].lower().strip() == 'code'):
                        value = int(r[i])

                    if col_names[i] in channel_col_names:
                        if value:
                            if type(value) == str:
                                value = value.replace(".", "")
                                value = value.replace(",", ".")
                            value = float(value)
                        else:
                            value = float(0)

                    # Split value for each channel in the column
                    temp_column_names = col_names[i].split('\n')
                    for j in range(len(temp_column_names)):
                        data[temp_column_names[j].strip()] = value
                data_list.append(data)
        except Exception as e:
            logger.findaylog(""" @ 130 EXCEPTION - models - budget -
                             read_file """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models- budget - read_file(-)')
        return {'data': data_list, 'channel_prices': channel_prices_columns}

    def insert(self, jsond):
        logger.addinfo('models - budget - insert')
        try:
            self.acquire()
            item_codes = []
            sales_prices = []
            sales_channels = []
            mapped_columns = jsond['sales_channels']
            lines = jsond['lines']
            for i in range(len(lines)):
                if lines[i]['item_code']:
                    item_codes.append(str(lines[i]['item_code']))

            for i in range(len(mapped_columns)):
                if mapped_columns[i]['excel_channel']:
                    value = mapped_columns[i]['oracle_channel']
                    sales_channels.append(value)

            for i in range(len(sales_channels)):
                for j in range(len(lines)):
                    if lines[j]['item_code']:
                        if lines[j][sales_channels[i]]:
                            price = float(lines[j][sales_channels[i]])
                        else:
                            price = float(0)
                        sales_prices.append(price)

            status_code = self.cursor.var(cx_Oracle.STRING)

            self.cursor.execute("""
                DECLARE\
                    sales_channels qpex_budget_pkg.sales_record_cover;\

                    sales_records qpex_budget_pkg.sales_channels_record_cover;\

                    type number_table_t is table of number
                        index by binary_integer;\

                    type string_table_t is table of varchar2(100)
                        index by binary_integer;\

                     type sales_group_price_rec is record
                     (
                        sales_group varchar2(100),
                        sales_price number_table_t
                     );

                     type sales_group_price_t is
                        table of sales_group_price_rec index by binary_integer;\

                     d_item_codes string_table_t := :p_item_codes;\
                     d_sales_price number_table_t := :p_sales_price;\
                     d_sales_channels string_table_t := :p_sales_channels;\
                     d_sales_group_price sales_group_price_t;\
                     d_loop_variable_start number;
                     d_loop_variable_end number;
                     d_loop_variable number;

                    BEGIN\
                        d_loop_variable_start := 1;\
                        d_loop_variable_end := d_item_codes.count;\
                        for i in 1..d_sales_channels.count
                        LOOP
                            d_sales_group_price(i).sales_group := d_sales_channels(i);\
                            d_loop_variable := 1;\
                            for j in d_loop_variable_start..d_loop_variable_end
                            loop
                                d_sales_group_price(i).sales_price(d_loop_variable) := d_sales_price(j);
                                d_loop_variable := d_loop_variable + 1;\
                            end loop;\
                            d_loop_variable_start := d_loop_variable_end + 1;\
                            d_loop_variable_end := d_loop_variable_end + d_item_codes.count;\
                        end loop;\

                        for j in 1..d_sales_channels.count
                        LOOP
                            sales_records(j).sales_group := d_sales_channels(j);
                            for i in 1..d_item_codes.count
                            loop
                                sales_records(j).budget_lines(i).item_code := d_item_codes(i);
                                sales_records(j).budget_lines(i).sales_price := d_sales_group_price(j).sales_price(i);
                            end loop;\
                        end loop;\

                        qpex_budget_pkg.insert_budget(
                            :p_budget_name,
                            :p_start_date,
                            :p_end_date,
                            sales_records,
                            :p_created_by,
                            :x_status_code
                        );
                    end;
            """, p_budget_name=jsond['budget_name'],
                                p_start_date=jsond['start_date'],
                                p_end_date=jsond['end_date'],
                                p_item_codes=item_codes,
                                p_sales_price=sales_prices,
                                p_sales_channels=sales_channels,
                                p_created_by=jsond['created_by'],
                                x_status_code=status_code)

        except Exception as e:
            logger.findaylog(""" @ 174 EXCEPTION - models - budget -
                             insert """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - budget - insert(-)')
        return status_code.getvalue()

    def get_budget_lines(self, budget_id):
        logger.addinfo('models - budget - get_budget_lines(+)')
        try:
            self.acquire()
            query = self.sql_file['get_budget_lines']
            self.cursor.execute(query, p_budget_id=budget_id)
            lines = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" 209 EXCEPTION - models - budget -
                             get_budget_lines """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - budget - get_budget_lines(-)')
        return lines

    def delete_header(self, budget_id):
        logger.addinfo('models - budget - delete_header(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                begin
                    qpex_budget_pkg.delete_header(
                        :p_budget_id,
                        :x_status_code
                    );
                end;
            """, p_budget_id=budget_id,
                                x_status_code=status_code)
        except Exception as e:
            logger.findaylog(""" @ 231 EXCEPTION - models - budget -
                             delete_header """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - budget - delete_header(-)')
        return status_code.getvalue()

    def delete_lines(self, budget_id, item_code):
        logger.addinfo('models - budget - delete_lines(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                begin
                    qpex_budget_pkg.delete_lines(
                        :p_budget_id,
                        :p_item_code,
                        :x_status_code
                    );
                end;
            """, p_budget_id=budget_id,
                                p_item_code=str(item_code),
                                x_status_code=status_code)
        except Exception as e:
            logger.findaylog(""" @ 254 EXCEPTION - models - budget -
                             delete_lines """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - budget - delete_lines(-)')
        return status_code.getvalue()

    def insert_line(self, jsond):
        logger.addinfo('models- budget - insert_line(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            item_description = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                begin
                    qpex_budget_pkg.insert_line (
                        :p_budget_id,
                        :p_item_code,
                        :p_sales_price,
                        :p_sales_group,
                        :x_status_code,
                        :x_item_description
                    );
                end;
            """, p_budget_id=jsond['budget_id'],
                                p_item_code=str(jsond['item_code']),
                                p_sales_price=jsond['sales_price'],
                                p_sales_group=jsond['sales_group'],
                                x_status_code=status_code,
                                x_item_description=item_description)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - budget -
                            insert_line """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - budget - insert_line(-)')
        return {
            'status': status_code.getvalue(),
            'item_description': item_description.getvalue()
        }

    def update_line(self, jsond):
        logger.addinfo('models- budget - update_line(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                begin
                    qpex_budget_pkg.update_line (
                        :p_budget_id,
                        :p_item_code,
                        :p_sales_price,
                        :x_status_code
                    );
                end;
            """, p_budget_id=jsond['budget_id'],
                                p_item_code=jsond['item_code'],
                                p_sales_price=jsond['sales_price'],
                                x_status_code=status_code)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models - budget -
                            update_line """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - budget - update_line(-)')
        return status_code.getvalue()

    def get_start_end_dates(self, jsond):
        logger.addinfo('models - budget - get_start_end_dates(+)')
        try:
            self.acquire()
            query = self.sql_file['get_start_end_dates']
            sales_channels = ','.join("'" + str(s) + "'" for s in jsond['channels'])
            query %= sales_channels
            self.cursor.execute(query,
                                p_start_date=jsond['start_date'],
                                p_end_date=jsond['end_date'],
                                )
            existing_channels = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog(""" @ 397 EXCEPTION - models - budget -
                             get_start_end_dates """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - budget - get_start_end_dates(-)')
        return existing_channels
