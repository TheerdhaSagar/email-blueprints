from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import logger


class ProofOfDelivery:

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def get_pod_details(self, jsond):
        """
        To get proof of delivery details
        filters : pod_received, customer_invoice_date( from_date, to_date), org_id
        :return: json array
        """
        logger.addinfo('@ models - proofofdelivery - get_pod_details(-)')
        try:
            query = self.sql_file['get_pod']
            with OracleConnectionManager() as conn:
                conn.execute(query,
                             p_pod_received=jsond['pod_received'],
                             p_from_date=jsond['from_date'],
                             p_to_date=jsond['to_date'],
                             p_org_id=jsond['org_id'])
                result = conn.get_result()
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - proofofdelivery -
            get_pod_details """ + str(error))
            raise error
        logger.addinfo('@ models - proofofdelivery - get_pod_details(+)')
        return result
