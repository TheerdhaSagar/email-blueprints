import datetime
import base64
import string
import random
import xlrd
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('upload-outofdoor')
class UploadOutofDoorFiles(object):

    def __init__(self, jsond):
        tmp_file = UploadOutofDoorFiles.get_temporary_file_from_base64(jsond['base64'])
        try:
            self.xls_workbook = xlrd.open_workbook(tmp_file, formatting_info=True)
        except Exception:
            self.xls_workbook = xlrd.open_workbook(tmp_file)
        self.sheet = self.get_workbook(sheet_name=jsond.get('sheet_name'))
        self.columns = jsond.get('mapped_columns')
        self.distributor = jsond.get('distributor')
        self.row_index = jsond.get('row_index')

    def get_workbook(self, sheet_name=None):
        """
        Get sheet details by sheet name
        """
        sheet = None
        if sheet_name:
            sheet = self.xls_workbook.sheet_by_name(sheet_name)
        return sheet

    def get_sheets_list(self):
        """
        Get excel workbook sheets
        """
        return self.xls_workbook.sheet_names()

    @staticmethod
    def get_temporary_file_from_base64(base_64):
        tmp_folder = '/tmp/'
        decoded = base64.b64decode(base_64)
        file_name = UploadOutofDoorFiles.id_generator()
        tmp_f_name = tmp_folder + file_name + '.xls'
        text_file = open(tmp_f_name, 'wb')
        text_file.write(decoded)
        text_file.close()
        return tmp_f_name

    @staticmethod
    def id_generator():
        size = 9
        chars = string.ascii_uppercase + string.digits
        system_random = random.SystemRandom()
        return ''.join(system_random.choice(chars) for _ in range(size))

    def get_month_year(self, data, parsed_date=False):
        """
        get month and year if there is date format
        """
        date_mode = self.xls_workbook.datemode
        date = datetime.datetime(
            *xlrd.xldate_as_tuple(data, date_mode))
        return date.strftime("%d/%m/%Y") if parsed_date else date.strftime("%m/%Y")

    def get_column_names(self, start_index=0, end_index=None, non_empty_no=4):
        if not end_index:
            end_index = self.sheet.nrows
        row_index = 0
        non_empty_values = []
        # Iterate through all the rows and take the first row with all non empty values as column
        # names or column names with non empty values greater than 4 for zeigler, generation pet
        # and e and f
        for i in range(start_index, end_index):
            columns = [{'column_name': self.sheet.cell_value(i, j), 'column_index': j,
                        'column_type': self.sheet.cell_type(i, j)}
                       for j in range(self.sheet.ncols)]
            non_empty_values = [col for col in columns if col['column_name']]
            empty_values = len(columns) - len(non_empty_values)
            if empty_values == 0 or len(non_empty_values) > non_empty_no:
                row_index = i + 1
                break
        return row_index, non_empty_values

    def format_cell_value(self, cell_type, cell_value):
        if (cell_type == 2 or
                cell_type == 5):
            # 2 - float type value, 5 - Integer type value
            row_data = float(0) if not cell_value else float(cell_value)
        elif cell_type == 3:
            # 3 - date value in float
            row_data = self.get_month_year(cell_value, parsed_date=True)
        elif cell_type == 1:
            # 1 - Non empty string value
            row_data = cell_value.strip()
        elif cell_type == 0 or cell_type == 6:
            row_data = ''
        else:
            row_data = cell_value
        return row_data

    def get_distributor_file(self):
        rows = []
        if self.sheet.nrows:
            if self.distributor.lower() == 'nan':
                rows = self.upload_file_nan()
            elif self.distributor.lower() == 'e and f':
                rows = self.upload_e_and_f_file()
            else:
                rows = self.upload_us_files()
        return rows

    def get_rows_data(self, row_index, non_empty_count=3, cust_orc_name='NAME'):
        """
        For getting row details based on the selected columns
        :param row_index:  From where it should start
        to remove the rows , we add add_n_rows
        for example: generation pet , last row is totals so to neglect that row
        we add -1
        """
        rows = []
        cust_name = ''
        for i in range(row_index, self.sheet.nrows):
            row_data = {}
            for column in self.columns:
                row_value = ''
                if column['column_name'] != 'NA':
                    cust_name, row_value = self.column_non_empty_value(
                        i, column, cust_name, cust_orc_name)
                row_data[column['oracle_name']] = row_value
            non_empty_values = [value for _, value in list(row_data.items())
                                if self.check_non_empty_fields(value)]
            if len(non_empty_values) > non_empty_count:
                rows.append(row_data)
        return rows

    def check_non_empty_fields(self, value):
        return not isinstance(value, str) or \
            (isinstance(value, str) and value)

    def column_non_empty_value(self, row_index, column, cust_name, cust_orc_name):
        col_index = column['column_index']
        row_value = self.format_cell_value(self.sheet.cell_type(row_index, col_index),
                                           self.sheet.cell_value(row_index, col_index))
        if column.get('column_calc'):
            math_expr = column['column_calc'].replace(column['oracle_name'].upper(),
                                                      str(row_value))
            row_value = UploadOutofDoorFiles.evaluate(math_expr)
        if column['oracle_name'] == cust_orc_name:
            cust_name = row_value or cust_name
            row_value = cust_name
        return cust_name, row_value

    @staticmethod
    def evaluate(input_string):
        code = compile(input_string, "<string>", "eval")
        if code.co_names:
            raise NameError("Use of names not allowed")
        return eval(code, {"__builtins__": {}}, {})

    def upload_us_files(self):
        rows = self.get_rows_data(self.row_index)
        return rows

    def upload_file_nan(self):
        cust_name_flag = next(
            column['column_name'] for column in self.columns if column['oracle_name'] == 'NAME')
        customer_name = ''
        nan_array = []
        rows = self.get_rows_data(self.row_index, 0)
        if cust_name_flag == 'NA':
            for row in rows:
                text = row['DESCRIPTION']
                if text.startswith('AL ', 0) or text.startswith('ALM ', 0) \
                        or text.find('SALES') != -1 \
                        or text.find('FEEDER') != -1:
                    row['NAME'] = customer_name
                    nan_array.append(row)
                else:
                    customer_name = text
        else:
            nan_array = rows
        return nan_array

    def upload_zeigler_file(self):
        row_num = 12
        zeigler_arr = []
        cust_num = None
        cust_name = None
        for row in range(row_num, self.sheet.nrows):
            zeigler_row = {}
            cust_num_iterator = self.sheet.cell_value(row, 0)
            cust_name_iterator = self.sheet.cell_value(row, 1).rstrip()
            if cust_name_iterator is not None and cust_name_iterator != 'Customer':
                cust_name = cust_name_iterator
                cust_num = cust_num_iterator
            if row + 2 < self.sheet.nrows:
                item_code = self.sheet.cell_value(row + 2, 13).rstrip()
                qty = self.sheet.cell_value(row + 2, 16)
                amount = self.sheet.cell_value(row + 2, 19)
                item_descr = self.sheet.cell_value(row + 2, 21).rstrip()
                if item_code:
                    zeigler_row['CUST_NO'] = cust_num
                    zeigler_row['NAME'] = cust_name
                    zeigler_row['ITEM_CODE'] = item_code
                    zeigler_row['DESCRIPTION'] = item_descr
                    zeigler_row['QTY'] = qty
                    zeigler_row['TOTAL'] = amount
                    zeigler_arr.append(zeigler_row)
        return zeigler_arr

    def upload_e_and_f_file(self):
        ef_array = []
        each_cust_name = ''
        state = ''
        for i in range(self.sheet.ncols):
            cell_value = self.sheet.cell_value(0, i)
            if cell_value and cell_value != 0 and cell_value != 'TOTAL':
                cust_names = cell_value.split(' ')
                if len(cust_names) > 1:
                    state = cust_names[0][:-1]
                    del cust_names[0]
                    each_cust_name = ' '.join(cust_names)
                for row_index in range(self.sheet.nrows):
                    ef_row = {}
                    each_item_qty = self.sheet.cell_value(row_index, i)
                    each_item_sales = self.sheet.cell_value(row_index, i + 2)
                    item_description = self.sheet.cell_value(row_index, 0)
                    if each_item_qty and each_item_qty != 0 and item_description:
                        ef_row['NAME'] = each_cust_name
                        ef_row['DESCRIPTION'] = item_description
                        ef_row['QTY'] = each_item_qty
                        ef_row['TOTAL'] = each_item_sales
                        ef_row['STATE'] = state
                        ef_row['CUST_NO'] = ''
                        ef_row['ITEM_CODE'] = ''
                        ef_array.append(ef_row)
        return ef_array
