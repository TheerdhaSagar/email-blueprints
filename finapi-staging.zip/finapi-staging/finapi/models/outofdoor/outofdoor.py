from finapi.models.outofdoor.uploadfile import UploadOutofDoorFiles
from finapi.utils import db_util
from collections import OrderedDict
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util
from finapi.sql import sql_util
from finapi.utils.conn_util import OracleConnectionManager
from finapi.models.storelocator.storelocator import StoreLocator
from copy import deepcopy
from finapi.utils.log_util import LogUtil
import base64
import datetime
import xlrd
import string
import os
import ujson
import random
import itertools


@LogUtil.class_module_logs('Outofdoor')
class Outofdoor:

    def __init__(self, **kwargs):
        self.tmp_folder = '/tmp/'
        self.manager_no = '%-{}-%'
        self.customer_name_var = 'Customer Name'
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    def get_file_name(self, file_data):
        decoded = base64.b64decode(file_data)
        file_name = Outofdoor.id_generator()
        tmp_f_name = self.tmp_folder + file_name + '.xls'
        text_file = open(tmp_f_name, 'wb')
        text_file.write(decoded)
        text_file.close()
        return tmp_f_name

    def get_sheet_names(self, jsond):
        file_name = self.get_file_name(jsond['file_data'])
        sheet = xlrd.open_workbook(file_name)
        sheet_names = sheet.sheet_names()
        return sheet_names

    def open_file(self, file_data, sheet_name):
        file_name = self.get_file_name(file_data)
        sheet = xlrd.open_workbook(file_name)
        return sheet.sheet_by_name(sheet_name), sheet

    def get_month_year(self, data, sheet, parsed_date=False):
        date_mode = sheet.datemode
        date = datetime.datetime(
            *xlrd.xldate_as_tuple(data, date_mode))
        return date.strftime("%d/%m/%Y") if parsed_date else date.strftime("%m/%Y")

    def get_column_index(self, mapped_column, column_names, data):
        alternate_column_index = -1
        column_index = column_names.index(mapped_column['column_name'])
        if mapped_column.get('alternate_column_name'):
            alternate_column_index = column_names.index(mapped_column['alternate_column_name'])

        # alternate_column_index is the index of alternate column.
        # Used to replace the value if the actual column is empty
        return alternate_column_index if not data[column_index] and \
            mapped_column.get('alternate_column_name') else column_index

    def validate_filter_by_column(self, jsond, data, sheet, i):
        if jsond.get('reference_type') == 'chain_store' and \
           Outofdoor.check_resultant_key_in_chain_store(jsond, data, i):
            return True
        # To filter data with selected period date and month
        date = jsond['period']
        filter_by_column = [d for d in jsond['mapped_columns'] if d['oracle_column_name'] == 'filter_by_date_month'
                            and d['column_name'] != 'NA']
        if filter_by_column and filter_by_column[0]['column_name']:
            column_index = jsond['column_names'].index(filter_by_column[0]['column_name'])
            if data.cell_type(i, column_index) == 3:
                formatted_date = self.get_month_year(data.cell_value(i, column_index), sheet)
                if formatted_date.lstrip('0') != date:
                    return True
            elif str(data.cell_value(i, column_index).split('-')[0]).strip() != str(date.split('/')[0]):
                return True
        return False

    def format_cell_value(self, cell_type, cell_value):
        if (cell_type == 2 or
                cell_type == 5):
            # 2 - float type value, 5 - Integer type value
            row_data = float(0) if not cell_value else float(cell_value)
        elif cell_type == 3:
            # 3 - date value in float
            row_data = self.get_month_year(cell_value, parsed_date=True)
        elif cell_type == 1:
            # 1 - Non empty string value
            row_data = cell_value.strip()
        elif cell_type == 0:
            row_data = None
        else:
            row_data = cell_value
        return row_data

    def get_rows_data(self, jsond, data, sheet):
        rows = []
        row_index = jsond['row_index']
        column_names = jsond['column_names']
        mapped_columns = jsond['mapped_columns']
        for i in range(row_index, data.nrows):
            row_data = {}

            # To filter data with selected period date and month
            if self.validate_filter_by_column(jsond, data, sheet, i):
                continue

            for j in range(len(mapped_columns)):
                # If object has delete_column attribute dont add that column
                if mapped_columns[j].get('delete_column') or \
                        mapped_columns[j]['oracle_column_name'] == 'filter_by_date_month':
                    continue

                # If the column is mandatory and there is no matching column in uploaded file set value to null
                if mapped_columns[j]['column_name'] == 'NA':
                    row_data[mapped_columns[j]['oracle_column_name']] = ''
                    continue

                # get mapped column index in uploaded file
                get_value_from_index = self.get_column_index(
                    mapped_columns[j], column_names, data.row_values(i))

                row_data[mapped_columns[j]['oracle_column_name']] = self.format_cell_value(
                    data.cell_type(i, get_value_from_index),
                    data.cell_value(i, get_value_from_index))
            row_data = Outofdoor.check_inserted_row(jsond, row_data)
            if row_data:
                rows.append(row_data)
        return rows

    def upload_canada_file(self, jsond):
        data, sheet = self.open_file(jsond['file_data'], jsond['sheet_name'])
        jsond['data'] = self.get_rows_data(jsond, data, sheet)
        result = Outofdoor.save(jsond)
        return result

    @staticmethod
    def check_resultant_key_in_chain_store(jsond, data, row_index):
        """
        check the row containing invalid keys and not insert them in db
        """
        if jsond.get('reference_type') == 'chain_store':
            sql_file = db_util.getSqlData()
            invalid_keys = sql_file['chain_store_exception_keys']
            for key in invalid_keys:
                if (key.lower() in [val.lower() for val in data.row_values(row_index)
                                    if isinstance(val, str)]):
                    return True
        return False

    @staticmethod
    def check_inserted_row(jsond, row_data):
        if not row_data['item_code'] and jsond.get('reference_type') == 'chain_store':
            return None
        # Add Customer Data for chain stores as they are default values
        if jsond.get('reference_type') == 'chain_store':
            row_data['cust_no'] = 52786
            row_data['customer_name'] = 'J.E. Mondou LTEE'
        return row_data

    def get_column_names(self, jsond):
        oracle_column_names = ['Item Code', 'Description',
                               'Cust No', self.customer_name_var,
                               'Address', 'City', 'State', 'Country',
                               'Zip Code', 'Phone', 'Ship To Name',
                               'Ship To Addr', 'Ship To City',
                               'Ship To Zip', 'Quantity', 'UOM',
                               'PZ Quantity', 'Amount', 'Total Sales',
                               'Discount', 'Salesrep No', 'Sales Person']
        if jsond.get('reference_type') == 'chain_store':
            oracle_column_names.extend(
                ['E Commerce Qty', 'E Commerce Sales', 'Stores Qty', 'Stores Sales'])
        data, sheet = self.open_file(jsond['file_data'], jsond['sheet_name'])
        row_index = 0
        # Iterate through all the rows and take the first row with all non empty values as column names
        for i in range(data.nrows):
            column_names = [data.cell_value(i, j).strip() for j in range(data.ncols)]
            if column_names.count('') == 0 or (jsond.get('reference_type') == 'chain_store'
                                               and column_names.count('') < 5):
                row_index = i + 1
                break
        result = {
            'row_index': row_index,
            'column_names': column_names,
            'oracle_column_names': oracle_column_names
        }
        return result

    def get_states(self, manager_id):
        state_list = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['out_of_door_states']
            if manager_id is None:
                query = query.format(manager_filter='')
                conn.execute(query)
            else:
                query = query.format(
                    manager_filter=self.sql_file['outofdoor_revenue_month_by_manager'])
                conn.execute(query, p_manager_no=self.manager_no.format(manager_id))
            state_list = conn.get_result()
        return state_list

    def revenue_states_months(self, year, st):
        revenue_list = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['outofdoor_states_months']
            conn.execute(query, p_year=year, p_st=st)
            revenue_list = conn.get_result()
        return revenue_list

    @staticmethod
    def writing(pencoded, file_type, replaceYear):
        logger.addinfo("@ models - outofdoor - writing(+)")
        try:
            decoded = base64.b64decode(pencoded)
            file_name = Outofdoor.id_generator()
            tmp_f_name = file_name + '.xls'
            text_file = open(tmp_f_name, 'w')
            text_file.write(decoded)
            text_file.close()
            if file_type == 'west':
                tmp_data = Outofdoor.reading(tmp_f_name, file_type,
                                             replaceYear)
            else:
                tmp_data = Outofdoor.just_reading(tmp_f_name, file_type,
                                                  replaceYear)
            if tmp_data == "success":
                tmp_data = Outofdoor.update_empty_agents()
                tmp_data = Outofdoor.save_agents_data()
        except Exception as error:
            logger.findaylog("""@ 35 EXCEPTION - models - outofdoor -
                 csv_writing """ + str(error))
            raise error
        logger.addinfo("@ models - outofdoor - csv_writing(-)")
        return tmp_data

    @staticmethod
    def id_generator():
        size = 9
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))

    @staticmethod
    def reading(file_name, file_type, replaceYear):
        logger.addinfo("@ models - outofdoor - reading(+)")
        try:
            book = xlrd.open_workbook(file_name)
            sheet = book.sheet_by_index(0)
            data = []
            rowCount = sheet.nrows
            item_cols = ['CUST_NO', 'ITEM_CODE', 'DESCRIPTION', 'YEAR',
                         'JAN_SALES', 'JAN_QUANTITY', 'FEB_SALES',
                         'FEB_QUANTITY', 'MAR_SALES', 'MAR_QUANTITY',
                         'APR_SALES', 'APR_QUANTITY', 'MAY_SALES',
                         'MAY_QUANTITY', 'JUN_SALES', 'JUN_QUANTITY',
                         'JUL_SALES', 'JUL_QUANTITY', 'AUG_SALES',
                         'AUG_QUANTITY', 'SEP_SALES', 'SEP_QUANTITY',
                         'OCT_SALES', 'OCT_QUANTITY', 'NOV_SALES',
                         'NOV_QUANTITY', 'DEC_SALES', 'DEC_QUANTITY', 'ID',
                         'NAME']
            cust_cols = ['CUST_NO', 'NAME', 'ADDRESS', 'CITY', 'ST', 'ZIP',
                         'PHONE', 'EMAIL', 'ID']
            item_data = []
            first_row_values = []
            second_row_values = []
            firstrow = sheet.row_values(0)
            # years
            for num in range(0, len(firstrow)):
                if(firstrow[num] != '' and firstrow[num] is not None):
                    first_row_values.append(int(firstrow[num]))
            secondrow = sheet.row_values(1)
            final_second_row = []
            # months
            for num in range(0, len(secondrow)):
                if(secondrow[num] != '' and secondrow[num] is not None):
                    if(secondrow[num] == 'Total'):
                        final_second_row.append(second_row_values)
                        second_row_values = []
                    else:
                        second_row_values.append(secondrow[num])
            new_months = final_second_row[-1]
            new_month = int(new_months[-1])
            new_year = first_row_values[-1]
            # starting from 4th row
            for rownum in range(3, rowCount):
                row_values = sheet.row_values(rownum)
                if (row_values[0] is not None and row_values[0] != '' and
                        row_values[0] != 'Total'):
                    final_data = OrderedDict()
                    id = str(row_values[0])
                    name = str(row_values[2])
                    state = str(row_values[5])
                    add_id = str(row_values[1])
                    final_data[cust_cols[0]] = id
                    final_data[cust_cols[1]] = name
                    final_data[cust_cols[2]] = str(row_values[3])
                    final_data[cust_cols[3]] = str(row_values[4])
                    final_data[cust_cols[4]] = state
                    final_data[cust_cols[5]] = str(row_values[6])
                    final_data[cust_cols[6]] = str(row_values[7])
                    final_data[cust_cols[7]] = str(row_values[8])
                    final_data[cust_cols[8]] = add_id
                    final_data['REGION'] = file_type
                    final_data['MONTH'] = new_month
                    final_data['YEAR'] = new_year
                    data.append(final_data)
                elif (row_values[0] != 'Total' and row_values[1] != '' and
                        row_values[1] is not None and
                        row_values[1] != 'Total' and
                        row_values[2] != 'Total' and
                        row_values[2] != '' and
                        row_values[2] is not None and
                        (row_values[0] == '' or row_values[0] is None)):
                    final_data = OrderedDict()
                    name = str(row_values[2])
                    add_id = str(row_values[1])
                    if row_values[5] is not None and row_values[5] != '':
                        state = str(row_values[5])
                    else:
                        state = ''
                    final_data[cust_cols[0]] = id
                    final_data[cust_cols[1]] = name
                    if row_values[3] is not None and row_values[3] != '':
                        final_data[cust_cols[2]] = str(row_values[3])
                    else:
                        final_data[cust_cols[2]] = ''
                    if row_values[4] is not None and row_values[4] != '':
                        final_data[cust_cols[3]] = str(row_values[4])
                    else:
                        final_data[cust_cols[3]] = ''
                    final_data[cust_cols[4]] = state
                    if row_values[6] is not None and row_values[6] != '':
                        final_data[cust_cols[5]] = str(row_values[6])
                    else:
                        final_data[cust_cols[5]] = ''
                    if row_values[7] is not None and row_values[7] != '':
                        final_data[cust_cols[6]] = str(row_values[7])
                    else:
                        final_data[cust_cols[6]] = ''
                    if row_values[8] is not None and row_values[8] != '':
                        final_data[cust_cols[7]] = str(row_values[8])
                    else:
                        final_data[cust_cols[7]] = ''
                    final_data[cust_cols[8]] = add_id
                    final_data['REGION'] = file_type
                    final_data['MONTH'] = new_month
                    final_data['YEAR'] = new_year
                    data.append(final_data)
                if replaceYear:
                    # replace specific year
                    index = first_row_values.index(replaceYear)
                    if index != -1:
                        if (id != '' and row_values[0] != 'Total' and
                                row_values[1] != 'Total' and
                                row_values[2] != 'Total'):
                            toReplaceYear = first_row_values[index]
                            m = 0
                            count = index * 26 + 11
                            item_yr_data = OrderedDict()
                            item_yr_data[item_cols[0]] = id
                            if (row_values[9] is not None and
                                    row_values[9] != ''):
                                item_yr_data[item_cols[1]] = str(row_values[9])
                            else:
                                item_yr_data[item_cols[1]] = ''
                            if (row_values[10] is not None and
                                    row_values[10] != ''):
                                a1_count = str(row_values[10])
                                item_yr_data[item_cols[2]] = a1_count
                            else:
                                item_yr_data[item_cols[2]] = ''
                            b1_count = str(first_row_values[index])
                            item_yr_data[item_cols[3]] = b1_count
                            dict = 4
                            for m in range(12):
                                if(m < len(final_second_row[index])):
                                    if (row_values[count] is not None and
                                            row_values[count] != ''):
                                        d1_coun = str(row_values[count])
                                        item_yr_data[item_cols[dict]] = d1_coun
                                    else:
                                        item_yr_data[item_cols[dict]] = ''
                                    if (row_values[count+1] is not None and
                                            row_values[count+1] != ''):
                                        e1_c = str(row_values[count+1])
                                        item_yr_data[item_cols[dict+1]] = e1_c
                                    else:
                                        item_yr_data[item_cols[dict+1]] = ''
                                    count += 2
                                    dict += 2
                                else:
                                    item_yr_data[item_cols[dict]] = ''
                                    item_yr_data[item_cols[dict+1]] = ''
                                    dict += 2
                            count += 2
                            item_yr_data[item_cols[len(item_cols)-2]] = add_id
                            item_yr_data[item_cols[len(item_cols)-1]] = name
                            item_yr_data['REGION'] = file_type
                            item_yr_data['MONTH'] = new_month
                            item_yr_data['CITY'] = str(row_values[4])
                            item_yr_data['ST'] = state
                            item_data.append(item_yr_data)
                    else:
                        return "selected year not available in file"
                else:
                    toReplaceYear = ''
                    if (id != '' and row_values[0] != 'Total' and
                            row_values[1] != 'Total' and
                            row_values[2] != 'Total'):
                        count = 11
                        m = 0
                        for y in range(len(first_row_values)):
                            item_yr_data = OrderedDict()
                            item_yr_data[item_cols[0]] = id
                            if (row_values[9] is not None and
                                    row_values[9] != ''):
                                item_yr_data[item_cols[1]] = str(row_values[9])
                            else:
                                item_yr_data[item_cols[1]] = ''
                            if (row_values[10] is not None and
                                    row_values[10] != ''):
                                z_count = str(row_values[10])
                                item_yr_data[item_cols[2]] = z_count
                            else:
                                item_yr_data[item_cols[2]] = ''
                            y_count = str(first_row_values[y])
                            item_yr_data[item_cols[3]] = y_count
                            dict = 4
                            for m in range(12):
                                if(m < len(final_second_row[y])):
                                    if (row_values[count] is not None and
                                            row_values[count] != ''):
                                        t_count = str(row_values[count])
                                        item_yr_data[item_cols[dict]] = t_count
                                    else:
                                        item_yr_data[item_cols[dict]] = ''
                                    if (row_values[count+1] is not None and
                                            row_values[count+1] != ''):
                                        r_cou = str(row_values[count+1])
                                        item_yr_data[item_cols[dict+1]] = r_cou
                                    else:
                                        item_yr_data[item_cols[dict+1]] = ''
                                    count += 2
                                    dict += 2
                                else:
                                    item_yr_data[item_cols[dict]] = ''
                                    item_yr_data[item_cols[dict+1]] = ''
                                    dict += 2
                            count += 2
                            item_yr_data[item_cols[len(item_cols)-2]] = add_id
                            item_yr_data[item_cols[len(item_cols)-1]] = name
                            item_yr_data['REGION'] = file_type
                            item_yr_data['ST'] = state
                            item_data.append(item_yr_data)
            tmp = ujson.dumps(data)
            tmp1 = ujson.dumps(item_data)
            os.remove(file_name)
            new_cust = ujson.dumps(Outofdoor.new_customers(tmp))
            msg = Outofdoor.save_data(new_cust, tmp1, toReplaceYear, file_type)
        except Exception as error:
            logger.findaylog("""@ 80 EXCEPTION - models - outofdoor -
                 reading """ + str(error))
            raise error
        logger.addinfo("@ models - outofdoor - reading(-)")
        return msg

    @staticmethod
    def save_data(data, itm, toReplaceYear, file_type):
        logger.addinfo('@ models - outofdoor - save_data(+)')
        connection = None
        cursor = None
        fieldname_strng = ""
        parameter_strng = ""
        item_field = ""
        item_parameter = ""
        data = ujson.loads(data)
        itm = ujson.loads(itm)
        try:
            sql_file = db_util.getSqlData()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cus_data = []
            it_data = []
            if toReplaceYear:
                # do something
                query = sql_file['outofdoor_delete_year_data']
                cursor.execute(query, P_region=file_type, P_year=toReplaceYear)
            else:
                cursor.execute(sql_file['outofdoor_delete_west_item'])
            query = sql_file['outofdoor_customer_maxid']
            max_ids = cursor.execute(query).fetchone()
            if max_ids[0] is not None:
                max_id = max_ids[0]
            else:
                max_id = 0
            max_id = int(max_id)
            for c_line in data:
                if 'CUSTOMER_ID' not in c_line:
                    max_id += 1
                    c_line['CUSTOMER_ID'] = max_id
                values = ""
                values = tuple(val for key, val in c_line.items())
                cus_data.append(values)
            query1 = sql_file['outofdoor_item_maxid']
            max_ids1 = cursor.execute(query1).fetchone()
            if max_ids1[0] is not None:
                max_id1 = max_ids1[0]
            else:
                max_id1 = 0
            for i_line in itm:
                if 'ITEM_ID' not in i_line:
                    max_id1 += 1
                    i_line['ITEM_ID'] = max_id1
                values = ""
                values = tuple(val for key, val in i_line.items())
                it_data.append(values)

            if data:
                dict_val = data[0]
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"

            if itm:
                dict_val = itm[0]
                item_field += "("
                indx_value = 1
                item_parameter += "("
                for key, value in dict_val.items():
                    item_field += str(key)+','
                    item_parameter += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                item_field = item_field[:-1]
                item_parameter = item_parameter[:-1]
                item_field += ")"
                item_parameter += ")"

            cursor.prepare("""insert into
            QPEX_OUTOFDOOR_CUSTOMERS """ + fieldname_strng+"""
            values""" + parameter_strng)
            cursor.executemany(None, cus_data)

            cursor.prepare("""insert into
            QPEX_OUTOFDOOR_ITEM """ + item_field+"""
            values""" + item_parameter)
            cursor.executemany(None, it_data)

            connection.commit()
        except Exception as error:
            logger.findaylog("""@ 159 EXCEPTION - models - outofdoor -
                 save_data """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - save_data(-)')
        return "success"

    @staticmethod
    def revenue_items(year, cust_no):
        logger.addinfo('@ models - outofdoor - revenue_items(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_revenue_items1']
            cursor.execute(query, p_year=year, p_year_1=year-1,
                           p_cust_no=cust_no)
        except Exception as error:
            logger.findaylog("""@ 276 EXCEPTION - models - outofdoor -
                 revenue_items """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - revenue_items(-)')
        return revenue_list

    def revenue_by_month(self, jsond):
        revenue_list = []
        kwargs = {'p_year': jsond['year']}
        with OracleConnectionManager() as conn:
            manager_filter = ''
            if jsond['manager_id'] is not None:
                manager_filter = self.sql_file['outofdoor_revenue_month_by_manager']
                kwargs['p_manager_no'] = '%-{0}-%'.format(jsond['manager_id'])
            query = self.sql_file['outofdoor_revenue_month']
            query = query.format(manager_filter=manager_filter)
            conn.execute(query, **kwargs)
            revenue_list = conn.get_result()
        return revenue_list

    @staticmethod
    def just_reading(file_name, file_type, replaceYear):
        logger.addinfo("@ models - outofdoor - reading(+)")
        try:
            b = xlrd.open_workbook(file_name)
            sheet = b.sheet_by_index(2)
            cols = []
            col_types = []
            var = sheet.nrows - 1
            for col in range(0, sheet.ncols):
                cols.append(sheet.cell_value(0, col))
                col_types.append(sheet.cell_type(var, col))
            data_list = []
            for rownum in range(1, sheet.nrows):
                data = OrderedDict()
                r = sheet.row_values(rownum)
                for i in range(0, len(cols)):
                    if col_types[i] == 3 and r[i] != '':
                        z = b.datemode
                        tmp_vak = datetime.datetime(*xlrd.xldate_as_tuple(r[i],
                                                                          z))
                        tmp_val = tmp_vak.strftime("%d/%m/%Y")
                        data[cols[i]] = tmp_val
                    else:
                        data[cols[i]] = r[i]
                data_list.append(data)
            tmp_data = ujson.dumps(data_list)
            os.remove(file_name)
            msg = Outofdoor.data_save(tmp_data, file_type, replaceYear)
        except Exception as error:
            logger.findaylog("""@ 340 EXCEPTION - models - outofdoor -
                 just_reading """ + str(error))
            raise error
        logger.addinfo("@ models - outofdoor - reading(-)")
        return msg

    @staticmethod
    def data_save(tmp_data, file_type, replaceYear):
        logger.addinfo('@ models - outofdoor - save_data(+)')
        customer_name_var = 'Customer Name'
        connection = None
        cursor = None
        fieldname_strng = ""
        parameter_strng = ""
        item_field = ""
        item_parameter = ""
        customer_data = []
        items_data = []
        tmp_data = ujson.loads(tmp_data)
        for i in tmp_data:
            cust_data = {}
            item_data = {}
            a, b, c = str(i['Ship Date']).split("/")
            month_name = get_monthname(int(b) - 1)
            item_data['CUST_NO'] = str(to_num(i['Account #']))
            item_data['ITEM_CODE'] = str(i['Item #'])
            item_data['DESCRIPTION'] = str(i['Description'])
            item_data['YEAR'] = str(int(c))
            item_data['NAME'] = str(i[customer_name_var])
            item_data['ST'] = str(i['State'])
            item_data['REGION'] = str(file_type)
            item_data['TM_NO'] = str(i['TM #'])
            item_data['TM_NAME'] = str(i['TM Name'])
            item_data['CITY'] = str(i['City'])
            if month_name == 'JAN':
                item_data['JAN_SALES'] = str(float(i['Total $\'s']))
                item_data['JAN_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 1
            else:
                item_data['JAN_SALES'] = ''
                item_data['JAN_QUANTITY'] = ''

            if month_name == 'FEB':
                item_data['FEB_SALES'] = str(float(i['Total $\'s']))
                item_data['FEB_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 2
            else:
                item_data['FEB_SALES'] = ''
                item_data['FEB_QUANTITY'] = ''

            if month_name == 'MAR':
                item_data['MAR_SALES'] = str(float(i['Total $\'s']))
                item_data['MAR_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 3
            else:
                item_data['MAR_SALES'] = ''
                item_data['MAR_QUANTITY'] = ''

            if month_name == 'APR':
                item_data['APR_SALES'] = str(float(i['Total $\'s']))
                item_data['APR_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 4
            else:
                item_data['APR_SALES'] = ''
                item_data['APR_QUANTITY'] = ''

            if month_name == 'MAY':
                item_data['MAY_SALES'] = str(float(i['Total $\'s']))
                item_data['MAY_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 5
            else:
                item_data['MAY_SALES'] = ''
                item_data['MAY_QUANTITY'] = ''

            if month_name == 'JUN':
                item_data['JUN_SALES'] = str(float(i['Total $\'s']))
                item_data['JUN_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 6
            else:
                item_data['JUN_SALES'] = ''
                item_data['JUN_QUANTITY'] = ''

            if month_name == 'JUL':
                item_data['JUL_SALES'] = str(float(i['Total $\'s']))
                item_data['JUL_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 7
            else:
                item_data['JUL_SALES'] = ''
                item_data['JUL_QUANTITY'] = ''

            if month_name == 'AUG':
                item_data['AUG_SALES'] = str(float(i['Total $\'s']))
                item_data['AUG_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 8
            else:
                item_data['AUG_SALES'] = ''
                item_data['AUG_QUANTITY'] = ''

            if month_name == 'SEP':
                item_data['SEP_SALES'] = str(float(i['Total $\'s']))
                item_data['SEP_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 9
            else:
                item_data['SEP_SALES'] = ''
                item_data['SEP_QUANTITY'] = ''

            if month_name == 'OCT':
                item_data['OCT_SALES'] = str(float(i['Total $\'s']))
                item_data['OCT_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 10
            else:
                item_data['OCT_SALES'] = ''
                item_data['OCT_QUANTITY'] = ''

            if month_name == 'NOV':
                item_data['NOV_SALES'] = str(float(i['Total $\'s']))
                item_data['NOV_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 11
            else:
                item_data['NOV_SALES'] = ''
                item_data['NOV_QUANTITY'] = ''

            if month_name == 'DEC':
                item_data['DEC_SALES'] = str(float(i['Total $\'s']))
                item_data['DEC_QUANTITY'] = str(float(i['QTY']))
                cust_data['MONTH'] = 12
            else:
                item_data['DEC_SALES'] = ''
                item_data['DEC_QUANTITY'] = ''

            item_data['MONTH'] = cust_data['MONTH']
            cust_data['CUST_NO'] = str(to_num(i['Account #']))
            cust_data['NAME'] = str(i[customer_name_var])
            cust_data['ADDRESS'] = str(i['Address'])
            cust_data['CITY'] = str(i['City'])
            cust_data['ST'] = str(i['State'])
            cust_data['ZIP'] = str(i['Zip'])
            cust_data['PHONE'] = str(i['Phone #'])
            cust_data['TM_NO'] = str(to_num(i['TM #']))
            cust_data['TM_NAME'] = str(i['TM Name'])
            cust_data['REGION'] = str(file_type)
            cust_data['YEAR'] = str(int(c))
            items_data.append(item_data)
            customer_data.append(cust_data)
        customer_data_unique = Outofdoor.get_unique_customers(customer_data)
        try:
            sql_file = db_util.getSqlData()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cus_data = []
            it_data = []
            if replaceYear != '' or replaceYear is not None:
                query = sql_file['outofdoor_delete_year_data']
                cursor.execute(query, P_region='east', P_year=replaceYear)
            else:
                cursor.execute(sql_file['outofdoor_delete_east_item'])
            query = sql_file['outofdoor_customer_maxid']
            max_ids = cursor.execute(query).fetchone()
            if max_ids[0] is not None:
                max_id = max_ids[0]
            else:
                max_id = 0
            max_id = int(max_id)
            for c_line in customer_data_unique:
                if 'CUSTOMER_ID' not in c_line:
                    max_id += 1
                    c_line['CUSTOMER_ID'] = max_id
                values = ""
                values = tuple(val for key, val in c_line.items())
                cus_data.append(values)
            query1 = sql_file['outofdoor_item_maxid']
            max_ids1 = cursor.execute(query1).fetchone()
            if max_ids1[0] is not None:
                max_id1 = max_ids1[0]
            else:
                max_id1 = 0
            for i_line in items_data:
                if 'ITEM_ID' not in i_line:
                    max_id1 += 1
                    i_line['ITEM_ID'] = max_id1
                values = ""
                values = tuple(val for key, val in i_line.items())
                it_data.append(values)
            if customer_data_unique:
                dict_val = customer_data_unique[0]
                fieldname_strng += "("
                indx_value = 1
                parameter_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    parameter_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                parameter_strng = parameter_strng[:-1]
                fieldname_strng += ")"
                parameter_strng += ")"
            if items_data:
                i_dict_val = items_data[0]
                item_field += "("
                idx_value = 1
                item_parameter += "("
                for key, value in i_dict_val.items():
                    item_field += str(key)+','
                    item_parameter += ":"+str(idx_value)+','
                    idx_value = idx_value+1
                item_field = item_field[:-1]
                item_parameter = item_parameter[:-1]
                item_field += ")"
                item_parameter += ")"

            cursor.prepare("""insert into
            QPEX_OUTOFDOOR_CUSTOMERS """ + fieldname_strng+"""
            values""" + parameter_strng)
            cursor.executemany(None, cus_data)

            cursor.prepare("""insert into
            QPEX_OUTOFDOOR_ITEM """ + item_field+"""
            values""" + item_parameter)
            cursor.executemany(None, it_data)
            connection.commit()
        except Exception as error:
            logger.findaylog("""@ 159 EXCEPTION - models - outofdoor -
                 data_save """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - data_save(-)')
        return "success"

    @staticmethod
    def get_unique_customers(data):
        logger.addinfo("@ models - outofdoor - get_unique_customers(+)")
        try:
            sql_file = db_util.getSqlData()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['outofdoor_new_customers']
            cursor.execute(query, P_region='east')
            cursor_data = cursor.fetchall()
            # sorting according to month and customer number
            list_customers = sorted(data, key=lambda customer: (
                customer['CUST_NO'], customer['MONTH']))
            list_unique_customers = []
            # unique customer
            check = set()
            for line in list_customers:
                copied_line = line.copy()
                copied_line.pop('MONTH')
                copied_line = tuple(copied_line.items())
                if copied_line not in check:
                    list_unique_customers.append(line)
                    check.add(copied_line)

            count = 0
            remove_lines = []
            new_data_add = list_unique_customers
            for line in list_unique_customers:
                for row in cursor_data:
                    count = 1
                    if row[1] == line['CUST_NO']:
                        remove_lines.append(line)
            if count == 0:
                lines = list_unique_customers
            else:
                for remline in remove_lines:
                    for index, item in enumerate(new_data_add):
                        if item['CUST_NO'] == remline['CUST_NO']:
                            break
                    else:
                        index = -1
                    if index != -1:
                        new_data_add.pop(index)
                lines = new_data_add
        except Exception as error:
            logger.findaylog("""@ 35 EXCEPTION - models - outofdoor -
                 get_unique_customers """ + str(error))
            raise error
        logger.addinfo("@ models - outofdoor - get_unique_customers(-)")
        return lines

    @staticmethod
    def revenue_customer(year, cust_no, state, is_phillips):
        logger.addinfo('@ models - outofdoor - revenue_customer(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if is_phillips:
                query = sql_file['outofdoor_customer_ph']
                cursor.execute(query, p_year=year, p_cust_no=cust_no)
            else:
                query = sql_file['outofdoor_customer']
                cursor.execute(query, p_year=year, p_cust_no=cust_no,
                               p_state=state)
        except Exception as error:
            logger.findaylog("""@ 473 EXCEPTION - models - outofdoor -
                 revenue_customer """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - revenue_customer(-)')
        return revenue_list

    @staticmethod
    def revenue_agent_by_state(year, state):
        logger.addinfo('@ models - outofdoor - revenue_agent_by_state(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_agents_by_state']
            cursor.execute(query, p_year=year, p_state=state)
        except Exception as error:
            logger.findaylog("""@ 473 EXCEPTION - models - outofdoor -
                 revenue_agent_by_state """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - revenue_agent_by_state(-)')
        return revenue_list

    def get_customers(self, manager_id, is_phillips):
        customer_list = []
        with OracleConnectionManager() as conn:
            if is_phillips:
                query = self.sql_file['out_of_door_customers_ph']
                conn.execute(query)
            elif manager_id is None:
                query = self.sql_file['out_of_door_customers']
                conn.execute(query)
            else:
                query = self.sql_file['outofdoor_customers_by_salesmanagers']
                conn.execute(query, p_manager_no=self.manager_no.format(manager_id))
            customer_list = conn.get_result()
        return customer_list

    @staticmethod
    def revenue_by_month_region(region):
        logger.addinfo('@ models - outofdoor - revenue_by_month_region(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['out_of_door_month_region']
            cursor.execute(query, p_region=region)
        except Exception as error:
            logger.findaylog("""@ 538 EXCEPTION - models - outofdoor -
                 revenue_by_month_region """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                    setattr(revenue, fn, row[index])
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - revenue_by_month_region(-)')
        return revenue_list

    @staticmethod
    def update(val_list):
        logger.addinfo('@ models - outofdoor - update(+)')
        cur = None
        con = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            for line in val_list:
                sql_data = "update qpex_outofdoor_customers set "
                for key, value in line.items():
                    if key == 'address':
                        address = str(value)
                    if key == 'city':
                        city = str(value)
                    if key == 'zip':
                        zip = str(value)
                    sql_data += str(key)+"="
                    sql_data += "'"
                    sql_data += str(value)
                    sql_data += "'"
                    sql_data += ","
                sql_data = sql_data[:-1]
                sql_data += " where address ="
                sql_data += "'" + address + "'"
                sql_data += " and city ="
                sql_data += "'" + city + "'"
                sql_data += " and zip ="
                sql_data += "'" + zip + "'"
                cur.execute(sql_data)
                sql_data = ""
        except Exception as error:
            logger.findaylog("""@ 805 EXCEPTION - models - outofdoor -
                 update """ + str(error))
            db_util.release_connection(con)
            raise error
        finally:
            cur.close()
            con.commit()
            db_util.release_connection(con)
        logger.addinfo('@ models - outofdoor - update(-)')
        return 'success'

    @staticmethod
    def update_empty_agents():
        logger.addinfo('@ models - outofdoor - update(+)')
        cur = None
        con = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_item_table_update_agent']
            cur.execute(query)
            query = sql_file['outofdoor_customer_table_update_agent']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 805 EXCEPTION - models - outofdoor -
                 update """ + str(error))
            db_util.release_connection(con)
            raise error
        finally:
            cur.close()
            con.commit()
            db_util.release_connection(con)
        logger.addinfo('@ models - outofdoor - update(-)')
        return 'success'

    @staticmethod
    def get_agents():
        logger.addinfo('@ models - outofdoor - get_agents(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_agents_query']
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1676 EXCEPTION - models - outofdoor -
                 get_agents """ + str(error))
            raise error
        else:
            items_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                item = {}
                for index, field in enumerate(field_names):
                    item[field] = row[index]
                items_list.append(item)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - outofdoor - get_agents(-)')
        return items_list

    @staticmethod
    def get_customer_revenue(agent_name, year, manager, is_phillips):
        logger.addinfo('@ models - outofdoor - get_customer_revenue(+)')
        con = None
        cur = None
        agents = []
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            if manager:
                agents = Outofdoor.get_agents_for_manager(manager)
            else:
                agents = [{'tm_name': agent_name}]
            if len(agents):
                query = sql_file['outofdoor_customer_revenue']
                if is_phillips:
                    query = sql_file['outofdoor_customer_revenue_ph']
                query = query % (',' . join([str("'" + agents[i]['tm_name'] +
                                                 "'") for i in range(len(agents))]))
                cur.execute(query, p_year=year)
        except Exception as error:
            logger.findaylog("""@ 1705 EXCEPTION - models - outofdoor -
                 get_customer_revenue """ + str(error))
            raise error
        else:
            items_list = []
            if len(agents) > 0:
                field_names = [a[0].lower() for a in cur.description]
                for row in cur:
                    item = {}
                    for index, field in enumerate(field_names):
                        item[field] = row[index]
                    items_list.append(item)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - outofdoor - get_customer_revenue(-)')
        return items_list

    @staticmethod
    def get_agent_revenue(year, userid):
        logger.addinfo('@ models - outofdoor - get_agent_revenue(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            if userid is None:
                query = sql_file['outofdoor_agents_revenue']
                cur.execute(query, p_year=year)
            elif userid == '-1':
                query = sql_file['outofdoor_unassigned_agents_revenue']
                cur.execute(query, p_year=year)
            else:
                agentsquery = sql_file['outofdoor_get_agents_for_manager']
                cursor = con.cursor()
                cursor.execute(agentsquery, p_manager_no=userid)
                agents = list(cursor)
                cursor.close()
                if len(agents) > 0:
                    query1_sum = sql_file[
                        'outofdoor_agent_revenue_query1_sum']
                    for i in range(0, len(agents)):
                        if agents[i][0] is not None:
                            query1_sum += "'" + agents[i][0] + "',"
                    query1_sum = query1_sum[:-1]
                    query1_sum += ")"
                    query2_group = sql_file[
                        'outofdoor_agent_revenue_query2_group']
                    query = query1_sum+query2_group
                    cur.execute(query, p_year=year)
        except Exception as error:
            logger.findaylog("""@ 1705 EXCEPTION - models - outofdoor -
                 get_agent_revenue """ + str(error))
            raise error
        else:
            items_list = []
            if cur.rowcount > 0:
                field_names = [a[0].lower() for a in cur.description]
                for row in cur:
                    item = {}
                    for index, field in enumerate(field_names):
                        item[field] = row[index]
                    items_list.append(item)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - outofdoor - get_agent_revenue(-)')
        return items_list

    @staticmethod
    def new_customers(xlsx_customer_data):
        logger.addinfo("@ models - outofdoor - new_customers(+)")
        connection = None
        cursor = None
        data = ujson.loads(xlsx_customer_data)
        lines = []
        try:
            sql_file = db_util.getSqlData()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['outofdoor_new_customers']
            cursor.execute(query, P_region='west')
            cursor_data = cursor.fetchall()
        except Exception as error:
            logger.findaylog("""@ 361 EXCEPTION - models - outofdoor -
                 new_customers """ + str(error))
            raise error
        else:
            count = 0
            remove_lines = []
            new_data_add = data
            for line in data:
                for row in cursor_data:
                    count = 1
                    if (row[0] == line['NAME'] and
                            row[1] == line['CUST_NO'] and
                            row[2] == line['ID']):
                        remove_lines.append(line)

            if count == 0:
                lines = data
            else:
                for remline in remove_lines:
                    for index, item in enumerate(new_data_add):
                        if (item['NAME'] == remline['NAME'] and
                                item['CUST_NO'] == remline['CUST_NO'] and
                                item['ID'] == remline['ID']):
                            break
                    else:
                        index = -1
                    if index != -1:
                        new_data_add.pop(index)
                lines = new_data_add
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - new_customers(-)')
        return lines

    @staticmethod
    def get_revenue_cust(year, cust, is_phillips):
        logger.addinfo('@ models - outofdoor - get_revenue_cust(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_customer_revenue_query']
            if is_phillips:
                query = sql_file['outofdoor_customer_revenue_ph_query']
            cursor.execute(query, p_year=str(year), p_cust_no=str(cust))
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 get_revenue_cust """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_revenue_cust(-)')
        return revenue_list

    def get_revenue_gap(self, cust, is_phillips):
        """
        Fetch items based on the customer in USA outofdoor
        """
        revenue_list = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['outofdoor_customer_gap_items']
            if is_phillips:
                query = self.sql_file['outofdoor_customer_gap_items_ph']
            conn.execute(query, p_cust_no=cust)
            revenue_list = conn.get_result()
        return revenue_list

    @staticmethod
    def agents_without_manager():
        logger.addinfo('@ models - outofdoor - agents_without_manager(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_agents_without_manager']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 agents_without_manager """ + str(error))
            raise error
        else:
            agent_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                agent_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - agents_without_manager(-)')
        return agent_list

    @staticmethod
    def manager_update(managers):
        logger.addinfo('@ models - outofdoor - manager_update(+)')
        connection = None
        cursor = None
        try:
            for manager in managers:
                connection = db_util.get_connection()
                cursor = connection.cursor()
                sql_file = db_util.getSqlData()
                query = sql_file['outofdoor_managers_update']
                cursor.execute(query, p_manager_name=manager['manager_name'],
                               p_manager_no=manager['manager_no'],
                               p_tm_name=manager['tm_name'])
                connection.commit()
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 manager_update """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - manager_update(-)')
        return "success"

    @staticmethod
    def save_agents_data():
        logger.addinfo("@ models = outofdoor - save_agents_data(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_agents_query']
            cursor.execute(query)
            distinct_agents = list(cursor.fetchall())
            query = sql_file['outofdoor_agents_query']
            cursor.execute(query)
            outofdoor_agents = list(cursor.fetchall())
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 get_revenue_gap """ + str(error))
            raise error
        else:
            result = list(set(distinct_agents) - set(outofdoor_agents))
            if len(result) > 0:
                for i in range(0, len(result)):
                    if result[i][0] is not None:
                        query = sql_file['outofdoor_agents_sequence']
                        agents_query = sql_file['outofdoor_add_agents']
                        data = cursor.execute(query).fetchone()
                        agents_query += "'" + result[i][0] + "',"
                        agents_query += str(data[0]) + ')'
                        cursor.execute(agents_query)
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_revenue_gap(-)')
        return "success"

    @staticmethod
    def get_agents_for_manager(id):
        logger.addinfo('@ models - outofdoor - get_agents_for_manager(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_get_agents_for_manager']
            cursor.execute(query, p_manager_no=id)
            agents = cursor.fetchall()
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 get_agents_for_manager """ + str(error))
            raise error
        else:
            agent_list = []
            for row in agents:
                agentObj = {}
                agentObj['tm_name'] = row[0]
                agent_list.append(agentObj)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_agents_for_manager(-)')
        return agent_list

    @staticmethod
    def revenue_by_agents(year, agent):
        logger.addinfo('@ models - outofdoor - revenue_by_agents(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_revenue_agents']
            cursor.execute(query, p_year=year, p_tm_name=agent)
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 revenue_by_agents """ + str(error))
            raise error
        else:
            agent_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                agent_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - revenue_by_agents(-)')
        return agent_list

    @staticmethod
    def get_new_customer(month, year, agent, manager):
        logger.addinfo('@ models - outofdoor - get_new_customer(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if len(str(month)) < 2:
                month = '0' + str(month)
            if agent is None:
                if manager is None:
                    query = sql_file['outofdoor_newly_added_customers']
                    cursor.execute(query, p_year=year, p_month=month)
                else:
                    agentsquery = sql_file['outofdoor_get_agents_for_manager']
                    cur = connection.cursor()
                    cur.execute(agentsquery, p_manager_no=manager)
                    agents = list(cur)
                    cur.close()
                    if len(agents):
                        q = sql_file['outofdoor_new_customers_manager_agent']
                        q = q % (',' . join([str("'" + agents[i][0] + "'")
                                             for i in range(len(agents))]))
                        cursor.execute(q, p_year=year, p_month=month,
                                       p_manager_no=manager)
                    else:
                        query = sql_file['outofdoor_new_customers_manager']
                        cursor.execute(query, p_year=year, p_month=month,
                                       p_manager_no=manager)
            else:
                query = sql_file['outofdoor_newly_added_customers_byagent']
                cursor.execute(query, p_year=year, p_month=month,
                               p_tm_name=agent)
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 get_new_customer """ + str(error))
            raise error
        else:
            customer_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                customer_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_new_customer(-)')
        return customer_list

    @staticmethod
    def manager_remove(agents):
        logger.addinfo('@ models - outofdoor - manager_remove(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_remove_manager']
            for agent in agents:
                query += "'" + agent['id'] + "',"
            query = query[:-1]
            query += ")"
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 manager_update """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - outofdoor - manager_update(-)')
        return "success"

    @staticmethod
    def get_agents_by_managers(id):
        logger.addinfo('@ models - outofdoor - get_agents_by_managers(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_get_agents_for_manager']
            cursor.execute(query, p_manager_no=id)
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 get_agents_by_managers """ + str(error))
            raise error
        else:
            agent_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                agent_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_agents_by_managers(-)')
        return agent_list

    @staticmethod
    def get_items_salesmanagers(year, id):
        logger.addinfo('@ models - outofdoor - get_revenue_gap(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if id is None:
                query = sql_file['outofdoor_agents_revenue']
                cursor.execute(query, p_year=year)
            else:
                agentsquery = sql_file['outofdoor_get_agents_for_manager']
                cur = connection.cursor()
                cur.execute(agentsquery, p_manager_no=id)
                agents = list(cur)
                cur.close()
                if len(agents) > 0:
                    query1_sum = sql_file[
                        'outofdoor_items_revenue_salesmanager']
                    for i in range(0, len(agents)):
                        if agents[i][0] is not None:
                            query1_sum += "'" + agents[i][0] + "',"
                    query1_sum = query1_sum[:-1]
                    query2_group = sql_file[
                        'outofdoor_items_revenue_salesmanager_group']
                    query = query1_sum+query2_group
                    cursor.execute(query, p_year=year)
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 get_revenue_gap """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_revenue_gap(-)')
        return revenue_list

    def get_customers_salesmanagers(self, jsond):
        revenue_list = []
        kwargs = {'p_year': jsond['year'],
                  'p_cust_no': jsond['cust_no'],
                  'p_state': jsond['state']}
        manager_filter = ''
        distributor_filter = ''
        with OracleConnectionManager() as conn:
            if jsond.get('distributor'):
                distributor_filter = self.sql_file['outofdoor_revenue_month_by_distributor']
                kwargs['p_distributor'] = jsond['distributor']
            if jsond.get('manager_id'):
                manager_filter = self.sql_file['outofdoor_revenue_month_by_manager']
                kwargs['p_manager_no'] = self.manager_no.format(jsond['manager_id'])
            query = self.sql_file['outofdoor_customer']
            query = query.format(manager_filter=manager_filter,
                                 distributor_filter=distributor_filter)

            conn.execute(query, **kwargs)
            revenue_list = conn.get_result()
        return revenue_list

    def get_state_salesmanagers(self, year, manager_id, state):
        revenue_state_list = []
        with OracleConnectionManager() as conn:
            kwargs = {'p_year': year, 'p_st': state}
            manager_filter = ''
            query = self.sql_file['outofdoor_revenue_states1']
            if manager_id is not None:
                manager_filter = self.sql_file['outofdoor_revenue_month_by_manager']
                kwargs['p_manager_no'] = self.manager_no.format(manager_id)
            query = query.format(manager_filter=manager_filter)
            conn.execute(query, **kwargs)
            revenue_state_list = conn.get_result()
        return revenue_state_list

    @staticmethod
    def get_managers():
        logger.addinfo('@ models - outofdoor - get_managers(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_managers_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1663 EXCEPTION - models - outofdoor -
                 get_managers """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_managers(-)')
        return revenue_list

    @staticmethod
    def get_managers_revenue(year):
        logger.addinfo('@ models - outofdoor - get_managers_revenue(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoot_managers_revenue_query']
            cursor.execute(query, p_year=year)
        except Exception as error:
            logger.findaylog("""@ 1692 EXCEPTION - models - outofdoor -
                 get_managers_revenue """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_managers_revenue(-)')
        return revenue_list

    @staticmethod
    def get_customers_by_managers(id):
        logger.addinfo('@ models - outofdoor - get_customers_by_managers(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_customers_manager']
            cursor.execute(query, p_manager_no=id)
        except Exception as error:
            logger.findaylog("""@ 1727 EXCEPTION - models - outofdoor -
                 get_customers_by_managers """ + str(error))
            raise error
        else:
            customer_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                customer = {}
                for index, fn in enumerate(fieldnames):
                    customer[fn] = row[index]
                customer_list.append(customer)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_customers_by_managers(-)')
        return customer_list

    @staticmethod
    def update_manager_customers(managers):
        logger.addinfo('@ models - outofdoor - update_manager_customers(+)')
        connection = None
        cursor = None
        try:
            for manager in managers:
                connection = db_util.get_connection()
                cursor = connection.cursor()
                sql_file = db_util.getSqlData()
                query = sql_file['outofdoor_manager_customers_update']
                cursor.execute(query, p_manager_name=manager['manager_name'],
                               p_manager_no=manager['manager_no'],
                               p_cust_no=manager['cust_no'])
                connection.commit()
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 update_manager_customers """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - update_manager_customers(-)')
        return "success"

    @staticmethod
    def remove_manager_customers(customers):
        logger.addinfo('@ models - outofdoor - remove_manager_customers(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_remove_manager_customers']
            for customer in customers:
                query += "'" + customer['cust_no'] + "',"
            query = query[:-1]
            query += ")"
            cur.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1034 EXCEPTION - models - outofdoor -
                 remove_manager_customers """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - outofdoor - remove_manager_customers(-)')
        return "success"

    @staticmethod
    def revenue_items_state(jsond):
        logger.addinfo('@ models - outofdoor - revenue_items_state(+)')
        connection = None
        cursor = None
        results = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_items_bystate']
            cursor.execute(query, p_from=jsond['from'], p_to=jsond['to'],
                           p_state=jsond['state'])
        except Exception as error:
            logger.findaylog("""@ 1809 EXCEPTION - models - outofdoor -
                 revenue_items_state """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                data = {}
                for index, fn in enumerate(fieldnames):
                    data[fn] = row[index]
                results.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - revenue_items_state(-)')
        return results

    def canada_writing(self, jsond):
        try:
            decoded = base64.b64decode(jsond['file_data'])
            file_name = Outofdoor.id_generator()
            tmp_f_name = self.tmp_folder + file_name + '.xls'
            text_file = open(tmp_f_name, 'w')
            text_file.write(decoded)
            text_file.close()
            tmp_data = Outofdoor.read_file(tmp_f_name, jsond['date'],
                                           jsond['org_id'])
            os.remove(tmp_f_name)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - outofdoor -
                 canada_writing """ + str(error))
            raise error
        return tmp_data

    @staticmethod
    def petlink_reading(file_name, date, org_id):
        logger.addinfo("@ models - outofdoor - petlink_reading(+)")
        try:
            b = xlrd.open_workbook(file_name)
            sheet = b.sheet_by_index(1)
            cols = []
            col_types = []
            var = sheet.nrows - 1
            for col in range(0, sheet.ncols):
                cols.append(sheet.cell_value(0, col))
                col_types.append(sheet.cell_type(var, col))
            for i in range(0, len(cols)):
                cols[i] = cols[i].replace(" ", "_")
            data_list = []
            for rownum in range(1, sheet.nrows):
                data = OrderedDict()
                r = sheet.row_values(rownum)
                for i in range(0, len(cols)):
                    data[cols[i]] = r[i]
                data_list.append(data)
        except Exception as error:
            logger.findaylog("""@ 1874 EXCEPTION - models - outofdoor -
                 petlink_reading """ + str(error))
            raise error
        logger.addinfo("@ models - outofdoor - reading(-)")
        data_save = Outofdoor.petlink_save(data_list, date, org_id)
        return data_save

    @staticmethod
    def petlink_save(jsond, date, org_id):
        logger.addinfo('@ models - outofdoor - petlink_save(+)')
        connection = None
        cursor = None
        a = date.split('/')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cur = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['petslink_delete_query']
            cur.execute(query, p_day=1, p_month=a[0], p_year=a[1],
                        p_manager='PETSLINK')
            cur.close()
            data = []
            sql_data = 'insert into qpex_outofdoor_data ('
            for line in jsond:
                line['QUANTITY'] = int(line['Eaches'])
                del line['Eaches']
                line['DESCRIPTION'] = line['Product_Description']
                del line['Product_Description']
                line['CUSTOMER_NAME'] = line['Store_Name']
                del line['Store_Name']
                line['ITEM_CODE'] = line['UPC_Code']
                del line['UPC_Code']
                line['AMOUNT'] = line['Pet_Planet_Cost']
                del line['Pet_Planet_Cost']
                line['TOTAL_SALES'] = line['Total']
                del line['Total']
                line['DAY'] = 1
                line['MONTH'] = a[0]
                line['YEAR'] = a[1]
                line['ORG_ID'] = org_id
                line['MANAGER_NAME'] = 'PETSLINK'
                del line['Vendor']
                my_data = []
                for key, value in line.items():
                    my_data.append(value)
                    new_record = tuple(my_data)
                data.append(new_record)
            for key, value in line.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(line.items()):
                sql_args += ":"+str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            cursor.executemany(sql_data, data)
        except Exception as error:
            logger.findaylog("""@ 1911 EXCEPTION - models - outofdoor -
                 petlink_save """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - petlink_save(-)')
        return "success"

    @staticmethod
    def anipet_reading(file_name, date, org):
        logger.addinfo("@ models - outofdoor - anipet_reading(+)")
        try:
            b = xlrd.open_workbook(file_name)
            sheet = b.sheet_by_index(0)
            cols = []
            col_types = []
            var = sheet.nrows - 1
            for col in range(0, sheet.ncols):
                cols.append(sheet.cell_value(0, col))
                col_types.append(sheet.cell_type(var, col))
            for i in range(0, len(cols)):
                cols[i] = cols[i].replace(" ", "_")
            data_list = []
            for rownum in range(1, sheet.nrows):
                data = OrderedDict()
                r = sheet.row_values(rownum)
                for i in range(0, len(cols)):
                    data[cols[i]] = r[i]
                data_list.append(data)
        except Exception as error:
            logger.findaylog("""@ 1874 EXCEPTION - models - outofdoor -
                 anipet_reading """ + str(error))
            raise error
        logger.addinfo("@ models - outofdoor - anipet_reading(-)")
        data_save = Outofdoor.anipet_save(data_list, date, org)
        return data_save

    @staticmethod
    def anipet_save(jsond, date, org_id):
        logger.addinfo('@ models - outofdoor - petlink_save(+)')
        connection = None
        cursor = None
        a = date.split('/')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cur = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['petslink_delete_query']
            cur.execute(query, p_day=1, p_month=a[0], p_year=a[1],
                        p_manager='ANIPET')
            cur.close()
            data = []
            sql_data = 'insert into qpex_outofdoor_data ('
            for line in jsond:
                line['SALESREP_NO'] = line['Salesperson_Code']
                del line['Salesperson_Code']
                line['SALES_PERSON'] = line['Salesperson_Name']
                del line['Salesperson_Name']
                line['CUST_NO'] = str(line['Customer_No.'])
                del line['Customer_No.']
                line['CUSTOMER_NAME'] = line['Name']
                del line['Name']
                line['ITEM_CODE'] = str(line['Item_No.'])
                del line['Item_No.']
                line['DESCRIPTION'] = line['Description']
                del line['Description']
                line['QUANTITY'] = line['Invoiced_Quantity']
                del line['Invoiced_Quantity']
                line['UOM'] = line['Base_Unit_of_Measure']
                del line['Base_Unit_of_Measure']
                line['TOTAL_SALES'] = line['Sales_Amount_(Actual)']
                del line['Sales_Amount_(Actual)']
                line['DISCOUNT'] = line['Discount_Amount']
                del line['Discount_Amount']
                line['DAY'] = 1
                line['MONTH'] = a[0]
                line['YEAR'] = a[1]
                line['ORG_ID'] = org_id
                line['MANAGER_NAME'] = 'ANIPET'
                my_data = []
                for key, value in line.items():
                    my_data.append(value)
                    new_record = tuple(my_data)
                data.append(new_record)
            for key, value in line.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(line.items()):
                sql_args += ":"+str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            cursor.executemany(sql_data, data)
        except Exception as error:
            logger.findaylog("""@ 2031 EXCEPTION - models - outofdoor -
                 petlink_save """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - petlink_save(-)')
        return "success"

    @staticmethod
    def gastronome_reading(file_name, org_id):
        logger.addinfo("@ models - outofdoor - gastronome_reading(+)")
        try:
            b = xlrd.open_workbook(file_name)
            sheet = b.sheet_by_index(0)
            cols = []
            col_types = []
            var = sheet.nrows - 5
            for col in range(0, sheet.ncols):
                cols.append(sheet.cell_value(0, col))
                col_types.append(sheet.cell_type(var, col))
            for i in range(0, len(cols)):
                cols[i] = cols[i].replace(" ", "_")
            data_list = []
            for rownum in range(1, sheet.nrows-2):
                data = OrderedDict()
                r = sheet.row_values(rownum)
                for i in range(0, len(cols)):
                    if col_types[i] == 3 and r[i] != '':
                        z = b.datemode
                        tmp_vak = datetime.datetime(*xlrd.xldate_as_tuple(r[i],
                                                                          z))
                        tmp_val = tmp_vak.strftime("%d/%m/%Y")
                        data[cols[i]] = tmp_val
                    else:
                        data[cols[i]] = r[i]
                data_list.append(data)
        except Exception as error:
            logger.findaylog("""@ 2082 EXCEPTION - models - outofdoor -
                 gastronome_reading """ + str(error))
            raise error
        logger.addinfo("@ models - outofdoor - gastronome_reading(-)")
        data_save = Outofdoor.gastronome_save(data_list, org_id)
        return data_save

    @staticmethod
    def gastronome_save(jsond, org_id):
        logger.addinfo('@ models - outofdoor - petlink_save(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            invoice_dates = []
            data = []
            sql_data = 'insert into qpex_outofdoor_data ('
            for line in jsond:
                invoice_dates.append(line['InDate'])
                line['CUST_NO'] = line['StoreId']
                del line['StoreId']
                line['ITEM_CODE'] = line['SkuNumber']
                del line['SkuNumber']
                line['ZIP_CODE'] = line['InPostalCode']
                del line['InPostalCode']
                line['UOM'] = line['UOM']
                del line['UOM']
                line['SHIP_TO_NAME'] = line['SHIPname']
                del line['SHIPname']
                line['DESCRIPTION'] = line['Description']
                del line['Description']
                line['SHIP_TO_ZIP'] = line['SHIPpostalCode']
                del line['SHIPpostalCode']
                line['CUSTOMER_NAME'] = line['StoreName']
                del line['StoreName']
                line['PZ_QUANTITY'] = int(line['UOMCnt'])
                del line['UOMCnt']
                tmp_date = line['InDate'].split('/')
                line['DAY'] = int(tmp_date[0])
                line['MONTH'] = int(tmp_date[1])
                line['YEAR'] = int(tmp_date[2])
                line['ADDRESS'] = line['InAddress']
                del line['InAddress']
                line['SHIP_TO_CITY'] = line['SHIPcity']
                del line['SHIPcity']
                line['PHONE'] = str(line['InPhoneNumber1'])
                del line['InPhoneNumber1']
                line['QUANTITY'] = int(line['Qty'])
                del line['Qty']
                line['TOTAL_SALES'] = float(line['TotalSales'])
                del line['TotalSales']
                line['CITY'] = line['InCity']
                del line['InCity']
                line['SHIP_TO_ADDR'] = line['SHIPaddress']
                del line['SHIPaddress']
                del line['InName']
                del line['PrSequence']
                del line['InInvoiceNumber']
                del line['InDate']
                del line['SHIPcareOf']
                del line['TranDt']
                line['ORG_ID'] = org_id
                line['MANAGER_NAME'] = 'GASTRONOME'
                my_data = []
                for key, value in line.items():
                    my_data.append(value)
                    new_record = tuple(my_data)
                data.append(new_record)
            invoice_dates = list(set(invoice_dates))
            for i in range(0, len(invoice_dates)):
                tmp = invoice_dates[i].split("/")
                cur = connection.cursor()
                sql_file = db_util.getSqlData()
                query = sql_file['petslink_delete_query']
                cur.execute(query, p_day=tmp[0], p_month=tmp[1], p_year=tmp[2],
                            p_manager='GASTRONOME')
                cur.close()
            for key, value in line.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(line.items()):
                sql_args += ":"+str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            cursor.executemany(sql_data, data)
        except Exception as error:
            logger.findaylog("""@ 1911 EXCEPTION - models - outofdoor -
                 petlink_save """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - petlink_save(-)')
        return "success"

    @staticmethod
    def freedom_reading(file_name, date, org_id):
        logger.addinfo("@ models - outofdoor - gastronome_reading(+)")
        try:
            b = xlrd.open_workbook(file_name)
            sheet = b.sheet_by_index(0)
            data_list = []
            data = []
            for rownum in range(1, sheet.nrows):
                r = sheet.row_values(rownum)
                if r[0] == 'CUSTOMER TOTAL':
                    data_list.append(data)
                    data = []
                else:
                    data.append(r)
        except Exception as error:
            logger.findaylog("""@ 2082 EXCEPTION - models - outofdoor -
                 gastronome_reading """ + str(error))
            raise error
        tmp_list = []
        for i in range(0, len(data_list)):
            customer_name = ''
            ship_to = ''
            for j in range(0, len(data_list[i])):
                dict = {}
                if j == 0:
                    customer_name = data_list[i][j][0]
                elif j == 1:
                    ship_to = data_list[i][j][0]
                else:
                    if "SHIP TO:" in data_list[i][j][0]:
                        ship_to = data_list[i][j][0]
                    elif data_list[i][j][0] == "SHIP TO TOTAL":
                        pass
                    else:
                        dict['ITEM_CODE'] = data_list[i][j][0]
                        dict['DESCRIPTION'] = data_list[i][j][1]
                        dict['QTY'] = data_list[i][j][2]
                        dict['PRICE'] = data_list[i][j][3]
                dict['CUSTOMER_NAME'] = customer_name
                dict['SHIP_TO'] = ship_to
                tmp_list.append(dict)
        final_list = []
        for i in range(0, len(tmp_list)):
            if len(tmp_list[i]) != 2:
                final_list.append(tmp_list[i])
        logger.addinfo("@ models - outofdoor - gastronome_reading(-)")
        data_save = Outofdoor.freedom_save(final_list, date, org_id)
        return data_save

    @staticmethod
    def freedom_save(jsond, date, org_id):
        logger.addinfo('@ models - outofdoor - petlink_save(+)')
        connection = None
        cursor = None
        a = date.split('/')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cur = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['petslink_delete_query']
            cur.execute(query, p_day=1, p_month=a[0], p_year=a[1],
                        p_manager='FREEDOM')
            cur.close()
            data = []
            sql_data = 'insert into qpex_outofdoor_data ('
            for line in jsond:
                line['QUANTITY'] = int(line['QTY'])
                del line['QTY']
                line['AMOUNT'] = line['PRICE']
                del line['PRICE']
                line['TOTAL_SALES'] = line['QUANTITY'] * line['AMOUNT']
                line['SHIP_TO_ADDR'] = line['SHIP_TO'].replace("SHIP TO: ", '')
                del line['SHIP_TO']
                line['DAY'] = 1
                line['MONTH'] = a[0]
                line['YEAR'] = a[1]
                line['ORG_ID'] = org_id
                line['MANAGER_NAME'] = 'FREEDOM'
                my_data = []
                for key, value in line.items():
                    my_data.append(value)
                    new_record = tuple(my_data)
                data.append(new_record)
            for key, value in line.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(line.items()):
                sql_args += ":"+str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            cursor.executemany(sql_data, data)
        except Exception as error:
            logger.findaylog("""@ 2302 EXCEPTION - models - outofdoor -
                 petlink_save """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - petlink_save(-)')
        return "success"

    @staticmethod
    def get_types():
        logger.addinfo('@ models - outofdoor - get_types(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['canada_types_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 2305 EXCEPTION - models - outofdoor -
                 get_types """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_types(-)')
        return revenue_list

    @staticmethod
    def outcanada_revenue_by_month(jsond):
        logger.addinfo('@ models - outofdoor - outcanada_revenue_by_month(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outcanada_revenue_by_month']
            cursor.execute(query, p_year=jsond['year'],
                           p_customer_name=jsond['customer'],
                           p_manager_name=jsond.get('manager_name'),
                           p_manager_reference_as=jsond.get('manager_reference_as'))
        except Exception as error:
            logger.findaylog("""@ 306 EXCEPTION - models - outofdoor -
                 outcanada_revenue_by_month """ + str(error))
            raise error
        else:
            month_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                month_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - outcanada_revenue_by_month(-)')
        return month_list

    @staticmethod
    def outcanada_revenue_by_customer(jsond):
        logger.addinfo("""@ models - outofdoor -
                       outcanada_revenue_by_customer(+)""")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outcanada_revenue_by_customer']
            if jsond.get('manager_reference_as') == 'chain_store':
                chain_store_details = sql_file['get_chain_store_details']
                query = query.format(chain_store_details)
            query = query.format('')
            cursor.execute(query, p_year=jsond['year'], p_month=jsond['month'],
                           p_manager_reference_as=jsond.get('manager_reference_as'),
                           p_manager_name=jsond.get('manager_name'))
        except Exception as error:
            logger.findaylog("""@ 306 EXCEPTION - models - outofdoor -
                 outcanada_revenue_by_customer """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("""@ models - outofdoor -
                       outcanada_revenue_by_customer(-)""")
        return revenue_list

    @staticmethod
    def outcanada_revenue_by_items(jsond):
        logger.addinfo("""@ models - outofdoor -
                       outcanada_revenue_by_items(+)""")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outcanada_revenue_by_items']
            if jsond.get('manager_reference_as') == 'chain_store':
                chain_store_qry = sql_file['get_chain_store_details']
                query = query.format(chain_store_qry)
            query = query.format('')
            cursor.execute(query, p_year=jsond['year'], p_month=jsond['month'],
                           p_customer_name=jsond['customer'],
                           p_manager_reference_as=jsond.get('manager_reference_as'),
                           p_manager_name=jsond.get('manager_name'))
        except Exception as error:
            logger.findaylog("""@ 306 EXCEPTION - models - outofdoor -
                 outcanada_revenue_by_items """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("""@ models - outofdoor -
                       outcanada_revenue_by_items(-)""")
        return revenue_list

    @staticmethod
    def outcanada_customers_list():
        logger.addinfo("""@ models - outofdoor -
                       outcanada_customers_list(+)""")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outcanada_customers']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 306 EXCEPTION - models - outofdoor -
                 outcanada_customers_list """ + str(error))
            raise error
        else:
            customers = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                customers.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("""@ models - outofdoor -
                       outcanada_customers_list(-)""")
        return customers

    @staticmethod
    def outcanada_revenue_by_manager(jsond, customers):
        logger.addinfo("""@ models - outofdoor -
                       outcanada_revenue_by_manager(+)""")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if customers == 'customers':
                # to get revenue of customer by manager
                query = sql_file['outcanada_revenue_by_manager_customer']
                cursor.execute(query, p_year=jsond['year'],
                               p_month=jsond['month'],
                               p_manager_name=jsond['manager'])
            else:
                # to get revenue of managers
                query = sql_file['outcanada_revenue_by_manager']
                cursor.execute(query, p_year=jsond['year'],
                               p_month=jsond['month'],
                               p_manager_name=jsond['manager'],
                               p_manager_no=jsond['manager_no'],
                               p_manager_reference_as=jsond.get('manager_reference_as'))
        except Exception as error:
            logger.findaylog("""@ 306 EXCEPTION - models - outofdoor -
                 outcanada_revenue_by_manager """ + str(error))
            raise error
        else:
            revenue_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("""@ models - outofdoor -
                       outcanada_revenue_by_manager(-)""")
        return revenue_list

    @staticmethod
    def outcanada_revenue_by_month_manager(year, manager):
        logger.addinfo(
            '@ models - outofdoor - outcanada_revenue_by_month_manager(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outcanada_revenue_by_month_manager']
            cursor.execute(query, p_year=year, p_manager_name=manager)
        except Exception as error:
            logger.findaylog("""@ 306 EXCEPTION - models - outofdoor -
                 outcanada_revenue_by_month_manager """ + str(error))
            raise error
        else:
            month_list = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                month_list.append(revenue)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo(
            '@ models - outofdoor - outcanada_revenue_by_month_manager(-)')
        return month_list

    @staticmethod
    def read_file(file_name, date, org_id):
        logger.addinfo('@ models - outofdoor - read_file(+)')
        try:
            b = xlrd.open_workbook(file_name)
            data = b.sheet_by_index(0)
            column_names = data.ncols
            oracle_column_names = ['ITEM CODE', 'DESCRIPTION',
                                   'CUST NO', 'CUSTOMER NAME',
                                   'ADDRESS', 'CITY', 'STATE', 'COUNTRY',
                                   'ZIP CODE', 'PHONE', 'SHIP TO NAME',
                                   'SHIP TO ADDR', 'SHIP TO CITY',
                                   'SHIP TO ZIP', 'QUANTITY', 'UOM',
                                   'PZ QUANTITY', 'AMOUNT', 'TOTAL SALES',
                                   'DISCOUNT', 'SALESREP NO', 'SALES PERSON']
            column_names = []
            for i in range(data.ncols):
                column_names.append(data.cell_value(0, i))
            rows = []
            for i in range(1, data.nrows):
                rows_data = data.row_values(i)
                row_data = {}
                for j in range(data.ncols):
                    row_data[column_names[j]] = rows_data[j]
                rows.append(row_data)
        except Exception as e:
            logger.findaylog(""" @ 2573 EXCEPTION - models - outofdoor -
                             read_file """ + str(e))
            raise e
        logger.addinfo('@ models - outofdoor - read_file(-)')
        return {'data': rows,
                'column_names': column_names,
                'oracle_column_names': oracle_column_names,
                'status': 0}

    @staticmethod
    def save(jsond):
        logger.addinfo('@ models - outofdoor - save(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            data = jsond['data']
            date = jsond['period'].split('/')
            for i in range(len(data)):
                data[i]['day'] = 1
                data[i]['month'] = date[0]
                data[i]['year'] = date[1]
                data[i]['org_id'] = jsond['org_id']
                data[i]['manager_name'] = jsond['type']
                # this is to have a filter whether the manager is distributor or chainstore
                # while getting the month, customer details
                data[i]['attribute1'] = jsond.get('reference_type')
                data[i]['manager_no'] = jsond['managers']
                if 'ZIP_CODE' in data[i] and not data[i]['ZIP_CODE']:
                    data[i]['ZIP_CODE'] = None
            if len(data) > 0:
                stores = []
                store_data = deepcopy(data)
                for i in range(len(store_data)):
                    if 'ADDRESS' in store_data[i] and (
                            store_data[i]['ADDRESS']) and (
                            'CITY' in store_data[i]) and (
                            store_data[i]['CITY']) and (
                            'ZIP_CODE' in store_data[i]) and (
                            store_data[i]['ZIP_CODE']):
                        store_data[i]['country'] = 'CANADA'
                        store_data[i]['address'] = store_data[i]['ADDRESS']
                        store_data[i]['city'] = store_data[i]['CITY']
                        store_data[i]['zip_code'] = store_data[i]['ZIP_CODE']
                        store_data[i][
                            'shop_name'] = store_data[i]['CUSTOMER_NAME']
                        store_data[i]['province'] = ''
                        if 'STATE' in store_data[i] and store_data[i]['STATE']:
                            store_data[i]['province'] = store_data[i]['STATE']
                        stores.append(store_data[i])
                if len(stores) > 0:
                    jsond = {'category_id': [], 'user_id': jsond['user_id'],
                             'storelocator_flag': '', 'shop_campaigns': '', 'home_delivery': ''}
                    StoreLocator().check_duplicate(
                        stores, jsond)
                query = sql_file['petslink_delete_query']
                cursor.execute(query, p_month=date[0], p_year=date[1],
                               p_manager=jsond['type'])
                parameter_string = '('
                fieldname_string = '('
                for key, value in data[0].items():
                    fieldname_string += str(key) + ","
                    parameter_string += ":" + str(key) + ","
                fieldname_string = fieldname_string[:-1]
                parameter_string = parameter_string[:-1]
                fieldname_string += ")"
                parameter_string += ")"
            cursor.prepare("""insert into qpex_outofdoor_data """ +
                           fieldname_string + """ values """ +
                           parameter_string)
            cursor.executemany(None, data)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION - models  - outofdoor -
                             save """ + str(e))
            raise e
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - save(-)')
        return 'success'

    @staticmethod
    def read_us_file(base64_data):
        logger.addinfo('@ models - outofdoor - read_us_file(+)')
        result = {}
        try:
            decoded = base64.b64decode(base64_data)
            file_name = Outofdoor.id_generator()
            tmp_f_name = '/tmp/' + file_name + '.xls'
            text_file = open(tmp_f_name, 'w')
            text_file.write(decoded)
            text_file.close()
            d = xlrd.open_workbook(tmp_f_name)
            sheet = d.sheet_by_index(2)
            column_names = []
            col_types = []
            if sheet.nrows > 1:
                for i in range(sheet.ncols):
                    col_types.append(sheet.cell_type(1, i))
                    column_names.append(sheet.cell_value(0, i))
                oracle_names = ['CUST NO', 'NAME', 'ITEM CODE', 'ADDRESS',
                                'CITY', 'ST', 'ZIP', 'PHONE', 'EMAIL',
                                'ID', 'TM NO', 'TM NAME', 'DESCRIPTION']
                result['column_names'] = column_names
                result['oracle_names'] = oracle_names
                rows = []
                for i in range(1, sheet.nrows):
                    rows_data = sheet.row_values(i)
                    row_data = {}
                    for j in range(sheet.ncols):
                        # cell_type = 3 denotes value is type date
                        if col_types[j] == 3 and rows_data[j] != '' and \
                                isinstance(rows_data[j], float):
                            z = d.datemode
                            date = datetime.datetime(
                                *xlrd.xldate_as_tuple(rows_data[j], z))
                            formatted_date = date.strftime("%d/%m/%Y")
                            row_data[column_names[j]] = formatted_date
                        else:
                            row_data[column_names[j]] = rows_data[j]
                    rows.append(row_data)
                result['data'] = rows
            else:
                result['data'] = []
        except Exception as e:
            logger.findaylog(""" @ 2668 EXCEPTION - models - outofdoor -
                             read_us_file """ + str(e))
            raise e
        logger.addinfo('@ models - outofdoor - read_us_file(-)')
        return result

    @staticmethod
    def save_us_file(jsond):
        logger.addinfo('@ models - outofdoor - save_us_file(+)')
        connection = None
        cursor = None
        customer_oracle_names = ['CUST_NO', 'NAME', 'ADDRESS', 'CITY',
                                 'ST', 'ZIP', 'PHONE', 'EMAIL',
                                 'CUSTOMER_ID', 'ID', 'TM_NO', 'TM_NAME',
                                 'REGION', 'MONTH', 'YEAR']
        item_oracle_names = ['CUST_NO', 'ITEM_CODE', 'DESCRIPTION',
                             'YEAR', 'ITEM_ID', 'ID', 'NAME', 'REGION',
                             'ST', 'TM_NO', 'TM_NAME', 'CITY', 'ZIP']
        unique_customers = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            data = jsond['data']
            month_year = jsond['period'].split('/')
            month = month_year[0]
            year = month_year[1]
            sql_file = db_util.getSqlData()
            customer_lines = []
            item_lines = []

            cursor.execute(sql_file['outofdoor_item_maxid'])
            max_item_id = cursor.fetchone()[0]
            if not max_item_id:
                max_item_id = 0

            cursor.execute(sql_file['outofdoor_customer_maxid'])
            max_customer_id = cursor.fetchone()[0]

            month_name = get_monthname(int(month) - 1)

            if jsond['replace_month'] == 'Y':
                query = sql_file['replace_us_month_data']
                query += month_name + '_sales = null, '
                query += month_name + '_quantity = null'
                query += sql_file['replace_us_month_data_conditions']
                cursor.execute(query, p_year=year,
                               p_region=jsond['region'],
                               p_distributor=jsond['distributor'])
                connection.commit()

            month_sales_qty = ['JAN_SALES', 'JAN_QUANTITY', 'FEB_SALES',
                               'FEB_QUANTITY', 'MAR_SALES', 'MAR_QUANTITY',
                               'APR_SALES', 'APR_QUANTITY', 'MAY_SALES',
                               'MAY_QUANTITY', 'JUN_SALES', 'JUN_QUANTITY',
                               'JUL_SALES', 'JUL_QUANTITY', 'AUG_SALES',
                               'AUG_QUANTITY', 'SEP_SALES', 'SEP_QUANTITY',
                               'OCT_SALES', 'OCT_QUANTITY', 'NOV_SALES',
                               'NOV_QUANTITY', 'DEC_SALES', 'DEC_QUANTITY']
            for i in range(len(data)):
                line = {}
                for j in range(len(customer_oracle_names)):
                    line['year'] = str(year)
                    line['region'] = jsond['region']
                    line['month'] = str(month)
                    if len(line['month']) < 2:
                        line['month'] = '0' + line['month']
                    if customer_oracle_names[j] in data[i]:
                        if data[i][customer_oracle_names[j]] is not None and (
                                data[i][customer_oracle_names[j]] != ''):
                            if type(data[i][
                                    customer_oracle_names[j]]) == str:
                                line[customer_oracle_names[j]] = str(
                                    data[i][
                                        customer_oracle_names[j]]).strip().replace("'", "''")
                            else:
                                line[customer_oracle_names[j]] = str(
                                    data[i][
                                        customer_oracle_names[j]]
                                ).replace("'", "''")
                            if customer_oracle_names[j] == 'NAME':
                                line[customer_oracle_names[j]] = line[
                                    customer_oracle_names[j]].upper()
                        elif customer_oracle_names[j] == 'CUST_NO' or (
                                customer_oracle_names[j] == 'NAME'):
                            line[customer_oracle_names[j]] = '9999999'
                        else:
                            line[customer_oracle_names[j]] = ''
                customer_lines.append(line)

                line = {}
                for j in range(len(item_oracle_names)):
                    line['year'] = str(year)
                    line['region'] = jsond['region']
                    line['item_id'] = max_item_id
                    line['month'] = str(month)
                    line['additional_info_1'] = jsond['distributor']
                    line['manager_no'] = jsond['managers']
                    if len(line['month']) < 2:
                        line['month'] = '0' + line['month']
                    max_item_id = max_item_id + 1
                    for k in range(len(month_sales_qty)):
                        line[month_sales_qty[k]] = ''
                    if item_oracle_names[j] in data[i]:
                        if data[i][item_oracle_names[j]] is not None and (
                                data[i][item_oracle_names[j]] != ''):
                            if type(data[i][
                                    item_oracle_names[j]]) == str:
                                line[item_oracle_names[j]] = str(
                                    data[i][
                                        item_oracle_names[j]]).strip().replace("'", "''")
                            else:
                                line[item_oracle_names[j]] = str(data[i][
                                    item_oracle_names[j]]
                                ).replace("'", "''")
                            if item_oracle_names[j] == 'NAME':
                                line[item_oracle_names[j]] = line[
                                    item_oracle_names[j]].upper()
                        elif item_oracle_names[j] == 'CUST_NO' or (
                                item_oracle_names[j] == 'ITEM_CODE'):
                            line[item_oracle_names[j]] = '9999999'
                        else:
                            line[item_oracle_names[j]] = ''
                sales_month = month_name + '_SALES'
                sales_qty = month_name + '_QUANTITY'
                if data[i]['TOTAL'] != '' and (
                        data[i]['TOTAL'] is not None):
                    line[sales_month] = str(float(data[i]['TOTAL']))
                if data[i]['QTY'] != '' and (
                        data[i]['QTY'] is not None):
                    line[sales_qty] = str(float(data[i]['QTY']))
                item_lines.append(line)
            unique_customers = Outofdoor.us_unique_customer(customer_lines,
                                                            jsond['region'])
            if len(customer_lines) > 0:
                stores = []
                store_customers = deepcopy(customer_lines)
                for i in range(len(store_customers)):
                    if 'ADDRESS' in store_customers[i] and (
                            store_customers[i]['ADDRESS']) and (
                            'CITY' in store_customers[i]) and (
                            store_customers[i]['CITY']) and (
                            'ZIP' in store_customers[i]) and (
                                store_customers[i]['ZIP']) and (
                            store_customers[i]['NAME'] and
                            store_customers[i]['NAME'].lower().find('almo ') == -1
                    ):
                        store_customers[i][
                            'country'] = 'US'
                        store_customers[i][
                            'zip_code'] = store_customers[i]['ZIP'].strip()
                        store_customers[i][
                            'city'] = store_customers[i]['CITY'].strip()
                        store_customers[i][
                            'address'] = store_customers[i]['ADDRESS'].strip()
                        store_customers[i][
                            'shop_name'] = store_customers[i]['NAME'].strip()
                        store_customers[i]['user_verified_flag'] = 'N'
                        store_customers[i]['province'] = ''
                        if store_customers[i]['ST']:
                            store_customers[i][
                                'province'] = store_customers[i]['ST'].strip()
                        store_customers[i]['phone'] = ''
                        if 'PHONE' in store_customers[i] and (
                                store_customers[i]['PHONE']):
                            store_customers[i][
                                'phone'] = store_customers[i]['PHONE'].strip()
                        stores.append(store_customers[i])
                if len(stores) > 0:
                    jsond = {'category_id': [], 'user_id': jsond['user_id'],
                             'storelocator_flag': '', 'shop_campaigns': '', 'home_delivery': ''}
                    StoreLocator().check_duplicate(
                        stores, jsond)
            connection = db_util.get_connection()
            cursor = connection.cursor()
            if len(unique_customers) > 0:
                for i in range(len(unique_customers)):
                    unique_customers[i]['customer_id'] = max_customer_id
                    max_customer_id = max_customer_id + 1
                fieldname_string = '('
                parameter_string = '('
                for key, value in unique_customers[0].items():
                    fieldname_string += str(key) + ','
                    parameter_string += ':' + str(key) + ','
                fieldname_string = fieldname_string[:-1]
                parameter_string = parameter_string[:-1]
                fieldname_string += ')'
                parameter_string += ')'
                cursor.prepare(""" insert into QPEX_OUTOFDOOR_CUSTOMERS """ +
                               fieldname_string + """ values """ +
                               parameter_string)
                cursor.executemany(None, unique_customers)
                connection.commit()
            if item_lines:
                fieldname_string = '('
                parameter_string = '('
                for key, value in item_lines[0].items():
                    fieldname_string += str(key) + ','
                    parameter_string += ':' + str(key) + ','
                fieldname_string = fieldname_string[:-1]
                parameter_string = parameter_string[:-1]
                fieldname_string += ')'
                parameter_string += ')'
                cursor.prepare(""" insert into QPEX_OUTOFDOOR_ITEM """ +
                               fieldname_string + """ values """ +
                               parameter_string)
                cursor.executemany(None, item_lines)
        except Exception as e:
            logger.findaylog(""" @ 2810 EXCEPTION - models - outofdoor -
                             save_us_file """ + str(e))
            raise e
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - save_us_file(-)')
        return 'success'

    @staticmethod
    def us_unique_customer(customer_data, region):
        logger.addinfo('@ models - outofdoor - us_unique_customer(+)')
        connection = None
        cursor = None
        try:
            unique_customers = []
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outofdoor_new_customers']
            cursor.execute(query, p_region=region)
            data = Code_util.iterate_data(cursor)
            for i in range(len(customer_data)):
                is_exists = False
                for j in range(len(data)):
                    if customer_data[i]['CUST_NO'] == data[j]['cust_no'] and (
                            data[j]['cust_no'] != '9999999'):
                        is_exists = True
                        break
                if not is_exists:
                    unique_customers.append(customer_data[i])
        except Exception as e:
            logger.findaylog(""" @ 2843 EXCEPTION - models - outofdoor -
                             us_unique_customer """ + str(e))
            raise e
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - us_unique_customer(-)')
        return unique_customers

    @classmethod
    def revenue_province(cls, req_data):
        logger.addinfo('@ models - outofdoor - revenue_province(+)')
        connection = None
        cursor = None
        result = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['outdoor_canada_revenue_province']
            if req_data.get('manager_reference_as') == 'chain_store':
                chain_store_qry = sql_file['get_chain_store_details']
                query = query.format(chain_store_qry)
            query = query.format('')
            cursor.execute(query, p_month=req_data['month'],
                           p_year=req_data['year'],
                           p_manager_reference_as=req_data.get('manager_reference_as'),
                           p_manager_name=req_data.get('manager_name')
                           )
        except Exception as e:
            logger.findaylog("""@ 2866 EXCEPTION - models - outofdoor -
                revenue_province """ + str(e))
            raise e
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                data = dict()
                for index, fn in enumerate(fieldnames):
                    data[fn] = row[index]
                result.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - revenue_province(+)')
        return result

    @staticmethod
    def get_us_distributors():
        logger.addinfo('@ models - outofdoor - get_us_distributors(+')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            names = []
            sql_file = db_util.getSqlData()
            query = sql_file['us_distributors']
            cursor.execute(query)
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                name = {}
                for index, value in enumerate(fieldnames):
                    name[value] = row[index]
                names.append(name)
        except Exception as error:
            logger.findaylog("""@ 3002 EXCEPTION - models - outofdoor -
                             get_us_distributors """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_us_distributors(-')
        return names

    @staticmethod
    def get_us_by_distributors(jsond):
        logger.addinfo('@ models - outofdoor - get_us_by_distributors(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            distributors = []
            query = sql_file['us_by_distributor']
            cursor.execute(query, p_year=jsond['year'],
                           p_distributor=jsond['distributor'],
                           p_manager_no=jsond['manager_no'])
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                distributor = {}
                for index, value in enumerate(fieldnames):
                    distributor[value] = row[index]
                distributors.append(distributor)
        except Exception as error:
            logger.findaylog("""@ 3031 EXCEPTION - models - outofdoor -
                            get_us_by_distributors """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_us_by_distributors(-)')
        return distributors

    @staticmethod
    def get_customers_by_distributor(jsond):
        logger.addinfo('@ models - outofdoor - get_customers_by_distributor(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            customers = []
            query = sql_file['us_by_distributors_customers']
            cursor.execute(query, p_year=jsond['year'],
                           p_distributor=jsond['distributor'])
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                customer = {}
                for index, value in enumerate(fieldnames):
                    customer[value] = row[index]
                customers.append(customer)
        except Exception as error:
            logger.findaylog("""@ 3057 EXCEPTION - models - outofdoor -
                             get_customers_by_distributor """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_customers_by_distributor(-)')
        return customers

    @staticmethod
    def get_distributor_months_data(jsond):
        logger.addinfo('@ models - outofdoor - get_distributor_months_data(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            months = []
            query = sql_file['us_by_distributor_months']
            cursor.execute(query, p_year=jsond['year'],
                           p_distributor=jsond['distributor'])
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                month = {}
                for index, value in enumerate(fieldnames):
                    month[value] = row[index]
                months.append(month)
        except Exception as error:
            logger.findaylog("""@ 3084 EXCEPTION - models - outofdoor -
                             get_distributor_months_data """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - get_distributor_months_data(-)')
        return months

    @staticmethod
    def out_of_door_users():
        logger.addinfo('@ models - outofdoor - out_of_door_users(+)')
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['out_of_door_users']
            cursor.execute(query)
            users = Code_util.iterate_data(cursor)
        except Exception as error:
            logger.findaylog("""@ 3110 EXCEPTION - models - outofdoor -
                             out_of_door_users """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - outofdoor - out_of_door_users(-)')
        return users

    @staticmethod
    def uploaded_file_sheets(jsond):
        upload_obj = UploadOutofDoorFiles(jsond)
        sheet_names = upload_obj.get_sheets_list()
        return {'status': 0, 'sheets': sheet_names}

    @staticmethod
    def uploaded_sheet_columns(jsond):
        upload_obj = UploadOutofDoorFiles(jsond)
        row_index, column_names = upload_obj.get_column_names()
        oracle_names = ['CUST NO', 'NAME', 'ITEM CODE', 'ADDRESS',
                        'CITY', 'ST', 'ZIP', 'PHONE', 'EMAIL',
                        'ID', 'TM NO', 'TM NAME', 'DESCRIPTION',
                        'QTY', 'TOTAL']
        return {'status': 0, 'column_names': column_names,
                'row_index': row_index, 'oracle_names': oracle_names}

    @staticmethod
    def upload_us_files_in_db(jsond):
        final = {}
        upload_obj = UploadOutofDoorFiles(jsond)
        jsond['data'] = upload_obj.get_distributor_file()
        result = Outofdoor.save_us_file(jsond)
        if result == 'success':
            final['msg'] = 'File uploaded successfully'
            final['status'] = 0
        else:
            final['msg'] = 'Failed to upload file'
            final['status'] = 1
        return final

    @staticmethod
    def canada_type_reference():
        sql_file = db_util.getSqlData()
        with OracleConnectionManager() as conn:
            query = sql_file['get_canada_type_references']
            conn.execute(query)
            result = conn.get_result()
            if result:
                result = [x['manager_reference'] for x in result]
        return {'status': 0, 'references': result}


def get_monthname(number):
    months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG',
              'SEP', 'OCT', 'NOV', 'DEC']
    return months[number]


def isplit(i, s):
    return [list(g) for k, g in itertools.groupby(i, lambda x:x[0] in s)
            if not k]


def to_num(num):
    number = ''
    try:
        number = int(num)
    except:
        number = num

    return number
