from finapi.utils import db_util
from finapi.utils.code_util import Code_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.logdata import logger
from mailjet_rest import Client
import os
import io
import requests
import ujson
import cx_Oracle
import random
import string
import pdfkit
import base64
from finapi.models.cms.cms import CMS
from finapi.utils import auth_util
from string import Template
from PyPDF2 import PdfFileWriter, PdfFileReader
from finapi.models.contacts.contacts import Contacts


class Wordpress:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_address_details(key, state):
        logger.addinfo('@ models - wordpress - get_address_details(+)')
        return_data = []
        final_data = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            result = Wordpress.get_postal_codes(key)
            if result != 'no':
                key = result
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            query = file_data['get_address_details_query']
            if type(key) == list:
                for i in range(0, len(key)):
                    key1 = '%' + key[i] + '%'
                    cursor.execute(query, p_key=key1)
                    tmp_data = cursor.fetchall()
                    if len(tmp_data) > 0:
                        final_data.append(tmp_data[0])
            else:
                key = '%' + key + '%'
                cursor.execute(query, p_key=key)
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - models - wordpress -
                 get_address_details """ + str(error))
            raise error
        else:
            if type(key) != list:
                field_names = [a[0].lower() for a in cursor.description]
                fn_index = field_names.index('st')
                for row in cursor:
                    data = {}
                    flag = False
                    for index, fn in enumerate(field_names):
                        if state:
                            if row[fn_index] and row[fn_index] == state:
                                flag = True
                                data[fn] = row[index]
                        else:
                            flag = True
                            data[fn] = row[index]
                    if flag:
                        return_data.append(data)
            else:
                field_names = [a[0].lower() for a in cursor.description]
                for row in final_data:
                    data = {}
                    for index, fn in enumerate(field_names):
                        data[fn] = row[index]
                    return_data.append(data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - wordpress - get_address_details(-)')
        return return_data

    @staticmethod
    def check_newsletter_subscription(req):
        """
            Check if user already have newsletter project subscription
        """
        newsletter_details = None

        cms_obj = CMS()
        contact_data = cms_obj.check_contact_details(req['email'])

        if contact_data.get('status') != 'ERROR':
            contact_data = contact_data.get('details')
            contact_properties = contact_data.get('properties')
            if contact_properties.get('newsletter_project_subscription'):
                newsletter_details = contact_properties.get(
                    'newsletter_project_subscription').get('value')

        if newsletter_details:
            if req['project'] not in newsletter_details:
                newsletter_details += ';' + req['project']
        else:
            newsletter_details = req['project']

        return newsletter_details

    @staticmethod
    def add_contact_hubspot(req):
        logger.addinfo('@ models - wordpress - add_contact_hubspot(+)')
        try:
            valid_newsletter_projects = ['CAFL', 'ALMONATURE',
                                         'RVF', 'H&W', 'BIODIVERSITY', 'FONDAZIONE']

            props = {
                'email': req['email'],
                'country': CMS.format_country_code(req['country'])
            }

            if req['project'] in valid_newsletter_projects:
                props['newsletter_project_subscription'] = Wordpress.check_newsletter_subscription(
                    req)

            if 'source' in req:
                if req['source'] == 'newsletter':
                    props['hs_persona'] = 'persona_6'
                    props['hubspot_owner_id'] = 35516220

            if 'consent_projects' in req:
                props['consent_projects'] = req['consent_projects']

            if 'consent_foundation' in req:
                props['consent_foundation'] = req['consent_foundation']

            if 'first_name' in req:
                props['firstname'] = req['first_name']

            if 'zip_code' in req:
                props['zip'] = req['zip_code']

            if 'city' in req:
                props['city'] = req['city']

            if 'pet_type' in req:
                props['pet_type'] = req['pet_type']

            if 'no_cats' in req:
                props['no_of_cats'] = req['no_cats']

            if 'no_dogs' in req:
                props['no_of_dogs'] = req['no_dogs']

            if 'dogs' in req:
                dogs_details = ''
                for dog in req['dogs']:
                    dogs_details += '[Name => ' + dog['name']
                    dogs_details += ', Birth Year => ' + str(dog['birth_year'])
                    dogs_details += '],'
                dogs_details = dogs_details[:-1]
                props['dog_details'] = dogs_details

            if 'cats' in req:
                cats_details = ''
                for cat in req['cats']:
                    cats_details += '[Name => ' + cat['name']
                    cats_details += ', Birth Year => ' + str(cat['birth_year'])
                    cats_details += '],'
                cats_details = cats_details[:-1]
                props['cat_details'] = cats_details

            cms_obj = CMS()
            cms_obj.create_contact(props)
        except Exception as e:
            logger.findaylog("""@ 67 EXCEPTION - models - wordpress -
                add_contact_hubspot """ + str(e))
            raise e
        logger.addinfo('@ models - wordpress - add_contact_hubspot(-)')
        return 'success'

    @staticmethod
    def add_subscriber(req):
        logger.addinfo('@ models - wordpress - add_subscriber(+)')
        CONFIRMED_LIST_ID = 1796017
        UNCONFIRMED_LIST_ID = 1796000
        status = None
        url = None
        template_id = None
        subject = None
        try:
            strings = db_util.get_strings()
            api_key = os.environ['MJ_APIKEY_PUBLIC']
            api_secret = os.environ['MJ_APIKEY_PRIVATE']
            mailjet = Client(auth=(api_key, api_secret))

            country = req['country']
            uid = base64.b64encode(ujson.dumps(req))
            if not req['unsubscribe']:
                if req['confirm']:
                    req['action'] = 'remove'
                    if manage_subscriber(req, UNCONFIRMED_LIST_ID):
                        req['action'] = 'addforce'
                        status = manage_subscriber(req, CONFIRMED_LIST_ID)
                    else:
                        return 'failed'
                else:
                    req['action'] = 'addnoforce'
                    status = manage_subscriber(req, UNCONFIRMED_LIST_ID)
                    if country == 'DE_CH':
                        url = 'de_CH/'
                    elif country == 'IT_CH':
                        url = 'it_CH/'
                    elif country == 'FR_CH':
                        url = 'fr_CH/'
                    elif country == 'EN_GB':
                        url = 'en_GB/'
                    elif country == 'EN_CA':
                        url = 'en_CA/'
                    else:
                        url = country.lower() + '/'
                    url += strings['wp_subscribe_confirm_url'] + '?uid=' + uid
                    if country == 'IT' or country == 'IT_CH':
                        template_id = 407647
                        subject = strings['wp_subs_confirm_it']
                    elif country == 'DE' or country == 'DE_CH':
                        template_id = 407648
                        subject = strings['wp_subs_confirm_de']
                    elif country == 'FR' or country == 'FR_CH':
                        template_id = 407650
                        subject = strings['wp_subs_confirm_fr']
                    elif country == 'NL':
                        template_id = 407651
                        subject = strings['wp_subs_confirm_nl']
                    else:
                        template_id = 407652
                        subject = strings['wp_subs_confirm']
            else:
                if req['confirm']:
                    req['action'] = 'addnoforce'
                    status = manage_subscriber(req, CONFIRMED_LIST_ID)
                else:
                    if country == 'DE_CH':
                        url = 'de_CH/'
                    elif country == 'IT_CH':
                        url = 'it_CH/'
                    elif country == 'FR_CH':
                        url = 'fr_CH/'
                    elif country == 'EN_GB':
                        url = 'en_GB/'
                    elif country == 'EN_CA':
                        url = 'en_CA/'
                    else:
                        url = country.lower() + '/'
                    url += strings['wp_unsubscribe_confirm_url']
                    url += '?uid=' + uid
                    if country == 'IT' or country == 'IT_CH':
                        template_id = 407663
                        subject = strings['wp_unsubs_confirm_it']
                    elif country == 'DE' or country == 'DE_CH':
                        template_id = 407664
                        subject = strings['wp_unsubs_confirm_de']
                    elif country == 'FR' or country == 'FR_CH':
                        template_id = 407666
                        subject = strings['wp_unsubs_confirm_fr']
                    elif country == 'NL':
                        template_id = 407669
                        subject = strings['wp_unsubs_confirm_nl']
                    else:
                        template_id = 407668
                        subject = strings['wp_unsubs_confirm']
                    status = True

            if not status:
                return 'failed'

            if not req['confirm']:
                error_mail = strings['mj_error_report_mail']
                data = {
                    'FromEmail': strings['sender_email'],
                    'FromName': strings['sender_name'],
                    'Subject': subject,
                    'MJ-TemplateID': template_id,
                    'MJ-TemplateLanguage': True,
                    'MJ-TemplateErrorReporting': error_mail,
                    'Recipients': [
                        {
                            'Email': req['email']
                        }
                    ],
                    'Vars': {
                        "subscribe_link": url
                    }
                }
                # mailjet.send.create(data=data)
        except Exception as error:
            logger.findaylog("""@ 67 EXCEPTION - models - wordpress -
                add_subscriber """ + str(error))
            raise error
        logger.addinfo('@ models - wordpress - add_subscriber(-)')
        return 'success'

    @staticmethod
    def get_postal_codes(key):
        logger.addinfo('@ models - wordpress - get_postal_codes(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getSqlData()
            query = file_data['store_locator_string']
            query1 = file_data['store_locator_string2']
            tmp = query + key + query1
            r = requests.get(tmp)
            data = ujson.loads(r.text)
            if 'zip_codes' in data:
                tmp_data = data['zip_codes']
                tmp_array = []
                for i in range(0, len(tmp_data)):
                    tmp_array.append(tmp_data[i]['zip_code'])
                tmp_array = list(set(tmp_array))
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - models - wordpress -
                 get_postal_codes """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - wordpress - get_postal_codes(-)')
        if 'zip_codes' in data:
            return tmp_array
        else:
            return 'no'

    @staticmethod
    def add_store(jsond):
        logger.addinfo('@ models - wordpress - add_store(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['insert_store_query']
            cursor.execute(query, p_name=jsond['storename'],
                           p_address=jsond['address'],
                           p_city=jsond['city'],
                           p_state=jsond['state'],
                           p_zip=jsond['zip'],
                           p_lat=jsond['lat'],
                           p_lng=jsond['lng'])
        except Exception as error:
            logger.findaylog("""@ 147 EXCEPTION - models - wordpress -
                add_store """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - wordpress - add_store(-)')
        return 'success'

    @staticmethod
    def user_registration(req):
        logger.addinfo('@ models - wordpress - user_registration(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            encrypted_password = hashPassword(req['password'])
            sql_file = db_util.getSqlData()
            query = sql_file['username_check_query']
            cursor.execute(query, p_email=req['email'])
            data = cursor.fetchone()
            if data and data[0] > 0:
                status = 'USER_EXISTS'
            else:
                cursor.execute("""
                begin
                    qpex_wordpress_pkg.create_user(
                        :p_name,
                        :p_last_name,
                        :p_email,
                        :p_password,
                        :p_encrypted_password,
                        :p_reference_email,
                        :p_comments,
                        :p_registration_type,
                        :p_comments_name,
                        :p_country,
                        :p_postal_code,
                        :p_city,
                        :p_status_code
                    );
                end; """, p_name=req['first_name'],
                               p_last_name=req['last_name'],
                               p_email=req['email'].strip(),
                               p_password=req['password'],
                               p_encrypted_password=encrypted_password,
                               p_reference_email=req['reference_email'],
                               p_comments=req['comments'],
                               p_registration_type=req['registration'][0]['type'],
                               p_comments_name=None,
                               p_country=req['country'],
                               p_postal_code=req.get('postal_code', ''),
                               p_city=req.get('city', ''),
                               p_status_code=status_code)
                status = status_code.getvalue()
                if status == 'SUCCESS':
                    obj = dict()
                    name = req['first_name'] + ' ' + req['last_name']
                    obj['name'] = name
                    obj['email'] = req['email']
                    obj['pet_type'] = ''
                    obj['country'] = req['country']
                    obj['project'] = 'N'
                    obj['zip_code'] = req.get('postal_code', '')
                    obj['city'] = req.get('city', '')
                    privacy = req['privacy'][0]
                    obj['consent_projects'] = privacy['consent_projects']
                    obj['consent_profiling'] = privacy['consent_profiling']
                    obj['consent_foundation'] = privacy['consent_foundation']
                    obj['source'] = 'professional'
                    obj['unsubscribe'] = False
                    obj['confirm'] = False
                    if obj['consent_projects'] == 'Y' or \
                            obj['consent_profiling'] == 'Y' or \
                            obj['consent_foundation'] == 'Y':
                        # Wordpress.add_subscriber(obj)
                        Wordpress.add_contact_hubspot(obj)
                else:
                    logger.findaylog("""@ models - wordpress 
                    - user_registration - Unexpected Error! Please try later""")
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - wordpress -
                 user_registration """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - wordpress - user_registration(-)')
        return status

    @staticmethod
    def send_mail(req):
        logger.addinfo('@ models - wordpress - send_mail(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            strings = db_util.get_strings()
            reg_type = req['registration'][0]['type']

            if 'country_code' in req:
                country_code = req['country_code']
            else:
                country_code = req['country']

            props = {
                'email': req['email'],
                'firstname': req['first_name'],
                'lastname': req['last_name'],
                'hs_persona': 'persona_7',
                'country': country_code,
                'phone': req['contact_number'],
                'company': req['business_name'],
                'zip': req.get('postal_code', ''),
                'city': req.get('city', '')
            }

            try:
                props['reference_email'] = req['reference_email']
            except KeyError:
                props['reference_email'] = ''

            cms_obj = CMS()
            contact_response = cms_obj.create_contact(props)

            if reg_type == 'customer':
                query = sql_file['reference_email_check']
                cur.execute(query, p_reference_email=req['reference_email'])
                user = cur.fetchone()
                if user and user[0] > 0:
                    reference_email = req['reference_email']
                else:
                    reference_email = strings['wp_alternate_ref_email']
                ref_email = reference_email
            else:
                """
                For Business Inquiry get Support Emails from Hub DB
                """
                support_details = cms_obj.business_inquiry_support_email(country_code.upper())

                if len(support_details) > 0 and 'status' not in support_details:
                    req['support'] = [
                        {
                            'name': support_details[0]['name'],
                            'email': support_details[0]['support_email']
                        }
                    ]
                    if 'mail_to_cc' in support_details[0]:
                        req['mail_to_cc'] = support_details[0]['mail_to_cc']
                try:
                    reference_email = req['reference_email']
                except KeyError:
                    reference_email = ''
                ref_email = req['support'][0]['email']
            link = 'email=' + req['email'] + '&name=' + req['first_name']
            link += '%20' + req['last_name']
            # 575995 - Business enquiry
            # 575993 - Approve/Reject registration
            data = {
                'subject': req['subject'],
                'template_id': req['template_id'],
                'params': [{
                    'key': 'registration_name',
                    'value': req['registration'][0]['name'],
                }, {
                    'key': 'business_name', 'value': req['business_name'], },
                    {'key': 'last_name',
                     'value': req['last_name'], },
                    {'key': 'first_name',
                     'value': req['first_name'], },
                    {'key': 'contact_number',
                     'value': req['contact_number'], },
                    {'key': 'email',
                     'value': req['email'], },
                    {'key': 'country',
                     'value': req['country'], },
                    {'key': 'reference_email',
                     'value': req['reference_email'], },
                    {'key': 'comments_data',
                     'value': req['comments']
                     },
                    {'key': 'postal_code',
                     'value': req.get('postal_code', '')
                     },
                    {'key': 'city',
                     'value': req.get('city', '')
                     }],
                'recipients': [
                    {'Email': ref_email, 'Name': ''}
                ]
            }

            if reg_type == 'customer':
                data['params'].append({'key': 'req_link', 'value': link})
            else:
                if reference_email:
                    data['recipients'].append({'Email': reference_email, 'Name': ''})
                data['params'].append({'key': 'support_name', 'value': req['support'][0]['name']})
                if 'mail_to_cc' in req:
                    data['cc'] = req['mail_to_cc']

            mail_result = CommonUtils.send_mail(data)
            if mail_result != 'SUCCESS':
                logger.findaylog('@ models - wordpress - send_email - {}'.format(data))

            try:
                internal_contact = reference_email
            except KeyError:
                internal_contact = strings['wp_alternate_ref_email']
            data = {
                'subject': strings['wp_user_create_mail'],
                'template_id': 107450,
                'params': [{
                    'key': 'internal_contact',
                    'value': internal_contact
                },
                    {
                        'key': 'register_name',
                        'value': req['first_name']
                }],
                'recipients': [
                    {
                        'Email': req['email']
                    }
                ]
            }

            if reg_type == 'customer':
                customer_mail = CommonUtils.send_mail(data)
                if customer_mail != 'SUCCESS':
                    logger.findaylog('@ models - wordpress - send_email - {}'.format(data))

                # Log email sent to user in HubSpot
                html_message = 'Hi <b>{0}</b>. <br/><br/>'
                html_message += 'We have received your request to access professional area.  '
                html_message += 'Your account will be activated within 24hrs time. <br/><br/>'
                html_message += 'If your account has not been activated within 24 hours or has been rejected, '
                html_message += 'please contact {1}'
                html_message = html_message.format(req['first_name'], internal_contact)

                props = {
                    'type': 'EMAIL',
                    'sender': strings['sender_email'],
                    'email': req['email'],
                    'subject': strings['wp_user_create_mail'],
                    'html_message': html_message,
                    'contact_id': contact_response['contact_id']
                }
            else:
                # Log email sent to user in HubSpot
                html_message = '<b>Comments</b>: <br/> {0}'
                html_message = html_message.format(req['comments'].encode('utf-8'))

                props = {
                    'type': 'EMAIL',
                    'sender': req['email'],
                    'email': req['support'][0]['email'],
                    'subject': req['subject'],
                    'html_message': html_message,
                    'contact_id': contact_response['contact_id']
                }

            cms_obj = CMS()
            cms_obj.contact_log(props)
        except Exception as error:
            logger.findaylog("""@ 269 EXCEPTION - models - wordpress -
                send_mail """ + str(error))
            raise error
        finally:
            if cur:
                cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - wordpress - send_mail(-)')
        return 'SUCCESS'

    @staticmethod
    def login(jsond):
        logger.addinfo('@ models - wordpress - login(+)')
        connection = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            encrypted_password = hashPassword(jsond['password'])
            sql_file = db_util.getSqlData()
            query = sql_file['username_check_query']
            cursor.execute(query, p_email=jsond['email'])
            data = cursor.fetchone()
            cursor.close()
            if data[0] > 0:
                cursor = connection.cursor()
                query = sql_file['wordpress_login_query']
                cursor.execute(query, p_email=jsond['email'])
                data = Code_util.iterate_data(cursor)
                cursor.close()
                if data[0]['failed_login_attempts'] >= 2:
                    result['status'] = 'MORE_FAILS'
                elif data[0]['active'] != 'A':
                    result['status'] = 'INACTIVE'
                elif data[0]['encrypted_password'] == encrypted_password:
                    update_failed_attempts(0, 'A', jsond['email'])
                    result['status'] = 'SUCCESS'
                    del data[0]['failed_login_attempts']
                    del data[0]['encrypted_password']
                    result['data'] = data
                else:
                    flag = 'A'
                    if data[0]['failed_login_attempts'] is None:
                        failed_attempts = 1
                    else:
                        failed_attempts = data[0]['failed_login_attempts'] + 1
                    if failed_attempts == 3:
                        flag = 'I'
                    update_failed_attempts(failed_attempts, flag,
                                           jsond['email'])
                    attempts = 3 - failed_attempts
                    result['status'] = 'Authentication failed! ' \
                                       + str(attempts) + ' attempts remaining'
                    logger.findaylog("""@ models - wordpress 
                    - login - """ + result['status'])
            else:
                result['status'] = 'NO_USER'
        except Exception as error:
            logger.findaylog("""@ 192 EXCEPTION - models - wordpress -
                 login """ + str(error))
            raise error
        finally:
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - wordpress - login(-)')
        return result

    @staticmethod
    def forgot_password(email_address):
        logger.addinfo('@ models - wordpress - forgot_password(+)')
        result = ''
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['wordpress_password_query']
            cur.execute(query, p_email=email_address)
            data = cur.fetchone()
            if data and len(data) > 0:
                strings = db_util.get_strings()
                data = {
                    'subject': strings['forgot_password'],
                    'template_id': 107415,
                    'params': [{
                        'key': 'register_name',
                        'value': data[0]
                    }, {
                        'key': 'password',
                        'value': data[1]
                    }],
                    'recipients': [
                        {
                            'Email': email_address
                        }
                    ]
                }
                result = CommonUtils.send_mail(data)
                if result != 'SUCCESS':
                    logger.findaylog("""@ models - wordpress - forgot_password 
                                                       - Failed to send forgot password.""")
                update_failed_attempts(0, 'A', email_address)
            else:
                result = 'FAIL'
                logger.findaylog("""@ models - wordpress - forgot_password 
                - No user details found with given email.""")
        except Exception as error:
            logger.findaylog("""@ 343 EXCEPTION - models - wordpress -
                forgot_password """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - wordpress - forgot_password(-)')
        return result

    @staticmethod
    def change_user_status(email, status):
        logger.addinfo('@ models - wordpress - change_user_status(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['update_wp_user_status']
            cursor.execute(query, p_status=status,
                           p_email=email)
        except Exception as error:
            logger.findaylog("""@ 414 EXCEPTION - models - wordpress -
                change_user_status """ + str(error))
            return "error"
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - wordpress - change_user_status(-)')
        return "success"

    @staticmethod
    def send_status_mail(register_name, email_address, status):
        logger.addinfo('@ models - wordpress - send_status_mail(+)')
        try:
            strings = db_util.get_strings()
            data = {
                'subject': strings['wordpress_user_status'],
                'template_id': 107449,
                'params': [{
                    'key': 'status',
                    'value': status
                },
                    {
                        'key': 'register_name',
                        'value': register_name
                }],
                'recipients': [
                    {
                        'Email': email_address
                    }
                ]
            }
            result = CommonUtils.send_mail(data)
            if result != 'SUCCESS':
                logger.findaylog("""@ models - wordpress - send_status_mail -
                {}""".format(data))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - wordpress -
                send_status_mail """ + str(error))
            raise error
        logger.addinfo('@ models - wordpress - send_status_mail(-)')
        return 'SUCCESS'

    @staticmethod
    def generate_coupon(jsond):
        logger.addinfo('@ models - wordpress - generate_coupon(+)')
        connection = None
        cursor = None
        coupon_code = None
        coupon_type = None
        language = None
        status = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['check_coupon_query']
            coupon_type = jsond['coupon_type']
            language = jsond['language']
            if language == 'it':
                coupon_code = 'KCI'
            elif language == 'fr':
                coupon_code = 'FRC'
            elif language == 'nl':
                coupon_code = 'NLC'
            else:
                coupon_code = 'KCI'
            coupon_code += ''.join(random.choice
                                   (string.ascii_uppercase +
                                    string.digits) for i in range(9))
            row = cursor.execute(query,
                                 p_email_id=jsond['email_id'],
                                 p_pet_type=jsond['pet_type'],
                                 p_language=jsond['language']).fetchone()
            if row is None:
                query = sql_file['coupon_insert_query']
                if language == 'de':
                    coupon_code = None
                elif language == 'fr' and coupon_type == 'O':
                    coupon_code = None
                elif language == 'nl' and coupon_type == 'O':
                    coupon_code = None
                cursor.execute(query, p_name=jsond['name'],
                               p_email_id=jsond['email_id'],
                               p_coupon_code=coupon_code,
                               p_pet_type=jsond['pet_type'],
                               p_expiration_date=jsond['expiration_date'],
                               p_pet_size=jsond['pet_size'],
                               p_product=jsond['product'],
                               p_agent_date=jsond['agent'],
                               p_language=jsond['language'])

                if language == 'de' or coupon_type == 'O':
                    status = send_online_coupon(jsond)
                else:
                    status = send_offline_coupon(jsond, coupon_code)
            else:
                status = 'EXISTS'
            if status not in ['SUCCESS', 'EXISTS']:
                logger.findaylog("""@ - models - wordpress -
                                generate_coupon - Coupon generation failed""")
        except Exception as error:
            logger.findaylog("""@ 451 EXCEPTION - models - wordpress -
                generate_coupon """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - wordpress - generate_coupon(-)')
        return status

    @staticmethod
    def get_coupons():
        logger.addinfo('@ models - wordpress - get_coupons(+)')
        connection = None
        cursor = None
        coupons = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['coupons_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 630 EXCEPTION - models - wordpress -
                get_coupons """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cursor.description]
            for row in cursor:
                coupon = {}
                for index, fn in enumerate(field_names):
                    coupon[fn] = row[index]
                coupons.append(coupon)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - wordpress - get_coupons(-)')
        return coupons

    @staticmethod
    def download_coupon(jsond):
        logger.addinfo('@ models - wordpress - download_coupon(+)')
        encoded = None
        try:
            data = get_coupon(jsond)
            coupon_path = prepare_coupon(data)
            pdf_file = open(coupon_path, 'r')
            encoded = base64.b64encode(pdf_file.read())
            pdf_file.close()
        except Exception as error:
            logger.findaylog("""@ 652 EXCEPTION - models - wordpress -
                download_coupon """ + str(error))
            raise error
        logger.addinfo('@ models - wordpress - download_coupon(-)')
        return encoded, data['coupon_code']

    @staticmethod
    def send_contact_details(req):
        logger.addinfo('@ models - wordpress - send_contact_details(+)')
        result = {}
        try:
            cms_obj = CMS()
            format_country = CMS.format_country_code(req['country'])
            # Get HubSpot Owner Id
            owner_id = cms_obj.get_contact_hubspot_owner_id(req['eng_reason'],
                                                            format_country, existing=True)

            # Create Contact in HubSpot
            props = {
                'email': req['email'],
                'firstname': req['name'],
                'hs_persona': 'persona_5',
                'country': format_country,
                'contact_reason_text': req['reason'],
                'subject': req['subject'].encode('utf-8'),
                'message': req['message'].encode('utf-8')
            }

            if owner_id and len(str(owner_id)) > 0:
                props['hubspot_owner_id'] = owner_id

            contact_response = cms_obj.create_contact(props)

            # Create Contact Log in HubSpot
            # html_message = '<b>Reason</b>: {0} <br/>'
            # html_message += '<b>Subject</b>: {1} <br/>'
            # html_message += '<b>Message</b>: <br/> {2}'
            # html_message = html_message.format(req['reason'],
            #                                    req['subject'].encode('utf-8'),
            #                                    req['message'].encode('utf-8'))
            #
            # props = {
            #     'type': 'EMAIL',
            #     'sender': req['email'],
            #     'email': req['support_email'],
            #     'subject': req['subject'].encode('utf-8'),
            #     'html_message': html_message,
            #     'contact_id': contact_response['contact_id']
            # }
            #
            # cms_obj.contact_log(props)

            # email = os.environ['SMTP_MAIL']
            # password = os.environ['SMTP_PASS']
            #
            # mail_content = """
            # Name: {name}
            # Email: {email}
            #
            # {content}
            # """

            email = req['email'] + '<br/>'
            email += '<b>Reason:</b> ' + req['reason'] + '<br/>'

            data = {
                'sender': {
                    'email': req['email'],
                    'name': req['name']
                },
                'subject': req['subject'].encode('utf-8'),
                'template_id': 391586,
                'params': [{
                    'key': 'name',
                    'value': req['name']
                }, {
                    'key': 'email',
                    'value': email
                }, {
                    'key': 'message',
                    'value': req['message'].encode('utf-8')
                }],
                'recipients': [
                    {
                        'Email': req['support_email'],
                        'Name': ''
                    }
                ]
            }

            if 'mail_to_cc' in req and req['mail_to_cc']:
                data['cc'] = req['mail_to_cc']
            res = CommonUtils.send_mail(data)
            if res != 'SUCCESS':
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to send email. Please try again'
                logger.findaylog(""" @ models - wordpress - send_contact_details -{}"""
                                 .format(data))
            else:
                privacy = req['privacy'][0]
                obj = {
                    'name': '',
                    'email': req['email'],
                    'pet_type': '',
                    'country': req['country'],
                    'zip_code': '',
                    'project': 'N',
                    'consent_projects': privacy['consent_projects'],
                    'consent_profiling': privacy['consent_profiling'],
                    'consent_foundation': privacy['consent_foundation'],
                    'source': req['source'],
                    'unsubscribe': False,
                    'confirm': False
                }
                # obj['name'] = ''
                # obj['email'] = req['email']
                # obj['pet_type'] = ''
                # obj['country'] = req['country']
                # obj['zip_code'] = ''
                # obj['project'] = 'N'
                # obj['consent_projects'] = privacy['consent_projects']
                # obj['consent_profiling'] = privacy['consent_profiling']
                # obj['consent_foundation'] = privacy['consent_foundation']
                # obj['source'] = req['source']
                # obj['unsubscribe'] = False
                # obj['confirm'] = False
                # contacts_obj = Contacts()
                # contacts_obj.add_contact(req['contact'])

                if obj['consent_projects'] == 'Y' or \
                        obj['consent_profiling'] == 'Y' or \
                        obj['consent_foundation'] == 'Y':
                    # Wordpress.add_subscriber(obj)
                    Wordpress.add_contact_hubspot(obj)

                result['status'] = 'OK'
                result['msg'] = 'Contact email sent successfully'
        except Exception as e:
            logger.findaylog("""@ 669 EXCEPTION - models - wordpress -
                send_contact_details """ + str(e))
            raise e
        logger.addinfo('@ models - wordpress - send_contact_details(-)')
        return result


def send_online_coupon(jsond):
    logger.addinfo('@ models - wordpress - send_online_coupon(+)')
    status = None
    try:
        strings = db_util.get_strings()
        temp_id = ''
        if jsond['language'] == 'de':
            if 'temp_id' in jsond:
                temp_id = jsond['temp_id']
            else:
                temp_id = 240234
        elif jsond['language'] == 'fr':
            if 'temp_id' in jsond:
                temp_id = jsond['temp_id']
            else:
                temp_id = 241223
        elif jsond['language'] == 'nl':
            if 'temp_id' in jsond:
                temp_id = jsond['temp_id']
            else:
                temp_id = 241288
        subject = strings['wordpress_coupon_code_online_' + jsond['language']]
        data = {
            'subject': subject,
            'template_id': temp_id,
            'params': [{
                'key': 'name',
                'value': jsond['name']
            }],
            'recipients': [
                {
                    'Email': jsond['email_id']
                }
            ]
        }
        result = CommonUtils.send_mail(data)
        if result != 'SUCCESS':
            status = 'ERROR'
            logger.findaylog("""@ models - wordpress 
            - send_online_coupon - Failed to send email {} """.format(data))
        else:
            add_contact(jsond)
            status = 'SUCCESS'
    except Exception as error:
        logger.findaylog("""@ 627 EXCEPTION - models - wordpress -
            send_online_coupon """ + str(error))
        raise error
    logger.addinfo('@ models - wordpress - send_online_coupon(-)')
    return status


def send_offline_coupon(jsond, coupon_code):
    logger.addinfo('@ models - wordpress - send_offline_coupon(+)')
    path = '/home/finuser/finapi/dist/cdn/coupons/'
    pet_type = jsond['pet_type'].lower()
    try:
        exp_date = jsond['exp_date']
        language = jsond['language']
        merge_file = 'coupon_' + pet_type + '_' + language + '.pdf'
        coupon_html = 'coupon_' + pet_type + '_' + language + '.html'
        file_name = os.path.join(os.path.dirname(__file__) +
                                 '/' + coupon_html)
        with io.open(file_name, 'r', encoding='utf-8') as original:
            content = Template(original.read())
        original.close()

        agent = '15/12/2017'
        if language != 'it':
            agent = '15/02/2018'
            exp_date = '31/12/2017'
        else:
            agent = '30/01/2018'
            exp_date = '15/12/2017'
        with io.open('/tmp/' + coupon_code + '.html', 'w',
                     encoding='utf-8') as changed:
            if pet_type == 'dog':
                content = content.safe_substitute(name=jsond['name'],
                                                  coupon=coupon_code,
                                                  validity=exp_date,
                                                  agent=agent)
            else:
                content = content.safe_substitute(name=jsond['name'],
                                                  coupon=coupon_code,
                                                  validity=exp_date)
            changed.write(content)
            changed.close()

        options = {
            'page-size': 'A4',
            'zoom': '0.73',
            'encoding': 'UTF-8',
            'quiet': ''
        }
        if language == 'fr' or language == 'nl':
            options['zoom'] = '0.72'
        pdfkit.from_file('/tmp/' + coupon_code + '.html',
                         '/tmp/' + coupon_code + '.pdf',
                         options=options)

        pdf_writer = PdfFileWriter()
        file = PdfFileReader(open(path + merge_file, 'rb'))
        pdf_writer.addPage(file.getPage(0))
        file = PdfFileReader(open(
                             '/tmp/' + coupon_code + '.pdf', 'rb'))
        pdf_writer.addPage(file.getPage(0))

        pdf_writer.write(open(
                         '/tmp/Coupon ' + coupon_code + '.pdf', 'wb'))
        pdf_file = open('/tmp/Coupon ' + coupon_code + '.pdf', 'r')
        encoded = base64.b64encode(pdf_file.read())
        pdf_file.close()

        strings = db_util.get_strings()
        temp_id = ''
        if language == 'it':
            # temp_id = 191941
            temp_id = 250973
        elif language == 'fr':
            temp_id = 241258
        elif language == 'nl':
            temp_id = 241410
        subject = strings['wordpress_coupon_code_' + language]
        data = {
            'subject': subject,
            'template_id': temp_id,
            'params': [{
                'key': 'name',
                'value': jsond['name']
            }],
            'recipients': [
                {
                    'Email': jsond['email_id']
                }
            ],
            'attachments': [
                {
                    'file_type': 'application/pdf',
                    'file_name': coupon_code + '.pdf',
                    'file_data': encoded
                }
            ]
        }
        result = CommonUtils.send_mail(data)
        if result != 'SUCCESS':
            status = 'ERROR'
            logger.findaylog("""@ models - wordpress 
            - send_offline_coupon - Failed to send email {} """.format(data))
        else:
            add_contact(jsond)
            status = 'SUCCESS'
    except Exception as error:
        logger.findaylog("""@  EXCEPTION - models - wordpress -
            send_offline_coupon """ + str(error))
        raise error
    logger.addinfo('@ models - wordpress - send_offline_coupon(-)')
    return status


def add_contact(jsond):
    logger.addinfo('@ models - wordpress - add_contact(+)')
    contacts = []
    list_id = None
    language = None
    try:
        language = jsond['language']
        if language == 'it':
            list_id = 1779659
        elif language == 'de':
            list_id = 1779539
        elif language == 'fr' and jsond['coupon_type'] == 'O':
            list_id = 1779540
        elif language == 'fr' and jsond['coupon_type'] == 'L':
            list_id = 1779541
        elif language == 'nl' and jsond['coupon_type'] == 'O':
            list_id = 1779542
        elif language == 'nl' and jsond['coupon_type'] == 'L':
            list_id = 1779543
        else:
            return
        contact = {
            'email': jsond['email_id'],
            'name': '',
            'list_id': list_id,
            'action': 'addnoforce',
            'properties': [
                {
                    'Name': 'firstname',
                    'value': jsond['first_name']
                },
                {
                    'Name': 'last_name',
                    'value': jsond['last_name']
                },
                {
                    'Name': 'pet_type',
                    'value': jsond['pet_type']
                }
            ]
        }
        contacts.append(contact)
        contacts_obj = Contacts()
        contacts = contacts_obj.add_contact(contacts)
    except Exception as error:
        logger.findaylog(""" @ 766 EXCEPTION - models - wordpress -
            add_contact """ + str(error))
        raise error
    logger.addinfo('@ models - wordpress - add_contact(-)')


def prepare_coupon(jsond):
    logger.addinfo('@ models - wordpress - prepare_coupon(+)')
    path = '/home/finuser/finapi/dist/cdn/'
    try:
        coupon_code = jsond['coupon_code']
        pet_type = jsond['pet_type'].lower()
        merge_file = 'coupon_' + pet_type + '.pdf'
        file_name = os.path.join(os.path.dirname(__file__) +
                                 '/coupon_' + pet_type + '.html')
        with io.open(file_name, 'r', encoding='utf-8') as original:
            content = Template(original.read())
            original.close()

        with io.open('/tmp/' + jsond['coupon_code'] + '.html', 'w',
                     encoding='utf-8') as changed:
            if pet_type == 'dog':
                content = content.safe_substitute(name=jsond['name'],
                                                  coupon=jsond['coupon_code'],
                                                  validity=jsond['exp_date'],
                                                  agent='15/12/2017')
            else:
                content = content.safe_substitute(name=jsond['name'],
                                                  coupon=jsond['coupon_code'],
                                                  validity=jsond['exp_date'])
            changed.write(content)
            changed.close()

        options = {
            'page-size': 'A4',
            'zoom': '0.73',
            'encoding': 'UTF-8',
            'quiet': ''
        }
        pdfkit.from_file('/tmp/' + coupon_code + '.html',
                         '/tmp/' + coupon_code + '.pdf',
                         options=options)

        pdf_writer = PdfFileWriter()
        file = PdfFileReader(open(path + merge_file, 'rb'))
        pdf_writer.addPage(file.getPage(0))
        file = PdfFileReader(open(
                             '/tmp/' + coupon_code + '.pdf', 'rb'))
        pdf_writer.addPage(file.getPage(0))

        pdf_writer.write(open(
                         '/tmp/Coupon ' + coupon_code + '.pdf', 'wb'))
    except Exception as error:
        logger.findaylog("""@ 695 EXCEPTION - models - wordpress -
            prepare_coupon """ + str(error))
        raise error
    logger.addinfo('@ models - wordpress - prepare_coupon(-)')
    return '/tmp/Coupon ' + coupon_code + '.pdf'


def get_coupon(jsond):
    logger.addinfo('@ models - wordpress - get_coupon(+)')
    connection = None
    cursor = None
    row = None
    try:
        coupon_code = 'KCI'
        coupon_code += ''.join(random.choice
                               (string.ascii_uppercase +
                                string.digits) for i in range(9))
        connection = db_util.get_connection()
        cursor = connection.cursor()
        sql_file = db_util.getSqlData()
        query = sql_file['check_coupon_query']
        row = cursor.execute(query, p_email_id=jsond['email_id'],
                             p_pet_type=jsond['pet_type']).fetchone()
        if row is None:
            jsond['record_exists'] = False
            jsond['coupon_code'] = coupon_code
            query = sql_file['coupon_insert_query']
            cursor.execute(query, p_name=jsond['name'],
                           p_email_id=jsond['email_id'],
                           p_coupon_code=coupon_code,
                           p_pet_type=jsond['pet_type'],
                           p_expiration_date=jsond['expiration_date'],
                           p_pet_size=jsond['pet_size'],
                           p_product=jsond['product'],
                           p_agent_date=jsond['agent'])
        else:
            jsond['coupon_code'] = row[3]
            jsond['name'] = row[1]
            jsond['exp_date'] = row[6]
            jsond['record_exists'] = True
    except Exception as error:
        logger.findaylog("""@ 655 EXCEPTION - models - wordpress -
            get_coupon """ + str(error))
        raise error
    finally:
        connection.commit()
        cursor.close()
        db_util.release_connection(connection)
    logger.addinfo('@ models - wordpress - get_coupon(-)')
    return jsond


# generate encrypted password
def hashPassword(new_password):
    return auth_util.encrypt_legacy(new_password)


def update_failed_attempts(failed_attempts, status, email):
    logger.addinfo('@ models - wordpress - update_failed_attempts(-)')
    try:
        con = db_util.get_connection()
        cur = con.cursor()
        sql_file = db_util.getSqlData()
        query = sql_file['update_failed_attempts_query']
        cur.execute(query, p_failed_attempts=failed_attempts, p_status=status,
                    p_email=email)
    except Exception as error:
        logger.findaylog("""@ 370 EXCEPTION - models - wordpress -
            update_failed_attempts """ + str(error))
        raise error
    finally:
        if cur is not None:
            cur.close()
        con.commit()
        db_util.release_connection(con)
    logger.addinfo('@ models - wordpress - update_failed_attempts(-)')
    return 'SUCCESS'


def manage_subscriber(req, list_id):
    logger.addinfo('@ models - wordpress - manage_subscriber(+)')
    try:
        strings = db_util.get_strings()
        api_key = os.environ['MJ_APIKEY_PUBLIC']
        api_secret = os.environ['MJ_APIKEY_PRIVATE']
        mailjet = Client(auth=(api_key, api_secret))
        firstname = None
        no_of_cats = None
        no_of_dogs = None
        cats_details = None
        dogs_details = None
        try:
            if 'firstname' in req:
                firstname = req['first_name']
            if 'no_cats' in req:
                no_of_cats = req['no_cats']
            if 'no_dogs' in req:
                no_of_dogs = req['no_dogs']
            if 'cats' in req:
                cats_details = ''
                for cat in req['cats']:
                    cats_details += '[Name => ' + cat['name']
                    cats_details += ', Birth Year => ' + str(cat['birth_year'])
                    cats_details += '],'
                cats_details = cats_details[:-1]
            if 'dogs' in req:
                dogs_details = ''
                for dog in req['dogs']:
                    dogs_details += '[Name => ' + dog['name']
                    dogs_details += ', Birth Year => ' + str(dog['birth_year'])
                    dogs_details += '],'
                dogs_details = dogs_details[:-1]
        except KeyError:
            firstname = ''
            no_of_cats = ''
            no_of_dogs = ''
            dogs_details = ''
            cats_details = ''
        data = {
            'Email': req['email'],
            'Name': req['email'],
            'Action': req['action'],
            'Properties': {
                'country': req['country'],
                'pet_type': req['pet_type'],
                'zip_code': req['zip_code'],
                'project': req['project'],
                'consent_projects': req['consent_projects'],
                'consent_profiling': req['consent_profiling'],
                'consent_foundation': req['consent_foundation'],
                'source': req['source'],
                'firstname': firstname,
                'no_of_cats': no_of_cats,
                'no_of_dogs': no_of_dogs,
                'cats_details': cats_details,
                'dogs_details': dogs_details,
            }
        }
        result = mailjet.contactslist_managecontact.create(id=list_id,
                                                           data=data)
        if req['action'] == 'addforce' or req['action'] == 'addnoforce':
            if result.status_code != 201:
                logger.findaylog("""@ models - wordpress -
                 manage_subscriber - Failed to send email {}""".format(data))
                return False
        else:
            result = ujson.dumps(result)
            if 'StatusCode' in result:
                return False
    except Exception as e:
        logger.findaylog("""@ 1073 EXCEPTION models - wordpress -
            manage_subscriber """ + str(e))
        raise e
    logger.addinfo('@ models - wordpress - manage_subscriber(-)')
    return True
