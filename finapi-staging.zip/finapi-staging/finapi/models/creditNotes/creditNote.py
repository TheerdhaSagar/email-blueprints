from finapi.utils import db_util
from finapi.utils.logdata import logger
import cx_Oracle
import base64
import ujson
from finapi.utils.log_util import LogUtil
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.constants import Status


@LogUtil.class_module_logs('credit_notes')
class CreditNote:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def getCreditNoteSummary(orgId=None, status=None):
        creditNote_list = []
        logger.addinfo('@ models - creditnotes - getCreditNoteSummary(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["getCNbyStatus_query"]
            cursor.execute(query, p_status=status, porg_id=orgId, p_reqid='')
        except Exception as error:
            logger.findaylog("""@ 28 EXCEPTION - models - creditnotes -
                 getCreditNoteSummary """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            field_types = [a[1] for a in cursor.description]
            cnDataType = {}
            creditNote_list.append(setHeader(fieldnames, field_types,
                                             cnDataType))
            for creditNote in cursor:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = creditNote[index]
                creditNote_list.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - getCreditNoteSummary(-)')
        return creditNote_list

    @staticmethod
    def getCreditNoteById(requestID):
        logger.addinfo('@ models - creditnotes - getCreditNoteById(+)')
        creditNote = {}
        final = {}
        creditNote_list = []
        connection = None
        cursor = None
        count = 0
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["get_credit_note_by_id"]
            cursor.execute(query, p_reqid=requestID)
            tmpcreditNote = cursor.fetchall()
            if len(tmpcreditNote) > 0:
                count = 1
                CreditNoteIDFields = [a[0].lower() for a in cursor.description]
                for index, fn in enumerate(CreditNoteIDFields):
                    value = tmpcreditNote[0][index]
                    if fn == "request_id":
                        linesQuery = sql_file['CreditNote_lines_query']
                        cursor.execute(linesQuery, p_requestId=value)
                        creditNotelines = []
                        creditLiFn = [a[0].lower() for a in cursor.description]
                        fTypes = [a[1] for a in cursor.description]
                        tmpCn = {}
                        creditNotelines.append(setHeader(creditLiFn, fTypes,
                                                         tmpCn))
                        for creditLine in cursor:
                            result = {}
                            for index, field in enumerate(creditLiFn):
                                result[field] = creditLine[index]
                            creditNotelines.append(result)
                        creditNote["lines"] = creditNotelines
                        creditNote["request_id"] = value
                    elif fn == "cust_account_id":
                        customerNameQuery = sql_file["CustomerNameById"]
                        cursor.execute(customerNameQuery, p_Accountid=value)
                        customerName = cursor.fetchall()
                        custName = [cust for cust in customerName[0]]
                        if customerName:
                            creditNote["cust_acc_id"] = value
                            creditNote["Customer"] = custName[0]
                    elif fn == "receipt_method_id":
                        transactionTypeQuery = sql_file["PaymentReceMethodId"]
                        cursor.execute(transactionTypeQuery,
                                       p_receiptMethodId=value)
                        paymentName = cursor.fetchall()
                        payment = ""
                        if paymentName:
                            payment = [pay for pay in paymentName[0]]
                        if payment:
                            creditNote["receipt_method_id"] = value
                            creditNote["payment_method"] = payment[0]
                    elif fn == "cust_trx_type_id":
                        transactionTypeQuery = sql_file["transactionTypeById"]
                        cursor.execute(transactionTypeQuery,
                                       p_custTrxId=value)
                        transactionType = cursor.fetchall()
                        transaction = [trans for trans in transactionType[0]]
                        if transaction:
                            creditNote["transaction_id"] = value
                            creditNote["transaction_type"] = transaction[0]
                    else:
                        creditNote[fn] = tmpcreditNote[0][index]
                attachments = []
                cursor.execute(sql_file['attachmnt_byid'], preq_id=requestID)
                attachmentsFn = [a[0].lower() for a in cursor.description]
                for attachment in cursor:
                    data = {}
                    for index, fn in enumerate(attachmentsFn):
                        if fn == 'file_content':
                            encoded_string = base64.b64encode(attachment[
                                                              index].read())
                            data[fn] = encoded_string.decode('utf-8')
                        else:
                            data[fn] = attachment[index]
                    attachments.append(data)
                creditNote["attachments"] = attachments
                creditNote_list.append(creditNote)
            else:
                final['status'] = 1
                final['msg'] = 'Credit Note #' + str(requestID) + ' not found'
                send_log('getCreditNoteById', final['msg'], {
                    'requestID': requestID})
        except Exception as error:
            logger.findaylog("""@ 123 EXCEPTION - models - creditnotes -
                 getCreditNoteById """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - getCreditNoteById(-)')
        if count == 0:
            return final
        else:
            return creditNote_list

    @staticmethod
    def getReasons(lang):
        cm_reasons = []
        logger.addinfo('@ models - creditnotes - getReasons(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            if not lang:
                lang = 'American'
            elif lang == 'IT':
                lang = 'Italian'
            elif lang == 'DE':
                lang = 'German'
            elif lang == 'FR':
                lang = 'French'
            elif lang == 'EN':
                lang = 'American'
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=" + str(lang))
            query = sql_file["CmReasonsQuery"]
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 162 EXCEPTION - models - creditnotes -
                 getReasons """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for reason in cursor:
                tmpReason = {}
                for index, fn in enumerate(fieldnames):
                    tmpReason[fn] = reason[index]
                cm_reasons.append(tmpReason)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - getReasons(-)')
        return cm_reasons

    @staticmethod
    def getDebitTo():
        logger.addinfo('@ models - creditnotes - getDebitTo(+)')
        cm_DebitTo = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["cmDebitTo"]
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 192 EXCEPTION - models - creditnotes -
                 getDebitTo """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for debitTo in cursor:
                tmpDebitTo = {}
                for index, fn in enumerate(fieldnames):
                    tmpDebitTo[fn] = debitTo[index]
                cm_DebitTo.append(tmpDebitTo)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - getDebitTo(-)')
        return cm_DebitTo

    @staticmethod
    def getItems(org_id):
        logger.addinfo('@ models - creditnotes - getItems(+)')
        cm_Items = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["cm_Items_Query"]
            cursor.execute(query, p_org_id=org_id)
        except Exception as error:
            logger.findaylog("""@ 222 EXCEPTION - models - creditnotes -
                 getItems """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for item in cursor:
                tmpItem = {}
                for index, fn in enumerate(fieldnames):
                    tmpItem[fn] = item[index]
                cm_Items.append(tmpItem)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - getItems(-)')
        return cm_Items

    @staticmethod
    def getTransactionTypes(porg_id):
        logger.addinfo('@ models - creditnotes - getTransactionTypes(+)')
        cm_TransactionTypes = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            query = sql_file["cm_transactionType_query"]
            cursor.execute(query, p_org_id=porg_id)
        except Exception as error:
            logger.findaylog("""@ 252 EXCEPTION - models - creditnotes -
                 getTransactionTypes """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for trxType in cursor:
                tmptrx = {}
                for index, fn in enumerate(fieldnames):
                    tmptrx[fn] = trxType[index]
                cm_TransactionTypes.append(tmptrx)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - getTransactionTypes(-)')
        return cm_TransactionTypes

    # generate HeaderId
    @staticmethod
    def get_header_id():
        logger.addinfo("@ models - creditnotes - get_header_id(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['request_id_sequence']
            data = cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 282 EXCEPTION - models - creditnotes -
             get_header_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - creditnotes - get_header_id(-)")
        return header_id

    # generate HeaderId
    @staticmethod
    def get_line_id():
        logger.addinfo("@ models - creditnotes - get_line_id(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['line_id_query']
            data = cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 305 EXCEPTION - models - creditnotes -
             get_line_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - creditnotes - get_line_id(-)")
        return header_id

    @staticmethod
    def insertCreditNote(header, lines):
        logger.addinfo('@ models - creditnotes - insertCreditNote(+)')
        qty_array = []
        price_array = []
        amount_array = []
        attribute1_array = []
        attribute2_array = []
        attribute3_array = []
        attribute4_array = []
        attribute5_array = []
        attribute6_array = []
        trx_line_id_array = []
        attachment_result = []
        for i in lines:
            qty_array.append(i['quantity'])
            price_array.append(round(float(i['price']), 2))
            amount_array.append(round(float(i['extended_amount']), 2))
            attribute1_array.append(i['ATTRIBUTE1'])
            attribute2_array.append(i['ATTRIBUTE2'])
            attribute3_array.append(i['ATTRIBUTE3'])
            attribute4_array.append(i['ATTRIBUTE4'])
            attribute5_array.append(i['ATTRIBUTE5'])
            attribute6_array.append(i.get('ATTRIBUTE6'))
        for i in range(0, len(attribute1_array)):
            if qty_array[i] == '':
                qty_array[i] = -100
            attribute1_array[i] = ujson.dumps(attribute1_array[i])
            attribute1_array[i] = attribute1_array[i][1:-1]
            attribute2_array[i] = ujson.dumps(attribute2_array[i])
            attribute2_array[i] = attribute2_array[i][1:-1]
            attribute3_array[i] = ujson.dumps(attribute3_array[i])
            attribute3_array[i] = attribute3_array[i][1:-1]
            attribute4_array[i] = ujson.dumps(attribute4_array[i])
            attribute4_array[i] = attribute4_array[i][1:-1]
            attribute5_array[i] = ujson.dumps(attribute5_array[i])
            attribute5_array[i] = attribute5_array[i][1:-1]
            attribute6_array[i] = ujson.dumps(attribute6_array[i])
            attribute6_array[i] = attribute6_array[i][1:-1]
        if header['customer_trx_id'] == -100:
            for i in range(0, len(lines)):
                trx_line_id_array.append(int(CreditNote.get_line_id()))
        else:
            for i in lines:
                trx_line_id_array.append(i['customer_trx_line_id'])
        customer_trx_id = header['customer_trx_id']
        org_id = header['org_id']
        created_by = header['created_by']
        ATTRIBUTE1 = header['ATTRIBUTE1']
        ATTRIBUTE2 = header['ATTRIBUTE2']
        ATTRIBUTE3 = header['ATTRIBUTE3']
        ATTRIBUTE5 = header['ATTRIBUTE5']
        ATTRIBUTE4 = header['ATTRIBUTE4']
        ATTRIBUTE6 = header['ATTRIBUTE6']
        ATTRIBUTE8 = header['ATTRIBUTE8']
        ATTRIBUTE9 = header['ATTRIBUTE9']
        ATTRIBUTE10 = header['ATTRIBUTE10']
        ATTRIBUTE11 = header['ATTRIBUTE11']
        ATTRIBUTE12 = header['ATTRIBUTE12']
        ATTRIBUTE13 = header['ATTRIBUTE13']
        ATTRIBUTE14 = header.get('ATTRIBUTE14')
        COMMENTS = header['COMMENTS']
        internal_comment = header['internal_comment']
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            status = cur.var(cx_Oracle.STRING)
            message = cur.var(cx_Oracle.STRING)
            request_id = cur.var(cx_Oracle.NUMBER)
            cur.execute("""
                          declare\
                          l_status VARCHAR2(1000);\
                          l_return_code varchar2(30);\
                          l_msg varchar2(150);\
                          l_request_id number;\
                          cm_header qpex_creditnotes_pkg.cm_header_rec_type;\
                          cm_lines
                                qpex_creditnotes_pkg.Cm_Line_Tbl_Type_Cover;\
                          type d_jtf_number_table_t is table of number
                                index by binary_integer;\
                          type t_jtf_number_table_t is table of VARCHAR2(150)
                                index by binary_integer;\
                          trx_jtf d_jtf_number_table_t := :p_trx_array;\
                          qty_jtf d_jtf_number_table_t := :p_qty_array;\
                          price_jtf d_jtf_number_table_t:= :p_price_array;\
                          amount_jtf d_jtf_number_table_t:= :p_amount_array;\
                          attribute1_jtf t_jtf_number_table_t:=
                                                :p_attribute1_array;\
                          attribute2_jtf t_jtf_number_table_t:=
                                                :p_attribute2_array;\
                          attribute3_jtf t_jtf_number_table_t:=
                                                :p_attribute3_array;\
                          attribute4_jtf t_jtf_number_table_t:=
                                                :p_attribute4_array;\
                          attribute5_jtf t_jtf_number_table_t:=
                                                :p_attribute5_array;\
                          attribute6_jtf t_jtf_number_table_t:=
                                                :p_attribute6_array;\

                          begin\
                          cm_header.user_id := :p_created_by;\
                          cm_header.customer_trx_id := :p_customer_trx_id;\
                          cm_header.cm_reason_code := :p_ATTRIBUTE6;\
                          cm_header.comments := :p_COMMENTS;\

                          cm_header.internal_comment := :p_internal_comment;\
                          cm_header.org_id := :p_org_id;\
                          cm_header.cust_trx_type_id := :p_ATTRIBUTE1;\
                          cm_header.customer_id := :p_ATTRIBUTE2;\
                          cm_header.bill_to_site_use_id := :p_ATTRIBUTE3;\
                          cm_header.ship_to_site_use_id := :p_ATTRIBUTE4;\
                          cm_header.currency_code := :p_ATTRIBUTE5;\
                          cm_header.reason_code := :p_ATTRIBUTE6;\
                          cm_header.debit_to := :p_ATTRIBUTE8;\
                          cm_header.apply_creditnote_to := :p_ATTRIBUTE9;\
                          cm_header.receipt_method_id := :p_ATTRIBUTE10;\
                          cm_header.No_salesrep_flag := :p_ATTRIBUTE11;\
                          cm_header.Accured_currenct_year_flag :=
                                                        :p_ATTRIBUTE12;\
                          cm_header.Ic_credit_flag := :p_ATTRIBUTE13;\
                          cm_header.related_to_objectives := :p_ATTRIBUTE14;\

                          FOR i in 1.. qty_jtf.count LOOP
                            cm_lines(i).customer_trx_line_id := trx_jtf(i);
                            IF ( qty_jtf(i) = -100  ) THEN
                                cm_lines(i).quantity_credited := NULL;
                            ELSE
                                cm_lines(i).quantity_credited := qty_jtf(i);
                            END IF;
                            cm_lines(i).price := price_jtf(i);
                            cm_lines(i).extended_amount := amount_jtf(i);
                            cm_lines(i).ATTRIBUTE1 := attribute1_jtf(i);
                            cm_lines(i).ATTRIBUTE2 := attribute2_jtf(i);
                            cm_lines(i).ATTRIBUTE3 := attribute3_jtf(i);
                            cm_lines(i).ATTRIBUTE4 := attribute4_jtf(i);
                            cm_lines(i).ATTRIBUTE5 := attribute5_jtf(i);
                            cm_lines(i).ATTRIBUTE6 := attribute6_jtf(i);
                          END LOOP;\

                          QPEX_CREDITNOTES_PKG.ar_request_cm
                          (cm_header , cm_lines,:p_request_id,:p_status,
                          :p_message);

                          commit;
                          end;""", p_org_id=org_id,
                        p_customer_trx_id=customer_trx_id,
                        p_created_by=created_by, p_ATTRIBUTE1=ATTRIBUTE1,
                        p_ATTRIBUTE2=ATTRIBUTE2, p_ATTRIBUTE3=ATTRIBUTE3,
                        p_ATTRIBUTE4=ATTRIBUTE4, p_ATTRIBUTE5=ATTRIBUTE5,
                        p_ATTRIBUTE6=ATTRIBUTE6, p_ATTRIBUTE8=ATTRIBUTE8,
                        p_ATTRIBUTE9=ATTRIBUTE9,
                        p_ATTRIBUTE10=ATTRIBUTE10, p_ATTRIBUTE11=ATTRIBUTE11,
                        p_ATTRIBUTE12=ATTRIBUTE12, p_ATTRIBUTE13=ATTRIBUTE13,
                        p_ATTRIBUTE14=ATTRIBUTE14,
                        p_COMMENTS=COMMENTS,
                        p_internal_comment=internal_comment,
                        p_qty_array=qty_array, p_price_array=price_array,
                        p_amount_array=amount_array, p_request_id=request_id,
                        p_trx_array=trx_line_id_array,
                        p_status=status, p_message=message,
                        p_attribute1_array=attribute1_array,
                        p_attribute2_array=attribute2_array,
                        p_attribute3_array=attribute3_array,
                        p_attribute4_array=attribute4_array,
                        p_attribute5_array=attribute5_array,
                        p_attribute6_array=attribute6_array)
            if status.getvalue() == 'S':
                req_id = int(request_id.getvalue())
                attachments = header['files']
                if attachments:
                    for attachment in attachments:
                        attachment_obj = {'filename': attachment['filename'],
                                          'file_id': ''}
                        attachment_obj[
                            'file_id'] = CreditNote.insert_attachment(
                            req_id,
                            attachment['base64'],
                            attachment['filename'])
                        attachment_result.append(attachment_obj)
                if header.get('status') == 'DRAFT':
                    query = sql_file['update_credit_note_to_draft']
                    cur.execute(query, p_request_id=req_id, p_status='DRAFT')
                    con.commit()
                    package_return = {'status': 0, 'msg': 'Credit Memo created successfully',
                                      'header_id': req_id, 'attachment_result': attachment_result}
                else:
                    package_return = CreditNote.package_save(req_id)
                    package_return['attachment_result'] = attachment_result
            else:
                package_return = {'msg': message.getvalue(), 'status': 1}
        except Exception as error:
            logger.findaylog("""@ 443 EXCEPTION - models - creditnotes -
                 insertCreditNote """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - creditnotes - insertCreditNote(-)')
        return package_return

    @staticmethod
    def insert_CreditNoteLines(pcreditnote_lines_list, request_id):
        logger.addinfo('@ models - creditnotes - insert_CreditNoteLines(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            for cn_line in pcreditnote_lines_list:
                if 'customer_trx_line_id' not in cn_line:
                    query = sql_file['line_id_query']
                    cur = connection.cursor()
                    data = cur.execute(query).fetchone()
                    cur.close()
                    cn_line['customer_trx_line_id'] = data[0]
                cn_line['request_id'] = request_id
                values = ""
                values = tuple(str(val) for key, val in cn_line.items())
                row_list.append(values)
            if pcreditnote_lines_list:
                dict_val = pcreditnote_lines_list[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            cursor.prepare("""insert into
            RA_CM_REQUEST_LINES_ALL """ + fieldname_strng+"""
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
            connection.commit()
        except Exception as error:
            logger.findaylog("""@ 494 EXCEPTION - models - creditnotes -
                 insert_CreditNoteLines """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - insert_CreditNoteLines(-)')

    @staticmethod
    def insert_attachment(preq_id, pbase64, pfilename):
        logger.addinfo('@ models - creditnotes - insert_attachment(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            sql_file = db_util.getSqlData()
            cur = con.cursor()
            query = sql_file['attachments_insert']
            file_id_query = sql_file['attachment_sequence']
            data = cur.execute(file_id_query).fetchone()
            file_id = data[0]
            if type(pfilename) == str or type(pfilename) == str:
                pfilename = pfilename.replace("'", "''")
            attachmentQuery = query % (file_id, pfilename, preq_id, 'N')
            cur.setinputsizes(blobData=cx_Oracle.BLOB)
            cur.execute(attachmentQuery,
                        {'blobData': base64.b64decode(pbase64)})
            con.commit()
        except Exception as error:
            logger.findaylog("""@ 523 EXCEPTION - models - creditnotes -
                 insert_attachment """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - creditnotes - insert_attachment(-)')
        return file_id

    @staticmethod
    def package_save(header_id):
        logger.addinfo('@ models - creditnotes - package_save(+)')
        con = None
        cur = None
        returnval = {}
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            return_value = cur.var(cx_Oracle.STRING)
            err_message = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
            QPEX_CM_APPR_PKG.START_CM_PROCESS(:P_REQUEST_ID,:submit_wf_status,
            :submit_wf_message);
            end;""", P_REQUEST_ID=header_id, submit_wf_status=return_value,
                        submit_wf_message=err_message)
        except Exception as error:
            logger.findaylog("""@ 550 EXCEPTION - models - creditnotes -
                 package_save """ + str(error))
            raise error
        else:
            if return_value.getvalue() == 'S':
                returnval['msg'] = "Credit Memo created successfully"
                returnval['status'] = 0
                returnval['header_id'] = header_id
            else:
                returnval['msg'] = err_message.getvalue()
                returnval['status'] = 1
                returnval['header_id'] = ""
                send_log('package_save', err_message.getvalue(), {
                    'header_id': header_id})
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - creditnotes - package_save(-)')
        return returnval

    @staticmethod
    @db_util.langs("American")
    def creditnote_search(conditiondict):
        logger.addinfo('@ models - creditnotes - creditnote_search(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        creditnote_datalst = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            sql_file = db_util.getSqlData()
            query = sql_file['creditnote_search']
            query_temp = CreditNote.getconditionqry(query, conditiondict)
            cursor.execute(query_temp)
        except Exception as error:
            logger.findaylog("""@ 583 EXCEPTION - models - creditnotes -
                 creditnote_search """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                creditnote_data = {}
                for index, fn in enumerate(fieldnames):
                    creditnote_data[fn] = row[index]
                creditnote_datalst.append(creditnote_data)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - creditnote_search(-)')
        return creditnote_datalst

    @staticmethod
    def getconditionqry(qry, conditiondict):
        logger.addinfo('@ models - creditnotes - getconditionqry(+)')
        for key, value in conditiondict.items():
            if 'customer_number' == key:
                qry += " and account_number = '{0}'".format(value)
            elif "status" == key:
                if value != "all":
                    qry += " and "
                    qry += " lower("
                    qry += str(key)+")"+" = "+"lower('"+str(value)+"')"
            elif "request_id" == key:
                qry += " and "
                qry += str(key)+"="+"'"+str(value)+"'"
            elif 'org_id' == key:
                qry += ' and {0} = {1}'.format(key, value)
            elif 'no_salesrep_flag' == key:
                qry += " and {0} = '{1}'".format(key, value)
            elif "start_date" == key:
                qry += " and "
                st_date = "'"+conditiondict['start_date']+"'"
                en_date = "'"+conditiondict['end_date']+"'"
                qry += """trunc(requested_date, 'dd')
                        between to_date("""+st_date+"""
                        ,'dd-MON-yyyy') and
                        to_date("""+en_date+""", 'dd-MON-yyyy')"""
        logger.addinfo('@ models - creditnotes - getconditionqry(-)')
        return qry

    @staticmethod
    def update_cm(jsond):
        logger.addinfo('@ models - creditnotes - update_cm(+)')
        connection = None
        attachment_result = []
        result = {}
        try:
            connection = db_util.get_connection()
            cur = connection.cursor()
            if len(jsond['deletedAttachments']['file_ids']) > 0:
                delete_attachment(jsond['deletedAttachments'])
            if jsond['attachments']:
                attachments = jsond['attachments']
                for i in range(len(jsond['attachments'])):
                    attachment_obj = {'filename': '', 'file_id': ''}
                    attachment_obj['filename'] = attachments[i]['filename']
                    attachment_obj['file_id'] = CreditNote.insert_attachment(
                        jsond['request_id'],
                        attachments[i]['base64'],
                        attachments[i]['filename'])
                    attachment_result.append(attachment_obj)
            if 'update_lines' in jsond and len(jsond['update_lines']) > 0:
                update_lines(jsond['request_id'])
            if jsond.get('delete_lines') and jsond['delete_lines'] > 0:
                CreditNote.delete_cm_lines(jsond['delete_lines'])
            if jsond.get('credit_lines'):
                CreditNote.update_creditnote_lines(jsond)
            attribute1 = jsond['ATTRIBUTE1']
            attribute2 = jsond['ATTRIBUTE2']
            attribute3 = jsond['ATTRIBUTE3']
            attribute4 = jsond['ATTRIBUTE4']
            attribute6 = jsond['ATTRIBUTE6']
            attribute8 = jsond['ATTRIBUTE8']
            attribute9 = jsond['ATTRIBUTE9']
            attribute10 = jsond['ATTRIBUTE10']
            attribute11 = jsond['ATTRIBUTE11']
            attribute12 = jsond['ATTRIBUTE12']
            attribute13 = jsond['ATTRIBUTE13']
            attribute14 = jsond.get('ATTRIBUTE14')
            comments = jsond['COMMENTS']
            internal_comment = jsond['internal_comment']
            cm_reason_code = jsond['cm_reason_code']
            request_id = jsond['request_id']
            status = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
            QPEX_CREDITNOTES_PKG.update_creditnote(:p_attribute1,
            :p_attribute2, :p_attribute3, :p_attribute4,
            :p_attribute6,:p_attribute8, :p_attribute9, :p_attribute10,
            :p_attribute11,:p_attribute12, :p_attribute13,:p_attribute14,
            :p_comments,
            :p_internal_comment,:p_reason_code,:p_request_id,:p_status);
            end;""", p_attribute1=attribute1,
                        p_attribute2=attribute2,
                        p_attribute3=attribute3,
                        p_attribute4=attribute4,
                        p_attribute6=attribute6,
                        p_attribute8=attribute8, p_attribute9=attribute9,
                        p_attribute10=attribute10, p_attribute11=attribute11,
                        p_attribute12=attribute12, p_attribute13=attribute13,
                        p_attribute14=attribute14,
                        p_comments=comments,
                        p_internal_comment=internal_comment,
                        p_reason_code=cm_reason_code, p_request_id=request_id,
                        p_status=status)
            if status.getvalue() == 'SUCCESS':
                if jsond.get('status') == 'DRAFT' and jsond.get('is_submit') is True:
                    sql_file = db_util.getSqlData()
                    query = sql_file['update_credit_note_to_draft']
                    cur.execute(query, p_request_id=request_id, p_status='PENDING_APPROVAL')
                    connection.commit()
                    result = CreditNote.package_save(request_id)
                    result['attachment_result'] = attachment_result
                    if result['status'] == 0:
                        result['msg'] = 'success'
                    else:
                        result['msg'] = 'fails'
                else:
                    result = {'msg': 'success', 'attachment_result': attachment_result}
            else:
                send_log('update_cm', status.getvalue(), jsond)
                result = {'msg': 'fails'}

        except Exception as error:
            logger.findaylog("""@ 646 EXCEPTION - models - creditnotes -
                 update_cm """ + str(error))
            raise error
        finally:
            connection.commit()
            cur.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - update_cm(-)')
        return result

    @staticmethod
    def update_creditnote_lines(jsond):
        logger.addinfo('@ models - creditnotes - update_creditnote_lines(+)')
        try:
            result = {}
            qty_array = []
            price_array = []
            amount_array = []
            attribute1_array = []
            attribute2_array = []
            attribute3_array = []
            attribute4_array = []
            attribute5_array = []
            attribute6_array = []
            trx_line_id_array = []
            lines = jsond['credit_lines']
            for i in lines:
                qty_array.append(i['quantity'])
                price_array.append(round(float(i['price']), 2))
                amount_array.append(round(float(i['extended_amount']), 2))
                attribute1_array.append(i['ATTRIBUTE1'])
                attribute2_array.append(i['ATTRIBUTE2'])
                attribute3_array.append(i['ATTRIBUTE3'])
                attribute4_array.append(i['ATTRIBUTE4'])
                attribute5_array.append(i['ATTRIBUTE5'])
                attribute6_array.append(i.get('ATTRIBUTE6'))
            for i in range(0, len(attribute1_array)):
                if qty_array[i] == '':
                    qty_array[i] = -100
                attribute1_array[i] = ujson.dumps(attribute1_array[i])
                attribute1_array[i] = attribute1_array[i][1:-1]
                attribute2_array[i] = ujson.dumps(attribute2_array[i])
                attribute2_array[i] = attribute2_array[i][1:-1]
                attribute3_array[i] = ujson.dumps(attribute3_array[i])
                attribute3_array[i] = attribute3_array[i][1:-1]
                attribute4_array[i] = ujson.dumps(attribute4_array[i])
                attribute4_array[i] = attribute4_array[i][1:-1]
                attribute5_array[i] = ujson.dumps(attribute5_array[i])
                attribute5_array[i] = attribute5_array[i][1:-1]
                attribute6_array[i] = ujson.dumps(attribute6_array[i])
                attribute6_array[i] = attribute6_array[i][1:-1]

            for i in lines:
                if i['customer_trx_line_id']:
                    trx_line_id_array.append(i['customer_trx_line_id'])
                else:
                    trx_line_id_array.append(int(CreditNote.get_line_id()))
            with OracleConnectionManager() as conn:
                status = conn.cursor.var(cx_Oracle.STRING)
                request_id = jsond['request_id']
                conn.cursor.execute("""
                                        declare\
                                        l_status VARCHAR2(1000);\
                                        l_return_code varchar2(30);\
                                        l_msg varchar2(150);\
                                        l_request_id number;\
                                cm_lines
                                    qpex_creditnotes_pkg.Cm_Line_Tbl_Type_Cover;\
                              type d_jtf_number_table_t is table of number
                                    index by binary_integer;\
                              type t_jtf_number_table_t is table of VARCHAR2(150)
                                    index by binary_integer;\
                              trx_jtf d_jtf_number_table_t := :p_trx_array;\
                              qty_jtf d_jtf_number_table_t := :p_qty_array;\
                              price_jtf d_jtf_number_table_t:= :p_price_array;\
                              amount_jtf d_jtf_number_table_t:= :p_amount_array;\
                              attribute1_jtf t_jtf_number_table_t:=
                                                    :p_attribute1_array;\
                              attribute2_jtf t_jtf_number_table_t:=
                                                    :p_attribute2_array;\
                              attribute3_jtf t_jtf_number_table_t:=
                                                    :p_attribute3_array;\
                              attribute4_jtf t_jtf_number_table_t:=
                                                    :p_attribute4_array;\
                              attribute5_jtf t_jtf_number_table_t:=
                                                    :p_attribute5_array;\
                              attribute6_jtf t_jtf_number_table_t:=
                                                    :p_attribute6_array;\

                              begin\

                              FOR i in 1.. qty_jtf.count LOOP
                                cm_lines(i).customer_trx_line_id := trx_jtf(i);
                                IF ( qty_jtf(i) = -100  ) THEN
                                    cm_lines(i).quantity_credited := NULL;
                                ELSE
                                    cm_lines(i).quantity_credited := qty_jtf(i);
                                END IF;
                                cm_lines(i).price := price_jtf(i);
                                cm_lines(i).extended_amount := amount_jtf(i);
                                cm_lines(i).ATTRIBUTE1 := attribute1_jtf(i);
                                cm_lines(i).ATTRIBUTE2 := attribute2_jtf(i);
                                cm_lines(i).ATTRIBUTE3 := attribute3_jtf(i);
                                cm_lines(i).ATTRIBUTE4 := attribute4_jtf(i);
                                cm_lines(i).ATTRIBUTE5 := attribute5_jtf(i);
                                cm_lines(i).ATTRIBUTE6 := attribute6_jtf(i);
                              END LOOP;\

                              QPEX_CREDITNOTES_PKG.update_creditnote_lines
                              (cm_lines,:p_request_id, :p_user_id, :p_org_id, :x_status);
                              commit;
                            end;""", p_org_id=jsond['org_id'],
                                    p_qty_array=qty_array, p_price_array=price_array,
                                    p_amount_array=amount_array, p_request_id=request_id,
                                    p_trx_array=trx_line_id_array,
                                    x_status=status, p_user_id=jsond['user_id'],
                                    p_attribute1_array=attribute1_array,
                                    p_attribute2_array=attribute2_array,
                                    p_attribute3_array=attribute3_array,
                                    p_attribute4_array=attribute4_array,
                                    p_attribute5_array=attribute5_array,
                                    p_attribute6_array=attribute6_array)
            if status.getvalue() == 'S':
                result = {'msg': 'success'}
            else:
                send_log('update_creditnote_lines', status.getvalue(), jsond)
                result = {'msg': 'fails'}

        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - creditnotes -
                 update_creditnote_lines """ + str(error))
            raise error
        logger.addinfo('@ models - creditnotes - update_creditnote_lines(-)')
        return result

    @staticmethod
    def delete_cm_lines(jsond):
        logger.addinfo('@ models - creditnotes - delete_cm_lines (+)')
        try:
            result = ''
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                for line in jsond:
                    conn.cursor.execute("""
                        begin \
                            QPEX_CREDITNOTES_PKG.delete_cn_product_lines(
                                :p_request_id,
                                :p_customer_trx_line_id,
                                :x_status
                            );
                            commit;
                        end;""", p_request_id=line['request_id'],
                                        p_customer_trx_line_id=line['customer_trx_line_id'],
                                        x_status=status_code)
                if status_code.getvalue() == 'S':
                    result = 'SUCCESS'
                else:
                    result = 'FAIL'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - creditnotes -
                 delete_cm_lines """ + str(error))
            raise error
        logger.addinfo('@ models - creditnotes - delete_cm_lines(-)')
        return result

    @staticmethod
    def delete_cm(request_id, status):
        logger.addinfo('@ models - creditnotes - delete_cm(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_creditnotes_pkg.delete_credit_note(
                    :p_request_id,
                    :p_status,                                                                                  
                    :p_status_code
                );
            end; """, p_request_id=request_id, p_status=status,
                           p_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ 673 EXCEPTION - models - creditnotes -
                 delete_cm """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - creditnotes - delete_cm(-)')
        return status_code.getvalue()

    @staticmethod
    def get_customer_req_ids(cust_acc_id):
        """
        For getting list of credit note ids based on customer
        :param cust_acc_id: number
        :return result: {'status': '', 'result':''}
        """
        logger.addinfo('@ models - creditnotes - get_customer_req_ids(+)')
        try:
            result = {}
            with OracleConnectionManager() as conn:
                sql_file = db_util.getSqlData()
                query = sql_file['get_customer_request_ids']
                conn.execute(query, p_cust_account_id=cust_acc_id)
                result['result'] = conn.get_result()
                result['status'] = Status.OK.value
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - creditnotes -
                 get_customer_req_ids """ + str(error))
            raise error
        logger.addinfo('@ models - creditnotes - get_customer_req_ids(-)')
        return result

    @staticmethod
    def get_customer_invoice(jsond):
        """
        For getting invoice number based on item inventory item
        @param jsond: {
            cust_account_id: number,
            bill_to: number,
            inventory_item_id: number,
            item_code: string,
            period_from: string,
            period_to: string
        }
        @return {"status": "", "invoice_number": "", "inventory_item_id":"", "item_code":""}

        """
        with OracleConnectionManager() as conn:
            invoice_num = conn.cursor.var(cx_Oracle.STRING)
            conn.execute("""
            begin
                 :invoice_number := qpex_creditnotes_pkg.find_inv_for_product(:p_cust_account_id,
                                                       :p_bill_to_suid,
                                                       :p_item_id,
                                                       :p_period_from,
                                                       :p_period_to,
                                                       :x_status);
            end;""", output_key='x_status',
                         p_cust_account_id=jsond['cust_account_id'],
                         p_bill_to_suid=jsond['bill_to'],
                         p_item_id=jsond['inventory_item_id'],
                         p_period_from=jsond['period_from'],
                         p_period_to=jsond['period_to'],
                         invoice_number=invoice_num
                         )
            conn.get_output_param(raise_exception=True, send_email=True)
        return {'status': 0, 'invoice_number': invoice_num.getvalue(),
                'inventory_item_id': jsond['inventory_item_id'],
                'item_code': jsond['item_code']}


def delete_attachment(list):
    logger.addinfo('models - creditnotes - delete_attachment(+)')
    try:
        connection = db_util.get_connection()
        cursor = connection.cursor()
        sql_file = db_util.getSqlData()
        ids = list['file_ids']
        query = sql_file['delete_creditnote_attachment']
        query = query % (',' . join([str(ids[i]) for i in range(len(ids))]))
        cursor.execute(query, p_request_id=list['request_id'])
    except Exception as e:
        logger.findaylog(""" @ 797 EXCEPTION - models - creditnotes -
                         delete_attachment """ + str(e))
        raise e
    finally:
        connection.commit()
        cursor.close()
        db_util.release_connection(connection)
    logger.addinfo('models - creditnotes - delete_attachment(-)')
    return 'success'


def update_lines(request_id):
    logger.addinfo('models - creditnotes - update_lines(+)')
    try:
        connection = db_util.get_connection()
        cursor = connection.cursor()
        return_status = cursor.var(cx_Oracle.STRING)
        return_message = cursor.var(cx_Oracle.STRING)
        cursor.execute("""
        begin
        qpex_creditnotes_pkg.update_lines(:p_request_id, :x_return_value,
        :x_return_msg);
        end;""", p_request_id=request_id,
                       x_return_value=return_status,
                       x_return_msg=return_message)
    except Exception as e:
        logger.findaylog(""" @ 823 EXCEPTION - models - creditnotes -
                         update_lines """ + str(e))
        raise e
    finally:
        connection.commit()
        cursor.close()
        db_util.release_connection(connection)
    logger.addinfo('models - creditnotes - update_lines(-)')
    if return_status.getvalue() == 'S':
        return 'success'
    return 'error'


def setHeader(fieldnames, field_types, Object):
    logger.addinfo('@ models - creditnotes - setHeader(+)')
    for index, fn in enumerate(fieldnames):
        type_str = str(field_types[index])
        for ch in ['cx_Oracle', '.', '<', '>', '\'', 'type']:
            if ch in type_str:
                type_str = type_str.replace(ch, "")
        type_str = type_str.strip()
        Object[fn] = type_str
    logger.addinfo('@ models - creditnotes - setHeader(-)')
    return Object


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'creditnotes',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
