
from finapi.utils import db_util
from finapi.utils.logdata import logger


class Slokam:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_details():
        logger.addinfo('@ models - slokam - get_details(+)')
        return_data = []
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.execute("""SELECT
                invoice_id,
                i.invoice_date,
                to_char(i.invoice_date,'YYYY') invoice_year,
                to_char(i.invoice_date,'MON-YY') invoice_period,
                i.invoice_num,
                i.invoice_amount,
                i.amount_paid,
                vendor_name,
                segment1 vendor_num
            FROM ap_invoices_all i, ap_suppliers s
            WHERE     i.vendor_id = s.vendor_id
            AND invoice_date BETWEEN '01-JAN-14' AND TRUNC (SYSDATE)
            AND rownum <= 100""")
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - models - slokam -
                 get_details """ + str(error.message))
            raise error
        else:
            for row in cursor:
                d = {}
                d['InvoiceId'] = row[0]  # .invoice_id
                d['InvoiceDate'] = row[1]  # ]invoice_date
                d['InvoiceYear'] = row[2]  # invoice_year
                d['InvoicePeriod'] = row[3]  # .invoice_period
                d['InvoiceNum'] = row[4]  # .invoice_num
                d['InvoiceAmount'] = row[5]  # .invoice_amount
                d['AmountPaid'] = row[6]  # amount_paid
                d['VendorName'] = row[7]  # vendor_name
                d['VendorNum'] = row[8]  # vendor_num
                return_data.append(d)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - slokam - get_details(-)')
        return return_data
