from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil


class OrderType:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    #  used in cutomer to get ordertypes of organization
    @staticmethod
    def get_order_types(porgid):
        logger.addinfo('@ models - ordertype - get_order_types(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['ordertypeSelect']
            cur.execute(query, P_ORG_ID=porgid)
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - models - ordertype -
                 get_order_types """ + str(error))
            raise error
        else:
            ortype_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                order_type = {}
                for index, fn in enumerate(field_names):
                    order_type[fn] = row[index]
                ortype_list.append(order_type)
            order_dict = {'order_types': ortype_list}
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - ordertype - get_order_types(-)')
        return order_dict

    #  used in cutomer to get ordertypes of organization
    @staticmethod
    def get_defalutordr(porgid):
        logger.addinfo('@ models - ordertype - get_defalutordr(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['defalut_ordertype']
            cur.execute(query, P_ORG_ID=porgid)
        except Exception as error:
            logger.findaylog("""@ 56 EXCEPTION - models - ordertype -
                 get_defalutordr """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            order_type = ""
            for row in cur:
                defalutordr_data = {}
                for index, fn in enumerate(field_names):
                    defalutordr_data[fn] = row[index]
                order_type = defalutordr_data
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - ordertype - get_defalutordr(-)')
        return order_type

    @staticmethod
    def get_all_ordertypes(porgid):
        logger.addinfo('@ models - ordertype - get_all_ordertypes(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['order_types_query']
            cur.execute(query, p_org_id=porgid)
        except Exception as error:
            logger.findaylog("""@ 85 EXCEPTION - models - ordertype -
                 get_all_ordertypes """ + str(error))
            raise error
        else:
            ortype_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                order_type = {}
                for index, fn in enumerate(field_names):
                    order_type[fn] = row[index]
                ortype_list.append(order_type)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - ordertype - get_all_ordertypes(-)')
        return ortype_list


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'ordertype',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
