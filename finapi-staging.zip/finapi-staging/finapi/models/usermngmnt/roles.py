from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.models.usermngmnt.method_util import Methodutil


class Roles:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_roles(role_id):
        logger.addinfo('@ models - roles - get_roles(+)')
        try:
            sql_file = db_util.getusermngSql()
            role_qry = sql_file['roles_qry']
            role_list = []
            if role_id:
                role_qry += " where QpexRolesEO.ROLE_ID="+str(role_id)
                role_list = Methodutil.get_qry(role_qry)
                role_perms = Roles.get_role_withperm(role_id)
                for value in role_list:
                    value['role_permissions'] = role_perms
            else:
                role_list = Methodutil.get_qry(role_qry)
        except Exception as error:
            logger.findaylog("""@ 30 EXCEPTION - models - roles -
                 get_roles """ + str(error))
            raise error
        logger.addinfo('@ models - roles - get_roles(-)')
        return role_list

    @staticmethod
    def get_role_withperm(role_id):
        logger.addinfo('@ models - roles - get_role_withperm(+)')
        try:
            sql_file = db_util.getusermngSql()
            rperm_qry = sql_file['role_permissions']
            if role_id:
                rperm_qry += " and QpexRolePermissionsEO.ROLE_ID="+str(role_id)
            roleperm_data = Methodutil.get_qry(rperm_qry)
        except Exception as error:
            logger.findaylog("""@ 46 EXCEPTION - models - roles -
                 get_role_withperm """ + str(error))
            raise error
        logger.addinfo('@ models - roles - get_role_withperm(-)')
        return roleperm_data

    @staticmethod
    def get_permlov():
        logger.addinfo('@ models - roles - get_permlov(+)')
        return_data = []
        try:
            sql_file = db_util.getusermngSql()
            return_data = Methodutil.get_qry(sql_file['role_permissionLOV'])
        except Exception as error:
            logger.findaylog("""@ 60 EXCEPTION - models - roles -
                 get_permlov """ + str(error))
            raise error
        logger.addinfo('@ models - roles - get_permlov(-)')
        return return_data

    @staticmethod
    def save(list_val, seqval, ptype):
        logger.addinfo('@ models - roles - save(+)')
        returnmsg = ""
        tablename = ""
        try:
            if ptype == "permission":
                tablename = "QPEX_ROLE_PERMISSIONS"
            elif ptype == "role":
                tablename = "QPEX_ROLES"
            returnmsg = Methodutil.save(list_val, tablename,
                                        "ROLE_ID", seqval)
        except Exception as error:
            logger.findaylog("""@ 79 EXCEPTION - models - roles -
                 save """ + str(error))
            raise error
        logger.addinfo('@ models - roles - save(-)')
        return returnmsg

    @staticmethod
    def get_roleseq():
        logger.addinfo('@ models - roles - get_roleseq(+)')
        data = ""
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getusermngSql()
            query = sql_file['role_seq']
            data = cur.execute(query).fetchone()
        except Exception as error:
            logger.findaylog("""@ 98 EXCEPTION - models - roles -
                 get_roleseq """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - roles - get_roleseq(-)')
        return str(data[0])

    @staticmethod
    def update(list_val, ptype, role_id):
        logger.addinfo('@ models - roles - update(+)')
        returnmsg = ""
        tablename = ""
        try:
            if ptype == "permission":
                tablename = "QPEX_ROLE_PERMISSIONS"
                permission = list_val
                perm_id = permission['permission_id']
                condition = " where ROLE_ID="+str(
                            role_id)+" and permission_id="+str(perm_id)
            elif ptype == "role":
                tablename = "QPEX_ROLES"
                condition = " where ROLE_ID="+str(role_id)
            returnmsg = Methodutil.update(tablename, list_val, condition)
        except Exception as error:
            logger.findaylog("""@ 124 EXCEPTION - models - roles -
                 update """ + str(error))
            raise error
        logger.addinfo('@ modoles - roles - update(-)')
        return returnmsg

    @staticmethod
    def get_validation(p_val):
        logger.addinfo('@ models - roles - get_validation(+)')
        role_data = {}
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['role_validation']
            role_data = Methodutil.get_validation(qry, p_val)
        except Exception as error:
            logger.findaylog("""@ 139 EXCEPTION - models - roles -
                 get_validation """ + str(error))
            raise error
        logger.addinfo('@ models - roles - get_validation(-)')
        return role_data

    @staticmethod
    def get_role_perm_validation(role_id, perm_id):
        logger.addinfo('@ models - roles - get_role_perm_validation(+)')
        con = None
        cur = None
        mydata = []
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getusermngSql()
            qry = sql_file['role_perm_validation']
            cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            cur.execute(qry, p_role=role_id, p_perm=perm_id)
            mydata = cur.fetchall()
        except Exception as error:
            logger.findaylog("""@ 160 EXCEPTION - models - roles -
                 get_role_perm_validation """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - roles - get_role_perm_validation(-)')
        if mydata:
            return "update"
        else:
            return "save"
