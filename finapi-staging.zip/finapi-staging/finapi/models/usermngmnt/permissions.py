from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.models.usermngmnt.method_util import Methodutil
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.constants import Status
import cx_Oracle
from finapi.utils.code_util import Code_util


class Permissions:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_permissions(p_permid):
        logger.addinfo('@ models - permissions - get_permissions(+)')
        permission_data = []
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['permission_get']
            if p_permid:
                qry = sql_file['permissionby_id'
                               ] + ' where permission_id = ' + str(p_permid)
            permission_data = Methodutil.get_qry(qry)
        except Exception as error:
            logger.findaylog("""@ 25 EXCEPTION - models - permissions -
                 get_permissions """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - get_permissions(-)')
        return permission_data

    @staticmethod
    def get_permissiontypes():
        logger.addinfo('@ models - permissions - get_permissiontypes(+)')
        permission_data = []
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['permission_type']
            permission_data = Methodutil.get_qry(qry)
        except Exception as error:
            logger.findaylog("""@ 40 EXCEPTION - models - permissions -
                 get_permissiontypes """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - get_permissiontypes(-)')
        return permission_data

    @staticmethod
    def get_valuebytype(p_type):
        logger.addinfo('@ models - permissions - get_valuebytype(+)')
        permission_data = []
        try:
            sql_file = db_util.getusermngSql()
            if p_type == "UI":
                qry = sql_file['UI_Permission']
            elif p_type == "D":
                qry = sql_file['Data_Permission']
            elif p_type == "ADMIN":
                qry = sql_file['Admin']
            elif p_type == "QUOTES":
                qry = sql_file['Quotes']
            elif p_type == "GROUP_ID":
                qry = sql_file['Sales_Group']
            elif p_type == "ORGANIZATION_ID":
                qry = sql_file['Organization']
            elif p_type == "SALESREP_ID":
                qry = sql_file['Agent']
            elif p_type == "OTHER":
                qry = sql_file['other_permission']
            permission_data = Methodutil.get_qry(qry)
        except Exception as error:
            logger.findaylog("""@ 70 EXCEPTION - models - permissions -
                 get_valuebytype """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - get_valuebytype(-)')
        return permission_data

    @staticmethod
    def get_validation(p_val):
        logger.addinfo('@ models - permissions - get_validation(+)')
        permission_data = {}
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['perm_validation']
            permission_data = Methodutil.get_validation(qry, p_val)
        except Exception as error:
            logger.findaylog("""@ 85 EXCEPTION - models - permissions -
                 get_validation """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - get_validation(-)')
        return permission_data

    @staticmethod
    def fnd_lookup(data):
        logger.addinfo('@ models - permissions - fnd_lookup(+)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.cursor.execute("""
                begin
                    qpex_usermanagement_pkg.insert_fnd_lookup(
                    :p_lookup_key,
                    :p_lookup_value,
                    :p_lookup_type,
                    :x_status_code
                    );
                end; """, p_lookup_key=data['lookup_key'],
                                    p_lookup_value=data['lookup_value'],
                                    p_lookup_type=data['lookup_type'],
                                    x_status_code=status_code)

                status = status_code.getvalue()

                if status == 'SUCCESS':
                    result['status'] = Status.OK.value
                    result['msg'] = 'Fnd Lookup value added Successfully'

                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed add Fnd lookup value'
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - permissions - 
              fnd_lookup """ + str(e))
            raise e
        logger.addinfo('@ models - permissions - fnd_lookup(+)')
        return result

    @staticmethod
    def get_fnd_lookup():
        logger.addinfo('@ models - permissions - get_fnd_lookup(-)')
        result = {}
        try:
            sql_file = db_util.getusermngSql()
            with OracleConnectionManager() as conn:
                conn.cursor.execute(sql_file['get_fnd_lookup_values'])
                result['status'] = Status.OK.value
                result['fnd_values'] = Code_util.iterate_data(conn.cursor)
        except Exception as e:
            logger.findaylog(""" @ EXCEPTION models - permissions - 
              get_fnd_lookup""" + str(e))
            raise e
        logger.addinfo('@ models - permissions - get_fnd_lookup(+)')
        return result

    @staticmethod
    def save(perm_list):
        logger.addinfo('@ models - permissions - save(+)')
        con = None
        cur = None
        returnmsg = ""
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getusermngSql()
            query = sql_file['permission_seq']
            data = cur.execute(query).fetchone()
            returnmsg = Methodutil.save(perm_list, "qpex_permissions",
                                        "PERMISSION_ID", str(data[0]))
        except Exception as error:
            logger.findaylog("""@ 106 EXCEPTION - models - permissions -
                 save """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - permissions - save(-)')
        return returnmsg

    @staticmethod
    def update(permission_json, perm_id):
        logger.addinfo('@ models - permissions - update(+)')
        returnmsg = ""
        try:
            condition = " where PERMISSION_ID="+str(perm_id)
            returnmsg = Methodutil.update("qpex_permissions",
                                          permission_json, condition)
        except Exception as error:
            logger.findaylog("""@ 124 EXCEPTION - models - permissions -
                 update """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - update(-)')
        return returnmsg
