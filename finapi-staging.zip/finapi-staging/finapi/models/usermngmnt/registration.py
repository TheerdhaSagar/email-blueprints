
from finapi.utils import db_util
import random
import string
import datetime
import cx_Oracle
import os
import time
import base64
from finapi.utils.logdata import logger
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from finapi.utils import auth_util
from finapi.models.usermngmnt.method_util import Methodutil
from finapi.models.suppliers.supplier import Supplier
from finapi.utils.common_utils import CommonUtils
from finapi.models.cms.cms import CMS
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('registration')
class Registration:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def cust_save(custnum, email_id, inv_num, inv_amunt):
        con = None
        cur = None
        sql_file = db_util.getusermngSql()
        returnmsg = {}
        gmail_user = 'support@qualitypeopleit.com'
        gmail_pwd = 'Welcome9'
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            data = []
            data = cur.execute(sql_file['cust_data'],
                               p_parm=custnum).fetchone()
            edata = cur.execute(sql_file['email_validation'],
                                p_email=email_id).fetchone()
            inv_qry = sql_file['invoice_validation']
            invdata = cur.execute(inv_qry, P_AMOUNT=inv_amunt,
                                  P_ACCOUNT_NUMBER=custnum,
                                  P_INV_NUM=inv_num).fetchall()
            custaccnt_data = []
            if data:
                custaccnt_data = cur.execute(sql_file['custaccnt_validation'],
                                             pcust_id=data[1]).fetchone()
            if data and invdata and not edata and not custaccnt_data:
                cur_date = datetime.date.today().strftime("%d,%B,%Y")
                hashval = ''.join(random.choice
                                  (string.ascii_uppercase +
                                   string.ascii_lowercase +
                                   string.digits) for i in range(8))
                reg_val = Registration()
                encr_passwd = auth_util.encrypt(hashval)
                setattr(reg_val, 'CLIENT_SITE_ID', 958)
                setattr(reg_val, 'CREATED_USER_ID', -1)
                setattr(reg_val, 'CREATE_DATE ', cur_date)
                setattr(reg_val, 'RECENT_UPDATE_DATE', cur_date)
                setattr(reg_val, 'RECENT_UPDATED_USER_ID ', -1)
                setattr(reg_val, 'PASSWORD_CHANGED_DATE ', cur_date)
                setattr(reg_val, 'PASSWORD_CHANGED_DATE ', cur_date)
                setattr(reg_val, 'USER_DESCRIPTION', str(data[0]))
                setattr(reg_val, 'ENCRYPTED_PASSWORD', encr_passwd)
                setattr(reg_val, 'USER_NAME', email_id)
                setattr(reg_val, 'EMAIL_ADDRESS', email_id)
                setattr(reg_val, 'cust_account_id', str(data[1]))
                query = sql_file['user_seq']
                seq_data = cur.execute(query).fetchone()
                if seq_data:
                    Methodutil.save(reg_val, "QPEX_CLIENT_USERS",
                                    "USER_ID", str(seq_data[0]))
                msg = MIMEMultipart('alternative')
                html_data = """<html><head></head><body><div>
                <div class="template-border" style="background-color: #ffffff;
                border-radius: 35px;padding: 30px;
                border: 1px solid #269abc;margin-top: 10%;
                margin-left: 25%;width: 500px;
                height: 450px;"><div class="template-header"
                style="padding-left: 5px;
                background-color: #3498db;color: #ffffff;font-size: 18px;">
                <span>Welcome to Ayodhya</span></div>
                <div class="template-body" style="padding-top: 35px;">
                <p style="font-size: 12px">
                <span>
                 An account has been created for you.Now all you
                 need to do is click the link below to activate
                 and set your password. After that,login to the
                 system and you will be ready to roll !!
                </span>
                 </p>
                 <p style="font-size: 14px">your personalized
                 activation link : <a> """
                html_data += "https://ayodhya.finday.com/#/welcome"
                html_data += """</a></p>
                 <p style="font-size: 14px">
                     Your access credentials are:
                 <p><p style="font-size: 14px">
                <span><b>Username</b> : <a>"""
                html_data += email_id
                html_data += """</a><br><b>Password</b> : <a>"""
                html_data += hashval
                html_data += """</a></span></p>
                <p style="font-size: 12px;"><b
                style="font-size: 14px;">IMPORTANT :</b>
                 You must setup your password within 7 days of
                  receiving this message.</p>
                  </div></div></div></body></html>"""
                msg['subject'] = "Account Created !!"
                mesg = (MIMEText(html_data, 'html'))
                msg.attach(mesg)
                smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
                smtpserver.ehlo()
                smtpserver.starttls()
                smtpserver.ehlo
                smtpserver.login(gmail_user, gmail_pwd)
                smtpserver.sendmail(gmail_user, email_id, msg.as_string())
                smtpserver.quit()
                returnmsg['msg'] = "success"
                returnmsg['customer'] = data[0]
            else:
                if edata or custaccnt_data:
                    returnmsg['msg'] = "User Already Exsists!!"
                    returnmsg['customer'] = ''
                elif not data:
                    returnmsg['msg'] = "Invalid Customer Number!!"
                    returnmsg['customer'] = ''
                elif not invdata:
                    returnmsg['msg'] = "Enter a Valid Invoice Details !!"
                    returnmsg['customer'] = ''
        except Exception as error:
            logger.findaylog("""@ 129 EXCEPTION - models - registration -
                 cust_save """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        return returnmsg

    @staticmethod
    def new_cust_save(new_registration):
        gmail_user = 'support@qualitypeopleit.com'
        gmail_pwd = 'Welcome9'
        try:
            first_name = new_registration['first_name']
            last_name = new_registration['last_name']
            email = new_registration['email']
            phonenum = new_registration['phonenum']
            comments = ""
            if 'comments' in new_registration:
                comments = new_registration['comments']
            msg = MIMEMultipart('alternative')
            html_data = """<html><head></head><body><div>
            <div class="template-border" style="background-color: #ffffff;
            border-radius: 35px;padding: 30px;
            border: 1px solid #269abc;margin-top: 10%;
            margin-left: 25%;width: 500px;
            height: 250px;"><div class="template-header"
            style="padding-left: 5px;
            background-color: #3498db;color: #ffffff;font-size: 18px;">
            <span>Welcome to Ayodhya</span></div>
            <div class="template-body" style="padding-top: 35px;">
            <p style="font-size: 12px">
            <span><b>Congratulations !!</b><br><br>
            <span> Dear <b>"""
            html_data += last_name
            html_data += """</b>,<br><br>We appreciate
            your interest , Our Sales Representative will get in
            touch with you very soon !!!
            </span>
            </p><br>
            <span> <b>HAVE GOOD DAY </b></span>
            </div></div></div></body></html>"""
            msg['subject'] = "Registration Completed!!"
            mesg = (MIMEText(html_data, 'html'))
            msg.attach(mesg)
            smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
            smtpserver.ehlo()
            smtpserver.starttls()
            smtpserver.ehlo
            smtpserver.login(gmail_user, gmail_pwd)
            smtpserver.sendmail(gmail_user, email, msg.as_string())
            msgto_back = MIMEMultipart('alternative')
            htmlb_data = """<html><head></head><body><div>
            <div class="template-border" style="background-color: #ffffff;
            border-radius: 35px;padding: 30px;
            border: 1px solid #269abc;margin-top: 10%;
            margin-left: 25%;width: 500px;
            height: 250px;"><div class="template-header"
            style="padding-left: 5px;
            background-color: #3498db;color: #ffffff;font-size: 18px;">
            <span>New User Details</span></div>
            <div class="template-body" style="padding-top: 35px;">
            <span> Details of newly Registered User as Follows </span>
            <p style="font-size: 16px"><br><span>First Name  :  """
            htmlb_data += first_name
            htmlb_data += "</span><br><br><span> Last Name  :  "
            htmlb_data += last_name
            htmlb_data += "</span><br><br><span> Email  :  "
            htmlb_data += email
            htmlb_data += "</span><br><br><span> Phone Number  :  "
            htmlb_data += str(phonenum)
            if comments:
                htmlb_data += "</span><br><br><span> Comments  :  "
                htmlb_data += comments
            htmlb_data += """</span><br><br>
            </div></div></div></body></html>"""
            msgto_back['subject'] = "New User Details!!"
            mesgtob = (MIMEText(htmlb_data, 'html'))
            msgto_back.attach(mesgtob)
            smtpserver.sendmail(gmail_user,
                                "reddy@finday.com",
                                msgto_back.as_string())
            smtpserver.quit()
        except Exception as error:
            logger.findaylog("""@ 215 EXCEPTION - models - registration -
                 new_cust_save """ + str(error))
            raise error
        return "success"

    @staticmethod
    def invite_supplier(req):
        try:
            with OracleConnectionManager() as conn:
                invite_id = conn.cursor.var(cx_Oracle.NUMBER)
                status_code = conn.cursor.var(cx_Oracle.STRING)

                conn.execute("""
                begin
                    qpex_client_suppliers_pkg.create_invitation(
                        :p_invite_id,
                        :p_invite_key,
                        :p_supplier_name,
                        :p_email_address,
                        :p_message,
                        :p_status,
                        :p_created_by,
                        :p_creation_date,
                        :p_language,
                        :p_firstname,
                        :p_lastname,
                        :p_supplier_id,
                        :p_default_org_id,
                        :p_default_payment_term,
                        :p_status_code
                    );
                end; """, p_invite_id=invite_id,
                             p_invite_key=req['invite_key'],
                             p_supplier_name=req['supplier_name'],
                             p_email_address=req['email_address'],
                             p_message=req['message'],
                             p_status=req['status'],
                             p_created_by=req['created_by'],
                             p_creation_date=req['creation_date'],
                             p_language=req['language'],
                             p_firstname=req['firstname'],
                             p_lastname=req['lastname'],
                             p_supplier_id=req['supplier_id'],
                             p_default_org_id=req.get('default_org_id', ''),
                             p_default_payment_term=req.get('payment_term_id'),
                             p_status_code=status_code)
                status = status_code.getvalue()

            if status == 'SUCCESS':
                status = send_invitation_email(req)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - registration -
                invite_supplier """ + str(error))
            raise error
        return status

    @staticmethod
    def create_supplier(data):
        connection = None
        cursor = None
        status = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            supplier_id = cursor.var(cx_Oracle.NUMBER)
            status_code = cursor.var(cx_Oracle.STRING)
            encrypted_password = auth_util.encrypt(data['password'])
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.create_vendor (
                    :p_vendor_id,
                    :p_vendor_type,
                    :p_first_or_business_name,
                    :p_last_or_known_as,
                    :p_gender,
                    :p_business_classification,
                    :p_vat_registration_number,
                    :p_tax_payer_id,
                    :p_website_url,
                    :p_user_name,
                    :p_encrypted_password,
                    :p_password,
                    :p_country,
                    :p_supplier_type,
                    :p_referrer,
                    :p_referrer_email,
                    :p_referrer_phone,
                    :p_invited_by,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_status_code
                );
            end; """, p_vendor_id=supplier_id,
                           p_vendor_type=data['vendor_type'],
                           p_first_or_business_name=data['name'],
                           p_last_or_known_as=data['last_or_known_as'],
                           p_gender=data['gender'],
                           p_business_classification=data['classification'],
                           p_vat_registration_number=data['vat_number'],
                           p_tax_payer_id=data['tax_payer_id'],
                           p_website_url=data['website_url'],
                           p_user_name=data['user_name'],
                           p_encrypted_password=encrypted_password,
                           p_password=data['password'],
                           p_country=data['country'],
                           p_supplier_type=data['supplier_type'],
                           p_referrer=data['referrer'],
                           p_referrer_email=data['referrer_email'],
                           p_referrer_phone=data['referrer_phone'],
                           p_invited_by=data['invited_by'],
                           p_creation_date=data['creation_date'],
                           p_created_by=data['created_by'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                sites = data['sites']
                for i in range(len(sites)):
                    sites[i]['vendor_id'] = supplier_id.getvalue()
                    Registration.create_vendor_site(sites[i], connection)
                files = data['attachments']
                for i in range(len(files)):
                    files[i]['vendor_id'] = supplier_id.getvalue()
                    Registration.create_attachment(files[i], connection)
                account = data['bank_details']
                account['vendor_id'] = supplier_id.getvalue()
                Registration.create_bank_account(account, connection)
            result['status'] = status
            result['supplier_id'] = supplier_id.getvalue()
        except Exception as error:
            logger.findaylog("""@ 312 EXCEPTION - models - registration -
                create_supplier """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return result

    @staticmethod
    def create_vendor_site(data, connection):
        cursor = None
        status = None
        try:
            cursor = connection.cursor()
            site_id = cursor.var(cx_Oracle.NUMBER)
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.create_vendor_site (
                    :p_site_id,
                    :p_vendor_id,
                    :p_address_type,
                    :p_address_line1,
                    :p_address_line2,
                    :p_country,
                    :p_province,
                    :p_city,
                    :p_state,
                    :p_zip_code,
                    :p_org_id,
                    :p_currency,
                    :p_term_id,
                    :p_awt_flag,
                    :p_enasarco,
                    :p_offset,
                    :p_term_flag,
                    :p_tax_code,
                    :p_awttax_code,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_status_code
                );
            end; """, p_site_id=site_id,
                           p_vendor_id=data['vendor_id'],
                           p_address_type=data['address_type'],
                           p_address_line1=data['address_line1'],
                           p_address_line2=data['address_line2'],
                           p_country=data['country'],
                           p_province=data['province'],
                           p_city=data['city'],
                           p_state=data['state'],
                           p_zip_code=data['zip_code'],
                           p_org_id=data['org_id'],
                           p_currency=data['currency'],
                           p_term_id=data['term_id'],
                           p_awt_flag=data['awt_flag'],
                           p_enasarco=data['enasarco'],
                           p_offset=data['offset'],
                           p_term_flag=data['term_verified'],
                           p_tax_code=data['tax_code'],
                           p_awttax_code=data['awttaxcode'],
                           p_creation_date=data['creation_date'],
                           p_created_by=data['created_by'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                contacts = data['contacts']
                for i in range(len(contacts)):
                    contacts[i]['site_id'] = site_id.getvalue()
                    contacts[i]['vendor_id'] = data['vendor_id']
                    Registration.create_vendor_contact(contacts[i], connection)
        except Exception as error:
            logger.findaylog("""@ 312 EXCEPTION - models - registration -
                create_vendor_site """ + str(error))
            raise error
        finally:
            cursor.close()
        return status

    @staticmethod
    def create_vendor_contact(data, connection):
        cursor = None
        try:
            cursor = connection.cursor()
            contact_id = cursor.var(cx_Oracle.NUMBER)
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.create_vendor_contact (
                    :p_contact_id,
                    :p_vendor_id,
                    :p_site_id,
                    :p_contact_type,
                    :p_contact_name,
                    :p_email,
                    :p_phone_number,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_status_code
                );
            end; """, p_contact_id=contact_id,
                           p_vendor_id=data['vendor_id'],
                           p_site_id=data['site_id'],
                           p_contact_type=data['contact_type'],
                           p_contact_name=data['contact_name'],
                           p_email=data['email'],
                           p_phone_number=data['phone_number'],
                           p_creation_date=data['creation_date'],
                           p_created_by=data['created_by'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           x_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ 312 EXCEPTION - models - registration -
                create_vendor_contact """ + str(error))
            raise error
        finally:
            cursor.close()
        return status_code.getvalue()

    @staticmethod
    def create_bank_account(data, connection):
        cursor = None
        try:
            cursor = connection.cursor()
            bank_account_id = cursor.var(cx_Oracle.NUMBER)
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.create_vendor_bank_account (
                    :p_bank_account_id,
                    :p_vendor_id,
                    :p_account_name,
                    :p_account_number,
                    :p_swift_or_bic,
                    :p_iban,
                    :p_bank_id,
                    :p_branch_id,
                    :p_bank_name,
                    :p_country_code,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_status_code
                );
            end; """, p_bank_account_id=bank_account_id,
                           p_vendor_id=data['vendor_id'],
                           p_account_name=data['account_name'],
                           p_account_number=data['account_number'],
                           p_swift_or_bic=data['swift_or_bic'],
                           p_iban=data['iban'],
                           p_bank_id=data['bank_id'],
                           p_branch_id=data['branch_id'],
                           p_bank_name=data['bank_name'],
                           p_country_code=data['country_code'],
                           p_creation_date=data['creation_date'],
                           p_created_by=data['created_by'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           x_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ 312 EXCEPTION - models - registration -
                create_bank_account """ + str(error))
            raise error
        finally:
            cursor.close()
        return status_code.getvalue()

    @staticmethod
    def get_invite(key):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invitation_details']
            cursor.execute(query, P_KEY=key)
        except Exception as error:
            logger.findaylog("""@ 410 EXCEPTION - models - registration -
                 get_invite """ + str(error))
            raise error
        else:
            summary = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                summary.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return summary

    @staticmethod
    def resend_invite(req):
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)
                conn.execute("""
                begin
                    qpex_client_suppliers_pkg.resend_invitation(
                        :p_invite_id,
                        :p_invite_key,
                        :p_supplier_name,
                        :p_email_address,
                        :p_message,
                        :p_status,
                        :p_language,
                        :p_firstname,
                        :p_lastname,
                        :p_default_payment_term,
                        :p_status_code
                    );
                end; """, p_invite_id=req['invite_id'],
                             p_invite_key=req['invite_key'],
                             p_supplier_name=req['supplier_name'],
                             p_email_address=req['email_address'],
                             p_message=req['message'],
                             p_status=req['status'],
                             p_language=req['language'],
                             p_firstname=req['firstname'],
                             p_lastname=req['lastname'],
                             p_default_payment_term=req.get('payment_term_id'),
                             p_status_code=status_code)
                status = status_code.getvalue()

            if status == 'SUCCESS':
                status = send_invitation_email(req)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - registration -
                resend_invite """ + str(error))
            raise error
        return status

    @staticmethod
    def get_countries(lang):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['countries_query']
            cursor.execute(query, p_language=lang)
        except Exception as error:
            logger.findaylog("""@ 667 EXCEPTION - models - registration -
                 get_countries """ + str(error))
            raise error
        else:
            countries = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                countries.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return countries

    @staticmethod
    def update_supplier(data):
        connection = None
        cursor = None
        status = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            encrypted_password = auth_util.encrypt(data['password'])
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.update_vendor (
                    :p_vendor_id,
                    :p_vendor_type,
                    :p_first_or_business_name,
                    :p_last_or_known_as,
                    :p_gender,
                    :p_business_classification,
                    :p_vat_registration_number,
                    :p_tax_payer_id,
                    :p_website_url,
                    :p_user_name,
                    :p_encrypted_password,
                    :p_password,
                    :p_status,
                    :p_country,
                    :p_supplier_type,
                    :p_referrer,
                    :p_referrer_email,
                    :p_referrer_phone,
                    :p_creator_approval,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_status_code
                );
            end; """, p_vendor_id=data['vendor_id'],
                           p_vendor_type=data['vendor_type'],
                           p_first_or_business_name=data['name'],
                           p_last_or_known_as=data['last_or_known_as'],
                           p_gender=data['gender'],
                           p_business_classification=data['classification'],
                           p_vat_registration_number=data['vat_number'],
                           p_tax_payer_id=data['tax_payer_id'],
                           p_website_url=data['website_url'],
                           p_user_name=data['user_name'],
                           p_encrypted_password=encrypted_password,
                           p_password=data['password'],
                           p_status=data['status'],
                           p_country=data['country'],
                           p_supplier_type=data['supplier_type'],
                           p_referrer=data['referrer'],
                           p_referrer_email=data['referrer_email'],
                           p_referrer_phone=data['referrer_phone'],
                           p_creator_approval=data['creator_approval'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                if data['creator_approved'] == 'A' and \
                        data['accounting_approval'] != 'A':
                    req = dict()
                    req['supplier_name'] = data['name']
                    req['supplier_id'] = data['vendor_id']
                    req['org_id'] = data['org_id']
                    req['approver_name'] = data['approver_name']
                    Supplier.creator_approval(req)
                sites = data['sites']
                sql_file = db_util.getSqlData()
                for i in range(len(sites)):
                    if sites[i]['operation_code'] == 'DELETE':
                        cursor.execute(sql_file['delete_supplier_sites'],
                                       P_VENDOR_ID=data['vendor_id'],
                                       P_SITE_ID=sites[i]['site_id'])
                    elif sites[i]['site_id'] == -1:
                        Registration.create_vendor_site(sites[i], connection)
                    else:
                        Registration.update_vendor_site(sites[i], connection)
                files = data['attachments']
                for i in range(len(files)):
                    if files[i]['operation_code'] == 'DELETE':
                        Registration.delete_attachment(files[i], connection)
                    if files[i]['operation_code'] == 'CREATE':
                        files[i]['vendor_id'] = data['vendor_id']
                        Registration.create_attachment(files[i], connection)
                account = data['bank_details']
                if account['bank_account_id'] == -1:
                    Registration.create_bank_account(account, connection)
                else:
                    Registration.update_bank_account(account, connection)
        except Exception as error:
            logger.findaylog("""@ 738 EXCEPTION - models - registration -
                update_supplier """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return status

    @staticmethod
    def update_vendor_site(data, connection):
        cursor = None
        status = None
        try:
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.update_vendor_site (
                    :p_site_id,
                    :p_vendor_id,
                    :p_address_type,
                    :p_address_line1,
                    :p_address_line2,
                    :p_country,
                    :p_province,
                    :p_city,
                    :p_state,
                    :p_zip_code,
                    :p_org_id,
                    :p_currency,
                    :p_term_id,
                    :p_awt_flag,
                    :p_enasarco,
                    :p_offset,
                    :p_term_flag,
                    :p_tax_code,
                    :p_awttax_code,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_status_code
                );
            end; """, p_site_id=data['site_id'],
                           p_vendor_id=data['vendor_id'],
                           p_address_type=data['address_type'],
                           p_address_line1=data['address_line1'],
                           p_address_line2=data['address_line2'],
                           p_country=data['country'],
                           p_province=data['province'],
                           p_city=data['city'],
                           p_state=data['state'],
                           p_zip_code=data['zip_code'],
                           p_org_id=data['org_id'],
                           p_currency=data['currency'],
                           p_term_id=data['term_id'],
                           p_awt_flag=data['awt_flag'],
                           p_enasarco=data['enasarco'],
                           p_offset=data['offset'],
                           p_term_flag=data['term_verified'],
                           p_tax_code=data['tax_code'],
                           p_awttax_code=data['awttaxcode'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                contacts = data['contacts']
                for i in range(len(contacts)):
                    Registration.update_vendor_contact(contacts[i], connection)
        except Exception as error:
            logger.findaylog("""@ 793 EXCEPTION - models - registration -
                update_vendor_site """ + str(error))
            raise error
        finally:
            cursor.close()
        return status

    @staticmethod
    def update_vendor_contact(data, connection):
        cursor = None
        try:
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.update_vendor_contact (
                    :p_contact_id,
                    :p_vendor_id,
                    :p_site_id,
                    :p_contact_type,
                    :p_contact_name,
                    :p_email,
                    :p_phone_number,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_status_code
                );
            end; """, p_contact_id=data['contact_id'],
                           p_vendor_id=data['vendor_id'],
                           p_site_id=data['site_id'],
                           p_contact_type=data['contact_type'],
                           p_contact_name=data['contact_name'],
                           p_email=data['email'],
                           p_phone_number=data['phone_number'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           x_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ 833 EXCEPTION - models - registration -
                update_vendor_contact """ + str(error))
            raise error
        finally:
            cursor.close()
        return status_code.getvalue()

    @staticmethod
    def update_bank_account(data, connection):
        cursor = None
        try:
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.update_vendor_bank_account (
                    :p_bank_account_id,
                    :p_vendor_id,
                    :p_account_name,
                    :p_account_number,
                    :p_swift_or_bic,
                    :p_iban,
                    :p_bank_id,
                    :p_branch_id,
                    :p_bank_name,
                    :p_country_code,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_status_code
                );
            end; """, p_bank_account_id=data['bank_account_id'],
                           p_vendor_id=data['vendor_id'],
                           p_account_name=data['account_name'],
                           p_account_number=data['account_number'],
                           p_swift_or_bic=data['swift_or_bic'],
                           p_iban=data['iban'],
                           p_bank_id=data['bank_id'],
                           p_branch_id=data['branch_id'],
                           p_bank_name=data['bank_name'],
                           p_country_code=data['country_code'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           x_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ 875 EXCEPTION - models - registration -
                update_bank_account """ + str(error))
            raise error
        finally:
            cursor.close()
        return status_code.getvalue()

    @staticmethod
    def update_invitation(data):
        try:
            sql_file = db_util.getSqlData()
            with OracleConnectionManager() as conn:
                query = sql_file['update_invitation']
                conn.execute(query, P_SUPPLIER_ID=data['supplier_id'],
                             P_KEY=data['invite_key'])
                query = sql_file['supplier_created_mail']
                conn.execute(query, P_SUPPLIER_ID=data['supplier_id'])
                user = conn.get_result(convert_data=True)[0]
            recipients = []
            try:
                if data['referrer_mail']:
                    recipient_mail = data['referrer_mail']
                else:
                    recipient_mail = user['email_address']
            except AttributeError:
                recipient_mail = user['email_address']

            recipients.append({
                'Email': recipient_mail
            })

            if recipient_mail != user['email_address']:
                recipients.append({
                    'Email': user['email_address']
                })

            if user:
                strings = db_util.get_strings()

                result = CommonUtils.send_mail({
                    'template_id': 107433,
                    'subject': strings['supplier_created_subject'].format(data['supplier_name'].encode('utf-8')),
                    'params': [
                        {
                            'key': 'username',
                            'value': user['user_description']
                        },
                        {
                            'key': 'firstname',
                            'value': user['first_name']
                        },
                        {
                            'key': 'lastname',
                            'value': user['last_name']
                        },
                        {
                            'key': 'vendorname',
                            'value': user['first_or_business_name']
                        },
                        {
                            'key': 'vendor_id',
                            'value': data['supplier_id']
                        }
                    ],
                    'recipients': recipients
                })
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - registration -
                update_invitation """ + str(error))
            raise error
        return result

    @staticmethod
    def get_iban_details(country_code, country_name):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['iban_details_query']
            cursor.execute(query, p_country_code=country_code,
                           p_country_name=country_name)
        except Exception as error:
            logger.findaylog("""@ 883 EXCEPTION - models - registration -
                 get_iban_details """ + str(error))
            raise error
        else:
            countries = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                countries.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return countries

    @staticmethod
    def get_business_details():
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['business_classification_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 913 EXCEPTION - models - registration -
                 get_business_details """ + str(error))
            raise error
        else:
            data = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return data

    @staticmethod
    def create_attachment(data, connection):
        cursor = None
        try:
            cursor = connection.cursor()
            attachment_id = cursor.var(cx_Oracle.NUMBER)
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.setinputsizes(p_file_blob=cx_Oracle.BLOB)
            cursor.execute("""
            begin
                qpex_client_suppliers_pkg.create_vendor_attachment (
                    :p_attachment_id,
                    :p_vendor_id,
                    :p_file_name,
                    :p_file_type,
                    :p_file_blob,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :p_document_type,
                    :x_status_code
                );
            end; """, p_attachment_id=attachment_id,
                           p_vendor_id=data['vendor_id'],
                           p_file_name=data['file_name'],
                           p_file_type=data['file_type'],
                           p_file_blob=CommonUtils.decode_base64(data['file_blob']),
                           p_creation_date=data['creation_date'],
                           p_created_by=data['created_by'],
                           p_last_update_date=data['last_update_date'],
                           p_last_updated_by=data['last_updated_by'],
                           p_document_type=data.get('document_type', 'SUPPORTING_DOC'),
                           x_status_code=status_code)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - registration -
                create_attachment """ + str(error))
            raise error
        finally:
            cursor.close()
        return status_code.getvalue()

    @staticmethod
    def delete_attachment(data, connection):
        cursor = None
        try:
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['delete_vendor_attachment']
            cursor.execute(query, P_ATTACHMENT_ID=data['attachment_id'])
        except Exception as error:
            logger.findaylog("""@ 1061 EXCEPTION - models - registration -
                delete_attachment """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
        return 'SUCCESS'

    @staticmethod
    def validate_email(email_address):
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['valid_contact_query']
            cursor.execute(query, p_email=email_address)
            data = cursor.fetchall()
        except Exception as error:
            logger.findaylog("""@ 1139 EXCEPTION - models - registration -
                 validate_email """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        if len(data) > 0:
            return 'success'
        else:
            return 'fails'

    # generate HeaderId
    @staticmethod
    def user_id():
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['survey_user_sequence']
            data = cursor.execute(query).fetchone()
            user_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ 1165 EXCEPTION - models - registration -
                 user_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return user_id

    @staticmethod
    def insert_user(json, user_id):
        con = None
        cur = None
        try:
            return_data = {}
            con = db_util.get_connection()
            sql_file = db_util.getSqlData()
            cur = con.cursor()
            row_data = []
            query = sql_file['user_insert_query1']
            my_data = []
            encrypted_password = hashPassword(json['password'])
            json['encrypted_password'] = encrypted_password
            for key, value in json.items():
                my_data.append(value)
                my_new_tuple = tuple(my_data)
            row_data.append(my_new_tuple)
            for key, value in json.items():
                query += str(key)
                query += ','
            query = query[:-1]
            query += sql_file["user_insert_query2"]
            query += str(user_id) + ","
            sql_args = ""
            for idx, key in enumerate(json.items()):
                sql_args += ":" + str(idx) + ","
            sql_args = sql_args[:-1]
            query += sql_args + ")"
            cur.executemany(query, row_data)
            return_data['req_id'] = user_id
            return_data['status'] = 0
            return_data['result'] = "success"
            return_data['msg'] = "User created sucessfully"
        except Exception as error:
            logger.addinfo(time.ctime())
            logger.findaylog("""@ 1211 EXCEPTION - models - surveys -
                    insert_user """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo(time.ctime())
        return return_data

    @staticmethod
    def send_mail(email_address, name):
        connection = None
        cursor = None
        try:
            status = ''
            connection = db_util.get_connection()
            cursor = connection.cursor()
            strings = db_util.get_strings()
            data = {
                'subject': strings['create_survey_user'],
                'template_id': 107447,
                'params': [{
                    'key': 'user_name',
                    'value': name
                }],
                'recipients': [
                    {
                        'Email': email_address
                    }
                ]
            }
            result = CommonUtils.send_mail(data)
            if result != 'SUCCESS':
                status = 'Failure - Failed to send email'
            else:
                status = 'success'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - surveys -
                send_mail """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return status

    @staticmethod
    def get_paymentterms():
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['payment_terms_query']
            cursor.execute(query)
        except Exception as error:
            logger.findaylog("""@ 1286 EXCEPTION - models - supplier -
                 get_paymentterms """ + str(error))
            raise error
        else:
            terms = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                terms.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return terms

    @staticmethod
    def user_validation(p_val):
        data = {}
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['user_validation']
            data = Methodutil.get_validation(qry, p_val)
        except Exception as error:
            logger.findaylog("""@ 1312 EXCEPTION - models - registration -
                 user_validation """ + str(error))
            raise error
        return data

    @staticmethod
    def get_vendor_details(vendor_id):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            # get vendor details
            query = sql_file['vendor_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            result = {}
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
            # get vendor site details
            query = sql_file['vendor_site_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            sites = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                site = {}
                for index, fn in enumerate(fieldnames):
                    site[fn] = row[index]
                sites.append(site)
            result['sites'] = sites
            # get vendor contacts
            query = sql_file['vendor_contacts_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            contacts = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                contact = {}
                for index, fn in enumerate(fieldnames):
                    contact[fn] = row[index]
                contacts.append(contact)
            result['contacts'] = contacts
            setattr(result, 'contacts', contacts)
            # get vendor bank accounts
            query = sql_file['vendor_bank_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            accounts = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                account = {}
                for index, fn in enumerate(fieldnames):
                    account[fn] = row[index]
                accounts.append(account)
            result['bank_details'] = accounts
            # get vendor attachments
            query = sql_file['vendor_attachment_details']
            cursor.execute(query, P_VENDOR_ID=vendor_id)
            attachments = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                attachment = {}
                for index, fn in enumerate(fieldnames):
                    attachment[fn] = row[index]
                attachments.append(attachment)
            result['attachments'] = attachments
        except Exception as error:
            logger.findaylog("""@ 1395 EXCEPTION - models - registration -
                 get_vendor_details """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return result


# generate encrypted password
def hashPassword(password):
    return auth_util.encrypt(password)


def send_invitation_email(req):
    try:
        path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        # open & read registration user guide pdf file
        if req['language'] == 'IT':
            path += '/static/Guide_Italian.pdf'
        else:
            path += '/static/Guide.pdf'
        guide = open(path, 'rb')
        pdf_guide = base64.b64encode(guide.read())

        # open & read qr code pdf file
        file_name = ''
        path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        if req['org_id'] == 82:  # Almo Nature Spa
            path += '/static/qrcode_almonature_spa.pdf'
            file_name = 'QRCode Almo Nature Spa.pdf'
        elif req['org_id'] == 243:  # Fondazione Capellino
            path += '/static/qrcode_fondazione_capellino.pdf'
            file_name = 'QRCode Fondazione Capellino.pdf'
        elif req['org_id'] == 263:  # Villa Fortuna
            path += '/static/qrcode_villa_fortuna.pdf'
            file_name = 'QRCode Villa Fortuna.pdf'
        if file_name:
            qr_code = open(path, 'rb')
            qr_code_file = base64.b64encode(qr_code.read())

        privacy_url = 'https://cdn.almonature.com/hubfs/Privacy%20policy/B2B%20Privacy%20policy/'
        if req['language'] == 'IT':
            tid = 107436
            privacy_url += 'IT_b2b_privacy_policy.pdf'
        elif req['language'] == 'FR':
            tid = 107434
            privacy_url += 'FR_b2b_privacy_policy.pdf'
        elif req['language'] == 'DE':
            tid = 107435
            privacy_url += 'DE_b2b_privacy_policy.pdf'
        else:
            tid = 107437
            privacy_url += 'EN_b2b_privacy_policy.pdf'
        sql_file = db_util.getSqlData()
        countries = sql_file['org_country_map']
        personas = sql_file['supplier_persona_map']
        if req['org_id'] in countries:
            supplier_country = countries[req['org_id']]
            persona = personas[supplier_country]
        else:
            supplier_country = 'IT'
            persona = 'persona_48'

        # Send supplier invitation to suppplier from HubSpot
        props = {
            'vendor_name': req['supplier_name'],
            'firstname': req['firstname'],
            'lastname': req['lastname'],
            'email': req['email_address'],
            'organization_name': req['org_name'],
            'hs_persona': persona,
            'country': supplier_country,
            'vendor_email_language': req['language'],
            'vendor_invite_message': req['message'],
            'vendor_invite_key': req['invite_key'],
            'vendor_workflow': 'send_vendor_invitation_email'
        }
        cms_obj = CMS()
        cms_obj.create_contact(props)
        common_utils_obj = CommonUtils()

        # Send invitation email to user who invited supplier to have a copy of invitation
        invited_user_email = common_utils_obj.get_user_details_based_on_id(
            req['created_by'])['email_address']
        strings = db_util.get_strings()
        subject = strings.get('supplier_invitation_subject_' +
                              req['language'].lower(), strings['supplier_invitation_subject_en'])
        data = {'to_email': invited_user_email, 'subject': subject, 'params': [
            {
                'key': 'supplier_name',
                'value': req['supplier_name']
            },
            {
                'key': 'invite_key',
                'value': req['invite_key']
            },
            {
                'key': 'message',
                'value': req['message']
            },
            {
                'key': 'org_name',
                'value': req['org_name']
            },
            {
                'key': 'privacy_url',
                'value': privacy_url
            }
        ], 'template_id': tid, 'attachments': [
            {
                'file_type': 'application/pdf',
                'file_name': 'Guide.pdf',
                'file_data': pdf_guide
            }
        ]}

        if req['org_id'] in [82, 243, 263]:
            data['attachments'].append({
                'file_type': 'application/pdf',
                'file_name': file_name,
                'file_data': qr_code_file
            })
        result = common_utils_obj.send_mail(data)
        if result != 'SUCCESS':
            status = 'Failure - Failed to send email'
        else:
            status = 'SUCCESS'
    except Exception as e:
        logger.findaylog(""" EXCEPTION - models - registration -
                         send_invitation_email """ + str(e))
        raise e
    return status
