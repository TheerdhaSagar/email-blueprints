from finapi.utils import db_util
from finapi.sql import sql_util
import cx_Oracle
import ujson
from flask import Response
from finapi.utils.logdata import logger
from finapi.utils import auth_util
from finapi.utils.common_utils import CommonUtils
import base64
import os
import random
import string
from finapi.utils.code_util import Code_util
from finapi.models.usermngmnt.method_util import Methodutil
from finapi.utils.conn_util import OracleConnectionManager
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('users')
class Users:

    def __init__(self, **kwargs):
        self.connection = None
        self.cursor = None
        self.is_acquired = False
        for name, value in list(kwargs.items()):
            setattr(self, name, value)
        self.sql_file = db_util.getusermngSql()
        self.strings = db_util.get_strings()

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    @staticmethod
    def get_users(org_id):
        data = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['users_query']
            data = Methodutil.get_data_by_param(query, org_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_users """ + str(error))
            raise error
        return data

    @staticmethod
    def get_sales_users(user_id):
        return_data = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['users_sales_query']
            return_data = Methodutil.get_data_by_param(query, user_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_sales_users """ + str(error))
            raise error
        return return_data

    @staticmethod
    def get_manager_customers(org_id, user_id):
        try:
            file_data = db_util.getusermngSql()
            with OracleConnectionManager() as conn:
                if user_id:
                    kwargs = {'p_user_id': user_id}
                    query = file_data['manager_customer_mapping']
                    query += file_data['manager_customer_mapping_with_org']
                    kwargs['p_parm'] = org_id
                    conn.execute(query, **kwargs)
                    data = conn.get_result()
                    users = Users.parse_customer_details(data)
                else:
                    # fetch the count directly in query itself using the groupby
                    query = file_data['manager_customer_mapping_summary']
                    conn.execute(query, p_parm=org_id)
                    users = conn.get_result()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_manager_customers """ + str(error))
            raise error
        return users

    @staticmethod
    def get_account_manager_customers(user_id):
        try:
            file_data = db_util.getusermngSql()
            with OracleConnectionManager() as conn:
                if user_id:
                    kwargs = {'p_user_id': user_id}
                    query = file_data['manage_account_managers_customers']
                    conn.execute(query, **kwargs)
                else:
                    query = file_data['manage_account_managers']
                    conn.execute(query)
                users = conn.get_result()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_account_manager_customers """ + str(error))
            raise error
        return users

    @staticmethod
    def parse_customer_details(data):
        # get unique user details from data
        users = list({each['user_id']: Users.delete_dict_key(
            each, ['cust_account_id', 'customer_name', 'account_number']) for each in data}.values())
        for user in users:
            # append customer details in an array
            cust_acc_id = []
            for customer in data:
                if user['user_id'] == customer['user_id']:
                    cust_acc_id.append(
                        {'cust_account_id': customer['cust_account_id'],
                         'customer_name': customer['customer_name'],
                         'account_number': customer['account_number']})
            user['cust_account_ids'] = cust_acc_id
            user['customer_count'] = len(cust_acc_id)
        return users

    @staticmethod
    def delete_dict_key(mydict, keys):
        return {k: v for k, v in list(mydict.items()) if k not in keys}

    def insert_sales_agent(self, data):
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            user_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            hashval = ''.join(random.choice
                              (string.ascii_uppercase +
                               string.ascii_lowercase +
                               string.digits) for i in range(10))
            value = hashPassword(hashval)
            self.cursor.execute("""
                        begin
                            qpex_usermanagement_pkg.add_sales_agent(
                            :p_org_id,
                            :p_resource_first_name,
                            :p_resource_last_name,
                            :p_supplier_name,
                            :p_vat_code,
                            :p_address,
                            :p_city,
                            :p_province,
                            :p_zip,
                            :p_country,
                            :p_group_name,
                            :p_reports_id,
                            :p_email_address,
                            :p_user_name,
                            :p_password,
                            :p_encrypted_pwd,
                            :p_phone,
                            :p_ui_language,
                            :p_number_format,
                            :p_date_format,
                            :p_notify_orders,
                            :p_notify_invoices,
                            :x_sales_user_id,
                            :x_status_code
                            );
                        end; """, p_org_id=data['org_id'],
                                p_resource_first_name=data['first_name'],
                                p_resource_last_name=data['last_name'],
                                p_supplier_name=data['supplier_name'],
                                p_vat_code=data['vat_code'],
                                p_address=data['address'],
                                p_city=data['city'],
                                p_province=data['province'],
                                p_zip=data['zip'],
                                p_country=data['country'],
                                p_group_name=data['group_name'],
                                p_reports_id=data['reports_id'],
                                p_email_address=data['email'],
                                p_user_name=data['user_name'],
                                p_password=hashval,
                                p_encrypted_pwd=value,
                                p_phone=data['telephone'],
                                p_ui_language=data['ui_language'],
                                p_number_format=data['number_format'],
                                p_date_format=data['date_format'],
                                p_notify_orders=data['notify_orders'],
                                p_notify_invoices=data['notify_invoices'],
                                x_sales_user_id=user_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                # Users.email_service(data['email'],
                #                     hashval,
                #                     data['user_name'], data['cc'], data['bcc'])
                data['password'] = hashval
                data['email_address'] = data['email']
                self.new_email_service(data, 'newuser')
                result['status'] = 0
                result['msg'] = 'Sales agent added to Cruscott'
                result['user_id'] = user_id.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add Sales agent - ' + str(status)
                result['user_id'] = -1
                logger.findaylog("""@ EXCEPTION models - users -
                                insert_sales_agent - {}""".format(status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - users -
                insert_sales_agent """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def manager_customer_mapping(self, data):
        result = dict()
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            status = 'SUCCESS'
            if data['customer_account_id_insert']:
                self.cursor.execute("""
                            declare\
                                l_customer_ids qpex_usermanagement_pkg.lm_cust_id_record_type_cover;\
            
                                type t_customer_id_table is table of NUMBER
                                      index by binary_integer;\
                                p_cust_account_id t_customer_id_table := :p_customer_ids;\
                                begin\
                                                                                        
                                for i in 1..p_cust_account_id.count
                                LOOP
                                    l_customer_ids(i).cust_account_id := p_cust_account_id(i);\
                                END LOOP;\
                            qpex_usermanagement_pkg.insert_customer_user_mapping(
                            :p_user_id,
                            l_customer_ids,
                            :x_status_code
                            );
                        end; """, p_user_id=data['user_id'],
                                    p_customer_ids=data[
                                        'customer_account_id_insert'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
            delete_status = 'SUCCESS'
            if data['customer_account_id_delete']:
                self.cursor.execute("""
                            declare\
                                l_customer_ids qpex_usermanagement_pkg.lm_cust_id_record_type_cover;\

                                type t_customer_id_table is table of NUMBER
                                      index by binary_integer;\
                                p_cust_account_id t_customer_id_table := :p_customer_ids;\
                            begin\
                                for i in 1..p_cust_account_id.count
                                LOOP
                                    l_customer_ids(i).cust_account_id := p_cust_account_id(i);\
                                END LOOP;\
                            qpex_usermanagement_pkg.delete_customer_user_mapping(
                            :p_user_id,
                            l_customer_ids,
                            :x_status_code
                            );
                        end; """, p_user_id=data['user_id'],
                                    p_customer_ids=data[
                                        'customer_account_id_delete'],
                                    x_status_code=status_code)
                delete_status = status_code.getvalue()
            if status == 'SUCCESS' and delete_status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'User mapped to Customer Successfully'
                result['user_id'] = data['user_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to map User - ' + str(status)
                result['user_id'] = -1
                logger.findaylog("""@ models - users - manager_customer_mapping - {} & 
                    {}""".format(status, delete_status))
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - users -
                manager_customer_mapping """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    @staticmethod
    def user_id():
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            sql_file = db_util.getusermngSql()
            query = sql_file['user_id_sequence']
            cursor = connection.cursor()
            data = cursor.execute(query).fetchone()
            user_id = str(data[0])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 user_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return user_id

    # insert roles of user
    @staticmethod
    def save_roles(p_roles_list, user_id):
        connection = None
        cursor = None
        fieldname_strng = ""
        paramater_strng = ""
        returnval = {}
        row_list = []
        for role in p_roles_list:
            role['REFERENCE_ID'] = user_id
            role['REFERENCE_TYPE'] = 'U'
            values = ""
            values = tuple(str(val) for key, val in role.items())
            row_list.append(values)
        if p_roles_list:
            dict_val = p_roles_list[0]
            fieldname_strng += "("
            indx_value = 1
            paramater_strng += "("
            for key, value in dict_val.items():
                fieldname_strng += str(key) + ','
                paramater_strng += ":" + str(indx_value) + ','
                indx_value = indx_value + 1
            fieldname_strng = fieldname_strng[:-1]
            paramater_strng = paramater_strng[:-1]
            fieldname_strng += ")"
            paramater_strng += ")"
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.prepare("""insert into
            QPEX_USER_GROUP_ROLES """ + fieldname_strng + """
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 save_roles """ + str(error))
            returnval['msg'] = "Fails"
            returnval['user_id'] = ""
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)

    # insert user
    def insert_header(self, p_users, user_id, send_email, cc, bcc):
        connection = None
        cursor = None
        row_data = []
        hashval = ''
        user_dict = {}
        user_name = ''
        sql_data = '''insert into QPEX_CLIENT_USERS ('''
        for user in p_users:
            my_data = []
            for key, value in list(user.items()):
                user_dict = user
                if key == 'user_name':
                    user_name = value
                if key == 'encrypted_password':
                    if not value:
                        hashval = ''.join(random.choice
                                          (string.ascii_uppercase +
                                           string.ascii_lowercase +
                                           string.digits) for i in range(10))
                        value = hashPassword(hashval)
                    else:
                        hashval = value
                        value = hashPassword(value)
                my_data.append(value)
                my_new_tuple = tuple(my_data)
            row_data.append(my_new_tuple)
        for key, value in list(user.items()):
            sql_data += str(key)
            sql_data += ','
        sql_data += " USER_ID)\
                VALUES ( "
        sql_args = ""
        for idx, key in enumerate(user.items()):
            sql_data += ":" + str(idx) + ","
        sql_data += sql_args + user_id + ")"
        returnval = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.executemany(sql_data, row_data)
            if send_email == 'Y':
                if hashval:
                    # old function for reference
                    # Users.email_service(user_dict['email_address'],
                    #                     hashval,
                    #                     user_dict['user_name'], cc, bcc)
                    user_dict['password'] = hashval
                    user_dict['bcc'] = bcc
                    user_dict['cc'] = cc
                    self.new_email_service(user_dict, 'newuser')
                # rvalue = cursor.var(cx_Oracle.STRING)
                # cursor.execute("""
                # begin
                # :retval := qpex_quotes_pub_pkg.send_activation_email
                # (:p_user_name);
                # end;""", p_user_name=user_name, retval=rvalue)
                # if rvalue.getvalue() == 'S':
                connection.commit()
                returnval['msg'] = "User created successfully"
                returnval['status'] = 0
                # else:
                # returnval['msg'] = "Fails"
                # returnval['status'] = 1
            else:
                returnval['msg'] = "User created successfully"
                returnval['status'] = 0
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 insert_header """ + str(error))
            returnval['msg'] = str(error)
            returnval['status'] = 1
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return returnval

    @staticmethod
    def get_user_data(user_id):
        final = {}
        user_data = {}
        try:
            sql_file = db_util.getusermngSql()
            user_details_qry = sql_file['user_details_query']
            user_data = Methodutil.get_data_by_param(user_details_qry, user_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_user_data """ + str(error))
            raise error
        user_roles_data = {}
        try:
            sql_file = db_util.getusermngSql()
            user_roles_qry = sql_file['user_roles_query']
            user_roles_data = Methodutil.get_data_by_param(user_roles_qry,
                                                           user_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_user_data """ + str(error))
            raise error
        final['user_details'] = user_data
        final['roles'] = user_roles_data
        return final

    @staticmethod
    def get_user_details(user_id):
        user_data = {}
        user_roles_data = {}
        try:
            sql_file = db_util.getusermngSql()
            user_roles_qry = sql_file['user_roles_query']
            user_roles_data = Methodutil.get_data_by_param(user_roles_qry,
                                                           user_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_user_details """ + str(error))
            raise error
        user_groups_data = {}
        try:
            sql_file = db_util.getusermngSql()
            user_groups_qry = sql_file['user_groups_query']
            user_groups_data = Methodutil.get_data_by_param(user_groups_qry,
                                                            user_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_user_details """ + str(error))
            raise error
        user_data['roles'] = user_roles_data
        user_data['groups'] = user_groups_data
        return user_data

    # insert roles of user
    @staticmethod
    def update_roles(p_roles_list, user_id):
        final_data = Users.new_roles(p_roles_list, user_id)
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            row_list = []
            role_ids = []
            my_ids = []
            returnval = {}
            update_strng = "SET "
            for roleval in final_data:
                for key, value in roleval.items():
                    if key == 'role_id':
                        role_ids.append(value)
                    update_strng += str(key)
                    update_strng += '='
                    if isinstance(value, int):
                        update_strng += str(value)
                    else:
                        update_strng += "'" + value + "'"
                    update_strng += ','
                row_list.append(update_strng[:-1])
                update_strng = "SET "
            length = len(role_ids)
            sql_file = db_util.getusermngSql()
            qry = sql_file['user_roles_exist_query']
            for i in range(0, length):
                cursor.execute(qry, p_role_id=role_ids[i], p_user_id=user_id)
                data = cursor.fetchall()
                if len(data) == 0:
                    my_ids.append(i)
            for i in range(0, length):
                cursor.execute("""update
                QPEX_USER_GROUP_ROLES """ + str(row_list[i]) + """
                where role_id = """ + str(role_ids[i]) + """
                and reference_id = """ + str(user_id))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 update_roles """ + str(error))
            returnval['msg'] = "Fails"
            returnval['user_id'] = ""
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return "success"

    # insert roles of user
    @staticmethod
    def new_roles(p_roles_list, user_id):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            role_ids = []
            my_ids = []
            new_roles_list = []
            for roleval in p_roles_list:
                for key, value in roleval.items():
                    if key == 'role_id':
                        role_ids.append(value)
            length = len(role_ids)
            for i in range(0, length):
                sql_file = db_util.getusermngSql()
                qry = sql_file['user_roles_exist_query']
                cursor.execute(qry, p_role_id=role_ids[i], p_user_id=user_id)
                data = cursor.fetchall()
                if len(data) == 0:
                    my_ids.append(i)
            exist_list = []
            for i in range(0, len(my_ids)):
                new_roles_list.append(p_roles_list[my_ids[i]])
            for i in range(0, length):
                if i not in my_ids:
                    exist_list.append(p_roles_list[i])
            Users.save_roles(new_roles_list, user_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 new_roles """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return exist_list

    # insert roles of user
    @staticmethod
    def update_users(p_users, user_id):
        connection = None
        cursor = None
        update_strng = "SET "
        returnval = {}
        for key, value in p_users.items():
            if key == 'encrypted_password':
                if value:
                    value = hashPassword(value)
            update_strng += str(key)
            update_strng += '='
            if isinstance(value, int):
                update_strng += str(value)
            else:
                update_strng += "'" + value + "'"
            update_strng += ','
        final = update_strng[:-1]
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.execute("""update
                QPEX_CLIENT_USERS """ + str(final) + """
                where user_id = """ + str(user_id))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 update_users """ + str(error))
            returnval['msg'] = "Fails"
            returnval['user_id'] = ""
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return "success"

    @staticmethod
    def validation(p_val):
        data = {}
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['user_validation']
            data = Methodutil.get_validation(qry, p_val)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 validation """ + str(error))
            raise error
        return data

    @staticmethod
    def email_service(email_id, password, user_name, cc, bcc):
        try:
            strings = db_util.get_strings()
            data = {
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name'],
                },
                'subject': strings['newuser_subject'],
                'template_id': '107422',
                'params': [
                    {
                        'key': 'user_name',
                        'value': user_name
                    },
                    {
                        'key': 'password',
                        'value': password
                    }],
                'to_email': email_id,
                'cc': cc,
                'bcc': bcc
            }
            result = CommonUtils.send_mail(data)
            if result != 'SUCCESS':
                status = 'Failure - Failed to send email'
                logger.findaylog(""" @ models -  users - email_service - {}""".format(data))
            else:
                status = 'Success'
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - users -
                email_service """ + str(error))
            final = {}
            final['status'] = 1
            final['msg'] = str(error)
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
            return resp
        return status

    @staticmethod
    def get_persons(id):
        return_data = []
        query = ''
        try:
            file_data = db_util.getusermngSql()
            if id:
                query = file_data['persons_query']
            else:
                query = file_data['employees_query']
            return_data = Methodutil.get_qry(query)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_persons """ + str(error))
            raise error
        return return_data

    @staticmethod
    def get_hostess():
        return_data = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['hostess_query']
            return_data = Methodutil.get_qry(query)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_hostess """ + str(error))
            raise error
        return return_data

    @staticmethod
    def get_card_details(card_id):
        return_data = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['credit_card_number_query']
            card_id = str(card_id)
            return_data = Methodutil.get_data_by_param(query, card_id)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_users """ + str(error))
            raise error
        return return_data

    @staticmethod
    def get_notifications(user_id, status):
        connection = None
        cursor = None
        data = []
        try:
            file_data = db_util.getusermngSql()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = file_data['user_notifications']
            cursor.execute(query, P_USER_ID=user_id, P_STATUS=status)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_notifications """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return data

    @staticmethod
    def workflow_action(data):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.execute("alter session set nls_language=American")
            cursor.execute("""
            begin
                qpex_stand_pkg.set_wf_notification(
                    :p_item_key,
                    :p_result,
                    :p_type,
                    :p_comment,
                    :p_login_user_name
                );
            end; """, p_item_key=data['item_key'],
                           p_result=data['result'],
                           p_type=data['type'],
                           p_comment=data['comment'],
                           p_login_user_name=data['login_user_name'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - supplier -
                workflow_action """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return 'SUCCESS'

    @staticmethod
    def get_notification_count(user_id):
        connection = None
        cursor = None
        data = []
        try:
            file_data = db_util.getusermngSql()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = file_data['user_notifications_count']
            cursor.execute(query, P_USER_ID=user_id)
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = {}
                for index, fn in enumerate(fieldnames):
                    result[fn] = row[index]
                data.append(result)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_notification_count """ + str(error), send_email=False)
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return data

    @staticmethod
    def get_usersmail():
        return_data = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['user_emails_query']
            return_data = Methodutil.get_qry(query)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 get_usersmail """ + str(error))
            raise error
        return return_data

    @staticmethod
    def get_wp_users():
        connection = None
        cursor = None
        result = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['wordpress_users_query']
            cursor.execute(query)
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                obj = {}
                for index, fn in enumerate(fieldnames):
                    obj[fn] = row[index]
                result.append(obj)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                get_wp_users """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return result

    @staticmethod
    def change_user_status(jsond):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['update_wp_user_status']
            cursor.execute(query, p_status=jsond['status'],
                           p_email=jsond['email'])
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                change_user_status """ + str(error))
            return "error"
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return "success"

    @staticmethod
    def send_mail(register_name, email_address, status):
        try:
            strings = db_util.get_strings()
            data = {
                'sender': {
                    'email': strings['sender_email'],
                    'name': strings['sender_name'],
                },
                'subject': strings['wordpress_user_status'],
                'template_id': 107449,
                'params': [{
                    'key': 'status',
                    'value': status
                }, {
                    'key': 'register_name',
                    'value': register_name
                }],
                'recipients': [
                    {
                        'Email': email_address
                    }
                ]
            }
            result = CommonUtils.send_mail(data)
            if result != 'SUCCESS':
                logger.findaylog("""@ models - procurement -
                                send_mail - {}""".format(data))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - procurement -
                send_mail """ + str(error))
            raise error
        return 'SUCCESS'

    # insert last_logon_date of user to sysdate
    @staticmethod
    def update_last_logon(user_id):
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getusermngSql()
            query = sql_file['update_last_logon']
            cursor.execute(query, p_user_id=user_id)
            connection.commit()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 update_last_logon """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return 'success'

    # Get B2B users
    @staticmethod
    def get_role_based_users():
        result = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['role_based_users_query']
            result = Methodutil.get_qry(query)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                         get_role_based_users """ + str(error))
            result = {}
            result['msg'] = str(error)
            result['status'] = 1
        return result

    @staticmethod
    def get_summary_user_access(user_id):
        """
        Summary of list of users with oracle access flag
        """
        try:
            file_data = db_util.getusermngSql()
            result = {}
            with OracleConnectionManager() as conn:
                obj = CommonUtils()
                if obj.check_role_exists(user_id,
                                         'UI-ACCESS-CONTROL-REPORT-ALL'):
                    user_id = ''
                    query = file_data['all_oracle_responsibilities']
                    conn.execute(query)
                    result['oracle_responsibilities'] = conn.get_result()
                    query = file_data['all_role_query']
                    conn.execute(query)
                    result['role_responsibilities'] = conn.get_result()
                query = file_data['summary_user_access']
                conn.execute(query, p_user_id=user_id)
                result['summary'] = conn.get_result()
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                         get_summary_user_access """ + str(error))
            raise error
        return result

    # User crusott and oracle responsibilities, assets and leave details
    @staticmethod
    def get_details_user_access(user_id):
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getusermngSql()
            query = file_data['get_details_user_access']
            cursor.execute(query, p_user_id=user_id)
            result = Code_util.iterate_data(cursor)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                         get_details_user_access """ + str(error))
            result['msg'] = str(error)
            result['status'] = 1
        finally:
            if cursor:
                cursor.close()
            db_util.release_connection(connection)
        return result

    # insert role based user
    def insert_role_based_user(self, p_users, cc, bcc):
        connection = None
        cursor = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            password = CommonUtils.generate_random_string(8)
            encrypted_pwd = hashPassword(password)
            new_user_id = cursor.var(cx_Oracle.NUMBER)
            status_code = cursor.var(cx_Oracle.STRING)

            cursor.execute("""
                        begin
                            qpex_usermanagement_pkg.create_user(
                                :x_user_id,
                                :p_cust_account_id,
                                :p_username,
                                :p_known_as,
                                :p_password,
                                :p_encrypted_pwd,
                                :p_email,
                                :p_phone,
                                :p_org_id,
                                :p_ui_language,
                                :p_number_format,
                                :p_date_format,
                                :p_notify_orders,
                                :p_notify_invoices,
                                :p_created_by,
                                :x_status_code
                            );
                        end; """, x_user_id=new_user_id,
                           p_cust_account_id=p_users['cust_account_id'],
                           p_username=p_users['user_name'],
                           p_known_as=p_users['known_as'],
                           p_password=password,
                           p_encrypted_pwd=encrypted_pwd,
                           p_email=p_users['email'],
                           p_phone=p_users['phone'],
                           p_org_id=p_users['org_id'],
                           p_ui_language=p_users['ui_language'],
                           p_number_format=p_users['number_format'],
                           p_date_format=p_users['date_format'],
                           p_notify_orders=p_users['notify_orders'],
                           p_notify_invoices=p_users['notify_invoices'],
                           p_created_by=p_users['created_by'],
                           x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                if password:
                    # Users.email_service(p_users['email'],
                    #                     password,
                    #                     p_users['user_name'], cc, bcc)
                    p_users['password'] = password
                    p_users['email_address'] = p_users['email']
                    p_users['cc'] = cc
                    p_users['bcc'] = bcc
                    self.new_email_service(p_users, 'newuser')
                result['user_id'] = new_user_id.getvalue()
                result['status'] = 'OK'
                result['msg'] = 'User created successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to create a user - '
                result['msg'] += str(status_code.getvalue())
                logger.findaylog("""@ models - users -
                                insert_role_based_user - {}""".format(status_code.getvalue()))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 insert_role_based_user """ + str(error))
            result['msg'] = str(error)
            result['status'] = 1
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return result

    # update role based user
    @staticmethod
    def update_role_based_user(p_users):
        connection = None
        cursor = None
        result = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            cursor.execute("""
                        begin
                            qpex_usermanagement_pkg.update_user(
                                :p_user_id,
                                :p_known_as,
                                :p_email,
                                :p_phone,
                                :p_org_id,
                                :p_ui_language,
                                :p_number_format,
                                :p_date_format,
                                :p_notify_orders,
                                :p_notify_invoices,
                                :p_updated_by,
                                :x_status_code
                            );
                        end; """, p_user_id=p_users['user_id'],
                           p_known_as=p_users['known_as'],
                           p_email=p_users['email'],
                           p_phone=p_users['phone'],
                           p_org_id=p_users['org_id'],
                           p_ui_language=p_users['ui_language'],
                           p_number_format=p_users['number_format'],
                           p_date_format=p_users['date_format'],
                           p_notify_orders=p_users['notify_orders'],
                           p_notify_invoices=p_users['notify_invoices'],
                           p_updated_by=p_users['updated_by'],
                           x_status_code=status_code)

            if status_code.getvalue() == 'SUCCESS':
                if p_users['password'] and p_users['password_changed_date']:
                    encrypted_pwd = hashPassword(p_users['password'])
                    sql_file = db_util.getusermngSql()
                    query = sql_file['update_user_password_query']
                    cursor.execute(query, p_password=encrypted_pwd,
                                   p_password_changed_date=p_users[
                                       'password_changed_date'],
                                   p_user_id=p_users['user_id'])
                result['status'] = 'OK'
                result['msg'] = 'User details updated successfully'
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to update user details - '
                result['msg'] += str(status_code.getvalue())
                logger.findaylog("""@ models - users -
                                update_role_based_user - {}""".format(
                    status_code.getvalue()))
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                 update_role_based_user """ + str(error))
            result['msg'] = str(error)
            result['status'] = 1
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return result

    # update role based user status
    @staticmethod
    def update_user_status(data):
        connection = None
        cursor = None
        result = {}
        status = ''
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            for i in range(len(data['user_id'])):
                status_code = cursor.var(cx_Oracle.STRING)
                if data['status'] == 'I':
                    cursor.execute("""
                                    begin
                                        qpex_usermanagement_pkg.deactivate_user(
                                            :p_user_id,
                                            :x_status_code
                                        );
                                    end;""", p_user_id=data['user_id'][i],
                                   x_status_code=status_code)
                elif data['status'] == 'A':
                    cursor.execute("""
                                    begin
                                        qpex_usermanagement_pkg.activate_user(
                                            :p_user_id,
                                            :x_status_code
                                        );
                                    end;""", p_user_id=data['user_id'][i],
                                   x_status_code=status_code)
                status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                if data['status'] == 'I':
                    result['msg'] = 'User(s) de-activated successfully'
                elif data['status'] == 'A':
                    result['msg'] = 'User(s) activated successfully'
            else:
                result['status'] = 1
                if data['status'] == 'I':
                    result['msg'] = 'Failed to de-activate User(s)- ' + str(
                        status)
                elif data['status'] == 'A':
                    result['msg'] = 'Failed to activate User(s)- ' + str(status)
                logger.findaylog("""@ models - users -
                                update_user_status - {} - {}""".format(data['status'], status))
        except Exception as e:
            logger.findaylog("""EXCEPTION models - users -
                    update_user_status """ + str(e))
            raise e
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        return result

    @staticmethod
    def activate_user(jsond):
        """
        User Account to be activated/deactivated
        :param jsond: {'status':'', 'user_id':'', 'updated_by':''
        :return: 'SUCCESS'
        """
        try:
            sql_file = db_util.getSqlData()
            with OracleConnectionManager() as conn:
                if jsond['status'] == 'A':
                    query = sql_file['activate_user_query']
                    conn.execute(query, p_updated_by=jsond['updated_by'],
                                 p_user_id=jsond['user_id'])
                else:
                    hashval = ''.join(random.choice
                                      (string.ascii_uppercase +
                                       string.ascii_lowercase +
                                       string.digits) for _ in range(10))
                    reset_password = hashPassword(hashval)
                    query = sql_file['deactivate_user_query']
                    conn.execute(query,
                                 p_updated_by=jsond['updated_by'],
                                 p_encrypted_password=reset_password,
                                 p_password=hashval,
                                 p_user_id=jsond['user_id'])
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - users -
                activate_user """ + str(e))
            raise e
        return 'SUCCESS'

    @staticmethod
    def user_access_search(request_data):
        """
        To get users who are having oracle responsibility or role responsibility
        or both the oracle and role responsibility
        :param request_data:
        {'oracle_key':'', 'role_key':''}
        :return: {'status':'', users:[], 'msg':''}
        """
        try:
            result = {}
            file_data = db_util.getusermngSql()
            user_details = []
            with OracleConnectionManager() as conn:
                if request_data['oracle_key'] is not None and \
                        request_data['role_key'] is not None:
                    query1 = file_data['check_oracle_responsibility']
                    query2 = file_data['check_role_responsibility']
                    query = '({0}) INTERSECT ({1})'.format(query1, query2)
                    conn.execute(query,
                                 p_responsibility_id=request_data['oracle_key'],
                                 p_role_id=request_data['role_key']
                                 )
                    user_details = conn.get_result()
                    result['status'] = 0
                elif request_data['oracle_key'] is not None:
                    query = file_data['check_oracle_responsibility']
                    conn.execute(query,
                                 p_responsibility_id=request_data['oracle_key'])
                    user_details = conn.get_result()
                    result['status'] = 0
                elif request_data['role_key'] is not None:
                    query = file_data['check_all_users_role_responsibility']
                    conn.execute(query,
                                 p_role_id=request_data['role_key'])
                    user_details = conn.get_result()
                    result['status'] = 0
                else:
                    query = file_data['summary_user_access']
                    user_id = request_data['user_id']
                    obj = CommonUtils()
                    if obj.check_role_exists(user_id,
                                             'UI-ACCESS-CONTROL-REPORT-ALL'):
                        user_id = ''
                    conn.execute(query, p_user_id=user_id)
                    user_details = conn.get_result()
                result['users'] = user_details
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - users -
                    user_access_search """ + str(e))
            raise e
        return result

    def sharecredentials(self, request_data):
        """
        to resend the credentials details
        @:param request_data: {
            "user_id": "",
            "updated_by": "",
            "cc": "",
            "bcc": "",
            "send_coupon_manual": ""
        }
        @:return
        """
        try:
            with OracleConnectionManager() as conn:
                sql_file = db_util.getusermngSql()
                user_details_qry = sql_file['user_details_query']
                conn.execute(user_details_qry, p_parm=request_data['user_id'])
                user_data = conn.get_result()[0]
                password = CommonUtils.generate_random_string(8)
                encrypted_pwd = hashPassword(password)
                user_data['password'] = password
                sql_file_q = db_util.getSqlData()
                query = sql_file_q['password_activate_user_query']
                conn.execute(query, p_updated_by=request_data['updated_by'],
                             p_user_id=request_data['user_id'],
                             p_password=encrypted_pwd)
                user_data['cc'] = request_data['cc']
                user_data['bcc'] = request_data['bcc']
                user_data['send_coupon_manual'] = request_data.get('send_coupon_manual')

            result = self.new_email_service(user_data, 'sharecredentials')
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - users -
                sharecredentials - """ + str(error))
            raise error

        return result

    def new_email_service(self, jsond, emailtype):
        try:
            if jsond['ui_language'] is None:
                jsond['ui_language'] = 'EN'
            sql_file = sql_util.get_translation_sql(jsond['ui_language'])
            subject = sql_file[emailtype + '_subject']
            template_subject = sql_file[emailtype + '_template_subject']
            if jsond.get('org_id') == 141:
                template_id = 12599091
            else:
                template_id = 1259909

            template_data = {
                'template_id': template_id,
                'params': [
                    {
                        'key': 'user_name',
                        'value': jsond['user_name']
                    },
                    {
                        'key': 'password',
                        'value': jsond['password']
                    },
                    {
                        'key': 'email_address',
                        'value': jsond['email_address']
                    },
                    {
                        'key': 'password_translation',
                        'value': sql_file['password_translate']
                    },
                    {
                        'key': 'user_name_translation',
                        'value': sql_file['user_name_translate']
                    },
                    {
                        'key': 'email_address_translation',
                        'value': sql_file['email_address_translate']
                    },
                    {
                        'key': 'template_subject',
                        'value': template_subject
                    },
                    {
                        'key': 'privacy_policy_translation',
                        'value': sql_file['privacy_policy_translate']
                    },
                    {
                        'key': 'our_key_translation',
                        'value': sql_file['our_key_translate']
                    },
                    {
                        'key': 'login_now',
                        'value': sql_file['login_now'].upper()
                    }
                ], 'subject': subject,
                'to_email': jsond['email_address'],
                'to_name': jsond['user_name'],
                'sender': {
                    'email': self.strings['sender_email'],
                    'name': self.strings['sender_name']
                },
                'attachments': [],
                'cc': jsond['cc'],
                'bcc': jsond['bcc']
            }
            # this parameter is sent only for B2B users
            # if true, we will send the Instructions Manual for coupons in the email
            if jsond.get('send_coupon_manual'):
                coupons_manual = Users.get_coupon_manual(jsond['ui_language'])
                template_data['attachments'].append(coupons_manual)
            result = CommonUtils.send_mail(template_data)
            if result == 'SUCCESS':
                status = {'status': 0, 'msg': 'Mail is sent successfully'}
            else:
                status = {'status': 0, 'msg': 'Failed to send the email'}
                logger.findaylog("new_email_service -{} ".format(status))
        except Exception as error:
            logger.findaylog(""" @ EXCEPTION - models - users -
                new_email_service """ + str(error))
            raise error
        return status

    @staticmethod
    def get_coupon_manual(ui_language):
        """
            To get the Coupons Instruction Manual file based on the
            UI language passed
        """
        try:
            if ui_language == 'IT':
                sql_file = sql_util.get_translation_sql(ui_language)
                coupon_manual_file_name = 'coupons_manual_it.pdf'
                coupon_manual_file_title = sql_file['coupon_manual_title']
            else:
                coupon_manual_file_name = 'coupons_manual_en.pdf'
                coupon_manual_file_title = 'Instructions Manual for Coupons.pdf'
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

            # Coupons instruction manual
            file_name = path + '/static/' + coupon_manual_file_name
            coupons_manual = open(file_name, 'r')
            coupons_manual = base64.b64encode(coupons_manual.read())
            result = {
                'file_type': 'application/pdf',
                'file_name': coupon_manual_file_title,
                'file_data': coupons_manual
            }
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - users -
                            get_coupon_manual """ + str(e))
            raise e
        return result


# generate encrypted password
def hashPassword(password):
    return auth_util.encrypt(password)
