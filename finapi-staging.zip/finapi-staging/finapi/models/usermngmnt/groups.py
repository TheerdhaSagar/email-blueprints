from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.models.usermngmnt.method_util import Methodutil


class Groups:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    @staticmethod
    def get_groups():
        logger.addinfo('@ models - groups - get_groups(+)')
        return_data = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['groups_query']
            return_data = Methodutil.get_qry(query)
        except Exception as error:
            logger.findaylog("""@ 22 EXCEPTION - models - groups -
                 get_groups """ + str(error))
            raise error
        logger.addinfo('@ models - groups - get_groups(-)')
        return return_data

    @staticmethod
    def get_group_data(group_id):
        logger.addinfo('@ models - groups - get_group_data(+)')
        final = {}
        group_data = {}
        try:
            sql_file = db_util.getusermngSql()
            user_details_qry = sql_file['group_details_query']
            group_data = Methodutil.get_data_by_param(user_details_qry,
                                                      group_id)
        except Exception as error:
            logger.findaylog("""@ 39 EXCEPTION - models - groups -
                 get_group_data """ + str(error))
            raise error
        group_users_data = {}
        try:
            sql_file = db_util.getusermngSql()
            group_users_qry = sql_file['group_users_query']
            group_users_data = Methodutil.get_data_by_param(group_users_qry,
                                                            group_id)
        except Exception as error:
            logger.findaylog("""@ 49 EXCEPTION - models - groups -
                 get_group_data """ + str(error))
            raise error
        group_roles_data = {}
        try:
            sql_file = db_util.getusermngSql()
            group_roles_qry = sql_file['group_roles_query']
            group_roles_data = Methodutil.get_data_by_param(group_roles_qry,
                                                            group_id)
        except Exception as error:
            logger.findaylog("""@ 59 EXCEPTION - models - groups -
                 get_group_data """ + str(error))
            raise error
        final['group_details'] = group_data
        final['users'] = group_users_data
        final['roles'] = group_roles_data
        return final

    @staticmethod
    def get_group_details(group_id):
        logger.addinfo('@ models - groups - get_group_details(+)')
        groups_data = {}
        group_users_data = {}
        try:
            sql_file = db_util.getusermngSql()
            group_users_qry = sql_file['group_users_query']
            group_users_data = Methodutil.get_data_by_param(group_users_qry,
                                                            group_id)
        except Exception as error:
            logger.findaylog("""@ 78 EXCEPTION - models - groups -
                 get_group_details """ + str(error))
            raise error
        group_roles_data = {}
        try:
            sql_file = db_util.getusermngSql()
            group_roles_qry = sql_file['group_roles_query']
            group_roles_data = Methodutil.get_data_by_param(group_roles_qry,
                                                            group_id)
        except Exception as error:
            logger.findaylog("""@ 88 EXCEPTION - models - groups -
                 get_group_details """ + str(error))
            raise error
        logger.addinfo('@ models - groups - get_group_details(-)')
        groups_data['users'] = group_users_data
        groups_data['roles'] = group_roles_data
        return groups_data

    @staticmethod
    def group_id():
        logger.addinfo("@ models - groups - group_id(+)")
        sql_file = db_util.getusermngSql()
        query = sql_file['group_id_sequence']
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            data = cursor.execute(query).fetchone()
        except Exception as error:
            logger.findaylog("""@ 108 EXCEPTION - models - groups -
                 group_id """ + str(error))
        else:
            group_id = str(data[0])
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - groups - group_id(-)")
        return group_id

    # insert roles of user
    @staticmethod
    def save_roles(p_roles_list, group_id):
        logger.addinfo('@ models - groups - save_roles(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            for role in p_roles_list:
                role['REFERENCE_ID'] = group_id
                role['REFERENCE_TYPE'] = 'G'
                values = ""
                values = tuple(str(val) for key, val in role.items())
                row_list.append(values)
            if p_roles_list:
                dict_val = p_roles_list[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            cursor = connection.cursor()
            cursor.prepare("""insert into
            QPEX_USER_GROUP_ROLES """ + fieldname_strng+"""
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
        except Exception as error:
            logger.findaylog("""@154 EXCEPTION - models - groups -
                 save_roles """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo('@ models - groups - save_roles(-)')

    @staticmethod
    def validation(p_val):
        logger.addinfo('@ models - groups - validation(+)')
        data = {}
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['group_validation']
            data = Methodutil.get_validation(qry, p_val)
        except Exception as error:
            logger.findaylog("""@ 172 EXCEPTION - models - groups -
                 validation """ + str(error))
            raise error
        logger.addinfo('@ models - groups - validation(-)')
        return data

    # insert roles of user
    @staticmethod
    def save_users(p_users_list, group_id):
        logger.addinfo('@ models - groups - save_users(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            for user in p_users_list:
                user['GROUP_ID'] = group_id
                values = ""
                values = tuple(str(val) for key, val in user.items())
                row_list.append(values)
            if p_users_list:
                dict_val = p_users_list[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            cursor = connection.cursor()
            cursor.prepare("""insert into
            QPEX_USER_GROUPS """ + fieldname_strng+"""
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
        except Exception as error:
            logger.findaylog("""@ 213 EXCEPTION - models - groups -
                 save_users """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - groups - save_users(-)')

    # insert user
    @staticmethod
    def insert_header(p_groups, group_id):
        logger.addinfo('@ models - groups - insert_header(+)')
        connection = None
        cursor = None
        row_data = []
        sql_data = '''insert into QPEX_GROUPS ('''
        for group in p_groups:
            my_data = []
            for key, value in group.__dict__.items():
                my_data.append(value)
                my_new_tuple = tuple(my_data)
            row_data.append(my_new_tuple)
        for key, value in group.__dict__.items():
            sql_data += str(key)
            sql_data += ','
        sql_data += " GROUP_ID)\
                VALUES ( "
        sql_args = ""
        for idx, key in enumerate(group.__dict__.items()):
            sql_args += ":"+str(idx) + ","
        sql_data += sql_args + group_id + ")"
        returnval = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.executemany(sql_data, row_data)
            returnval['msg'] = "Group created successfully"
            returnval['status'] = 0
        except Exception as error:
            logger.findaylog("""@ 253 EXCEPTION - models - groups -
                 insert_header """ + str(error))
            returnval['msg'] = "Group creation failed"
            returnval['status'] = 1
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - groups - insert_header(-)')
        return returnval

    # insert roles of user
    @staticmethod
    def update_roles(p_roles_list, group_id):
        logger.addinfo('@ models - groups - update_roles(+)')
        final_data = Groups.new_roles(p_roles_list, group_id)
        connection = None
        cursor = None
        row_list = []
        role_ids = []
        my_ids = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            update_strng = "SET "
            for roleval in final_data:
                for key, value in roleval.items():
                    if key == 'role_id':
                        role_ids.append(value)
                    update_strng += str(key)
                    update_strng += '='
                    if isinstance(value, int):
                        update_strng += str(value)
                    else:
                        update_strng += "'" + value + "'"
                    update_strng += ','
                row_list.append(update_strng[:-1])
                update_strng = "SET "
            length = len(role_ids)
            sql_file = db_util.getusermngSql()
            qry = sql_file['user_roles_exist_query']
            for i in range(0, length):
                cursor.execute(qry, p_role_id=role_ids[i], p_user_id=group_id)
                data = cursor.fetchall()
                if len(data) == 0:
                    my_ids.append(i)
            for i in range(0, length):
                cursor.execute("""update
                QPEX_USER_GROUP_ROLES """ + str(row_list[i]) + """
                where role_id = """ + str(role_ids[i]) + """
                and reference_id = """ + str(group_id))
        except Exception as error:
            logger.findaylog("""@ 306 EXCEPTION - models - groups -
                 update_roles """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - groups - update_roles(-)')
        return "success"

    # insert roles of user
    @staticmethod
    def new_roles(p_roles_list, group_id):
        logger.addinfo('@ models - groups - new_roles(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            role_ids = []
            my_ids = []
            new_roles_list = []
            for roleval in p_roles_list:
                for key, value in roleval.items():
                    if key == 'role_id':
                        role_ids.append(value)
            length = len(role_ids)
            sql_file = db_util.getusermngSql()
            qry = sql_file['user_roles_exist_query']
            for i in range(0, length):
                cursor.execute(qry, p_role_id=role_ids[i], p_user_id=group_id)
                data = cursor.fetchall()
                if len(data) == 0:
                    my_ids.append(i)
            exist_list = []
            for i in range(0, len(my_ids)):
                new_roles_list.append(p_roles_list[my_ids[i]])
            for i in range(0, length):
                if i not in my_ids:
                    exist_list.append(p_roles_list[i])
            Groups.save_roles(new_roles_list, group_id)
        except Exception as error:
            logger.findaylog("""@ 349 EXCEPTION - models - groups -
                 new_roles """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - groups - new_roles(-)')
        return exist_list

    # insert roles of user
    @staticmethod
    def update_users(p_users_list, group_id):
        logger.addinfo('@ models - groups - update_users(+)')
        final_data = Groups.new_users(p_users_list, group_id)
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            row_list = []
            user_ids = []
            my_ids = []
            update_strng = "SET "
            for roleval in final_data:
                for key, value in roleval.items():
                    if key == 'user_id':
                        user_ids.append(value)
                    update_strng += str(key)
                    update_strng += '='
                    if isinstance(value, int):
                        update_strng += str(value)
                    else:
                        update_strng += "'" + value + "'"
                    update_strng += ','
                row_list.append(update_strng[:-1])
                update_strng = "SET "
            length = len(user_ids)
            sql_file = db_util.getusermngSql()
            qry = sql_file['group_users_exist_query']
            for i in range(0, length):
                cursor.execute(qry, p_user_id=user_ids[i], p_group_id=group_id)
                data = cursor.fetchall()
                if len(data) == 0:
                    my_ids.append(i)
            for i in range(0, length):
                cursor.execute("""update
                QPEX_USER_GROUPS """ + str(row_list[i]) + """
                where user_id = """ + str(user_ids[i]) + """
                and group_id = """ + str(group_id))
        except Exception as error:
            logger.findaylog("""@ 399 EXCEPTION - models - groups -
                 update_users """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - groups - update_users(-)')
        return "success"

    # insert roles of user
    @staticmethod
    def new_users(p_users_list, group_id):
        logger.addinfo('@ models - groups - new_users(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            user_ids = []
            my_ids = []
            new_users_list = []
            for userval in p_users_list:
                for key, value in userval.items():
                    if key == 'user_id':
                        user_ids.append(value)
            length = len(user_ids)
            sql_file = db_util.getusermngSql()
            qry = sql_file['group_users_exist_query']
            for i in range(0, length):
                cursor.execute(qry, p_user_id=user_ids[i], p_group_id=group_id)
                data = cursor.fetchall()
                if len(data) == 0:
                    my_ids.append(i)
            exist_list = []
            for i in range(0, len(my_ids)):
                new_users_list.append(p_users_list[my_ids[i]])
            for i in range(0, length):
                if i not in my_ids:
                    exist_list.append(p_users_list[i])
            Groups.save_users(new_users_list, group_id)
        except Exception as error:
            logger.findaylog("""@ 442 EXCEPTION - models - groups -
                 new_users """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - groups - new_users(-)')
        return exist_list

    # insert roles of user
    @staticmethod
    def update_groups(p_groups, group_id):
        logger.addinfo('@ models - groups - update_groups(+)')
        connection = None
        cursor = None
        update_strng = "SET "
        returnval = {}
        for key, value in p_groups.items():
            update_strng += str(key)
            update_strng += '='
            if isinstance(value, int):
                update_strng += str(value)
            else:
                update_strng += "'" + value + "'"
            update_strng += ','
        final = update_strng[:-1]
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.execute("""update
                QPEX_GROUPS """ + str(final) + """
                where group_id = """ + str(group_id))
        except Exception as error:
            logger.findaylog("""@ 475 EXCEPTION - models - groups -
                 update_groups """ + str(error))
            returnval['msg'] = "Fails"
            returnval['user_id'] = ""
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - groups - update_groups(-)')
        return "success"
