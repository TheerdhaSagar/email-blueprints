import re
import os
import csv
import tempfile
from datetime import datetime
import cx_Oracle
import paramiko
from finapi.utils.logdata import logger
from finapi.utils.constants import Status
from finapi.sql import sql_util
from finapi.utils.log_util import LogUtil
from finapi.utils.conn_util import OracleConnectionManager
from finapi.models.outofdoor.uploadfile import UploadOutofDoorFiles
from finapi.models.dsv.label_printing import LabelPrinting


@LogUtil.class_module_logs('dsv')
class DSV(object):

    def __init__(self):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())

    def get_invoice_container_ids(self):
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_invoice_ids']
            conn.execute(query)
            invoice_details = conn.get_result()
            invoice_ids = [invoice['invoice_no'] for invoice in invoice_details]
            container_nos = [invoice['container_no'] for invoice in invoice_details]
        return invoice_ids, container_nos

    @staticmethod
    def check_for_existing_invoices(invoice, existing_invoice, invoice_ids, container_ids):
        if invoice['invoice_no'] in invoice_ids or\
                invoice['container_no'] in container_ids:
            existing_invoice.append({'invoice_no': invoice['invoice_no'],
                                     'container_no': invoice['container_no']})
        return existing_invoice

    def import_dsv_excel(self, jsond):
        """
        import dsv excel files based on the supplier lookup code
        jsond: {"base64":"","created_id":"", "filename":"","invoice_arr":"", "invoice_dict":"", }
        """
        invoice_details = []
        supplier_name = jsond.get('supplier_lookup').lower()
        if supplier_name:
            # based on the supplier lookup code , the function name is created so call the function
            invoice_details = getattr(self, '%s_excel_to_json' % supplier_name)(jsond)
            # if there is an existing invoices , return the data
            if isinstance(invoice_details, dict) and invoice_details.get('invoice_dict'):
                return invoice_details
        status = DSV.insert_invoices(invoice_details, jsond)
        return status

    def tuus_excel_to_json(self, jsond):
        """
        TUUS related excel to json convertion
        """
        upload_obj = UploadOutofDoorFiles(jsond)
        sheets_list = upload_obj.get_sheets_list()
        invoice_arr = jsond.get('invoice_arr') or []
        invoice_dict = {}
        existing_invoice = []
        # for getting existing invoice ids, container ids
        invoice_ids, container_ids = self.get_invoice_container_ids()
        if not invoice_arr:
            # check for sheets_list
            for sheet in sheets_list:
                upload_obj.sheet = upload_obj.get_workbook(sheet)
                # check if the sheet is visible and contains any rows
                if upload_obj.sheet.visibility == 0 and upload_obj.sheet.nrows:
                    invoice_dict = self.tuus_invoice_header(upload_obj, sheet)
                    # check if the invoice is an existing in db
                    existing_invoice = DSV.check_for_existing_invoices(invoice_dict,
                                                                       existing_invoice,
                                                                       invoice_ids, container_ids)
                # append all the invoices to an array
                if invoice_dict.get('invoice_no'):
                    invoice_arr.append(invoice_dict)
            if existing_invoice:
                return {'status': 0, 'invoice_dict': existing_invoice,
                        'invoice_arr': invoice_arr, 'row_index': upload_obj.row_index}
        # fetch all invoices items list
        invoice_arr = self.tuus_invoice_items(invoice_arr, upload_obj)
        return invoice_arr

    def tuus_invoice_header(self, upload_obj, sheetname):
        """
        Get TUUS header table details
        """
        items_keys = self.sql_file['tuus_item_keys']
        invoice_dict = {'items_arr': [], 'sheet_name': sheetname, 'cans_error': []}
        for i in range(upload_obj.sheet.nrows):
            cell_value = upload_obj.sheet.cell_value(i, 0)
            substr = next(DSV.replace_string_text(
                cell_value, " ", "", lowercase=True).find(elem.lower()) for elem in items_keys)
            if 'ITEM' in cell_value:
                upload_obj.row_index = i
                break
            elif substr != -1:
                upload_obj.row_index = i - 1
                break
            else:
                invoice_dict = self.invoice_header(cell_value, invoice_dict)
        return invoice_dict

    @staticmethod
    def replace_string_text(value, replace_char, replace_with, lowercase=False, uppercase=False):
        new_value = value.replace(replace_char, replace_with)
        if lowercase:
            return new_value.lower()
        elif uppercase:
            return new_value.upper()
        return new_value

    def invoice_header(self, cell_value, invoice_dict):
        new_cell_value = DSV.replace_string_text(cell_value, " ", "", True)
        for key, values in self.sql_file['file_keys'].items():
            substr = [DSV.replace_string_text(s, ' ', '', True) for s in values
                      if new_cell_value.find(DSV.replace_string_text(s, ' ', '', True)) != -1]
            if substr:
                last_char_index = re.search(substr[0], new_cell_value).end()
                if key == 'net_weight':
                    word = new_cell_value.find('CONTAINER'.lower()) + 9
                    invoice_dict[key] = DSV.replace_string_text(
                        new_cell_value[last_char_index: word], ':', '', uppercase=True).strip()
                else:
                    input_val = DSV.replace_string_text(
                        new_cell_value[last_char_index:], ':', '', uppercase=True).strip()
                    invoice_dict[key] = input_val
        return invoice_dict

    def tuus_invoice_items(self, invoice_arr, upload_obj):
        """
        Fetch items for TUUS
        """
        for invoice in invoice_arr:
            upload_obj.sheet = upload_obj.get_workbook(invoice['sheet_name'])
            invoice = self.invoice_lines(
                upload_obj.sheet, invoice, upload_obj.row_index)
            if invoice.get('gross_weight'):
                gross_weight_with_uom = re.search(
                    "([0-9]+[.,][0-9]+[.,]*[0-9]+)", invoice.get('gross_weight'))
                first_index = gross_weight_with_uom.start()
                last_index = gross_weight_with_uom.end()
                invoice['uom'] = invoice.get('gross_weight')[
                    last_index:]
                invoice['gross_weight'] = float(invoice.get('gross_weight')[
                    first_index:last_index].replace(',', ''))

            if invoice.get('net_weight'):
                net_weight_with_uom = re.search(
                    "([0-9]+[.,][0-9]+[.,]*[0-9]+)", invoice.get('net_weight'))
                first_index = net_weight_with_uom.start()
                last_index = net_weight_with_uom.end()
                invoice['net_weight'] = float(
                    str(invoice['net_weight'])[first_index:last_index].replace(',', ''))
        return invoice_arr

    def invoice_lines(self, sheet, invoice_details, row_index):
        items_val = False
        cans_flag = False
        cans_error_arr = []
        items_keys = self.sql_file['tuus_item_keys']
        for i in range(row_index, sheet.nrows):
            cell_value = sheet.cell_value(i, 0)
            if cell_value:
                substr = next(DSV.replace_string_text(
                    cell_value, " ", "", lowercase=True).find(elem.lower()) for elem in items_keys)
                if substr != -1:
                    item_code = re.findall(r'\d+', cell_value)[0]
                    items_val = True
                elif ('ITEM' in cell_value) or cell_value in self.sql_file['buyers_keys']:
                    items_val = 'ITEM' not in cell_value
                    if 'CODES' in cell_value:
                        cans_flag = 'CANS' in sheet.cell_value(i, 2)
                elif items_val:
                    items = {'item_code': item_code}
                    items['codes'] = sheet.cell_value(i, 0) + ' ' + sheet.cell_value(i, 1)

                    cans_error_arr, items['cartons'] = DSV.convert_to_cartons(
                        cans_flag, cans_error_arr,
                        {
                            'item_code': item_code,
                            'cartons': sheet.cell_value(i, 2),

                        })
                    date_string = DSV.check_date_type(sheet.cell_value(i, 4))
                    items['expiry_date'] = datetime.strptime(
                        date_string, "%m%d%y").strftime('%d-%b-%y')
                    items['batch_number'] = date_string
                    invoice_details['items_arr'].append(items)
            else:
                items_val = False
                cans_flag = False
        invoice_details['cans_error'] = cans_error_arr
        return invoice_details

    @staticmethod
    def check_date_type(cell_value):
        date_string = ''
        if isinstance(cell_value, str):
            date_string = cell_value.replace('BB ', '')
        else:
            date_string = str(int(cell_value)).zfill(6)
        return date_string

    @staticmethod
    def convert_to_cartons(flag, error_arr, jsond):
        value = jsond['cartons']
        if flag:
            with OracleConnectionManager() as conn:
                cartons = conn.set_output_param('NUMBER')
                conn.execute("""
                BEGIN
                    qpex_dsv_pkg.item_pces_to_cts(
                        :p_item_code,
                        :p_pces,
                        :p_cts,
                        :x_status_code);
                END;""", output_key='x_status_code',
                             p_item_code=jsond['item_code'],
                             p_pces=jsond['cartons'],
                             p_cts=cartons)
                status = conn.get_output_param(raise_exception=False)
                if status != 'FAIL' and cartons.getvalue():
                    value = cartons.getvalue()
                else:
                    error_arr.append(jsond['item_code'])
        return error_arr, value

    def hqus_excel_to_json(self, jsond):
        """
        Convert HQUS excel to json
        """
        upload_obj = UploadOutofDoorFiles(jsond)
        sheets_list = upload_obj.get_sheets_list()
        # for getting existing invoice ids, container ids
        invoice_ids, container_ids = self.get_invoice_container_ids()
        invoice_arr = jsond.get('invoice_arr') or []
        existing_invoice = []
        # if invoices are not found, fetch invoice header details
        if not invoice_arr:
            for sheet in sheets_list:
                upload_obj.sheet = upload_obj.get_workbook(sheet)
                invoice_dict = {'items_arr': [], 'sheet_name': sheet, 'cans_error': []}
                if upload_obj.sheet.visibility == 0 and upload_obj.sheet.nrows:
                    # fetch hiq invoice_header details
                    invoice_dict = self.get_hq_invoice_header(upload_obj, invoice_dict)
                    existing_invoice = DSV.check_for_existing_invoices(invoice_dict,
                                                                       existing_invoice,
                                                                       invoice_ids, container_ids)
                if invoice_dict.get('invoice_no'):
                    invoice_arr.append(invoice_dict)
            if existing_invoice:
                return {'status': 0, 'invoice_dict': existing_invoice, 'row_index': None,
                        'invoice_arr': invoice_arr}
        # fetch all invoices related items
        invoice_arr = self.hq_all_invoices(upload_obj, invoice_arr)
        return invoice_arr

    def get_hq_invoice_header(self, upload_obj, invoice_dict):
        """
        get invoice_header details for HQUS
        """
        for row_index in range(upload_obj.sheet.nrows):
            row = upload_obj.sheet.row_values(row_index)
            hiq_keys = self.sql_file['hiq_header_keys']
            for key, values in list(hiq_keys.items()):
                column_index = next((str(index) for index, item in enumerate(row) for val in values
                                     if isinstance(item, (str)) and
                                     re.search(DSV.replace_string_text(val, ' ', '', True),
                                               DSV.replace_string_text(item, ' ', '', True))), None)
                if column_index and not invoice_dict.get(key):
                    invoice_dict = DSV.check_hq_header_info(
                        invoice_dict, upload_obj, row_index, column_index, key)
            if invoice_dict.get('start_index'):
                break
        return invoice_dict

    @staticmethod
    def check_hq_header_info(invoice_dict, upload_obj, row_index, column_index, key):
        if key in ['invoice_no']:
            invoice_dict[key] = upload_obj.sheet.cell_value(
                row_index, int(column_index) + 1)
        elif key in ['container_no']:
            invoice_dict[key] = upload_obj.sheet.cell_value(
                row_index, int(column_index) + 2)
        else:
            invoice_dict['start_index'] = row_index
            invoice_dict['col_index'] = int(column_index)
        return invoice_dict

    def hq_all_invoices(self, upload_obj, invoice_arr):
        for invoice_dict in invoice_arr:
            upload_obj.sheet = upload_obj.get_workbook(invoice_dict['sheet_name'])
            if invoice_dict.get('start_index'):
                # fetch column name details
                _, columns = upload_obj.get_column_names(
                    start_index=invoice_dict['start_index'])
                new_clumns = self.column_mapping_with_excel_keys(columns)
                invoice_dict = DSV.get_hq_invoice_lines(upload_obj, new_clumns, invoice_dict)
        return invoice_arr

    def column_mapping_with_excel_keys(self, columns):
        # column names mapping keys
        hiq_item_keys = self.sql_file['hiq_items_keys']
        new_clumns = []
        for key, values in hiq_item_keys.items():
            flag = False
            new_col = {}
            if values:
                for column in columns:
                    if any(DSV.replace_string_text(column['column_name'], ' ', '', True).rstrip()
                           in DSV.replace_string_text(val, ' ', '', True)
                           for val in values):
                        new_col = {'column_index': column['column_index'],
                                   'column_name': column['column_name'],
                                   'column_type': column['column_type'],
                                   'oracle_name': key}
                        flag = True
                        new_clumns.append(new_col)
            if not flag:
                new_clumns.append({'oracle_name': key, 'column_name': 'NA'})
        return new_clumns

    @staticmethod
    def get_hq_invoice_lines(upload_obj, new_clumns, invoice_dict):
        item_code = None
        for row_index in range(invoice_dict['start_index'] + 1, upload_obj.sheet.nrows):
            row = {}
            for col in new_clumns:
                item_code, valor = DSV.check_column_val(col, row_index, upload_obj, item_code)
                row[col['oracle_name']] = valor
            empty_rows = all(bool(value) for key, value in row.items() if key != 'codes')
            if row['item_code'] and row['item_code'].lower() == 'total':
                invoice_dict['net_weight'] = None
                invoice_dict['gross_weight'] = None
                invoice_dict['uom'] = None
                invoice_dict['total'] = row['cartons']
                break
            elif not row['item_code'] or not empty_rows:
                continue
            row['expiry_date'] = datetime.strptime(
                row['expiry_date'], "%m%d%y").strftime('%d-%b-%y')
            invoice_dict['items_arr'].append(row)
        return invoice_dict

    @staticmethod
    def check_column_val(col, row_index, upload_obj, item_code):
        valor = None
        if col['column_name'] != 'NA':
            col_index = col['column_index']
            valor = upload_obj.sheet.cell(row_index, col_index).value
            if col['oracle_name'] == 'item_code':
                item_code = valor or item_code
                valor = item_code
        return item_code, valor

    @staticmethod
    def insert_invoices(invoice_details, jsond):
        """
        To insert the invoices from excel sheet to db
        """
        item_codes = []
        cartons = []
        codes = []
        batch_number = []
        expiry_dates = []
        sheet_error = []
        cans_error = []
        with OracleConnectionManager() as conn:
            for invoice in invoice_details:
                for items in invoice['items_arr']:
                    item_codes.append(items['item_code'])
                    cartons.append(float(items['cartons']))
                    codes.append(items['codes'])
                    expiry_dates.append(items['expiry_date'])
                    batch_number.append(items['batch_number'])
                if item_codes:
                    conn.execute('''
                            BEGIN
                                QPEX_DSV_PKG.manage_dsv_details(
                                :p_item_codes,
                                :p_codes,
                                :p_cartons,
                                :p_expiry_dates,
                                :p_batch_number,
                                :p_invoice_no,
                                :p_container_no,
                                :p_net_weight,
                                :p_gross_weight,
                                :p_total_cartons,
                                :p_uploaded_filename,
                                :p_uom,
                                :p_created_id,
                                :x_status_code
                                );
                            END;''',
                                 output_key='x_status_code',
                                 p_item_codes=conn.cursor.arrayvar(cx_Oracle.STRING, item_codes),
                                 p_codes=conn.cursor.arrayvar(cx_Oracle.STRING, codes),
                                 p_cartons=conn.cursor.arrayvar(cx_Oracle.NUMBER, cartons),
                                 p_expiry_dates=conn.cursor.arrayvar(
                                     cx_Oracle.STRING, expiry_dates),
                                 p_batch_number=conn.cursor.arrayvar(
                                     cx_Oracle.STRING, batch_number),
                                 p_invoice_no=invoice['invoice_no'],
                                 p_container_no=invoice['container_no'],
                                 p_net_weight=float(invoice.get('net_weight')) if invoice.get(
                                     'net_weight') else None,
                                 p_gross_weight=float(invoice.get('gross_weight')) if invoice.get(
                                     'gross_weight') else None,
                                 p_total_cartons=sum(cartons),
                                 p_uploaded_filename=jsond.get('filename'),
                                 p_uom=invoice.get('uom'),
                                 p_created_id=jsond.get('created_id', -1))
                    status = conn.get_output_param(raise_exception=False)
                    cans_error.append({'invoice_no': invoice['invoice_no'],
                                       'cans_error': invoice['cans_error']})
                    if status != 'SUCCESS':
                        sheet_error.append(invoice['invoice_no'])
        return DSV.output_result(sheet_error, cans_error, item_codes)

    @staticmethod
    def output_result(sheet_error, cans_error, item_codes):
        output = bool(sheet_error or not item_codes)
        msg = ''
        if sheet_error:
            msg += 'Failed to load Invoices :{}'.format(','.join(sheet_error))
        if output:
            msg += 'Failed to load Excel sheet'
        return {
            'status': Status.ERROR.value if output else Status.OK.value,
            'msg': 'Invoice details are added successfully',
            'sheet_msg': msg,
            'err_sheet': sheet_error,
            'cans_error': cans_error
        }

    def get_invoice_details(self, header_id):
        """
        to get invoice summary and details of imported excel file
        """
        result = {}
        with OracleConnectionManager() as conn:
            query = self.sql_file['get_dsv_summary']
            kwargs = dict(p_dsv_header_id=header_id)
            conn.execute(query, **kwargs)
            if not header_id:
                result = conn.get_result()
            else:
                result = conn.get_single_result()
                items_query = self.sql_file['get_dsv_invoice_details']
                history_query = self.sql_file['get_dsv_history']
                conn.execute(items_query, **kwargs)
                result['items'] = conn.get_result()
                conn.execute(history_query, **kwargs)
                result['history'] = conn.get_result()
        return {'status': Status.OK.value, 'invoice_details': result}

    @staticmethod
    def cancel_invoice(dsv_header_id):
        """
        If exported invoice is wrong and cancel it , the status is changed the cancelled
        """
        result = {}
        with OracleConnectionManager() as conn:
            conn.execute('''
            BEGIN
                    qpex_dsv_pkg.cancel_dsv_invoice(
                        :p_dsv_header_id,
                        :x_status_code
                    );

                END;''', output_key='x_status_code',
                         p_dsv_header_id=dsv_header_id)
            conn.get_output_param()
            result = {
                'status': Status.OK.value,
                'msg': 'Invoice details are deleted successfully'
            }
        return result

    @staticmethod
    def add_history(jsond):
        """
        if a user has downloaded the csv , the history is maintained in another table
        """
        result = {
            'status': Status.OK.value,
            'msg': 'History added successfully'
        }
        with OracleConnectionManager() as conn:
            conn.execute('''
                BEGIN
                    qpex_dsv_pkg.manage_history(
                        :p_dsv_header_id,
                        :p_downloaded_filename,
                        :p_description,
                        :p_created_id,
                        :x_status_code
                    );
                END;''', output_key='x_status_code',
                         p_dsv_header_id=jsond['header_id'],
                         p_downloaded_filename=jsond['filename'],
                         p_description=jsond['description'],
                         p_created_id=jsond['created_id'])
            status = conn.get_output_param(raise_exception=False)
            if status != 'SUCCESS':
                result = {
                    'status': Status.ERROR.value,
                    'msg': 'Failed to add history'
                }
        return result

    def export_to_file(self, req_obj, file_type):
        """
        Export invoice with item details to txt file
        """
        file_path = tempfile.gettempdir() + '/'
        with OracleConnectionManager() as conn:
            # get invoice with item details from db
            csv_query = self.sql_file['get_dsv_csv_details']
            conn.execute(csv_query, p_dsv_header_id=req_obj['header_id'])
            # fetch field names
            field_names = [header[0].lower() for header in conn.cursor.description]
            invoice_details = conn.get_result(convert_data=True)
            # filename to be invoiceno_containerno_datetime
            file_name = '_'.join([str(invoice_details[0]['invoice_no']).replace('/', ''),
                                  invoice_details[0]
                                  ['container_no'], datetime.now().strftime("%m%d%y%H%M%S")])
            file_name = '{}.{}'.format(file_name, file_type)
            # to remove existing file with the file_name
            if os.path.exists(file_path + file_name):
                os.remove(file_path + file_name)
            getattr(DSV, 'write_to_%s' % file_type)(
                file_path + file_name, invoice_details, field_names)
        req_obj['description'] += ' ' + file_name
        req_obj['filename'] = file_name
        status = DSV.upload_dsv_files(file_name)
        if status == 'SUCCESS':
            DSV.add_history(req_obj)
            return {'status': 0, 'file_name': file_name}
        return {'status': 1, 'msg': 'Failed to Export CSV file. Please try again later!',
                'file_name': file_name}

    @staticmethod
    def write_to_txt(file_path, invoice_details, field_names):
        with open(file_path, 'w') as csv_file:
            csv_file.write('\t'.join(field_names))
            csv_file.write('\n')
            for invoice in invoice_details:
                for field in field_names:
                    csv_file.write(DSV.py2_unicode_to_str(invoice[field]) + '\t')
                csv_file.write('\n')

    @staticmethod
    def write_to_csv(file_path, invoice_details, field_names):
        with open(file_path, 'w') as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=field_names)
            writer.writeheader()
            for invoice in invoice_details:
                writer.writerow({DSV.py2_unicode_to_str(k): DSV.py2_unicode_to_str(v)
                                 for k, v in list(invoice.items())})

    @staticmethod
    def py2_unicode_to_str(dict_val):
        if not dict_val:
            return '\t'
        # # unicode is only exist in python2
        # if isinstance(dict_val, str):
        #     return dict_val
        elif isinstance(dict_val, (int, float)):
            return str(round(dict_val, 2))
        return dict_val

    @staticmethod
    def upload_dsv_files(file_name):
        client = None
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            host = os.environ['PAYMENTS_SFTP_HOST']
            username = os.environ['PAYMENTS_SFTP_USER']
            password = os.environ['PAYMENTS_SFTP_PASS']
            path = os.environ['DSV_FILE_UPLOAD']
            client.connect(host, username=username, password=password)
            sftp = client.open_sftp()
            local_path_csv = tempfile.gettempdir() + '/' + file_name
            remote_path_csv = path + file_name
            sftp.put(local_path_csv, remote_path_csv)
            sftp.close()
            status = 'SUCCESS'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - dsv -
                 upload_dsv_files """ + str(error))
            raise error
        finally:
            if client:
                client.close()
        return status

    def get_chewy_download(self, data):
        result = {}
        if 'pallets' not in list(data.keys()):
            data = self.get_chewy_details(data['order_number'])['chewy_labels'][0]
        label_obj = LabelPrinting('chewy_label')
        for pallet in data['pallets']:
            ship_label = {key: value if value else '' for key,
                          value in list(data.items()) + list(pallet.items())}
            barcode_postal_code = label_obj.barcode_gs1128_generator(
                ship_label['ship_to_postal_code'])
            barcode_ssc = label_obj.barcode_gs1128_generator(ship_label['sscc'])
            ship_label['barcode_postal_code'] = barcode_postal_code
            ship_label['barcode_ssc'] = barcode_ssc
            html_file = label_obj.generate_html('chewy_label.html', ship_label)
            file_details = label_obj.pdf_generate(html_file)
        result = LabelPrinting.base64_file(file_details['file_path'], file_details['file_name'])
        self.update_creation_date(data)
        label_obj.delete()
        return result

    def update_creation_date(self, data):
        with OracleConnectionManager() as conn:
            query = self.sql_file['update_chewy_label_creation']
            conn.execute(query, p_user_id=data['created_by'],
                         p_delivery_number=data['delivery_number'])
        return {'status': 0, 'msg': 'Updated Successfully'}

    def get_chewy_details(self, order_id):
        result = []
        with OracleConnectionManager() as conn:
            if order_id:
                query = self.sql_file['get_chewy_details_by_order_id']
                conn.execute(query, p_order_number=order_id)
                orders = conn.get_result()
                if orders:
                    order_details = orders[0]
                    order_details['pallets'] = []
                    for order in orders:
                        pallet = {'sku': order['sku'], 'num_of_cts': order['num_of_cts'],
                                  'ct_qty': order['ct_qty'], 'sscc': order['sscc']}
                        order_details['pallets'].append(pallet)

                    result = [order_details]
            else:
                query = self.sql_file['get_summary']
                conn.execute(query)
                result = conn.get_result()
        return {'status': 0, 'chewy_labels': result}

    def get_dsv_suppliers(self):
        """
        For getting supplier invoice details
        """
        result = []
        with OracleConnectionManager() as conn:
            query = self.sql_file['dsv_suppliers']
            conn.execute(query)
            result = conn.get_result()
        return {'status': Status.OK.value, 'suppliers': result}
