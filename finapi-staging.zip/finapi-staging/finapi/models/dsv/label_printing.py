import os
import tempfile
import datetime
import base64
import shutil
import barcode
from barcode.writer import ImageWriter
import pdfkit
import jinja2
from PyPDF2 import PdfFileWriter, PdfFileReader
from finapi.utils.common_utils import CommonUtils
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('label_printing')
class LabelPrinting(object):

    def __init__(self, folder_name):
        self.pdf_writer = PdfFileWriter()
        self.random_str = CommonUtils.generate_random_string(10)
        self.tmp_file = tempfile.gettempdir() + '/'
        self.folder_name = folder_name
        self.folder_path = self.check_folder_exists(folder_name)
        self.date_now = datetime.datetime.now().strftime('%Y%m%d')

    def check_folder_exists(self, folder_name):
        if not os.path.exists(self.tmp_file + folder_name):
            os.mkdir(self.tmp_file + folder_name)
        return self.tmp_file + folder_name

    def generate_html(self, html_template, kwargs):
        # generate HTML file from template
        path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        path += '/static/'
        template = jinja2.Environment(
            loader=jinja2.FileSystemLoader(path),
            autoescape=True
        ).get_template(html_template).render(
            **kwargs
        )
        html_file_name = 'label_{}.html'.format(self.random_str)
        with open(self.tmp_file + html_file_name, 'w') as html_file:
            html_file.write(template)
        return html_file_name

    def pdf_generate(self, html_file_name):
        margin = '0.05in'
        # generate PDF file
        options = {
            'page-width': '10.2cm',
            'page-height': '15.2cm',
            'margin-top': margin,
            'margin-bottom': margin,
            'margin-left': margin,
            'margin-right': margin,
            'encoding': 'UTF-8',
            'quiet': ''
        }

        pdf_file_name = 'label_{}'.format(self.random_str)
        pdfkit.from_file(self.tmp_file + html_file_name, self.tmp_file + pdf_file_name + '.pdf',
                         options=options)
        pdf_file = PdfFileReader(open(self.tmp_file + pdf_file_name + '.pdf', 'rb'))
        self.pdf_writer.addPage(pdf_file.getPage(0))
        return self.write_to_pdf(pdf_file_name)

    def write_to_pdf(self, pdf_file_name):
        pdf_file_name = '{}_{}.pdf'.format(pdf_file_name, self.date_now)
        self.pdf_writer.write(open(self.folder_path + '/' + pdf_file_name, 'wb'))
        return {'file_path': self.folder_path + '/' + pdf_file_name, 'file_name': pdf_file_name}

    def barcode_gs1128_generator(self, barcode_val):
        # generating code128 barcode
        code = barcode.codex.Code128(barcode_val, writer=ImageWriter())
        barcode_file_name = 'bar_{}'.format(self.random_str)
        code.save(self.tmp_file + barcode_file_name, options={
            'quiet_zone': 0,
            'module_height': 6.0,
            'module_width': 0.1,
            'write_text': False
        })
        return self.tmp_file + barcode_file_name + '.png'

    @staticmethod
    def base64_file(file_path, file_name):
        result = {}
        with open(file_path, 'r') as tmp_file:
            result['file_data'] = base64.b64encode(tmp_file.read())
        result['file_name'] = '%s' % (file_name)
        return result

    def delete(self):
        # delete the labels folder and zip file if exists
        if os.path.exists(self.folder_path):
            shutil.rmtree(self.folder_path)
