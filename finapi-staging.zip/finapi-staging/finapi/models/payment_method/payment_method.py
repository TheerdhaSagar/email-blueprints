import ujson
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil


class PaymentMethod:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    #  used in Address to get payment terms of billto address
    @staticmethod
    @db_util.langs("American")
    def get_paymentmethods(paccntid):
        logger.addinfo('@ models - paymentmethod - get_paymentmethods(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['Payment_method']
            cur.execute(query, pcust_id=paccntid)
        except Exception as error:
            logger.findaylog("""@ 27 EXCEPTION - models - paymentmethod -
                 get_paymentmethods """ + str(error))
            raise error
        else:
            payment_dict = {}
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                payterm = {}
                for index, fn in enumerate(field_names):
                    payterm[fn] = row[index]
                    if fn == 'site_use_id':
                        keyval = row[index]
                if keyval in list(payment_dict.keys()):
                    payment_dict.get(keyval).append(payterm)
                else:
                    pay_list = []
                    pay_list.append(payterm)
                    payment_dict[keyval] = pay_list
            data = ujson.dumps(payment_dict)
            payment_data = ujson.loads(data)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - paymentmethod - get_paymentmethods(-)')
        return payment_data


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'paymentmethod',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
