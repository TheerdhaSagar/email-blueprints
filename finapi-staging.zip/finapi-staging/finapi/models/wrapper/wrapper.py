import os
import time
import jinja2

from apiclient.discovery import build
from google.oauth2 import service_account

from finapi.models.cms.cms import CMS
from finapi.utils.log_util import LogUtil
from finapi.utils.google_cred_util import GoogleCredUtil


@LogUtil.class_module_logs('wrapper')
class Wrapper(object):
    scopes = ['https://www.googleapis.com/auth/gmail.settings.basic',
              'https://www.googleapis.com/auth/gmail.settings.sharing',
              'https://www.googleapis.com/auth/gmail.readonly',
              'https://www.googleapis.com/auth/gmail.metadata',
              'https://www.googleapis.com/auth/admin.directory.user']

    def __init__(self):
        credential_file = os.environ.get('ALMO_SERVICE_ACCOUNT')
        self.credentials = service_account.Credentials.from_service_account_file(
            credential_file, scopes=self.scopes)

    @staticmethod
    def generate_signature(user):
        path = os.path.dirname(os.path.dirname(os.path.dirname(__file__))) + '/static/'
        template = 'signature_{}.html'.format(user['signature_template'])
        signature = jinja2.Environment(
            loader=jinja2.FileSystemLoader(path)
        ).get_template(template)
        return signature.render(name=user['name'],
                                designation=user['designation'],
                                email=user['email'],
                                phone=user['phone'],
                                work_phone=user['work_phone'],
                                address=user['address'],
                                im=user['im'],
                                footer_text=user.get('footer_text'),
                                footer_link=user.get('footer_link'),
                                footer_link_text=user.get('footer_link_text'))

    @staticmethod
    def get_user_address(user):
        addresses = user.get('addresses', [])
        for address in addresses:
            if address.get('type') == 'work':
                return address.get('formatted').replace('\n', '|')
        return ''

    @staticmethod
    def get_user_designation(user):
        organizations = user.get('organizations', [])
        for org in organizations:
            if org.get('primary'):
                return org.get('title')
        return ''

    @staticmethod
    def get_user_im(user):
        custom_schema = user.get('customSchemas')
        if custom_schema:
            commnunication = custom_schema.get('Communication')
            if commnunication:
                return commnunication.get('Skype')
        return ''

    @staticmethod
    def get_user_phone(user, phone_type):
        phones = user.get('phones', [])
        for phone in phones:
            if phone.get('type') == phone_type:
                return phone.get('value')

    def delegate_account(self, account=None):
        if not account:
            account = os.environ.get('ALMO_GOOGLE_ADMIN_ACCOUNT')
        return self.credentials.with_subject(account)

    def get_api(self, api, version, account=None):
        return build(api, version, credentials=self.delegate_account(account))

    def get_users(self):
        api = self.get_api('admin', 'directory_v1')
        response = api.users().list(customer='my_customer', projection='full').execute()
        users = response.get('users', [])
        if not users:
            result = {
                'status': 1,
                'msg': 'No users found in this domain'
            }
        else:
            result = []
            for user in users:
                result.append({
                    'name': user['name'].get('fullName'),
                    'firstname': user['name'].get('givenName'),
                    'lastname': user['name'].get('familyName'),
                    'email': user['primaryEmail'],
                    'address': Wrapper.get_user_address(user),
                    'designation': Wrapper.get_user_designation(user),
                    'im': Wrapper.get_user_im(user),
                    'phone': Wrapper.get_user_phone(user, 'mobile'),
                    'work_phone': Wrapper.get_user_phone(user, 'work')
                })
        return result

    def update_user(self, req):
        result = {'status': 0, 'msg': 'User details updated successfully'}
        api = self.get_api('admin', 'directory_v1')
        body = {
            'name': req['name']
        }
        if req['address']:
            body['addresses'] = [{
                'type': 'work',
                'formatted': req['address']
            }]
        if req['designation']:
            body['organizations'] = [{
                'primary': True,
                'title': req['designation']
            }]
        if req['phone']:
            body['phones'] = [{
                'type': 'mobile',
                'value': req['phone']
            }]
        if req['work_phone']:
            body['phones'] = body.get('phones', [])
            body['phones'].append({
                'type': 'work',
                'value': req['work_phone']
            })
        if req['im']:
            body['customSchemas'] = {
                'Communication': {
                    'Skype': req['im']
                }
            }
        api.users().update(userKey=req['email'], body=body).execute()
        if req.get('signature_template'):
            result = self.update_signature(req)
        return result

    def update_signature(self, req):
        api = self.get_api('gmail', 'v1', req['email'])
        body = {'signature': Wrapper.generate_signature(req)}
        api.users().settings().sendAs().patch(userId='me',
                                              sendAsEmail=req['email'],
                                              body=body).execute()
        return {'status': 0, 'msg': 'Signature updated successfully'}

    @staticmethod
    def get_gmail_contacts_list(req):
        contact_scopes = [
            'https://www.googleapis.com/auth/contacts',
            'https://www.googleapis.com/auth/contacts.readonly',
            'https://www.googleapis.com/auth/contacts.other.readonly',
            'https://www.googleapis.com/auth/directory.readonly'
        ]
        credentials = GoogleCredUtil(os.environ['CONTACTS_SERVICE_ACCOUNT_PATH'],
                                     scopes=contact_scopes)
        api = credentials.get_api('people', 'v1', req['email'])
        contacts = Wrapper.read_contacts(api)
        # filter the contacts which doesn't have CMS or Personal label
        contacts = [contact for contact in contacts
                    if not contact.get('exists_in_hubspot_or_personal')]
        return contacts

    @staticmethod
    def read_contacts(people_api):
        contacts = []
        cms_group = Wrapper.create_contact_group(people_api, 'CMS')
        personal_group = Wrapper.create_contact_group(people_api, 'Personal')
        # get contacts from people API
        result = Wrapper.get_next_contacts(people_api)
        if 'connections' in result:
            contacts.extend(Wrapper.parse_contacts_data(people_api, result,
                                                        groups=[cms_group, personal_group]))

        # get contacts from otherContacts API
        result = Wrapper.get_next_other_contacts(people_api)
        if 'otherContacts' in result:
            contacts.extend(Wrapper.parse_contacts_data(people_api, result,
                                                        groups=[cms_group, personal_group],
                                                        people=contacts,
                                                        list_type='other'))
        return contacts

    @staticmethod
    def check_duplicate_emails(contacts, emails):
        for contact in contacts:
            for email in emails:
                if email in contact['emails']:
                    return True
        return False

    @staticmethod
    def parse_contacts_data(api, result, groups,
                            people=None, list_type=''):
        contacts = []
        # run the loop till there is no nextPageToken in the response
        while True:
            page_token = result.get('nextPageToken')
            # list type other refers to contacts in otherContacts group in google
            data = Wrapper.get_contact_list_data(result, list_type)
            for contact in data:
                emails = Wrapper.get_contact_emails(contact)
                # in case of other contacts we need to check if the email is
                # already present in mycontacts group
                if list_type == 'other' and Wrapper.check_duplicate_emails(people, emails):
                    continue
                obj = {
                    'etag': contact['etag'],
                    'resource_name': contact['resourceName'],
                    'emails': emails,
                    'names': Wrapper.get_contact_names(contact),
                    'photo': Wrapper.get_contact_photo(contact)
                }
                # if membership information exist in contact then we check
                # whether the contact has Personal or CMS labels
                if 'memberships' in contact:
                    obj['exists_in_hubspot_or_personal'] = Wrapper.check_group_exists_in_contact(
                        contact['memberships'], groups=groups)
                    obj['memberships'] = contact['memberships']
                contacts.append(obj)
            if not page_token:
                return contacts
            # since there is a rate limit for the API we wait for 1 second
            # before request the next set of contacts
            time.sleep(1)
            if list_type == 'other':
                result = Wrapper.get_next_other_contacts(api, page_token)
            else:
                result = Wrapper.get_next_contacts(api, page_token)

    @staticmethod
    def get_contact_list_data(result, list_type):
        if list_type == 'other':
            return result['otherContacts']
        return result['connections']

    @staticmethod
    def get_next_contacts(api, page_token=None):
        return api.people().connections().list(
            resourceName='people/me',
            personFields='names,emailAddresses,photos,memberships',
            pageToken=page_token,
            pageSize=1000).execute()

    @staticmethod
    def get_next_other_contacts(api, page_token=None):
        return api.otherContacts().list(
            readMask='names,emailAddresses', pageToken=page_token,
            pageSize=1000).execute()

    # add all emails to contact
    @staticmethod
    def get_contact_emails(contact):
        emails = []
        if 'emailAddresses' in contact:
            for email_address in contact['emailAddresses']:
                if email_address['value'] not in emails:
                    emails.append(email_address['value'])
        return emails

    # get names associated with the email
    @staticmethod
    def get_contact_names(contact):
        names = {}
        if 'names' in contact:
            for name in contact['names']:
                names['display_name'] = name.get('displayName', '')
                names['family_name'] = name.get('familyName', '')
                names['given_name'] = name.get('givenName', '')
        return names

    # get contact photo
    @staticmethod
    def get_contact_photo(contact):
        if 'photos' in contact:
            for photo in contact['photos']:
                if 'metadata' in photo and photo['metadata']['primary']:
                    return photo['url']
        return ''

    @staticmethod
    def get_contact_groups(api):
        """ Return list of contact labels """
        return api.contactGroups().list().execute()

    @staticmethod
    def check_group_exists_in_contact(memberships, groups):
        """
        Check if a label exist for a particular contact. Labels are
        part of `memberships` property of the contact
        """
        for group in groups:
            for membership in memberships:
                if 'contactGroupMembership' in membership and\
                        membership['contactGroupMembership']['contactGroupResourceName'] == group:
                    return True
        return False

    @staticmethod
    def check_group_exists(api, group_name):
        """
        Check if a given `group_name` already exists in Contacts
        If yes then return True and the group resource name
        If no then return False and None
        """
        response = Wrapper.get_contact_groups(api)
        if 'contactGroups' in response:
            groups = response['contactGroups']
            for group in groups:
                if group.get('name') == group_name:
                    return True, group['resourceName']
        return False, None

    @staticmethod
    def create_contact_group(api, group_name):
        """
        Create a label if not exists otherwise return the label resource name
        """
        is_exists, group_resource_name = Wrapper.check_group_exists(api, group_name)
        if is_exists:
            return group_resource_name
        obj = {
            "contactGroup": {
                "name": group_name
            }
        }
        response = api.contactGroups().create(body=obj).execute()
        return response.get('resourceName')

    @staticmethod
    def copy_other_contact_to_group(api, resource_name):
        """
        Copy the contact from otherContacts group to myContacts group
        """
        body = {
            'copyMask': 'emailAddresses,names,phoneNumbers'
        }
        response = api.otherContacts().copyOtherContactToMyContactsGroup(
            body=body, resourceName=resource_name).execute()
        if 'resourceName' not in response:
            return None
        return response

    @staticmethod
    def update_contact_group(api, person, group_resource_name, retries=0):
        """
        Update the label for the given contact
        """
        body = {
            'etag': person['etag'],
            'memberships': person['memberships']
        }
        body['memberships'].append({
            'contactGroupMembership': {
                'contactGroupResourceName': group_resource_name
            }
        })
        try:
            result = api.people().updateContact(
                updatePersonFields="memberships",
                resourceName=person['resourceName'], body=body).execute()
            if 'resourceName' not in result:
                return False
        except Exception:
            if retries < 5:
                time.sleep(0.1)
                return Wrapper.update_contact_group(api, person, group_resource_name,
                                                    retries=retries + 1)
        return True

    @staticmethod
    def add_contact_label(req):
        scopes = [
            'https://www.googleapis.com/auth/contacts',
            'https://www.googleapis.com/auth/contacts.other.readonly'
        ]
        credentials = GoogleCredUtil(os.environ['CONTACTS_SERVICE_ACCOUNT_PATH'],
                                     scopes=scopes)
        api = credentials.get_api('people', 'v1', req['email'])
        group_resource_name = Wrapper.create_contact_group(api, req['group_name'])
        person = req
        person['resourceName'] = req['resource_name']
        # if contact is in other contacts then we need to copy it to
        # my contacts group before adding label
        if req['resource_name'].find('otherContacts') != -1:
            person = Wrapper.copy_other_contact_to_group(api, req['resource_name'])
            if not person:
                return {'status': 1, 'msg': 'Failed to copy contact from other contact group'}
        time.sleep(0.1)
        if not Wrapper.update_contact_group(api, person, group_resource_name):
            return {'status': 1, 'msg': 'Failed to update label for the contact'}
        return {'status': 0, 'msg': 'Contact label updated successfully'}
