import ujson
import datetime

from finapi.utils import auth_util
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.log_util import LogUtil


@LogUtil.class_module_logs('login')
class Login:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    # used to authenticate user details provided by the user
    @staticmethod
    def authenticate(user_name, password, src, login_as=None):
        connection = db_util.get_connection()
        cursor = None
        sql_file = db_util.getSqlData()
        result = ""
        # verify if the user exist or not
        try:
            user_query = sql_file['user_name_query']
            cursor = connection.cursor()
            cursor.execute(user_query, p_user_name=user_name.upper())
            user_data = cursor.fetchone()
            if not user_data:
                logger.findaylog(""" models - login - authenticate - INVALID USER""")
                return 'INVALID_USER'
            user_id = user_data[0]
            db_user_name = user_data[1]
            encrypted_pwd = user_data[2]
            accesses_left = user_data[3]
            failed_attempts = user_data[4]
            # email_address = user_data[5]
            # user_description = user_data[6]
            inactive_date = user_data[7]

            # account is active if account has no inactive_date or inactive_date is greater than sysdate
            is_account_active = inactive_date is None or inactive_date.date() > datetime.datetime.now().date()
            if db_user_name.upper() == user_name.upper() and is_account_active:
                if failed_attempts < 5 and auth_util.verify(password, encrypted_pwd):
                    # login as a different user is restricted to the
                    # hardcoded users
                    if login_as and user_id in [-1, 1, 4988, 4989, 5394]:
                        user_id = int(login_as)
                    data = Login.get_user_preferences(user_id)
                    result = data
                    query = sql_file['update_user_login_data']
                    cursor.execute(query.format(src, user_name.upper()))
                    connection.commit()
                else:
                    if failed_attempts == 0 and accesses_left == 0:
                        accesses_left = 5

                    if accesses_left == 0 or failed_attempts == 5:
                        # mail_data = {
                        #     'params': [
                        #         {
                        #             'key': 'user_name',
                        #             'value': user_description
                        #         }
                        #     ],
                        #     'subject': 'Cruscott: Unusual login activity',
                        #     'template_id': 779091,
                        #     'to_email': email_address,
                        #     'to_name': user_description
                        # }
                        # CommonUtils.send_mail(mail_data)
                        result = 'TOO_MANY_ATTEMPTS'
                    else:
                        failed_attempts += 1
                        accesses_left -= 1
                        query = sql_file['update_password_attempts']
                        cursor.execute(query, p_accesses_left=accesses_left,
                                       p_failed_attempts=failed_attempts,
                                       p_user_id=user_id)
                        connection.commit()
                        result = {
                            'accesses_left': accesses_left,
                            'failed_attempts': failed_attempts,
                            'msg': 'LOGIN_FAILED'
                        }
            else:
                result = 'DEACTIVATED_ACCOUNT'
        except Exception as error:
            logger.findaylog("""@ EXCEPTION - models - login -
                 authenticate """ + str(error))
            raise error
        finally:
            if cursor:
                cursor.close()
            db_util.release_connection(connection)
        if isinstance(result, str) or (isinstance(result, dict) and result.get('failed_attempts')):
            logger.findaylog(""" models - login - authenticate - """ + str(result))
        return result

    @staticmethod
    def get_user_preferences(user_id):
        try:
            con = db_util.get_connection()
            sqlFile = db_util.getSqlData()
            cur = con.cursor()
            cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            org_query = sqlFile['org_ids_query']
            cur.execute(org_query, p_user_id=user_id)
            org_data = cur.fetchall()
            org_list = []
            org_fieldnames = [a[0].lower() for a in cur.description]
            for org_row in org_data:
                org_names = {}
                for org_index, org_fn in enumerate(org_fieldnames):
                    org_names[org_fn] = org_row[org_index]
                org_list.append(org_names)
            b2b_query = sqlFile['b2b-query']
            cur.execute(b2b_query, p_user_id=user_id)
            b2b_data = cur.fetchone()
            if b2b_data is None:
                cust_acc_id = ''
            else:
                cust_acc_id = b2b_data[0]
            query = sqlFile['user_details_query']
            cur.execute(query, p_user_id=user_id)
            mydata = cur.fetchall()
            myuserpref_list = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in mydata:
                myuserpref = {}
                for index, fn in enumerate(fieldnames):
                    myuserpref[fn] = row[index]
                myuserpref_list.append(myuserpref)
            data = ujson.dumps(myuserpref_list)
            userpref_data = ujson.loads(data)
            list_permission = []
            finaluser_pref = {}
            default_org_id = ""
            vendor_id = ""
            for userdict in userpref_data:
                default_org_id = userdict['default_org_id']
                if userdict['permission_type'] == 'UI':
                    permission = userdict['reference_type'
                                          ] + "-" + userdict["reference_value"]
                    list_permission.append(permission)
                if userdict['permission_type'] == 'D':
                    finaluser_pref[userdict['reference_type']
                                   .lower()] = userdict['reference_value']
                if userdict['reference_type'] == 'VENDOR_ID':
                    vendor_id = userdict['reference_value']
                for key in list(userdict.keys()):
                    if key not in list(finaluser_pref.keys()):
                        finaluser_pref[key] = userdict[key]
                finaluser_pref['permissions'] = list_permission
                del finaluser_pref["reference_type"]
                del finaluser_pref["reference_value"]
                del finaluser_pref["permission_type"]
                del finaluser_pref["permission_name"]
            resource_query = sqlFile['user_id_query']
            cur.execute(resource_query, p_user_id=user_id)
            data = cur.fetchone()
            if data is None:
                resource_id = ''
            else:
                resource_id = data[0]
            finaluser_pref["resource_id"] = resource_id
            finaluser_pref["cust_acc_id"] = cust_acc_id
            keys = list(finaluser_pref.keys())
            if 'salesrep_id' not in keys:
                finaluser_pref["salesrep_id"] = ''
            finaluser_pref["organizations"] = org_list
            if "organization_id" in finaluser_pref:
                del finaluser_pref["organization_id"]
            finaluser_pref["organization_id"] = default_org_id
            salesrep_ids_query = sqlFile['salesrep_ids_query']
            cur.execute(salesrep_ids_query, p_user_id=user_id)
            salesreps_data = cur.fetchall()
            salesreps = []
            salesreps_fieldnames = [a[0].lower() for a in cur.description]
            for row in salesreps_data:
                myuserpref = {}
                for index, fn in enumerate(salesreps_fieldnames):
                    myuserpref[fn] = row[index]
                salesreps.append(myuserpref)
            if len(salesreps) > 0:
                finaluser_pref["salesreps"] = salesreps
            else:
                finaluser_pref["salesreps"] = ''
            sales_group_query = sqlFile['user_sales_channels_query']
            cur.execute(sales_group_query, p_user_id=user_id)
            groups_data = cur.fetchall()
            group_names = []
            group_fieldnames = [a[0].lower() for a in cur.description]
            for row in groups_data:
                for index, fn in enumerate(group_fieldnames):
                    group_names.append(row[index])
            finaluser_pref["groups"] = group_names
            finaluser_pref["vendor_id"] = vendor_id
        except Exception as error:
            logger.findaylog("""@ 157 EXCEPTION - models - login -
                 get_user_preferences """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        return finaluser_pref

    @staticmethod
    def get_appversion():
        con = None
        cur = None
        app_list = []
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['almo_eappqry']
            cur.execute(query)
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                login_data = {}
                for index, fn in enumerate(field_names):
                    login_data[fn] = row[index]
                app_list.append(login_data)
        except Exception as error:
            logger.findaylog("""@ 181 EXCEPTION - models - login -
                 get_appversion """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        return app_list

    @staticmethod
    def get_vesrion(app_name):
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['mobile_version_query']
            cursor.execute(query, p_app_name=app_name)
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                version = {}
                for index, fn in enumerate(fieldnames):
                    version[fn] = row[index]
        except Exception as error:
            logger.findaylog("""@ 665 EXCEPTION - models - surveys -
                 get_vesrion """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        return version
