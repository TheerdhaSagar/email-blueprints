from finapi.utils.logdata import logger
import os
from mailjet_rest import Client
import csv
import base64
import string
import random
import xlrd
from collections import OrderedDict


class Contacts:

    def __init__(self):
        self.api_key = os.environ['MJ_APIKEY_PUBLIC']
        self.api_secret = os.environ['MJ_APIKEY_PRIVATE']
        self.mailjet_api = Client(auth=(self.api_key, self.api_secret))

    def get_contact_lists(self):
        logger.addinfo('@ models - contacts - get_contact_lists(+)')
        try:
            account_info = self.mailjet_api.contactslist.get(
                filters={'limit': 0}
            )
        except Exception as error:
            logger.findaylog("""@ 22 EXCEPTION - models - contacts -
                 get_contact_lists """ + str(error))
            raise error
        logger.addinfo('@ models - contacts - get_contact_lists(-)')
        return account_info

    def get_contacts(self, list_id):
        logger.addinfo('@ models - contacts - get_contacts(+)')
        try:
            contacts = self.mailjet_api.contact.get(
                filters={'contactsList': list_id, 'limit': 0})
            contacts = contacts.json()
            contact_data = self.get_contact_data(list_id)
            contacts['contact_data'] = contact_data.json()
            properties = self.get_properties()
            contacts['properties'] = properties.json()
            # contacts['all_contacts'] = self.get_all_contacts()
        except Exception as error:
            logger.findaylog("""@ 40 EXCEPTION - models - contacts -
                 get_contacts """ + str(error))
            raise error
        logger.addinfo('@ models - contacts - get_contacts(-)')
        return contacts

    def get_properties(self):
        logger.addinfo('@ models - contacts - get_properties(+)')
        try:
            properties = self.mailjet_api.contactmetadata.get(
                filters={'limit': 0}
            )
        except Exception as error:
            logger.findaylog("""@ 52 EXCEPTION - models - contacts -
                 get_properties """ + str(error))
            raise error
        logger.addinfo('@ models - contacts - get_properties(-)')
        return properties

    def get_contactdata(self):
        logger.addinfo('@ models - contacts - get_contactdata(+)')
        try:
            contact_data = self.mailjet_api.contactdata.get(
                    filters={'limit': 0})
        except Exception as error:
            logger.findaylog("""@ 65 EXCEPTION - models - contacts -
                 get_contactdata """ + str(error))
            raise error
        logger.addinfo('@ models - contacts - get_contactdata(-)')
        return contact_data

    def get_contact_data(self, list_id):
        logger.addinfo('@ models - contacts - get_contact_data(+)')
        try:
            contact_data = self.mailjet_api.contactdata.get(
                        filters={'ContactsList': list_id, 'limit': 0})
        except Exception as error:
            logger.findaylog("""@ 78 EXCEPTION - models - contacts -
                 get_contact_data """ + str(error))
            raise error
        logger.addinfo('@ models - contacts - get_contact_data(-)')
        return contact_data

    def add_list(self, jsond):
        logger.addinfo('@ models - contacts - add_list(+)')
        try:
            data = {
                'Name': jsond['name']
            }
            result = self.mailjet_api.contactslist.create(data=data)
        except Exception as error:
            logger.findaylog("""@ 93 EXCEPTION - models - contacts -
                 add_list """ + str(error))
            raise error
        logger.addinfo('@ models - objectives - add_list(-)')
        return result

    def update_list(self, jsond):
        logger.addinfo('@ models - contacts - update_list(+)')
        try:
            result = self.mailjet_api.contactslist.update(
                id=jsond['id'], data={'Name': jsond['Name']}
            )
        except Exception as e:
            logger.findaylog(""" @ 130 EXCEPTION - models - contacts -
                             update_list """ + str(e))
            raise e
        logger.addinfo('@ models - contacts - update_list(-)')
        return result

    def delete_list(self, list_id):
        logger.addinfo('@ models - contacts - add_list(+)')
        try:
            result = self.mailjet_api.contactslist.delete(id=list_id)
        except Exception as error:
            logger.findaylog("""@ 105 EXCEPTION - models - contacts -
                 delete_list """ + str(error))
            raise error
        logger.addinfo('@ models - contacts - delete_list(-)')
        return result

    def delete_contact(self, jsond):
        logger.addinfo('@ models - contacts - delete_contact(+)')
        try:
            id = jsond['list_id']
            contacts = jsond['contacts']
            data = {
                'Action': 'remove',
                'Contacts': contacts
            }
            method = self.mailjet_api.contactslist_ManageManyContacts
            result = method.create(id=id, data=data)
        except Exception as e:
            logger.findaylog(""" EXCEPTION 134 - models - contacts -
                            delete_contact """ + str(e))
            raise e
        logger.addinfo('@ models - contacts - delete_contact(-)')
        return result

    def add_contact(self, jsond):
        logger.addinfo('@ models - contacts - add_list(+)')
        try:
            id = jsond[0]['list_id']
            contacts = []
            for c in range(len(jsond)):
                contact = {}
                contact['Email'] = jsond[c]['email']
                contact['Name'] = jsond[c]['name']
                properties = {}
                for p in jsond[c]['properties']:
                    properties[p['Name']] = p['value']
                contact['properties'] = properties
                contacts.append(contact)
            data = {
                'Action': jsond[0]['action'],
                'Contacts': contacts
            }
            method = self.mailjet_api.contactslist_ManageManyContacts
            result = method.create(id=id, data=data)
            # result = mailjet_api.contact.create(data=data)
        except Exception as error:
            logger.findaylog("""@ 129 EXCEPTION - models - contacts -
                 add_list """ + str(error))
            raise error
        logger.addinfo('@ models - contacts - add_list(-)')
        return result

    def add_property(self, jsond):
        logger.addinfo('@ models - contacts - add_property(+)')
        try:
            data = {
                'Datatype': jsond['datatype'],
                'Name': jsond['name'],
                'NameSpace': 'static'
            }
            result = self.mailjet_api.contactmetadata.create(data=data)
        except Exception as error:
            logger.findaylog("""@ 146 EXCEPTION - models - contacts -
                 add_property """ + str(error))
            raise error
        logger.addinfo('@ models - contatcs - add_property(-)')
        return result

    def update_property(self, jsond):
        logger.addinfo('@ models - contacts - update_property(+)')
        try:
            result = self.mailjet_api.contactmetadata.update(
                        id=jsond['id'], data={'Name': jsond['name']})
        except Exception as error:
            logger.findaylog("""@ 160 EXCEPTION - models - contacts -
                 update_property """ + str(error))
            raise error
        logger.addinfo('@ models - contatcs - update_property(-)')
        return result

    def delete_property(self, jsond):
        logger.addinfo('@ models - contacts - delete_property(+)')
        try:
            result = self.mailjet_api.contactmetadata.delete(
                    id=jsond['id'], data={'Name': jsond['name']})
        except Exception as error:
            logger.findaylog("""@ 172 EXCEPTION - models - contacts -
                 delete_property """ + str(error))
            raise error
        logger.addinfo('@ models - contatcs - delete_property(-)')
        return result

    def id_generator(self):
        size = 8
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))

    def read_file(self, jsond):
        logger.addinfo('@ models - contacts - read_file(+)')
        try:
            decoded = base64.b64decode(jsond['base64'])
            file_name = self.id_generator()
            text_file = open(file_name, 'w')
            text_file.write(decoded)
            text_file.close()
            if jsond['filetype'] == 'text/csv':
                tmp_data = self.csv_reading(file_name)
            else:
                tmp_data = self.xls_reading(file_name)
            if tmp_data == 'error':
                logger.addinfo("@ models - contacts - read_file(-)")
                return 'error'
            contacts_data = []
            for t in tmp_data:
                if t != {}:
                    contacts_data.append(t)
        except Exception as error:
            logger.findaylog("""@ 216 EXCEPTION - models - contacts -
                 read_file """ + str(error))
            raise error
        logger.addinfo('@ models - contatcs - read_file(-)')
        return contacts_data

    def csv_reading(self, file_name):
        logger.addinfo('@ models - contacts - csv_reading(+)')
        array = []
        try:
            with open(file_name, 'rb') as csvfile:
                file_data = csv.reader(csvfile, delimiter=',', quotechar='|')
                for row in file_data:
                    array.append(row)
                tmp_array = []
                for j in range(1, len(array)):
                    tmp = [0] * len(array[j])
                    for i in range(len(array[j])):
                        tmp[i] = array[j][i].strip('"')
                    tmp_array.append(tmp)
                header_array = [0] * len(array[0])
                for i in range(len(array[0])):
                    header_array[i] = array[0][i].strip('"')
            final_data = []
            for i in range(len(tmp_array)):
                combo = list(zip(header_array, tmp_array[i]))
                who = dict(combo)
                final_data.append(who)
            os.remove(file_name)
        except Exception as error:
            logger.findaylog("""@ 246 EXCEPTION - models - contacts -
                 csv_reading """ + str(error))
            raise error
        logger.addinfo('@ models - contatcs - csv_reading(-)')
        return final_data

    def xls_reading(self, file_name):
        logger.addinfo('@ models - contacts - xls_reading(+)')
        try:
            b = xlrd.open_workbook(file_name)
            sheet = b.sheet_by_index(0)
            cols = []
            col_types = []
            for col in range(0, sheet.ncols):
                cols.append(sheet.cell_value(0, col))
                col_types.append(sheet.cell_type(1, col))
            data_list = []
            for rownum in range(1, sheet.nrows):
                data = OrderedDict()
                r = sheet.row_values(rownum)
                for i in range(0, len(cols)):

                    # col_type = 4 referes boolean values
                    if col_types[i] == 4:
                        if r[i] == 1:
                            data[cols[i]] = True
                        else:
                            data[cols[i]] = False
                    else:
                        data[cols[i]] = r[i]
                data_list.append(data)
            os.remove(file_name)
        except Exception as error:
            logger.findaylog("""@ 273 EXCEPTION - models - contacts -
                 xls_reading """ + str(error))
            raise error
        logger.addinfo('@ models - contatcs - xls_reading(-)')
        return data_list

    def import_list(self, jsond):
        logger.addinfo('@ models - contacts - import_list(+)')
        response = {}
        try:
            response['status'] = 'success'
            if jsond['listType'] == 'newList':
                result = self.add_list(jsond)
                result = result.json()
                if 'StatusCode' in result:
                    response['msg'] = result['ErrorMessage']
                    response['status'] = 'error'
                else:
                    list_id = result['Data'][0]['ID']
                    list_name = result['Data'][0]['Name']
                    response['list_name'] = list_name
                    response['list_id'] = list_id
            else:
                list_id = jsond['id']
            if response['status'] == 'success':
                contacts = jsond['contacts']
                method = self.mailjet_api.contact_managecontactslists
                for i in range(len(contacts)):
                    data = {
                        'ContactsLists': [
                            {
                                'ListID': list_id,
                                'Action': 'addnoforce'
                            }
                        ]
                    }
                    list_result = method.create(
                                    id=contacts[i]['ID'], data=data)
                    if 'StatusCode' in list_result:
                        response['status'] = 'error'
        except Exception as e:
            logger.findaylog(""" @ 332 EXCEPTION - models - contacts -
                             import_list """ + str(e))
            raise e
        logger.addinfo('@ models - contacts - import_list(-)')
        return response

    def merge_list(self, jsond):
        logger.addinfo('@ models - contacts - merge_list(+)')
        response = {}
        try:
            response['status'] = 'success'
            lists = jsond['lists']
            list_name = jsond['listName']
            add_status = self.add_list({'name': list_name})
            add_status = add_status.json()
            if 'StatusCode' not in add_status:
                list_id = add_status['Data'][0]['ID']
                for i in range(len(lists)):
                    contacts = self.get_contact_data(lists[i]['ID'])
                    contacts = contacts.json()
                    obj = {}
                    obj['listType'] = 'existingList'
                    obj['id'] = list_id
                    obj['contacts'] = contacts['Data']
                    result = self.import_list(obj)
                    if result['status'] != 'success':
                        response['status'] = 'error'
            else:
                response = {}
                response['status'] = 'error'
                response['msg'] = add_status['ErrorMessage']
        except Exception as e:
            logger.findaylog(""" @ 358 EXCEPTION - models - contacts -
                             merge_list """ + str(e))
            raise e
        logger.addinfo('@ models - contacts - merge_list(-)')
        return response
