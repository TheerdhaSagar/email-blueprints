from finapi.utils import db_util
from finapi.utils.logdata import logger


class Analytics:

    #  budget summary data
    @staticmethod
    def get_summary(psales_grp, period, customer_number):
        logger.addinfo('@ models - analytics - get_summary(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['budget_summary']
            cur.execute(query, p_salesgrp=psales_grp, p_year=period,
                        p_customer_number=customer_number)
        except Exception as error:
            logger.findaylog("""@ 21 EXCEPTION - models - analytics -
                 get_summary """ + str(error))
            raise error
        else:
            budg_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                budg_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - analytics - get_summary(-)')
        return budg_list

    #  budget details for salesrep
    @staticmethod
    def get_details(psales_grp, period, customer_number):
        logger.addinfo('@ models - analytics - get_details(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['budget_details']
            # cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            cur.execute(query, p_salesgrp=psales_grp, p_year=period,
                        p_customer_number=customer_number)
        except Exception as error:
            logger.findaylog("""@ 52 EXCEPTION - models - analytics -
                 get_details """ + str(error))
            raise error
        else:
            budg_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                budg_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - analytics - get_details(-)')
        return budg_list
