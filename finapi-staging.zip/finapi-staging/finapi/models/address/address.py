import ujson
from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.models.payment_term.payment_term import PaymentTerm
from finapi.models.payment_method.payment_method import PaymentMethod
from finapi.utils.log_util import LogUtil


class Address:
    # this method is now used to get customer shipto
    @staticmethod
    @db_util.langs("American")
    def get_allshipto_address(pcustid, psaleslst, porg_id):
        logger.addinfo('@ models - address - get_allshipto_address(+)')
        connection = None
        cursor = None
        mydata = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.getSqlData()
            query = ""
            # not for salesrep shipto
            if not psaleslst:
                query = sqlFile['shiptoSelectAll']
                cursor.execute(query, p_org=porg_id, p_cust_acc_id=pcustid)
                # shipto address for salerep
            else:
                query_temp = sqlFile['shiptoSelectsalesrep']
                salesrep_query = query_temp % (',' . join([":" + str(i)
                                               for i in range(len(
                                                   psaleslst))]),
                                               pcustid, porg_id)
                cursor.execute(salesrep_query, psaleslst)
            mydata = cursor.fetchall()
        except Exception as error:
            logger.findaylog("""@ 37 EXCEPTION - models - address -
                 get_allshipto_address """ + str(error))
            send_log('get_allshipto_address', error, {
                    'pcustid': pcustid, 'psaleslst': psaleslst,
                    'porg_id': porg_id})
            raise error
        else:
            myaddressess = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in mydata:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                myaddressess.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - address - get_allshipto_address(-)')
        return myaddressess

    # this method is now used to get customer billto
    @staticmethod
    @db_util.langs("American")
    def get_allbillto_address(pcustid, porg_id, plang):
        logger.addinfo('@ models - address - get_allbillto_address(+)')
        connection = None
        cursor = None
        mydata = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.getSqlData()
            query = ""
            query = sqlFile['billtoselectall']
            # cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            cursor.execute(query, p_orgid=porg_id, p_cust_acc_id=pcustid)
            mydata = cursor.fetchall()
        except Exception as error:
            logger.findaylog("""@ 72 EXCEPTION - models - address -
                 get_allbillto_address """ + str(error))
            send_log('get_allbillto_address', error, {
                    'pcustid': pcustid, 'porg_id': porg_id,
                    'plang': plang})
            raise error
        else:
            siteuse_idlist = []
            myaddressess = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in mydata:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                    # to get siteuse id for each billto
                    if field == 'site_use_id':
                        siteuse_idlist.append(row[index])
                myaddressess.append(result)
            data = ujson.dumps(myaddressess)
            bill_jsdata = ujson.loads(data)
        try:
            if siteuse_idlist:
                # payment terms based on siteuseid
                payment_terms = PaymentTerm.get_payments(siteuse_idlist,
                                                         porg_id, plang,
                                                         None)
            # payment method for creditnotes
            Payment_Method = PaymentMethod.get_paymentmethods(pcustid)
        except Exception as error:
            logger.findaylog("""@ 97 EXCEPTION - models - address -
                 get_allbillto_address """ + str(error))
            send_log('get_allbillto_address', error, {
                    'siteuse_idlist': siteuse_idlist, 'porg_id': porg_id,
                    'plang': plang, 'pcustid': pcustid})
            raise error
        else:
            for addrdict in bill_jsdata:
                # adding payment term based on siteuseid
                addrdict['payment_terms'] = payment_terms.get(
                    str(addrdict['site_use_id']))
                # adding payment method based on siteuseid
                addrdict['payment_methods'] = Payment_Method.get(
                    str(addrdict['site_use_id']))
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - address - get_allbillto_address(-)')
        return bill_jsdata

    @staticmethod
    @db_util.langs("American")
    def get_onlybillto(pcustid, porg_id):
        logger.addinfo('@ models - address - get_onlybillto(+)')
        connection = None
        cursor = None
        mydata = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.getSqlData()
            query = ""
            query = sqlFile['billtoselectall']
            # cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            cursor.execute(query, p_orgid=porg_id, p_cust_acc_id=pcustid)
            mydata = cursor.fetchall()
        except Exception as error:
            logger.findaylog("""@ 131 EXCEPTION - models - address -
                 get_onlybillto """ + str(error))
            send_log('get_onlybillto', error, {
                    'pcustid': pcustid, 'porg_id': porg_id})
            raise error
        else:
            myaddressess = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in mydata:
                result = {}
                for index, field in enumerate(fieldnames):
                    result[field] = row[index]
                myaddressess.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - address - get_onlybillto(-)')
        return myaddressess


def send_log(func, err, inp):
    LogUtil.send_log({
        'source': 'Finapi',
        'module': 'address',
        'function': func,
        'error_msg': err,
        'input_data': inp
    })
