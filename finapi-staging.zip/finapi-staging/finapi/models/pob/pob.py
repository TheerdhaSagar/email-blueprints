import io
import os
import time
import base64
import random
import datetime
import threading
import cx_Oracle

import ujson
import jinja2
import pdfkit
import requests
import copy
import yaml
import tempfile
from finapi.utils.conn_util import OracleConnectionManager

from multiprocessing import Process, Queue

from PyPDF2 import PdfFileWriter, PdfFileReader
from werkzeug.utils import secure_filename

from finapi.sql import sql_util
from finapi.utils import db_util
from finapi.utils.code_util import Code_util
from finapi.utils.common_utils import CommonUtils
from finapi.utils.logdata import logger
from finapi.models.cms.cms import CMS
from finapi.models.outofdoor.uploadfile import UploadOutofDoorFiles


class POB:
    yaml_file = sql_util.get_sql('pob')
    strings = db_util.get_strings()

    cms = None
    table_schema = {}

    mime_types = {
        'strings': 'text/strings',
        'octet': 'application/octet-stream'
    }

    hub_id = os.environ['CMS_HUB_ID']
    hubdb_api = os.environ['CMS_HUBDB_API']
    hub_api = os.environ['CMS_HUB_API']
    api_key = os.environ['CMS_HUB_API_KEY']
    items_table = os.environ['CMS_ITEMS_TABLE_TST']
    pob_labels_tbl = os.environ['CMS_POB_LABELS']
    recipes_us_tbl = os.environ['CMS_ITEM_RECIPES_US_TST']
    recipes_it_tbl = os.environ['CMS_ITEM_RECIPES_IT_TST']
    recipes_uk_tbl = os.environ['CMS_ITEM_RECIPES_UK_TST']
    recipes_de_tbl = os.environ['CMS_ITEM_RECIPES_DE_TST']
    recipes_fr_tbl = os.environ['CMS_ITEM_RECIPES_FR_TST']
    recipes_nl_tbl = os.environ['CMS_ITEM_RECIPES_NL_TST']
    recipes_es_tbl = os.environ['CMS_ITEM_RECIPES_ES_TST']
    recipes_fi_tbl = os.environ['CMS_ITEM_RECIPES_FI_TST']
    recipes_sv_tbl = os.environ['CMS_ITEM_RECIPES_SV_TST']
    recipes_be_nl_tbl = os.environ['CMS_ITEM_RECIPES_BE_NL_TST']
    recipes_be_fr_tbl = os.environ['CMS_ITEM_RECIPES_BE_FR_TST']
    recipes_ch_it_tbl = os.environ['CMS_ITEM_RECIPES_CH_IT_TST']
    recipes_ch_de_tbl = os.environ['CMS_ITEM_RECIPES_CH_DE_TST']
    recipes_ch_fr_tbl = os.environ['CMS_ITEM_RECIPES_CH_FR_TST']
    recipes_ca_fr_tbl = os.environ['CMS_ITEM_RECIPES_CA_FR_TST']
    recipes_ca_en_tbl = os.environ['CMS_ITEM_RECIPES_CA_EN_TST']
    item_images_tbl = os.environ['CMS_ITEM_IMAGES']
    file_upload_url = hub_api + 'filemanager/api/v3/files/upload?hapikey={0}'

    def __init__(self):
        self.session = requests.Session()
        self.session.trust_env = False
        self.connection = None
        self.cursor = None
        self.is_acquired = None
        self.logging = True

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def get_products(self, req):
        if self.logging:
            logger.addinfo('@ models - pob - get_products(+)')
        result = {}
        try:
            stale_attributes = self.yaml_file['product_stale_attributes']
            if 'item_code' in req:
                all_recipes = req.get('all_recipes', '')
                if all_recipes == 'Y':
                    languages = self.yaml_file['recipe_languages']
                else:
                    languages = [req.get('language', '')]

                query = '&item_code=' + req['item_code']
                products = self.get_table_data(self.items_table, query=query,
                                               stale_attrs=stale_attributes,
                                               include_id=True)
                # get recipe data for each language
                recipes = {}
                for language in languages:
                    recipe_table_id = self.get_recipe_table_id(language)
                    data = self.get_table_data(recipe_table_id, query=query, include_id=True)
                    if data:
                        recipe = data[0]
                        constituents = recipe.get('analytical_constituents', None)
                        # analytical_constituents is a list but storedas string in hubdb
                        # parse the string as list
                        if constituents:
                            recipe['analytical_constituents'] = yaml.load(constituents)
                        recipes[language] = recipe

                # get additional_images for the item_code
                images = self.get_table_data(self.item_images_tbl, query=query,
                                             include_id=True)
                products[0]['images'] = images

                if products and 'status' not in products:
                    # weight and weight uom is saved in weight attribute in HubSpot
                    # we need to parse weight and send weight, weight_uom separately
                    # in the response e.g. format 85 g., 12 Kg.
                    weight = products[0].get('weight', '').lower()
                    if 'g' in weight:
                        weight = weight.split(' ')
                        weight, weight_uom = weight[0].strip(), weight[1].strip()
                        if 'kg' in weight_uom:
                            weight_uom = weight_uom.capitalize()
                        products[0]['weight'] = weight
                        products[0]['weight_uom'] = weight_uom

                    if not all_recipes:
                        products[0]['recipe_info'] = recipes.get(languages[0], {})
                    else:
                        products[0]['recipes_info'] = recipes
            else:
                products = self.get_table_data(self.items_table, stale_attrs=stale_attributes,
                                               include_id=True)
                if req.get('language'):
                    # fetch recipe table id for language
                    recipe_table_id = self.get_recipe_table_id(req['language'])
                    # get lnaguage specific product details
                    product_recipes = self.get_table_data(recipe_table_id, include_id=True)

                    # for loop all the products
                    for product in products:
                        # fetch recipe name from product recipes array with item code matching
                        product['recipe_lang_name'] = next(
                            (recipe['recipe'] for recipe in product_recipes
                             if recipe['item_code'] == product['item_code']), None)
            stale_attributes = ['language']
            labels = self.get_table_data(self.pob_labels_tbl, stale_attrs=stale_attributes)
            label_groups = {}
            for label in labels:
                if label['label_group'] not in label_groups:
                    label_groups[label['label_group']] = {
                        'title': label['label_group_title'],
                        'labels': []
                    }
            for key, value in list(label_groups.items()):
                for label in labels:
                    if label['label_group'] == key:
                        label_groups[key]['labels'].append({
                            'label': label['label'],
                            'label_key': label['label_key']
                        })

            result['data'] = products
            result['labels'] = label_groups
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    get_products """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - get_products(+)')
        return result

    def get_table_data(self, table_id, query=None, params=None, stale_attrs=None,
                       include_id=False, retries=0):
        """
        Get table data for the given table_id.

        Args:
            table_id (int): HubDB id of the table
            query (str): query parameters as a string (default = None)
            params (dict): query parameters as an object (default = None)
            stale_attrs (list): attributes you don't need in response
            include_id (bool): Indicates whether to include HubDB row id in the response

        Returns:
            list[dict]: Table data in case of success or (dict) in case of error

        Notes:
            See https://developers.hubspot.com/docs/methods/hubdb/v2/get_table_rows

        """
        time.sleep(0.05)  # for reducing the 502 errors from hubspot
        if self.logging:
            logger.addinfo('@ models - pob - get_table_data(+)')
        result = []
        res = {}
        try:
            url = self.hubdb_api + 'tables/{0}/rows?portalId={1}'
            if params:
                for key, value in list(params.items()):
                    url += '&' + key + '=' + value
            if query:
                url += query
            req = self.session.get(url.format(table_id, self.hub_id))
            if req.status_code == 200:
                try:
                    res = req.json()
                except ValueError:
                    if req.text:
                        res = ujson.loads(req.text)
                    else:
                        return CommonUtils.get_error_message()
            else:
                return CommonUtils.get_error_message()

            data = res['objects']
            columns = self.get_table_schema(table_id)
            if stale_attrs:
                stale_attrs = [p.strip() for p in stale_attrs]
            for i in range(len(data)):
                row = self.map_column_values(data[i]['values'], columns)
                if include_id:
                    row['rowid'] = data[i]['id']
                obj = {}
                for index, key in enumerate(row):
                    if isinstance(row[key], dict):
                        if 'type' in row[key]:
                            if row[key]['type'] == 'option':
                                obj[key] = row[key]['name']
                            elif row[key]['type'] == 'image':
                                obj[key] = row[key]['url']
                            else:
                                obj[key] = row[key]
                        else:
                            obj[key] = row[key]
                    elif stale_attrs:
                        if key not in stale_attrs:
                            obj[key] = row[key]
                    else:
                        obj[key] = row[key]
                result.append(obj)
        except Exception as error:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    get_table_data """ + str(error))
            # if get_table_data finish with any error, then wait for random
            # amount of time between 0.2 to 2 second and try again, the maximum
            # no. of such tries is capped at 5
            if retries == 5:
                raise error
            else:
                rand_wait = random.randrange(1, 100) / 50.0
                time.sleep(rand_wait)
                retries += 1
                self.get_table_data(table_id, query, params, stale_attrs, include_id, retries)
        if self.logging:
            logger.addinfo('@ models - pob - get_table_data(+)')
        return result

    def get_table_schema(self, table_id, raw_data=False):
        """
        Get column names & type of a specific table in HubDB.

        Notes:
            See https://developers.hubspot.com/docs/methods/hubdb/v2/get_table

        """
        if self.logging:
            logger.addinfo('@ models - pob - get_table_schema(+)')
        try:
            url = self.hubdb_api + 'tables/{0}?portalId={1}'
            req = self.session.get(url.format(table_id, self.hub_id))
            res = req.json()
            if 'status' in req:
                result = CommonUtils.get_error_message()
            else:
                columns = res['columns']
                if raw_data:
                    result = columns
                else:
                    result = []
                    for column in columns:
                        result.append({
                            'id': str(column['id']),
                            'name': column['name'].lower(),
                            'type': column['type']
                        })
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    get_table_schema """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - get_table_schema(-)')
        return result

    def map_column_values(self, row, columns):
        if self.logging:
            logger.addinfo('@ models - pob - map_column_values(+)')
        obj = {}
        try:
            for column in columns:
                if column['id'] in row:
                    obj[column['name']] = row[column['id']]
                else:
                    obj[column['name']] = ''
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    map_column_values """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - map_column_values(+)')
        return obj

    def update_product(self, req, no_load=False):
        """
        Update data for a single product in HubDB

        if `no_load` is True then we skip loading data from
        HubSpot for the particular item
        """
        if self.logging:
            logger.addinfo('@ models - pob - update_product(+)')
        try:
            language = req.get('language', 'GB')

            recipes = {}
            if 'recipe_info' in req:
                # recipe_info is present in the request for single product update
                recipes[language] = req['recipe_info']
                del req['recipe_info']
            elif 'recipes_info' in req:
                # recipes_info is present in the request for copy recipes
                recipes = req['recipes_info']
                del req['recipes_info']

            # Get all the recipes with same language to update them
            recipes = self.get_same_language_recipes(recipes, req['item_code'])

            # Get table schema as we need column id's to update
            schema = self.get_table_schema(self.items_table, True)

            # Get existing data for product from HubDB
            response = {}
            if not no_load:
                response = self.get_products({
                    'item_code': req['item_code'],
                    'language': language
                })
            # If there is no change in the existing and new value then
            # delete that attribute from the request
            if not no_load and 'data' in response:
                product = response['data'][0]
                for attr in list(product.keys()):
                    if attr in req and attr != 'item_code':
                        if product[attr] == req[attr]:
                            del req[attr]
                req['rowid'] = product['rowid']

            # Update product and recipe data
            failed_attrs = self.update_cell_value(self.items_table, schema, req)
            # update recipe details for every language in request
            failed_recipes = ''
            insert_errors = []
            res = {}
            response_row_ids = []
            insert_images = []
            error_images = []
            if req.get('images'):
                insert_images, error_images = self.additional_images_upload(req.get('images'))
            for language in recipes:
                recipe = recipes[language]
                # save analytical constituents as text in HubSpot
                constituents = recipe.get('analytical_constituents', [])
                recipe['analytical_constituents'] = ujson.dumps(constituents)
                recipe_table_id = self.get_recipe_table_id(language)
                recipe_schema = self.get_table_schema(recipe_table_id, raw_data=True)
                if recipe.get('rowid', ''):
                    failed_attrs += self.update_cell_value(recipe_table_id, recipe_schema,
                                                           recipe)
                    self.clear_single_recipe_data(language, req['item_code'])
                else:
                    # check if row_id is not present hubspot for this language, only then insert
                    if not self.get_recipe_rowid(req['item_code'], language)[language]:
                        # adding item_code to recipe level as this is part of master level
                        recipe['item_code'] = req['item_code']
                        # In recipes table has attribute recipe_name
                        if 'recipe' in recipe:
                            recipe['recipe_name'] = recipe['recipe']
                        new_recipe = {'values': {}}
                        # creating req object for inserting a new row
                        for key, value in list(recipe.items()):
                            for column in recipe_schema:
                                if key == column['name']:
                                    if column['type'] == 'NUMBER':
                                        new_recipe['values'][column['id']] = int(value)
                                    elif column['type'] == 'STRING':
                                        new_recipe['values'][column['id']] = str(value)
                                    else:
                                        new_recipe['values'][column['id']] = value
                                    break
                        res = self.insert_row(recipe_table_id, new_recipe)
                        if res['status'] == 1:
                            insert_errors.append(
                                {'item_code': req['item_code']})
                        else:
                            response_row_ids.append({'language': language, 'row_id': res['row_id']})
                # publish recipe table changes after update
                if not self.publish_table(recipe_table_id):
                    failed_recipes += language + ', '

            # Publish the table changes
            if self.publish_table(self.items_table):
                msg = 'Product data updated successfully'
                if failed_recipes:
                    msg += ' ' + failed_recipes.strip()[:-1]
            else:
                msg = 'Product data updated successfully but failed to publish table'
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    update_product """ + str(e))
            raise e
        else:
            if len(failed_attrs) == 0 and not insert_errors:
                if 'status' in res:
                    result = {
                        'status': 0,
                        'msg': msg,
                        'row_ids': response_row_ids
                    }
                else:
                    result = {
                        'status': 0,
                        'msg': msg
                    }
            else:
                result = {
                    'status': 1,
                    'msg': 'Failed to update product data',
                    'error_attributes': failed_attrs
                }
            result['insert_images'] = insert_images
            result['error_images'] = error_images
        if self.logging:
            logger.addinfo('@ models - pob - update_product(-)')
        return result

    def update_cell_value(self, table_id, schema, req):
        """
        Updates a single cell value for a given row in HubDB table

        Notes:
            https://developers.hubspot.com/docs/methods/hubdb/v2/update_cell
        """
        if self.logging:
            logger.addinfo('@ models - pob - update_cell_value(+)')
        try:
            failed_attrs = []
            url = self.hubdb_api + 'tables/{0}/rows/{1}/cells/{2}?hapikey={3}'
            data = self.map_schema_data(schema, req)
            for row in data:
                if 'value' in row:
                    res = self.session.put(
                        url.format(table_id, req['rowid'], row['id'], self.api_key),
                        json=row['value'])
                    if res.status_code != 200:
                        failed_attrs.append(row['name'])
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    update_cell_value """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - update_cell_value(-)')
        return failed_attrs

    def insert_row(self, table_id, req):
        """
        Insert new row in HubSpot table

        Notes:
            https://developers.hubspot.com/docs/methods/hubdb/v2/create_row
        """
        if self.logging:
            logger.addinfo('@ models - pob - insert_row(+)')
        try:
            url = self.hubdb_api + 'tables/{0}/rows?hapikey={1}'
            url = url.format(table_id, self.api_key)
            res = self.session.post(url, json=req)
            if res.status_code == 200:
                result = {
                    'status': 0,
                    'msg': 'Row added successfully',
                    'row_id': res.json()['id']
                }
                self.publish_table(table_id)
            else:
                result = {
                    'status': 1,
                    'msg': 'Error adding new row ' + res.text
                }
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    insert_row """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - insert_row(-)')
        return result

    def map_schema_data(self, schema, row):
        """
        Map HubSpot column ids with keys in the row and return data
        with HubSpot column mapping
        """
        if self.logging:
            logger.addinfo('@ models - pob - map_schema_data(+)')
        try:
            for index, column in enumerate(schema):
                column_name = column['name'].lower()
                # Check if the column name exists as an attribute in request data
                if column_name in row:
                    column_value = row[column_name]
                    column_type = column['type']
                    data = {}
                    if column_type == 'IMAGE':
                        data['value'] = {'type': column_type, 'url': column_value}
                    elif column_type == 'SELECT':
                        # If the column type is 'SELECT' we need to compare all the options
                        # for that column and get the id for the option value passed in the request
                        option_id = -1
                        if 'options' in column:
                            options = column['options']
                            for option in options:
                                if option['name'].lower() == column_value.lower():
                                    option_id = option['id']
                                    break
                        data['value'] = {'type': 'OPTION',
                                         'id': option_id} if option_id != -1 else ''
                    else:
                        data['value'] = column_value

                    schema[index]['value'] = data
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    map_schema_data """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - map_schema_data(-)')
        return schema

    def publish_table(self, table_id):
        """
        Publish updates made to the table data

        Notes:
            https://developers.hubspot.com/docs/methods/hubdb/v2/publish-draft-table
        """
        if self.logging:
            logger.addinfo('@ models - pob - publish_table(+)')
        try:
            url = self.hubdb_api + 'tables/{0}/publish?hapikey={1}'
            res = self.session.put(url.format(table_id, self.api_key))
            if res.status_code == 200:
                return True
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    publish_table """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - publish_table(-)')
        return False

    def get_recipe_table_id(self, language=''):
        return {
            'IT': self.recipes_it_tbl,
            'US': self.recipes_us_tbl,
            'UK': self.recipes_uk_tbl,
            'GB': self.recipes_uk_tbl,
            'DE': self.recipes_de_tbl,
            'FR': self.recipes_fr_tbl,
            'NL': self.recipes_nl_tbl,
            'ES': self.recipes_es_tbl,
            'FI': self.recipes_fi_tbl,
            'SV': self.recipes_sv_tbl,
            'BE_NL': self.recipes_be_nl_tbl,
            'BE_FR': self.recipes_be_fr_tbl,
            'CH_IT': self.recipes_ch_it_tbl,
            'CH_DE': self.recipes_ch_de_tbl,
            'CH_FR': self.recipes_ch_fr_tbl,
            'CA_FR': self.recipes_ca_fr_tbl,
            'CA_EN': self.recipes_ca_en_tbl
        }[language.upper()]

    def upload_product_image(self, req):
        """
        Upload product image to HubSpot file manager and return HubSpot file URL
        """
        logger.addinfo('@ models - pob - upload_product_image(+)')
        try:
            pet_type = req['pet_type'].strip().lower()
            food_type = req['food_type'].strip().lower()
            brand = req['brand'].strip().lower()

            # Decode file data and save the file in tmp folder
            file_data = base64.b64decode(req['file_data'])
            date_time = datetime.datetime.now().strftime("%d-%m-%Y_%H:%M:%S")
            file_name_without_extension = os.path.splitext(req['file_name'])[0]
            file_name = file_name_without_extension + '_' + date_time
            file_name = secure_filename(file_name)
            file_path = '/tmp/' + file_name
            with open(file_path, 'wb') as fp:
                fp.write(file_data)

            folder_path = 'products/' + pet_type + '/' + food_type + '/' + brand
            if req.get('image_type'):
                folder_path += '/additional_images'
            options = {
                'access': 'PUBLIC_NOT_INDEXABLE',
                'overwrite': False
            }
            files = {
                'file': (file_name, open(file_path, 'rb'), self.mime_types['octet']),
                'options': (None, ujson.dumps(options), self.mime_types['strings']),
                'folderPath': (None, folder_path, self.mime_types['strings'])
            }
            res = self.session.post(self.file_upload_url.format(self.api_key), files=files)

            if res.status_code == 200:
                # Once the file is uploaded delete it from tmp folder
                os.remove(file_path)
                response = res.json()
                file_url = ''
                if 'objects' in response:
                    file_url = response['objects'][0]['friendly_url']

                result = {
                    'status': 0,
                    'msg': 'File uploaded successfully',
                    'url': file_url
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Failed to upload file'
                }
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - pob -
                upload_product_image """ + str(e))
            raise e
        logger.addinfo('@ models - pob - upload_product_image(-)')
        return result

    def update_column_customization(self, req):
        logger.addinfo('@ models - pob - update_column_customization(+)')
        try:
            query = self.yaml_file['insert_customizations_query']
            # delete exiting data with same user_id, module & element
            self.delete_existing_customization(req)

            self.acquire()
            rows = []
            module = req['module']
            user_id = req['user_id']
            element = req['element']
            for row in req['element_keys']:
                rows.append(tuple([user_id, module, element, row['key'],
                                   row['order']]))
            self.cursor.executemany(query, rows)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - pob -
                update_column_customization """ + str(e))
            raise e
        else:
            result = {
                'status': 0,
                'msg': 'Customization updated successfully'
            }
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - pob - update_column_customization(-)')
        return result

    def delete_existing_customization(self, req):
        logger.addinfo('@ models - pob - delete_existing_customization(+)')
        try:
            query = self.yaml_file['delete_customizations_query']
            self.acquire()
            self.cursor.execute(query, p_module=req['module'],
                                p_element=req['element'],
                                p_user_id=req['user_id'])
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - pob -
                delete_existing_customization """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - pob - delete_existing_customization(-)')

    def get_column_customization(self, req):
        logger.addinfo('@ models - pob - get_column_customization(+)')
        try:
            query = self.yaml_file['customizations_query']
            self.acquire()
            self.cursor.execute(query, p_user_id=req['user_id'],
                                p_module=req['module'],
                                p_element=req['element'])
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - pob -
                get_column_customization """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - pob - get_column_customization(-)')
        return result

    def async_generate_tradesheet(self, req):
        """
        Generate tradesheet asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        self.logging = False
        thread = threading.Thread(target=self.generate_tradesheet,
                                  kwargs={'req': req})
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.yaml_file['tradesheet_async_status']
        }

    def generate_tradesheet(self, req):
        """
        Use this method to generate trade sheet PDF for single or
        multi products

        Args:
            req (dict): should contain array of item_codes and language

        Returns:
            dict with trade sheet URL, error in case of error
        """
        options = {
            'page-size': 'A4',
            'margin-bottom': '0.5in',
            'margin-left': '0.2in',
            'margin-right': '0.2in',
            'margin-top': '0.5in',
            'zoom': '0.9',
            'encoding': 'UTF-8',
            'quiet': '',
            'dpi': 900
        }
        try:
            if not self.cms:
                self.cms = CMS()
                self.cms.logging = False
            table_id = self.get_recipe_table_id(req['language'])
            pdf_generated = self.pdf_generate(req=req, tradesheet=True)
            response = pdf_generated['response']
            tmp_files = pdf_generated['tmp_files']
            error_items = pdf_generated['error_items']
            pdf_writer = PdfFileWriter()
            for tmp_file in tmp_files:
                # Add current PDF to PDF writer queue
                pdf_file = PdfFileReader(open(tmp_file, 'rb'))
                pdf_writer.addPage(pdf_file.getPage(0))
                # remove the file after it is written
                os.remove(tmp_file)

            self.publish_table(table_id)

            if len(req['item_codes']) > 1:
                # Generate file name as MD5 hash of the item_codes
                file_name = CommonUtils.generate_md5_hash(
                    ''.join(req['item_codes']) + req['language'])
                pdf_writer.write(open('/tmp/' + file_name + '.pdf', 'wb'))
                response = self.upload_file('/tmp/' + file_name + '.pdf',
                                            'tradesheets/multiple/')

                language = req.get('language', 'GB')
                # Trade sheet mail translations are defined in Yaml strings
                if language == 'NL':
                    translate_lang = 'nl'
                else:
                    translate_lang = self.yaml_file['language_code_mapping'][language.upper()]
                translations = self.yaml_file['trade_sheet_mail_translations'][translate_lang]

                # send email to user with tradesheet URL
                if 'email' in req and 'url' in response:
                    mail_data = {
                        'template_id': 1175276,
                        'subject': translations['subject'],
                        'params': [
                            {
                                'key': 'tradesheet_url',
                                'value': response['url']
                            },
                            {
                                'key': 'error_items',
                                'value': error_items
                            },
                            {
                                'key': 'no_errors',
                                'value': not len(error_items)
                            },
                            {
                                'key': 'show_download_option',
                                'value': len(error_items) != len(req['item_codes'])
                            },
                            {
                                'key': 'translations',
                                'value': translations
                            }
                        ],
                        'to_email': req['email'],
                        'to_name': '',
                        'no_log': True
                    }
                    CommonUtils.send_mail(mail_data)

            if 'url' in response:
                result = {
                    'status': 0,
                    'msg': 'Trade sheet generated successfully',
                    'url': response['url']
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Failed to generate trade sheet'
                }
        except Exception as e:
            raise e
        return result

    def upload_file(self, file_path, folder_path, delete_file=True, retries=0):
        """
        Upload file HubSpot file manager and return HubSpot file URL
        """
        if self.logging:
            logger.addinfo('@ models - pob - upload_file(+)')
        try:
            # Decode file data and save the file in tmp folder
            options = {
                'access': 'PUBLIC_NOT_INDEXABLE',
                'overwrite': True
            }
            file_name = file_path.split('/')[-1]
            files = {
                'file': (file_name, open(file_path, 'rb'), self.mime_types['octet']),
                'options': (None, ujson.dumps(options), self.mime_types['strings']),
                'folderPath': (None, folder_path, self.mime_types['strings'])
            }
            res = self.session.post(self.file_upload_url.format(self.api_key), files=files)

            # if the file upload fail with any error, then wait for random
            # amount of time between 0.01 to 1 second and try again, the maximum
            # no. of such tries is capped at 10
            if res.status_code != 200:
                retries += 1
                if retries < 10:
                    rand_wait = random.randrange(1, 100) / 100.0
                    time.sleep(rand_wait)
                    self.upload_file(file_path, folder_path, delete_file, retries)

            if res.status_code == 200:
                # Once the file is uploaded delete it from tmp folder
                if delete_file:
                    os.remove(file_path)
                response = res.json()
                file_url = ''
                if 'objects' in response:
                    file_url = response['objects'][0]['friendly_url']

                result = {
                    'status': 0,
                    'msg': 'File uploaded successfully',
                    'url': file_url
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Failed to upload file'
                }
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    upload_file """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - upload_file(-)')
        return result

    def asynchronously_run_sync(self, user_id):
        """
        Sync products data from Oracle with HubSpot tables.
        This needs to be done on a separate thread since it can
        take more time to finish
        """
        thread = threading.Thread(target=self.sync_products,
                                  kwargs={'user_id': user_id})
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': 'Sync started successfully. Your will be notified when it is done'
        }

    def add_recipe_sync(self, item_code):
        """
        While syncing new products from oracle to Hub spot, add new entry in each recipe with
        only item_code column populated
        """
        try:
            # for an item_code, failed recipes will hold those languages that failed to insert
            failed_recipes = []
            result = {}
            for language in self.yaml_file['recipe_languages']:
                if not self.get_recipe_rowid(item_code, language)[language]:
                    # check if row_id is not present hub spot for this language, only then insert
                    recipe_table_id = self.get_recipe_table_id(language)
                    if not self.get_recipe_rowid(item_code, language)[language]:
                        new_recipe = {'values': {
                            1: item_code
                        }}
                        res = self.insert_row(recipe_table_id, new_recipe)
                        if res['status'] == 1:
                            failed_recipes.append(language)
                    # publish recipe table changes after update
                    self.publish_table(recipe_table_id)
            if len(failed_recipes) > 0:
                result['status'] = 1
                result['msg'] = 'failed to add in all recipes'
                result['failed_recipes'] = failed_recipes
            else:
                result['status'] = 0
                result['msg'] = 'recipe added in all languages'
                result['failed_recipes'] = ''
        except Exception as e:
            raise e
        return result

    @staticmethod
    def get_user_email(user_id):
        user = None
        try:
            obj = CommonUtils()
            obj.logging = False
            user = obj.get_user_details_based_on_id(user_id)
        except Exception:
            pass
        return user

    def sync_products(self, user_id):
        """
        Sync products in Oracle with HubSpot
        """
        row_mapping = {}
        try:
            self.logging = False
            self.acquire()
            query = self.yaml_file['products_sync_query']
            self.cursor.execute(query)
            data = Code_util.iterate_data(self.cursor)

            # Get all products data from HubSpot
            result = self.get_products(req={})
            if 'data' in result:
                products = result['data']
                if products:
                    # Create a map of all item codes with the respective rowid
                    for product in products:
                        row_mapping[product['item_code']] = product['rowid']

            # missing_products contains the products which are in Oracle
            # but not in HubSpot
            missing_products = []
            # sync_errors contains the products which are failed to sync with HubSpot
            sync_errors = []

            for row in data:
                item_code = row['item_code']
                if item_code in row_mapping:
                    row['rowid'] = row_mapping[item_code]
                    response = self.update_product(row, no_load=True)
                    if 'status' in response and response['status'] == 0:
                        sync_errors.append({'item_code': row['item_code']})
                else:
                    missing_products.append(row)

            # insert_errors contains the products which are failed to insert into HubSpot
            insert_errors = []
            # recipe_errors will have recipe info that failed to insert in each language - Hubspot
            recipe_errors = []
            # Add missing products to HubSpot
            if missing_products:
                # Map HubSpot column ids with keys in the missing products
                column_mapping = {}
                schema = self.get_table_schema(self.items_table, True)
                for key, value in list(missing_products[0].items()):
                    for column in schema:
                        if key == column['name']:
                            column_mapping[key] = {
                                'id': column['id'],
                                'type': column['type']
                            }

                for product in missing_products:
                    req = {'values': {}}
                    for key, value in list(product.items()):
                        column_id = column_mapping[key]['id']
                        column_type = column_mapping[key]['type']

                        if value:
                            if column_type == 'NUMBER':
                                req['values'][column_id] = int(value)
                            elif column_type == 'STRING':
                                req['values'][column_id] = str(value)
                            else:
                                req['values'][column_id] = str(value)

                    res = self.insert_row(self.items_table, req)
                    if res['status'] == 1:
                        insert_errors.append(
                            {'item_code': product['item_code']})
                    else:
                        add_recipe = self.add_recipe_sync(product['item_code'])
                        if add_recipe['status'] == 1:
                            recipe_errors.append(
                                {'item_code': product['item_code'],
                                 'languages': add_recipe['failed_recipes']})

            # Send sync status email
            user = POB.get_user_email(user_id)
            mail_data = {
                'template_id': 879675,
                'subject': self.yaml_file['sync_status_mail_subject'],
                'params': [
                    {
                        'key': 'sync_errors_count',
                        'value': len(sync_errors)
                    },
                    {
                        'key': 'sync_errors',
                        'value': sync_errors
                    },
                    {
                        'key': 'insert_errors_count',
                        'value': len(insert_errors)
                    },
                    {
                        'key': 'insert_errors',
                        'value': insert_errors
                    },
                    {
                        'key': 'recipe_errors_count',
                        'value': len(recipe_errors)
                    },
                    {
                        'key': 'recipe_errors',
                        'value': recipe_errors
                    }
                ],
                'to_email': user['email_address'] if user else 'saikrishna@finday.com',
                'to_name': user['user_description'] if user else 'Saikrishna',
                'bcc': 'engineers@finday.com',
                'no_log': True
            }
            CommonUtils.send_mail(mail_data)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return

    def get_recipe_rowid(self, item_code, single_language=False):
        result = {}
        try:
            recipe_languages = []
            # check if we need all lang row_ids or specific to a lang
            if not single_language:
                recipe_languages = self.yaml_file['recipe_languages']
            else:
                recipe_languages.append(single_language)
            query_params = '&item_code={0}'.format(item_code)
            for language in recipe_languages:
                recipe_table_id = self.get_recipe_table_id(language)
                table_data = self.get_table_data(recipe_table_id,
                                                 query=query_params,
                                                 include_id=True)
                rowid = None
                if table_data and 'status' not in table_data:
                    rowid = table_data[0]['rowid']

                result[language] = rowid
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - pob -
                get_recipe_rowid ''' + str(error))
            raise error
        return result

    def get_missing_data(self, req):
        """
        Get missing data for each recipe in every language
        """
        logger.addinfo('@ models - pob - get_missing_data(+)')
        result = {}
        try:
            summary = req.get('summary', '')
            # if item_code parameter is passed we only send data for
            # that particular product
            code = req.get('item_code', '')
            products = self.get_table_data(self.items_table)
            product_attributes = self.yaml_file['product_required_attributes']
            product_attributes_labels = [attr['label'] for attr in product_attributes]
            for product in products:
                item_code = product['item_code']
                if code and item_code != code:
                    continue
                # add item_code if not already present in result
                if item_code not in result:
                    result[item_code] = {
                        'master': [],
                        'recipe_errors': 0,
                        'recipes': {}
                    }
                # check if data exist for each required attribute in
                # master table
                for attr in product_attributes:
                    if not product.get(attr['label_key'], None):
                        result[item_code]['master'].append(attr['label'])
                result[item_code]['master_errors'] = len(
                    result[item_code]['master'])

            recipe_languages = self.yaml_file['recipe_languages']
            recipe_attributes = self.yaml_file['recipe_required_attributes']
            # fetch data for each recipe table
            for lang in recipe_languages:
                table_id = self.get_recipe_table_id(lang)
                recipes = self.get_table_data(table_id)

                for recipe in recipes:
                    item_code = recipe['item_code']
                    if code and code != item_code:
                        continue
                    # if item_code does not exist initialize with
                    # default values
                    if item_code not in result:
                        result[item_code] = {
                            'master': product_attributes_labels,
                            'master_errors': len(product_attributes),
                            'recipe_errors': 0,
                            'recipes': {
                                lang: []
                            }
                        }
                    elif 'recipes' not in result[item_code]:
                        result[item_code]['recipes'] = {
                            lang: []
                        }
                    else:
                        result[item_code]['recipes'][lang] = []

                    # check if each required attribute exist in
                    # recipe table
                    for attr in recipe_attributes:
                        if not recipe.get(attr['label_key'], None):
                            result[item_code]['recipes'][lang].append(attr['label'])

                    language_errors = len(result[item_code]['recipes'][lang])
                    result[item_code]['recipe_errors'] += language_errors

            # if only summary data is requetsed then send only the
            # error counts and remove remaining attributes from response
            for item_code in result:
                if summary == 'Y' and not code:
                    result[item_code].pop('master')
                    result[item_code].pop('recipes')
        except Exception as error:
            logger.findaylog('''@ EXCEPTION models - pob -
                get_missing_data ''' + str(error))
            raise error
        logger.addinfo('@ models - pob - get_missing_data(-)')
        return result

    def async_generate_all_pdf(self, user_id):
        """
        generate pdf based on hubspot details on brand level
        This needs to be done on a separate thread since it can
        take more time to finish
        """
        self.logging = False
        thread = threading.Thread(target=self.generate_pdf_based_on_brands,
                                  kwargs={'user_id': user_id})
        thread.deamon = True
        thread.start()

        return {
            'status': 0,
            'msg': 'Generating PDF. You will be notified through email when it is done'
        }

    def generate_pdf_based_on_brands(self, user_id):
        """
        Generate pdf based on brand
        user_id : the user id to send mail to that user
        :return:
        """
        obj = CommonUtils()
        obj.logging = False
        user = obj.get_user_details_based_on_id(user_id)
        items_error = []
        failed_upload = []
        subject = self.yaml_file['all_brand_pdf_mail_subject']
        subject = subject.format(datetime.datetime.today().strftime('%d-%m-%Y'))
        queue = Queue()
        try:
            # get brand name new from item tables
            details = self.get_products({})['data']
            jobs = []
            if isinstance(details, list):
                # get unique brand names from the data
                brand_details = list(
                    set(p['brand_name_new'].lower() for p in details if p['brand_name_new'] != '')
                )
                languages = self.yaml_file['languages']

                if not self.cms:
                    self.cms = CMS()
                    self.cms.logging = False

                for brand in brand_details:
                    # filter all the products belongs to `brand`
                    brand_products = list(
                        [k for k in details if (str(k['brand_name_new']).lower() == brand.lower())]
                    )
                    brand_name = brand.replace('|', '').replace(' ', '_')
                    # get unique animal types
                    animal = list(set(p['animal'].lower() for p in brand_products))
                    # get unique food types
                    food_type = list(set(p['food_type'].lower() for p in brand_products))
                    for food in food_type:
                        for pet in animal:
                            # getting products based on food_type and pet
                            filter_products = list(
                                filter(
                                    lambda k: (
                                        str(k['food_type']).lower() == food.lower() and
                                        str(k['animal']).lower() == pet.lower()
                                    ),
                                    brand_products)
                            )
                            # sort products based on item_display_sequence
                            filter_products = sorted(filter_products,
                                                     key=lambda k: (
                                                         k['item_display_sequence'] == '',
                                                         k['item_display_sequence']))

                            item_codes = [p['item_code'] for p in filter_products]
                            if len(item_codes) > 0:
                                for language in languages:
                                    file_name = '_'.join([brand_name.upper(), pet.upper(),
                                                          food.upper(), language])

                                    job = Process(target=self.each_brand_pdf, args=({
                                        'item_codes': item_codes,
                                        'language': language,
                                        'file_name': file_name
                                    }, queue,))
                                    job.start()
                                    jobs.append(job)
                                    # wait randomly between 0.02 to 2 seconds before
                                    # spawning a new process
                                    rand_wait = random.randrange(1, 100) / 50.0
                                    time.sleep(rand_wait)

            else:
                failed_upload.append({'file_name': 'Failed to fetch products',
                                      'language': '', 'exception': ''})

            # iterate through all jobs and check their status
            for job in jobs:
                # wait until the job is finished to get the result from the queue
                while job.is_alive():
                    continue
                response = queue.get()
                if 'failed_pdf' in response:
                    failed_upload.append(response['failed_pdf'])
                if 'item_codes' in response:
                    items_error.append(response['item_codes'])
                job.terminate()

            status = self.send_email(failed_upload, items_error, user, subject)
            if status == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Generated tradesheets successfully',
                    'failed_pdf': failed_upload,
                    'failed_products': items_error
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Tradesheets generated & Failed to send email',
                    'failed_pdf': failed_upload,
                    'failed_products': items_error
                }
        except Exception as e:
            failed_upload = [
                {'file_name': 'Exception raised', 'exception': str(e), 'language': ''}
            ]
            self.send_email(failed_upload, [], user, subject)
            raise e
        finally:
            if queue:
                queue.close()
        return result

    def each_brand_pdf(self, req, queue):
        """
        upload pdf in hubspot if the pdf has item_codes
        :param req: {'file_name':'', 'item_codes':'', 'language':''}
        :param queue: process queue for passing result data
        :return:
        """
        result = {'msg': ''}
        try:
            response = self.pdf_generate(req)
            # failed items are saved in result
            if len(response['error_items']) > 0:
                result['item_codes'] = {
                    'item_code': ','.join(response['error_items']),
                    'language': req['language']
                }

            pdf_writer = PdfFileWriter()
            for tmp_file in response['tmp_files']:
                # Add current PDF to PDF writer queue
                pdf_file = PdfFileReader(open(tmp_file, 'rb'))
                pdf_writer.addPage(pdf_file.getPage(0))

            # if pdf_writer has any data only generate pdf
            if pdf_writer.getNumPages() > 0:
                pdf_writer.write(open('/tmp/' + req['file_name'] + '.pdf', 'wb'))
                # if the process in running in dev server create tradesheets in a
                # different folder in HubSpot
                if os.environ.get('FINAPI_SERVER') == 'dev':
                    folder_name = 'tradesheets_tst'
                else:
                    folder_name = 'tradesheets'

                # upload file to HubSpot
                upload_folder = '{1}/{0}/'.format(req['language'], folder_name)
                response_temp = self.upload_file('/tmp/' + req['file_name'] + '.pdf',
                                                 upload_folder)

                if response_temp['status'] == 1:
                    result['failed_pdf'] = {
                        'file_name': req['file_name'],
                        'language': req['language'],
                        'exception': 'Upload to hubspot has failed'
                    }
            else:
                result['failed_pdf'] = {
                    'file_name': req['file_name'],
                    'language': req['language'],
                    'exception': 'No product details are found'
                }
        except Exception as e:
            result['failed_pdf'] = {
                'file_name': req['file_name'],
                'language': req['language'],
                'exception': str(e)
            }
        # put result in the queue
        if queue:
            queue.put(result)
        return result

    def pdf_generate(self, req, tradesheet=False):
        """
        this is to generate_pdf and add to hubspot in tradesheets
        :param req: {'language':'','item_codes':'', 'file_name' : ''}
        :param tradesheet: boolean, if generating for tradesheet then tradesheet = True
        so that , the pdf is saved in hubspot
        :return:
        """
        options = {
            'page-size': 'A4',
            'margin-bottom': '0.5in',
            'margin-left': '0.2in',
            'margin-right': '0.2in',
            'margin-top': '0.5in',
            'zoom': '0.9',
            'encoding': 'UTF-8',
            'quiet': '',
            'dpi': 900
        }
        no_item_details = []
        tmp_files = []
        response = {'status': 0}
        try:
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/'
            language = req.get('language', 'GB')
            # Trade sheet labels & translations are defined in Yaml strings
            translate_lang = self.yaml_file['language_code_mapping'][language.upper()]
            translations = self.yaml_file['trade_sheet_translations'][translate_lang]

            # Get schema for recipes table
            if language == 'UK':
                language = 'GB'
            table_id = self.get_recipe_table_id(language)
            if not self.table_schema.get(table_id):
                self.table_schema[table_id] = self.get_table_schema(table_id, True)

            schema = self.table_schema.get(table_id)

            for item_code in req['item_codes']:
                rowid = None
                # Get product information based on item_code and language
                products = self.cms.get_recipes({
                    'item_code': str(item_code),
                    'language': language,
                    'no_cache': True
                }, include_stale_attrs=True, include_id=True)

                if products:
                    product = products[0]
                    product['time'] = time.time()
                    if 'recipe_rowid' in product:
                        rowid = product['recipe_rowid']

                    # Composition is saved as HTML <ul> & <li> tags so replace them with
                    # empty string
                    if 'composition' in product:
                        composition = product['composition'].replace('<li>', '')
                        composition = composition.replace('</li>', ' ').replace('</ul>', '')
                        product['composition'] = composition.replace('<ul>', '')[:-1]
                    tradesheet_template = jinja2.Environment(
                        loader=jinja2.FileSystemLoader(path)
                    ).get_template('tradesheetv2.html').render(product=product,
                                                               translations=translations)

                    # copy HTML content to temporary file
                    file_name = CommonUtils.generate_random_string(10)
                    with io.open('/tmp/' + file_name + '.html', 'w', encoding='utf-8') as fp:
                        fp.write(tradesheet_template)

                    pdf_file_path = '/tmp/{0}_{1}_{2}.pdf'.format(
                        int(time.time()), item_code, language.lower())
                    pdfkit.from_file('/tmp/' + file_name + '.html', pdf_file_path, options=options)
                    tmp_files.append(pdf_file_path)
                    os.remove('/tmp/' + file_name + '.html')
                    if tradesheet:
                        response = self.upload_file(pdf_file_path, 'tradesheets/', False)
                        # If rowid is there in product data then update trade sheet
                        # URL in recipes table in HubDB
                        if rowid and response['status'] == 0:
                            self.update_cell_value(table_id, schema, {
                                'rowid': rowid,
                                'trade_sheet_url': response['url']
                            })
                else:
                    no_item_details.append(item_code)
        except Exception as error:
            raise error
        return {'tmp_files': tmp_files, 'error_items': no_item_details, 'response': response}

    def send_email(self, failed_upload, items_error, user, subject):
        return CommonUtils.send_mail({
            'template_id': 1040298,
            'subject': subject,
            'params': [
                {
                    'key': 'pdf_error_count',
                    'value': len(failed_upload)
                },
                {
                    'key': 'pdf_error',
                    'value': failed_upload
                },
                {
                    'key': 'products_count',
                    'value': len(items_error)
                },
                {
                    'key': 'insert_errors',
                    'value': items_error
                }
            ],
            'to_email': user['email_address'],
            'to_name': user['user_description'],
            'no_log': True
        })

    def reorder_products(self, req):
        """
        Updates the item_display_sequence of products as arranged in Cruscott

        :param req: [{ 'row_id': (number),
                       'item_code': (string),
                       'item_display_sequence' : (number)}]
        :return:
        """
        if self.logging:
            logger.addinfo('@ models - pob - reorder_products(+)')
        try:
            failed_rows = []
            # Get table schema as we need column id's to update
            schema = self.get_table_schema(self.items_table, True)
            for row in req:
                if row['row_id']:
                    # If cell update fails, we receive the cell name in an array
                    failed_update = self.update_cell_value(self.items_table, schema, {
                        'rowid': row['row_id'],
                        'item_display_sequence': row['item_display_sequence']
                    })
                    # If cell update fails for a certain product append it's item_code to
                    # failed_rows
                    if len(failed_update) > 0:
                        failed_rows.append(row['item_code'])
            if self.publish_table(self.items_table):
                msg = 'Item display sequences updated successfully'
            else:
                msg = 'Item display sequences updated successfully but failed to publish table'
            if len(failed_rows) == 0:
                result = {
                    'status': 0,
                    'msg': msg
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Failed to update item display sequences',
                    'error_products': failed_rows
                }
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    reorder_products """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - reorder_products(-)')
        return result

    def clear_single_recipe_data(self, language, item_code):
        """
        Clears the single_recipe_data for a product for a particular language
        from the CMS instance.

        'single_recipe_data' is used in CMS 'get_recipes' to cache recipe of an item
         of a certain language instead of fetching it from HubDB every time

        :param item_code: item_code of the product as string
        :param language: language for which single_recipe_data has to be cleared
        :return:
        """
        if self.logging:
            logger.addinfo('@ models - pob - clear_single_recipe_data(+)')
        try:
            if not self.cms:
                self.cms = CMS()
                self.cms.logging = False

            if language == 'UK':
                language = 'GB'

            country = language.split('_')[0]
            language = self.cms.yaml_file['language_mapping'][language]
            lang_country = '{}_{}'.format(country, language)
            # Calculating the hash value for the given item and language
            # 'single_recipe_data' object stores the recipe data with this hash as a key
            param_hash = hash(ujson.dumps({
                'item_code': item_code
            }))
            param_hash += hash(lang_country)

            if self.cms.single_recipe_data.get(param_hash):
                # Clearing the recipe data for given item and language
                del self.cms.single_recipe_data[param_hash]
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    clear_single_recipe_data """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - clear_single_recipe_data(-)')
        success_message = 'Cleared single_recipe_data for item: {} in {}'
        return {
            'status': 0,
            'msg': success_message.format(item_code, language)
        }

    def additional_images_upload(self, images):
        """
        For uploading additional images in hubspot
        """
        insert_images = []
        error_images = []
        for image in images:
            new_recipe = {'values': {
                1: image['item_code'],
                2: {"url": image['image_url'], "type": 'image'}
            }
            }
            res = self.insert_row(self.item_images_tbl, new_recipe)
            if res['status'] == 1:
                error_images.append(
                    {'image_url': image['image_url']})
            else:
                insert_images.append({
                    'image_url': image['image_url'],
                    'rowid': res['row_id']
                })
        return insert_images, error_images

    def delete_row(self, table_id, row_id):
        """
        Delete hubspot row from a table
        Refer: https://legacydocs.hubspot.com/docs/methods/hubdb/v2/delete_row
        """
        if self.logging:
            logger.addinfo('@ models - pob - delete_row(+)')
        try:
            url = self.hubdb_api + 'tables/{0}/rows/{2}?hapikey={1}'
            url = url.format(table_id, self.api_key, row_id)
            res = self.session.delete(url)
            if res.status_code == 204:
                result = {
                    'status': 0,
                    'msg': 'Row deleted successfully',
                }
                self.publish_table(table_id)
            else:
                logger.findaylog("""
                    Failed to delete row from table - {}, row -{}
                    """.format(table_id, row_id))
                result = {
                    'status': 1,
                    'msg': 'Error deleting existing row ' + res.text
                }
        except Exception as e:
            if self.logging:
                logger.findaylog("""@ EXCEPTION models - pob -
                    delete_row """ + str(e))
            raise e
        if self.logging:
            logger.addinfo('@ models - pob - delete_row(-)')
        return result

    def get_same_language_recipes(self, recipes, item_code):
        """
        Get all the recipes of an item which have the same language
        as the recipe that is being updated and copy the recipe information
        """
        try:
            # Get different language recipe row ids for the item
            recipe_row_ids = self.get_recipe_rowid(item_code)
            # Get all the available recipe languages in POB
            recipe_languages_and_countries = self.yaml_file['recipe_languages']
            for language in list(recipes.keys()):
                # Separate the language parameter for the selected recipe
                selected_recipe_language = POB.get_language_for_recipe(language)

                # Find all the recipes which have the same language and update their recipe info
                for recipe_language_and_country in recipe_languages_and_countries:
                    recipe_language = POB.get_language_for_recipe(recipe_language_and_country)
                    if selected_recipe_language == recipe_language \
                            and \
                            recipe_language_and_country not in list(recipes.keys()):
                        recipes[recipe_language_and_country] = copy.deepcopy(recipes[language])
                        recipes[recipe_language_and_country]['rowid'] = recipe_row_ids[recipe_language_and_country]
        except Exception as e:
            logger.findaylog("""@ EXCEPTION models - pob -
                    get_same_language_recipes """ + str(e))
            raise e
        return recipes

    @staticmethod
    def get_language_for_recipe(recipe_language_country):
        language = recipe_language_country.split('_')
        if len(language) > 1:
            language = language[1]
        else:
            language = language[0]
        return language

    @staticmethod
    def load_recipes_xls(jsond):
        try:
            # load xls file
            upload_obj = UploadOutofDoorFiles(jsond)
            sheet_names = upload_obj.get_sheets_list()
            file_name = '{0}_{1}.txt'.format(int(time.time()), 'pob_recipes')
            file_path = '{0}/{1}'.format(tempfile.gettempdir(), file_name)
            with open(file_path, 'wb') as recipes_file:
                # Create each sheet details
                for sheet in sheet_names:
                    upload_obj.sheet = upload_obj.get_workbook(sheet)
                    indexes = POB.fetch_indexes(
                        upload_obj)
                    recipes_file.write(sheet + '\n\n')
                    for col_index in range(indexes['c_index'], upload_obj.sheet.ncols):
                        composition = ''
                        # language
                        recipes_file.write(upload_obj.sheet.cell_value(
                            indexes['r_index'], col_index).encode('utf8') + '\n')
                        # type
                        recipes_file.write(upload_obj.sheet.cell_value(
                            indexes['r_index'] + 1, col_index).encode('utf8') + '\n')
                        # composition to analytic constituents
                        for row_index in range(indexes['r_index'] + 3,
                                               indexes['analytic_index'] + 1):
                            cell_value = upload_obj.sheet.cell_value(
                                row_index, col_index).encode('utf8')
                            if row_index > indexes['comp_index'] and\
                                    row_index < indexes['additive_index']:
                                composition += cell_value + ', '
                            elif row_index == indexes['additive_index']:
                                recipes_file.write(composition[:-2] + '. ')
                                recipes_file.write(cell_value + ' ')
                            else:
                                recipes_file.write(cell_value + ' ')
                        recipes_file.write('\n\n')
                    recipes_file.write('\n\n')
            result = CommonUtils.file_to_bas64(file_path, file_name)
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - pob -
                    load_recipes_xls """ + str(error))
            raise error
        result['status'] = 0
        result['file_type'] = 'txt'
        if os.path.exists(file_path):
            os.remove(file_path)
        return result

    @staticmethod
    def fetch_indexes(upload_obj):
        """
        fetch indexes of keys so that the compositions, additives and analytics comes as a string
        compositions may vary for each product so row index is to be found
        """
        r_index = None
        c_index = None
        comp_index = None
        additive_index = None
        analytic_index = None
        for col_index in range(upload_obj.sheet.ncols):
            for row_index in range(upload_obj.sheet.nrows):
                cell_value = upload_obj.sheet.cell_value(row_index, col_index)
                if 'IT'.lower() == cell_value.lower():
                    r_index = row_index
                    c_index = col_index
                if 'Composizione'.lower() in cell_value.lower():
                    comp_index = row_index
                elif 'Additivi'.lower() in cell_value.lower():
                    additive_index = row_index
                elif 'Componenti analitici'.lower() in cell_value.lower():
                    analytic_index = row_index
            if analytic_index:
                break
        return {'r_index': r_index, 'c_index': c_index, 'comp_index': comp_index,
                'additive_index': additive_index, 'analytic_index': analytic_index}

    def load_tradesheet_copy(self, req):
        """
        Upload tradesheet copy to HubSpot file manager and return HubSpot file URL
        """
        logger.addinfo('@ models - pob - load_tradesheet_copy(+)')
        try:
            result = {
                'status': 0,
                'msg': 'Trade Copy File uploaded successfully'
            }
            # Decode file data and save the file in tmp folder
            file_data = base64.b64decode(req['base64'])
            date_time = datetime.datetime.now().strftime("%d-%m-%Y_%H:%M:%S")
            file_arr = os.path.splitext(req['filename'])
            file_name_without_extension = file_arr[0]
            file_name = file_name_without_extension + '_' + str(date_time) + file_arr[1]
            file_name = secure_filename(file_name)
            file_path = tempfile.gettempdir() + '/' + file_name
            with open(file_path, 'wb') as fp:
                fp.write(file_data)
            folder_path = 'trade_copy'
            options = {
                'access': 'PUBLIC_NOT_INDEXABLE',
                'overwrite': False
            }
            files = {
                'file': (file_name, open(file_path, 'rb'), self.mime_types['octet']),
                'options': (None, ujson.dumps(options), self.mime_types['strings']),
                'folderPath': (None, folder_path, self.mime_types['strings'])
            }
            res = self.session.post(self.file_upload_url.format(self.api_key), files=files)

            if res.status_code == 200:
                # Once the file is uploaded delete it from tmp folder
                os.remove(file_path)
                response = res.json()
                file_url = ''
                if 'objects' in response:
                    file_url = response['objects'][0]['friendly_url']

                # Get table schema as we need column id's to update
                schema = self.get_table_schema(self.pob_labels_tbl, True)
                query_params = '&label_key={}'.format('trade_copy')
                label_details = self.get_table_data(self.pob_labels_tbl,
                                                    query=query_params,
                                                    include_id=True)
                req = {}
                if label_details:
                    req['rowid'] = label_details[0]['rowid']
                    req['label'] = file_url
                    self.update_cell_value(self.pob_labels_tbl, schema, req)
                    publish_flag = self.publish_table(self.pob_labels_tbl)
                    if not publish_flag:
                        result = {
                            'status': 0,
                            'msg': 'File uploaded successfully but failed to publish',
                            'url': file_url
                        }
            else:
                result = {
                    'status': 1,
                    'msg': 'Failed to upload trade copy file'
                }
        except Exception as error:
            logger.findaylog("""@ EXCEPTION models - pob -
                load_tradesheet_copy """ + error)
            raise error
        logger.addinfo('@ models - pob - load_tradesheet_copy(-)')
        return result

    def get_items_category(self):
        result = []
        with OracleConnectionManager() as conn:
            query = self.yaml_file['items_categories']
            conn.execute(query)
            result = conn.get_result()
        return {'status': 0, 'item_categories': result}

    def delete_item_category(self, jsond):
        result = {'status': 0, 'msg': 'Product details are deleted successfully'}
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                qpex_item_category_pkg.delete_item_category_details(
                    :p_item_code,
                    :p_item_description,
                    :x_status_code
                    );
            END;

            """, output_key='x_status_code',
                         p_item_code=jsond['item_code'],
                         p_item_description=jsond['description'])
            conn.get_output_param(raise_exception=True)
        return result

    @staticmethod
    def manage_item_categories(jsond):
        result = {
            'status': 0,
            'msg': 'Product(s) details are updated successfully'
        }
        if len(jsond['products']) == 1:
            return POB.single_item_category_update(jsond['products'][0])
        line_num = []
        item_code = []
        item_description = []
        updated_line_num = []
        for product in jsond['products']:
            line_num.append(product['line_num'])
            item_code.append(product['item_code'])
            item_description.append(str(product['description']))
            updated_line_num.append(product['updated_line_num'])
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                qpex_item_category_pkg.manage_item_category_details(
                    :p_items_code,
                    :p_description,
                    :p_line_number,
                    :p_update_line_number,
                    :x_status_code
                    );
            END;
            """, output_key='x_status_code',
                         p_items_code=conn.cursor.arrayvar(cx_Oracle.STRING, item_code),
                         p_description=conn.cursor.arrayvar(cx_Oracle.STRING, item_description),
                         p_line_number=conn.cursor.arrayvar(cx_Oracle.NUMBER, line_num),
                         p_update_line_number=conn.cursor.arrayvar(
                             cx_Oracle.NUMBER, updated_line_num))
            conn.get_output_param(raise_exception=True)
        return result

    @staticmethod
    def single_item_category_update(jsond):
        result = {
            'status': 0,
            'msg': 'Product(s) details are updated successfully'
        }
        with OracleConnectionManager() as conn:
            conn.execute("""
            BEGIN
                qpex_item_category_pkg.update_item_category_details(
                    :p_item_code    ,
                    :p_description  ,
                    :p_segments     ,
                    :p_line_number  ,
                    :p_segment_num  ,
                    :p_category_id  ,
                    :p_pz_in_segment,
                    :x_status_code
                    );
            END;
            """, output_key='x_status_code',
                         p_item_code=jsond['item_code'],
                         p_description=jsond['description'],
                         p_segments=jsond['segments'],
                         p_line_number=jsond['line_num'],
                         p_segment_num=jsond['segment_num'],
                         p_category_id=jsond['category_id'],
                         p_pz_in_segment=jsond['pz_in_segment'])
            conn.get_output_param()
        return result

    @staticmethod
    def sync_item_categories():
        status = 'SUCCESS'
        result = {
            'status': 0,
            'msg': 'Product(s) details are synced successfully'
        }
        with OracleConnectionManager() as conn:
            status_code = conn.set_output_param('STRING')
            conn.execute("""
            BEGIN
                qpex_item_category_pkg.sync_item_categories(
                    :x_status_code
                    );
            END;
            """, x_status_code=status_code)
            status = status_code.getvalue()
        if status != 'SUCCESS':
            return {'status': 1, 'msg': status}
        return result
