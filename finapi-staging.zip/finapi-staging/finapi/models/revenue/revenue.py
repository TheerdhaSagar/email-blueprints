from finapi.utils import db_util
from finapi.utils.logdata import logger
from finapi.utils.code_util import Code_util


class Revenue:

    def __init__(self, **kwargs):
        for name, value in list(kwargs.items()):
            setattr(self, name, value)

    #  used in  to get revenue details in given period
    @staticmethod
    def get_revenue_data(p_period, numformat):
        logger.addinfo('@ models - revenue - get_revenue_data(+)')
        con = None
        cur = None
        try:
            sql_file = db_util.getSqlData()
            con = db_util.get_connection()
            cur = con.cursor()
            query = sql_file['revenueQuery']
            cur.execute(query, P_PERIOD=p_period)
        except Exception as error:
            logger.findaylog("""@ 26 EXCEPTION - models - revenue -
                 get_revenue_data """ + str(error))
            raise error
        else:
            revenue_data = []
            fieldnames = [a[0].lower() for a in cur.description]
            field_type = [a[1] for a in cur.description]
            myrevenued = {}
            myrevenued = Code_util.get_fieldtype(fieldnames, field_type)
            revenue_data.append(myrevenued)
            for row in cur:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_data.append(revenue)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - revenue - get_revenue_data(-)')
        return revenue_data

    @staticmethod
    #  used in  to get revenueorg details in given period
    def get_orgrevenue_data(p_period, numformat):
        logger.addinfo('@ models - revenue - get_orgrevenue_data(+)')
        con = None
        cur = None
        try:
            sql_file = db_util.getSqlData()
            con = db_util.get_connection()
            cur = con.cursor()
            query = sql_file['revenue_ytd']
            cur.execute(query, P_PERIOD=p_period)
        except Exception as error:
            logger.findaylog("""@ 60 EXCEPTION - models - report -
                 get_orgrevenue_data """ + str(error))
            raise error
        else:
            revenue_data = []
            fieldnames = [a[0].lower() for a in cur.description]
            field_type = [a[1] for a in cur.description]
            myrevenued = {}
            myrevenued = Code_util.get_fieldtype(fieldnames, field_type)
            revenue_data.append(myrevenued)
            for row in cur:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_data.append(revenue)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - revenue - get_orgrevenue_data(-)')
        return revenue_data

    #  used in  to get sales group details in given period
    @staticmethod
    def get_revenuesalesgroup_data(period, sales_group, numformat):
        logger.addinfo('@ models - report - get_revenuesalesgroup_data(+)')
        con = None
        cur = None
        try:
            sql_file = db_util.getSqlData()
            con = db_util.get_connection()
            cur = con.cursor()
            query_temp = sql_file['revenue_subgroup']
            cur.execute(query_temp, P_PERIOD=period, psales_group=sales_group)
        except Exception as error:
            logger.findaylog("""@ 94 EXCEPTION - models - revenue -
                 get_revenuesalesgroup_data """ + str(error))
            raise error
        else:
            revenue_data = []
            fieldnames = [a[0].lower() for a in cur.description]
            field_type = [a[1] for a in cur.description]
            myrevenued = {}
            myrevenued = Code_util.get_fieldtype(fieldnames, field_type)
            revenue_data.append(myrevenued)
            for row in cur:
                revenue = {}
                for index, fn in enumerate(fieldnames):
                    revenue[fn] = row[index]
                revenue_data.append(revenue)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - revenue - get_revenuesalesgroup_data(-)')
        return revenue_data
