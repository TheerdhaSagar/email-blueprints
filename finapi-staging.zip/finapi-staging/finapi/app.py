import os

from flask import Flask, abort

from .views.activityplanner.activityplanner import activityplanner
from finapi.views.aws.cognito.cognito import cognito
from finapi.views.aws.gateway.gateway import gateway
from finapi.views.cms.cms import cms
from finapi.views.pob.pob import pob
from .utils import db_util
from .views.address.address import address
from .views.admin.authtoken import authtoken
from .views.analytics.metrics import metrics
from .views.bill_books.bill_book import billBook
from .views.bonus.bonus import bonus
from .views.budget.budget import budget
from .views.cashforecast.cashforecast import cashforecast
from .views.cdn.cdn import cdn
from .views.contacts.contacts import contacts
from .views.creditNotes.creditNote import creditNote
from .views.customer.customer import customer
from .views.dashboard.dashboard import dashboard
from .views.dispute.dispute import dispute
from .views.donation.donation import donation
from .views.dsv.dsv import DSV_UPLOAD
from .views.hrms.hcm.employee_onboard import employeeonboard
from .views.events.events import events
from .views.expenses.expenses import expenses
from .views.forecast.forecast import forecast
from .views.groups.groups import groups
from .views.hrms.leavemanagement import leavemanagement
from .views.hrms.preauthorization import preauthorization
from .views.hrms.assetmanagement import assetmanagement
from .views.humanandwildlife.associations import hw_associations
from .views.humanandwildlife.invitations import hw_invite
from .views.humanandwildlife.contacts import hw_contacts
from .views.humanandwildlife.applications import hw_applications
from .views.humanandwildlife.partner_associations import hw_partner_associations
from .views.invoice.invoice import invoice
from .views.load.loadredis import load
from .views.login.login import login
from .views.objectives.objectives import objectives
from .views.onboard.onboard import onboard
from .views.oprunits.operatingunits import operatingunits
from .views.outofdoor.outofdoor import outofdoor
from .views.payments.payments import payments
from .views.permissions.permissions import permission
from .views.pforecast.pforecast import pforecast
from .views.poregister.poregister import poregister
from .views.preferences.preferences import preference
from .views.pricelists.pricelists import pricelists
from .views.privacyconsent.privacyconsent import privacyconsent
from .views.procurement.procurement import procurement
from .views.products.products import products
from .views.professional_area.professional_area import professional
from .views.proofofdelivery.proofofdelivery import proof_of_delivery
from .views.quotes.quote import quote
from .views.reclaim.reclaim import reclaim
from .views.recipes.recipes import recipes
from .views.registration.registration import registration
from .views.reports.report import report
from .views.revenue.revenue import revenue
from .views.roles.roles import roles
from .views.salescalendar.salescalendar import sales_calendar
from .views.schedules.schedules import schedules
from .views.storelocator.storelocator import storelocator
from .views.suppliers.supplier import supplier
from .views.surveys.surveys import surveys
from .views.surveyusers.surveyusers import surveyusers
from .views.transaction.transaction import transaction
from .views.tripplanner.tripplanner import tripplanner
from .views.users.users import users
from .views.utilities.utilities import utilities
from .views.wordpress.wordpress import wordpress
from .views.wrapper.wrapper import wrapper
from .views.workflows.workflows import workflows
from .views.agent.targets.targets import agent_targets
from .views.dtc.dtc import DTC_BP
from .views.promotions.promotions import PROMOTIONS
from .views.rvf.rvf import RVF_INVENTORY
from .views.budget.segment_budget import BUDGET_SEGMENT
from .views.gl_journal.gl_journal import GL_JOURNAL
from .views.logging.logging import LOGGING_BP

DEFAULT_BLUEPRINTS = [activityplanner, assetmanagement, quote, customer, products, login, revenue,
                      preference, address, transaction, authtoken, operatingunits, employeeonboard,
                      dashboard, permission, roles, registration, creditNote, reclaim,
                      dispute, invoice, billBook, report, users, groups,
                      metrics, load, supplier, poregister, cashforecast,
                      utilities, pforecast, expenses, events, procurement,
                      surveys, schedules, outofdoor, onboard, surveyusers,
                      wordpress, payments, bonus, objectives, contacts,
                      forecast, pricelists, storelocator, cdn, donation,
                      recipes, budget, professional, leavemanagement,
                      preauthorization, cognito, tripplanner, cms, pob,
                      gateway, privacyconsent, proof_of_delivery, wrapper,
                      workflows, hw_associations, hw_invite, hw_contacts,
                      hw_applications, sales_calendar, hw_partner_associations,
                      agent_targets, DSV_UPLOAD, DTC_BP, RVF_INVENTORY, BUDGET_SEGMENT,
                      LOGGING_BP, GL_JOURNAL, PROMOTIONS]


def create_app():
    blueprints = DEFAULT_BLUEPRINTS
    app = Flask(__name__)
    configure_app(app)
    configure_app_handlers(app)
    configure_blueprints(app, blueprints)
    configure_error_handlers(app)
    configure_after_request(app)
    return app


def configure_after_request(app):
    @app.after_request
    def after_request(response):
        #  response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers',
                             'Content-Type, Authorization, withCredentials')
        response.headers.add('Access-Control-Allow-Headers',
                             'Content-Type, Authorization')
        response.headers.add('Access-Control-Allow-Headers',
                             'x-api-key, x-api-secret')
        response.headers.add('Access-Control-Allow-Methods',
                             'GET, PUT, POST, DELETE, OPTIONS')
        return response


def configure_app(app):
    db_util.db_pool = db_util.init_pool()
    app.config['SECRET_KEY'] = os.environ['SECRET_KEY']
    app.config['USE_TOKEN_AUTH'] = True


def configure_blueprints(app, blueprints):
    for blueprint in blueprints:
        app.register_blueprint(blueprint)


def configure_app_handlers(app):
    @app.route('/')
    def get():
        abort(404)


def configure_error_handlers(app):
    @app.errorhandler(400)
    @app.errorhandler(401)
    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(405)
    @app.errorhandler(500)
    @app.errorhandler(502)
    def request_error(error):
        return error
