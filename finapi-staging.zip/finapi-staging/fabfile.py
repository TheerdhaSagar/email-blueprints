from __future__ import with_statement

import os
from functools import wraps

from fabric.api import task
from fabric.colors import green, magenta
from fabric.operations import local


def enforce_virtualenv(func):
    """ Make sure the task is run in virtualenv (decorator). """

    @wraps(func)
    def wrapper(*args, **kwargs):
        if os.environ.get("VIRTUAL_ENV"):
            print("found environment")
            return func(*args, **kwargs)

        raise EnvironmentError('Unable to find a python virtualenv! Did you'
                               ' forget to activate one?')
    return wrapper


@task
@enforce_virtualenv
def install_requirements():
    """ Install packages defined in the requirements files. """
    print(green("\n Installing the requirements ..."))
    local_with_retry("pip install -r requirements.txt")


@task
@enforce_virtualenv
def start():
    """ Start the api """
    try:
        os.environ['SECRET_KEY']
    except KeyError:
        os.environ['SECRET_KEY'] = 'DEVELOPMENT'
    local('python ./manage.py run')


def local_with_retry(command):
    """ Run a command with warning, if it fails, run the command again"""
    output = local(command)
    if output.failed:
        print(magenta("First try failed! Trying again '%s' again!" % command))
        output = local(command)
    return output


@task
def clean():
    """ Remove all .pyc/.pyo files """
    local("find . -type f -name '*.py[co]' -execdir rm -f '{}' '+'")
    local("rm -f logs/*")

