import os
import json
import urllib.request
import urllib.parse

import yaml
import cx_Oracle


class LoadStores:
    host = os.environ['CLIENTDBHOST']
    port = os.environ['CLIENTDBPORT']
    user = os.environ['CLIENTDBUSER']
    password = os.environ['CLIENTDBPASS']
    db = os.environ['CLIENTDBNAME']

    maps_api = 'https://maps.googleapis.com/maps/api/'
    geocode_api = 'geocode/json?address={}&key={}'
    places_api = 'place/findplacefromtext/json?input={}&inputtype=textquery&key={}'
    place_details_api = 'place/details/json?place_id={}&key={}&language={}'

    map_api_key = os.environ['MAP_API_KEY']

    def __init__(self):
        self.connection = None
        self.cursor = None
        self.is_connected = False
        self.load_sql()

    def load_sql(self):
        file_name = os.path.join(os.path.dirname(__file__), 'stores.yaml')
        with open(file_name, 'r') as yaml_file:
            self.sql_file = yaml.load(yaml_file, Loader=yaml.FullLoader)

    def acquire_connection(self):
        if not self.connection:
            try:
                self.connection = cx_Oracle.connect('{}/{}@{}:{}/{}'.format(
                    self.user, self.password, self.host, self.port, self.db))
                self.cursor = self.connection.cursor()
                self.is_connected = True
            except Exception as error:
                print(f'Error connecting to database - {error}')

    def release_connection(self):
        if self.is_connected and self.cursor:
            self.connection.commit()
            self.cursor.close()
            self.connection.close()

    def get_data(self):
        columns = [c[0].lower() for c in self.cursor.description]
        data = []
        for row in self.cursor:
            obj = {}
            for index, field_name in enumerate(columns):
                obj[field_name] = row[index]
            data.append(obj)
        return data

    def get_location(self, shop):
        latitude = longitude = None
        try:
            address = shop.get('address', '').replace(' ', '+')
            city = shop.get('city', '').replace(' ', '+')
            province = shop.get('province', '').replace(' ', '+')
            country = shop.get('country_code', '')
            zip_code = shop.get('zip_code', '')
            full_address = '{}+{}+{}+{}+{}'.format(
                address, city, province, country, zip_code)
            req = urllib.request.urlopen(
                self.maps_api + self.geocode_api.format(full_address, self.map_api_key))
            response = req.read().decode('utf-8')
            data = json.loads(response)
            if data['results']:
                latitude = data['results'][0]['geometry']['location']['lat']
                longitude = data['results'][0]['geometry']['location']['lng']
            else:
                print(f"Unable to get location from google {data.get('status')}")
        except Exception as error:
            print('Error getting location - ' + str(error))
        return latitude, longitude

    def get_place_id(self, shop):
        """ Get place id for the shop from Google places API """
        try:
            url = self.maps_api + self.places_api
            address = urllib.parse.quote(shop['shop_name'] + ' ' + shop['city'] +
                                         ' ' + shop['country_name'])
            url = url.format(address, self.map_api_key)
            req = urllib.request.urlopen(url)
            data = json.loads(req.read().decode('utf-8'))
            if data.get('status') == 'OK':
                place_id = data['candidates'][0]['place_id']
                self.get_place_details(
                    place_id, shop['shop_id'], shop['country_code'])
            else:
                self.get_location(shop)
        except Exception as error:
            print('Error in get_place_id - ' + str(error))

    def get_place_details(self, place_id, shop_id, country):
        """ Get shop details from Google places API """
        local_acquire = False
        try:
            url = self.maps_api + self.place_details_api
            url = url.format(place_id, self.map_api_key, country.lower())
            req = urllib.request.urlopen(url)
            data = json.loads(req.read().decode('utf-8'))
            if data.get('status') == 'OK':
                location = data['result']['geometry']['location']
                lat, lng = location['lat'], location['lng']
                if not self.connection:
                    self.acquire_connection()
                    local_acquire = True
                self.cursor.setinputsizes(p_google_shop_data=cx_Oracle.BLOB)
                status = self.cursor.var(cx_Oracle.STRING)
                self.cursor.execute('''
                begin
                    qpex_storelocator_pkg.update_data_from_google(
                        :p_shop_id,
                        :p_lat,
                        :p_lng,
                        :p_verified_by_google,
                        :p_google_shop_data,
                        :x_status_code
                    );
                end; ''', p_shop_id=shop_id,
                                    p_lat=lat,
                                    p_lng=lng,
                                    p_verified_by_google='Y',
                                    p_google_shop_data=json.dumps(data),
                                    x_status_code=status)
                if status.getvalue() != 'SUCCESS':
                    print('Error update_google_data for shop - ' + str(shop_id))
        except Exception as error:
            print('Error in get_place_detals - ' + str(error))
        finally:
            if local_acquire:
                self.release_connection()

    def sync_stores(self):
        """ Insert new stores, update existing stores & brands """
        try:
            print('Started syncing stores')
            self.acquire_connection()
            status = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
            begin
                qpex_storelocator_pkg.sync_stores(
                    :x_status_code
                );
            end; ''', x_status_code=status)
            if status.getvalue() != 'SUCCESS':
                print('Syncing stores was not successful')
            else:
                print('Finished syncing stores')
                self.load_shops_without_location()
        except Exception as error:
            print('Error in sync_stores - ' + str(error))
        finally:
            self.release_connection()

    def load_shops_without_location(self):
        """ Loading shops which have no lat, lng values """
        local_acquire = False
        try:
            if not self.connection:
                self.acquire_connection()
                local_acquire = True
            query = self.sql_file['shops_without_location_query']
            self.cursor.execute(query)
            shops = self.get_data()
            for shop in shops:
                try:
                    print('Loading place details for shop - ' +
                          shop['shop_name'])
                    self.get_place_id(shop)
                except Exception as error:
                    print('Exception loading place details for shop - ' +
                          shop['shop_name'])
        except Exception as error:
            print('Error in load_missing_shops - ' + str(error))
        finally:
            if local_acquire:
                self.release_connection()


if __name__ == '__main__':
    LoadStores().sync_stores()
