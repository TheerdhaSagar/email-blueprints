import os
import requests
import datetime


class CaflMetrics:
    hub_id = os.environ["CMS_HUB_ID"]
    hubdb_api = os.environ["CMS_HUBDB_API"]
    api_key = os.environ["CMS_HUB_API_KEY"]
    cafl_metrics_table = os.environ["CMS_CAFL_METRICS_TABLE"]
    x_api_key = os.environ["x_api_key"]
    x_api_secret = os.environ["x_api_secret"]

    def __init__(self):
        self.session = requests.Session()
        self.session.trust_env = False
        self.headers = self.get_token_details()
        if self.headers:
            self.get_cafl_aggregate_metrics()
            self.get_hw_aggregate_metrics()

    def get_token_details(self):
        # Get token
        headers = {
            "x-api-key": self.x_api_key,
            "x-api-secret": self.x_api_secret
        }
        request = requests.get("http://localhost:8000/request-token", headers=headers)
        if request.status_code != 200:
            print("Authentication error - {}".format(request.json()))
            auth_headers = None
        else:
            token_details = request.json()
            auth_headers = {
                "authorization": "Basic " + token_details["token"] + ":" + token_details[
                    "user_id"]
            }

        return auth_headers

    def get_cafl_aggregate_metrics(self):
        print("Reading CAFL Metrics aggregate data from oracle......")
        try:
            if self.headers:
                cafl_result = requests.get(
                    "http://localhost:8000/donation/metrics/",
                    headers=self.headers)
                if cafl_result.status_code != 200:
                    print("Error in reading cafl metrics data from oracle - {}".format(
                        cafl_result.json()))
                else:
                    for data in cafl_result.json():
                        metrics_data = data
                        metrics_data["org_type"] = "association"
                        self.update_hubspot(metrics_data)
                    self.publish_table()
        except Exception as e:
            print("Error in reading cafl metrics aggregate data - " + str(e.message))

    def get_hw_aggregate_metrics(self):
        print("Reading H&W Metrics aggregate data from oracle......")
        try:
            if self.headers:
                cafl_result = requests.get(
                    "http://localhost:8000/donation/hw/metrics/",
                    headers=self.headers)
                if cafl_result.status_code != 200:
                    print("Error in reading h&w metrics data from oracle - {}".format(
                        cafl_result.json()))
                else:
                    for data in cafl_result.json():
                        metrics_data = data
                        metrics_data["org_type"] = "humansandwildlife"
                        self.update_hubspot(metrics_data)
                    self.publish_table()
        except Exception as e:
            print("Error in reading h&w metrics aggregate data - " + str(e.message))

    def get_table_row(self, org_type, year):
        row_id = ""
        try:
            print("Get table rows...")
            url = self.hubdb_api + "tables/{0}/rows?portalId={1}&org_type={2}&year={3}"
            res = self.session.get(url.format(self.cafl_metrics_table, self.hub_id,
                                   org_type, year))
            if res.status_code != 200:
                print("Hubspot error in getting table rows....")
            else:
                try:
                    req = res.json()
                    if req.get("totalCount"):
                        row_id = req["objects"][0]["id"]
                except Exception as error:
                    print("Error is reading hubspot response" + str(error.message))
        except Exception as e:
            print("Error in getting table row " + str(e.message))
        return row_id

    def update_hubspot(self, metrics_data):
        print("Update hubspot table...")
        try:
            columns = self.get_table_schema()
            row_id = self.get_table_row(metrics_data["org_type"], metrics_data["year"])
            if columns:
                url = self.hubdb_api + "tables/{0}/rows"
                url += "/" if row_id else ""
                url += "{1}?hapikey={2}"
                row_data = {
                    "values": {}
                }
                for i in range(len(columns)):
                    value = None
                    if metrics_data.get(columns[i]["name"]):
                        value = metrics_data[columns[i]["name"]]
                    elif columns[i]["name"] == "last_update_date":
                        value = datetime.datetime.now().strftime("%Y-%m-%d:%H-%M-%S")
                    row_data["values"][columns[i]["id"]] = value
                url = url.format(self.cafl_metrics_table, row_id, self.api_key)
                if row_id:
                    res = self.session.put(url, json=row_data)
                else:
                    res = self.session.post(url, json=row_data)
                if res.status_code != 200:
                    print("Hubspot error in inserting row - {}".format(res.json()))
        except Exception as e:
            print("Error in updating hubspot table - " + str(e.message))

    def publish_table(self):
        print("Publishing hubspot table....")
        try:
            url = self.hubdb_api + "tables/{0}/publish?hapikey={1}"
            res = self.session.put(url.format(self.cafl_metrics_table, self.api_key))
            if res.status_code != 200:
                print("Hubspot error in publishing table - {}".format(res.json()))
        except Exception as error:
            print("Error in publishing table - " + str(error.message))

    def get_table_schema(self):
        print("Get table schema....")
        columns = []
        try:
            url = self.hubdb_api + "tables/{0}?portalId={1}"
            req = self.session.get(url.format(self.cafl_metrics_table, self.hub_id))
            res = req.json()
            if "status" in req:
                print("Error from hubspot - get_table_schema - {}".format(req.json()))
            else:
                columns = res["columns"]
        except Exception as e:
            print("Error in reading hubspot table schemea - " + str(e.message))
        return columns


if __name__ == "__main__":
    CaflMetrics()
