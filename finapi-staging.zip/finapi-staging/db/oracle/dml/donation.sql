alter table xalmo.qpex_ext_org_users add first_name varchar2(50);
alter table xalmo.qpex_ext_org_users add last_name varchar2(50);
alter table xalmo.qpex_ext_org_users modify (user_name null);
alter table xalmo.qpex_ext_org_users modify (encrypted_passwd null); 
