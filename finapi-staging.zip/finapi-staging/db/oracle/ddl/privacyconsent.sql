/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    privacyconsent.sql                                                      |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Privacy Consent DB Objects needed for QPIT Cruscott Products     |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 23-Sept-2019    Sreelekha     Created.                               |
 +=============================================================================*/


CREATE TABLE &custom_schema .qpex_privacy_consent
(
    privacy_id              number
    ,first_name	            varchar2(250)
    ,last_name	            varchar2(250)
    ,email_address	        varchar2(500)
    ,persona	            varchar2(250)
    ,org_id	                number
    ,email_status	        varchar2(250)
    ,video_url            varchar2(1000),
    ,created_date	        timestamp DEFAULT SYSDATE
    ,recent_updated_date	timestamp DEFAULT SYSDATE
    ,created_by	            number
    ,recent_updated_by	    number
    ,hubspot_contact_id	    number
    ,language               varchar2(100)
    ,additional_info_1	    varchar2(1000)
    ,additional_info_2	    varchar2(1000)
    ,additional_info_3	    varchar2(1000)
    ,additional_info_4	    varchar2(1000)
    ,additional_info_5	    varchar2(1000)
    ,additional_info_6	    varchar2(1000)
    ,additional_info_7	    varchar2(1000)
    ,additional_info_8	    varchar2(1000)
    ,additional_info_9	    varchar2(1000)
    additional_info_10	    varchar2(1000)
);


 CREATE TABLE &custom_schema .qpex_privacy_history
(
     privacy_history_id	    Number
    ,privacy_id	            Number
    ,description	        varchar2(1000)
    ,created_id	            Number
    ,created_date	        TIMESTAMP DEFAULT SYSDATE
    ,additional_info_1	    varchar2(250)
    ,additional_info_2	    varchar2(250)
    ,additional_info_3	    varchar2(250)
    ,additional_info_4	    varchar2(250)
    ,additional_info_5	    varchar2(250)
    ,additional_info_6	    varchar2(250)
    ,additional_info_7	    varchar2(250)
    ,additional_info_8	    varchar2(250)
    ,additional_info_9	    varchar2(250)
    additional_info_10	    varchar2(250)
);

 CREATE TABLE &custom_schema .qpex_privacy_attachments
(
   file_id                          NUMBER
  ,reference_id                     NUMBER
  ,reference_type                   VARCHAR2(100)
  ,file_name                        VARCHAR2(100)
  ,file_type				        VARCHAR2(100)
  ,file_content			    	    BLOB
  ,created_id                       NUMBER
  ,created_date                     timestamp DEFAULT SYSDATE
  ,Recent_update_date               timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id           NUMBER
  ,Additional_info_group            VARCHAR2(60)
  ,Additional_info_1                VARCHAR2(240)
  ,Additional_info_2                VARCHAR2(240)
  ,Additional_info_3                VARCHAR2(240)
  ,Additional_info_4                VARCHAR2(240)
  ,Additional_info_5                VARCHAR2(240)
  ,Additional_info_6                VARCHAR2(240)
  ,Additional_info_7                VARCHAR2(240)
  ,Additional_info_8                VARCHAR2(240)
  ,Additional_info_9                VARCHAR2(240)
  ,Additional_info_10               VARCHAR2(240)
);


  CREATE SEQUENCE &custom_schema .qpex_privacy_consent_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_privacy_consent_history_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_privacy_attachments_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SYNONYM qpex_privacy_consent_s
   FOR xalmo.qpex_privacy_consent_s;

CREATE SYNONYM qpex_privacy_consent
   FOR xalmo.qpex_privacy_consent;

CREATE SYNONYM qpex_privacy_consent_history_s
   FOR xalmo.qpex_privacy_consent_history_s;

CREATE SYNONYM qpex_privacy_history
   FOR xalmo.qpex_privacy_history;

CREATE SYNONYM qpex_privacy_attachments
   FOR xalmo.qpex_privacy_attachments;


CREATE SYNONYM qpex_privacy_attachments_s
   FOR xalmo.qpex_privacy_attachments_s;

