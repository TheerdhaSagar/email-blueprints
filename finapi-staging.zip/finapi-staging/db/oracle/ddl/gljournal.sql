 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    gl_journal.sql                                                                  |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates GL journal DB Objects                                                   |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 01-OCT-21    SREELEKHA    Created.                                          |
 +=============================================================================*/


CREATE TABLE &custom_schema .qpex_journal_header
(
   journal_batch_id             NUMBER
  ,header_description           NVARCHAR2(2000)
  ,period                       NVARCHAR2(500)
  ,file_name                    NVARCHAR2(500)
  ,status                       VARCHAR2(5) DEFAULT 'D'
  ,Created_id                   NUMBER
  ,Created_date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_id            NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);  


 CREATE TABLE &custom_schema .qpex_journal_lines
(
   journal_line_id              NUMBER
  ,journal_header_id            NUMBER
  ,line_date                    TIMESTAMP
  ,line_description             NVARCHAR2(1000)
  ,line_dare                    NUMBER
  ,line_avere                   NUMBER
  ,line_conto                   NUMBER
  ,Created_id                   NUMBER
  ,Created_date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_id            NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE SEQUENCE &custom_schema .qpex_journal_header_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_journal_lines_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SYNONYM qpex_journal_header
   FOR xalmo.qpex_journal_header;

CREATE SYNONYM qpex_journal_header_s
   FOR xalmo.qpex_journal_header_s;

CREATE SYNONYM qpex_journal_lines_s
   FOR xalmo.qpex_journal_lines_s;

CREATE SYNONYM qpex_journal_lines
   FOR xalmo.qpex_journal_lines;
