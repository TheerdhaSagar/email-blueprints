 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    dsv.sql                                                                  |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates RVF Inventory DB Objects                                         |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 16-Mar-21    SREELEKHA    Created.                                          |
 +=============================================================================*/


CREATE TABLE &custom_schema .qpex_rvf_header
(
   rvf_header_id                NUMBER
  ,item_code                    NVARCHAR2(100)
  ,item_description              NVARCHAR2(1000)
  ,uom                          NVARCHAR2(200)
  ,created_id                   NUMBER
  ,created_date                 timestamp DEFAULT SYSDATE
  ,recent_update_date           timestamp DEFAULT SYSDATE
  ,recent_updated_by            NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);  

CREATE TABLE &custom_schema .qpex_rvf_transactions
(
   rvf_transaction_id           NUMBER
  ,item_code                    NVARCHAR2(200)
  ,inventory_item_id            NUMBER
  ,transaction_date             timestamp
  ,transaction_quantity         NUMBER
  ,reason                       NVARCHAR2(500)
  ,created_id                   NUMBER
  ,created_date                 timestamp DEFAULT SYSDATE
  ,recent_update_date           timestamp DEFAULT SYSDATE
  ,recent_updated_by             NUMBER
  ,status                       VARCHAR2(5) DEFAULT 'P'
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE SEQUENCE &custom_schema .qpex_rvf_header_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_rvf_transactions_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SYNONYM qpex_rvf_header
   FOR xalmo.qpex_rvf_header;

CREATE SYNONYM qpex_rvf_header_s
   FOR xalmo.qpex_rvf_header_s;

CREATE SYNONYM qpex_rvf_transactions
   FOR xalmo.qpex_rvf_transactions;

CREATE SYNONYM qpex_rvf_transactions_s
   FOR xalmo.qpex_rvf_transactions_s;
