/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |         onboarding.sql                                                      |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Onboaring DB Objects needed for QPIT Cruscott Products           |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 29-Jul-19    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


CREATE TABLE &custom_schema .qpex_employment_types
(
   employment_type_id          NUMBER
  ,employment_type             VARCHAR2(100)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);



CREATE TABLE &custom_schema .qpex_job_roles
(
   job_id                       NUMBER
  ,job_role                     VARCHAR2(250)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);



CREATE TABLE &custom_schema .qpex_departments
(
   department_id                NUMBER
  ,department_name              VARCHAR2(200)
  ,department_sub_type          VARCHAR2(200)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);



CREATE TABLE &custom_schema .qpex_job_actions
(
   action_id                    NUMBER
  ,action_code                 VARCHAR2(200)
  ,action_description          VARCHAR2(200)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .qpex_employee_data
(
   employee_id                  NUMBER
  ,user_id                      NUMBER
  ,gender                       VARCHAR2(25)
  ,birth_date                   timestamp
  ,social_security_number       VARCHAR2(50)
  ,address                      VARCHAR2(500)
  ,city                         VARCHAR2(100)
  ,province                     VARCHAR2(100)
  ,zip                          VARCHAR2(100)
  ,country                      VARCHAR2(100)
  ,email_address                VARCHAR2(100)
  ,hire_date                    timestamp
  ,termination_date             timestamp
  ,emergency_contact_person     VARCHAR2(100)
  ,emergency_contact            number
  ,country_code                 number
  ,telephone_nbr                number
  ,access_to_cruscott           VARCHAR2(10)
  ,access_to_oracle             VARCHAR2(10)
  ,access_to_gsuite             VARCHAR2(10)
  ,assets_recovered             VARCHAR2(10)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);



CREATE TABLE &custom_schema .qpex_employee_job_mapping
(
   employee_id                  NUMBER
  ,start_date                   timestamp
  ,end_date                     timestamp
  ,department_id                NUMBER
  ,job_id                       Number
  ,action_id                    NUMBER
  ,comp_frequency               VARCHAR2(200)
  ,employment_type_id           NUMBER
  ,org_id                       Number
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);



CREATE TABLE &custom_schema .qpex_reports_to_manager
(
   employee_id                  NUMBER
  ,manager_employee_id          NUMBER
  ,start_date                   timestamp
  ,end_date                     timestamp
  ,approver_order               Number
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


 CREATE TABLE &custom_schema .qpex_employee_attachments
(
   file_id                      NUMBER
  ,reference_id                 NUMBER
  ,reference_type               VARCHAR2(100)
  ,file_name                    VARCHAR2(100)
  ,file_type				            VARCHAR2(100)
  ,file_content			    	      BLOB
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE SEQUENCE &custom_schema .qpex_employment_types_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SEQUENCE &custom_schema .qpex_job_roles_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_employee_attachments_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SEQUENCE &custom_schema .qpex_departments_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_reports_to_manager_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SEQUENCE &custom_schema .qpex_employee_job_mapping_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_employee_data_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_job_actions_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SYNONYM qpex_employment_types_s
   FOR xalmo.qpex_employment_types_s;

 CREATE SYNONYM qpex_employment_types
   FOR xalmo.qpex_employment_types;

 CREATE SYNONYM qpex_job_roles_s
   FOR xalmo.qpex_job_roles_s;

 CREATE SYNONYM qpex_job_roles
   FOR xalmo.qpex_job_roles;

 CREATE SYNONYM qpex_employee_attachments_s
   FOR xalmo.qpex_employee_attachments_s;

 CREATE SYNONYM qpex_employee_attachments
   FOR xalmo.qpex_employee_attachments;

 CREATE SYNONYM qpex_departments_s
   FOR xalmo.qpex_departments_s;

 CREATE SYNONYM qpex_departments
   FOR xalmo.qpex_departments;

 CREATE SYNONYM qpex_reports_to_manager_s
   FOR xalmo.qpex_reports_to_manager_s;

 CREATE SYNONYM qpex_reports_to_manager
   FOR xalmo.qpex_reports_to_manager;

 CREATE SYNONYM qpex_employee_job_mapping_s
   FOR xalmo.qpex_employee_job_mapping_s;

 CREATE SYNONYM qpex_employee_job_mapping
   FOR xalmo.qpex_employee_job_mapping;

 CREATE SYNONYM qpex_employee_data_s
   FOR xalmo.qpex_employee_data_s;

 CREATE SYNONYM qpex_employee_data
   FOR xalmo.qpex_employee_data;

 CREATE SYNONYM qpex_job_actions_s
   FOR xalmo.qpex_job_actions_s;

 CREATE SYNONYM qpex_job_actions
   FOR xalmo.qpex_job_actions;