/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |         employeeOnboarding.sql                                              |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Onboaring DB Objects needed for QPIT Cruscott Products           |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 18-Sep-19    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/



CREATE TABLE &custom_schema .qpex_onboarding_employee
(
   onboarding_id                NUMBER
  ,employee_name                VARCHAR2(100)
  ,employment_type              VARCHAR2(75)
  ,job_title                    VARCHAR2(50)
  ,manager_id                   number
  ,telephone_nbr                VARCHAR2(100)
  ,email_address                VARCHAR2(100)
  ,default_org_id               number
  ,access_to_cruscott           VARCHAR2(10)
  ,cruscott_similar_user        number
  ,onboard_description          VARCHAR2(4000)
  ,access_to_oracle             VARCHAR2(10)
  ,oracle_similar_user          number
  ,almo_email_access            VARCHAR2(10)
  ,status                       VARCHAR2(50)
  ,joining_date                 timestamp
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .qpex_onboarding_asset_map
(
   onboarding_id                NUMBER
  ,asset_id                     NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE SEQUENCE &custom_schema .qpex_onboarding_employee_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SYNONYM qpex_onboarding_employee_s
   FOR xalmo.qpex_onboarding_employee_s;

CREATE SYNONYM qpex_onboarding_employee
   FOR xalmo.qpex_onboarding_employee;

CREATE SYNONYM qpex_onboarding_asset_map
   FOR xalmo.qpex_onboarding_asset_map;