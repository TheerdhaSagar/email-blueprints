 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    assetmanagement.sql                                                      |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Asset Management DB Objects needed for QPIT Cruscott Products    |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 18-Jul-19    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


CREATE TABLE &custom_schema .qpex_asset_type
(
   asset_type_id                NUMBER
  ,asset_type                   VARCHAR2(100)
  ,asset_sub_type               VARCHAR2(250)
  ,brand                        VARCHAR2(250)
  ,description                  VARCHAR2(250)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


 CREATE TABLE &custom_schema .qpex_almo_locations
(
   location_id                  NUMBER
  ,location_name                VARCHAR2(200)
  ,address                      VARCHAR2(2000)
  ,city                         VARCHAR2(250)
  ,province                     VARCHAR2(100)
  ,zip                          VARCHAR2(100)
  ,org_id                       NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


 CREATE TABLE &custom_schema .qpex_asset_service_history
(
   asset_service_history_id     NUMBER
  ,asset_id                     NUMBER
  ,service_issue                VARCHAR2(2000)
  ,service_cost                 NUMBER
  ,service_warrenty_expiry      timestamp
  ,currency_code                VARCHAR2(50)
  ,org_id                       NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

  CREATE TABLE &custom_schema .qpex_asset_mapping
(
  asset_id                      NUMBER
  ,assigned_user_id             NUMBER
  ,condition                    VARCHAR2(100)
  ,created_id                   NUMBER
  ,created_date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


 CREATE TABLE &custom_schema .qpex_asset_management
(
  asset_id                      NUMBER
  ,asset_type_id                NUMBER
  ,model                        VARCHAR2(250)
  ,location_id                  NUMBER
  ,serial_number                VARCHAR2(1000)
  ,status                       VARCHAR2(100)
  ,warranty_expiry_date         timestamp
  ,renewal_date                 timestamp
  ,asset_life_time              NUMBER
  ,description                  NVARCHAR2(250)
  ,license_number               VARCHAR2(250)
  ,brand                        VARCHAR2(150)
  ,po_number                    VARCHAR2(250)
  ,purchased_price              NUMBER
  ,currency_code                VARCHAR2(50)
  ,purchased_date               TIMESTAMP
  ,org_id                       NUMBER
  ,created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE &custom_schema .qpex_asset_attachments
(
   file_id                      NUMBER
  ,reference_id                 NUMBER
  ,reference_type               VARCHAR2(100)
  ,file_name                    VARCHAR2(100)
  ,file_type				            VARCHAR2(100)
  ,file_content			    	      BLOB
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE &custom_schema .qpex_asset_history
(
   asset_history_id             NUMBER
  ,asset_id                     NUMBER
  ,description                  VARCHAR2(1000)
  ,notes                        VARCHAR2(2500)
  ,org_id                       NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


  CREATE SEQUENCE &custom_schema .qpex_asset_type_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_almo_locations_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_asset_service_history_s
START WITH 1
INCREMENT BY 1
NOCACHE;

  CREATE SEQUENCE &custom_schema .qpex_asset_management_s
START WITH 1
INCREMENT BY 1
NOCACHE;

  CREATE SEQUENCE &custom_schema .qpex_asset_attachments_s
START WITH 1
INCREMENT BY 1
NOCACHE;

   CREATE SEQUENCE &custom_schema .qpex_asset_history_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SYNONYM qpex_asset_type_s
   FOR xalmo.qpex_asset_type_s;

CREATE SYNONYM qpex_asset_type
   FOR xalmo.qpex_asset_type;

CREATE SYNONYM qpex_almo_locations_s
   FOR xalmo.qpex_almo_locations_s;

CREATE SYNONYM qpex_almo_locations
   FOR xalmo.qpex_almo_locations;


CREATE SYNONYM qpex_asset_service_history
   FOR xalmo.qpex_asset_service_history;

CREATE SYNONYM qpex_asset_service_history_s
   FOR xalmo.qpex_asset_service_history_s;

CREATE SYNONYM qpex_asset_management
   FOR xalmo.qpex_asset_management;

CREATE SYNONYM qpex_asset_management_s
   FOR xalmo.qpex_asset_management_s;

CREATE SYNONYM qpex_asset_attachments
   FOR xalmo.qpex_asset_attachments;

CREATE SYNONYM qpex_asset_attachments_s
   FOR xalmo.qpex_asset_attachments_s;

CREATE SYNONYM qpex_asset_history
   FOR xalmo.qpex_asset_history;

CREATE SYNONYM qpex_asset_history_s
   FOR xalmo.qpex_asset_history_s;

 CREATE SYNONYM qpex_asset_mapping
   FOR xalmo.qpex_asset_mapping;
