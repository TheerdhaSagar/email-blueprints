 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    budget_segment.sql                                                                  |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Budget Segment                                                |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 28-05-21    SREELEKHA    Created.                                          |
 +=============================================================================*/


CREATE TABLE &custom_schema .almo_budget_segments_header
(
   budget_id                NUMBER
  ,budget_name                  NVARCHAR2(1000)
  ,start_date                   TIMESTAMP
  ,end_date                     TIMESTAMP
  ,active_flag                  NVARCHAR2(2)
  ,sales_channel                     NVARCHAR2(20)
  ,Created_by                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_by            NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
); 


 CREATE TABLE &custom_schema .almo_budget_segments_lines
(
   BUDGET_ID               NUMBER       
   ,SALES_PRICE             NUMBER       
   ,sales_channel              VARCHAR2(50) 
   ,SEGMENT_NUM             NUMBER
   ,segment_name            NVARCHAR2(1000)
  ,created_by                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_by       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


  CREATE SEQUENCE &custom_schema .almo_budget_segments_header_s
START WITH 1
INCREMENT BY 1
NOCACHE;



CREATE SYNONYM almo_budget_segments_header
   FOR xalmo.almo_budget_segments_header;

CREATE SYNONYM almo_budget_segments_header_s
   FOR xalmo.almo_budget_segments_header_s;

CREATE SYNONYM almo_budget_segments_lines
   FOR xalmo.almo_budget_segments_lines;