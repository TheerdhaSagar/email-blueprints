/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    cashflow.sql                                                             |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Cash flow DB Objects needed for QPIT Cruscott Products        |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 26-FEB-19    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


 CREATE TABLE &custom_schema .qpex_cashflow_staging
(
   cashflow_id                  NUMBER
  ,cf_type                      VARCHAR2(100)
  ,cf_ref_name                  VARCHAR2(200)
  ,cf_ref_num                   VARCHAR2(200)
  ,cf_ref_account_num           NUMBER
  ,cf_txn_date                  timestamp
  ,cf_txn_num                   VARCHAR2(100)
  ,cf_due_date					        timestamp
  ,currency_code	  			      VARCHAR2(50)
  ,gl_account                   VARCHAR2(100)
  ,payment_method     				  VARCHAR2(100)
  ,payment_term                 VARCHAR2(100)
  ,base_amount                  NUMBER
  ,due_amount                   NUMBER
  ,w1                           NUMBER
  ,w2                           NUMBER
  ,w3                           NUMBER
  ,w4                           NUMBER
  ,w5                           NUMBER
  ,w6                           NUMBER
  ,w7                           NUMBER
  ,w8                           NUMBER
  ,w9                           NUMBER
  ,w10                          NUMBER
  ,w11                          NUMBER
  ,w12                          NUMBER
  ,org_id                       NUMBER
  ,ledger_id                    NUMBER
  ,period_name                  VARCHAR2(100)
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


create sequence &custom_schema .qpex_cashflow_staging_s
start with 1
increment by 1
nocache
nocycle;




/* Inserting Supplier invoices */
INSERT INTO xalmo.qpex_cashflow_staging (
    cashflow_id,
    cf_type,
    cf_ref_name,
    cf_txn_num,
    cf_ref_num,
    cf_txn_date,
    cf_due_date,
    currency_code,
    gl_account,
    payment_method,
    payment_term,
    base_amount,
    due_amount,
    w1,
    w2,
    w3,
    w4,
    w5,
    w6,
    w7,
    w8,
    w9,
    w10,
    w11,
    w12,
    org_id,
    created_date,
    recent_update_date
)
    ( SELECT
        xalmo.qpex_cashflow_staging_s.nextval,
        'Supplier_Invoices' type,
        vendor_name,
        invoice_id,
        vendor_id,
        invoice_date,
        due_date,
        invoice_currency_code,
        gl_account,
        '' payment_method,
        '' payment_term,
        base_amount *-1 base_amount,
        due *-1 due,
        w1 *-1 b1,
        w2 *-1 b2,
        w3 *-1 b3,
        w4 *-1 b4,
        w5 *-1 b5,
        w6 *-1 b6,
        w7 *-1 b7,
        w8 *-1 b8,
        w9 *-1 b9,
        w10 *-1 b10,
        w11 *-1 b11,
        w12 *-1 b12,
        org_id,
        SYSDATE,
        SYSDATE
      FROM
        qpex_supplier_aging_v
      WHERE
        base_amount <> 0
        AND   invoice_amount <> 0
    );



/* Customer Invoices */

INSERT INTO xalmo.qpex_cashflow_staging (
    cashflow_id,
    cf_type,
    cf_ref_name,
    cf_ref_account_num,
    cf_txn_num,
    cf_ref_num,
    cf_txn_date,
    cf_due_date,
    currency_code,
    gl_account,
    payment_method,
    payment_term,
    base_amount,
    due_amount,
    w1,
    w2,
    w3,
    w4,
    w5,
    w6,
    w7,
    w8,
    w9,
    w10,
    w11,
    w12,
    org_id,
    created_date,
    recent_update_date
)
(select xalmo.qpex_cashflow_staging_s.nextval, 'Customer_Invoices' type, party_name,  account_number, to_char(customer_trx_id) customer_trx_id, cust_account_id, invoice_date, due_date,
  currency_code, gl_account, payment_method, term_name, base_amount, w0 due_amount, w1 ,w2 ,w3 ,w4 ,w5 ,w6 ,w7 ,w8 ,w9 ,w10 ,w11 ,w12, org_id, sysdate,sysdate  from
  ((select party_name,
        account_number,
          cust_account_id,
          to_char(customer_trx_id) customer_trx_id,
          org_id,
          trx_number,
          TO_CHAR(due_date,'dd-MON-yyyy') due_date,
          invoice_date,
          payment_method,
          term_name,
          description,
          qcav.invoice_currency_code CURRENCY_CODE,
           decode(org_id,83,'HYPO EUR - 1010301',
            202,'HSBC USD - 1010603',
            121,decode(INVOICE_CURRENCY_CODE,'GBP','HSBC GBP - 1010501','EUR','HSBC EUR - 1010502'),
            181,'HSBC EUR - 1010233',
            101,'HSBC EUR - 1010223',
            84,decode(INVOICE_CURRENCY_CODE,'CHF','HSBC CHF - 1010235','EUR','BPS EUR - 1010225'),
            141,decode(INVOICE_CURRENCY_CODE,'CAD','HSBC CAD - 1010227'),
            82,decode(INVOICE_CURRENCY_CODE,'USD','CARIGE USD - 1010210','GBP','CARIGE EUR -  1010215','CHF','CARIGE CHF - 1010216',
                                            'EUR',decode(instr(party_name,'ALMO') ,1 ,'CARIGE EUR - 1010201','UNICREDIT EUR - 1010203'))) GL_ACCOUNT,
           AMOUNT,
           BASE_AMOUNT,
           w0 ,
      w1 ,w2 ,w3 ,w4 ,w5 ,w6 ,w7 ,w8 ,w9 ,w10 ,w11 ,w12  from
    qpex_customer_aging_v qcav)
    union
      ( select party_name, account_number, cust.CUST_ACCOUNT_ID cust_account_id, '' customer_trx_id,cr.ORG_ID org_id,
       ps.trx_number TRX_NUMBER, TO_CHAR(ps.due_date,'dd-MON-yyyy') due_date,
       ps.creation_date invoice_date, cr.type payment_method,cr.status term_name,'Others' Description,
       cr.CURRENCY_CODE CURRENCY_CODE,
       decode(cr.org_id,83,'HYPO EUR - 1010301',
            202,'HSBC USD - 1010603',
            121,decode(cr.CURRENCY_CODE,'GBP','HSBC GBP - 1010501','EUR','HSBC EUR - 1010502'),
            181,'HSBC EUR - 1010233',
            101,'HSBC EUR - 1010223',
            84,decode(cr.CURRENCY_CODE,'CHF','HSBC CHF - 1010235','EUR','BPS EUR - 1010225'),
            141,decode(cr.CURRENCY_CODE,'CAD','HSBC CAD - 1010227'),
            82,decode(cr.CURRENCY_CODE,'USD','CARIGE USD - 1010210','GBP','CARIGE EUR -  1010215','CHF','CARIGE CHF - 1010216',
                                            'EUR',decode(instr(party_name,'ALMO') ,1 ,'CARIGE EUR - 1010201','UNICREDIT EUR - 1010203'))) GL_ACCOUNT,acctd_amount_due_remaining amount,
    acctd_amount_due_remaining base_amount,
    (CASE
                       when ps.trx_date  - 0 <
                              SYSDATE
                  THEN
                      acctd_amount_due_remaining
               END)
                 w0,
              (CASE
              WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd') AND   TRUNC (SYSDATE,'dd') + 6 THEN
                      acctd_amount_due_remaining

               END)
                 w1,
              (CASE
                       WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd') + 7 AND   TRUNC (SYSDATE,'dd') + 13 THEN
                      acctd_amount_due_remaining

               END)
                 w2,
              (CASE
                  WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd') + 14 AND   TRUNC (SYSDATE,'dd') + 20
                  THEN
                      acctd_amount_due_remaining

               END)
                 w3,
              (CASE
                  WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd') + 21 AND   TRUNC ( SYSDATE,'dd') + 27 THEN
                      acctd_amount_due_remaining

               END)
                 w4,
              (CASE
                  WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd') + 28 AND   TRUNC (SYSDATE,'dd') + 34 THEN
                      acctd_amount_due_remaining

               END)
                 w5,
              (CASE
                  WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd') + 35 AND   TRUNC (SYSDATE,'dd') + 41
                  THEN
                      acctd_amount_due_remaining

               END)
                 w6,
              (CASE
                    WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE, 'dd') + 42 AND   TRUNC (SYSDATE,'dd') + 48 THEN  acctd_amount_due_remaining
               END)
                 w7,
              (CASE
                   WHEN ps.trx_date  BETWEEN   TRUNC ( SYSDATE,'dd') + 49 AND   TRUNC (SYSDATE,'dd') + 55
                  THEN
                      acctd_amount_due_remaining

               END)
                 w8,
              (CASE
                WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd') + 56 AND   TRUNC (SYSDATE,
                                                                                         'dd') + 62 THEN
                      acctd_amount_due_remaining

               END)
                 w9,
              (CASE
                 WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE, 'dd') + 63 AND   TRUNC (SYSDATE,'dd') + 69 THEN
                      acctd_amount_due_remaining

               END)
                 w10,
              (CASE WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd') + 70 AND   TRUNC (SYSDATE,'dd') + 76 THEN
                      acctd_amount_due_remaining

               END)
                 w11,
              (CASE

                       WHEN ps.trx_date  BETWEEN   TRUNC (SYSDATE,'dd')+ 77 AND   TRUNC (SYSDATE,'dd') + 83
                  THEN
                      acctd_amount_due_remaining
               END) w12 from ar_cash_receipts_all cr, ar_payment_schedules_all ps,
                    hz_cust_accounts cust, hz_parties party
                    where ps.class = 'PMT'
                    and cr.cash_receipt_id = ps.cash_receipt_id
                    and party.party_id = cust.party_id
                    and ps.status = 'OP'
                    and ps.org_id = cr.org_id
                    and cust_account_id = pay_from_customer)));


/* To be invoiced - Ar interface view */

INSERT INTO xalmo.qpex_cashflow_staging (
    cashflow_id,
    cf_type,
    cf_ref_name,
    cf_ref_num,
    cf_ref_account_num,
    cf_txn_date,
    cf_txn_num,
    cf_due_date,
    currency_code,
    gl_account,
    payment_method,
    payment_term,
    base_amount,
    due_amount,
    w1,
    w2,
    w3,
    w4,
    w5,
    w6,
    w7,
    w8,
    w9,
    w10,
    w11,
    w12,
    org_id,
    created_date,
    recent_update_date
)
    ( SELECT
        xalmo.qpex_cashflow_staging_s.nextval,
        'To_be_Invoiced' type,
        party_name,
        cust_account_id,
        account_number,
        trx_date,
        sales_order,
        due_date,
        currency_code,
        gl_account,
        payment_method,
        term_name,
        base_amount,
        w0,
        w1,
        w2,
        w3,
        w4,
        w5,
        w6,
        w7,
        w8,
        w9,
        w10,
        w11,
        w12,
        org_id,
        SYSDATE,
        SYSDATE
      FROM
        qpex_ar_interface_v
    );


/* Customer Receipts */

INSERT INTO xalmo.qpex_cashflow_staging (
    cashflow_id,
    cf_type,
    cf_ref_name,
    cf_ref_num,
    cf_ref_account_num,
    cf_txn_date,
    cf_txn_num,
    cf_due_date,
    currency_code,
    gl_account,
    payment_method,
    payment_term,
    base_amount,
    due_amount,
    w1,
    w2,
    w3,
    w4,
    w5,
    w6,
    w7,
    w8,
    w9,
    w10,
    w11,
    w12,
    org_id,
    created_date,
    recent_update_date
)
 ( SELECT
        xalmo.qpex_cashflow_staging_s.nextval,
        'Customer_Receipts' type,party_name, '', account_number, '', receipt_number, maturity_date, cr.CURRENCY_CODE,
                  decode(cr.org_id,83,'HYPO EUR - 1010301',
        202,'HSBC USD - 1010603',
        121,decode(cr.CURRENCY_CODE,'GBP','HSBC GBP - 1010501','EUR','HSBC EUR - 1010502'),
        181,'HSBC EUR - 1010233',
        101,'HSBC EUR - 1010223',
        84,decode(cr.CURRENCY_CODE,'CHF','HSBC CHF - 1010235','EUR','BPS EUR - 1010225'),
        141,decode(cr.CURRENCY_CODE,'CAD','HSBC CAD - 1010227'),
        82,decode(cr.CURRENCY_CODE,'USD','CARIGE USD - 1010210','GBP','CARIGE EUR -  1010215','CHF','CARIGE CHF - 1010216',
                                        'EUR',decode(instr(party.PARTY_NAME,'ALMO') ,1 ,'CARIGE EUR - 1010201','UNICREDIT EUR - 1010203'))) GL_ACCOUNT,
    payment_method_dsp, '', cr.amount,    ( case when  maturity_date -0 < sysdate then  amount end ) b0,
   ( case when  maturity_date between trunc(sysdate,'dd') and  trunc(sysdate,'dd')+6   then         amount end ) b1,
   ( case when  maturity_date between trunc(sysdate,'dd')+7 and  trunc(sysdate,'dd')+13   then   amount end ) b2,
   ( case when  maturity_date between trunc(sysdate,'dd')+14 and  trunc(sysdate,'dd')+20   then  amount end ) b3,
   ( case when  maturity_date between trunc(sysdate,'dd')+21 and  trunc(sysdate,'dd')+27   then  amount end ) b4,
   ( case when  maturity_date between trunc(sysdate,'dd')+28 and  trunc(sysdate,'dd')+34   then  amount end ) b5,
   ( case when  maturity_date between trunc(sysdate,'dd')+35 and  trunc(sysdate,'dd')+41   then  amount end ) b6,
   ( case when  maturity_date between trunc(sysdate,'dd')+42 and  trunc(sysdate,'dd')+48   then  amount end ) b7,
   ( case when  maturity_date between trunc(sysdate,'dd')+49 and  trunc(sysdate,'dd')+55   then  amount end ) b8,
   ( case when  maturity_date between trunc(sysdate,'dd')+56 and  trunc(sysdate,'dd')+62   then  amount end ) b9,
   ( case when  maturity_date between trunc(sysdate,'dd')+63 and  trunc(sysdate,'dd')+69   then  amount end ) b10,
   ( case when  maturity_date between trunc(sysdate,'dd')+70 and  trunc(sysdate,'dd')+76   then  amount end ) b11,
   ( case when  maturity_date between trunc(sysdate,'dd')+77 and  trunc(sysdate,'dd')+83   then  amount end ) b12,cr.org_id, sysdate, sysdate from hz_cust_accounts cust,
   hz_parties party,
   ar_cash_receipts_v cr
   WHERE cust.cust_account_id = cr.customer_id
   AND cust.party_id = party.party_id
   and   cr.state ='REMITTED');


/* Purchase Orders */

INSERT INTO xalmo.qpex_cashflow_staging (
    cashflow_id,
    cf_type,
    cf_ref_name,
    cf_ref_num,
    cf_ref_account_num,
    cf_txn_date,
    cf_txn_num,
    cf_due_date,
    currency_code,
    gl_account,
    payment_method,
    payment_term,
    base_amount,
    due_amount,
    w1,
    w2,
    w3,
    w4,
    w5,
    w6,
    w7,
    w8,
    w9,
    w10,
    w11,
    w12,
    org_id,
    created_date,
    recent_update_date
)
    ( select xalmo.qpex_cashflow_staging_s.nextval,
        'Purchase_Orders' type,
        vendor_name,
        vendor_id,
        po_header_id,
        creation_date,
        po_num,
        NEED_BY_DATE,
        currency_code,gl_account, '', '', base_amount, b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12, org_id,sysdate,sysdate from ( SELECT
        vendor_name,
        vendor_id,
        po_header_id,
        creation_date,
        po_num,
        NEED_BY_DATE,
        currency_code,
        DECODE(org_id,83,DECODE(instr(qcpfov.vendor_name,'ALMO'),1,'UNICREDIT EUR - 1010236','HYPO EUR - 1010301'),202,'HSBC USD - 1010603'
,121,DECODE(qcpfov.currency_code,'GBP','HSBC GBP - 1010501','EUR','HSBC EUR - 1010502'),181,'HSBC EUR - 1010233',101,'HSBC EUR - 1010223'
,84,DECODE(qcpfov.currency_code,'CHF','HSBC CHF - 1010235','EUR','BPS EUR - 1010225'),141,DECODE(qcpfov.currency_code,'CAD','HSBC CAD - 1010227'
,'USD','CARIGE USD - 1010230'),82,DECODE(qcpfov.currency_code,'USD','CARIGE USD - 1010210','GBP','CARIGE EUR -  1010215','EUR','UNICREDIT EUR - 1010203'
) ) gl_account,
        base_amount,
        (
            CASE
                WHEN nvl(need_by_date,SYSDATE - 1) - 0 < SYSDATE THEN SUM(qcpfov.base_amount)
            END
        ) b0,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') AND trunc(SYSDATE,'dd') + 6 THEN SUM(qcpfov.base_amount)
            END
        ) b1,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 7 AND trunc(SYSDATE,'dd') + 13 THEN SUM(qcpfov.base_amount)
            END
        ) b2,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 14 AND trunc(SYSDATE,'dd') + 20 THEN SUM(qcpfov.base_amount)
            END
        ) b3,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 21 AND trunc(SYSDATE,'dd') + 27 THEN SUM(qcpfov.base_amount)
            END
        ) b4,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 28 AND trunc(SYSDATE,'dd') + 34 THEN SUM(qcpfov.base_amount)
            END
        ) b5,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 35 AND trunc(SYSDATE,'dd') + 41 THEN SUM(qcpfov.base_amount)
            END
        ) b6,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 42 AND trunc(SYSDATE,'dd') + 48 THEN SUM(qcpfov.base_amount)
            END
        ) b7,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 49 AND trunc(SYSDATE,'dd') + 55 THEN SUM(qcpfov.base_amount)
            END
        ) b8,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 56 AND trunc(SYSDATE,'dd') + 62 THEN SUM(qcpfov.base_amount)
            END
        ) b9,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 63 AND trunc(SYSDATE,'dd') + 69 THEN SUM(qcpfov.base_amount)
            END
        ) b10,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 70 AND trunc(SYSDATE,'dd') + 76 THEN SUM(qcpfov.base_amount)
            END
        ) b11,
        (
            CASE
                WHEN need_by_date BETWEEN trunc(SYSDATE,'dd') + 77 AND trunc(SYSDATE,'dd') + 83 THEN SUM(qcpfov.base_amount)
            END
        ) b12,
        org_id
      FROM
        qpex_ce_po_fc_orders_v qcpfov
    GROUP BY
        po_header_id,
        vendor_name,
        vendor_id,
        creation_date,
        po_num,
        NEED_BY_DATE,
        currency_code,
        org_id,
        base_amount
    )
    );


/* ICO Intercompany */

INSERT INTO xalmo.qpex_cashflow_staging (
    cashflow_id,
    cf_type,
    cf_ref_name,
    currency_code,
    gl_account,
    Additional_info_1,
    ledger_id,
    PERIOD_NAME,
    created_date,
    recent_update_date,
    base_amount,
    due_amount
)
   ( select xalmo.qpex_cashflow_staging_s.nextval,
        'ICO_INTER_COMPANY' type,  name, currency_code, segment2, description, ledger_id,PERIOD_NAME, sysdate, sysdate, PTD_ACTUAL, YTD_ACTUAL from (SELECT GLS.NAME
, GB.CURRENCY_CODE,
gls.ledger_id,
PERIOD_NAME
, decode(gls.ledger_id,21,decode(instr(FFVL.DESCRIPTION,'ALMO') , 0 , NULL, 'UNICREDIT EUR - 1010236','HYPO EUR - 1010301'),
                    1165,'HSBC USD - 1010603',
                    43,decode(gb.currency_code,'GBP','HSBC GBP - 1010501','EUR','HSBC EUR - 1010502'),
                    1145,'HSBC EUR - 1010233',
                    42,'HSBC EUR - 1010223',
                    22,decode(gb.currency_code,'CHF','HSBC CHF - 1010235','EUR','BPS EUR - 1010225'),
                    63,decode(gb.currency_code,'CAD','HSBC CAD - 1010227','USD','CARIGE USD - 1010230'),
                    1,decode(gb.currency_code,'USD','CARIGE USD - 1010210','GBP','CARIGE EUR -  1010215',
                                                    'EUR','UNICREDIT EUR - 1010203')) SEGMENT2
, FFVL.DESCRIPTION,
SUM(ABS((GB.PERIOD_NET_DR - GB.PERIOD_NET_CR))) AS PTD_ACTUAL,
SUM((GB.BEGIN_BALANCE_DR - GB.BEGIN_BALANCE_CR )+ (GB.PERIOD_NET_DR - GB.PERIOD_NET_CR) ) AS YTD_ACTUAL
FROM GL_CODE_COMBINATIONS_KFV  GKV,
GL_BALANCES GB,
GL_LEDGERS GLS,
FND_FLEX_VALUES_VL FFVL,
xalmo.almo_ico_accounts ac
WHERE SEGMENT2 =ac.account_number
AND SEGMENT3 != 'T'
AND GLS.currency_code = gb.currency_code
AND GB.CODE_COMBINATION_ID = GKV.CODE_COMBINATION_ID
AND FFVL.FLEX_VALUE = SEGMENT2
AND FFVL.FLEX_VALUE_SET_ID =1007615
AND GLS.LEDGER_ID = GB.LEDGER_ID
GROUP BY GLS.NAME, GB.CURRENCY_CODE, FFVL.DESCRIPTION,gls.ledger_id, PERIOD_NAME
ORDER BY GLS.NAME, SEGMENT2, GB.CURRENCY_CODE,FFVL.DESCRIPTION));


/* VAT & AWT */

INSERT INTO xalmo.qpex_cashflow_staging (
    cashflow_id,
    cf_type,
    currency_code,
    gl_account,
    org_id,
    period_name,
    due_amount,
    w1,
    w2,
    w3,
    w4,
    w5,
    w6,
    w7,
    w8,
    w9,
    w10,
    w11,
    w12,
    created_date,
    recent_update_date
)
    ( SELECT
        xalmo.qpex_cashflow_staging_s.nextval,
        'VAT_AWT' type,
        currency_code,
        gl_account,
        81,
        period_name,
        b0,
        b1,
        b2,
        b3,
        b4,
        b5,
        b6,
        b7,
        b8,
        b9,
        b10,
        b11,
        b12,
        SYSDATE,
        SYSDATE
      FROM
        qpex_vatawt_aging_v
    );