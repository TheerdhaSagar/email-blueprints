/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    salescalendar.sql                                                        |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Sales Calendar DB Objects needed for QPIT Cruscott Products      |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 18-May-20    Sahitya Buddharaju     Created.                                |
 +=============================================================================*/

CREATE TABLE &custom_schema .qpex_sales_cal_projects (
    project_id               NUMBER,
    project_name             NVARCHAR2(250),
    color                    VARCHAR2(50),
    created_by               NUMBER,
    created_date             TIMESTAMP DEFAULT SYSDATE,
    recent_update_date       TIMESTAMP DEFAULT SYSDATE,
    recent_updated_user_id   NUMBER,
    additional_info_group    VARCHAR2(60),
    additional_info_1        VARCHAR2(240),
    additional_info_2        VARCHAR2(240),
    additional_info_3        VARCHAR2(240),
    additional_info_4        VARCHAR2(240),
    additional_info_5        VARCHAR2(240),
    additional_info_6        VARCHAR2(240),
    additional_info_7        VARCHAR2(240),
    additional_info_8        VARCHAR2(240),
    additional_info_9        VARCHAR2(240),
    additional_info_10       VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_sales_cal_focus_pts (
    focus_point_id           NUMBER,
    focus_point_name         NVARCHAR2(500),
    priority                 NUMBER,
    project_id               NUMBER,
    status                   VARCHAR2(1),
    created_by               NUMBER,
    created_date             TIMESTAMP DEFAULT SYSDATE,
    recent_update_date       TIMESTAMP DEFAULT SYSDATE,
    recent_updated_user_id   NUMBER,
    additional_info_group    VARCHAR2(60),
    additional_info_1        VARCHAR2(240),
    additional_info_2        VARCHAR2(240),
    additional_info_3        VARCHAR2(240),
    additional_info_4        VARCHAR2(240),
    additional_info_5        VARCHAR2(240),
    additional_info_6        VARCHAR2(240),
    additional_info_7        VARCHAR2(240),
    additional_info_8        VARCHAR2(240),
    additional_info_9        VARCHAR2(240),
    additional_info_10       VARCHAR2(240)
);

CREATE TABLE &custom_schema.qpex_sales_cal_activity (
    activity_id               NUMBER,
    activity_name             NVARCHAR2(500),
    start_date                TIMESTAMP,
    end_date                  TIMESTAMP,
    goal                      NCLOB,
    description               NCLOB,
    communication_request     NVARCHAR2(1000),
    communication_intensity   NVARCHAR2(500),
    status                    VARCHAR2(1),
    focus_point_id            NUMBER,
    created_by                NUMBER,
    created_date              TIMESTAMP DEFAULT SYSDATE,
    recent_update_date        TIMESTAMP DEFAULT SYSDATE,
    recent_updated_user_id    NUMBER,
    additional_info_group     VARCHAR2(60),
    additional_info_1         VARCHAR2(240),
    additional_info_2         VARCHAR2(240),
    additional_info_3         VARCHAR2(240),
    additional_info_4         VARCHAR2(240),
    additional_info_5         VARCHAR2(240),
    additional_info_6         VARCHAR2(240),
    additional_info_7         VARCHAR2(240),
    additional_info_8         VARCHAR2(240),
    additional_info_9         VARCHAR2(240),
    additional_info_10        VARCHAR2(240)
);

CREATE SEQUENCE &custom_schema .qpex_sales_cal_projects_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_sales_cal_focus_pts_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_sales_cal_activity_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SYNONYM qpex_sales_cal_projects_s
   FOR xalmo.qpex_sales_cal_projects_s;

CREATE SYNONYM qpex_sales_cal_focus_pts_s
   FOR xalmo.qpex_sales_cal_focus_pts_s;

CREATE SYNONYM qpex_sales_cal_activity_s
   FOR xalmo.qpex_sales_cal_activity_s;

CREATE SYNONYM qpex_sales_cal_projects
   FOR xalmo.qpex_sales_cal_projects;

CREATE SYNONYM qpex_sales_cal_focus_pts
   FOR xalmo.qpex_sales_cal_focus_pts;

CREATE SYNONYM qpex_sales_cal_activity
   FOR xalmo.qpex_sales_cal_activity;