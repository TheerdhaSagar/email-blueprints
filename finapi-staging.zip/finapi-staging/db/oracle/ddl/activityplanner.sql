 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    activityplanner.sql                                                      |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Trip Planner DB Objects needed for QPIT Cruscott Products        |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 18-Jun-19    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/

CREATE TABLE &custom_schema .qpex_activity_trip_header
(
   trip_id                      NUMBER
  ,org_id                       NUMBER
  ,trip_description             NVARCHAR2(1000)
  ,status						NVARCHAR2(50)
  ,approver_id			    	NUMBER
  ,user_comments                NVARCHAR2(2000)
  ,approver_comments            NVARCHAR2(2000)
  ,start_date_time              TIMESTAMP(6)
  ,end_date_time                TIMESTAMP(6)
  ,google_event_id              NVARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .qpex_activity_task
(
   task_id                      NUMBER
  ,org_id                       NUMBER
  ,task_description             NVARCHAR2(1000)
  ,task_location                NVARCHAR2(1000)
  ,start_date_time              timestamp
  ,end_date_time                timestamp
  ,goals                        NVARCHAR2(2000)
  ,results                      NVARCHAR2(2000)
  ,status						NVARCHAR2(50)
  ,approver_id			    	NUMBER
  ,user_comments                NVARCHAR2(2000)
  ,approver_comments            NVARCHAR2(2000)
  ,google_event_id              NVARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

ALTER TABLE &custom_schema .qpex_activity_task ADD goal_id NUMBER;

CREATE TABLE &custom_schema .qpex_activity_trip_lines
(
   line_id                      NUMBER
  ,trip_id                      NUMBER
  ,from_location                NVARCHAR2(200)
  ,to_location                  NVARCHAR2(200)
  ,start_date_time              timestamp
  ,end_date_time                timestamp
  ,goals                        NVARCHAR2(2000)
  ,results                      NVARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_trips_tasks
(
   trip_id                      NUMBER
  ,task_id                      NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .qpex_activity_budget
(
  budget_id                     NUMBER
  ,line_id                      NUMBER
  ,trip_id                      NUMBER
  ,budget_type                  NVARCHAR2(240)
  ,currency_code                NVARCHAR2(100)
  ,budget_value                 NVARCHAR2(1000)
  ,expense_amount               NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE &custom_schema .qpex_activity_attachments
(
   file_id                      NUMBER
  ,reference_id                 NUMBER
  ,reference_type               VARCHAR2(100)
  ,attachment_type              VARCHAR2(100)
  ,file_name                    VARCHAR2(100)
  ,file_type				    VARCHAR2(100)
  ,file_content			    	BLOB
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_activity_comments
(
   comment_id                   NUMBER
  ,comment_type                 VARCHAR2(100)
  ,comment_data                 NVARCHAR2(2000)
  ,parent_id				    NUMBER
  ,activity_id                  NUMBER
  ,activity_type                VARCHAR2(100)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_activity_subtask
(
   sub_task_id                   NUMBER
  ,task_id                       NUMBER
  ,sub_task_title                NVARCHAR2(500)
  ,assigned_user_id	             NUMBER
  ,sub_task_description          NVARCHAR2(2000)
  ,sub_task_display_order        NUMBER
  ,sub_task_priority             VARCHAR2(100)
  ,due_date                      timestamp
  ,Created_id                    NUMBER
  ,Created_Date                  timestamp DEFAULT SYSDATE
  ,Recent_update_date            timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id        NUMBER
  ,Additional_info_group         VARCHAR2(60)
  ,Additional_info_1             VARCHAR2(240)
  ,Additional_info_2             VARCHAR2(240)
  ,Additional_info_3             VARCHAR2(240)
  ,Additional_info_4             VARCHAR2(240)
  ,Additional_info_5             VARCHAR2(240)
  ,Additional_info_6             VARCHAR2(240)
  ,Additional_info_7             VARCHAR2(240)
  ,Additional_info_8             VARCHAR2(240)
  ,Additional_info_9             VARCHAR2(240)
  ,Additional_info_10            VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_activity_collaborators
(
   task_id                      NUMBER
  ,user_id                      NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_activity_log
(
   task_id                      NUMBER
  ,log_message                  VARCHAR2(1500)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_task_order
(
   task_id                      NUMBER
  ,user_id                      NUMBER
  ,status                       NVARCHAR2(50)
  ,display_order                NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_activity_goals
(
   goal_id                      NUMBER
  ,goal_name                    NVARCHAR2(500)
  ,goal_description             NVARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_activity_managers
(
   employee_id                  NUMBER
  ,manager_id                   NUMBER
  ,org_id                       NUMBER
  ,module_name                  VARCHAR2(200)
  ,primary_approver             VARCHAR2(60)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_activity_chat_threads
(
   chat_id                      NUMBER
  ,chat_creator                 NUMBER
  ,chat_recipient               NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE SEQUENCE &custom_schema .qpex_activity_trip_header_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_activity_task_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE &custom_schema .qpex_activity_trip_lines_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_activity_budget_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE &custom_schema .qpex_activity_attachments_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE &custom_schema .qpex_activity_comments_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE &custom_schema .qpex_activity_subtask_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE &custom_schema .qpex_activity_goals_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE &custom_schema .qpex_activity_chat_threads_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SYNONYM qpex_activity_trip_header_s
   FOR xalmo.qpex_activity_trip_header_s;

CREATE SYNONYM qpex_activity_task_s
   FOR xalmo.qpex_activity_task_s;

CREATE SYNONYM qpex_activity_trip_lines_s
   FOR xalmo.qpex_activity_trip_lines_s;

CREATE SYNONYM qpex_activity_budget_s
   FOR xalmo.qpex_activity_budget_s;

CREATE SYNONYM qpex_activity_attachments_s
   FOR xalmo.qpex_activity_attachments_s;

CREATE SYNONYM qpex_activity_comments_s
   FOR xalmo.qpex_activity_comments_s;

CREATE SYNONYM qpex_activity_subtask_s
   FOR xalmo.qpex_activity_subtask_s;

CREATE SYNONYM qpex_activity_goals_s
   FOR xalmo.qpex_activity_goals_s;

CREATE SYNONYM qpex_activity_chat_threads_s
   FOR xalmo.qpex_activity_chat_threads_s;

CREATE SYNONYM qpex_trips_tasks
   FOR xalmo.qpex_trips_tasks;

CREATE SYNONYM qpex_activity_trip_header
   FOR xalmo.qpex_activity_trip_header;

CREATE SYNONYM qpex_activity_task
   FOR xalmo.qpex_activity_task;

CREATE SYNONYM qpex_activity_trip_lines
   FOR xalmo.qpex_activity_trip_lines;

CREATE SYNONYM qpex_activity_budget
   FOR xalmo.qpex_activity_budget;

CREATE SYNONYM qpex_activity_attachments
   FOR xalmo.qpex_activity_attachments;

CREATE SYNONYM qpex_activity_comments
   FOR xalmo.qpex_activity_comments;

CREATE SYNONYM qpex_activity_subtask
   FOR xalmo.qpex_activity_subtask;

CREATE SYNONYM qpex_activity_collaborators
   FOR xalmo.qpex_activity_collaborators;

CREATE SYNONYM qpex_activity_log
   FOR xalmo.qpex_activity_log;

CREATE SYNONYM qpex_task_order
   FOR xalmo.qpex_task_order;

CREATE SYNONYM qpex_activity_goals
   FOR xalmo.qpex_activity_goals;

CREATE SYNONYM qpex_activity_managers
   FOR xalmo.qpex_activity_managers;

CREATE SYNONYM qpex_activity_chat_threads
   FOR xalmo.qpex_activity_chat_threads;