 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    dsv.sql                                                                  |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates DSV DB Objects                                                   |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 03-Jan-21    SREELEKHA    Created.                                          |
 +=============================================================================*/


CREATE TABLE &custom_schema .qpex_dsv_header
(
   dsv_header_id                NUMBER
  ,invoice_no                   NUMBER
  ,net_weight                   NUMBER
  ,gross_weight                 NUMBER
  ,container_no                 NVARCHAR2(500)
  ,total_cartons                NUMBER
  ,last_downloaded_on           TIMESTAMP
  ,uom                          NVARCHAR2(200)
  ,uploaded_filename            NVARCHAR2(500)
  ,exported_filename            NVARCHAR2(500)
  ,status                       VARCHAR2(5) DEFAULT 'A'
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);  


 CREATE TABLE &custom_schema .qpex_dsv_item_lines
(
   buyer_id                     NUMBER
  ,item_code                    NVARCHAR2(200)
  ,dsv_header_id                NUMBER
  ,codes                        NVARCHAR2(250)
  ,cartons                      NUMBER
  ,expiry_date                  TIMESTAMP
  ,batch_number                 NVARCHAR2(250) 
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE &custom_schema .qpex_dsv_header_history
(
   dsv_history_id               NUMBER
  ,dsv_header_id                NUMBER
  ,description                  NVARCHAR2(1000)
  ,notes                        NVARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


  CREATE SEQUENCE &custom_schema .qpex_dsv_header_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_dsv_item_lines_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .qpex_dsv_header_history_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SYNONYM qpex_dsv_header
   FOR xalmo.qpex_dsv_header;

CREATE SYNONYM qpex_dsv_header_s
   FOR xalmo.qpex_dsv_header_s;

CREATE SYNONYM qpex_dsv_item_lines_s
   FOR xalmo.qpex_dsv_item_lines_s;

CREATE SYNONYM qpex_dsv_item_lines
   FOR xalmo.qpex_dsv_item_lines;

CREATE SYNONYM qpex_dsv_header_history_s
   FOR xalmo.qpex_dsv_header_history_s;

CREATE SYNONYM qpex_dsv_header_history
   FOR xalmo.qpex_dsv_header_history;


 CREATE TABLE &custom_schema .qpex_dsv_suppliers
(
   dsv_supplier_id               NUMBER
  ,supplier_lookup               NVARCHAR2(1000)
  ,supplier_name                 NVARCHAR2(2000)
);

  CREATE SEQUENCE &custom_schema .qpex_dsv_suppliers_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SYNONYM qpex_dsv_suppliers_s
   FOR xalmo.qpex_dsv_suppliers_s;

CREATE SYNONYM qpex_dsv_suppliers
   FOR xalmo.qpex_dsv_suppliers;