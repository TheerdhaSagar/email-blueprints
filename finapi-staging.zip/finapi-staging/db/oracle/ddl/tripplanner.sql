 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    triplanner.sql                                                           |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Trip Planner DB Objects needed for QPIT Cruscott Products        |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 14-FEB-19    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


 CREATE TABLE &custom_schema .Qpex_trip_calendar
(
   trip_id                      NUMBER
  ,trip_title                   VARCHAR2(50)
  ,trip_description             VARCHAR2(2000)
  ,Requested_id                 NUMBER
  ,start_date					          timestamp
  ,end_date	  			            timestamp
  ,trip_budget     				      NUMBER
  ,currency_code                VARCHAR2(100)
  ,location                     VARCHAR2(500)
  ,status						            VARCHAR2(20)
  ,approval_id			    	      NUMBER
  ,approval_status						  VARCHAR2(20)
  ,approval_comments					  VARCHAR2(1500)
  ,user_comments					      VARCHAR2(1200)
  ,purpose_achieved             VARCHAR2(10)
  ,notes						            VARCHAR2(3000)
  ,has_attachments              VARCHAR2(10)
  ,org_id                       NUMBER
  ,expense_header_id            NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


 CREATE TABLE &custom_schema .Qpex_trip_attachments
(
   trip_id                      NUMBER
  ,attachment_id                NUMBER
  ,file_name                    VARCHAR2(100)
  ,file_type						        VARCHAR2(100)
  ,file_content			    	      BLOB
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE SEQUENCE &custom_schema .Qpex_trip_calendar_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE &custom_schema .Qpex_trip_attachments_s
START WITH 1
INCREMENT BY 1
NOCACHE;