 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    humanandwildlife.sql                                                     |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Invitation, Contact, Association DB Objects                      |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 13-APR-20    Sreelekha    Created.                                          |
 +=============================================================================*/

CREATE TABLE &custom_schema .qpex_hw_invitations
(
   invitation_id                    NUMBER
  ,invitation_key                   VARCHAR2(100)
  ,association_id                   NUMBER
  ,association_name					NVARCHAR2(250)
  ,status			    	        VARCHAR2(1)
  ,contact_id                       NUMBER
  ,sender_id                        NUMBER
  ,subject                          NVARCHAR2(250)
  ,message                          NCLOB
  ,country_code                     VARCHAR2(60)
  ,language                         VARCHAR2(20)
  ,org_id                           NUMBER
  ,created_id                       NUMBER
  ,created_Date                     timestamp DEFAULT SYSDATE
  ,recent_update_date               timestamp DEFAULT SYSDATE
  ,recent_updated_user_id           NUMBER
  ,additional_info_group            VARCHAR2(60)
  ,additional_info_1                VARCHAR2(240)
  ,additional_info_2                VARCHAR2(240)
  ,additional_info_3                VARCHAR2(240)
  ,additional_info_4                VARCHAR2(240)
  ,additional_info_5                VARCHAR2(240)
  ,additional_info_6                VARCHAR2(240)
  ,additional_info_7                VARCHAR2(240)
  ,additional_info_8                VARCHAR2(240)
  ,additional_info_9                VARCHAR2(240)
  ,additional_info_10               VARCHAR2(240)
);


CREATE TABLE &custom_schema .qpex_hw_contacts
(
   contact_id                       NUMBER
  ,contact_user_id                  NUMBER
  ,first_name                       NVARCHAR2(120)
  ,last_name                        NVARCHAR2(120)
  ,association_id                   NUMBER
  ,email                            NVARCHAR2(120)
  ,phone                            VARCHAR2(30)
  ,status                           VARCHAR2(1)
  ,primary_flag						VARCHAR2(1)
  ,created_id                       NUMBER
  ,created_date                     timestamp DEFAULT SYSDATE
  ,recent_update_date               timestamp DEFAULT SYSDATE
  ,recent_updated_user_id           NUMBER
  ,additional_info_group            VARCHAR2(60)
  ,additional_info_1                VARCHAR2(240)
  ,additional_info_2                VARCHAR2(240)
  ,additional_info_3                VARCHAR2(240)
  ,additional_info_4                VARCHAR2(240)
  ,additional_info_5                VARCHAR2(240)
  ,additional_info_6                VARCHAR2(240)
  ,additional_info_7                VARCHAR2(240)
  ,additional_info_8                VARCHAR2(240)
  ,additional_info_9                VARCHAR2(240)
  ,additional_info_10               VARCHAR2(240)
);


CREATE SEQUENCE &custom_schema .qpex_hw_invitations_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SEQUENCE &custom_schema .qpex_hw_contacts_s
START WITH 1
INCREMENT BY 1
NOCACHE;



CREATE SYNONYM qpex_hw_invitations_s
   FOR xalmo.qpex_hw_invitations_s;

CREATE SYNONYM qpex_hw_contacts_s
   FOR xalmo.qpex_hw_contacts_s;


CREATE SYNONYM qpex_hw_invitations
   FOR xalmo.qpex_hw_invitations;

CREATE SYNONYM qpex_hw_contacts
   FOR xalmo.qpex_hw_contacts;


CREATE TABLE xalmo.qpex_hw_associations (
   association_id          NUMBER PRIMARY KEY,
   association_name        NVARCHAR2(250) NOT NULL,
   status                  VARCHAR2(1),
   type                    VARCHAR2(60),
   sub_type                VARCHAR2(60),
   address_id              NUMBER,
   ship_to_address_id      NUMBER,
   website_url             VARCHAR2(250),
   facebook_url            VARCHAR2(250),
   instagram_url           VARCHAR2(250),
   supported_activities    VARCHAR2(500),
   country_code            VARCHAR2(60),
   language                VARCHAR2(20),
   no_of_partners           NUMBER,
   no_of_dogs              NUMBER,
   org_id                  NUMBER,
   project_proposal        NCLOB,
   created_by              NUMBER,
   created_date            DATE,
   last_updated_by         NUMBER,
   last_updated_date       DATE,
   additional_info_group   VARCHAR2(60),
   additional_info_1       VARCHAR2(240),
   additional_info_2       VARCHAR2(240),
   additional_info_3       VARCHAR2(240),
   additional_info_4       VARCHAR2(240),
   additional_info_5       VARCHAR2(240),
   additional_info_6       VARCHAR2(240),
   additional_info_7       VARCHAR2(240),
   additional_info_8       VARCHAR2(240),
   additional_info_9       VARCHAR2(240),
   additional_info_10      VARCHAR2(240)
  );

   CREATE OR REPLACE SYNONYM qpex_hw_associations FOR xalmo.qpex_hw_associations;

   CREATE SEQUENCE qpex_hw_associations_s INCREMENT BY 1 START WITH 1 NOCACHE;

   CREATE TABLE xalmo.qpex_hw_documents (
       attachment_id           NUMBER PRIMARY KEY,
       association_id          NUMBER NOT NULL,
       file_type               VARCHAR2(60) NOT NULL,
       file_data               BLOB NOT NULL,
       document_type           VARCHAR2(60) NOT NULL,
       created_by              NUMBER,
       created_date            DATE,
       last_updated_by         NUMBER,
       last_updated_date       DATE,
       additional_info_group   VARCHAR2(60),
       additional_info_1       VARCHAR2(240),
       additional_info_2       VARCHAR2(240),
       additional_info_3       VARCHAR2(240),
       additional_info_4       VARCHAR2(240),
       additional_info_5       VARCHAR2(240),
       additional_info_6       VARCHAR2(240),
       additional_info_7       VARCHAR2(240),
       additional_info_8       VARCHAR2(240),
       additional_info_9       VARCHAR2(240),
       additional_info_10      VARCHAR2(240)
   );

   CREATE OR REPLACE SYNONYM qpex_hw_documents FOR xalmo.qpex_hw_documents;

   CREATE SEQUENCE qpex_hw_documents_s INCREMENT BY 1 START WITH 1 NOCACHE;

   CREATE TABLE xalmo.qpex_hw_addresses (
       address_id              NUMBER PRIMARY KEY,
       type                    VARCHAR2(60),
       location_id              NUMBER NOT NULL,
       status                  VARCHAR2(1),
       created_by              NUMBER,
       created_date            DATE,
       last_updated_by         NUMBER,
       last_updated_date       DATE,
       additional_info_group   VARCHAR2(60),
       additional_info_1       VARCHAR2(240),
       additional_info_2       VARCHAR2(240),
       additional_info_3       VARCHAR2(240),
       additional_info_4       VARCHAR2(240),
       additional_info_5       VARCHAR2(240),
       additional_info_6       VARCHAR2(240),
       additional_info_7       VARCHAR2(240),
       additional_info_8       VARCHAR2(240),
       additional_info_9       VARCHAR2(240),
       additional_info_10      VARCHAR2(240)
   );

   CREATE OR REPLACE SYNONYM qpex_hw_addresses FOR xalmo.qpex_hw_addresses;

   CREATE SEQUENCE qpex_hw_addresses_s INCREMENT BY 1 START WITH 1 NOCACHE;

   CREATE TABLE xalmo.qpex_donation_locations (
       location_id             NUMBER PRIMARY KEY,
       address_line_1          NVARCHAR2(250),
       address_line_2          NVARCHAR2(250),
       city                    NVARCHAR2(100),
       province                NVARCHAR2(200),
       zip                     VARCHAR2(100) NOT NULL,
       country                 VARCHAR2(60) NOT NULL,
       lat                     NUMBER,
       lng                     NUMBER,
       created_by              NUMBER,
       created_date            DATE,
       last_updated_by         NUMBER,
       last_updated_date       DATE,
       additional_info_group   VARCHAR2(60),
       additional_info_1       VARCHAR2(240),
       additional_info_2       VARCHAR2(240),
       additional_info_3       VARCHAR2(240),
       additional_info_4       VARCHAR2(240),
       additional_info_5       VARCHAR2(240),
       additional_info_6       VARCHAR2(240),
       additional_info_7       VARCHAR2(240),
       additional_info_8       VARCHAR2(240),
       additional_info_9       VARCHAR2(240),
       additional_info_10      VARCHAR2(240)
   );

   CREATE OR REPLACE SYNONYM qpex_donation_locations FOR xalmo.qpex_donation_locations;

   CREATE SEQUENCE qpex_donation_locations_s INCREMENT BY 1 START WITH 1 NOCACHE;

   CREATE TABLE xalmo.qpex_hw_partner_associations (
       partner_association_id               NUMBER PRIMARY KEY,
       association_id                       NUMBER,
       partner_association_name             NVARCHAR2(250),
       status                               VARCHAR2(1),
       address_id                           NUMBER,
       website_url                          NVARCHAR2(250),
       facebook_url                         NVARCHAR2(250),
       instagram_url                        NVARCHAR2(250),
       product_types                        VARCHAR2(1000),
       primary_sales                        VARCHAR2(1000),
       primary_certifications              VARCHAR2(1000),
       biodiversity_impact                  VARCHAR2(1000),
       no_of_livestock                      NUMBER,
       org_id                               NUMBER,
       created_by                           NUMBER,
       created_date                         TIMESTAMP DEFAULT SYSDATE,
       last_updated_by                      NUMBER,
       last_updated_date                    TIMESTAMP DEFAULT SYSDATE,
       additional_info_group                VARCHAR2(60),
       additional_info_1                    VARCHAR2(240),
       additional_info_2                    VARCHAR2(240),
       additional_info_3                    VARCHAR2(240),
       additional_info_4                    VARCHAR2(240),
       additional_info_5                    VARCHAR2(240),
       additional_info_6                    VARCHAR2(240),
       additional_info_7                    VARCHAR2(240),
       additional_info_8                    VARCHAR2(240),
       additional_info_9                    VARCHAR2(240),
       additional_info_10                   VARCHAR2(240)
   );

   CREATE OR REPLACE SYNONYM qpex_hw_partner_associations FOR xalmo.qpex_hw_partner_associations;

   CREATE SEQUENCE qpex_hw_partner_associations_s INCREMENT BY 1 START WITH 1 NOCACHE;

   CREATE TABLE xalmo.qpex_hw_pet_details (
       pet_id                               NUMBER PRIMARY KEY,
       partner_association_id               NUMBER,
       pet_name                             NVARCHAR2(250),
       pet_race                             NVARCHAR2(250),
       pet_age                              NUMBER,
       training_received                    VARCHAR2(1000),
       health_rating                        NUMBER,
       work_attitude_rating                 NUMBER,
       tourist_attitude_rating              NUMBER,
       created_by                           NUMBER,
       created_date                         TIMESTAMP DEFAULT SYSDATE,
       last_updated_by                      NUMBER,
       last_updated_date                    TIMESTAMP DEFAULT SYSDATE,
       additional_info_group                VARCHAR2(60),
       additional_info_1                    VARCHAR2(240),
       additional_info_2                    VARCHAR2(240),
       additional_info_3                    VARCHAR2(240),
       additional_info_4                    VARCHAR2(240),
       additional_info_5                    VARCHAR2(240),
       additional_info_6                    VARCHAR2(240),
       additional_info_7                    VARCHAR2(240),
       additional_info_8                    VARCHAR2(240),
       additional_info_9                    VARCHAR2(240),
       additional_info_10                   VARCHAR2(240)
   );

   CREATE OR REPLACE SYNONYM qpex_hw_pet_details FOR xalmo.qpex_hw_pet_details;

   CREATE SEQUENCE qpex_hw_pet_details_s INCREMENT BY 1 START WITH 1 NOCACHE;


   CREATE TABLE xalmo.qpex_hw_partner_donations (
       partner_association_id               NUMBER,
       donation_date                        TIMESTAMP,
       quantity                             NUMBER,
       created_by                           NUMBER,
       created_date                         TIMESTAMP DEFAULT SYSDATE,
       last_updated_by                      NUMBER,
       last_updated_date                    TIMESTAMP DEFAULT SYSDATE,
       additional_info_group                VARCHAR2(60),
       additional_info_1                    VARCHAR2(240),
       additional_info_2                    VARCHAR2(240),
       additional_info_3                    VARCHAR2(240),
       additional_info_4                    VARCHAR2(240),
       additional_info_5                    VARCHAR2(240),
       additional_info_6                    VARCHAR2(240),
       additional_info_7                    VARCHAR2(240),
       additional_info_8                    VARCHAR2(240),
       additional_info_9                    VARCHAR2(240),
       additional_info_10                   VARCHAR2(240)
   );

   CREATE OR REPLACE SYNONYM qpex_hw_partner_donations FOR xalmo.qpex_hw_partner_donations;
