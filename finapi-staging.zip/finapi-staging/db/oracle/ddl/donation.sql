/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    qpex_db_objects_pet_for_life.sql                                                      |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates pet for life DB Objects needed for QPIT Cruscott Products                  |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 27-Feb-18    Theerdha Sagar Nimmagadda     Created.                                            |
 +=============================================================================*/





CREATE TABLE &custom_schema .Qpex_ext_organizations
(
   Org_id                       NUMBER            PRIMARY KEY
  ,Org_name                     NVARCHAR2(50)      NOT NULL
  ,Org_type                     VARCHAR2(50)
  ,Org_unique_code              VARCHAR2(50)
  ,Telephone                    VARCHAR2(50)
  ,Address                      NVARCHAR2(240)
  ,City                         NVARCHAR2(50)
  ,Zip                          VARCHAR2(50)
  ,Country                      VARCHAR2(50)
  ,Website_Url                  VARCHAR2(50)
  ,Facebook_Page                VARCHAR2(50)
  ,Created_by                   NUMBER
  ,Created_Date                timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .QPEX_ext_org_users
(
   User_id                      NUMBER            PRIMARY KEY
  ,Org_id                       NUMBER
  ,User_name                    VARCHAR2(50)       NOT NULL
  ,Encrypted_passwd             VARCHAR2(100)      NOT NULL
  ,User_email                   VARCHAR2(50)
  ,User_telephone               VARCHAR2(50)
  ,Address                      NVARCHAR2(240)
  ,Subscribe_to_advs            VARCHAR2(3)
  ,Cust_acct_site_id            NUMBER
  ,Approval_status              VARCHAR2(20)
  ,Approved_by                  NUMBER          --References qpex_client_users
  ,UI_language                  VARCHAR2(20)
  ,Created_by                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .QPEX_ext_user_request_headers
(
   Request_header_id            NUMBER            PRIMARY KEY
  ,Org_id                       NUMBER            NOT NULL
  ,Application_no               VARCHAR2(100)
  ,Assigned_agent_user_id       NUMBER
  ,Request_status               VARCHAR2(100)      NOT NULL
  ,Request_type                 VARCHAR2(50)
  ,Quote_header_id              NUMBER
  ,Created_by                   NUMBER
  ,Created_Date                TIMESTAMP DEFAULT systimestamp
  ,Recent_update_date           TIMESTAMP DEFAULT systimestamp
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .QPEX_ext_user_request_lines
(
   Request_line_id              NUMBER            PRIMARY KEY
  ,Request_header_id            NUMBER            NOT NULL
  ,Pet_type                     VARCHAR2(100)
  ,No_of_pets                   NUMBER
  ,No_of_qty                    NUMBER
  ,Created_by                   NUMBER
  ,Created_Date                TIMESTAMP DEFAULT systimestamp
  ,Recent_update_date           TIMESTAMP DEFAULT systimestamp
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .QPEX_ext_user_request_attchmts
(
   Atthmt_id                    NUMBER            PRIMARY KEY
  ,Request_header_id            NUMBER            NOT NULL
  ,File_name                    VARCHAR2(100)
  ,File_type                    VARCHAR2(100)
  ,File_data                    blob
  ,Created_by                   NUMBER
  ,Created_Date                TIMESTAMP DEFAULT systimestamp
  ,Recent_update_date           TIMESTAMP DEFAULT systimestamp
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .Qpex_ext_user_adoptions
(
   Adoptions_id                 NUMBER            PRIMARY KEY
  ,Request_header_id            NUMBER            NOT NULL
  ,Pet_type                     VARCHAR2(100)
  ,No_of_qty                    NUMBER
  ,Unique_code                  VARCHAR2(100)
  ,Is_coupon_generated          VARCHAR2(10)
  ,Created_by                   NUMBER
  ,Created_Date                DATE DEFAULT SYSDATE
  ,Recent_update_date           DATE DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


ALTER TABLE &custom_schema .QPEX_SITE_COUPONS ADD unique_code VARCHAR2(100);
ALTER TABLE &custom_schema .QPEX_SITE_COUPONS ADD is_coupon_redeem VARCHAR2(10);


CREATE TABLE &custom_schema .Qpex_api_management
(
   Api_id                       NUMBER            PRIMARY KEY
  ,Client_id                    NUMBER      NOT NULL
  ,Client_name                  VARCHAR2(50)
  ,Api_key                      VARCHAR2(50)
  ,Api_secret                   VARCHAR2(50)
  ,Created_by                   NUMBER
  ,Created_date                 TIMESTAMP DEFAULT systimestamp
  ,Recent_update_date           TIMESTAMP DEFAULT systimestamp
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .qpex_ext_org_notes (
    note_id                  NUMBER,
    org_id                   NUMBER,
    notes                    VARCHAR2(500),
    create_date              TIMESTAMP,
    created_user_id          NUMBER,
    recent_update_date       TIMESTAMP,
    recent_updated_user_id   NUMBER,
    additional_info_group    VARCHAR2(60),
    additional_info_1        VARCHAR2(240),
    additional_info_2        VARCHAR2(240),
    additional_info_3        VARCHAR2(240),
    additional_info_4        VARCHAR2(240),
    additional_info_5        VARCHAR2(240),
    additional_info_6        VARCHAR2(240),
    additional_info_7        VARCHAR2(240),
    additional_info_8        VARCHAR2(240),
    additional_info_9        VARCHAR2(240),
    additional_info_10       VARCHAR2(240)
);

create TABLE &custom_schema .qpex_ext_org_attchmts (
    atthmt_id                NUMBER PRIMARY KEY,
    org_id                   NUMBER NOT NULL,
    file_name                VARCHAR2(100),
    file_type                VARCHAR2(100),
    file_data                BLOB,
    document_type            VARCHAR2(100),
    purpose                  varchar2(100),
    created_user_id          NUMBER,
    create_date              TIMESTAMP DEFAULT systimestamp,
    recent_update_date       TIMESTAMP DEFAULT systimestamp,
    recent_updated_user_id   NUMBER,
    additional_info_group    VARCHAR2(60),
    additional_info_1        VARCHAR2(240),
    additional_info_2        VARCHAR2(240),
    additional_info_3        VARCHAR2(240),
    additional_info_4        VARCHAR2(240),
    additional_info_5        VARCHAR2(240),
    additional_info_6        VARCHAR2(240),
    additional_info_7        VARCHAR2(240),
    additional_info_8        VARCHAR2(240),
    additional_info_9        VARCHAR2(240),
    additional_info_10       VARCHAR2(240)
);

create TABLE &custom_schema .qpex_association_locator (
    association_id           NUMBER,
    association_name         VARCHAR2(500),
    status                   VARCHAR2(10),
    address_line_1           VARCHAR2(200),
    address_line_2           VARCHAR2(200),
    address_line_3           VARCHAR2(200),
    city                     VARCHAR2(100),
    province                 VARCHAR2(200),
    zip_code                 VARCHAR2(100),
    country                  VARCHAR2(100),
    dogs                     VARCHAR2(10),
    cats                     VARCHAR2(10),
    website                  VARCHAR2(100),
    latitude                 NUMBER,
    longitude                NUMBER,
    datasource               VARCHAR2(100),
    create_date              TIMESTAMP DEFAULT systimestamp,
    created_user_id          NUMBER,
    recent_update_date       TIMESTAMP DEFAULT systimestamp,
    recent_updated_user_id   NUMBER,
    user_verified_flag       VARCHAR2(10),
    additional_info_group    VARCHAR2(100),
    additional_info_1        VARCHAR2(240),
    additional_info_2        VARCHAR2(240),
    additional_info_3        VARCHAR2(240),
    additional_info_4        VARCHAR2(240),
    additional_info_5        VARCHAR2(240),
    additional_info_6        VARCHAR2(240),
    additional_info_7        VARCHAR2(240),
    additional_info_8        VARCHAR2(240),
    additional_info_9        VARCHAR2(240),
    additional_info_10       VARCHAR2(240)
);

create TABLE &custom_schema .qpex_association_contacts (
    association_id           NUMBER,
    contact_id               NUMBER,
    contact_type             VARCHAR2(200),
    status                   VARCHAR2(10),
    primary_flag             VARCHAR2(10),
    contact_person_name      VARCHAR2(200),
    contact_method           VARCHAR2(200),
    phone_country_code       VARCHAR2(10),
    data_source              VARCHAR2(200),
    create_date              TIMESTAMP DEFAULT systimestamp,
    created_user_id          NUMBER,
    recent_update_date       TIMESTAMP DEFAULT systimestamp,
    recent_updated_user_id   NUMBER,
    additional_info_group    VARCHAR2(100),
    additional_info_1        VARCHAR2(240),
    additional_info_2        VARCHAR2(240),
    additional_info_3        VARCHAR2(240),
    additional_info_4        VARCHAR2(240),
    additional_info_5        VARCHAR2(240),
    additional_info_6        VARCHAR2(240),
    additional_info_7        VARCHAR2(240),
    additional_info_8        VARCHAR2(240),
    additional_info_9        VARCHAR2(240),
    additional_info_10       VARCHAR2(240)
);

CREATE SEQUENCE &custom_schema .Qpex_ext_organizations_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .QPEX_ext_org_users_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .Qpex_api_management_s
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

CREATE SEQUENCE &custom_schema .QPEX_ext_request_headers_s
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

CREATE SEQUENCE &custom_schema .QPEX_ext_request_lines_s
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

CREATE SEQUENCE &custom_schema .QPEX_ext_request_attchmts_s
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

create sequence &custom_schema .qpex_ext_org_notes_s 
start with 1 
increment by 1 
nocache 
nocycle;

create sequence &custom_schema .qpex_ext_org_attchmts_s 
start with 1 
increment by 1 
nocache 
nocycle;

create sequence &custom_schema .qpex_association_locator_s
start with 1
increment by 1
nocache
nocycle;

create sequence &custom_schema .qpex_association_contacts_s
start with 1
increment by 1
nocache
nocycle;

