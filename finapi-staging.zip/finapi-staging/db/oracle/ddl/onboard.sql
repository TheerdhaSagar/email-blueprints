/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    onboard.sql                                     |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates On boarding DB Objects needed for QPIT Cruscott Products    |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 18-Oct-18    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


CREATE TABLE &custom_schema .Qpex_emp_onboaring_header
(
   onboard_header_id            NUMBER
  ,department_id                NUMBER
  ,user_id					    NUMBER
  ,org_id                       NUMBER
  ,start_date				    timestamp
  ,comments						VARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,status						VARCHAR2(20)
  ,approver_user_id				NUMBER
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .Qpex_emp_onboaring_lines
(
   onboard_lines_id             NUMBER
  ,onboard_header_id            NUMBER
  ,application_access_id        NUMBER
  ,hardware_access_id           NUMBER
  ,hardware_asset_id            VARCHAR2(240)
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .Qpex_almo_departments
(
   department_id                NUMBER
  ,department_name              VARCHAR2(60)
  ,org_id                       NUMBER
  ,manager_id                   NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,status						VARCHAR2(20)
  ,approver_user_id				NUMBER
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE &custom_schema .Qpex_onboard_application_access
(
   applications_access_id       NUMBER
  ,application_access_name      VARCHAR2(60)
  ,application_access_type      VARCHAR2(60)
  ,manager_id                   NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,status						VARCHAR2(20)
  ,approver_user_id				NUMBER
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

create sequence &custom_schema .qpex_almo_departments_s
start with 1
increment by 1
nocache
nocycle;