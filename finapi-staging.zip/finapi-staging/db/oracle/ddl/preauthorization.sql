/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    preauthorization.sql                                                     |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates On boarding DB Objects needed for QPIT Cruscott Products         |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 04-Jun-19    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


CREATE TABLE &custom_schema .Qpex_preauthorization_header
(
   authorization_id             NUMBER
  ,request_for                  VARCHAR2(240)
  ,request_type                 VARCHAR2(240)
  ,need_by				              Date
  ,has_offer                    VARCHAR2(10)
  ,estimated_cost               NUMBER
  ,currency_code                VARCHAR2(50)
  ,Description						      VARCHAR2(3000)
  ,org_id                       NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 Date DEFAULT SYSDATE
  ,Recent_update_date           Date DEFAULT SYSDATE
  ,request_status						    VARCHAR2(20)
  ,approver_user_id				      NUMBER
  ,approver_comments            VARCHAR2(3000)
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


create sequence &custom_schema .Qpex_preauthorization_header_s
start with 1
increment by 1
nocache
nocycle;

CREATE SYNONYM Qpex_preauthorization_header_s
   FOR xalmo.Qpex_preauthorization_header_s;

CREATE SYNONYM Qpex_preauthorization_header
   FOR xalmo.Qpex_preauthorization_header;