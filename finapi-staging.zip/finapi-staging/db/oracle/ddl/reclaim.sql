/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    Reclaimi.sql                                                             |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates ticket for damaged/expired products DB Objects needed for        |
 |                               QPIT Cruscott Products                        |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 15-Oct-2019    Theerdha Sagar     Created.                                  |
 +=============================================================================*/




 CREATE TABLE &custom_schema .qpex_reclaimi_customer
(
   reclaim_id                  NUMBER
  ,cust_account_id              NUMBER
  ,party_site_id                NUMBER
  ,reference_person             VARCHAR2(100)
  ,telephone_number					    NVARCHAR2(100)
  ,sales_rep_id                 NUMBER
  ,item_code                    VARCHAR2(100)
  ,problem_description          NVARCHAR2(2000)
  ,qty                          NUMBER
  ,claim_amount                 NUMBER
  ,batch_nbr                    varchar2(100)
  ,is_reported                  VARCHAR2(20)
  ,invoice_number               VARCHAR2(100)
  ,customer_trx_line_id         NUMBER
  ,internal_comments            NVARCHAR2(2000)
  ,status                       VARCHAR2(20)
  ,org_id                       NUMBER
  ,cm_header_id                 NUMBER
  ,created_id                   NUMBER
  ,created_Date                 timestamp DEFAULT SYSDATE
  ,recent_update_date           timestamp DEFAULT SYSDATE
  ,recent_updated_id            NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


 CREATE TABLE &custom_schema .qpex_reclaimi_supplier
(
   reclaim_vendor_id            NUMBER
  ,reclaim_id                  NUMBER
  ,vendor_id                    NUMBER
  ,internal_comments            NVARCHAR2(2000)
  ,supplier_comments            NVARCHAR2(2000)
  ,item_code                    VARCHAR2(100)
  ,qty                          NUMBER
  ,batch_nbr                    varchar2(100)
  ,is_reported                  VARCHAR2(20)
  ,status                       VARCHAR2(20)
  ,org_id                       NUMBER
  ,created_id                   NUMBER
  ,created_Date                 timestamp DEFAULT SYSDATE
  ,recent_update_date           timestamp DEFAULT SYSDATE
  ,recent_updated_id            NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE &custom_schema .qpex_reclaimi_attachments
(
   file_id                      NUMBER
  ,reference_id                 NUMBER
  ,reference_type               VARCHAR2(50)
  ,file_name                    VARCHAR2(100)
  ,file_type				            VARCHAR2(100)
  ,file_content			    	      BLOB
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE SEQUENCE &custom_schema .qpex_reclaim_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_reclaim_supplier_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .qpex_reclaimi_attachments_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SYNONYM qpex_reclaim_s
   FOR xalmo.qpex_reclaim_s;

CREATE SYNONYM qpex_reclaim_supplier_s
   FOR xalmo.qpex_reclaim_supplier_s;

CREATE SYNONYM qpex_reclaimi_attachments_s
   FOR xalmo.qpex_reclaimi_attachments_s;

CREATE SYNONYM qpex_reclaimi_supplier
   FOR xalmo.qpex_reclaimi_supplier;

CREATE SYNONYM qpex_reclaimi_customer
   FOR xalmo.qpex_reclaimi_customer;

CREATE SYNONYM qpex_reclaimi_attachments
   FOR xalmo.qpex_reclaimi_attachments;
