/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    leavemanagement.sql                                     |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Leave Management DB Objects needed for QPIT Cruscott Products    |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 20-Sep-18    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


CREATE TABLE &custom_schema .Qpex_leave_management
(
   Leave_id                     NUMBER
  ,Leave_type                   VARCHAR2(50)
  ,from_date					timestamp
  ,upto_date				    timestamp
  ,reason						VARCHAR2(1000)
  ,Applied_by                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,status						VARCHAR2(20)
  ,manager_user_id				NUMBER
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE &custom_schema .Qpex_holiday_calender
(
   Holiday_id 					NUMBER
  ,Holiday_name					VARCHAR2(20)
  ,description					VARCHAR2(1000)
  ,Org_id						NUMBER
  ,Holiday_date					timestamp
  ,Created_by                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Year                         NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
)



CREATE TABLE &custom_schema .Qpex_Leave_TYPES
(
   Leave_type_id				NUMBER
  ,Leave_type 					VARCHAR2(50)
  ,DESCRIPTION					VARCHAR2(1000)
  ,Org_id						NUMBER
  ,Leave_count 					NUMBER
  ,Created_by                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Year                         NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
)


CREATE SEQUENCE &custom_schema .Qpex_leave_management_s
START WITH 1
INCREMENT BY 1
NOCACHE;


CREATE SEQUENCE &custom_schema .Qpex_holidays_list_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE SEQUENCE &custom_schema .Qpex_leave_type_s
START WITH 1
INCREMENT BY 1
NOCACHE;
